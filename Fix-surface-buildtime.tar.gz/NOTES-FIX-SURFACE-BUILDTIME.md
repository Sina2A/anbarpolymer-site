# یادداشت تحویل — اصلاح ناسازگاری SURFACE در زمان Build و دیپلوی مشترک

## چرا تحویل قبلی ناسازگار بود
`next.config.ts` با `env: { SURFACE: process.env.SURFACE }` مقدار را **زمان `next build`** داخل
باندل Client inline می‌کند (مستندات Next.js: env at build time). دیپلوی واقعی پروژه یک `npm run build`
مشترک (SURFACE خالی) + سه pm2 جدا (`anbarpolymer` / `anbarpolymer-admin` / `anbarpolymer-transport`)
با `SURFACE` متفاوت از همان خروجی مشترک است. نتیجه: هر سه پورت مقدار زمان build (مثلاً `''`) را
می‌دیدند و `PublicHeader`/`PanelHeader`/`TransportPanelShell` که `'use client'` هستند روی هر سه پورت
همان `/` را برمی‌گرداندند — دقیقاً باگی که می‌خواستیم رفع کنیم. `manifest.ts` هم کاملاً استاتیک بود و
`start_url` هم زمان build قفل می‌شد.

## راه‌حل

### ۱) `next.config.ts` → برگشت به خالی
```ts
const nextConfig: NextConfig = {};
```
inline زمان build حذف شد.

### ۲) `middleware.ts` → سه‌حالته + هدر زنده `x-app-surface`
- `resolveSurface()` → `'admin' | 'transport' | 'public'` (قبلاً فقط `admin|public` و `transport` گم بود).
- **رفتار مسدودسازی دقیقاً مثل قبل می‌ماند** (طبق تایید):
  - `admin`: فقط مسیرهای ادمین (`/admin-`, `/my-tasks`) مجازند؛ بقیه → `/404`
  - `public`: مسیرهای ادمین → `/404`
  - `transport`: مثل `public`، مسیرهای ادمین → `/404` (قبلاً چون به `public` می‌افتاد همین بود)
  سه‌حالته‌شدن فقط شاخه‌ی `transport` را صریح می‌کند؛ دو شاخه‌ی قبلی بی‌تغییر.
- هر پاسخ `NextResponse.next()` یا `rewrite` حالا `res.headers.set('x-app-surface', surface)` می‌گیرد.
  middleware هر درخواست واقعاً اجرا می‌شود و `process.env.SURFACE` همان پردازش pm2 را می‌بیند —
  پس هدر همیشه درست است.

### ۳) `src/lib/surfaceHome.ts` → helper برای هدر
- `SURFACE_HOME` و `getSurfaceHome()` (Server) بدون تغییر.
- اضافه: `getSurfaceHomeFromHeader(s: string|null)` و `normalizeSurface()` برای خواندن مقدار هدر.

### ۴) `src/components/{PublicHeader,PanelHeader,TransportPanelShell}.tsx` → prop
هر سه Client بودند و مستقیم `getSurfaceHome()` (یعنی `process.env.SURFACE`) می‌خواندند — حذف شد.
حالا `homeHref?: string` (default `'/'`) می‌گیرند و `href={homeHref}` رندر می‌کنند.
این prop فقط یک سطح از والد Server همان هدر پاس داده می‌شود.

### ۵) همه‌ی صفحاتی که این هدرها را رندر می‌کنند → `homeHref={getSurfaceHome()}`
- Public (۱۱ صفحه): `page.tsx`, `about`, `contact`, `grades`, `grades/[code]`, `market`, `warehouses`, `services`, `reports`, `reports/[id]`, `transport`
- Panel (۱۶ صفحه): `account`, `custom-request`, `dashboard`, `my-deals`, `my-deals/[id]`, `my-listings`, `my-orders`, `my-requests`, `new-listing`, `price-alerts`, `proformas`, `proformas/[id]`, `purchase-requests`, `support`, `support/[id]`, `verification`, `rfq`
- `src/app/transport-panel/layout.tsx` → `<TransportPanelShell homeHref={getSurfaceHome()}>`
والدها خودشان Server و داخل صفحات `force-dynamic` هستند، پس `process.env.SURFACE` زمان درخواست زنده است.

### ۶) `src/components/{BrandMark,Footer,TransportPanelFooter}.tsx` (Server) → دست‌نخورده
همچنان `getSurfaceHome()` — چون صفحات والد `force-dynamic` هستند درست است.

### ۷) `src/app/manifest.ts` → `force-dynamic` + خواندن هدر
```ts
export const dynamic = 'force-dynamic'
export default async function manifest() {
  const surface = (await headers()).get('x-app-surface')
  const startUrl = surface ? getSurfaceHomeFromHeader(surface) : getSurfaceHome()
}
```
اگر `manifest.ts` استاتیک بماند، `start_url` زمان build مشترک قفل می‌شود. با `force-dynamic` هر
درخواست `manifest.webmanifest` مقدار همان pm2 را برمی‌گرداند. اگر Next 16 این را برای metadata مجاز
نداند، fallback یک Route Handler `manifest.webmanifest/route.ts` با همین منطق است (فعلاً لازم نشد).

## فایل‌های تغییریافته
- `next.config.ts`
- `middleware.ts`
- `src/lib/surfaceHome.ts`
- `src/app/manifest.ts`
- `src/components/PublicHeader.tsx`, `PanelHeader.tsx`, `TransportPanelShell.tsx`
- صفحات: `src/app/page.tsx`, `about/page.tsx`, `contact/page.tsx`, `grades/page.tsx`, `grades/[code]/page.tsx`, `market/page.tsx`, `warehouses/page.tsx`, `services/page.tsx`, `reports/page.tsx`, `reports/[id]/page.tsx`, `rfq/page.tsx`, `transport/page.tsx`, `account/page.tsx`, `custom-request/page.tsx`, `dashboard/page.tsx`, `my-deals/page.tsx`, `my-deals/[id]/page.tsx`, `my-listings/page.tsx`, `my-orders/page.tsx`, `my-requests/page.tsx`, `new-listing/page.tsx`, `price-alerts/page.tsx`, `proformas/page.tsx`, `proformas/[id]/page.tsx`, `purchase-requests/page.tsx`, `support/page.tsx`, `support/[id]/page.tsx`, `verification/page.tsx`, `src/app/transport-panel/layout.tsx`

## راستی‌آزمایی
- `grep -rn "process.env.SURFACE" src/components/PublicHeader.tsx src/components/PanelHeader.tsx src/components/TransportPanelShell.tsx` → صفر
- `grep -rn "<PublicHeader|<PanelHeader|<TransportPanelShell" src/app --include="*.tsx" | grep -v homeHref` → صفر (همه prop گرفته‌اند)
- `npx tsc --noEmit` → EXIT 0
