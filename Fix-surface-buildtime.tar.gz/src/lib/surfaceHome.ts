// src/lib/surfaceHome.ts
//
// نگاشت متمرکز «خانه‌ی هر سطح» — هم manifest و هم لینک‌های لوگو از همین‌جا می‌خوانند.
// برای Server Components داخل صفحات force-dynamic، process.env.SURFACE زمان
// درخواست زنده است. برای Client Components مقدار باید از والد Server به‌صورت
// prop پاس داده شود (چون Client باندل SURFACE را زمان build قفل می‌کند).

export const SURFACE_HOME: Record<string, string> = {
  admin: '/admin-orders',
  transport: '/transport-panel',
}

export function getSurfaceHome(): string {
  return SURFACE_HOME[process.env.SURFACE ?? ''] ?? '/'
}

// مقدار هدر x-app-surface که middleware ست می‌کند — برای خواندن در Server
// والد و پاس‌دادن به Client، یا در manifest (force-dynamic).
export function getSurfaceHomeFromHeader(surface: string | null | undefined): string {
  return SURFACE_HOME[surface ?? ''] ?? '/'
}

export function normalizeSurface(value: string | null | undefined): string {
  return value === 'admin' || value === 'transport' ? value : 'public'
}
