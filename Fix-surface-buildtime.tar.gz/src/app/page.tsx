import { getCurrentUserOrNull } from '@/lib/currentUser'
import { getSurfaceHome } from '@/lib/surfaceHome'
import PublicHeader from '@/components/PublicHeader'
import Footer from '@/components/Footer'
import prisma from '@/lib/prisma'

export const dynamic = 'force-dynamic'

const home = {
  navy: '#1E357B',
  navyDark: '#16285F',
  orange: '#E65716',
  orangeDark: '#c94a10',
  orangeSoft: '#FFF1EA',
  bgPage: '#F7F8FA',
  bgCard: '#ffffff',
  borderSubtle: '#E4E7EC',
  textPrimary: '#172033',
  textSecondary: '#475467',
  textMuted: '#667085',
} as const

export default async function Home() {
  const user = await getCurrentUserOrNull()
  const [gradeCount, baseCount] = await Promise.all([
    prisma.grade.count({ where: { isActive: true } }),
    prisma.grade
      .findMany({ where: { isActive: true }, select: { category: true }, distinct: ['category'] })
      .then((r: { category: string }[]) => r.length),
  ])

  return (
    <div style={{ background: home.bgPage, minHeight: '100vh' }}>
      <PublicHeader homeHref={getSurfaceHome()} activePage="/" isLoggedIn={!!user} />

      <main>
        {/* Hero */}
        <section className="home-hero">
          <div className="home-hero-pattern" aria-hidden />
          <div className="home-hero-glow" aria-hidden />
          <div className="home-hero-inner">
            <div className="home-hero-eyebrow">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.2}><path d="M13 2 3 14h7l-1 8 10-12h-7z" /></svg>
              بازار صنعتی زنده و به‌روز
            </div>
            <h1 className="home-hero-title">
              خرید و فروش <span>مواد اولیه پلیمری</span>
              <br />
              مستقیم و بدون واسطه
            </h1>
            <p className="home-hero-sub">
              انبار پلیمر شبکه‌ای‌ست که خریدارها و فروشنده‌های صنعتی رو مستقیم به‌هم وصل می‌کنه — با دیتاشیت فنی کامل، قیمت شفاف و احراز هویت تولیدکننده.
            </p>
            <div className="home-hero-stat-chip">
              <b>{gradeCount.toLocaleString('fa-IR')}</b>
              <span>گرید فنی</span>
              <div className="home-hero-divider" />
              <b>{baseCount.toLocaleString('fa-IR')}</b>
              <span>پایه پلیمری</span>
            </div>
            <div className="home-hero-actions">
              <a href="/market" className="home-btn-primary">
                ورود به بازار صنعتی
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.2}><path d="M19 12H5M12 19l-7-7 7-7" /></svg>
              </a>
              <a href="/grades" className="home-btn-secondary">کاتالوگ گریدها</a>
            </div>
            <div className="home-hero-trustbar">
              <div className="home-trust-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><path d="M9 12l2 2 4-4" /><circle cx="12" cy="12" r="9" /></svg>
                <span>احراز هویت تولیدکننده</span>
              </div>
              <div className="home-trust-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><path d="M14 2v6h6" /></svg>
                <span>دیتاشیت فنی کامل</span>
              </div>
              <div className="home-trust-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z" /></svg>
                <span>تسویه‌ی امن</span>
              </div>
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="home-features">
          <div className="home-features-head">
            <div>
              <div className="home-eyebrow">چرا انبار پلیمر</div>
              <div className="home-section-title">همه‌چیز برای یه معامله‌ی صنعتی مطمئن</div>
            </div>
            <div className="home-features-note">از پیدا‌کردن گرید درست تا اطمینان از صحت مدارک فروشنده — همه‌جا.</div>
          </div>
          <div className="home-features-grid">
            <a href="/market" className="home-feat home-feat-lead">
              <div>
                <div className="home-feat-icon">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><rect x="3" y="7" width="18" height="13" rx="2" /><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /><path d="M3 13h18" /></svg>
                </div>
                <div className="home-feat-title">بازار دوطرفه</div>
                <div className="home-feat-desc">فروشنده آگهی می‌ذاره، خریدار درخواست خرید ثبت می‌کنه — سیستم خودش دو طرف رو به‌هم می‌رسونه، بدون واسطه‌ی تلفنی.</div>
              </div>
              <span className="home-feat-tag">مشاهده‌ی بازار ←</span>
            </a>
            <div className="home-feat">
              <div className="home-feat-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" /></svg></div>
              <div className="home-feat-title">جستجو و فیلتر پیشرفته</div>
              <div className="home-feat-desc">بر اساس گرید، تولیدکننده، خانواده‌ی پلیمری، استان و کاربرد فیلتر کنید.</div>
            </div>
            <div className="home-feat">
              <div className="home-feat-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><path d="M14 2v6h6" /><path d="M9 15h6M9 11h3" /></svg></div>
              <div className="home-feat-title">دیتاشیت فنی کامل</div>
              <div className="home-feat-desc">مشخصات هر گرید با MFI، چگالی، استاندارد و اسناد قابل‌دانلود.</div>
            </div>
            <div className="home-feat">
              <div className="home-feat-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><path d="M12 2 4 5v6c0 5 3.4 8.4 8 11 4.6-2.6 8-6 8-11V5z" /></svg></div>
              <div className="home-feat-title">احراز هویت تولیدکننده</div>
              <div className="home-feat-desc">فروشنده‌ها پروانه‌ی بهره‌برداری بارگذاری می‌کنن — معامله با اطمینان بیشتر.</div>
            </div>
          </div>
        </section>

        {/* Gallery */}
        <section className="home-gallery">
          <div className="home-gallery-grid">
            <div className="home-img-ph">
              <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.6}><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="8.5" cy="8.5" r="1.5" /><path d="m21 15-5-5L5 21" /></svg>
              <span className="home-ph-label">عکس واقعی انبار</span>
              <span className="home-ph-sub">بعداً جایگزین می‌شود</span>
            </div>
            <div className="home-img-ph">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.6}><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="8.5" cy="8.5" r="1.5" /><path d="m21 15-5-5L5 21" /></svg>
              <span className="home-ph-label">عکس مواد اولیه</span>
              <span className="home-ph-sub">بعداً جایگزین می‌شود</span>
            </div>
            <div className="home-img-ph">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.6}><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="8.5" cy="8.5" r="1.5" /><path d="m21 15-5-5L5 21" /></svg>
              <span className="home-ph-label">عکس لجستیک/بارگیری</span>
              <span className="home-ph-sub">بعداً جایگزین می‌شود</span>
            </div>
          </div>
        </section>

        {/* How */}
        <section className="home-how">
          <div className="home-how-inner">
            <div className="home-eyebrow">فلوی معامله</div>
            <div className="home-section-title">از پیداکردن گرید تا تحویل بار — همه در یک مسیر شفاف</div>
            <div className="home-steps">
              <div className="home-step"><div className="home-step-num">۱</div><div className="home-step-title">ثبت آگهی / درخواست</div><div className="home-step-desc">فروشنده گرید رو عرضه می‌کنه، خریدار درخواست خرید ثبت می‌کنه.</div></div>
              <div className="home-step"><div className="home-step-num">۲</div><div className="home-step-title">تطبیق و توافق</div><div className="home-step-desc">طرف مقابل پیشنهاد رو می‌بینه و قبول می‌کنه.</div></div>
              <div className="home-step"><div className="home-step-num">۳</div><div className="home-step-title">تسویه‌ی امن</div><div className="home-step-desc">وجه کالا و کارمزد جدا پیگیری و تایید می‌شه.</div></div>
              <div className="home-step"><div className="home-step-num">۴</div><div className="home-step-title">بارگیری و حمل</div><div className="home-step-desc">راننده تخصیص می‌خوره، مسیر بارگیری تا تخلیه ثبت می‌شه.</div></div>
              <div className="home-step"><div className="home-step-num">۵</div><div className="home-step-title">تحویل و تسویه‌ی نهایی</div><div className="home-step-desc">تایید نهایی دو طرف، پرونده‌ی معامله بسته می‌شه.</div></div>
            </div>
          </div>
        </section>

        {/* Logistics */}
        <section className="home-logi">
          <div className="home-logi-inner">
            <div className="home-eyebrow">لجستیک یکپارچه</div>
            <div className="home-section-title">از بارگیری تا تخلیه — همه‌چیز ثبت می‌شه</div>
            <div className="home-logi-grid">
              <div className="home-logi-card">
                <div className="home-feat-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><path d="M14 18V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2" /><path d="M15 18H9" /><path d="M19 18h2a1 1 0 0 0 1-1v-5h-4l-2-3h-3.5" /><circle cx="7" cy="18" r="2" /><circle cx="17" cy="18" r="2" /></svg></div>
                <div className="home-feat-title">تخصیص راننده و ناوگان</div>
                <div className="home-feat-desc">هر محموله راننده و خودروی مشخص داره — اطلاعات تماس و مجوز حمل ثبت می‌شه.</div>
              </div>
              <div className="home-logi-card">
                <div className="home-feat-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><path d="M12 8v4l3 3" /><circle cx="12" cy="12" r="9" /></svg></div>
                <div className="home-feat-title">زمان‌بندی دقیق هر مرحله</div>
                <div className="home-feat-desc">مهلت‌ها بر اساس ساعت کاری واقعی محاسبه می‌شن، نه تقویم خام.</div>
              </div>
              <div className="home-logi-card">
                <div className="home-feat-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z" /></svg></div>
                <div className="home-feat-title">رهگیری محموله</div>
                <div className="home-feat-desc">از بارگیری تا تخلیه، هر تغییر وضعیت با زمان دقیق ثبت و به دو طرف اطلاع داده می‌شه.</div>
              </div>
            </div>
          </div>
        </section>

        {/* Trust */}
        <section className="home-trust">
          <div className="home-trust-inner">
            <div className="home-eyebrow">امنیت معامله</div>
            <div className="home-section-title">هر قدم، قابل‌پیگیری و قابل‌اثبات</div>
            <div className="home-trust-grid">
              <div className="home-trust-card">
                <div className="home-feat-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><path d="M12 2 4 5v6c0 5 3.4 8.4 8 11 4.6-2.6 8-6 8-11V5z" /><path d="m9 12 2 2 4-4" /></svg></div>
                <div className="home-feat-title">احراز هویت چندسطحی</div>
                <div className="home-feat-desc">تولیدکننده‌ها پروانه‌ی بهره‌برداری و مدارک شرکتی بارگذاری می‌کنن تا سطح اعتماد بالاتر بگیرن.</div>
              </div>
              <div className="home-trust-card">
                <div className="home-feat-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><rect x="3" y="11" width="18" height="10" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /></svg></div>
                <div className="home-feat-title">تسویه‌ی وجه جداگانه</div>
                <div className="home-feat-desc">وجه کالا و کارمزد فروشنده جدا پیگیری می‌شن؛ مرحله‌ی حمل فقط بعد از تایید هردو باز می‌شه.</div>
              </div>
              <div className="home-trust-card">
                <div className="home-feat-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z" /></svg></div>
                <div className="home-feat-title">رسیدگی به اختلاف</div>
                <div className="home-feat-desc">اگه مغایرتی توی بار یا پرداخت پیش بیاد، یه مسیر رسمی رسیدگی و داوری وجود داره.</div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="home-cta-wrap">
          <div className="home-cta">
            <div className="home-cta-title">آماده‌اید شروع کنید؟</div>
            <div className="home-cta-sub">همین الان ثبت‌نام کنید و قیمت به‌روز مواد اولیه پلیمری رو ببینید.</div>
            <a href={user ? '/dashboard' : '/signup'} className="home-btn-primary">
              {user ? 'رفتن به داشبورد' : 'ثبت‌نام رایگان'}
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.2}><path d="M19 12H5M12 19l-7-7 7-7" /></svg>
            </a>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
