import prisma from '@/lib/prisma'
import { getSurfaceHome } from '@/lib/surfaceHome'
import { getCurrentUser } from '@/lib/currentUser'
import UserNav from '@/components/UserNav'
import PanelHeader from '@/components/PanelHeader'
import Footer from '@/components/Footer'
import { createPriceAlertAction, cancelPriceAlertAction } from './actions'
import { colors, radius, fontSize, shadow } from '@/lib/styles/tokens'

export const dynamic = 'force-dynamic'

export default async function PriceAlertsPage() {
  const user = await getCurrentUser()

  const [alerts, grades] = await Promise.all([
    prisma.priceAlert.findMany({
      where: { userId: user.id },
      include: { grade: { select: { code: true, category: true, producer: true } } },
      orderBy: { createdAt: 'desc' },
    }),
    prisma.grade.findMany({
      where: { isActive: true },
      select: { id: true, code: true, category: true, producer: true },
      orderBy: { code: 'asc' },
    }),
  ])

  const activeAlerts = alerts.filter((a) => a.status === 'active')
  const triggeredAlerts = alerts.filter((a) => a.status === 'triggered')

  return (
    <>
    <PanelHeader homeHref={getSurfaceHome()} currentUserName={user.companyName} />
    <div
      style={{
        minHeight: '100vh',
        background: colors.bgCard,
        display: 'flex',
        gap: 24,
        padding: '32px 24px',
        fontFamily: "'Vazirmatn', Tahoma, sans-serif",
        direction: 'rtl',
        width: '100%',
      }}
    >
      <UserNav currentUserName={user.companyName} activeSection="price-alerts" />
      <div style={{ flex: 1, minWidth: 0 }}>
        <h1 style={{ fontSize: fontSize.xxl, fontWeight: 800, color: colors.textPrimary, marginBottom: 4 }}>هشدار قیمت</h1>
        <p style={{ fontSize: fontSize.base, color: colors.textMuted, marginBottom: 24 }}>
          وقتی قیمت گریدی که می‌خوای به سقف مدنظرت رسید، بهت خبر می‌دیم
        </p>

        {/* ── فرم ساخت هشدار جدید ── */}
        <div style={cardStyle}>
          <h3 style={{ fontSize: 15, fontWeight: 800, marginBottom: 14 }}>هشدار جدید</h3>
          <form action={createPriceAlertAction} style={formStyle}>
            <div>
              <label style={labelStyle}>گرید</label>
              <select name="gradeId" required style={selectStyle}>
                <option value="">انتخاب کن...</option>
                {grades.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.code} — {g.producer} ({g.category})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label style={labelStyle}>سقف قیمت (تومان/کیلو)</label>
              <input
                name="targetPriceToman"
                type="number"
                step="0.01"
                required
                placeholder="مثلاً 45000"
                style={inputStyle}
              />
              <div style={{ fontSize: 11.5, color: colors.textMuted, marginTop: 4 }}>
                وقتی قیمت این گرید به این مقدار یا کمتر رسید، هشدار فعال می‌شه
              </div>
            </div>
            <button type="submit" style={submitBtnStyle}>
              ساخت هشدار
            </button>
          </form>
        </div>

        {/* ── هشدارهای فعال ── */}
        <div style={{ marginTop: 28 }}>
          <h3 style={sectionHeadStyle}>
            هشدارهای فعال
            {activeAlerts.length > 0 && <span style={countBadge}>{activeAlerts.length}</span>}
          </h3>

          {activeAlerts.length === 0 ? (
            <div style={emptyBoxStyle}>هیچ هشدار فعالی نداری. یکی بساز تا وقتی قیمت رسید بهت بگیم.</div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {activeAlerts.map((alert) => (
                <div key={alert.id} style={alertCardStyle}>
                  <div style={alertHeadStyle}>
                    <div>
                      <span style={{ fontSize: fontSize.md, fontWeight: 800, fontFamily: 'monospace' }}>
                        {alert.grade.code}
                      </span>
                      <span style={{ fontSize: 12, color: '#6b7280', marginRight: 8 }}>
                        {alert.grade.producer} — {alert.grade.category}
                      </span>
                    </div>
                    <span style={activeBadgeStyle}>فعال</span>
                  </div>
                  <div style={{ display: 'flex', gap: 20, alignItems: 'center', marginTop: 8 }}>
                    <div>
                      <div style={{ fontSize: fontSize.xs, color: colors.textMuted }}>سقف قیمت</div>
                      <div style={{ fontSize: fontSize.md, fontWeight: 700, fontFamily: 'monospace', direction: 'ltr' }}>
                        {alert.targetPriceToman.toLocaleString('fa-IR')} تومان/کیلو
                      </div>
                    </div>
                    <div>
                      <div style={{ fontSize: fontSize.xs, color: colors.textMuted }}>تاریخ ساخت</div>
                      <div style={{ fontSize: fontSize.sm }}>{new Date(alert.createdAt).toLocaleDateString('fa-IR')}</div>
                    </div>
                    <div style={{ marginRight: 'auto' }}>
                      <form action={cancelPriceAlertAction.bind(null, alert.id)}>
                        <button type="submit" style={cancelBtnStyle}>
                          لغو هشدار
                        </button>
                      </form>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ── هشدارهای فعال‌شده ── */}
        {triggeredAlerts.length > 0 && (
          <div style={{ marginTop: 28 }}>
            <h3 style={sectionHeadStyle}>
              هشدارهای فعال‌شده
              <span style={countBadge}>{triggeredAlerts.length}</span>
            </h3>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {triggeredAlerts.map((alert) => (
                <div key={alert.id} style={{ ...alertCardStyle, background: '#fef3c7' }}>
                  <div style={alertHeadStyle}>
                    <div>
                      <span style={{ fontSize: fontSize.md, fontWeight: 800, fontFamily: 'monospace' }}>
                        {alert.grade.code}
                      </span>
                      <span style={{ fontSize: 12, color: '#6f7680', marginRight: 8 }}>
                        {alert.grade.producer} — {alert.grade.category}
                      </span>
                    </div>
                    <span style={triggeredBadgeStyle}>رسید!</span>
                  </div>
                  <div style={{ display: 'flex', gap: 20, alignItems: 'center', marginTop: 8, flexWrap: 'wrap' }}>
                    <div>
                      <div style={{ fontSize: fontSize.xs, color: colors.warningText }}>سقف قیمتت</div>
                      <div style={{ fontSize: fontSize.md, fontWeight: 700, fontFamily: 'monospace', direction: 'ltr' }}>
                        {alert.targetPriceToman.toLocaleString('fa-IR')} تومان
                      </div>
                    </div>
                    <div>
                      <div style={{ fontSize: fontSize.xs, color: colors.warningText }}>قیمت فعلی</div>
                      <div
                        style={{
                          fontSize: fontSize.md,
                          fontWeight: 800,
                          fontFamily: 'monospace',
                          direction: 'ltr',
                          color: colors.orange,
                        }}
                      >
                        {alert.triggeredPrice
                          ? `${(alert.triggeredPrice / 10).toLocaleString('fa-IR')} تومان`
                          : '—'}
                      </div>
                    </div>
                    <div>
                      <div style={{ fontSize: fontSize.xs, color: colors.warningText }}>زمان فعال‌شدن</div>
                      <div style={{ fontSize: fontSize.sm }}>
                        {alert.triggeredAt ? new Date(alert.triggeredAt).toLocaleString('fa-IR') : '—'}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
    <Footer />
  </>
)
}

const cardStyle: React.CSSProperties = {
  border: `1px solid ${colors.borderStrong}`,
  borderRadius: radius.lg,
  padding: 18,
  background: colors.bgCard,
  boxShadow: shadow.card,
  marginBottom: 8,
}
const formStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 16,
}
const labelStyle: React.CSSProperties = {
  display: 'block',
  fontSize: fontSize.sm,
  fontWeight: 700,
  marginBottom: 6,
  color: colors.textPrimary,
}
const selectStyle: React.CSSProperties = {
  width: '100%',
  padding: '9px 12px',
  border: `1px solid ${colors.borderStrong}`,
  borderRadius: radius.md,
  fontSize: fontSize.base,
  fontFamily: 'inherit',
}
const inputStyle: React.CSSProperties = {
  width: '100%',
  padding: '9px 12px',
  border: `1px solid ${colors.borderStrong}`,
  borderRadius: radius.md,
  fontSize: fontSize.base,
  fontFamily: 'inherit',
}
const submitBtnStyle: React.CSSProperties = {
  background: colors.navy,
  color: '#fff',
  border: 'none',
  borderRadius: radius.md,
  padding: '11px 20px',
  fontSize: fontSize.base,
  fontWeight: 700,
  fontFamily: 'inherit',
  cursor: 'pointer',
  alignSelf: 'flex-start',
}
const sectionHeadStyle: React.CSSProperties = {
  fontSize: 15,
  fontWeight: 800,
  display: 'flex',
  alignItems: 'center',
  gap: 8,
  marginBottom: 14,
}
const countBadge: React.CSSProperties = {
  background: colors.infoBg,
  color: colors.infoText,
  fontSize: fontSize.xs,
  fontWeight: 800,
  borderRadius: 20,
  padding: '2px 10px',
}
const emptyBoxStyle: React.CSSProperties = {
  padding: 24,
  textAlign: 'center',
  color: colors.textMuted,
  border: `1px dashed ${colors.borderStrong}`,
  borderRadius: radius.lg,
  fontSize: fontSize.sm,
}
const alertCardStyle: React.CSSProperties = {
  border: `1px solid ${colors.borderStrong}`,
  borderRadius: 10,
  padding: 14,
  background: colors.bgCard,
}
const alertHeadStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  flexWrap: 'wrap',
  gap: 10,
}
const activeBadgeStyle: React.CSSProperties = {
  fontSize: 10.5,
  fontWeight: 700,
  background: colors.darkGreenBg,
  color: colors.darkGreenText,
  borderRadius: radius.sm,
  padding: '3px 10px',
}
const triggeredBadgeStyle: React.CSSProperties = {
  fontSize: 10.5,
  fontWeight: 700,
  background: '#fee2e2',
  color: colors.dangerText,
  borderRadius: radius.sm,
  padding: '3px 10px',
}
const cancelBtnStyle: React.CSSProperties = {
  background: colors.bgCard,
  color: colors.dangerText,
  border: `1px solid ${colors.borderStrong}`,
  borderRadius: radius.sm,
  padding: '7px 14px',
  fontSize: 12,
  fontWeight: 700,
  fontFamily: 'inherit',
  cursor: 'pointer',
}
