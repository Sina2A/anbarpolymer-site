import { getCurrentUser } from '@/lib/currentUser'
import { getSurfaceHome } from '@/lib/surfaceHome'
import { getKycForUser } from '@/lib/kyc'
import { submitCompanyStepAction, submitProducerStepAction, submitBusinessProfileAction } from './actions'
import prisma from '@/lib/prisma'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { cardStyle as sharedCardStyle, inputStyle as sharedInputStyle, pageWrapStyle } from '@/lib/styles/shared'
import UserNav from '@/components/UserNav'
import PanelHeader from '@/components/PanelHeader'
import Footer from '@/components/Footer'
import VerificationStepper, { type StepState } from '@/components/VerificationStepper'

export const dynamic = 'force-dynamic'

// ── مقادیر ثابت ──
const LEGAL_TYPES = [
  { value: 'factory', label: 'کارخانه / واحد تولیدی' },
  { value: 'production_unit', label: 'واحد تولیدی کوچک' },
  { value: 'trading_company', label: 'شرکت بازرگانی' },
  { value: 'cooperative', label: 'تعاونی' },
  { value: 'official_agent', label: 'نماینده‌ی رسمی' },
  { value: 'importer', label: 'واردکننده' },
  { value: 'exporter', label: 'صادرکننده' },
]

const ACTIVITY_DOMAINS = [
  'Pipe', 'Film', 'Injection', 'Raffia', 'Sheet',
  'Blow Molding', 'Masterbatch', 'Compound', 'Recycling',
]

const PRODUCTS_USED = [
  'پلی‌پروپیلن (PP)', 'پلی‌اتیلن (PE)', 'پی‌وی‌سی (PVC)',
  'پلی‌اتیلن ترفتالات (PET)', 'پلی‌استایرن (PS)', 'ABS',
  'مستربچ', 'افزودنی‌ها', 'سایر',
]

const TARGET_MARKETS = [
  'ایران', 'عراق', 'افغانستان', 'ترکیه', 'پاکستان',
  'آسیای میانه', 'آفریقا', 'اروپا', 'سایر',
]

export default async function VerificationPage() {
  const user = await getCurrentUser()
  const company = await getKycForUser(user.id)
  const kyc = company?.kyc

  const level = kyc?.level ?? 0
  const step1Pending = kyc?.documentsSubmittedAt && level < 1
  const step2Pending = kyc?.producerDocumentsSubmittedAt && level < 2 && level >= 1

  const bizProfile = company
    ? await prisma.businessProfile.findUnique({ where: { companyId: company.id } })
    : null

  // ── وضعیت گام‌ها برای استپر ──
  const step1Done = level >= 1
  const step2Done = level >= 2
  const step3Done = !!bizProfile

  // گام فعلی = اولین گامی که هنوز کامل نشده
  const currentStep = !step1Done ? 1 : !step2Done ? 2 : 3

  const step1State: StepState = step1Done ? 'completed' : step1Pending ? 'pending' : 'active'
  const step2State: StepState = step2Done ? 'completed' : step2Pending ? 'pending' : currentStep === 2 ? 'active' : 'locked'
  const step3State: StepState = step3Done ? 'completed' : currentStep === 3 ? 'active' : 'locked'

  return (
    <>
      <PanelHeader homeHref={getSurfaceHome()} currentUserName={user.companyName} />
      <div style={pageStyle}>
      <div style={pageWrapStyle}>
        <UserNav currentUserName={user.companyName} activeSection="verification" />

        <div style={containerStyle}>
          <h1 style={h1Style}>احراز هویت</h1>
          <p style={subtitleStyle}>
            برای استفاده از همه‌ی امکانات سایت (دیدن قیمت دقیق، ارسال استعلام، خرید/فروش) باید مدارک هویتی رو تکمیل کنی.
            تا وقتی احراز نشده، فقط بخش عمومی (لیست گریدها، مقالات) رو می‌بینی.
          </p>

          {/* ── نشانگر افقی مراحل ── */}
          <div style={stepperCardStyle}>
            <VerificationStepper
              steps={[
                { label: 'هویت شرکت', state: step1State },
                { label: 'احراز تولیدکننده', state: step2State },
                { label: 'پروفایل تجاری', state: step3State },
              ]}
            />
          </div>

          <StatusBadge level={level} />

          {/* ─────── گام ۱: هویت شرکت ─────── */}
          {(
            <div style={cardStyle}>
              {step1Done ? (
                <StatusLine tone="success">
                  ✓ هویت شرکت تایید شده — دسترسی به قیمت‌های دقیق و ارسال استعلام فعاله
                </StatusLine>
              ) : step1Pending ? (
                <StatusLine tone="warning">
                  ⏳ اطلاعات ارسال شد، منتظر بررسی کارشناسه
                </StatusLine>
              ) : (
                <>
                  <h3 style={stepTitleStyle}>هویت شرکت</h3>
                  <p style={stepDescStyle}>
                    برای دیدن قیمت‌های دقیق و ارسال استعلام لازمه. نیازی به آپلود مدرک نیست — فقط اطلاعات زیر رو دقیق وارد کن،
                    کارشناس از طریق سامانه‌ی رسمی «روزنامه‌ی رسمی کشور» تطبیقش می‌ده.
                  </p>

                  <form action={submitCompanyStepAction} style={formStyle}>
                    <div style={rowStyle}>
                      <input name="companyName" placeholder="نام کامل شرکت" defaultValue={company?.companyName} required style={rowInputStyle} />
                      <select name="legalType" defaultValue={company?.legalType || 'factory'} style={rowInputStyle}>
                        {LEGAL_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
                      </select>
                    </div>
                    <div style={rowStyle}>
                      <input name="nationalId" placeholder="شناسه‌ی ملی شرکت" defaultValue={company?.nationalId || ''} required style={rowInputStyle} />
                      <input name="registrationNumber" placeholder="شماره‌ی ثبت" defaultValue={company?.registrationNumber || ''} required style={rowInputStyle} />
                    </div>
                    <div style={rowStyle}>
                      <input name="province" placeholder="استان" defaultValue={company?.province || ''} required style={rowInputStyle} />
                      <input name="city" placeholder="شهر" defaultValue={company?.city || ''} required style={rowInputStyle} />
                    </div>
                    <input name="address" placeholder="آدرس دقیق" defaultValue={company?.address || ''} required style={inputStyle} />
                    <button type="submit" style={submitBtnStyle}>تایید و ادامه</button>
                  </form>
                </>
              )}
            </div>
          )}

          {/* ─────── گام ۲: احراز تولیدکننده ─────── */}
          {step2State !== 'locked' && (
            <div style={cardStyle}>
              {step2Done ? (
                <StatusLine tone="success">
                  ✓ تولیدکننده‌ی تایید‌شده — می‌تونی توی شبکه عرضه بار ثبت کنی
                </StatusLine>
              ) : step2Pending ? (
                <StatusLine tone="warning">
                  ⏳ مدارک ارسال شد، منتظر بررسی کارشناسه (تطبیق با سامانه‌ی بهین‌یاب)
                </StatusLine>
              ) : (
                <>
                  <h3 style={stepTitleStyle}>احراز تولیدکننده</h3>
                  <p style={stepDescStyle}>فقط لازمه اگه می‌خوای توی سایت بار بفروشی (شبکه عرضه).</p>

                  <form action={submitProducerStepAction} style={formStyle}>
                    <div style={rowStyle}>
                      <input name="productionLicenseNumber" placeholder="شماره‌ی پروانه‌ی بهره‌برداری" required style={rowInputStyle} />
                      <input name="factoryActivityType" placeholder="نوع فعالیت تولیدی" required style={rowInputStyle} />
                    </div>
                    <label style={checkboxLineStyle}>
                      <input type="checkbox" name="productionLicenseIsSetup" />
                      واحد هنوز در حال احداثه (به‌جاش جواز تاسیس دارم، نه پروانه‌ی نهایی)
                    </label>
                    <input name="factoryAddress" placeholder="آدرس دقیق کارخانه" required style={inputStyle} />
                    <textarea
                      name="factoryProducts"
                      placeholder="محصولات تولیدی"
                      rows={3}
                      style={{ ...inputStyle, fontFamily: 'inherit', resize: 'vertical' }}
                    />
                    <label style={fileLabelStyle}>
                      تصویر پروانه‌ی بهره‌برداری (یا جواز تاسیس)
                      <input type="file" name="licenseFile" accept=".pdf,image/*" required style={{ marginTop: 6 }} />
                    </label>
                    <button type="submit" style={submitBtnStyle}>ارسال برای بررسی</button>
                  </form>
                </>
              )}
            </div>
          )}

          {/* ─────── گام ۳: پروفایل تجاری ─────── */}
          {step3State !== 'locked' && (
            <div style={cardStyle}>
              {step3Done && (
                <StatusLine tone="success">
                  ✓ پروفایل تجاری ذخیره شده — می‌تونی هر وقت خواستی ویرایش کنی
                </StatusLine>
              )}

              <h3 style={stepTitleStyle}>پروفایل تجاری</h3>
              <p style={stepDescStyle}>
                اطلاعات تجاری شرکت (حوزه فعالیت، ظرفیت، بازار هدف). اختیاریه ولی برای ویترین بهتر و اولویت در معامله‌ها پیشنهاد می‌شه.
              </p>

              <form action={submitBusinessProfileAction} style={formStyle}>
                {/* نقش */}
                <label style={fieldLabelStyle}>نقش شرکت در بازار</label>
                <select name="role" defaultValue={bizProfile?.role || 'seller'} style={inputStyle}>
                  <option value="seller">فروشنده / تولیدکننده</option>
                  <option value="buyer">خریدار</option>
                  <option value="both">هر دو</option>
                </select>

                {/* حوزه‌ی فعالیت */}
                <fieldset style={fieldsetStyle}>
                  <legend style={fieldLabelStyle}>حوزه‌ی فعالیت (چند مورد انتخاب کن)</legend>
                  <div style={checkboxGridStyle}>
                    {ACTIVITY_DOMAINS.map((d) => (
                      <label key={d} style={checkboxLabelStyle}>
                        <input type="checkbox" name="activityDomain" value={d} defaultChecked={bizProfile?.activityDomain?.includes(d)} />
                        {d}
                      </label>
                    ))}
                  </div>
                </fieldset>

                {/* محصولات مصرفی */}
                <fieldset style={fieldsetStyle}>
                  <legend style={fieldLabelStyle}>محصولات مصرفی (چند مورد انتخاب کن)</legend>
                  <div style={checkboxGridStyle}>
                    {PRODUCTS_USED.map((p) => (
                      <label key={p} style={checkboxLabelStyle}>
                        <input type="checkbox" name="productsUsed" value={p} defaultChecked={bizProfile?.productsUsed?.includes(p)} />
                        {p}
                      </label>
                    ))}
                  </div>
                </fieldset>

                {/* ظرفیت خرید + مصرف ماهانه */}
                <div style={rowStyle}>
                  <div style={rowColStyle}>
                    <label style={fieldLabelStyle}>ظرفیت خرید ماهانه</label>
                    <select name="purchaseCapacityTier" defaultValue={bizProfile?.purchaseCapacityTier || ''} style={inputStyle}>
                      <option value="">انتخاب نشده</option>
                      <option value="under_20t">زیر ۲۰ تن</option>
                      <option value="20_100t">۲۰ تا ۱۰۰ تن</option>
                      <option value="100_500t">۱۰۰ تا ۵۰۰ تن</option>
                      <option value="over_500t">بالای ۵۰۰ تن</option>
                    </select>
                  </div>
                  <div style={rowColStyle}>
                    <label style={fieldLabelStyle}>مصرف ماهانه (تن)</label>
                    <input
                      type="number"
                      name="monthlyConsumptionTon"
                      placeholder="مثلاً ۵۰"
                      defaultValue={bizProfile?.monthlyConsumptionTon ?? ''}
                      min={0}
                      step="0.1"
                      style={inputStyle}
                    />
                  </div>
                </div>

                {/* ظرفیت تولید سالانه */}
                <label style={fieldLabelStyle}>ظرفیت تولید سالانه (تن در سال)</label>
                <input
                  type="number"
                  name="productionCapacityTonPerYear"
                  placeholder="مثلاً ۱۲۰۰"
                  defaultValue={bizProfile?.productionCapacityTonPerYear ?? ''}
                  min={0}
                  step="1"
                  style={inputStyle}
                />

                {/* بازار هدف */}
                <fieldset style={fieldsetStyle}>
                  <legend style={fieldLabelStyle}>بازارهای هدف (چند مورد انتخاب کن)</legend>
                  <div style={checkboxGridStyle}>
                    {TARGET_MARKETS.map((m) => (
                      <label key={m} style={checkboxLabelStyle}>
                        <input type="checkbox" name="targetMarkets" value={m} defaultChecked={bizProfile?.targetMarkets?.includes(m)} />
                        {m}
                      </label>
                    ))}
                  </div>
                </fieldset>

                <button type="submit" style={submitBtnStyle}>ذخیره‌ی پروفایل تجاری</button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
      <Footer />
    </>
  )
}

// ── کامپوننت‌های محلی ──

function StatusBadge({ level }: { level: number }) {
  const labels = ['کاربر ساده', 'شرکت تایید‌شده', 'تولیدکننده‌ی تایید‌شده']
  const levelColors = [colors.textSecondary, colors.successText, colors.successText]
  return (
    <div style={{ marginBottom: spacing.xl, fontSize: fontSize.base, fontWeight: 700, color: levelColors[level] }}>
      وضعیت فعلی: {labels[level]}
    </div>
  )
}

function StatusLine({ tone, children }: { tone: 'success' | 'warning'; children: React.ReactNode }) {
  const bg = tone === 'success' ? colors.successBg : colors.warningBg
  const fg = tone === 'success' ? colors.successText : colors.warningText
  return (
    <div style={{ background: bg, color: fg, borderRadius: radius.md, padding: '10px 14px', fontSize: fontSize.base, fontWeight: 600 }}>
      {children}
    </div>
  )
}

// ── استایل‌ها ──

const pageStyle: React.CSSProperties = { minHeight: '100vh', background: colors.bgCard, padding: `${spacing.xxl}px ${spacing.xl}px`, fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl' }
const containerStyle: React.CSSProperties = { flex: 1, minWidth: 0 }
const cardStyle: React.CSSProperties = { ...sharedCardStyle, borderRadius: radius.lg, padding: '22px 20px', marginBottom: 20 }
const stepperCardStyle: React.CSSProperties = { ...sharedCardStyle, borderRadius: radius.lg, padding: '26px 20px 10px', marginBottom: 20 }
const h1Style: React.CSSProperties = { fontSize: fontSize.xxl, fontWeight: 800, marginBottom: 6, color: colors.textPrimary }
const subtitleStyle: React.CSSProperties = { color: colors.textSecondary, fontSize: fontSize.md, marginBottom: 24, lineHeight: 1.9 }
const inputStyle: React.CSSProperties = { ...sharedInputStyle, padding: '10px 14px', fontSize: fontSize.md }
const rowInputStyle: React.CSSProperties = { ...inputStyle, flex: 1 }
const formStyle: React.CSSProperties = { display: 'flex', flexDirection: 'column', gap: 12, marginTop: 10 }
const rowStyle: React.CSSProperties = { display: 'flex', gap: 10 }
const rowColStyle: React.CSSProperties = { flex: 1, display: 'flex', flexDirection: 'column' }
const stepTitleStyle: React.CSSProperties = { fontSize: fontSize.lg, marginBottom: 4, color: colors.textPrimary }
const stepDescStyle: React.CSSProperties = { fontSize: fontSize.sm, color: colors.textMuted, marginBottom: spacing.lg, lineHeight: 1.9 }
const fileLabelStyle: React.CSSProperties = { fontSize: fontSize.sm, color: colors.neutralText, display: 'flex', flexDirection: 'column' }
const checkboxLineStyle: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: colors.textSecondary }
const submitBtnStyle: React.CSSProperties = {
  background: colors.orange,
  color: '#fff',
  border: 'none',
  borderRadius: radius.md,
  padding: '13px 0',
  fontSize: fontSize.md,
  fontWeight: 800,
  cursor: 'pointer',
  marginTop: 6,
}
const fieldLabelStyle: React.CSSProperties = { fontSize: fontSize.sm, fontWeight: 700, color: colors.neutralText, marginBottom: -6 }
const fieldsetStyle: React.CSSProperties = { border: 'none', padding: 0, margin: 0 }
const checkboxGridStyle: React.CSSProperties = { display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '8px 14px', marginTop: 6 }
const checkboxLabelStyle: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 6, fontSize: fontSize.sm, cursor: 'pointer' }
