import prisma from '@/lib/prisma'
import { getSurfaceHome } from '@/lib/surfaceHome'
import { getCurrentUser } from '@/lib/currentUser'
import UserNav from '@/components/UserNav'
import PanelHeader from '@/components/PanelHeader'
import Footer from '@/components/Footer'
import { enforceDealDeadlines } from '@/lib/dealDeadlines'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { cardStyle as sharedCardStyle, badgeStyle, emptyStateStyle } from '@/lib/styles/shared'
import { acceptDealOfferAction, rejectDealOfferAction } from './actions'

export const dynamic = 'force-dynamic'

/**
 * صفحه‌ی لیست «معاملات من» — فقط Dealهایی که همین خریدار (buyerId) طرف‌شونه.
 * هم‌الگوی proformas/page.tsx — کارت لینک‌دار به جزئیات هر معامله.
 */

const STATUS_LABELS: Record<string, string> = {
  draft: 'پیش‌نویس',
  confirmed: 'تایید شد',
  seller_fee_paid: 'کارمزد فروشنده پرداخت شد',
  payment_secured: 'وجه تضمین شد',
  transport_pending: 'در انتظار حمل',
  loading: 'در حال بارگیری',
  in_transit: 'در مسیر ارسال',
  delivered: 'تحویل شد',
  settled: 'تسویه شد',
  void: 'باطل شد',
}

export default async function MyDealsPage() {
  const user = await getCurrentUser()

  await enforceDealDeadlines()

  const deals = await prisma.deal.findMany({
    where: { buyerId: user.id },
    include: { materialListing: { include: { grade: true } } },
    orderBy: { createdAt: 'desc' },
  })

  // پیشنهادهای دریافتی — Dealهای پیش‌نویسی که روی آگهیِ همین کاربر (فروشنده) ثبت شده‌اند
  const receivedOffers = await prisma.deal.findMany({
    where: { status: 'draft', OR: [{ sellerId: user.id }, { materialListing: { userId: user.id } }] },
    include: { materialListing: { include: { grade: true } } },
    orderBy: { createdAt: 'desc' },
  })

  return (
    <>
      <PanelHeader homeHref={getSurfaceHome()} currentUserName={user.companyName} />
      <div style={pageStyle}>
      <div style={{ width: '100%', display: 'flex', gap: 24 }} className="admin-page-wrap">
        <UserNav currentUserName={user.companyName} activeSection="deals" />
        <div style={{ flex: 1, minWidth: 0 }}>
          <h1 style={{ fontSize: fontSize.xxl, fontWeight: 800, marginBottom: spacing.xs, color: colors.textPrimary }}>معاملات من</h1>
          <p style={{ fontSize: fontSize.base, color: colors.textMuted, marginBottom: spacing.xl }}>
            معاملاتی که شما به‌عنوان خریدار طرف‌شون هستید — برای پرداخت یا پیگیری حمل، روی هر کارت بزنید
          </p>

          {deals.length === 0 && (
            <div style={emptyBox}>
              هنوز معامله‌ای به نام شما ثبت نشده — وقتی کارشناس معامله‌ای برایتان ایجاد کند، اینجا نمایش داده می‌شود.
            </div>
          )}

          {deals.map((deal) => {
            const gradeCode = (deal.materialListing as unknown as { grade?: { code: string } })?.grade?.code || ''

            return (
              <a key={deal.id} href={`/my-deals/${deal.id}`} style={cardLink}>
                <div style={cardStyle}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.md }}>
                    <b style={{ fontSize: fontSize.md }}>معامله #{deal.id.slice(0, 8)}</b>
                    <span style={statusTag}>{STATUS_LABELS[deal.status] || deal.status}</span>
                  </div>

                  <div style={{ fontSize: fontSize.sm, color: colors.neutralText, marginBottom: 6 }}>
                    {gradeCode && <span style={{ fontFamily: 'monospace' }}>{gradeCode} — </span>}
                    {deal.quantity}
                  </div>

                  {deal.buyerConfirmDeadline && (deal.status === 'confirmed' || deal.status === 'seller_fee_paid') && (
                    <div style={{ fontSize: fontSize.sm, color: colors.warningText, marginBottom: 6 }}>
                      ⏳ مهلت پرداخت: {new Date(deal.buyerConfirmDeadline).toLocaleString('fa-IR', { dateStyle: 'short', timeStyle: 'short' })} — بعد از این زمان معامله خودکار لغو می‌شود
                    </div>
                  )}

                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: fontSize.sm, fontWeight: 700 }}>
                      {deal.agreedPrice !== null && deal.agreedPrice !== undefined ? `${deal.agreedPrice.toLocaleString('fa-IR')} تومان/کیلو` : 'قیمت توافقی ثبت نشده'}
                    </span>
                    <span style={{ fontSize: fontSize.xs, color: colors.textMuted }}>
                      {new Date(deal.createdAt).toLocaleDateString('fa-IR')}
                    </span>
                  </div>
                </div>
              </a>
            )
          })}

          {/* پیشنهادهای دریافتی — بخش فروشنده */}
          {receivedOffers.length > 0 && (
            <div style={{ marginTop: spacing.xxl }}>
              <h2 style={{ fontSize: fontSize.xl, fontWeight: 800, marginBottom: spacing.xs, color: colors.textPrimary }}>پیشنهادهای دریافتی</h2>
              <p style={{ fontSize: fontSize.base, color: colors.textMuted, marginBottom: spacing.xl }}>
                خریدارانی که روی آگهی‌های شما پیشنهاد ثبت کرده‌اند — با قبول، مهلت پرداخت آن‌ها شروع می‌شود
              </p>

              {receivedOffers.map((offer) => {
                const gradeCode = (offer.materialListing as unknown as { grade?: { code: string } })?.grade?.code || ''

                return (
                  <div key={offer.id} style={cardStyle}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.md }}>
                      <b style={{ fontSize: fontSize.md }}>پیشنهاد معامله #{offer.id.slice(0, 8)}</b>
                      <span style={statusTag}>در انتظار پاسخ شما</span>
                    </div>

                    <div style={{ fontSize: fontSize.sm, color: colors.neutralText, marginBottom: 6 }}>
                      {gradeCode && <span style={{ fontFamily: 'monospace' }}>{gradeCode} — </span>}
                      {offer.quantity}
                    </div>

                    <div style={{ fontSize: fontSize.sm, fontWeight: 700, marginBottom: spacing.md }}>
                      {offer.agreedPrice !== null && offer.agreedPrice !== undefined ? `${offer.agreedPrice.toLocaleString('fa-IR')} تومان/کیلو` : 'قیمت توافقی ثبت نشده'}
                      <span style={{ fontSize: fontSize.xs, fontWeight: 400, color: colors.textMuted, marginRight: spacing.md }}>
                        {new Date(offer.createdAt).toLocaleDateString('fa-IR')}
                      </span>
                    </div>

                    <div style={{ display: 'flex', gap: spacing.md }}>
                      <form action={acceptDealOfferAction.bind(null, offer.id)}>
                        <button type="submit" style={acceptBtn}>قبول پیشنهاد</button>
                      </form>
                      <form action={rejectDealOfferAction.bind(null, offer.id)}>
                        <button type="submit" style={rejectBtn}>رد</button>
                      </form>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </div>
    </div>
      <Footer />
    </>
  )
}

const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: colors.bgPage,
  padding: `${spacing.xxl}px ${spacing.xl}px`,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const emptyBox: React.CSSProperties = {
  ...emptyStateStyle,
  padding: 32,
}
const cardLink: React.CSSProperties = {
  display: 'block',
  textDecoration: 'none',
  color: 'inherit',
}
const cardStyle: React.CSSProperties = {
  ...sharedCardStyle,
  padding: 18,
  marginBottom: 14,
  transition: 'border-color .15s',
}
const statusTag: React.CSSProperties = {
  ...badgeStyle('info'),
  fontWeight: 700,
}
const acceptBtn: React.CSSProperties = {
  padding: '9px 22px',
  background: colors.orange,
  color: '#fff',
  border: 'none',
  borderRadius: radius.md,
  fontWeight: 700,
  fontSize: fontSize.base,
  cursor: 'pointer',
  fontFamily: 'inherit',
}
const rejectBtn: React.CSSProperties = {
  padding: '9px 22px',
  background: colors.bgCard,
  color: colors.dangerText,
  border: `1.5px solid ${colors.dangerBg}`,
  borderRadius: radius.md,
  fontWeight: 700,
  fontSize: fontSize.base,
  cursor: 'pointer',
  fontFamily: 'inherit',
}
