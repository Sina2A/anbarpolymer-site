import type { MetadataRoute } from 'next'
import { headers } from 'next/headers'
import { getSurfaceHome, getSurfaceHomeFromHeader } from '@/lib/surfaceHome'

export const dynamic = 'force-dynamic'

/**
 * PWA manifest — نصب‌شدنی روی موبایل و دسکتاپ.
 *
 * start_url باید سطح‌آگاه باشد: سایت روی سه استقرار سرو می‌شود
 * (SURFACE=public:3000 / admin:3001 / transport:4000). روی SURFACE=admin
 * مسیر '/' یک admin path نیست و middleware آن را به /404 rewrite می‌کند،
 * پس start_url ثابت '/' نصب ادمین را روی صفحه‌ی مرده باز می‌کرد.
 *
 * این Route Handler باید force-dynamic باشد چون:
 * - دیپلوی واقعی یک build مشترک + سه pm2 با SURFACE متفاوت است
 * - اگر manifest استاتیک بماند، start_url زمان یه build مشترک (SURFACE خالی)
 *   قفل می‌شود و هر سه سطح '/' می‌بینند — دقیقاً باگ اصلی.
 * - middleware هدر x-app-surface را زمان هر درخواست زنده می‌گذارد؛
 *   manifest آن را با headers() می‌خواند. fallback به process.env برای
 *   حالت مستقیم بدون middleware (مثلاً dev).
 */
export default async function manifest(): Promise<MetadataRoute.Manifest> {
  let surface: string | null = null
  try {
    surface = (await headers()).get('x-app-surface')
  } catch {
    // headers() فقط داخل Route Handler / Server Component در دسترس است؛
    // اگر به هر دلیل در دسترس نبود، fallback به env
  }
  const startUrl = surface ? getSurfaceHomeFromHeader(surface) : getSurfaceHome()
  return {
    name: 'انبار پلیمر',
    short_name: 'انبارپلیمر',
    description: 'بازار و انبار پلیمر — معاملات امن مواد اولیه‌ی پلیمری',
    start_url: startUrl,
    scope: '/',
    display: 'standalone',
    background_color: '#f7f8fa',
    theme_color: '#1e357b',
    lang: 'fa',
    dir: 'rtl',
    icons: [
      { src: '/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
      { src: '/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
      { src: '/icon-maskable-192.png', sizes: '192x192', type: 'image/png', purpose: 'maskable' },
      { src: '/icon-maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
    ],
  }
}
