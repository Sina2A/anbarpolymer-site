import prisma from '@/lib/prisma'
import { getSurfaceHome } from '@/lib/surfaceHome'
import { getCurrentUser } from '@/lib/currentUser'
import UserNav from '@/components/UserNav'
import PanelHeader from '@/components/PanelHeader'
import Footer from '@/components/Footer'
import { notFound } from 'next/navigation'
import { addUserMessageAction } from '../actions'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { cardStyle as sharedCardStyle, badgeStyle, btnPrimaryStyle, inputStyle as sharedInputStyle, labelStyle as sharedLabelStyle } from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

type Props = { params: Promise<{ id: string }> }

export default async function SupportTicketPage({ params }: Props) {
  const { id } = await params
  const user = await getCurrentUser()

  const ticket = await prisma.supportTicket.findUnique({
    where: { id },
    include: { messages: { orderBy: { createdAt: 'asc' } } },
  })

  // فقط صاحب تیکت اجازه‌ی دیدن داره — در غیر این صورت انگار وجود نداره
  if (!ticket || ticket.userId !== user.id) notFound()

  const isClosed = ticket.status === 'closed'

  return (
    <>
      <PanelHeader homeHref={getSurfaceHome()} currentUserName={user.companyName} />
      <div style={{ display: 'flex', gap: spacing.xl, padding: `${spacing.xxl}px ${spacing.xl}px`, fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', width: '100%', background: colors.bgCard, minHeight: '100vh' }}>
        <UserNav currentUserName={user.companyName} activeSection="support" />

        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', gap: spacing.md, marginBottom: 18 }}>
            <div>
              <h1 style={{ fontSize: fontSize.xl, fontWeight: 800, margin: 0, marginBottom: 6, color: colors.textPrimary }}>{ticket.subject}</h1>
              <div style={{ display: 'flex', gap: spacing.md, alignItems: 'center', flexWrap: 'wrap' }}>
                <span style={statusTagStyle(ticket.status)}>{translateStatus(ticket.status)}</span>
                <span style={{ fontSize: fontSize.xs, color: colors.textMuted }}>
                  ثبت: {new Date(ticket.createdAt).toLocaleDateString('fa-IR')}
                </span>
              </div>
            </div>
            <a href="/support" style={backBtnStyle}>→ تیکت‌های من</a>
          </div>

          {/* ── تایم‌لاین گفتگو ── */}
          <div style={cardStyle}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {ticket.messages.map((m) => {
                const isMine = m.senderType === 'user'
                return (
                  <div
                    key={m.id}
                    style={{
                      alignSelf: isMine ? 'flex-start' : 'flex-end',
                      maxWidth: '85%',
                      background: isMine ? colors.warningBg : colors.infoBg,
                      border: '1px solid',
                      borderColor: isMine ? '#fbd9c4' : '#d3e2fb',
                      borderRadius: radius.lg,
                      padding: '11px 14px',
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, marginBottom: 5 }}>
                      <span style={{ fontSize: fontSize.xs, fontWeight: 700, color: isMine ? colors.warningText : colors.navy }}>
                        {isMine ? 'شما' : 'کارشناس پشتیبانی'}
                      </span>
                      <span style={{ fontSize: fontSize.xs, color: colors.textMuted, direction: 'ltr', fontFamily: 'monospace' }}>
                        {new Date(m.createdAt).toLocaleDateString('fa-IR')} {new Date(m.createdAt).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <div style={{ fontSize: fontSize.base, lineHeight: 1.8, whiteSpace: 'pre-wrap', color: colors.textPrimary }}>{m.body}</div>
                  </div>
                )
              })}
            </div>

            {/* ── فرم پاسخ کاربر ── */}
            {isClosed ? (
              <div style={{ marginTop: 18, borderTop: `1px solid ${colors.borderSubtle}`, paddingTop: spacing.lg }}>
                <div style={closedNoticeStyle}>این تیکت بسته شده. برای موضوع جدید، یک تیکت تازه ثبت کن.</div>
              </div>
            ) : (
              <form action={addUserMessageAction} style={{ marginTop: 18, borderTop: `1px solid ${colors.borderSubtle}`, paddingTop: spacing.lg }}>
                <input type="hidden" name="ticketId" value={ticket.id} />
                <div style={labelStyle}>پاسخ شما</div>
                <textarea name="body" rows={4} required placeholder="پیامت رو بنویس…"
                  style={{ ...inputStyle, resize: 'vertical', marginBottom: 10 }} />
                <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                  <button type="submit" style={submitBtnStyle}>ارسال پیام</button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </>
  )
}

// ── ترجمه و رنگ وضعیت ─────────────────────────────────────────────────
function translateStatus(status: string): string {
  const map: Record<string, string> = { open: 'باز', answered: 'پاسخ‌داده‌شده', closed: 'بسته' }
  return map[status] ?? status
}

function statusTagStyle(status: string): React.CSSProperties {
  let kind: 'warning' | 'success' | 'neutral' = 'neutral'
  if (status === 'open') kind = 'warning'
  else if (status === 'answered') kind = 'success'
  else if (status === 'closed') kind = 'neutral'
  return badgeStyle(kind)
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const cardStyle: React.CSSProperties = {
  ...sharedCardStyle, padding: 18, marginBottom: 0,
}
const backBtnStyle: React.CSSProperties = {
  background: 'none', border: `1px solid ${colors.borderStrong}`, borderRadius: radius.md,
  padding: '7px 14px', fontSize: fontSize.sm, fontWeight: 600, color: colors.neutralText,
  textDecoration: 'none', whiteSpace: 'nowrap',
}
const inputStyle: React.CSSProperties = {
  ...sharedInputStyle,
}
const labelStyle: React.CSSProperties = {
  ...sharedLabelStyle,
}
const submitBtnStyle: React.CSSProperties = {
  ...btnPrimaryStyle,
  fontSize: fontSize.sm,
  fontWeight: 700,
}
const closedNoticeStyle: React.CSSProperties = {
  background: colors.neutralBg, color: colors.neutralText, borderRadius: radius.md, padding: '10px 14px',
  fontSize: fontSize.sm, textAlign: 'center',
}
