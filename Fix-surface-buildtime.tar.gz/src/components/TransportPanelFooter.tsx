import { BrandCoin } from '@/components/BrandMark'
import { getSurfaceHome } from '@/lib/surfaceHome'

export default function TransportPanelFooter() {
  return (
    <footer className="transport-panel-footer">
      <a className="transport-panel-footer-brand" href={getSurfaceHome()}>
        <BrandCoin coin={36} mark={30} />
        <span>انبار پلیمر</span>
      </a>
      <p>© تمامی حقوق برای انبار پلیمر محفوظ است.</p>
      <a href="tel:+982191234567">پشتیبانی: ۰۲۱-۹۱۲۳۴۵۶۷</a>
    </footer>
  )
}
