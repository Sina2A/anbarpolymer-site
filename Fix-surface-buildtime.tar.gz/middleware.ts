import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

const ADMIN_PATH_PREFIXES = ['/admin-', '/my-tasks']
// /offline باید روی هر سه سطح (public/admin/transport) دسترس‌پذیر بماند،
// وگرنه وقتی کاربر ادمین آفلاین می‌شود به‌جای پیام صریح، /404 می‌بیند.
const ALWAYS_ALLOWED = ['/login', '/logout', '/offline']

function resolveSurface(raw: string | undefined): 'admin' | 'transport' | 'public' {
  if (raw === 'admin') return 'admin'
  if (raw === 'transport') return 'transport'
  return 'public'
}

export function middleware(request: NextRequest) {
  const surface = resolveSurface(process.env.SURFACE)
  const { pathname } = request.nextUrl

  // رفتار مسدودسازی دقیقاً مثل قبل می‌ماند:
  // - admin: فقط مسیرهای ادمین مجاز (بقیه → /404)
  // - public: مسیرهای ادمین مسدود (→ /404)
  // - transport: مثل public مسیرهای ادمین مسدود (→ /404)
  // سه‌حالته‌شدن فقط هدر را دقیق می‌کند و شاخه‌ی transport را اضافه می‌کند
  // بدون تغییر در منطق دو شاخه‌ی قبلی.

  if (ALWAYS_ALLOWED.some((p) => pathname === p || pathname.startsWith(p + '/'))) {
    const res = NextResponse.next()
    res.headers.set('x-app-surface', surface)
    return res
  }

  const isAdminPath = ADMIN_PATH_PREFIXES.some((p) => pathname.startsWith(p))

  if (surface === 'admin' && !isAdminPath) {
    const res = NextResponse.rewrite(new URL('/404', request.url))
    res.headers.set('x-app-surface', surface)
    return res
  }
  if (surface === 'public' && isAdminPath) {
    const res = NextResponse.rewrite(new URL('/404', request.url))
    res.headers.set('x-app-surface', surface)
    return res
  }
  if (surface === 'transport' && isAdminPath) {
    const res = NextResponse.rewrite(new URL('/404', request.url))
    res.headers.set('x-app-surface', surface)
    return res
  }

  const res = NextResponse.next()
  res.headers.set('x-app-surface', surface)
  return res
}

export const config = {
  // فایل‌های استاتیک و زیرساخت PWA از middleware مستثنا هستند تا روی
  // هر سه سطح (public/admin/transport) سرو شوند. قبلاً sw.js،
  // manifest.webmanifest، آیکون‌ها، لوگوها و /fonts/* مستثنا نبودند؛
  // روی SURFACE=admin همه‌شان به /404 rewrite می‌شدند — یعنی هم لوگو
  // و هم فونت در سطح ادمین می‌شکست و PWA اصلاً نصب نمی‌شد.
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|uploads|fonts/|sw\\.js|manifest\\.webmanifest|[^/]+\\.(?:png|svg|ico|webp|jpg|jpeg|gif|woff2?|ttf)$).*)',
  ],
}
