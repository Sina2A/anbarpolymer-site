# NOTES — رفع خطای Build (TS2322 روی className) + توضیح صادقانه‌ی تناقض

## خلاصه‌ی علت ریشه (چرا tsc محلی EXIT 0 داد ولی build سرور ۹ خطا داد)

خطا **از نوع تایپ در working tree محلی نبود** — از **بسته‌بندی تحویل قبلی** بود:

- در working tree محلی، هر دو کامپوننت از قبل درست بودند: `QuickActionCard.tsx` و `StatCard.tsx` هر دو `className?: string` را در `Props` داشتند و به عنصر ریشه اعمال می‌کردند. برای همین `npx tsc --noEmit` محلی واقعاً EXIT 0 می‌داد — آن ادعا برای درختِ محلی درست بود.
- اما مانیفستِ `tar -T` تحویل قبلی (`mega-nav-header-dashboard-pagination.tar.gz`) این دو فایل را **جا انداخته بود**. محتوای آن آرشیو (تایید‌شده با `tar -tzf`): شامل `dashboard/page.tsx` و `loading.tsx` و `SkeletonCard.tsx` بود ولی **نه** `QuickActionCard.tsx` و **نه** `StatCard.tsx`.
- بخش ۵ این سه‌تا را با هم عوض کرده بود: `dashboard/page.tsx` جدید prop جدید `className="dash-m-action|hero|wide"` را به این دو کارت پاس می‌دهد. روی سرور، `dashboard/page.tsx` **جدید** روی کامپوننت‌های کارتِ **قدیمی** (بدون `className` در `Props`) اعمال شد → ۹ بار `TS2322`.

نتیجه: بند‌های ۱–۳ پرامپت از قبل در کد برقرار بود (تایپ `className?: string` دارد؛ کامپوننت آن را با `className` موجود merge می‌کند — QuickActionCard: `` `quick-action-card${className ? ` ${className}` : ''}` ``؛ StatCard: مستقیم روی ریشه). هیچ تغییری در منطق/چیدمان/CSS لازم و انجام نشد. رفعِ واقعی = فرستادن همان دو فایلِ جاافتاده.

## بررسی فایل‌های دیگرِ همان Session

مانیفست کاملِ تحویل قبلی با `tar -tzf` بازبینی شد. ۱۶ فایل دیگر (mobileNavItems, UserBottomNav, MoreSheet, UserNav, globals.css, PublicHeader, PanelHeader, dashboard/page, dashboard/loading, SkeletonCard, Pagination, proformas, custom-request, my-listings, price-alerts, support) در آرشیو حاضر بودند و با فایل‌های محلیِ typecheck‌شده یکی‌اند. تنها قلمِ مشکوک همین دو کامپوننتِ جاافتاده بود که این تحویل جبرانش می‌کند.

## خروجی واقعی و کامل `npx tsc --noEmit` (نه فقط ادعای EXIT 0)

```
$ npx tsc --noEmit
(بدون هیچ خروجی — هیچ خطایی)
EXIT: 0
```

## فایل‌های این تحویل

| فایل | وضعیت |
|---|---|
| `src/components/QuickActionCard.tsx` | `className?: string` در Props + merge روی `<a>` ریشه |
| `src/components/StatCard.tsx` | `className?: string` در Props + اعمال روی `<div>` ریشه |

این دو فایل باید روی سرور جایگزین شوند تا `dashboard/page.tsx`ِ بخش ۵ کامپایل شود.
