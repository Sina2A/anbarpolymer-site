// src/components/QuickActionCard.tsx
//
// کارت دسترسی سریع — برای بخش Quick Actions پیشخوان

import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import type { CSSProperties, ReactNode } from 'react'

type Props = {
  icon: ReactNode
  title: string
  description?: string
  badge?: string | number
  href: string
  className?: string
}

export default function QuickActionCard({ icon, title, description, badge, href, className }: Props) {
  return (
    <a href={href} style={cardStyle} className={`quick-action-card${className ? ` ${className}` : ''}`}>
      {badge !== undefined && (
        <div style={badgeStyle}>
          {badge}
        </div>
      )}
      <div style={iconStyle}>{icon}</div>
      <div style={titleStyle} className="quick-action-title">{title}</div>
      {description && <div style={descStyle} className="quick-action-desc">{description}</div>}
    </a>
  )
}

const cardStyle: CSSProperties = {
  display: 'block',
  background: colors.bgCard,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
  padding: spacing.md,
  textDecoration: 'none',
  color: colors.textPrimary,
  transition: 'all 0.2s ease',
  position: 'relative',
  cursor: 'pointer',
}

const iconStyle: CSSProperties = {
  marginBottom: spacing.xs,
  lineHeight: 1,
  display: 'flex',
}

const titleStyle: CSSProperties = {
  fontSize: fontSize.md,
  fontWeight: 700,
  color: colors.textPrimary,
  marginBottom: 2,
}

const descStyle: CSSProperties = {
  fontSize: fontSize.xs,
  color: colors.textMuted,
  lineHeight: 1.5,
  marginTop: 4,
}

const badgeStyle: CSSProperties = {
  position: 'absolute',
  top: 8,
  left: 8,
  background: colors.orange,
  color: '#fff',
  fontSize: fontSize.xs,
  fontWeight: 700,
  borderRadius: 999,
  padding: '2px 8px',
  minWidth: 20,
  textAlign: 'center',
}
