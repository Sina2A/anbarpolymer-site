# NOTES — مگاتسک: انبار کلیک‌پذیر / انتقال بسته‌بندی / RFQ عمومی / گیت تولیدکننده

**تایید typecheck:** `npx tsc --noEmit` → **EXIT 0** (خروجی کامل پایین).
**قواعد رعایت‌شده:** بدون داده‌ی جعلی / از توابع و الگوهای موجود استفاده شد (بازسازی نشد) / تغییرات Schema همه Backward-safe / بدون commit/push.

---

## خروجی واقعی `npx tsc --noEmit`

```
$ npx tsc --noEmit
(بدون هیچ خروجی — هیچ خطایی)
EXIT: 0
```

---

## بخش ۱ — انبار کلیک‌پذیر + صفحه‌ی موجودی + blur مهمان + ناوبری

- **`src/app/warehouses/page.tsx`**: هر کارت داخل `<Link href={/warehouses/${w.id}}>` پیچیده شد (به‌جای `<div>`). `cardStyle` حالا `display:block, textDecoration:none, color:inherit, cursor:pointer` دارد؛ یک ردیف CTA «مشاهده‌ی موجودی این انبار ←» ته کارت اضافه شد. ساختار/محتوای داخلی کارت بی‌تغییر.
- **`src/app/warehouses/[id]/page.tsx`** (جدید): Server Component، `dynamic='force-dynamic'`، `params: Promise<{id:string}>` با `await` (کنوانسیون این نسخه‌ی Next). `getCurrentUserOrNull` (بدون ریدایرکت). `warehouse.findUnique` → اگر نبود `notFound()`. `warehouseStock.findMany({ where:{ warehouseId, quantityTon:{gt:0} }, include:{grade:true}, orderBy:{updatedAt:'desc'} })`. جدول: کد گرید، خانواده‌ی پلیمری، **نوع بسته‌بندی (per-stock)**، قیمت، موجودی، بچ، و دکمه‌ی «ⓘ» → `/grades/${code}`. Chrome عمومی: `CurrencyTicker`+`PublicHeader isLoggedIn`+`Footer` عیناً مثل `warehouses/page.tsx`.
- **`src/components/GuestBlurGate.tsx`** (جدید): وقتی `!isLoggedIn`، children را با `filter:'blur(8px)', pointerEvents:'none', userSelect:'none'` می‌پیچد و overlay مطلق با متن «برای مشاهده وارد شوید یا ثبت‌نام کنید» + دکمه‌های `/login` و `/signup`. لاگین‌شده: children بی‌تغییر. الگوی blur از `transport/page.tsx`. دو مصرف‌کننده (صفحه‌ی موجودی انبار + `/rfq-public`).
- **ناوبری `/warehouses`**: به `NAV_ITEMS` هدر عمومی (`PublicHeader.tsx`) اضافه شد؛ به `USER_SHEET_ITEMS` (شیت موبایل کاربر لاگین‌شده) اضافه شد (قبلاً فقط `GUEST_SHEET_ITEMS` داشت). آیکون `Warehouse` از قبل import بود.

## بخش ۲ — انتقال `packagingType` از `Grade` به `WarehouseStock`

- **`prisma/schema.prisma`**: `packagingType String?` از `Grade` حذف؛ `packagingType String?` به `WarehouseStock` اضافه (nullable → backward-safe).
- **Migration** `prisma/migrations/20260926000000_move_packaging_and_producer_gate/migration.sql` (دستی‌نوشته برای جلوگیری از data loss):
  1. `ALTER TABLE "WarehouseStock" ADD COLUMN "packagingType" TEXT;`
  2. `UPDATE "WarehouseStock" ws SET "packagingType"=g."packagingType" FROM "Grade" g WHERE ws."gradeId"=g."id" AND g."packagingType" IS NOT NULL;` (کپی بسته‌بندی هر گرید روی ردیف‌های موجودی همان گرید)
  3. `ALTER TABLE "Grade" DROP COLUMN "packagingType";`
  4. (بخش ۴) `ALTER TABLE "Grade" ADD COLUMN "requiresProducerVerification" BOOLEAN NOT NULL DEFAULT false;`
  نام جدول‌ها با double-quote چون `Grade`/`WarehouseStock` هیچ `@@map` ندارند.
- **سایت‌های نوشتن**: `admin-warehouses/actions.ts` (`upsertStockAction`) حالا `packagingType` را می‌خواند و در هر دو بلوک `create`/`update` می‌نویسد. `admin-warehouses/page.tsx`: ستون «نوع بسته‌بندی» در جدول موجودی + فیلد ورودی در فرم افزودن و فرم ویرایش inline (`colSpan` از 7/6 به 8/7 اصلاح شد).
- **سایت‌های خواندن روی Grade (بازاتصال)**: `grades/[code]/page.tsx` — KeyCell «نوع بسته‌بندی» حذف شد. `admin-grades/page.tsx` — فیلد packaging از فرم ساخت و ویرایش حذف شد. `admin-grades/actions.ts` — `packagingType` از create/update/CSV-create/CSV-update حذف شد. `gradeSpecs.ts` — `packagingType` از `CSV_BASE_COLUMNS` و نمونه‌ی template حذف؛ متن راهنمای شمارش ستون‌ها از `-11` به `-10` اصلاح شد.
- **⛔ OFF-LIMITS (دست نخورد):** ۴ فایلِ `MaterialListing.packagingType` (مدل جدا): `api/material-listings/route.ts`, `new-listing/page.tsx`, `my-listings/page.tsx`, `ListingDetailModal.tsx`. سویپ `grep -rn packagingType` تأیید کرد هیچ ارجاعِ Grade-context باقی نمانده.

## بخش ۳ — صفحه‌ی RFQ عمومی `/rfq-public`

- **`src/app/rfq-public/page.tsx`** (جدید): همان کوئری و mapping موجودیِ `/rfq` عیناً کپی شد. Chrome عمومی (`PublicHeader`/`Footer`). مهمان: `RfqCart` داخل `GuestBlurGate`. لاگین‌شده (هر سطح KYC): `RfqCart` کامل. **بازاستفاده‌ی مستقیم**: `import RfqCart from '../rfq/RfqCart'` و همان اکشن `submitRfq`. `/rfq` پنلی دست‌نخورده.
- **`rfq/actions.ts`**: `requireCompanyVerified(user.id)` → `requireCompanyVerifiedFor(user.id, 'U-KYC1-RFQ')` (کد از قبل تعریف‌شده و بلااستفاده بود) برای پیام دقیق‌تر. تنها تغییر منطقی که روی هر دو مسیر اثر مثبت دارد.
- **ناوبری (رفع باگ ریدایرکت مهمان در هر دو مسیر)**: `PublicHeader.NAV_ITEMS` خط «استعلام قیمت» `/rfq`→`/rfq-public`؛ `GUEST_SHEET_ITEMS` همان `/rfq`→`/rfq-public`. `USER_SHEET_ITEMS` خط `/rfq` برای کاربر لاگین‌شده دست‌نخورده (پنل برایش کار می‌کند).

## بخش ۴ — فلگ `requiresProducerVerification` روی Grade + گیت خرید (KYC سطح ۲)

- **schema + migration**: `requiresProducerVerification Boolean @default(false)` به `Grade`؛ SQL: `... BOOLEAN NOT NULL DEFAULT false` → ردیف‌های موجود `false` (رفتار KYC۱ فعلی حفظ). Backward-safe.
- **admin toggle**: `admin-grades/page.tsx` — checkbox «خرید این گرید فقط برای تولیدکننده‌ی احرازشده مجاز باشد (احراز سطح ۲)» به فرم ساخت و ویرایش. `admin-grades/actions.ts` — `requiresProducerVerification: formData.get('requiresProducerVerification') != null` در create/update (checkbox واقعی؛ uncheck چیزی نمی‌فرستد).
- **گیت سه مسیر خرید** (بازاستفاده از `requireVerifiedProducerFor(userId, 'U-KYC2-PRODUCERGRADE')`؛ گیت سطح ۱ موجود دست‌نخورده به‌عنوان کف):
  - `purchase-requests/actions.ts` → `createPurchaseRequestAction`: `select` گرید با `requiresProducerVerification` گسترش یافت؛ اگر true → گیت سطح ۲.
  - `rfq/actions.ts` → `submitRfq`: gradeIdهای متمایز سبد شمرده می‌شوند؛ اگر هر قلمی گریدِ مشمول داشت → گیت سطح ۲ (پوشش هر دو `/rfq` و `/rfq-public`).
  - `market/actions.ts` → `createDealFromListingAction`: read سبک پیش از `$transaction` روی گریدِ آگهی؛ اگر true → گیت سطح ۲. رزرو اتمیک داخل tx بی‌تغییر (fast-path read، هم‌راستا با الگوی موجود فایل).
  - `acceptPurchaseRequestAction` **مشمول نشد** (کاربرِ عمل‌کننده فروشنده است).
- **کد خطای جدید**: `errorCodes.ts` → `'U-KYC2-PRODUCERGRADE'` با پیام «خرید این گرید فقط برای تولیدکننده‌های احرازشده مجازه...» و `cta:'/verification'`. `requireVerifiedProducerFor` کد را روی `KycRequiredError.digest` می‌گذارد؛ `error.tsx` برندشده پیام+CTA را نشان می‌دهد.

---

## ⚠️ نکته‌ی مهم درباره‌ی Migration (باید روی سرور اجرا شود)

در این محیط `DATABASE_URL` یک placeholder است (کاربر `user`، دیتابیس `dummy`) و به دیتابیس واقعی وصل نمی‌شود، پس `prisma migrate dev` اینجا قابل‌اجرا نبود. فایل migration طبق روال تسک **دستی نوشته شده** (ترتیب ADD→UPDATE→DROP برای صفر data loss). `npx prisma generate` با موفقیت اجرا شد (schema معتبر است، کلاینت تولید شد).

**روی سرور، بعد از استقرار این فایل‌ها:**
```bash
npx prisma migrate deploy
```
این migration را اعمال می‌کند: بسته‌بندی موجودِ هر گرید روی ردیف‌های موجودیِ همان گرید کپی می‌شود، سپس ستونِ گریدی حذف، و فلگ تولیدکننده با پیش‌فرض false اضافه می‌شود.

---

## فایل‌های این تحویل

| فایل | بخش | نوع |
|---|---|---|
| `prisma/schema.prisma` | ۲،۴ | ویرایش |
| `prisma/migrations/20260926000000_move_packaging_and_producer_gate/migration.sql` | ۲،۴ | جدید |
| `src/app/warehouses/page.tsx` | ۱ | ویرایش |
| `src/app/warehouses/[id]/page.tsx` | ۱ | جدید |
| `src/components/GuestBlurGate.tsx` | ۱،۳ | جدید |
| `src/components/PublicHeader.tsx` | ۱،۳ | ویرایش |
| `src/lib/mobileNavItems.ts` | ۱،۳ | ویرایش |
| `src/app/admin-warehouses/actions.ts` | ۲ | ویرایش |
| `src/app/admin-warehouses/page.tsx` | ۲ | ویرایش |
| `src/app/grades/[code]/page.tsx` | ۲ | ویرایش |
| `src/app/admin-grades/page.tsx` | ۲،۴ | ویرایش |
| `src/app/admin-grades/actions.ts` | ۲،۴ | ویرایش |
| `src/lib/gradeSpecs.ts` | ۲ | ویرایش |
| `src/app/rfq-public/page.tsx` | ۳ | جدید |
| `src/app/rfq/actions.ts` | ۳،۴ | ویرایش |
| `src/app/purchase-requests/actions.ts` | ۴ | ویرایش |
| `src/app/market/actions.ts` | ۴ | ویرایش |
| `src/lib/errorCodes.ts` | ۴ | ویرایش |

بازاستفاده (بدون بازسازی): `RfqCart`، `submitRfq`، `requireCompanyVerifiedFor`/`requireVerifiedProducerFor`، `getCurrentUserOrNull`، `PublicHeader`/`Footer`/`getSurfaceHome`، توکن‌های styles، الگوی blur.
