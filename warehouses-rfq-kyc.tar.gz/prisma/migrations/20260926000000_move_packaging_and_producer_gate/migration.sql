-- Move packagingType from "Grade" to "WarehouseStock" (backward-safe, no data loss)
-- and add "Grade"."requiresProducerVerification" (producer KYC-2 gate flag).
--
-- Order matters: ADD the new column, COPY existing per-grade packaging onto every
-- stock row of that grade, then DROP the old column. If Prisma had auto-diffed it
-- would DROP+ADD and silently lose the data.

-- 1) New per-stock packaging column (nullable -> backward-safe)
ALTER TABLE "WarehouseStock" ADD COLUMN "packagingType" TEXT;

-- 2) Copy existing grade-level packaging onto its stock rows before dropping it
UPDATE "WarehouseStock" ws
  SET "packagingType" = g."packagingType"
  FROM "Grade" g
  WHERE ws."gradeId" = g."id" AND g."packagingType" IS NOT NULL;

-- 3) Remove the now-migrated grade-level column
ALTER TABLE "Grade" DROP COLUMN "packagingType";

-- 4) Producer-only purchase gate flag (existing rows default to false -> KYC-1 behavior preserved)
ALTER TABLE "Grade" ADD COLUMN "requiresProducerVerification" BOOLEAN NOT NULL DEFAULT false;
