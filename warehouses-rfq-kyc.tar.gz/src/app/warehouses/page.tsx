import Link from 'next/link'
import prisma from '@/lib/prisma'
import { getSurfaceHome } from '@/lib/surfaceHome'
import WarehousesMap from '@/components/WarehousesMap'
import CurrencyTicker from '@/components/CurrencyTicker'
import PublicHeader from '@/components/PublicHeader'
import { getCurrentUserOrNull } from '@/lib/currentUser'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { pageWrapStyle, emptyStateStyle, badgeStyle } from '@/lib/styles/shared'
import Footer from '@/components/Footer'

export const dynamic = 'force-dynamic'

export default async function WarehousesPage() {
  const user = await getCurrentUserOrNull()
  const warehouses = await prisma.warehouse.findMany({
    orderBy: [{ city: 'asc' }, { name: 'asc' }],
  })
  const withLocation = warehouses.filter((w) => w.latitude && w.longitude)

  return (
    <div style={pageStyle}>
      <CurrencyTicker />
      <PublicHeader homeHref={getSurfaceHome()} activePage="/warehouses" isLoggedIn={!!user} />

      <main style={mainStyle}>
        {/* عنوان صفحه */}
        <div style={heroStyle}>
          <h1 style={heroTitle}>شبکه‌ی انبارهای انبار پلیمر</h1>
          <p style={heroSub}>
            موقعیت انبارهای فعال روی نقشه و فهرست کامل آن‌ها — برای شفافیت زنجیره‌ی عرضه.
          </p>
        </div>

        {/* نقشه */}
        <section style={sectionStyle}>
          <h2 style={sectionTitle}>موقعیت روی نقشه</h2>
          <WarehousesMap warehouses={withLocation} />
          {withLocation.length > 0 && (
            <p style={hintStyle}>
              📍 {withLocation.length} انبار از {warehouses.length} انبار دارای موقعیت ثبت‌شده هستند.
            </p>
          )}
        </section>

        {/* لیست کارتی همه‌ی انبارها */}
        <section style={sectionStyle}>
          <h2 style={sectionTitle}>فهرست انبارها</h2>
          {warehouses.length === 0 ? (
            <div style={emptyCardStyle}>هیچ انباری ثبت نشده است.</div>
          ) : (
            <div style={gridStyle}>
              {warehouses.map((w) => (
                <Link key={w.id} href={`/warehouses/${w.id}`} style={cardStyle}>
                  <div style={cardHead}>
                    <h3 style={cardTitle}>{w.name}</h3>
                    {w.latitude && w.longitude && (
                      <span style={geoBadge}>📍 روی نقشه</span>
                    )}
                  </div>
                  <div style={cardRow}>
                    <span style={cardLabel}>شهر</span>
                    <span style={cardValue}>{w.city}</span>
                  </div>
                  {w.address && (
                    <div style={cardRow}>
                      <span style={cardLabel}>آدرس</span>
                      <span style={cardValue}>{w.address}</span>
                    </div>
                  )}
                  {w.description && (
                    <p style={cardDesc}>{w.description}</p>
                  )}
                  <div style={cardCta}>مشاهده‌ی موجودی این انبار ←</div>
                </Link>
              ))}
            </div>
          )}
        </section>
      </main>

      <Footer homeHref={getSurfaceHome()} />
    </div>
  )
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: colors.bgPage,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
  display: 'flex',
  flexDirection: 'column',
}
const mainStyle: React.CSSProperties = {
  ...pageWrapStyle,
  padding: '32px 24px',
  flex: 1,
  boxSizing: 'border-box',
}
const heroStyle: React.CSSProperties = {
  marginBottom: 28,
}
const heroTitle: React.CSSProperties = {
  fontSize: fontSize.xl,
  fontWeight: 800,
  color: colors.textPrimary,
  marginBottom: spacing.sm,
}
const heroSub: React.CSSProperties = {
  fontSize: fontSize.base,
  color: colors.textSecondary,
  lineHeight: 1.7,
}
const sectionStyle: React.CSSProperties = {
  marginBottom: 36,
}
const sectionTitle: React.CSSProperties = {
  fontSize: fontSize.lg,
  fontWeight: 700,
  color: colors.textPrimary,
  marginBottom: 14,
}
const hintStyle: React.CSSProperties = {
  fontSize: fontSize.xs,
  color: colors.textMuted,
  marginTop: 10,
}
const emptyCardStyle: React.CSSProperties = {
  ...emptyStateStyle,
  border: `1px dashed ${colors.borderStrong}`,
  borderRadius: radius.lg,
  padding: 40,
  textAlign: 'center',
}
const gridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
  gap: 14,
}
const cardStyle: React.CSSProperties = {
  display: 'block',
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
  padding: 18,
  background: colors.bgCard,
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
  textDecoration: 'none',
  color: 'inherit',
  cursor: 'pointer',
}
const cardCta: React.CSSProperties = {
  marginTop: 12,
  paddingTop: 10,
  borderTop: `1px solid ${colors.borderSubtle}`,
  fontSize: fontSize.xs,
  fontWeight: 700,
  color: colors.navy,
}
const cardHead: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  gap: spacing.sm,
  marginBottom: spacing.md,
}
const cardTitle: React.CSSProperties = {
  fontSize: fontSize.md,
  fontWeight: 700,
  color: colors.navy,
  margin: 0,
}
const geoBadge: React.CSSProperties = {
  ...badgeStyle('success'),
  whiteSpace: 'nowrap',
}
const cardRow: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  gap: 10,
  marginBottom: 6,
  fontSize: fontSize.base,
}
const cardLabel: React.CSSProperties = {
  color: colors.textMuted,
  fontSize: fontSize.xs,
}
const cardValue: React.CSSProperties = {
  color: colors.textPrimary,
  fontWeight: 600,
  textAlign: 'left',
}
const cardDesc: React.CSSProperties = {
  fontSize: fontSize.xs,
  color: colors.textSecondary,
  lineHeight: 1.7,
  marginTop: 10,
  paddingTop: 10,
  borderTop: `1px solid ${colors.borderSubtle}`,
}
