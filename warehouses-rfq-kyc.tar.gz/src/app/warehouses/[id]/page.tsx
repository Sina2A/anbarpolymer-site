import Link from 'next/link'
import { notFound } from 'next/navigation'
import prisma from '@/lib/prisma'
import { getSurfaceHome } from '@/lib/surfaceHome'
import CurrencyTicker from '@/components/CurrencyTicker'
import PublicHeader from '@/components/PublicHeader'
import Footer from '@/components/Footer'
import GuestBlurGate from '@/components/GuestBlurGate'
import { getCurrentUserOrNull } from '@/lib/currentUser'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { pageWrapStyle, tableStyle, theadRowStyle, thStyle, tdStyle, emptyStateStyle } from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

export default async function WarehouseStockPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const user = await getCurrentUserOrNull()

  const warehouse = await prisma.warehouse.findUnique({ where: { id } })
  if (!warehouse) notFound()

  const stock = await prisma.warehouseStock.findMany({
    where: { warehouseId: id, quantityTon: { gt: 0 } },
    include: { grade: true },
    orderBy: { updatedAt: 'desc' },
  })

  return (
    <div style={pageStyle}>
      <CurrencyTicker />
      <PublicHeader homeHref={getSurfaceHome()} activePage="/warehouses" isLoggedIn={!!user} />

      <main style={mainStyle}>
        <div style={heroStyle}>
          <Link href="/warehouses" style={backLinkStyle}>→ بازگشت به فهرست انبارها</Link>
          <h1 style={heroTitle}>{warehouse.name}</h1>
          <p style={heroSub}>
            شهر: {warehouse.city}
            {warehouse.address ? ` — ${warehouse.address}` : ''}
          </p>
        </div>

        <section style={sectionStyle}>
          <h2 style={sectionTitle}>موجودی گریدهای این انبار</h2>

          {stock.length === 0 ? (
            <div style={emptyCardStyle}>در حال حاضر موجودی فعالی برای این انبار ثبت نشده است.</div>
          ) : (
            <GuestBlurGate isLoggedIn={!!user}>
              <div style={{ overflowX: 'auto', background: colors.bgCard, border: `1px solid ${colors.borderSubtle}`, borderRadius: radius.lg, padding: spacing.md }}>
                <table style={tableStyle}>
                  <thead>
                    <tr style={theadRowStyle}>
                      <th style={thStyle}>کد گرید</th>
                      <th style={thStyle}>خانواده پلیمری</th>
                      <th style={thStyle}>نوع بسته‌بندی</th>
                      <th style={thStyle}>قیمت (ریال/کیلو)</th>
                      <th style={thStyle}>موجودی (تن)</th>
                      <th style={thStyle}>بچ</th>
                      <th style={thStyle}></th>
                    </tr>
                  </thead>
                  <tbody>
                    {stock.map((s) => (
                      <tr key={s.id} className="stripe-row-hover">
                        <td style={{ ...tdStyle, fontFamily: 'monospace', fontWeight: 700 }}>{s.grade.code}</td>
                        <td style={tdStyle}>{s.grade.polymerFamily || '—'}</td>
                        <td style={tdStyle}>{s.packagingType || '—'}</td>
                        <td style={{ ...tdStyle, fontFamily: 'monospace', direction: 'ltr', textAlign: 'right' }}>
                          {s.priceRial.toLocaleString('en-US')}
                        </td>
                        <td style={{ ...tdStyle, fontFamily: 'monospace', direction: 'ltr', textAlign: 'right' }}>
                          {s.quantityTon.toLocaleString('en-US')}
                        </td>
                        <td style={{ ...tdStyle, color: colors.textSecondary }}>{s.batch || '—'}</td>
                        <td style={{ ...tdStyle, whiteSpace: 'nowrap' }}>
                          <Link
                            href={`/grades/${encodeURIComponent(s.grade.code)}`}
                            style={infoBtnStyle}
                            title="مشاهده‌ی مشخصات فنی گرید"
                          >
                            ⓘ
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </GuestBlurGate>
          )}
        </section>
      </main>

      <Footer homeHref={getSurfaceHome()} />
    </div>
  )
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: colors.bgPage,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
  display: 'flex',
  flexDirection: 'column',
}
const mainStyle: React.CSSProperties = {
  ...pageWrapStyle,
  flexDirection: 'column',
  padding: '32px 24px',
  flex: 1,
  boxSizing: 'border-box',
}
const heroStyle: React.CSSProperties = {
  marginBottom: 28,
}
const backLinkStyle: React.CSSProperties = {
  display: 'inline-block',
  fontSize: fontSize.xs,
  fontWeight: 700,
  color: colors.navy,
  textDecoration: 'none',
  marginBottom: spacing.md,
}
const heroTitle: React.CSSProperties = {
  fontSize: fontSize.xl,
  fontWeight: 800,
  color: colors.textPrimary,
  marginBottom: spacing.sm,
}
const heroSub: React.CSSProperties = {
  fontSize: fontSize.base,
  color: colors.textSecondary,
  lineHeight: 1.7,
}
const sectionStyle: React.CSSProperties = {
  marginBottom: 36,
}
const sectionTitle: React.CSSProperties = {
  fontSize: fontSize.lg,
  fontWeight: 700,
  color: colors.textPrimary,
  marginBottom: 14,
}
const emptyCardStyle: React.CSSProperties = {
  ...emptyStateStyle,
  border: `1px dashed ${colors.borderStrong}`,
  borderRadius: radius.lg,
  padding: 40,
  textAlign: 'center',
}
const infoBtnStyle: React.CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  width: 30,
  height: 30,
  borderRadius: 999,
  border: `1px solid ${colors.borderStrong}`,
  background: colors.bgCard,
  color: colors.navy,
  fontSize: fontSize.md,
  fontWeight: 700,
  textDecoration: 'none',
}
