'use server'

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { computePriceSnapshot } from '@/lib/pricing'
import { logStatusEvent } from '@/lib/statusEvents'
import { requireCompanyVerifiedFor, requireVerifiedProducerFor } from '@/lib/kyc'
import { redirect } from 'next/navigation'
import { SubmitRfqSchema } from '@/schemas/rfq'

interface CartItemInput {
  gradeId: string
  warehouseId: string
  quantity: number
}

/**
 * قفل موجودی + اعتبارسنجی — این تابع حالا واقعاً موجودی رو کم می‌کنه، نه
 * فقط می‌خونتش. برای جلوگیری از race condition (دو خریدار هم‌زمان برای
 * همون موجودی محدود درخواست بزنن)، از یه الگوی atomic استفاده می‌کنیم:
 * updateMany با شرط quantityTon >= درخواستی — اگه کسی زودتر برداشته باشه،
 * count صفر برمی‌گرده و همون‌جا با خطای واضح متوقف می‌شیم، نه اینکه موجودی
 * منفی بشه.
 */
export async function submitRfq(cartItems: CartItemInput[]) {
  const user = await getCurrentUser()

  // دروازه‌ی احراز هویت — تا هویت شرکت (سطح ۱) تایید نشه، نمی‌تونه استعلام
  // بفرسته. KycRequiredError پیام فارسی مناسب خودش رو داره.
  await requireCompanyVerifiedFor(user.id, 'U-KYC1-RFQ')

  // Zod validation
  const result = SubmitRfqSchema.safeParse({ cartItems })
  if (!result.success) {
    const firstError = Object.values(result.error.flatten().fieldErrors)[0]?.[0] ||
                       result.error.flatten().formErrors[0] ||
                       'ورودی معتبر نیست'
    throw new Error(firstError)
  }

  // گیت سطح ۲ — اگه هر قلم سبد گریدی باشه که فقط تولیدکننده‌ی احرازشده حق خریدش رو داره
  const gradeIds = [...new Set(result.data.cartItems.map((i) => i.gradeId))]
  const gatedCount = await prisma.grade.count({
    where: { id: { in: gradeIds }, requiresProducerVerification: true },
  })
  if (gatedCount > 0) {
    await requireVerifiedProducerFor(user.id, 'U-KYC2-PRODUCERGRADE')
  }

  const order = await prisma.$transaction(async (tx) => {
    const orderItemsData = []

    for (const item of result.data.cartItems) {

      // قفل اتمیک: فقط اگه موجودی کافی باشه، هم‌زمان کم می‌شه
      const result = await tx.warehouseStock.updateMany({
        where: { id: item.warehouseId, quantityTon: { gte: item.quantity } },
        data: { quantityTon: { decrement: item.quantity } },
      })

      if (result.count === 0) {
        // یا موجودی اصلاً وجود نداره، یا کافی نیست (شاید همین الان یکی دیگه برداشت)
        const stock = await tx.warehouseStock.findUnique({ where: { id: item.warehouseId } })
        if (!stock) throw new Error('یکی از اقلام سبد دیگه در دسترس نیست.')
        throw new Error(`موجودی «${stock.batch || 'این گرید'}» کافی نیست — فقط ${stock.quantityTon} تن باقی مونده.`)
      }

      const stock = await tx.warehouseStock.findUnique({ where: { id: item.warehouseId } })
      if (!stock) throw new Error('خطای غیرمنتظره در خواندن موجودی.')

      const snapshot = computePriceSnapshot(stock.priceRial)
      orderItemsData.push({
        gradeId: item.gradeId,
        warehouseId: stock.warehouseId,
        quantity: item.quantity,
        price: snapshot.price,
        priceSnapshotAt: snapshot.priceSnapshotAt,
        priceValidUntil: snapshot.priceValidUntil,
      })
    }

    return tx.order.create({
      data: {
        userId: user.id,
        status: 'pending',
        items: { create: orderItemsData },
      },
    })
  })

  await logStatusEvent({
    recordType: 'Order',
    recordId: order.id,
    newStageKey: 'pending',
    performedById: user.id,
    note: 'درخواست قیمت (RFQ) توسط مشتری ثبت شد — موجودی مربوطه قفل شد',
  })

  redirect('/my-orders')
}