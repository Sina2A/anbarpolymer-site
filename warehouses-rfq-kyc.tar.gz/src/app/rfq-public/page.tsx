import prisma from '@/lib/prisma'
import { getSurfaceHome } from '@/lib/surfaceHome'
import { getCurrentUserOrNull } from '@/lib/currentUser'
import CurrencyTicker from '@/components/CurrencyTicker'
import PublicHeader from '@/components/PublicHeader'
import Footer from '@/components/Footer'
import GuestBlurGate from '@/components/GuestBlurGate'
import RfqCart from '../rfq/RfqCart'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { pageWrapStyle, emptyStateStyle } from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

export default async function RfqPublicPage() {
  const user = await getCurrentUserOrNull()

  // همان کوئری و mapping صفحه‌ی پنلی /rfq — فقط اقلامی که موجودی فعلی‌شون > 0 هست
  const stocks = await prisma.warehouseStock.findMany({
    where: { quantityTon: { gt: 0 } },
    include: { grade: true, warehouse: true },
    orderBy: { updatedAt: 'desc' },
  })

  const items = stocks.map((s) => ({
    warehouseId: s.id,
    gradeId: s.gradeId,
    gradeCode: s.grade.code,
    producer: s.grade.producer,
    warehouseName: s.warehouse.name,
    warehouseCity: s.warehouse.city,
    availableTon: s.quantityTon,
    priceRial: s.priceRial,
  }))

  return (
    <div style={pageStyle}>
      <CurrencyTicker />
      <PublicHeader homeHref={getSurfaceHome()} activePage="/rfq-public" isLoggedIn={!!user} />

      <main style={mainStyle}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <h1 style={titleStyle}>درخواست خرید از انبار (سبد چندمحصولی)</h1>
          <p style={subStyle}>
            موجودی زنده‌ی انبارها رو ببین، اقلام مورد نظرت رو به سبد اضافه کن،
            و در نهایت یک درخواست خرید واحد (Order) با چند ردیف ثبت کن.
          </p>

          {items.length === 0 ? (
            <div style={emptyStyle}>فعلاً هیچ موجودی فعالی توی انبارها ثبت نشده.</div>
          ) : (
            <GuestBlurGate isLoggedIn={!!user}>
              <RfqCart items={items} />
            </GuestBlurGate>
          )}
        </div>
      </main>

      <Footer homeHref={getSurfaceHome()} />
    </div>
  )
}

const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: colors.bgPage,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
  display: 'flex',
  flexDirection: 'column',
}
const mainStyle: React.CSSProperties = {
  ...pageWrapStyle,
  flexDirection: 'column',
  padding: `${spacing.xxl}px ${spacing.xl}px`,
  flex: 1,
  boxSizing: 'border-box',
}
const titleStyle: React.CSSProperties = {
  fontSize: fontSize.xxl,
  fontWeight: 800,
  marginBottom: spacing.sm,
  color: colors.textPrimary,
}
const subStyle: React.CSSProperties = {
  color: colors.textSecondary,
  fontSize: fontSize.md,
  marginBottom: 22,
  lineHeight: 1.9,
}
const emptyStyle: React.CSSProperties = {
  ...emptyStateStyle,
  padding: 32,
  border: `1px dashed ${colors.borderStrong}`,
  borderRadius: radius.lg,
}
