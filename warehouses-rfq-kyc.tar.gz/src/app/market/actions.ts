'use server'

import prisma from '@/lib/prisma'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import { getCurrentUser } from '@/lib/currentUser'
import { requireCompanyVerifiedFor, requireVerifiedProducerFor } from '@/lib/kyc'
import { isUserRestricted, startSellerFeeDeadline } from '@/lib/dealDeadlines'
import { logAudit } from '@/lib/logger'

export async function createDealFromListingAction(formData: FormData) {
  const materialListingId = String(formData.get('materialListingId') || '').trim()
  const quantity = String(formData.get('quantity') || '').trim()
  const offerPriceRaw = String(formData.get('offerPriceToman') || '').trim()
  const notes = String(formData.get('notes') || '').trim()

  if (!materialListingId) throw new Error('آگهی انتخاب نشده است.')

  const user = await getCurrentUser()
  await requireCompanyVerifiedFor(user.id, 'U-KYC1-DEAL')

  const restriction = await isUserRestricted(user.id)
  if (restriction.restricted) throw new Error(restriction.reason || 'حساب کاربری شما موقتاً محدود شده است.')

  // گیت سطح ۲ — اگه گریدِ این آگهی فقط برای تولیدکننده‌ی احرازشده قابل خریده.
  // این فقط یک read پیش از رزروه (هم‌راستا با الگوی findUnique fast-path داخل tx)؛
  // رزرو اتمیک داخل tx بدون تغییر می‌مونه.
  const gateInfo = await prisma.materialListing.findUnique({
    where: { id: materialListingId },
    select: { grade: { select: { requiresProducerVerification: true } } },
  })
  if (gateInfo?.grade?.requiresProducerVerification) {
    await requireVerifiedProducerFor(user.id, 'U-KYC2-PRODUCERGRADE')
  }

  const offerPrice = offerPriceRaw ? Number(offerPriceRaw) : null
  const deal = await prisma.$transaction(async (tx) => {
    const listing = await tx.materialListing.findUnique({ where: { id: materialListingId } })
    if (!listing || listing.validityStatus !== 'active') {
      throw new Error('این آگهی دیگر در دسترس نیست یا رزرو شده است.')
    }
    if (listing.userId === user.id) throw new Error('خرید از آگهی خودتان امکان‌پذیر نیست.')

    const agreedPrice = offerPrice !== null && Number.isFinite(offerPrice)
      ? offerPrice
      : listing.askingPriceToman ?? null

    // رزرو اتمیک: شرط validityStatus:'active' داخل WHERE. اگر تراکنش همزمانی
    // زودتر آگهی را reserved کرده باشد، count صفر می‌شود و اینDeal ساخته نمی‌شود.
    // (تحت isolation پیش‌فرض Postgres یعنی READ COMMITTED، تنها همین شرطِ داخل
    //  UPDATE است که race را می‌بندد؛ چکِ findUnique بالاتر فقط fast-path است.)
    const reserved = await tx.materialListing.updateMany({
      where: { id: materialListingId, validityStatus: 'active' },
      data: { validityStatus: 'reserved' },
    })
    if (reserved.count === 0) {
      throw new Error('این آگهی دیگر در دسترس نیست یا رزرو شده است.')
    }

    // مدل ۴نقشی (v2): این مسیر «خریدار روی آگهی فروش» است ⇒ tradeDirection=SELL.
    // فروشنده (صاحب آگهی) requester است و خریدار (کاربر فعلی) acceptor. نقش‌ها همین‌جا
    // snapshot می‌شوند تا تغییر بعدیِ مالکیت آگهی، طرفین این معامله را جابه‌جا نکند.
    // دو ردیف DealPayment مستقل ساخته می‌شود؛ گیتِ عبور به حمل بر اساس همین ردیف‌هاست نه status.
    return tx.deal.create({
      data: {
        buyerId: user.id,
        sellerId: listing.userId,
        requesterId: listing.userId,
        acceptorId: user.id,
        tradeDirection: 'SELL',
        materialListingId,
        quantity: quantity || `${listing.quantityTon} تن`,
        agreedPrice,
        status: 'draft',
        payments: {
          create: [
            { kind: 'BUYER_GOODS', amount: agreedPrice, status: 'PENDING' },
            { kind: 'SELLER_FEE', amount: null, status: 'PENDING' },
          ],
        },
      },
    })
  })

  void notes
  await startSellerFeeDeadline(materialListingId)
  await logAudit('deal', 'پیشنهاد خرید جدید', user.id, { dealId: deal.id, tradeDirection: 'SELL' })
  revalidatePath('/my-deals')
  redirect('/my-deals')
}

/**
 * مسیر قرینه‌ی بازار دوطرفه: فروشنده یک «درخواست خرید» (PurchaseRequest) را می‌پذیرد.
 * tradeDirection=BUY ⇒ خریدار (ثبت‌کننده‌ی درخواست) requester و فروشنده (کاربر فعلی) acceptor.
 * رزرو race-safe روی همان فیلد status موجودِ PurchaseRequest انجام می‌شود (open → reserved):
 * شرط status:'open' داخل WHEREِ updateMany تنها چیزی است که همزمانی را می‌بندد.
 */
export async function acceptPurchaseRequestAction(formData: FormData) {
  const purchaseRequestId = String(formData.get('purchaseRequestId') || '').trim()
  const quantity = String(formData.get('quantity') || '').trim()
  const offerPriceRaw = String(formData.get('offerPriceToman') || '').trim()
  const notes = String(formData.get('notes') || '').trim()

  if (!purchaseRequestId) throw new Error('درخواست خرید انتخاب نشده است.')

  const user = await getCurrentUser()
  await requireCompanyVerifiedFor(user.id, 'U-KYC1-DEAL')

  const restriction = await isUserRestricted(user.id)
  if (restriction.restricted) throw new Error(restriction.reason || 'حساب کاربری شما موقتاً محدود شده است.')

  const offerPrice = offerPriceRaw ? Number(offerPriceRaw) : null
  const deal = await prisma.$transaction(async (tx) => {
    const request = await tx.purchaseRequest.findUnique({ where: { id: purchaseRequestId } })
    if (!request || request.status !== 'open') {
      throw new Error('این درخواست دیگر در دسترس نیست یا رزرو شده است.')
    }
    if (request.userId === user.id) throw new Error('پذیرش درخواست خودتان امکان‌پذیر نیست.')

    const agreedPrice = offerPrice !== null && Number.isFinite(offerPrice)
      ? offerPrice
      : request.maxPriceToman ?? null

    // رزرو اتمیک روی status موجود: اگر تراکنش همزمانی زودتر آن را reserved کرده باشد،
    // count صفر می‌شود و این Deal ساخته نمی‌شود. (READ COMMITTED؛ شرطِ داخل UPDATE race را می‌بندد.)
    const reserved = await tx.purchaseRequest.updateMany({
      where: { id: purchaseRequestId, status: 'open' },
      data: { status: 'reserved' },
    })
    if (reserved.count === 0) {
      throw new Error('این درخواست دیگر در دسترس نیست یا رزرو شده است.')
    }

    // BUY: buyer=ثبت‌کننده‌ی درخواست (requester)، seller=کاربر فعلی (acceptor)
    return tx.deal.create({
      data: {
        buyerId: request.userId,
        sellerId: user.id,
        requesterId: request.userId,
        acceptorId: user.id,
        tradeDirection: 'BUY',
        purchaseRequestId,
        quantity: quantity || `${request.quantityTon} تن`,
        agreedPrice,
        status: 'draft',
        payments: {
          create: [
            { kind: 'BUYER_GOODS', amount: agreedPrice, status: 'PENDING' },
            { kind: 'SELLER_FEE', amount: null, status: 'PENDING' },
          ],
        },
      },
    })
  })

  void notes
  await logAudit('deal', 'پذیرش درخواست خرید', user.id, { dealId: deal.id, tradeDirection: 'BUY', purchaseRequestId })
  revalidatePath('/my-deals')
  redirect('/my-deals')
}
