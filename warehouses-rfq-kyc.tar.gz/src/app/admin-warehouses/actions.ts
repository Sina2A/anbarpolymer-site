'use server'

// اکشن‌های CRUD پنل مدیریت انبارها:
//   ۱. createWarehouseAction — افزودن انبار جدید
//   ۲. updateWarehouseAction — ویرایش اطلاعات انبار
//   ۳. upsertStockAction — افزودن/به‌روزرسانی موجودی یک گرید در یک انبار
//   ۴. deleteStockAction — حذف ردیف موجودی
//
// قاعده: فقط Edit/Write، بدون شل. اسم فیلدها از مدل واقعی.

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import { AccessDeniedError } from '@/lib/errorCodes'
import { logAudit } from '@/lib/logger'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'

// ---------------------------------------------------------------- دسترسی

/** چک دسترسی نوشتن روی بخش «warehouses» */
async function requireWarehouseEditAccess() {
  const user = await getCurrentUser()
  if (user.role === 'admin') return user
  const access = await getAllSectionAccess(user.id)
  if (access.warehouses !== 'edit' && access.warehouses !== 'full') {
    throw new AccessDeniedError(
      'A-SECTION-WAREHOUSES',
      'دسترسی ویرایش انبارها رو نداری — از مدیر بخواه بهت بده.'
    )
  }
  return user
}

// ---------------------------------------------------------------- کار با عدد

/** «230,5» یا «230.5» رو عدد کن. خالی → null. */
function toFloatOrNull(s: string | undefined | null): number | null {
  const t = (s ?? '').trim().replace(/٬/g, '').replace(',', '.')
  if (!t) return null
  const n = Number(t)
  return Number.isFinite(n) ? n : null
}

// ================================================================ ایجاد انبار

export async function createWarehouseAction(formData: FormData) {
  const user = await requireWarehouseEditAccess()

  const name = (formData.get('name') as string)?.trim()
  const city = (formData.get('city') as string)?.trim()
  if (!name || !city) {
    throw new Error('نام و شهر انبار الزامی است.')
  }

  const warehouse = await prisma.warehouse.create({
    data: {
      name,
      city,
      address: (formData.get('address') as string)?.trim() || null,
      description: (formData.get('description') as string)?.trim() || null,
      latitude: toFloatOrNull(formData.get('latitude') as string),
      longitude: toFloatOrNull(formData.get('longitude') as string),
    },
  })

  await logAudit('warehouses', `انبار «${name}» ایجاد شد`, user.id, { warehouseId: warehouse.id })
  revalidatePath('/admin-warehouses')
  revalidatePath('/warehouses')
  redirect('/admin-warehouses?created=1')
}

// ================================================================ ویرایش انبار

export async function updateWarehouseAction(formData: FormData) {
  const user = await requireWarehouseEditAccess()

  const id = formData.get('id') as string
  const name = (formData.get('name') as string)?.trim()
  const city = (formData.get('city') as string)?.trim()
  if (!id) throw new Error('شناسه انبار نامعتبر.')
  if (!name || !city) throw new Error('نام و شهر انبار الزامی است.')

  await prisma.warehouse.update({
    where: { id },
    data: {
      name,
      city,
      address: (formData.get('address') as string)?.trim() || null,
      description: (formData.get('description') as string)?.trim() || null,
      latitude: toFloatOrNull(formData.get('latitude') as string),
      longitude: toFloatOrNull(formData.get('longitude') as string),
    },
  })

  await logAudit('warehouses', `انبار «${name}» ویرایش شد`, user.id, { warehouseId: id })
  revalidatePath('/admin-warehouses')
  revalidatePath('/warehouses')
  redirect('/admin-warehouses?updated=1')
}

// ================================================================ موجودی (upsert)

export async function upsertStockAction(formData: FormData) {
  const user = await requireWarehouseEditAccess()

  const gradeId = formData.get('gradeId') as string
  const warehouseId = formData.get('warehouseId') as string
  const quantityTon = toFloatOrNull(formData.get('quantityTon') as string)
  const priceRial = toFloatOrNull(formData.get('priceRial') as string)
  const batch = (formData.get('batch') as string)?.trim() || null
  const packagingType = (formData.get('packagingType') as string)?.trim() || null

  if (!gradeId || !warehouseId) throw new Error('گرید و انبار الزامی است.')
  if (quantityTon == null || priceRial == null) throw new Error('مقدار و قیمت الزامی هستند.')

  const existing = await prisma.warehouseStock.findFirst({
    where: { gradeId, warehouseId },
  })

  if (existing) {
    await prisma.warehouseStock.update({
      where: { id: existing.id },
      data: { quantityTon, priceRial, batch, packagingType },
    })
  } else {
    await prisma.warehouseStock.create({
      data: { gradeId, warehouseId, quantityTon, priceRial, batch, packagingType },
    })
  }

  await logAudit(
    'warehouses',
    existing ? `موجودی گرید ${gradeId} در انبار ${warehouseId} بروزرسانی شد` : `موجودی گرید ${gradeId} در انبار ${warehouseId} ثبت شد`,
    user.id,
    { gradeId, warehouseId, quantityTon, priceRial }
  )
  revalidatePath('/admin-warehouses')
  revalidatePath('/warehouses')
  redirect('/admin-warehouses?stock=1')
}

// ================================================================ حذف موجودی

export async function deleteStockAction(formData: FormData) {
  const user = await requireWarehouseEditAccess()

  const id = formData.get('id') as string
  if (!id) throw new Error('شناسه ردیف نامعتبر.')

  const stock = await prisma.warehouseStock.findUnique({ where: { id } })
  if (stock) {
    await prisma.warehouseStock.delete({ where: { id } })
    await logAudit('warehouses', `ردیف موجودی ${stock.gradeId} در انبار ${stock.warehouseId} حذف شد`, user.id, { stockId: id })
  }

  revalidatePath('/admin-warehouses')
  revalidatePath('/warehouses')
  redirect('/admin-warehouses?deleted=1')
}

// ================================================================ حذف انبار (با تاییدیه‌ی مدیر)
//
// جریان:
//   - کارشناس (غیرمدیر) روی «درخواست حذف» می‌زنه → فقط deletionRequestedById/At پر می‌شه
//   - مدیر واقعی (role==='admin') همون دکمه رو بزنه → مستقیم حذف می‌شه (نیازی به تایید از خودش نیست)
//   - مدیر روی درخواست‌های در انتظار، «تایید نهایی» یا «رد» می‌زنه

export async function requestDeleteWarehouseAction(formData: FormData) {
  const user = await requireWarehouseEditAccess()
  const id = formData.get('id') as string
  if (!id) throw new Error('شناسه انبار نامعتبر.')

  if (user.role === 'admin') {
    await performWarehouseDeletion(id, user.id)
    revalidatePath('/admin-warehouses')
    revalidatePath('/warehouses')
    redirect('/admin-warehouses?deletedWarehouse=1')
  }

  const warehouse = await prisma.warehouse.findUnique({ where: { id } })
  if (!warehouse) throw new Error('انبار پیدا نشد.')

  await prisma.warehouse.update({
    where: { id },
    data: { deletionRequestedById: user.id, deletionRequestedAt: new Date() },
  })

  await logAudit('warehouses', `درخواست حذف انبار «${warehouse.name}» ثبت شد`, user.id, { warehouseId: id })
  revalidatePath('/admin-warehouses')
  redirect('/admin-warehouses?deletionRequested=1')
}

/** فقط مدیر واقعی — تایید نهایی و حذف قطعی انبار */
export async function approveWarehouseDeletionAction(formData: FormData) {
  const user = await getCurrentUser()
  if (user.role !== 'admin') {
    throw new Error('فقط مدیر می‌تونه درخواست حذف رو تایید کنه.')
  }
  const id = formData.get('id') as string
  if (!id) throw new Error('شناسه انبار نامعتبر.')

  await performWarehouseDeletion(id, user.id)
  revalidatePath('/admin-warehouses')
  revalidatePath('/warehouses')
  redirect('/admin-warehouses?deletedWarehouse=1')
}

/** فقط مدیر واقعی — رد درخواست حذف (انبار دست‌نخورده می‌مونه) */
export async function rejectWarehouseDeletionAction(formData: FormData) {
  const user = await getCurrentUser()
  if (user.role !== 'admin') {
    throw new Error('فقط مدیر می‌تونه درخواست حذف رو رد کنه.')
  }
  const id = formData.get('id') as string
  if (!id) throw new Error('شناسه انبار نامعتبر.')

  const warehouse = await prisma.warehouse.findUnique({ where: { id } })
  if (warehouse) {
    await prisma.warehouse.update({
      where: { id },
      data: { deletionRequestedById: null, deletionRequestedAt: null },
    })
    await logAudit('warehouses', `درخواست حذف انبار «${warehouse.name}» رد شد`, user.id, { warehouseId: id })
  }

  revalidatePath('/admin-warehouses')
  redirect('/admin-warehouses?deletionRejected=1')
}

/**
 * حذف واقعی — فقط از داخل دو اکشن بالا صدا زده می‌شه، نه مستقیم از فرم.
 * محافظت حیاتی: اگه انبار موجودی یا سابقه‌ی سفارش داشته باشه، حذف مسدود
 * می‌شه (وگرنه دقیقاً همون خطای Foreign key constraint که توی RFQ دیدیم
 * رخ می‌ده، چون OrderItem.warehouseId به این انبار اشاره می‌کنه).
 */
async function performWarehouseDeletion(id: string, actorId: string) {
  const warehouse = await prisma.warehouse.findUnique({
    where: { id },
    include: { _count: { select: { stock: true, orderItems: true } } },
  })
  if (!warehouse) throw new Error('انبار پیدا نشد.')

  if (warehouse._count.stock > 0) {
    throw new Error(`نمی‌شه این انبار رو حذف کرد — هنوز ${warehouse._count.stock} ردیف موجودی داره. اول موجودی‌ها رو حذف کن.`)
  }
  if (warehouse._count.orderItems > 0) {
    throw new Error('نمی‌شه این انبار رو حذف کرد — سابقه‌ی سفارش داره که باید برای مستندات مالی نگه داشته بشه.')
  }

  await prisma.warehouse.delete({ where: { id } })
  await logAudit('warehouses', `انبار «${warehouse.name}» حذف شد`, actorId, { warehouseId: id })
}
