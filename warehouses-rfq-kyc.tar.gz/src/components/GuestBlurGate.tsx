import Link from 'next/link'
import { colors, radius, fontSize, spacing, shadow } from '@/lib/styles/tokens'

/**
 * گیت مهمان با blur — وقتی کاربر لاگین نیست، محتوا رو با blur(8px) می‌پوشونه و
 * یه overlay «برای مشاهده وارد شوید یا ثبت‌نام کنید» + دکمه‌های ورود/ثبت‌نام روش می‌ذاره.
 * لاگین‌شده: children بی‌تغییر برمی‌گرده.
 *
 * الگوی blur از transport/page.tsx گرفته شده. دو مصرف‌کننده: صفحه‌ی موجودی انبار و /rfq-public.
 */
export default function GuestBlurGate({
  isLoggedIn,
  children,
}: {
  isLoggedIn: boolean
  children: React.ReactNode
}) {
  if (isLoggedIn) return <>{children}</>

  return (
    <div style={{ position: 'relative', width: '100%' }}>
      <div
        style={{
          filter: 'blur(8px)',
          pointerEvents: 'none',
          userSelect: 'none',
        }}
        aria-hidden
      >
        {children}
      </div>
      <div style={overlayStyle}>
        <div style={cardStyle}>
          <div style={{ fontSize: fontSize.lg, fontWeight: 800, color: colors.textPrimary, marginBottom: spacing.sm }}>
            برای مشاهده وارد شوید یا ثبت‌نام کنید
          </div>
          <div style={{ fontSize: fontSize.md, color: colors.textSecondary, lineHeight: 1.7, marginBottom: spacing.lg }}>
            جزئیات موجودی، قیمت و بسته‌بندی فقط برای کاربران واردشده نمایش داده می‌شود.
          </div>
          <div style={{ display: 'flex', gap: spacing.md, justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link href="/login" style={primaryBtnStyle}>ورود</Link>
            <Link href="/signup" style={secondaryBtnStyle}>ثبت‌نام</Link>
          </div>
        </div>
      </div>
    </div>
  )
}

const overlayStyle: React.CSSProperties = {
  position: 'absolute',
  inset: 0,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  padding: spacing.xl,
}
const cardStyle: React.CSSProperties = {
  background: colors.bgCard,
  border: `1px solid ${colors.borderStrong}`,
  borderRadius: radius.lg,
  boxShadow: shadow.card,
  padding: `${spacing.xl}px ${spacing.xxl}px`,
  textAlign: 'center',
  maxWidth: 420,
}
const primaryBtnStyle: React.CSSProperties = {
  background: colors.navy,
  color: '#fff',
  border: 'none',
  borderRadius: radius.md,
  padding: '10px 28px',
  fontSize: fontSize.base,
  fontWeight: 700,
  textDecoration: 'none',
  display: 'inline-block',
}
const secondaryBtnStyle: React.CSSProperties = {
  background: colors.bgCard,
  color: colors.navy,
  border: `1px solid ${colors.navy}`,
  borderRadius: radius.md,
  padding: '10px 28px',
  fontSize: fontSize.base,
  fontWeight: 700,
  textDecoration: 'none',
  display: 'inline-block',
}
