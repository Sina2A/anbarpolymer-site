import CurrencyTicker from '@/components/CurrencyTicker'
import PublicHeader from '@/components/PublicHeader'
import { submitContactAction } from './actions'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { pageWrapStyle, inputStyle as sharedInputStyle, badgeStyle } from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

type SearchParams = Promise<Record<string, string | string[] | undefined>>

function one(v: string | string[] | undefined): string | undefined {
  if (Array.isArray(v)) return v[0]
  return v
}

export default async function ContactPage({ searchParams }: { searchParams: SearchParams }) {
  const sp = await searchParams
  const justSent = one(sp.sent) === '1'

  return (
    <div style={pageStyle}>
      <CurrencyTicker />
      <PublicHeader activePage="/contact" isLoggedIn={!!user} />

      <main style={mainStyle}>
        <div style={heroStyle}>
          <h1 style={heroTitle}>تماس با ما</h1>
          <p style={heroSub}>
            سوالی درباره‌ی مواد اولیه، قیمت یا همکاری داری؟ فرم زیر رو پر کن — همکاران ما پیامت رو می‌بینن و از راهی که گذاشتی جواب می‌دن.
          </p>
        </div>

        {justSent && (
          <div style={successBanner}>
            ✅ پیامت رسید. ممنون! در صورت نیاز از راهی که گذاشتی باهات تماس می‌گیریم.
          </div>
        )}

        <section style={formCardStyle}>
          <form action={submitContactAction}>
            <div style={{ marginBottom: 14 }}>
              <div style={labelStyle}>نام و نام خانوادگی</div>
              <input name="name" required maxLength={80} placeholder="مثلاً: علی رضایی"
                style={inputStyle} />
            </div>
            <div style={{ marginBottom: 14 }}>
              <div style={labelStyle}>راه تماس <span style={hintInline}>(ایمیل یا شماره موبایل)</span></div>
              <input name="contact" required maxLength={120} placeholder="example@mail.com یا 09121234567"
                style={{ ...inputStyle, direction: 'ltr', textAlign: 'left' }} />
            </div>
            <div style={{ marginBottom: 16 }}>
              <div style={labelStyle}>متن پیام</div>
              <textarea name="body" rows={6} required maxLength={2000} placeholder="سوال یا پیامت رو اینجا بنویس…"
                style={{ ...inputStyle, resize: 'vertical' }} />
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
              <span style={hintStyle}>نیازی به ثبت‌نام نیست — پیامت مستقیم به تیم ما می‌رسه.</span>
              <button type="submit" style={submitBtnStyle}>ارسال پیام</button>
            </div>
          </form>
        </section>
      </main>

      {/* فوتر */}
      <footer style={footerStyle}>
        <div style={footerInner}>
          <span>© {new Date().getFullYear()} انبار پلیمر — تمامی حقوق محفوظ است.</span>
          <span style={footerLinks}>
            <a href="/" style={footerLink}>خانه</a>
            <span style={dot}>•</span>
            <a href="/market" style={footerLink}>بازار</a>
            <span style={dot}>•</span>
            <a href="/login" style={footerLink}>ورود</a>
          </span>
        </div>
      </footer>
    </div>
  )
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: colors.bgPage,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
  display: 'flex',
  flexDirection: 'column',
}
const mainStyle: React.CSSProperties = {
  ...pageWrapStyle,
  padding: '32px 24px',
  flex: 1,
  boxSizing: 'border-box',
}
const heroStyle: React.CSSProperties = {
  marginBottom: 28,
}
const heroTitle: React.CSSProperties = {
  fontSize: fontSize.xl,
  fontWeight: 800,
  color: colors.textPrimary,
  marginBottom: spacing.sm,
}
const heroSub: React.CSSProperties = {
  fontSize: fontSize.base,
  color: colors.textSecondary,
  lineHeight: 1.7,
}
const successBanner: React.CSSProperties = {
  ...badgeStyle('success'),
  borderRadius: radius.md,
  padding: '12px 16px',
  fontSize: fontSize.base,
  fontWeight: 600,
  marginBottom: 18,
}
const formCardStyle: React.CSSProperties = {
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
  padding: spacing.xl,
  background: colors.bgCard,
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
  maxWidth: 640,
}
const labelStyle: React.CSSProperties = {
  fontSize: fontSize.sm,
  fontWeight: 700,
  color: colors.neutralText,
  marginBottom: 5,
}
const hintInline: React.CSSProperties = {
  fontWeight: 400,
  color: colors.textMuted,
  fontSize: fontSize.xs,
}
const inputStyle: React.CSSProperties = {
  ...sharedInputStyle,
  width: '100%',
  boxSizing: 'border-box',
}
const hintStyle: React.CSSProperties = {
  fontSize: fontSize.xs,
  color: colors.textMuted,
}
const submitBtnStyle: React.CSSProperties = {
  background: colors.navy,
  color: '#fff',
  border: 'none',
  borderRadius: radius.md,
  padding: '10px 28px',
  fontSize: fontSize.base,
  fontWeight: 700,
  cursor: 'pointer',
  fontFamily: 'inherit',
}
const footerStyle: React.CSSProperties = {
  background: colors.bgCard,
  borderTop: `1px solid ${colors.borderSubtle}`,
  padding: `${spacing.lg}px ${spacing.xl}px`,
  marginTop: 40,
}
const footerInner: React.CSSProperties = {
  maxWidth: 1100,
  margin: '0 auto',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  gap: spacing.md,
  flexWrap: 'wrap',
  fontSize: fontSize.xs,
  color: colors.textMuted,
}
const footerLinks: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: spacing.sm,
}
const footerLink: React.CSSProperties = {
  color: colors.neutralText,
  textDecoration: 'none',
  fontWeight: 600,
}
const dot: React.CSSProperties = {
  color: colors.borderSubtle,
}
