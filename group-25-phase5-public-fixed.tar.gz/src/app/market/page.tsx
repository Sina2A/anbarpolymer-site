import prisma from '@/lib/prisma'
import { getCurrentUserOrNull } from '@/lib/currentUser'
import ListingDetailModal from '@/components/ListingDetailModal'
import CurrencyTicker from '@/components/CurrencyTicker'
import PublicHeader from '@/components/PublicHeader'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { cardStyle as sharedCardStyle, badgeStyle, inputStyle as sharedInputStyle, selectStyle as sharedSelectStyle, emptyStateStyle } from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

const POLYMER_FAMILY_OPTIONS = ['PP', 'HDPE', 'LDPE', 'LLDPE', 'PVC', 'PET', 'PS', 'EPS', 'ABS', 'سایر']

function one(v: string | string[] | undefined): string | undefined {
  if (Array.isArray(v)) return v[0]
  return v
}

export default async function MarketPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>
}) {
  const sp = await searchParams
  const q = one(sp.q)?.trim() || ''
  const family = one(sp.family)?.trim() || ''
  const category = one(sp.category)?.trim() || ''
  const applicationType = one(sp.applicationType)?.trim() || ''
  const producer = one(sp.producer)?.trim() || ''
  const province = one(sp.province)?.trim() || ''
  // بازار دوطرفه: تب «عرضه» (آگهی فروشنده‌ها) و تب «تقاضا» (درخواست خرید خریدارها)
  const view = one(sp.view)?.trim() === 'demand' ? 'demand' : 'supply'

  // ── Check auth/KYC level ──
  const user = await getCurrentUserOrNull()
  let kycLevel = 0
  if (user) {
    const comp = await prisma.company.findUnique({
      where: { userId: user.id },
      select: { kyc: { select: { level: true } } },
    })
    kycLevel = comp?.kyc?.level ?? 0
  }

  // ── Build where ──
  const where: Record<string, unknown> = { validityStatus: 'active' }

  if (q) {
    ;(where as any).OR = [
      { grade: { code: { contains: q, mode: 'insensitive' } } },
      { grade: { producer: { contains: q, mode: 'insensitive' } } },
      { grade: { category: { contains: q, mode: 'insensitive' } } },
    ]
  }
  if (family) where.grade = { ...((where.grade as any) || {}), polymerFamily: family }
  if (category) where.grade = { ...((where.grade as any) || {}), category }
  if (applicationType) where.grade = { ...((where.grade as any) || {}), applicationType }
  if (producer) where.grade = { ...((where.grade as any) || {}), producer }
  if (province) where.province = province

  // ── Query ──
  // NOTE: do NOT include `user` here — the full listing is passed to the
  // <ListingDetailModal> client component and would serialize User.passwordHash
  // (and phone/email) into the public page payload. The modal never uses it.
  const listings = await prisma.materialListing.findMany({
    where: where as any,
    include: { grade: true },
    orderBy: { createdAt: 'desc' },
  })

  // ── Filter options ──
  const [allCategories, allApplicationTypes, allProducers, allProvinces] = await Promise.all([
    prisma.grade.findMany({
      where: { isActive: true },
      distinct: ['category'],
      select: { category: true },
      orderBy: { category: 'asc' },
    }),
    prisma.grade.findMany({
      where: { isActive: true, applicationType: { not: null } },
      distinct: ['applicationType'],
      select: { applicationType: true },
      orderBy: { applicationType: 'asc' },
    }),
    prisma.grade.findMany({
      where: { isActive: true },
      distinct: ['producer'],
      select: { producer: true },
      orderBy: { producer: 'asc' },
    }),
    prisma.materialListing.findMany({
      where: { validityStatus: 'active' },
      distinct: ['province'],
      select: { province: true },
      orderBy: { province: 'asc' },
    }),
  ])

  const categories = allCategories.map((r) => r.category)
  const applicationTypes = allApplicationTypes.map((r) => r.applicationType).filter((v): v is string => !!v)
  const producers = allProducers.map((r) => r.producer)
  const provinces = allProvinces.map((r) => r.province)

  // ── تب تقاضا: درخواست‌های خرید باز ──
  // شمارش همیشه اجرا می‌شه (عددِ روی تب)، لیست کامل فقط وقتی تب تقاضا فعاله.
  // «باز» یعنی status=open و منقضی‌نشده — انقضا تنبل حساب می‌شه، مثل
  // /purchase-requests. درخواست با ساخته‌شدن آگهی بسته نمی‌شه، پس چند
  // فروشنده می‌تونن روی یک درخواست رقابت کنن.
  // نکته‌ی امنیتی: include: { user } ممنوعه — این صفحه عمومیه و User شامل
  // passwordHash/phone/email می‌شه؛ همون قاعده‌ی کوئری آگهی‌ها.
  const openRequestWhere = {
    status: 'open',
    OR: [{ expiresAt: null }, { expiresAt: { gte: new Date() } }],
  }
  const demandCount = await prisma.purchaseRequest.count({ where: openRequestWhere })
  const demandRequests =
    view === 'demand'
      ? await prisma.purchaseRequest.findMany({
          where: openRequestWhere,
          orderBy: { createdAt: 'desc' },
          include: {
            grade: { select: { code: true, producer: true, category: true } },
            _count: { select: { listings: true } },
          },
        })
      : []

  return (
    <>
      <CurrencyTicker />
      <style>{`
        .market-table tbody tr:hover {
          background: ${colors.bgHover};
        }
      `}</style>
      <PublicHeader activePage="/market" isLoggedIn={!!user} />

      <section>
        <div className="wrap">
          <div className="eyebrow">خرید و فروش مواد اولیه</div>
          <div className="sec-title">بازار صنعتی پلیمر</div>
          <div className="sec-sub" style={{ marginBottom: spacing.lg }}>
            {view === 'supply' ? (
              <>
                آگهی‌های فروش مواد اولیه پلیمری از تولیدکنندگان و فروشندگان سراسر کشور —{' '}
                <b style={{ color: colors.orange }}>{listings.length} آگهی فعال</b>
              </>
            ) : (
              <>
                نیازِ خریدها که خریدارها اعلام کرده‌ن — اگه بار داری، می‌تونی روی همون‌جا آگهی بذاری —{' '}
                <b style={{ color: colors.orange }}>{demandRequests.length} درخواست باز</b>
              </>
            )}
          </div>

          {/* ── تب‌های بازار دوطرفه ── */}
          <div style={tabRowStyle}>
            <a href="/market" style={view === 'supply' ? tabActiveStyle : tabStyle}>
              عرضه‌ی فروشنده‌ها ({listings.length})
            </a>
            <a href="/market?view=demand" style={view === 'demand' ? tabActiveStyle : tabStyle}>
              تقاضای خریدارها ({demandCount})
            </a>
          </div>

          {/* ── Guest CTA ── */}
          {!user && (
            <div style={guestBanner}>
              برای مشاهده‌ی جزئیات کامل، قیمت و خرید،{' '}
              <a href="/signup" style={{ color: colors.orange, fontWeight: 700, textDecoration: 'underline' }}>
                عضو شوید ←
              </a>
            </div>
          )}

          {view === 'supply' ? (
            <>
              {/* ── Filters ── */}
              <form method="GET" action="/market" style={filterFormStyle}>
                <input
                  name="q"
                  defaultValue={q}
                  placeholder="جستجو: کد گرید، تولیدکننده، دسته…"
                  style={inputStyle}
                />

                {/* Quick chips */}
                <div style={chipRow}>
                  {POLYMER_FAMILY_OPTIONS.map((f) => (
                    <a
                      key={f}
                      href={`/market?family=${encodeURIComponent(f)}`}
                      style={{
                        ...chipStyle,
                        background: family === f ? colors.warningBg : colors.neutralBg,
                        color: family === f ? colors.orange : colors.neutralText,
                        fontWeight: family === f ? 700 : 400,
                      }}
                    >
                      {f}
                    </a>
                  ))}
                </div>

                <select name="category" defaultValue={category} style={selectStyle}>
                  <option value="">همه‌ی دسته‌ها</option>
                  {categories.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
                <select name="applicationType" defaultValue={applicationType} style={selectStyle}>
                  <option value="">همه‌ی کاربردها</option>
                  {applicationTypes.map((a) => (
                    <option key={a} value={a}>
                      {a}
                    </option>
                  ))}
                </select>
                <select name="producer" defaultValue={producer} style={selectStyle}>
                  <option value="">همه‌ی تولیدکنندگان</option>
                  {producers.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
                <select name="province" defaultValue={province} style={selectStyle}>
                  <option value="">همه‌ی استان‌ها</option>
                  {provinces.map((pr) => (
                    <option key={pr} value={pr}>
                      {pr}
                    </option>
                  ))}
                </select>
                <button type="submit" className="btn btn-sm" style={{ whiteSpace: 'nowrap' }}>
                  اعمال فیلتر
                </button>
                {(q || family || category || applicationType || producer || province) && (
                  <a href="/market" className="btn btn-sm btn-outline" style={{ whiteSpace: 'nowrap' }}>
                    پاک کردن
                  </a>
                )}
              </form>

              {/* ── Table ── */}
              {listings.length === 0 ? (
                <div style={emptyStyle}>هیچ آگهی فعالی با این فیلتر یافت نشد.</div>
              ) : (
                <div style={tableWrap}>
                  <table style={tableStyle} className="market-table">
                    <thead>
                      <tr>
                        <th>تاریخ ثبت</th>
                        <th>نوع ماده</th>
                        <th>تولیدکننده</th>
                        <th>کد گرید</th>
                        <th>MFI</th>
                        <th>کاربرد</th>
                        <th>مقدار</th>
                        <th>قیمت</th>
                        <th>وضعیت</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      {listings.map((listing) => (
                        <ListingDetailModal key={listing.id} listing={listing} kycLevel={kycLevel} isGuest={!user} />
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </>
          ) : (
            <>
              {/* ── تقاضای خریدارها: درخواست‌های باز — سقف قیمت عمومیه ── */}
              {demandRequests.length === 0 ? (
                <div style={emptyStyle}>در حال حاضر هیچ درخواست خرید بازی ثبت نشده.</div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  {demandRequests.map((req) => (
                    <div key={req.id} style={demandCardStyle}>
                      <div style={demandHeadStyle}>
                        <div>
                          <span style={{ fontSize: fontSize.md, fontWeight: 800 }}>{req.grade.code}</span>{' '}
                          <span style={{ fontSize: fontSize.xs, color: colors.textMuted }}>
                            {req.grade.producer} ({req.grade.category})
                          </span>
                        </div>
                        <span style={openTagStyle}>باز</span>
                      </div>

                      <div style={demandGridStyle}>
                        <div>
                          <div style={demandLabelStyle}>مقدار درخواستی</div>
                          <div style={{ fontSize: fontSize.sm, fontWeight: 700 }}>{req.quantityTon} تن</div>
                        </div>
                        <div>
                          <div style={demandLabelStyle}>سقف قیمت خریدار</div>
                          <div style={{ fontSize: fontSize.sm, fontWeight: 700, color: colors.orange }}>
                            {req.maxPriceToman
                              ? `${req.maxPriceToman.toLocaleString('fa-IR')} تومان/کیلو`
                              : 'اعلام نشده'}
                          </div>
                        </div>
                        <div>
                          <div style={demandLabelStyle}>استان تحویل</div>
                          <div style={{ fontSize: fontSize.sm, fontWeight: 600 }}>{req.province || 'مهم نیست'}</div>
                        </div>
                        <div>
                          <div style={demandLabelStyle}>آگهی‌های ثبت‌شده</div>
                          <div style={{ fontSize: fontSize.sm, fontWeight: 600 }}>{req._count.listings} آگهی</div>
                        </div>
                      </div>

                      {req.description && (
                        <div style={{ fontSize: fontSize.sm, color: colors.neutralText, lineHeight: 1.8, marginBottom: 10 }}>
                          {req.description}
                        </div>
                      )}

                      <div style={demandFootStyle}>
                        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
                          <span>ثبت: {new Date(req.createdAt).toLocaleDateString('fa-IR')}</span>
                          {req.expiresAt && (
                            <>
                              <span>•</span>
                              <span>اعتبار تا: {new Date(req.expiresAt).toLocaleDateString('fa-IR')}</span>
                            </>
                          )}
                          <span>•</span>
                          <span style={{ fontFamily: 'monospace', direction: 'ltr' }}>#{req.id.slice(0, 8)}</span>
                        </div>
                        {user ? (
                          <a href={`/new-listing?request=${req.id}`} style={respondBtnStyle}>
                            ثبت آگهی در پاسخ
                          </a>
                        ) : (
                          <a href="/login" style={respondBtnStyle}>
                            ورود برای پاسخ
                          </a>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </section>

      <footer style={footerStyle}>
        <div style={footerInner}>
          <span>© {new Date().getFullYear()} انبار پلیمر — تمامی حقوق محفوظ است.</span>
          <span style={footerLinks}>
            <a href="/" style={footerLink}>خانه</a>
            <span style={dot}>•</span>
            <a href="/market" style={footerLink}>بازار</a>
            <span style={dot}>•</span>
            <a href="/login" style={footerLink}>ورود</a>
          </span>
        </div>
      </footer>
    </>
  )
}

// ── Styles ──
const guestBanner: React.CSSProperties = {
  background: colors.warningBg,
  color: colors.warningText,
  borderRadius: radius.md,
  padding: '10px 16px',
  fontSize: fontSize.base,
  fontWeight: 600,
  marginBottom: 20,
  textAlign: 'center',
}
const filterFormStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: spacing.md,
  marginBottom: 20,
  padding: spacing.md,
  background: colors.bgHover,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
}
const inputStyle: React.CSSProperties = {
  ...sharedInputStyle,
}
const chipRow: React.CSSProperties = {
  display: 'flex',
  flexWrap: 'wrap',
  gap: 6,
}
const chipStyle: React.CSSProperties = {
  fontSize: fontSize.xs,
  borderRadius: 20,
  padding: '4px 12px',
  textDecoration: 'none',
  transition: 'background .15s',
  cursor: 'pointer',
}
const selectStyle: React.CSSProperties = {
  ...sharedSelectStyle,
  minWidth: 140,
}
const emptyStyle: React.CSSProperties = {
  ...emptyStateStyle,
  padding: 40,
  border: `1px dashed ${colors.borderStrong}`,
  borderRadius: radius.lg,
}
const tableWrap: React.CSSProperties = {
  overflowX: 'auto',
  borderRadius: radius.lg,
  border: `1px solid ${colors.borderStrong}`,
  background: colors.bgCard,
}
const tableStyle: React.CSSProperties = {
  width: '100%',
  borderCollapse: 'collapse',
  fontSize: fontSize.sm,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const tabRowStyle: React.CSSProperties = {
  display: 'flex',
  gap: spacing.sm,
  marginBottom: 20,
  borderBottom: `2px solid ${colors.borderSubtle}`,
}
const tabStyle: React.CSSProperties = {
  padding: '10px 18px',
  fontSize: fontSize.base,
  fontWeight: 600,
  color: colors.textMuted,
  textDecoration: 'none',
  borderBottom: '2px solid transparent',
  marginBottom: -2,
  cursor: 'pointer',
}
const tabActiveStyle: React.CSSProperties = {
  ...tabStyle,
  color: colors.navy,
  fontWeight: 800,
  borderBottom: `2px solid ${colors.navy}`,
}
const demandCardStyle: React.CSSProperties = {
  ...sharedCardStyle,
  padding: 18,
  marginBottom: 0,
}
const demandHeadStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: spacing.md,
}
const openTagStyle: React.CSSProperties = {
  ...badgeStyle('success'),
  fontWeight: 700,
}
const demandGridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))',
  gap: 14,
  marginBottom: spacing.md,
}
const demandLabelStyle: React.CSSProperties = {
  fontSize: fontSize.xs,
  color: colors.textMuted,
  marginBottom: 3,
}
const demandFootStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  flexWrap: 'wrap',
  gap: 10,
  borderTop: `1px solid ${colors.borderSubtle}`,
  paddingTop: spacing.md,
  fontSize: fontSize.xs,
  color: colors.textMuted,
}
const respondBtnStyle: React.CSSProperties = {
  background: colors.navy,
  color: '#fff',
  borderRadius: radius.md,
  padding: '8px 16px',
  fontSize: fontSize.sm,
  fontWeight: 700,
  textDecoration: 'none',
  whiteSpace: 'nowrap',
}
const footerStyle: React.CSSProperties = {
  background: colors.bgCard,
  borderTop: `1px solid ${colors.borderSubtle}`,
  padding: `${spacing.lg}px ${spacing.xl}px`,
  marginTop: 40,
}
const footerInner: React.CSSProperties = {
  maxWidth: 1100,
  margin: '0 auto',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  gap: spacing.md,
  flexWrap: 'wrap',
  fontSize: fontSize.xs,
  color: colors.textMuted,
}
const footerLinks: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: spacing.sm,
}
const footerLink: React.CSSProperties = {
  color: colors.neutralText,
  textDecoration: 'none',
  fontWeight: 600,
}
const dot: React.CSSProperties = {
  color: colors.borderSubtle,
}
