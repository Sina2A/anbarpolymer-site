export default function TransportPanelFooter() {
  return (
    <footer className="transport-panel-footer">
      <div className="transport-panel-footer-logo-space" aria-hidden="true" />
      <p>© تمامی حقوق برای انبار پلیمر محفوظ است.</p>
      <a href="tel:+982191234567">پشتیبانی: ۰۲۱-۹۱۲۳۴۵۶۷</a>
    </footer>
  )
}
