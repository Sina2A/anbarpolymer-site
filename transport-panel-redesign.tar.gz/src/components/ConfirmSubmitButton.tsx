'use client'

export default function ConfirmSubmitButton({
  message,
  children,
  style,
  className,
}: {
  message: string
  children: React.ReactNode
  style?: React.CSSProperties
  className?: string
}) {
  return (
    <button
      type="submit"
      style={style}
      className={className}
      onClick={(e) => {
        if (!confirm(message)) {
          e.preventDefault()
        }
      }}
    >
      {children}
    </button>
  )
}
