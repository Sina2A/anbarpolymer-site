import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { addDriver, toggleDriverActive } from './actions'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'
import { colors } from '@/lib/styles/tokens'

export const dynamic = 'force-dynamic'

const ACTIVE_STATUSES = ['payment_secured', 'loading', 'in_transit']
const DONE_STATUSES = ['delivered', 'settled']

const CARRIER_STATUS: Record<string, { label: string; bg: string; color: string }> = {
  payment_secured: { label: 'در انتظار بارگیری', bg: colors.warningBg, color: colors.warningText },
  loading: { label: 'در حال بارگیری', bg: colors.infoBg, color: colors.infoText },
  in_transit: { label: 'در مسیر', bg: colors.infoBg, color: colors.infoText },
  delivered: { label: 'تحویل‌شده', bg: colors.successBg, color: colors.successText },
  settled: { label: 'تسویه‌شده', bg: colors.successBg, color: colors.successText },
}

function loadingInfo(confs: { type: string; driverName: string | null; vehiclePlate: string | null }[]) {
  const c = confs.find((x) => x.type === 'loading') ?? confs[0]
  return { driverName: c?.driverName || null, plate: c?.vehiclePlate || null }
}

const faDateTime = (d: Date) => new Date(d).toLocaleString('fa-IR', { dateStyle: 'short', timeStyle: 'short' })

export default async function TransportPanelPage() {
  const user = await getCurrentUser()
  const company = await prisma.transportCompany.findUnique({
    where: { managerUserId: user.id },
    include: {
      deals: {
        where: { status: { in: [...ACTIVE_STATUSES, ...DONE_STATUSES] } },
        orderBy: { createdAt: 'desc' },
        take: 60,
        include: {
          materialListing: { include: { grade: true } },
          confirmations: { orderBy: { confirmedAt: 'desc' }, take: 5 },
        },
      },
      drivers: {
        orderBy: { createdAt: 'asc' },
        include: {
          confirmations: {
            orderBy: { confirmedAt: 'desc' },
            take: 10,
            include: { deal: true },
          },
        },
      },
    },
  })

  if (!company) return <AccessCard title="پنل شرکت حمل‌ونقل — دسترسی ندارید">این حساب به هیچ شرکت حمل‌ونقلی وصل نیست. با پشتیبانی انبار پلیمر تماس بگیرید.</AccessCard>
  if (!company.logisticsAccessEnabled) return <AccessCard title="پنل شرکت حمل‌ونقل — دسترسی غیرفعال">دسترسی پنل حمل‌ونقل برای <b>{company.name}</b> در حال حاضر غیرفعاله. برای فعال‌شدن با پشتیبانی انبار پلیمر تماس بگیرید.</AccessCard>

  const activeDeals = company.deals.filter((deal) => ACTIVE_STATUSES.includes(deal.status))
  const doneDeals = company.deals.filter((deal) => DONE_STATUSES.includes(deal.status)).slice(0, 20)

  return (
    <div className="transport-panel-page">
      <div className="transport-panel-page-heading">
        <h1>پیشخوان شرکت حمل‌ونقل</h1>
        <p><b>{company.name}</b> — محموله‌های سپرده‌شده، راننده‌ها و تاریخچه‌ی سفرهای تایید‌شده</p>
      </div>

      <section className="transport-panel-purpose">
        <b>هدف این پنل چیه؟</b>
        <p>
          این پنل مخصوص <b>مدیر شرکت حمل‌ونقل</b>‌ه — بخش داخلی «حمل و نقل» انبار پلیمر جای دیگه‌ایه و به این صفحه ربطی نداره.
          کارش فقط <b>احراز هویت راننده و مسیر طی‌شده</b>‌ست — به‌خاطر حساسیت صنعت مواد اولیه پتروشیمی در ایران.
          انبار پلیمر با رقم دقیق مسافتِ طی‌شده‌ی هیچ راننده‌ای کاری نداره و این داده رو برای ارزیابی عملکرد یا هزینه استفاده نمی‌کنه —
          فقط جهت تایید این‌که سفر واقعاً و توسط همون راننده‌ی ثبت‌شده انجام شده.
        </p>
      </section>

      <section className="transport-panel-section">
        <div className="transport-panel-section-heading"><h2>محموله‌های جاری</h2><span>{activeDeals.length}</span></div>
        {activeDeals.length === 0 && <EmptyState>الان محموله‌ی جاری‌ای به این شرکت سپرده نشده.</EmptyState>}
        <div className="transport-panel-card-list">
          {activeDeals.map((deal) => {
            const status = CARRIER_STATUS[deal.status]
            const { driverName, plate } = loadingInfo(deal.confirmations)
            const gradeCode = deal.materialListing?.grade?.code
            return (
              <article key={deal.id} className="transport-panel-card">
                <div className="transport-panel-card-head">
                  <div><b>محموله</b> <code>#{deal.id.slice(0, 8)}</code>{gradeCode && <span className="transport-panel-grade">{gradeCode}</span>}</div>
                  <StatusBadge status={status} fallback={deal.status} />
                </div>
                <div className="transport-panel-meta-grid">
                  <Meta label="مقدار" value={String(deal.quantity)} />
                  <Meta label="راننده" value={driverName ?? 'ثبت نشده'} />
                  <Meta label="پلاک" value={plate ?? '—'} ltr />
                  <Meta label="آخرین گزارش موقعیت" value={deal.locationUpdatedAt ? faDateTime(deal.locationUpdatedAt) : 'گزارشی ثبت نشده'} />
                </div>
                <div className="transport-panel-freight">
                  <span>کرایه حمل</span>
                  <b>{deal.transportCost != null ? `${deal.transportCost.toLocaleString('fa-IR')} تومان` : '—'}</b>
                  {deal.transportCost != null && <span className={`transport-panel-payment ${deal.transportCostPaid ? 'paid' : ''}`}>{deal.transportCostPaid ? 'پرداخت شده' : 'پرداخت نشده'}</span>}
                </div>
                {deal.driverSilenceFlaggedAt && <div className="transport-panel-alert">از <b>{faDateTime(deal.driverSilenceFlaggedAt)}</b> هیچ گزارشی از راننده‌ی این محموله ثبت نشده — پیگیری کنید.</div>}
              </article>
            )
          })}
        </div>
      </section>

      <section className="transport-panel-section">
        <div className="transport-panel-section-heading"><h2>تاریخچه‌ی محموله‌ها</h2><span>{doneDeals.length}</span></div>
        {doneDeals.length === 0 ? <EmptyState>هنوز محموله‌ی تکمیل‌شده‌ای ثبت نشده.</EmptyState> : (
          <div className="transport-panel-card transport-panel-history-list">
            {doneDeals.map((deal) => {
              const { driverName } = loadingInfo(deal.confirmations)
              return <div key={deal.id}><span><code>#{deal.id.slice(0, 8)}</code> — {deal.materialListing?.grade?.code ?? 'بدون گرید'} — {driverName ?? 'راننده ثبت نشده'}</span><StatusBadge status={CARRIER_STATUS[deal.status]} fallback={deal.status} /></div>
            })}
          </div>
        )}
      </section>

      <section className="transport-panel-section" id="add-driver">
        <div className="transport-panel-section-heading"><h2>افزودن راننده‌ی جدید</h2></div>
        <div className="transport-panel-card">
          <form action={addDriver} className="transport-panel-driver-form">
            <input name="fullName" placeholder="نام و نام خانوادگی" required />
            <input name="phone" placeholder="شماره موبایل" required dir="ltr" />
            <input name="nationalId" placeholder="کد ملی (اختیاری)" dir="ltr" />
            <input name="licenseNumber" placeholder="شماره گواهینامه (اختیاری)" dir="ltr" />
            <button type="submit">افزودن راننده</button>
          </form>
        </div>
      </section>

      <section className="transport-panel-section" id="drivers">
        <div className="transport-panel-section-heading"><h2>راننده‌ها</h2><span>{company.drivers.length}</span></div>
        {company.drivers.length === 0 && <EmptyState>هنوز راننده‌ای ثبت نشده.</EmptyState>}
        <div className="transport-panel-card-list">
          {company.drivers.map((driver) => (
            <article key={driver.id} className="transport-panel-card transport-panel-driver-card">
              <div className="transport-panel-card-head">
                <div><b>{driver.fullName}</b> <span dir="ltr">— {driver.phone}</span></div>
                <form action={toggleDriverActive}>
                  <input type="hidden" name="driverId" value={driver.id} />
                  <input type="hidden" name="value" value={(!driver.isActive).toString()} />
                  <ConfirmSubmitButton message={driver.isActive ? `«${driver.fullName}» غیرفعال بشه؟` : `«${driver.fullName}» دوباره فعال بشه؟`} className={`transport-panel-status-button ${driver.isActive ? 'active' : ''}`}>{driver.isActive ? 'فعال' : 'غیرفعال'}</ConfirmSubmitButton>
                </form>
              </div>
              {driver.confirmations.length > 0 && <div className="transport-panel-trips"><small>آخرین سفرهای تایید‌شده:</small>{driver.confirmations.map((confirmation) => <div key={confirmation.id}><span>{confirmation.type === 'loading' ? 'بارگیری' : 'تخلیه'} — معامله #{confirmation.dealId.slice(0, 8)}</span><time>{new Date(confirmation.confirmedAt).toLocaleDateString('fa-IR')}</time></div>)}</div>}
            </article>
          ))}
        </div>
      </section>
    </div>
  )
}

function AccessCard({ title, children }: { title: string; children: React.ReactNode }) {
  return <div className="transport-panel-page"><div className="transport-panel-access-card"><h1>{title}</h1><p>{children}</p></div></div>
}

function EmptyState({ children }: { children: React.ReactNode }) {
  return <div className="transport-panel-empty">{children}</div>
}

function Meta({ label, value, ltr = false }: { label: string; value: string; ltr?: boolean }) {
  return <div><span>{label}</span><b dir={ltr ? 'ltr' : undefined}>{value}</b></div>
}

function StatusBadge({ status, fallback }: { status?: { label: string; bg: string; color: string }; fallback: string }) {
  return <span className="transport-panel-badge" style={{ background: status?.bg ?? colors.neutralBg, color: status?.color ?? colors.neutralText }}>{status?.label ?? fallback}</span>
}
