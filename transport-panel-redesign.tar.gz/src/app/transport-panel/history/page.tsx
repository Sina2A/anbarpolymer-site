import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'

export const dynamic = 'force-dynamic'

// این مسیر فعلاً فقط اسکلت نمایشی است. اتصال تاریخچه‌ی کامل و صفحه‌بندی
// در مرحله‌ای جدا انجام می‌شود؛ بازطراحی حاضر رفتار داده‌ای را تغییر نمی‌دهد.
const PLACEHOLDER_ROWS = Array.from({ length: 10 }, (_, i) => ({
  n: i + 1,
  v1: `مقدار${i + 1}`,
  v2: `مقدار${i + 1}`,
  v3: `مقدار${i + 1}`,
  v4: `مقدار${i + 1}`,
  v5: `مقدار${i + 1}`,
}))

export default async function TransportHistoryPage() {
  const user = await getCurrentUser()
  const company = await prisma.transportCompany.findUnique({ where: { managerUserId: user.id } })

  if (!company) return <AccessCard title="پنل شرکت حمل‌ونقل — دسترسی ندارید">این حساب به هیچ شرکت حمل‌ونقلی وصل نیست. با پشتیبانی انبار پلیمر تماس بگیرید.</AccessCard>
  if (!company.logisticsAccessEnabled) return <AccessCard title="پنل شرکت حمل‌ونقل — دسترسی غیرفعال">دسترسی پنل حمل‌ونقل برای <b>{company.name}</b> در حال حاضر غیرفعاله. برای فعال‌شدن با پشتیبانی انبار پلیمر تماس بگیرید.</AccessCard>

  return (
    <div className="transport-panel-page">
      <div className="transport-panel-page-heading">
        <h1>تاریخچه‌ی محموله‌ها</h1>
        <p><b>{company.name}</b> — تاریخچه‌ی کامل محموله‌های این شرکت حمل‌ونقل</p>
      </div>
      <div className="transport-panel-table-card table-scroll">
        <table>
          <thead><tr><th>ردیف</th><th>متغیر ۱</th><th>متغیر ۲</th><th>متغیر ۳</th><th>متغیر ۴</th><th>متغیر ۵</th></tr></thead>
          <tbody>{PLACEHOLDER_ROWS.map((row) => <tr key={row.n}><td>{row.n}</td><td>{row.v1}</td><td>{row.v2}</td><td>{row.v3}</td><td>{row.v4}</td><td>{row.v5}</td></tr>)}</tbody>
        </table>
      </div>
    </div>
  )
}

function AccessCard({ title, children }: { title: string; children: React.ReactNode }) {
  return <div className="transport-panel-page"><div className="transport-panel-access-card"><h1>{title}</h1><p>{children}</p></div></div>
}
