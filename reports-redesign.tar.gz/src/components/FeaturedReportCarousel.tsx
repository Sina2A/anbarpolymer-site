'use client'

import { useState } from 'react'
import { colors, fontSize, radius } from '@/lib/styles/tokens'

type Article = {
  id: string
  title: string
  publishedAt: Date | null
  author?: { companyName: string } | null
}

type Props = {
  articles: Article[]
}

export default function FeaturedReportCarousel({ articles }: Props) {
  const [currentIndex, setCurrentIndex] = useState(0)

  if (articles.length === 0) return null

  const current = articles[currentIndex]
  const canGoPrev = currentIndex > 0
  const canGoNext = currentIndex < articles.length - 1

  const handlePrev = () => {
    if (canGoPrev) setCurrentIndex(currentIndex - 1)
  }

  const handleNext = () => {
    if (canGoNext) setCurrentIndex(currentIndex + 1)
  }

  const faDate = (d: Date | null) => {
    if (!d) return '—'
    return new Date(d).toLocaleDateString('fa-IR')
  }

  return (
    <div style={wrapperStyle}>
      {articles.length > 1 && (
        <button onClick={handlePrev} disabled={!canGoPrev} style={navBtnStyle(canGoPrev)}>
          →
        </button>
      )}

      <article style={featuredCardStyle}>
        <div style={featuredGridStyle}>
          <div style={featuredCoverStyle}>
            <span style={tagStyle}>گزارش بازار پلیمر</span>
            <div style={dateStyle}>
              {faDate(current.publishedAt)}
              {current.author?.companyName && ` — ${current.author.companyName}`}
            </div>
            <div>
              <div style={briefStyle}>
                Market<br />
                <span style={{ color: colors.orange }}>Brief</span>
              </div>
              <div style={briefSubStyle}>نمای فشرده‌ای از مهم‌ترین سیگنال‌های بازار برای تصمیم‌گیری سریع‌تر.</div>
            </div>
          </div>

          <div style={featuredBodyStyle}>
            <div style={kickerStyle}>
              <span>تحلیل بازار</span>
              <span style={sepStyle}>•</span>
              <span>۸ دقیقه مطالعه</span>
            </div>
            <h3 style={featuredTitleStyle}>{current.title}</h3>
            <a href={`/reports/${current.id}`} style={ctaBtnStyle}>
              مطالعه گزارش ←
            </a>
          </div>
        </div>
      </article>

      {articles.length > 1 && (
        <button onClick={handleNext} disabled={!canGoNext} style={navBtnStyle(canGoNext)}>
          ←
        </button>
      )}
    </div>
  )
}

const wrapperStyle: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 16,
}

const navBtnStyle = (enabled: boolean): React.CSSProperties => ({
  flexShrink: 0,
  width: 40,
  height: 40,
  borderRadius: '50%',
  border: `1px solid ${enabled ? colors.borderStrong : colors.borderSubtle}`,
  background: colors.bgCard,
  color: enabled ? colors.textPrimary : colors.textMuted,
  fontSize: 18,
  cursor: enabled ? 'pointer' : 'not-allowed',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  opacity: enabled ? 1 : 0.5,
})

const featuredCardStyle: React.CSSProperties = {
  borderRadius: 22,
  overflow: 'hidden',
  border: `1px solid ${colors.borderSubtle}`,
  background: colors.bgCard,
  boxShadow: '0 4px 20px rgba(23,32,51,.05)',
  flex: 1,
}

const featuredGridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: '1.05fr .95fr',
}

const featuredCoverStyle: React.CSSProperties = {
  background: '#162a5e',
  backgroundImage: `
    linear-gradient(rgba(255,255,255,.06) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255,255,255,.06) 1px, transparent 1px)
  `,
  backgroundSize: '26px 26px',
  padding: '48px 44px',
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'space-between',
  minHeight: 340,
  position: 'relative',
  overflow: 'hidden',
}

const tagStyle: React.CSSProperties = {
  display: 'inline-block',
  background: 'rgba(255,255,255,.1)',
  border: '1px solid rgba(255,255,255,.18)',
  color: 'rgba(255,255,255,.85)',
  fontSize: 11.5,
  padding: '6px 12px',
  borderRadius: 999,
  position: 'relative',
}

const dateStyle: React.CSSProperties = {
  marginTop: 28,
  color: 'rgba(255,255,255,.5)',
  fontSize: 12,
  position: 'relative',
}

const briefStyle: React.CSSProperties = {
  fontSize: 'clamp(32px,4vw,52px)',
  fontWeight: 900,
  color: 'rgba(255,255,255,.95)',
  lineHeight: 1.1,
  position: 'relative',
}

const briefSubStyle: React.CSSProperties = {
  marginTop: 14,
  maxWidth: 320,
  fontSize: 13.5,
  lineHeight: 1.8,
  color: 'rgba(255,255,255,.6)',
  position: 'relative',
}

const featuredBodyStyle: React.CSSProperties = {
  padding: '40px 44px',
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
}

const kickerStyle: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 8,
  color: colors.orange,
  fontSize: 12.5,
  fontWeight: 700,
}

const sepStyle: React.CSSProperties = {
  color: colors.orange,
}

const featuredTitleStyle: React.CSSProperties = {
  marginTop: 14,
  fontSize: 'clamp(20px,2.4vw,27px)',
  fontWeight: 800,
  lineHeight: 1.5,
}

const ctaBtnStyle: React.CSSProperties = {
  marginTop: 24,
  display: 'inline-flex',
  alignItems: 'center',
  gap: 8,
  background: colors.orange,
  color: '#fff',
  fontWeight: 700,
  fontSize: 14,
  borderRadius: 12,
  padding: '13px 22px',
  width: 'fit-content',
  transition: '.2s',
  textDecoration: 'none',
}
