'use client'

import { useState } from 'react'

export default function CopyLinkButton() {
  const [copied, setCopied] = useState(false)

  const handleCopy = () => {
    if (typeof window !== 'undefined') {
      navigator.clipboard.writeText(window.location.href)
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    }
  }

  return (
    <button onClick={handleCopy} style={btnStyle}>
      {copied ? 'کپی شد ✓' : 'کپی لینک'}
    </button>
  )
}

const btnStyle: React.CSSProperties = {
  border: '1px solid #ddd0ba', // colors.border
  background: '#faf7f1', // colors.bg
  borderRadius: 8,
  padding: '7px 12px',
  fontSize: 12,
  cursor: 'pointer',
  color: '#83765f', // colors.textMuted
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
}
