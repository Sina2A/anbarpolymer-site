'use client'

import { useState } from 'react'
import { colors, fontSize, radius } from '@/lib/styles/tokens'

type Article = {
  id: string
  title: string
}

type Props = {
  articles: Article[]
}

export default function ReportsSearchBar({ articles }: Props) {
  const [searchQuery, setSearchQuery] = useState('')

  const filteredArticles = articles.filter((a) =>
    a.title.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div style={containerStyle}>
      <div style={searchBoxWrapperStyle}>
        <input
          type="search"
          placeholder="جست‌وجو در گزارش‌ها..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          style={searchInputStyle}
        />
      </div>
      <div style={resultCountStyle}>
        {searchQuery ? `${filteredArticles.length} گزارش` : `${articles.length} گزارش`}
      </div>
    </div>
  )
}

const containerStyle: React.CSSProperties = {
  marginTop: 36,
  background: colors.bgCard,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: 16,
  padding: 14,
  display: 'flex',
  gap: 12,
  alignItems: 'center',
  boxShadow: '0 2px 8px rgba(23,32,51,.04)',
}

const searchBoxWrapperStyle: React.CSSProperties = {
  flex: 1,
  minWidth: 220,
  position: 'relative',
}

const searchInputStyle: React.CSSProperties = {
  width: '100%',
  border: 0,
  background: colors.bgPage,
  borderRadius: 10,
  padding: '13px 16px',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  fontSize: 14,
  outline: 'none',
}

const resultCountStyle: React.CSSProperties = {
  fontSize: fontSize.sm,
  color: colors.textMuted,
  whiteSpace: 'nowrap',
}
