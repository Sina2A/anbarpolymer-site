'use client'

import { useEffect, useState } from 'react'
import { colors, fontSize, radius } from '@/lib/styles/tokens'

type Heading = { id: string; text: string; level: 2 | 3 }

type Props = {
  headings: Heading[]
}

export default function ArticleTOC({ headings }: Props) {
  const [activeId, setActiveId] = useState<string>('')

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveId(entry.target.id)
          }
        })
      },
      { rootMargin: '-100px 0px -80% 0px' }
    )

    const headingElements = headings.map((h) => document.getElementById(h.id)).filter(Boolean)
    headingElements.forEach((el) => el && observer.observe(el))

    return () => observer.disconnect()
  }, [headings])

  if (headings.length === 0) return null

  return (
    <div style={tocCardStyle}>
      <h6 style={tocTitleStyle}>فهرست مطالب</h6>
      {headings.map((h) => (
        <a
          key={h.id}
          href={`#${h.id}`}
          style={{
            ...tocLinkStyle,
            paddingRight: h.level === 3 ? 20 : 10,
            ...(activeId === h.id ? activeLinkStyle : {}),
          }}
        >
          {h.text}
        </a>
      ))}
    </div>
  )
}

const tocCardStyle: React.CSSProperties = {
  border: `1px solid ${colors.borderSubtle}`,
  background: colors.bgCard,
  borderRadius: radius.lg,
  padding: 20,
  position: 'sticky',
  top: 24,
  boxShadow: '0 3px 14px rgba(23,32,51,.04)',
}

const tocTitleStyle: React.CSSProperties = {
  margin: '0 0 12px',
  fontSize: 12,
  fontWeight: 700,
  color: colors.textMuted,
}

const tocLinkStyle: React.CSSProperties = {
  display: 'block',
  color: colors.textSecondary,
  fontSize: 13.5,
  lineHeight: 1.9,
  padding: '6px 0',
  borderRight: '2px solid transparent',
  transition: '.15s',
  textDecoration: 'none',
}

const activeLinkStyle: React.CSSProperties = {
  color: colors.navy,
  borderRightColor: colors.orange,
  fontWeight: 700,
}
