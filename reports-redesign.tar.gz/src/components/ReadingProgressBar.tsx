'use client'

import { useEffect, useState } from 'react'

export default function ReadingProgressBar() {
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    const updateProgress = () => {
      const scrollTop = window.scrollY
      const docHeight = document.documentElement.scrollHeight - window.innerHeight
      const scrollPercent = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0
      setProgress(scrollPercent)
    }

    window.addEventListener('scroll', updateProgress)
    updateProgress() // Initial calculation

    return () => window.removeEventListener('scroll', updateProgress)
  }, [])

  return (
    <div style={progressBarContainerStyle}>
      <div style={{ ...progressBarFillStyle, width: `${progress}%` }} />
    </div>
  )
}

const progressBarContainerStyle: React.CSSProperties = {
  position: 'fixed',
  top: 0,
  left: 0,
  right: 0,
  height: 3,
  zIndex: 10000,
  pointerEvents: 'none',
  background: 'transparent',
}

const progressBarFillStyle: React.CSSProperties = {
  height: '100%',
  background: '#f6621b', // colors.orange
  transition: 'width 0.08s linear',
}
