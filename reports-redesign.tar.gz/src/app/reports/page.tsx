import prisma from '@/lib/prisma'
import { getCurrentUserOrNull } from '@/lib/currentUser'
import CurrencyTicker from '@/components/CurrencyTicker'
import PublicHeader from '@/components/PublicHeader'
import Footer from '@/components/Footer'
import FeaturedReportCarousel from '@/components/FeaturedReportCarousel'
import ReportsSearchBar from '@/components/ReportsSearchBar'

export const dynamic = 'force-dynamic'

type SearchParams = Promise<{ page?: string }>

function faDate(d: Date | null | undefined): string {
  if (!d) return '—'
  return new Date(d).toLocaleDateString('fa-IR')
}

// خلاصه‌ی متن مقاله برای کارت‌ها — ۱۶۰ کاراکتر اول، بدون شکستگی خط
function excerptOf(content: string): string {
  const flat = content.trim().replace(/\s+/g, ' ')
  return flat.length > 160 ? flat.slice(0, 160) + '…' : flat
}

export default async function ReportsPage({ searchParams }: { searchParams: SearchParams }) {
  const user = await getCurrentUserOrNull()
  const now = new Date()
  const page = parseInt((await searchParams).page ?? '1', 10)

  // ── کاروسل: ۳ مقاله جدید ──
  const carouselArticles = await prisma.article.findMany({
    where: { isPublished: true, publishedAt: { not: null, lte: now } },
    include: { author: { select: { companyName: true } } },
    orderBy: { publishedAt: 'desc' },
    take: 3,
  })

  // ── گرید مقالات: صفحه‌بندی (۱۰ تا در هر صفحه، بعد از ۳ تای کاروسل) ──
  const gridArticles = await prisma.article.findMany({
    where: { isPublished: true, publishedAt: { not: null, lte: now } },
    include: { author: { select: { companyName: true } } },
    orderBy: { publishedAt: 'desc' },
    skip: 3 + (page - 1) * 10,
    take: 10,
  })

  const totalCount = await prisma.article.count({
    where: { isPublished: true, publishedAt: { not: null, lte: now } },
  })
  const totalPages = Math.max(1, Math.ceil((totalCount - 3) / 10))

  // ── همه مقالات برای جست‌وجو (فقط id و title) ──
  const allArticles = await prisma.article.findMany({
    where: { isPublished: true, publishedAt: { not: null, lte: now } },
    select: { id: true, title: true },
    orderBy: { publishedAt: 'desc' },
  })

  // ── شاخص‌های بنچمارک — آخرین قیمت دلاری ثبت‌شده برای هر گرید ──
  // GlobalBenchmarkPrice رابطه‌ی Prisma به Grade ندارد؛ کد گرید جداگانه خوانده می‌شود.
  const rawBenchmarks = await prisma.globalBenchmarkPrice.findMany({
    orderBy: { effectiveDate: 'desc' },
    take: 80,
  })
  const seenGradeIds = new Set<string>()
  const latestPerGrade: typeof rawBenchmarks = []
  for (const b of rawBenchmarks) {
    if (seenGradeIds.has(b.gradeId)) continue
    seenGradeIds.add(b.gradeId)
    latestPerGrade.push(b)
    if (latestPerGrade.length >= 8) break
  }
  const grades = latestPerGrade.length
    ? await prisma.grade.findMany({
        where: { id: { in: latestPerGrade.map((b) => b.gradeId) } },
        select: { id: true, code: true },
      })
    : []
  const gradeCodeById = new Map(grades.map((g) => [g.id, g.code]))
  const benchmarks: Array<(typeof rawBenchmarks)[number] & { gradeCode: string }> = []
  for (const b of latestPerGrade) {
    const gradeCode = gradeCodeById.get(b.gradeId)
    if (!gradeCode) continue
    benchmarks.push({ ...b, gradeCode })
  }

  return (
    <>
      <CurrencyTicker />
      <PublicHeader activePage="/reports" isLoggedIn={!!user} />

      <section style={sectionStyle}>
        <div className="wrap">
          <div className="eyebrow">گزارش بازار</div>
          <div className="sec-title">گزارش‌ها و تحلیل‌های بازار پلیمر</div>
          <div className="sec-sub">
            تحلیل قیمت‌ها، شاخص‌های بنچمارک جهانی و اخبار بازار مواد اولیه پلیمری — به‌روزرسانی مستمر توسط تیم کارشناسی انبار پلیمر.
          </div>

          <ReportsSearchBar articles={allArticles} />

          {carouselArticles.length > 0 && (
            <div style={{ marginTop: 36 }}>
              <FeaturedReportCarousel articles={carouselArticles} />
            </div>
          )}
        </div>
      </section>

      <section className="section-line" style={sectionStyle}>
        <div className="wrap">
          <div className="eyebrow">مقالات و اخبار</div>
          <div className="sec-title">جدیدترین گزارش‌ها</div>
          <div className="sec-sub" style={{ marginBottom: 32 }}>
            تحلیل‌ها و اطلاعیه‌های بازار که توسط تیم انبار پلیمر منتشر می‌شوند.
          </div>

          {gridArticles.length === 0 ? (
            <div className="empty-state">
              {page === 1
                ? 'هنوز گزارشی منتشر نشده است — به‌زودی گزارش‌ها و تحلیل‌های بازار پلیمر اینجا منتشر می‌شود.'
                : 'گزارشی در این صفحه وجود ندارد.'}
            </div>
          ) : (
            <>
              <div className="news-grid">
                {gridArticles.map((a) => (
                  <a key={a.id} href={`/reports/${a.id}`} className="news-card">
                    <div className="thumb"></div>
                    <div className="body">
                      <div className="cat">گزارش بازار</div>
                      <h4>{a.title}</h4>
                      <p>{excerptOf(a.content)}</p>
                      <div className="time">
                        {faDate(a.publishedAt)}
                        {a.author?.companyName ? ` — ${a.author.companyName}` : ''}
                      </div>
                    </div>
                  </a>
                ))}
              </div>

              {totalPages > 1 && (
                <div style={paginationStyle}>
                  {page > 1 && (
                    <a href={`/reports?page=${page - 1}`} style={paginationLinkStyle}>
                      ← قبلی
                    </a>
                  )}
                  <div style={paginationInfoStyle}>
                    صفحه {page.toLocaleString('fa-IR')} از {totalPages.toLocaleString('fa-IR')}
                  </div>
                  {page < totalPages && (
                    <a href={`/reports?page=${page + 1}`} style={paginationLinkStyle}>
                      بعدی →
                    </a>
                  )}
                </div>
              )}
            </>
          )}
        </div>
      </section>

      {benchmarks.length > 0 && (
        <section className="section-line" style={sectionStyle}>
          <div className="wrap">
            <div className="eyebrow">شاخص‌های امروز</div>
            <div className="sec-title">آخرین قیمت‌های بنچمارک</div>
            <div className="sec-sub" style={{ marginBottom: 20 }}>
              جدیدترین قیمت دلاری ثبت‌شده برای هر گرید، از منابع مرجع جهانی.
            </div>
            <div className="price-block">
              <h4>قیمت بنچمارک دلاری</h4>
              <div className="hint">صرفاً جهت اطلاع — قیمت معاملاتی نهایی در استعلام قیمت اعلام می‌شود.</div>
              <table>
                <thead>
                  <tr>
                    <th>کد گرید</th>
                    <th>قیمت بنچمارک</th>
                    <th>منبع</th>
                    <th>تاریخ اعتبار</th>
                  </tr>
                </thead>
                <tbody>
                  {benchmarks.map((b) => (
                    <tr key={b.id}>
                      <td>
                        <a href={`/grades/${encodeURIComponent(b.gradeCode)}`} style={gradeCodeStyle}>
                          {b.gradeCode}
                        </a>
                      </td>
                      <td>
                        <span className="num-val" style={priceStyle}>
                          {b.priceUsd.toLocaleString('fa-IR')} دلار
                        </span>
                      </td>
                      <td>{b.sourceLabel ?? '—'}</td>
                      <td>{faDate(b.effectiveDate)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      )}

      <Footer />
    </>
  )
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const sectionStyle: React.CSSProperties = { padding: '56px 0' }
const gradeCodeStyle: React.CSSProperties = {
  fontFamily: 'var(--mono)',
  fontWeight: 600,
  fontSize: 13,
  color: 'var(--ink)',
}
const priceStyle: React.CSSProperties = {
  fontFamily: 'var(--mono)',
  color: 'var(--cyan)',
  fontWeight: 700,
}
const paginationStyle: React.CSSProperties = {
  marginTop: 48,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: 24,
}
const paginationLinkStyle: React.CSSProperties = {
  fontSize: 13,
  fontWeight: 600,
  color: 'var(--cyan)',
  textDecoration: 'none',
}
const paginationInfoStyle: React.CSSProperties = {
  fontSize: 13,
  color: 'var(--ink-mute)',
  fontFamily: 'var(--mono)',
}
