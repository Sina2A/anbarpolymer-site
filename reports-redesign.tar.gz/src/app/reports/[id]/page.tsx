import prisma from '@/lib/prisma'
import { notFound } from 'next/navigation'
import { getCurrentUserOrNull } from '@/lib/currentUser'
import CurrencyTicker from '@/components/CurrencyTicker'
import PublicHeader from '@/components/PublicHeader'
import Footer from '@/components/Footer'
import ReadingProgressBar from '@/components/ReadingProgressBar'
import ArticleTOC from '@/components/ArticleTOC'
import CopyLinkButton from '@/components/CopyLinkButton'

export const dynamic = 'force-dynamic'

type Params = Promise<{ id: string }>

function faDate(d: Date | null | undefined): string {
  if (!d) return '—'
  return new Date(d).toLocaleDateString('fa-IR')
}

// تزریق id به هدینگ‌های h2 و h3 برای TOC
function injectHeadingIds(html: string): string {
  let counter = 0
  return html.replace(/<h([23])>/gi, (match, level) => {
    counter++
    return `<h${level} id="section-${counter}">`
  })
}

// استخراج TOC از HTML با id تزریق‌شده
function extractTOC(html: string): Array<{ id: string; text: string; level: 2 | 3 }> {
  const headings: Array<{ id: string; text: string; level: 2 | 3 }> = []
  const pattern = /<(h[23])[^>]*id="([^"]+)"[^>]*>(.*?)<\/\1>/gi
  let match
  while ((match = pattern.exec(html)) !== null) {
    const level = match[1] === 'h2' ? 2 : 3
    const id = match[2]
    const text = match[3].replace(/<[^>]+>/g, '') // strip inner HTML
    headings.push({ id, text, level })
  }
  return headings
}

export default async function ReportDetailPage({ params }: { params: Params }) {
  const { id } = await params
  const user = await getCurrentUserOrNull()
  const now = new Date()

  const article = await prisma.article.findUnique({
    where: { id },
    include: { author: { select: { companyName: true } } },
  })

  const isPublic =
    !!article && article.isPublished && !!article.publishedAt && article.publishedAt.getTime() <= now.getTime()
  if (!article || !isPublic) notFound()

  // تزریق id و استخراج TOC
  const contentWithIds = injectHeadingIds(article.content)
  const toc = extractTOC(contentWithIds)

  const others = await prisma.article.findMany({
    where: { isPublished: true, publishedAt: { not: null, lte: now }, id: { not: article.id } },
    select: { id: true, title: true, publishedAt: true },
    orderBy: { publishedAt: 'desc' },
    take: 3,
  })

  return (
    <>
      <ReadingProgressBar />
      <CurrencyTicker />
      <PublicHeader activePage="/reports" isLoggedIn={!!user} />

      <section style={sectionStyle}>
        <div className="wrap">
          <a href="/reports" style={backLinkStyle}>
            ← همه‌ی گزارش‌ها
          </a>

          <div style={articleShellStyle}>
            <aside>
              <ArticleTOC headings={toc} />
              <div style={ctaCardStyle}>
                <p style={{ margin: 0, fontSize: 13, lineHeight: 1.8, color: 'rgba(255,255,255,.85)' }}>
                  برای دیدن قیمت لحظه‌ای گریدها و ثبت استعلام، وارد پنل بازرگانی شو.
                </p>
                <a href="/dashboard" style={ctaBtnStyle}>
                  ورود به پیشخوان
                </a>
              </div>
            </aside>

            <article style={articleCardStyle}>
              <div className="eyebrow">گزارش بازار</div>
              <h1 style={titleStyle}>{article.title}</h1>
              <div style={metaRowStyle}>
                <span>{faDate(article.publishedAt)}</span>
                {article.author?.companyName && (
                  <>
                    <span style={dotSepStyle}>•</span>
                    <span>{article.author.companyName}</span>
                  </>
                )}
                <div style={{ marginRight: 'auto', display: 'flex', gap: 8 }}>
                  <CopyLinkButton />
                  <button onClick={() => typeof window !== 'undefined' && window.print()} style={iconBtnStyle}>
                    چاپ
                  </button>
                </div>
              </div>

              <div className="article-content" dangerouslySetInnerHTML={{ __html: contentWithIds }} />
            </article>
          </div>
        </div>
      </section>

      {others.length > 0 && (
        <section className="section-line" style={sectionStyle}>
          <div className="wrap">
            <div className="eyebrow">ادامه‌ی مطالب</div>
            <div className="sec-title">گزارش‌های دیگر</div>
            <div className="sec-sub" style={{ marginBottom: 22 }}>
              تحلیل‌های تازه‌ی بازار مواد اولیه پلیمری.
            </div>
            <div className="news-grid">
              {others.map((o) => (
                <a key={o.id} href={`/reports/${o.id}`} className="news-card">
                  <div className="thumb"></div>
                  <div className="body">
                    <div className="cat">گزارش بازار</div>
                    <h4>{o.title}</h4>
                    <div className="time">{faDate(o.publishedAt)}</div>
                  </div>
                </a>
              ))}
            </div>
          </div>
        </section>
      )}

      <Footer />
    </>
  )
}

const sectionStyle: React.CSSProperties = { padding: '48px 0' }
const backLinkStyle: React.CSSProperties = {
  fontSize: 12.5,
  fontWeight: 600,
  color: 'var(--cyan)',
  display: 'inline-block',
  marginBottom: 18,
}
const articleShellStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: '280px minmax(0,1fr)',
  gap: 36,
  alignItems: 'start',
}
const ctaCardStyle: React.CSSProperties = {
  marginTop: 16,
  background: 'var(--cyan)',
  color: '#fff',
  borderRadius: 16,
  padding: 20,
}
const ctaBtnStyle: React.CSSProperties = {
  display: 'block',
  textAlign: 'center',
  background: '#fff',
  color: 'var(--cyan)',
  borderRadius: 10,
  padding: 12,
  fontWeight: 700,
  fontSize: 13,
  marginTop: 14,
  textDecoration: 'none',
}
const articleCardStyle: React.CSSProperties = {
  background: 'var(--panel)',
  border: '1px solid var(--border)',
  borderRadius: 22,
  boxShadow: '0 6px 24px rgba(23,32,51,.06)',
  overflow: 'hidden',
  padding: '40px 44px 36px',
}
const titleStyle: React.CSSProperties = {
  fontSize: 'clamp(24px,3vw,38px)',
  fontWeight: 800,
  lineHeight: 1.5,
  marginTop: 14,
  marginBottom: 0,
}
const metaRowStyle: React.CSSProperties = {
  marginTop: 16,
  display: 'flex',
  alignItems: 'center',
  gap: 14,
  flexWrap: 'wrap',
  fontSize: 12.5,
  color: 'var(--ink-mute)',
  fontFamily: 'var(--mono)',
}
const dotSepStyle: React.CSSProperties = { color: 'var(--border-strong)' }
const iconBtnStyle: React.CSSProperties = {
  border: '1px solid var(--border)',
  background: 'var(--bg)',
  borderRadius: 8,
  padding: '7px 12px',
  fontSize: 12,
  cursor: 'pointer',
  color: 'var(--ink-mute)',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
}
