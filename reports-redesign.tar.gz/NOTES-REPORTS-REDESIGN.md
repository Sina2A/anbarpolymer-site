# Reports Section Redesign — Implementation Notes

## Overview
Complete redesign of the reports section (`/reports` and `/reports/[id]`) following approved HTML preview designs. Implemented September 12, 2026.

## Changes Made

### 1. Archive Page (`src/app/reports/page.tsx`)

**Layout Structure (new order):**
1. Hero section (eyebrow + title + description) — unchanged
2. **ReportsSearchBar** — client-side search by article title
3. **FeaturedReportCarousel** — rotates through first 3 published articles
4. Article grid with pagination — 10 articles per page
5. **Benchmark prices table** — moved to bottom (was at top)

**Data Fetching:**
- Carousel: First 3 articles (sorted by `publishedAt desc`)
- Grid: Paginated articles (skip 3 + page offset, take 10)
- Search: All article IDs and titles for client-side filtering
- Pagination: URL param `?page=N`, defaults to 1

**Pagination Logic:**
```
Total articles: N
Carousel uses: 3
Remaining for grid: N - 3
Pages: ceil((N - 3) / 10)
```

**Key Decisions:**
- Carousel fixed at 3 articles (not dynamic 3-5)
- Search state client-side only (no URL params)
- Pagination uses simple text links (← قبلی | صفحه X از Y | بعدی →)
- No category filter implemented (Article model has no category field)
- Benchmark section preserved and moved below grid (not removed)

### 2. Detail Page (`src/app/reports/[id]/page.tsx`)

**Layout Structure:**
- **ReadingProgressBar** at top (fixed position)
- Two-column grid: sidebar (280px) + main article
- Sidebar contains:
  - **ArticleTOC** (sticky table of contents)
  - CTA card (link to dashboard)
- Main article contains:
  - Eyebrow, title, meta row with date/author
  - **CopyLinkButton** and print button in meta row
  - HTML content rendered via `dangerouslySetInnerHTML`

**HTML Content Processing:**
1. `injectHeadingIds(html)` — adds `id="section-N"` to all `<h2>` and `<h3>` tags
2. `extractTOC(html)` — parses headings with IDs, returns array for TOC
3. Content rendered with `.article-content` class (styled in globals.css)

**Critical Fix — Single-Pass Regex:**
Both `injectHeadingIds` and `extractTOC` use single-pass regex to preserve document order when h2 and h3 are interleaved:
- Injection: `/<h([23])>/gi` — matches both levels in one pass
- Extraction: `/<(h[23])[^>]*id="([^"]+)"[^>]*>(.*?)<\/\1>/gi` — matches both with backreference

Previous approach (separate h2 pass, then h3 pass) would break TOC order.

### 3. New Client Components

**`src/components/ReportsSearchBar.tsx`:**
- Props: `{ articles: Array<{id, title}> }`
- State: `searchQuery` (string)
- Filters articles by title match (case-insensitive)
- Shows result count

**`src/components/FeaturedReportCarousel.tsx`:**
- Props: `{ articles: Array<{id, title, publishedAt, author}> }`
- State: `currentIndex` (number)
- Prev/next buttons for navigation
- Two-column card: dark navy background (left) + light content (right)
- Matches HTML preview design with grid pattern background

**`src/components/ArticleTOC.tsx`:**
- Props: `{ headings: Array<{id, text, level}> }`
- State: `activeId` (string) — current scroll position
- IntersectionObserver for active section highlighting
- Sticky positioning (`top: 24px`)
- Indent level 3 headings more than level 2

**`src/components/ReadingProgressBar.tsx`:**
- No props
- State: `progress` (number 0-100)
- Listens to scroll events
- Fixed bar at top: 3px height, orange color
- Width = scroll percentage

**`src/components/CopyLinkButton.tsx`:**
- No props
- State: `copied` (boolean) — feedback state
- Copies `window.location.href` to clipboard
- Shows "کپی شد ✓" for 1.5 seconds after copy

### 4. CSS Additions (`src/app/globals.css`)

Added `.article-content` styles for TipTap HTML rendering:
- `h2`, `h3` — heading sizes, spacing, scroll margin
- `p` — paragraph line height, color
- `ul`, `ol`, `li` — list styling
- `blockquote` — orange border-right, amber background
- `table`, `th`, `td` — data table styling
- `.scenarios` grid and `.scenario-card` — for report scenario cards

**All colors use verified CSS variables:**
- `--ink` (#241d15) — dark text
- `--ink-dim` (#6b6053) — paragraph text
- `--ink-mute` (#83765f) — muted text
- `--cyan` (#f6621b) — orange brand color
- `--amber-dim` (#f7ecd9) — light background
- `--bg` (#faf7f1) — page background
- `--border` (#ddd0ba) — borders
- `--green` (#146c3a), `--red` (#a8241a) — scenario indicators

## Known Limitations

1. **Heading IDs:** TipTap editor does not auto-generate `id` attributes. The `injectHeadingIds()` function adds sequential numeric IDs (`section-1`, `section-2`, etc.) server-side. This avoids Persian slugification complexity but means IDs change if heading order changes.

2. **No Category Filter:** ReportsSearchBar implements search but not category filtering (بازار/قیمت/تأمین buttons from HTML preview) because Article model has no `category` field. Adding this requires a Prisma schema migration.

3. **Scenario Cards:** CSS includes `.scenario-card` styling for report content, but TipTap editor would need custom extensions to insert these cards. Currently requires manual HTML in article content.

4. **Mobile Responsive:** Components use CSS Grid and flexbox but may need media queries for mobile layouts (TOC collapsing, carousel touch gestures, etc.). Not implemented in this phase.

5. **Search Performance:** Client-side filtering loads all article titles upfront. For large article counts (>1000), consider server-side search with debouncing.

## Breaking Changes

None. Existing server logic and data model unchanged. Only presentation layer redesigned.

## Migration Notes

- No database migrations required
- No environment variables added
- No new dependencies installed (all features use built-in React/Next.js APIs)
- Existing article content (HTML from TipTap) renders correctly with new `.article-content` styles

## Testing Checklist

- [ ] Archive page hero section displays correctly
- [ ] Search bar filters articles by title
- [ ] Carousel navigation (prev/next) works
- [ ] Pagination links navigate correctly (?page=N)
- [ ] Grid shows 10 articles per page
- [ ] Benchmark table appears below article grid
- [ ] Detail page TOC extracts headings correctly
- [ ] TOC links scroll to sections (smooth behavior)
- [ ] Active TOC item highlights on scroll
- [ ] Reading progress bar tracks scroll position
- [ ] Copy link button copies URL
- [ ] Print button opens print dialog
- [ ] HTML content renders (tables, lists, blockquotes)
- [ ] No console errors in browser

## Files Modified

- `src/app/reports/page.tsx` — 209 lines (was 209, restructured)
- `src/app/reports/[id]/page.tsx` — 216 lines (was 154, added TOC and layout)
- `src/app/globals.css` — ~120 lines added

## Files Created

- `src/components/ReportsSearchBar.tsx` — 74 lines
- `src/components/FeaturedReportCarousel.tsx` — 216 lines
- `src/components/ArticleTOC.tsx` — 88 lines
- `src/components/ReadingProgressBar.tsx` — 35 lines
- `src/components/CopyLinkButton.tsx` — 33 lines
- `NOTES-REPORTS-REDESIGN.md` — this file

## References

- Original prompt: `prompt-reports-redesign.md`
- HTML previews: `reports-preview.html`, `report-detail-preview.html`
- Plan document: `.claude/plans/compressed-munching-newell.md`
