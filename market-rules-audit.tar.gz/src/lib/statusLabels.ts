// منبع واحد برچسب‌های وضعیت (بخش ۳.۷ اَبرتسک بازار).
// پنل ادمین، «آگهی‌های من»، داشبورد، «درخواست‌های خرید» و بازار همه از همین می‌خوانند
// تا برچسب‌ها یکی شوند و نیم‌فاصله‌ها یکسان بمانند. مرجع قطعی: DESIGN_SYSTEM_SPEC_FA.md §۶.
//
// نکته‌ها:
// • کلیدها = همان string statusهای Prisma (بدون enum). اینجا فقط نگاشتِ نمایش است.
// • رنگ/نوعِ بج (success/warning/…) عمداً اینجا نیست؛ منطق رنگ هر صفحه دست‌نخورده می‌ماند.
// • ماژول خنثی است (بدون 'use server'/'use client' و بدون importِ سمت‌سرور)، پس هم
//   Server Component و هم Client Component می‌توانند مستقیم import کنند.

// ── MaterialListing.validityStatus — نمای کامل پنل/مالک ──
export const MATERIAL_LISTING_STATUS_LABELS: Record<string, string> = {
  active: 'فعال',
  reserved: 'رزرو شده',
  needs_reverification: 'نیازمند بازبینی',
  completed: 'تکمیل‌شده',
  cancelled: 'لغو‌شده',
}

// ── PurchaseRequest.status — نمای کامل پنل/مالک ──
export const PURCHASE_REQUEST_STATUS_LABELS: Record<string, string> = {
  open: 'باز',
  reserved: 'رزرو شده',
  needs_review: 'در انتظار بازبینی',
  closed: 'بسته',
  expired: 'منقضی‌شده',
}

// ── نمای عمومی بازار (تب عرضه) — دوحالته ──
// آگهی‌های تب عرضه همیشه active اند، اما پاپ‌آپ جزئیات می‌تواند آگهی رزروشده را هم نشان دهد؛
// برای بازدیدکننده‌ی عمومی فقط «آزاد بودن برای خرید» مهم است، نه چرخه‌ی کامل وضعیت.
export const MARKET_LISTING_LABEL_AVAILABLE = 'آزاد'
export const MARKET_LISTING_LABEL_IN_DEAL = 'در حال معامله'

export function marketListingAvailabilityLabel(validityStatus: string): string {
  return validityStatus === 'active' ? MARKET_LISTING_LABEL_AVAILABLE : MARKET_LISTING_LABEL_IN_DEAL
}

// ── کمک‌تابع‌های امن (fallback به خود کلید = رفتار فعلی همه‌ی صفحات) ──
export function materialListingStatusLabel(validityStatus: string): string {
  return MATERIAL_LISTING_STATUS_LABELS[validityStatus] ?? validityStatus
}

export function purchaseRequestStatusLabel(status: string): string {
  return PURCHASE_REQUEST_STATUS_LABELS[status] ?? status
}
