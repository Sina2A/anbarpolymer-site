# NOTES-MARKET-FLOW.md

Discovery summary from reading the AnbarPolymer source files before writing `market-listing-flow.spec.ts`. No execution results — Sina runs tests on the remote server.

---

## 1. `src/app/new-listing/page.tsx` + Route Handler

- Form: `<form action="/api/material-listings" method="post" encType="multipart/form-data">`
  - **Route Handler**, not a server action — multipart encoding exceeds the server-action body limit.
- Fields (all `name` attributes): `gradeId`, `quantityTon`, `province`, `city`, `packagingType`, `packagingQuality`, `materialQuality`, `askingPriceToman`, `weighbridgeNetWeightKg`, `weighbridgeDate`, `weighbridgePlate`, `weighbridgeTicket` (file input).
- Submit button text: `ثبت آگهی`.
- KYC gate: if `kycLevel < 2`, form is hidden and page shows `احراز تولیدکننده لازمه`.
- Restricted gate: if deadline-violation flag is set, page shows `حسابت موقتاً محدوده`.
- When `?request=<id>` is in the URL, the form pre-fills grade and quantity from the PurchaseRequest (seller responding to buyer demand).
- **weighbridgeDate MUST be today** — API returns `ticket-not-today` error otherwise.

## 2. `src/app/api/material-listings/route.ts`

- `POST` handler parses multipart form, validates, creates `MaterialListing` record.
- On success: `redirect('/my-listings')` (303).
- On failure: `redirect('/new-listing?error=<code>')` (303). Error codes: `kyc`, `restricted`, `ticket-not-today`, `missing-fields`, etc.
- Weighbridge ticket saved to: `public/uploads/weighbridge/{userId}/{filename}`.
- New listing defaults: `validityStatus = 'active'`, `bureaucracyStage = 'submitted'`, `feeStatus = 'unpaid'`.

## 3. `src/app/market/page.tsx`

> **به‌روزرسانی:** طرح قبلی (کارت‌ها + `tr.market-row` + دکمه‌ی «بهزودی») منسوخ است. حالا هر دو تب جدولِ فشرده‌اند و مسیر خرید واقعی وصل است.

- Two tabs: **supply** (default, no query param) and **demand** (`?view=demand`).
- Supply tab: compact grid table (navy header + `SupplyTableRow` per listing). ستون‌ها از `SUPPLY_TABLE_COLUMNS`. کلیک روی ردیف → `ListingDetailDialog` (portaled)، آیکن ⓘ → `TrustCardModal`.
- Demand tab: compact grid table (navy header + `DemandTableRow` per open PurchaseRequest). کلیک روی ردیف → `PurchaseRequestDialog` (portaled). فعلاً دکمه‌ی «پیشنهاد فروش» به `/new-listing?request=<id>` می‌رود (بخش ۱ ابرتسک این را به `acceptPurchaseRequestAction` تغییر خواهد داد).
- روی موبایل هر دو جدول در یک wrapper با `overflow-x:auto` افقی اسکرول می‌شوند (چیدمان کارتی جدا نداریم — نگاه کن بخش «چیدمان نهایی» پایین).
- Only listings with `validityStatus = 'active'` appear in the supply table; only `status = 'open'` (و منقضی‌نشده) requests appear in the demand table.
- گیت دکمه‌ی عمل هر دو تب یکسان است: مهمان → ورود/عضویت، `kycLevel < 1` → «احراز هویت» (`/verification`)، وگرنه اکشن واقعی.

## 4. `src/components/ListingDetailModal.tsx`

> **به‌روزرسانی:** ادعای «بهزودی» منسوخ است — خرید از آگهی حالا واقعی است.

- Default export `ListingDetailModal` (کارت) + named export `ListingDetailDialog` (پرتال روی جدول عرضه) + helper `countryLabel`. جدول عرضه از `ListingDetailDialog` و `countryLabel` استفاده می‌کند (نگه‌داشتنشان لازم است)؛ کارتِ پیش‌فرض فعلاً importer بیرونی ندارد ولی حذف نشده.
- دکمه‌ی خرید گیت‌دار است: مهمان → `/signup`، `kycLevel < 1` → `/verification`، وضعیت `active` → فرمِ `createDealFromListingAction`، وگرنه غیرفعال.
- خرید مستقیم از آگهی (جهت SELL) واقعاً کار می‌کند؛ سناریوی ۲ می‌تواند مستقیماً «خرید خریدار از آگهی» را اجرا کند و مسیر دوطرفه‌ی PurchaseRequest هم همچنان موجود است.

## 5. `src/app/purchase-requests/page.tsx` + `actions.ts`

- Create form: server action `createPurchaseRequestAction`.
- Fields: `gradeId`, `quantityTon`, `maxPriceToman`, `province`, `expiresInDays`, `description` (textarea).
- Submit button: `ثبت درخواست`.
- After creation: redirected to `/purchase-requests`.
- Each card shows: grade code, quantity, price, status badge, and a count of responding listings (`X آگهی در پاسخ`).
- Close form: hidden `input[name="requestId"]` + `ConfirmSubmitButton` labeled `بستن درخواست` — فقط وقتی `displayStatus === 'open'` نمایش داده می‌شود.
- Status labels (کامل): `open` → `باز`، `reserved` → `رزرو شده`، `needs_review` → `در انتظار بازبینی` (warning)، `closed` → `بسته شده`، `expired` → `منقضی`.
  - `reserved`: یک فروشنده درخواست را با `acceptPurchaseRequestAction` پذیرفته و Deal ساخته شده.
  - `needs_review`: درخواست‌دهنده معامله‌ی BUY را لغو کرده و منتظر تایید دستی ادمین است (وضعیت میانی). این‌ها + `reserved` در فیلترِ تب تقاضا (`status:'open'`) خودبه‌خود پنهان‌اند.
- Access control: `requireCompanyVerifiedFor('U-KYC1-PURCHASEREQ')`.

## 6. `src/app/admin-material-listings/page.tsx` + `actions.ts`

- Server action `updateListingStatusAction` — می‌نویسد `reviewedById` / `reviewedAt`.
- Toggle action: `VALID_TRANSITIONS = { active: 'reserved', reserved: 'active', needs_reverification: 'active' }` — action param: `toggle`. برای `needs_reverification` برچسبِ toggle «تایید و انتشار مجدد» است.
- Cancel action: `action = 'cancel'` → sets `validityStatus = 'cancelled'`, sets reason "حذف به دلیل تخلف".
- Each row has two forms in the last `<td>`: toggle form + cancel form, each with hidden `<input name="id">` and `<input name="action">`.
- On success: redirect to `/admin-material-listings?updated=1`.
- Status labels: `active` → `آزاد`، `reserved` → `رزرو شده`، `needs_reverification` → `نیازمند بازبینی مجدد`، `cancelled` → `لغو شده` (with space, from Arabic).

## 7. `src/app/my-listings/page.tsx`

- Cards per listing: grade code, `#${id.slice(0, 8)}`, validityStatus tag, feeStatus.
- Status labels: `active` → `فعال`, `cancelled` → `لغو‌شده` (with ZWNJ — different from admin's `لغو شده`).
- No close/edit/delete buttons exposed to seller (managed only by admin).

## 8. `src/lib/sections.ts`

- All 17 admin sidebar sections have `isReal: true` — no hidden/placeholder sections.

## 9. Prisma schema highlights (lines 771–840)

- `MaterialListing`: `validityStatus` default `'active'`, `bureaucracyStage` default `'submitted'`, `feeStatus` default `'unpaid'`, `weighbridgeTicketUrl` is required (String, not optional).
- `PurchaseRequest`: `status` default `'open'`, `expiresAt` is optional DateTime.
- Both models have `createdAt` / `updatedAt` auto-managed.

---

## Key Test Implications

| Finding | Impact on tests |
|---|---|
| Form is multipart Route Handler, not server action | Must use `setInputFiles` for file upload, `waitForURL` for redirect |
| weighbridgeDate must be today | `todayStr()` helper required |
| KYC level 2 gate | Fast-fail with clear message if testseller not verified |
| Buy flow is live (`createDealFromListingAction`) | Scenario 2 can buy directly from a listing; PurchaseRequest flow still available as the second path |
| Admin cancel form hidden inputs | Locate by `form:has(input[name="id"][value="..."]):has(input[name="action"][value="cancel"])` |
| `لغو شده` (admin) vs `لغو‌شده` (seller) | Different ZWNJ — use exact text from each page source |
| PurchaseRequest hidden requestId | For seller's `/new-listing?request=<id>` link |
| all sections isReal:true | No test sections to worry about filtering |
