# Design System — انبار پلیمر

نسخه: 0.1 (پیشنهاد معماری) · وضعیت: بدون تغییر در schema، route، server action یا access rule

## 1) Audit مبتنی بر کد موجود

| مشاهده | شواهد | اثر | تصمیم کم‌ریسک |
|---|---|---|
| دو زبان بصری هم‌زمان | `src/lib/styles/tokens.ts` سرمه‌ای/خنثی است؛ `src/app/globals.css` هنوز زمینه کرم و هدر نارنجی دارد | صفحات از یک خانواده دیده نمی‌شوند | globals را تدریجی به tokenهای معنایی map کنید؛ رنگ برند را تغییر ندهید |
| token coverage ناقص | tokenهای spacing/radius/font-size وجود دارند، اما elevation، motion، z-index، breakpoint و theme ندارند | مقادیر محلی و رفتار ناهماهنگ | tokenهای جدید را additive اضافه کنید |
| styleهای inline فراوان | حدود 1,254 مقدار رنگی مستقیم در `src` | dark mode و نگهداری دشوار | ابتدا shared primitives، سپس migration صفحه‌به‌صفحه |
| shellهای جدا اما هم‌خانواده نیستند | `PublicHeader` محلی و `UserNav`/`AdminNav` مبتنی بر shared هستند | responsive و focus state یکسان نیست | AppShell/PublicShell واحد با slot برای nav |
| وضعیت‌ها String هستند | `Order.status`, `Deal.status`, `MaterialListing.validityStatus`, `SupportTicket.status` و ... | برچسب UI ممکن است از pipeline جدا شود | registry صرفاً mapping نمایش؛ کلید جدید ممنوع |
| جدول‌ها primitive هستند | `tableStyle` فاقد toolbar، sticky/compact mode و states است | داده زیاد و mobile شکننده می‌شود | DataTable + MobileRecordCard روی داده/API فعلی |

چیزهایی که حذف یا بازطراحی کامل نمی‌شوند: Prisma schema، روابط، status stringها، منطق KYC، مجوزها، modal/form actionهای موجود و مسیرها.

## 2) معماری

```
tokens (TS + CSS custom properties)
  └─ primitives: Text · Button · Field · Card · Badge · Feedback · Overlay
      └─ composites: PageHeader · Toolbar · DataTable · RecordCard · Stepper
          └─ shells: PublicShell · AppShell · AdminShell · LogisticsShell
              └─ feature pages (فقط داده، permission و actionهای موجود)
```

منبع حقیقت: `src/lib/styles/tokens.ts`. `globals.css` فقط export CSS variables، reset، typography، focus و responsive utilities باشد. `shared.ts` در مرحله migration adapter بماند، اما primitiveهای جدید API مبتنی بر `variant` داشته باشند.

## 3) Tokenها و mapping

| Semantic token | Light | Dark | mapping فعلی |
|---|---:|---:|---|
| `surface.page` | `#F7F8FA` | `#101625` | `bgPage` / `--bg` |
| `surface.default` | `#FFFFFF` | `#171F31` | `bgCard` / `--panel` |
| `surface.elevated` | `#FFFFFF` | `#202A3D` | جدید |
| `surface.subtle` | `#F1F4F8` | `#121A2A` | `bgHover`, `--panel-2` |
| `content.primary` | `#1A1F36` | `#F4F7FB` | `textPrimary` / `--ink` |
| `content.secondary` | `#526075` | `#BAC5D6` | `textSecondary` / `--ink-dim` |
| `content.muted` | `#6E7C91` | `#8F9CB0` | `textMuted` / `--ink-mute` |
| `border.subtle` | `#E3E8EE` | `#2B3850` | `borderSubtle` / `--border` |
| `border.strong` | `#C9D2DE` | `#46546A` | `borderStrong` / `--border-strong` |
| `action.primary` | `#1E357B` | `#8098E5` | `navy` |
| `action.primary-hover` | `#152A63` | `#A9B9F2` | `navyDark` |
| `action.secondary` | `#E65716` | `#FF9A65` | `orange`؛ فقط CTA مکمل/هشدار تجاری |
| `state.success` | `#0E6245` | `#66D7AA` | `successText` |
| `state.warning` | `#92400E` | `#F5C76E` | `warningText` |
| `state.danger` | `#9B1C1C` | `#FF9D9D` | `dangerText` |
| `state.info` | `#3730A3` | `#A9B9FF` | `infoText` |

توکن‌های تکمیلی: `space={4,8,12,16,24,32,40,48,64}`، `radius={6,8,12,16,999}`، elevation `0/1/2/overlay`، breakpoint `sm:640 md:768 lg:1024 xl:1280`، motion `fast:120 normal:180 slow:240` با ease-out، و z-index `header:100 sidebar:110 dropdown:200 modal:400 toast:500`.

Theme با `data-theme="light|dark"` روی `html` اعمال شود؛ theme تیره با سطح‌های مستقل بالا تعریف شود، نه invert.

## 4) استاندارد کامپوننت‌ها

| جزء | variant / اندازه | قواعد ضروری |
|---|---|---|
| Shell | Public, User, Admin, Logistics | دسکتاپ sidebar sticky/collapsible؛ موبایل header فشرده + navigation عملیاتی |
| PageHeader | title, description, breadcrumb, status, CTA | عنوان ۲ خط؛ CTA فقط action مجاز واقعی |
| Button | primary, secondary, tertiary, danger, icon; sm/md/lg | min-height موبایل 44px؛ loading جای متن را ثابت نگه دارد؛ focus ring |
| FormField | label, hint, error, required, prefix/suffix | label واقعی، error متنی، LTR برای مقدار فنی/عدد |
| Input/Select/Textarea | default, error, disabled, readonly | فرم و action فعلی را تغییر ندهد |
| Card | default, summary, detail, actionable, compact | `minmax()`، محتوای بلند clamp و link «مشاهده کامل» |
| Badge/StatusBadge | neutral/info/warning/success/danger | icon + label؛ رنگ تنها حامل معنا نیست |
| Alert/InlineNotice | info/success/warning/danger | علت، اثر و اقدام بعدی روشن |
| Modal/Drawer/Popover/ConfirmDialog | sizes sm/md/lg | focus trap، Escape، overlay، متن برگشت‌پذیری دقیق |
| Tabs/Segmented/Chips | default/selected/disabled | وضعیت انتخاب فقط از state/API موجود |
| Feedback | Loading/Skeleton, Empty, Error, NoAccess, PartialAccess, Success | برای empty database و empty search پیام جدا |
| DataTable | compact/default, sticky header, horizontal | ستون هویتی sticky، column-priority، scroll فقط در wrapper |
| RecordCard | mobile | همه داده حفظ؛ secondary در drawer/detail |
| Timeline/ActivityLog | compact/full | زمان، actor، رویداد و note؛ `StatusEvent` منبع اصلی |
| TechnicalSpecViewer | summary/full | 4–8 key spec؛ باقی grouped tabs/accordion؛ فیلد null در summary پنهان |
| Value display | Price/Quantity/DateTime/IdCode | واحد و مقدار یک جزء؛ mono + LTR برای داده فنی |
| Stepper | KYC/order/proforma/deal/logistics | مراحل صرفاً از workflow واقعی، نه مسیر فرضی |

ConfirmDialog نمونه: «آگهی [ID] لغو می‌شود و تا زمانی که backend امکان بازگردانی فراهم نکرده است، قابل بازگشت نیست. ادامه می‌دهید؟»

## 5) DataTable، فیلتر و pagination

1. دسکتاپ: toolbar شامل search، فیلترهای واقعی API، شمارش نتیجه و reset؛ table wrapper مستقل با `overflow-x:auto`.
2. موبایل: breakpoint `md` یا container query؛ همان query و pagination به `RecordCard` تبدیل شود. اطلاعات ثانویه در «جزئیات»/drawer، نه حذف.
3. ستون‌ها: identity (عنوان/ID)، status، زمان، value کلیدی، action. identity sticky، status و action priority بالا؛ سایر ستون‌ها در عرض کم hide شوند.
4. عنوان دو خط و متن سه خط؛ داده بلند truncate + Tooltip یا detail. sort فقط وقتی endpoint/داده واقعاً آن را پشتیبانی می‌کند.
5. انتخاب گروهی فقط با server action گروهی موجود. destructive action از منوی عادی جدا باشد.
6. pagination یا progressive loading دقیقاً با سازوکار API موجود؛ empty-result: «نتیجه‌ای با این فیلترها یافت نشد.»، empty-database: «هنوز رکوردی برای نمایش وجود ندارد.»
7. **استثنای بازار (`/market`) — چیدمان نهایی:** هر دو تب عرضه و تقاضا یک جدولِ grid فشرده با هدر سرمه‌ای‌اند و روی موبایل داخل wrapper با `overflow-x:auto` **افقی اسکرول** می‌شوند؛ اینجا تبدیل به `RecordCard` نداریم (خلاف بند ۲). دلیل: تعداد ستون‌های مقایسه‌ای زیاد است و مقایسه‌ی ردیف‌به‌ردیفِ گرید/قیمت/مقدار ارزش کاربری اصلی صفحه است. `skeleton` صفحه (`market/loading.tsx`) هم باید همین ساختار جدولِ افقی را آینه کند. ستون‌ها از `SUPPLY_TABLE_COLUMNS` / `DEMAND_TABLE_COLUMNS` با `minmax(0, …fr)` برای جلوگیری از Grid Blowout.

## 6) registry وضعیت‌های واقعی

| مدل / فیلد | کلید backend | نمایش فارسی | semantic | اقدام بعدی UI |
|---|---|---|---|---|
| `Order.status` | `pending` | در حال ثبت اولیه توسط مشتری | warning | بررسی/قیمت‌گذاری مجاز |
|  | `priced` | در حال تعیین قیمت توسط کارشناس فروش | info | اعلام/تأیید پیش‌فاکتور موجود |
|  | `buyer_confirmed` | در حال تأیید قیمت توسط مشتری | info | مشاهده پیش‌فاکتور |
|  | `contracted` | در حال عقد قرارداد | info | تکمیل/مشاهده قرارداد توسط نقش مجاز |
|  | `paid` | پرداخت‌شده؛ در انتظار بررسی و تأیید مالی | warning | بررسی رسید یا تأیید پرداخت توسط کارشناس مالی |
|  | `loading` | در حال بارگیری در انبار | info | ثبت/مشاهده تأییدیهٔ بارگیری مجاز |
|  | `in_transit` | در مسیر ارسال | info | پیگیری حمل و نمایش اطلاعات بار |
|  | `delivered` | تحویل داده شده؛ سفارش بسته شد | success | مشاهده سوابق و تأییدیه‌های ثبت‌شده |
|  | `rejected` | رد شده | danger | نمایش علت؛ بازگشت موجودی طبق workflow |
| `paymentReceiptStatus` | `pending/approved/rejected` | در انتظار بررسی / تأییدشده / ردشده | warning/success/danger | رسید یا علت رد |
| `Invoice.status` | `issued/cancelled` | صادرشده / لغوشده | success/neutral | مشاهده سند |
| `Deal.status` | `draft` | پیش‌نویس | neutral | تکمیل ثبت |
|  | `confirmed` | تأییدشده | info | انتظار پرداخت کارمزد فروشنده |
|  | `seller_fee_paid` | کارمزد فروشنده پرداخت شده | info | انتظار پرداخت خریدار |
|  | `payment_secured` | وجه تأمین شده | info | آماده بارگیری |
|  | `loading/in_transit/delivered/settled` | در حال بارگیری / در مسیر / تحویل‌شده / تسویه‌شده | info/info/success/success | تأییدیه مجاز بعدی |
| `MaterialListing.validityStatus` | `active/reserved/needs_reverification/completed/cancelled` | فعال / رزرو شده / نیازمند بازبینی / تکمیل‌شده / لغوشده | success/warning/warning/success/neutral | براساس workflow آگهی |
| `MaterialListing.feeStatus` | `unpaid/pending_review/paid` | پرداخت‌نشده / در انتظار بررسی / پرداخت‌شده | warning/warning/success | نمایش مهلت فقط اگر `feeDeadline` هست |
| `PurchaseRequest.status` | `open/reserved/needs_review/closed/expired` | باز / رزرو شده / در انتظار بازبینی / بسته / منقضی‌شده | success/warning/warning/neutral/neutral | باز→پاسخ/پذیرش فروشنده؛ `reserved`=با `acceptPurchaseRequestAction` پذیرفته و Deal ساخته شد؛ `needs_review`=لغو معامله توسط خریدار، در انتظار تأیید دستی ادمین (فقط `open` در تب تقاضا دیده می‌شود) |
| `SupportTicket.status` | `open/answered/closed` | باز / پاسخ داده‌شده / بسته | warning/info/neutral | پاسخ/مشاهده گفتگو |
| `Article` | `isPublished=false`, `publishedAt=null` | پیش‌نویس / زمان‌بندی‌نشده | neutral | ویرایش/انتشار طبق مجوز |
| `WarehouseStock.dealLightStatus` | `available/negotiating/recently_sold` | موجود / در حال مذاکره / تازه فروخته‌شده | success/warning/neutral | اطلاعات موجودی |
| `Kyc` | `level: 0..2` در رابط کاربر | کاربر ساده / شرکت تأییدشده / تولیدکننده تأییدشده | neutral/success/success | مرحله واقعی بعدی |
| `TransportCompany/Driver` | `isActive`, `logisticsAccessEnabled` | فعال/غیرفعال، دسترسی پنل فعال/غیرفعال | success/neutral | فقط stateهای boolean واقعی |

`src/lib/workflow.ts` منبع قطعی stageهای Order، MaterialListing و SupportTicket است؛ registry نباید کلیدی را به backend اضافه کند. برای statusهایی که بیرون از آن فایل‌اند، ابتدا actionهای متعلق به همان مدل audit و سپس registry تکمیل می‌شود.

یادداشت KYC: schema و پنل override ادمین امکان ذخیره/انتخاب `level=3` («چند معاملهٔ موفق») را دارند، اما صفحهٔ فعلی `/verification` فقط چرخهٔ قابل‌نمایش ۰ تا ۲ را پیاده می‌کند و مسیر خودکار ارتقا به ۳ در کد عملیاتی تأیید نشد. بنابراین سطح ۳ در UI عمومی، CTAها و Stepper قطعی فرض نمی‌شود؛ نمایش آن تا تأیید صاحب محصول صرفاً یک مقدار مدیریتی/legacy تلقی خواهد شد.

### 6.1 قوانین ثابت بازار (invariantهای معامله و امنیت)

این قوانین در actionهای بازار (`src/app/market/actions.ts`) و query‌های عمومی اجرا می‌شوند و تغییرشان بدون تأیید صاحب محصول ممنوع است:

1. **گیت احراز هویت:** هر دو مسیر خرید (`createDealFromListingAction` جهت SELL) و پذیرش درخواست (`acceptPurchaseRequestAction` جهت BUY) فقط KYC1 لازم دارند (`requireCompanyVerifiedFor`، کد `U-KYC1-DEAL`). گیت تولیدکننده (KYC2) به دکمه‌ی پذیرش اضافه **نمی‌شود**؛ تاریخ باسکول و عکس بارنامه فقط برای مرحله‌ی بارگیری واقعی رزرو است، نه پذیرش.
2. **منع معامله با خود:** خرید از آگهی خودِ کاربر ممنوع است («خرید از آگهی خودتان امکان‌پذیر نیست.») و پذیرش درخواست خودِ کاربر ممنوع است («پذیرش درخواست خودتان امکان‌پذیر نیست.»).
3. **کاربر محدودشده:** اگر `isUserRestricted` صادق باشد (تخلف مهلت)، هر دو action رد می‌شوند.
4. **رزروِ اتمیک (اولین کلیک برنده):** رزرو با `updateMany({ where: { id, <status اولیه> }, data })` زیر READ COMMITTED انجام و اگر `count === 0` بود throw می‌شود؛ SELL: `active→reserved`، BUY: `open→reserved`. سپس Deal با `status:'draft'` و دو `DealPayment` (`BUYER_GOODS`, `SELLER_FEE`) ساخته و به `/my-deals` ری‌دایرکت می‌شود.
5. **لغو توسط درخواست‌دهنده:** لغو معامله‌ی BUY توسط خریدار → وضعیت میانی `needs_review` روی `PurchaseRequest` + تأیید دستی ادمین (بازگشت به `open` یا بستن).
6. **امنیت — ممنوعیت `include:{user}` در query عمومی:** query‌های عمومی بازار (عرضه و تقاضا) هرگز نباید `include:{ user: … }` داشته باشند؛ این کار `User.passwordHash`/`phone`/`email` را داخل payload عمومی serialize می‌کند. فقط فیلدهای غیرحساسِ لازم با `select` صریح برداشته شوند. این قاعده در کامنت‌های `market/page.tsx` هم ثبت است.

## 7) الگوهای صفحه

| محیط | ساختار |
|---|---|
| عمومی | PublicHeader → hero/section → catalogue/market table → CTA؛ topbar سرمه‌ای، header سرمه‌ای، نارنجی فقط نقطه تأکید |
| پنل کاربر | UserNav → PageHeader → KYC/limited-access notice در صورت نیاز → toolbar → table/cards → timeline |
| ادمین | AdminNav (permission-aware) → PageHeader → queue/KPI فقط برای تصمیم → DataTable → drawer جزئیات + audit/history |
| حمل‌ونقل | LogisticsNav → بارهای نیازمند اقدام اول → record card موبایل → فرم تأیید بارگیری/تخلیه با checklist، GPS/evidence فعلی |
| راننده | mobile-first، یک عمل اصلی در هر view، شماره/پلاک/کد با mono LTR، CTA حداقل 44px |

## 8) RTL/LTR و قالب داده

- ریشه UI: `dir="rtl"`; فارسی `Vazirmatn` و تراز راست.
- `GradeCode`, `IdCode`, `Price`, `Quantity`, phone, URL, plate و مقدار علمی: `dir="ltr"`, `font-family: JetBrains Mono`, `unicode-bidi: plaintext`; در container RTL با `text-align:start` کنترل شود.
- قیمت: `۱۲٬۳۴۵ ریال` یا `۱۲٬۳۴۵ تومان` با component و واحد صریح؛ هرگز واحد جدا از مقدار wrap نشود.
- تاریخ: یک formatter مرکزی Persian calendar با fallback قابل‌دسترس و نمایش زمان/zone در عملیات حساس.
- مقدار: `25 kg` یا `1.2 g/cm³` در یک `ValueWithUnit`; precision بر اساس داده واقعی، نه round نمایشی گمراه‌کننده.

## 9) اجرای مرحله‌ای و اعتبارسنجی

| مرحله | فایل‌های درگیر (پیشنهادی) | دلیل | اعتبارسنجی |
|---|---|---|---|
| 1. تثبیت token | `tokens.ts`, `globals.css` | حل منبع‌های متناقض بدون تغییر رفتار | snapshot light/dark و بررسی contrast |
| 2. primitives | `src/components/ui/*`, `shared.ts` | جایگزین‌های additive برای styleهای محلی | unit/render + keyboard/focus |
| 3. shell/nav | `PublicHeader.tsx`, `UserNav.tsx`, `AdminNav.tsx`, `LogisticsNav.tsx` | navigation responsive و access-aware | desktop/mobile, active, no-access |
| 4. form/feedback | form/modal موجود + primitives | حفظ actionها، یکپارچه‌سازی ظاهر | validation، submit، Escape/focus trap |
| 5. table/card | list pageها + `DataTable`/`RecordCard` | تحمل صدها رکورد | 0/1/100/500 data، overflow، filter-empty |
| 6. عمومی | public routes | ابتدا صفحات کم‌خطر | visual regression و Core flows |
| 7. کاربر | dashboard/orders/requests/listings/deals | pipelineهای عملیاتی | E2E actionهای واقعی |
| 8. ادمین | admin routes | permission و destructive flows | role matrix و audit log |
| 9. responsive/dark | همه shell/primitives | تکمیل سیستم، نه بازنویسی | 320/768/1024/1440 + contrast |

قاعدهٔ مهاجرت: هیچ صفحه‌ای در فازهای ابتدایی بازنویسی کامل نمی‌شود. ابتدا primitives و tokenها به‌صورت additive ساخته می‌شوند، سپس هر route با visual regression و تست E2E موجود مهاجرت داده می‌شود.

## 10) تصمیم‌های باز برای تأیید صاحب محصول

1. منبع قطعی کلیدهای `Order.status` و `MaterialListing.bureaucracyStage` چیست؟ (workflow/actionها باید قبل از registry نهایی audit شوند.)
2. حالت theme: انتخاب کاربر، پیروی از سیستم، یا هر دو؟
3. فرمت رسمی تاریخ و زمان برای اسناد مالی/حقوقی: جلالی تنها یا جلالی همراه میلادی؟
4. سطح KYC که CTA فروش و ثبت آگهی را باز می‌کند دقیقاً کدام `level/badge` است؟
5. آیا کاربر مجاز به لغو/آرشیو/بازگردانی هر رکورد است یا فقط مشاهده می‌کند؟
6. کدام list APIها sort، filter server-side و pagination را بالفعل پشتیبانی می‌کنند؟
7. اولویت 4–8 Key Spec برای هر `polymerFamily` از کجا تعیین و مالک آن چه کسی است؟

## 11) فرآیند تحویل، تحلیل و استقرار

### 11.1 تحویل نسخهٔ قابل بررسی

پس از هر فاز طراحی یا پیاده‌سازی، فقط یک archive با فرمت `tar.gz` تحویل می‌شود. archive باید شامل فایل‌های جدید/تغییرکردهٔ همان فاز، فهرست دقیق آن‌ها، توضیح تغییر/دلیل/اثر بر route و component، دستورهای build/test/migration، نتیجهٔ تست‌های مرتبط، و checksum `SHA-256` باشد. اگر وابستگی تغییر کرده، `package.json` و lockfile همان فاز نیز الزامی‌اند.

archive نباید شامل `.env`، secret، API key، session، cookie، credential، `node_modules`، `.next`، log، test-result/report حجیم، فایل موقت، دادهٔ واقعی کاربر، رسید پرداخت یا فایل خصوصی باشد.

### 11.2 تحلیل چندمرحله‌ای پیش از انتشار

هر archive پیش از تأیید باید این کنترل‌ها را بگذراند:

1. تطبیق با Design System و tokenهای مصوب.
2. سازگاری با schema، route، server action و access ruleهای موجود.
3. بررسی RTL/LTR، داده‌های فنی، فرم‌ها، modalها و statusهای رکورد.
4. responsive در عرض‌های 320، 768، 1024 و 1440 پیکسل.
5. حالت‌های loading، empty، error، no-access و داده‌های بلند.
6. اجرای build و تست‌های موجود، به‌ویژه Playwright.
7. visual regression صفحات و جریان‌های حساس.

تا قبل از تأیید همهٔ موارد، هیچ فایلی روی production نصب یا جایگزین نمی‌شود.

### 11.3 انتشار در GitHub

پس از تأیید نهایی، تغییرات با commit روشن و قابل‌ردیابی در repository عمومی GitHub commit و push می‌شوند. تغییر وابستگی همراه lockfile ثبت می‌شود. اجرای مستقیم اسکریپت دریافت‌شده از اینترنت، مانند `wget … | bash` یا `curl … | sh`، ممنوع است. هر archive یا فایل دریافت‌شده از GitHub پیش از استفاده با SHA-256 و فهرست فایل مورد انتظار تطبیق داده می‌شود.

### 11.4 نصب کنترل‌شده روی سرور

کاربر revision یا archive را دستی از GitHub دریافت می‌کند. روند سرور: backup قابل‌بازگشت → دریافت revision مشخص → کنترل checksum و manifest → استخراج در staging → بررسی diff → نصب dependency فقط در صورت تغییر manifest/lockfile → `npm run build` → تست مرتبط → جایگزینی کنترل‌شدهٔ production → restart PM2 با نام واقعی سرویس‌ها → health-check، log check و آزمون جریان حساس.

با شکست build، test یا health-check، انتشار متوقف می‌شود و نسخهٔ پیشین قابل بازگشت باقی می‌ماند. چرخهٔ اجباری هر فاز: طراحی → archive قابل بررسی → تحلیل چندمرحله‌ای → تأیید → commit/push → staging → build/test → production → health-check. این روند نباید schema، دادهٔ کاربران، backend یا pipeline تجاری را ناخواسته تغییر دهد.
