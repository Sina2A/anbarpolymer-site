// src/lib/swVersion.ts
//
// تنها منبع حقیقت برای نسخه‌ی Service Worker. چون sw.js دست‌نویس است و
// precache manifest خودکار ندارد، تغییر asset‌ها باید با bump این عدد همراه
// باشد تا کش‌های قدیمی در activate پاک شوند و ثبت SW با query string جدید
// بارگذاری شود.
export const SW_VERSION = 'ap-v1'
export const SW_URL = `/sw.js?v=${SW_VERSION}`
