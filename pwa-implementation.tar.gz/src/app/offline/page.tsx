import type { Metadata } from 'next'
import { colors, radius, shadow, fontSize } from '@/lib/styles/tokens'
import OfflineActions from './OfflineActions'

/**
 * صفحه‌ی صریح آفلاین — جایگزین fallback ناوبری وقتی شبکه قطع است.
 *
 * ⚠️ این صفحه باید کاملاً استاتیک بماند:
 *   - هیچ prisma / fetch / cookies() / headers() اینجا نیست
 *   - هیچ `export const dynamic` هم لازم نیست؛ نبودِ هر API داینامیک
 *     خودش باعث رندر استاتیک می‌شود (و اگر cacheComponents روشن شود
 *     هم سازگار می‌ماند، چون در Next 16 آن export حذف شده است)
 *
 * Service Worker در رویداد install مسیر '/offline' را به‌همراه
 * assetهای hash‌دارش precache می‌کند تا این صفحه هنگام قطعی شبکه
 * با CSS و فونت کامل رندر شود.
 *
 * پیام عمداً صریح است: به کاربر نمی‌گوییم «داده‌ای نیست»، می‌گوییم
 * داده‌ی مالی فقط آنلاین قابل‌مشاهده است — تا وضعیت معامله/پرداختِ
 * قدیمی هرگز بی‌هشدار نشان داده نشود.
 */
export const metadata: Metadata = {
  title: 'اتصال اینترنت برقرار نیست — انبار پلیمر',
}

export default function OfflinePage() {
  return (
    <main
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: colors.bgPage,
        fontFamily: "'Vazirmatn', Tahoma, sans-serif",
        direction: 'rtl',
        padding: '24px',
      }}
    >
      <div
        style={{
          maxWidth: 460,
          width: '100%',
          background: colors.bgCard,
          border: `1px solid ${colors.borderSubtle}`,
          borderRadius: radius.lg,
          boxShadow: shadow.card,
          padding: '32px 24px',
          textAlign: 'center',
        }}
      >
        {/* آیکون قطع شبکه — SVG درون‌خطی، نه emoji */}
        <div
          aria-hidden="true"
          style={{
            width: 64,
            height: 64,
            margin: '0 auto 18px',
            borderRadius: '50%',
            background: colors.neutralBg,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <svg
            width="32"
            height="32"
            viewBox="0 0 24 24"
            fill="none"
            stroke={colors.textSecondary}
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M2 2l20 20" />
            <path d="M8.5 16.5a5 5 0 0 1 7 0" />
            <path d="M5 12.9a10 10 0 0 1 5.2-2.7" />
            <path d="M13.8 10.2A10 10 0 0 1 19 12.9" />
            <path d="M1.6 9.2a15 15 0 0 1 5.1-3.3" />
            <path d="M17.3 5.9a15 15 0 0 1 5.1 3.3" />
            <circle cx="12" cy="20" r="1" fill={colors.textSecondary} stroke="none" />
          </svg>
        </div>

        <h1
          style={{
            margin: '0 0 10px',
            fontSize: fontSize.xl,
            fontWeight: 800,
            color: colors.textPrimary,
          }}
        >
          اتصال اینترنت برقرار نیست
        </h1>

        <p
          style={{
            margin: '0 0 8px',
            fontSize: fontSize.md,
            lineHeight: 1.8,
            color: colors.textSecondary,
          }}
        >
          برای دیدن این صفحه دوباره به اینترنت وصل شوید.
        </p>

        <p
          style={{
            margin: '0 0 24px',
            fontSize: fontSize.base,
            lineHeight: 1.9,
            color: colors.textMuted,
          }}
        >
          اطلاعات معاملات، قیمت‌ها و وضعیت پرداخت‌ها فقط در حالت آنلاین
          قابل‌مشاهده است و هرگز به‌صورت آفلاین یا از حافظه‌ی پنهان نمایش
          داده نمی‌شود — چون ممکن است دیگر معتبر نباشند.
        </p>

        <OfflineActions />
      </div>
    </main>
  )
}
