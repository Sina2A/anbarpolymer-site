// src/app/offline/OfflineActions.tsx
//
// دکمه‌های تعاملی صفحه‌ی آفلاین. در یک فایل 'use client' جدا شده تا
// page.tsx سروری و کاملاً استاتیک بماند — الگوی همان error.tsx که کار
// تعاملی را به BrandedErrorPage می‌سپارد.
//
// اگر page.tsx به‌طور غیرعمد داینامیک شود، precache در install شکست
// می‌خورد و آفلاین کار نمی‌کند؛ پس هیچ import سروری سنگین اینجا نیست.
//
// ⚠️ دکمه‌ی دوم عمداً history.back() است نه لینک به '/':
// روی SURFACE=admin و SURFACE=transport مسیر '/' به /404 rewrite می‌شود،
// پس «خانه» برای آن سطح‌ها مقصد درستی نیست. history.back() سطح‌آگاه و
// امن است و اگر تاریخچه‌ای نباشد به reload می‌افتد.
'use client'

import { radius, fontSize, colors } from '@/lib/styles/tokens'

function goBack() {
  if (window.history.length > 1) {
    window.history.back()
  } else {
    window.location.reload()
  }
}

export default function OfflineActions() {
  return (
    <div style={{ display: 'flex', gap: 10, justifyContent: 'center', flexWrap: 'wrap' }}>
      <button
        type="button"
        onClick={() => window.location.reload()}
        style={{
          background: colors.navy,
          color: '#fff',
          border: 'none',
          borderRadius: radius.md,
          padding: '10px 20px',
          fontSize: fontSize.base,
          fontWeight: 700,
          cursor: 'pointer',
          fontFamily: 'inherit',
        }}
      >
        تلاش دوباره
      </button>
      <button
        type="button"
        onClick={goBack}
        style={{
          background: colors.bgCard,
          color: colors.navy,
          border: `1px solid ${colors.borderStrong}`,
          borderRadius: radius.md,
          padding: '10px 20px',
          fontSize: fontSize.base,
          fontWeight: 700,
          cursor: 'pointer',
          fontFamily: 'inherit',
        }}
      >
        بازگشت
      </button>
    </div>
  )
}
