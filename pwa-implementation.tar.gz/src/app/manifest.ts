import type { MetadataRoute } from 'next'

/**
 * PWA manifest — نصب‌شدنی روی موبایل و دسکتاپ.
 *
 * start_url باید سطح‌آگاه باشد: سایت روی سه استقرار سرو می‌شود
 * (SURFACE=public:3000 / admin:3001 / transport:4000). روی SURFACE=admin
 * مسیر '/' یک admin path نیست و middleware آن را به /404 rewrite می‌کند،
 * پس start_url ثابت '/' نصب ادمین را روی صفحه‌ی مرده باز می‌کرد.
 *
 * process.env.SURFACE یک مقدار استقرار است (نه Request-time API مثل
 * cookies()/headers())، پس manifest طبق docs همچنان کش‌شدنی می‌ماند.
 */
const SURFACE_START: Record<string, string> = {
  admin: '/admin-orders', // اولین بخش isReal در src/lib/sections.ts
  transport: '/transport-panel',
}

const startUrl = SURFACE_START[process.env.SURFACE ?? ''] ?? '/'

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'انبار پلیمر',
    short_name: 'انبارپلیمر',
    description: 'بازار و انبار پلیمر — معاملات امن مواد اولیه‌ی پلیمری',
    start_url: startUrl,
    scope: '/',
    display: 'standalone',
    background_color: '#f7f8fa',
    theme_color: '#1e357b',
    lang: 'fa',
    dir: 'rtl',
    icons: [
      {
        src: '/icon-192.png',
        sizes: '192x192',
        type: 'image/png',
        purpose: 'any',
      },
      {
        src: '/icon-512.png',
        sizes: '512x512',
        type: 'image/png',
        purpose: 'any',
      },
      {
        src: '/icon-maskable-192.png',
        sizes: '192x192',
        type: 'image/png',
        purpose: 'maskable',
      },
      {
        src: '/icon-maskable-512.png',
        sizes: '512x512',
        type: 'image/png',
        purpose: 'maskable',
      },
    ],
  }
}
