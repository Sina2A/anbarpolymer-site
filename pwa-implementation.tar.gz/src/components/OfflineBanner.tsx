// src/components/OfflineBanner.tsx
//
// بنر سراسری آفلاین. وقتی شبکه قطع است به کاربر صریح می‌گوید داده‌ی زنده
// در دسترس نیست — تا صفحه‌ای با داده‌ی قدیمی/خالی بی‌هشدار نماند.
//
// از useSyncExternalStore استفاده می‌کند (نه useState+useEffect): در React 19
// الگوی درست برای اشتراک یک منبع خارجی (navigator.onLine) است و با
// getServerSnapshot از hydration mismatch جلوگیری می‌کند — سرور همیشه
// «آنلاین» فرض می‌شود تا HTML اولیه با کلاینت یکی باشد.
'use client'

import { useSyncExternalStore } from 'react'
import { colors } from '@/lib/styles/tokens'

function subscribeToOnline(callback: () => void) {
  window.addEventListener('online', callback)
  window.addEventListener('offline', callback)
  return () => {
    window.removeEventListener('online', callback)
    window.removeEventListener('offline', callback)
  }
}

function getSnapshot(): boolean {
  return navigator.onLine
}

function getServerSnapshot(): boolean {
  // سرور هیچ‌وقت آفلاین نیست — تا رندر اولیه با هیدریشن یکی بماند.
  return true
}

export default function OfflineBanner() {
  const online = useSyncExternalStore(subscribeToOnline, getSnapshot, getServerSnapshot)
  if (online) return null

  return (
    <div
      role="status"
      aria-live="polite"
      style={{
        position: 'fixed',
        top: 0,
        insetInline: 0,
        zIndex: 9999,
        background: colors.navy,
        color: '#fff',
        fontFamily: "'Vazirmatn', Tahoma, sans-serif",
        fontSize: 13,
        fontWeight: 700,
        textAlign: 'center',
        padding: '8px 16px',
        lineHeight: 1.6,
        boxShadow: '0 1px 6px rgba(0,0,0,0.25)',
        direction: 'rtl',
      }}
    >
      اتصال اینترنت برقرار نیست — داده‌های معاملات، قیمت‌ها و پرداخت‌ها فقط
      آنلاین نمایش داده می‌شوند.
    </div>
  )
}
