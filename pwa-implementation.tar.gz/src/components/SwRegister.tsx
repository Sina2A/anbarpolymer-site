// src/components/SwRegister.tsx
//
// ثبت Service Worker. عمداً در یک کامپوننت کلاینتیِ بدون UI جدا شده تا
// layout.tsx سروری بماند.
//
// گیت‌های ثبت:
//   1. فقط production — در dev ثبت نمی‌کنیم تا کش قدیمی با HMR قاطی نشود.
//   2. فقط secure context (https یا localhost) — مرورگرها SW را روی
//      http معمولی اصلاً نمی‌پذیرند.
//   3. در همه‌ی سطح‌ها (public / admin / transport) ثبت می‌شود: فایل
//      sw.js هم‌منشأ است و منطقش سطح‌آگاه نیست، پس نصب‌شدنی بودن ادمین
//      و حمل‌ونقل هم از همین‌جا می‌آید.
'use client'

import { useEffect } from 'react'
import { SW_URL } from '@/lib/swVersion'

export default function SwRegister() {
  useEffect(() => {
    if (process.env.NODE_ENV !== 'production') return
    if (typeof navigator === 'undefined' || !('serviceWorker' in navigator)) return
    if (!window.isSecureContext) return

    let cancelled = false

    const register = async () => {
      try {
        const reg = await navigator.serviceWorker.register(SW_URL, { scope: '/' })
        // یک SW منتظرِ نصب را بی‌معطلی فعال کن — چون هیچ داده‌ی
        // تراکنشی کش نمی‌شود، فعال‌سازی فوری ریسک داده‌ی قدیمی ندارد.
        if (reg.waiting) reg.waiting.postMessage({ type: 'SKIP_WAITING' })
      } catch {
        // ثبت ناموفق نباید اپ را بشکند؛ سایت بدون SW کامل کار می‌کند.
      }
    }

    // کمی تاخیر تا ثبت SW با بارگذاری اولیه‌ی صفحه رقابت نکند.
    const timer = window.setTimeout(() => {
      if (!cancelled) void register()
    }, 1500)

    return () => {
      cancelled = true
      window.clearTimeout(timer)
    }
  }, [])

  return null
}
