import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

const ADMIN_PATH_PREFIXES = ['/admin-', '/my-tasks']
// /offline باید روی هر سه سطح (public/admin/transport) دسترس‌پذیر بماند،
// وگرنه وقتی کاربر ادمین آفلاین می‌شود به‌جای پیام صریح، /404 می‌بیند.
const ALWAYS_ALLOWED = ['/login', '/logout', '/offline']

export function middleware(request: NextRequest) {
  const surface = process.env.SURFACE === 'admin' ? 'admin' : 'public'
  const { pathname } = request.nextUrl

  if (ALWAYS_ALLOWED.some((p) => pathname === p || pathname.startsWith(p + '/'))) {
    return NextResponse.next()
  }

  const isAdminPath = ADMIN_PATH_PREFIXES.some((p) => pathname.startsWith(p))

  if (surface === 'admin' && !isAdminPath) {
    return NextResponse.rewrite(new URL('/404', request.url))
  }
  if (surface === 'public' && isAdminPath) {
    return NextResponse.rewrite(new URL('/404', request.url))
  }

  return NextResponse.next()
}

export const config = {
  // فایل‌های استاتیک و زیرساخت PWA از middleware مستثنا هستند تا روی
  // هر سه سطح (public/admin/transport) سرو شوند. قبلاً sw.js،
  // manifest.webmanifest، آیکون‌ها، لوگوها و /fonts/* مستثنا نبودند؛
  // روی SURFACE=admin همه‌شان به /404 rewrite می‌شدند — یعنی هم لوگو
  // و هم فونت در سطح ادمین می‌شکست و PWA اصلاً نصب نمی‌شد.
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|uploads|fonts/|sw\\.js|manifest\\.webmanifest|[^/]+\\.(?:png|svg|ico|webp|jpg|jpeg|gif|woff2?|ttf)$).*)',
  ],
}
