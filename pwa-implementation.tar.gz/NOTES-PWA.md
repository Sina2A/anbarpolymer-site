# PWA — NOTES

## خلاصه
سایت به PWA نصب‌شدنی تبدیل شد: `manifest.webmanifest` سطح‌آگاه، Service Worker دست‌نویس default-deny، صفحه‌ی صریح آفلاین، و بنر سراسری آفلاین. هیچ داده‌ی تراکنشی/مالی/قیمت/پرداخت/موجودی کش نمی‌شود و آفلاین هرگز وضعیت قدیمی نشان نمی‌دهد.

## فایل‌های جدید
- `src/app/manifest.ts` — سطح‌آگاه (`SURFACE` → `start_url`): `public`→`/`, `admin`→`/admin-orders`, `transport`→`/transport-panel`. `process.env.SURFACE` استقرار است (نه Request-time API)، پس manifest طبق docs کش‌شدنی می‌ماند.
- `src/lib/swVersion.ts` — تنها منبع حقیقت `ap-v1` (`SW_VERSION` / `SW_URL=/sw.js?v=ap-v1`). چون precache manifest خودکار نداریم، bump دستی لازم است.
- `public/sw.js` — دست‌نویس، ۶ قفل ایمنی (سرصفحه‌ی فایل). `CACHE_VERSION=ap-v1`.
- `src/app/offline/page.tsx` + `src/app/offline/OfflineActions.tsx` — صفحه‌ی کاملاً استاتیک (بدون prisma/cookies/fetch/`dynamic`) + دکمه‌ها: «تلاش دوباره» (`reload`) و «بازگشت» (`history.back()` + fallback به `reload`) — عمداً `router.push('/')` نیست چون `/` روی admin/transport به `/404` می‌رود.
- `src/components/OfflineBanner.tsx` — `useSyncExternalStore` + `getServerSnapshot` (بدون hydration mismatch)، `role="status"` و `aria-live="polite"`.
- `src/components/SwRegister.tsx` — گیت‌ها: `production` + `serviceWorker in navigator` + `isSecureContext`؛ ثبت در همه‌ی سطح‌ها؛ `SKIP_WAITING` به `reg.waiting`.
- `public/icon-192.png`, `icon-512.png`, `icon-maskable-192.png`, `icon-maskable-512.png`, `apple-touch-icon.png` — از `aaaa/pwa-icons.tar.gz`.

## فایل‌های ویرایش‌شده (افزایشی)
- `src/app/layout.tsx` — `Viewport` + `icons.apple` + `OfflineBanner` قبل از `ClientProviders`. بدون `<link rel="manifest">` دستی (Next از `app/manifest.ts` خودکار می‌سازد).
- `src/app/ClientProviders.tsx` — `<SwRegister />` بعد از `children` داخل `LoadingProvider`.
- `middleware.ts` — دو تغییر، بدنه‌ی `middleware()` دست نخورده:
  1. `ALWAYS_ALLOWED` شامل `/offline` شد (وگرنه ادمین آفلاین به‌جای پیام صریح، `/404` می‌دید).
  2. `matcher` منفی‌lookahead: `sw\.js|manifest\.webmanifest|[^/]+\.(?:png|…)` اضافه شد؛ `fonts/` با اسلش انتهایی تا صفحه‌ای به‌نام `fonts*` اشتباهاً مستثنا نشود. توکن `uploads` عیناً حفظ شد.
  - باگ پیشین رفع شد: روی `SURFACE=admin` لوگوهای `/anbarpolymer-logo-*.png`، `/fonts/*`، و اکنون `sw.js`/`manifest.webmanifest`/آیکون‌ها همه به `/404` rewrite می‌شدند — هم لوگو/فونت ادمین می‌شکست و هم PWA اصلاً نصب نمی‌شد.

## رفتار Service Worker (خلاصه)
- فقط دو دسته `event.respondWith` دارند: (الف) asset استاتیک hash‌دار → cache-first (آفلاینِ cache-miss → 504)، (ب) ناوبریِ `PUBLIC_PAGES` → network-first با تایم‌اوت ۴ ثانیه، fallback زنجیره‌ای: کش → `/offline` → HTML ۵۰۳ فارسی inline.
- هر درخواست دیگر (همه‌ی `/api/*`، `/dashboard`، `/my-*`، `/admin-*`، `/transport-panel`، `/driver/*`، auth، `/_next/image`) اصلاً intercept نمی‌شود → NetworkOnly خالص.
- مسیر جدیدی که بعداً اضافه شود به‌طور پیش‌فرض NetworkOnly می‌ماند (جهت امن برای سایت مالی).
- `isCacheableResponse` رد می‌کند: `!ok`، `type !== 'basic'`، هر `Set-Cookie`، `cache-control: no-store|private`.
- URL با query string هرگز کش نمی‌شود؛ `/_next/image` کش نمی‌شود؛ cross-origin دست‌نخورده می‌ماند.
- `install`: `/offline` + scrape آدرس‌های `/_next/static/*` و `/fonts/*` از HTML آن (جایگزین precache manifest). `activate`: حذف کش‌های غیر `ap-v1`. `message`: `{type:'SKIP_WAITING'}`.

## نصب‌شدنی بودن — تأیید ۴ سطح (الزام تحویل)

> هر ۴ سطح باید Add to Home Screen داشته باشند. جدول زیر از بیلد تولیدی و منطق کد استخراج شده و هر سطح جدا تست می‌شود (نه فقط `SURFACE=admin`).

| # | سطح | استقرار | `start_url` (manifest) | `sw.js` سرو می‌شود؟ | آیکون‌ها سرو می‌شوند؟ | `/offline` دسترس‌پذیر؟ | نتیجه نصب |
|---|------|----------|------------------------|----------------------|------------------------|------------------------|------------|
| 1 | صفحات عمومی (مهمان) | `SURFACE=public` (`:3000`) | `/` | بله — matcher `sw.js` را مستثنا می‌کند | بله — matcher `*.png` را مستثنا می‌کند | بله — `ALWAYS_ALLOWED` | ✅ نصب‌شدنی |
| 2 | پنل کاربر لاگین‌شده | `SURFACE=public` (`:3000` + سشن) | `/` | بله (همان استقرار) | بله | بله | ✅ نصب‌شدنی — `SwRegister` در همین استقرار ثبت می‌کند؛ `/dashboard` و `/my-*` هرگز کش نمی‌شوند و آفلاین به `/offline` می‌افتند |
| 3 | پنل ادمین | `SURFACE=admin` (`:3001`) | `/admin-orders` (اولین بخش `isReal` در `src/lib/sections.ts`) | بله — **باگ رفع‌شده**: قبلاً matcher فاقد `sw.js` بود و روی admin به `/404` rewrite می‌شد | بله — **باگ رفع‌شده**: `*.png` و `/fonts/*` قبلاً روی admin به `/404` می‌رفتند | بله — `ALWAYS_ALLOWED` شامل `/offline` شد | ✅ نصب‌شدنی |
| 4 | پنل حمل‌ونقل | `SURFACE=transport` (`:4000`) | `/transport-panel` | بله — matcher `sw.js` را در هر سطح مستثنا می‌کند | بله | بله — `/offline` سطح‌آزاد است | ✅ نصب‌شدنی |

### چگونه بازتولید کنید (production build)
```bash
npx next build   # باید ببینید: ○ /offline  و  ○ /manifest.webmanifest  (هر دو Static)
# سپس روی هر استقرار:
curl -s http://localhost:3000/manifest.webmanifest | grep start_url  # "/"
curl -s http://localhost:3001/manifest.webmanifest | grep start_url  # "/admin-orders"
curl -s http://localhost:4000/manifest.webmanifest | grep start_url  # "/transport-panel"
curl -sI http://localhost:3001/sw.js           | head -1  # 200 (قبل از فیکس: 404)
curl -sI http://localhost:3001/icon-192.png    | head -1  # 200 (قبل از فیکس: 404)
# آفلاین: تب را آفلاین کنید و /dashboard را reload کنید → باید /offline ببینید، نه کش قدیمی
```

## تأیید بیلد
- `npx tsc --noEmit` — صفر خطا.
- `npx next build` — EXIT 0؛ `/offline` → `○ (Static)`، `/manifest.webmanifest` → `○ (Static)`. `/offline` هیچ API داینامیک ندارد، پس با هر دو مدل کش (کلاسیک و Cache Components) استاتیک می‌ماند.
- وابستگی‌های ازپیش‌اعلان‌نشده‌ی `lucide-react`, `@tanstack/react-table@8`, `echarts`, `echarts-for-react` برای بیلد با `--no-save --no-package-lock` نصب شدند؛ `package.json`/`package-lock.json` دست‌نخورده ماندند (بکاپ در `/tmp/pkg.bak`).

## نکات استقرار
- `SURFACE` را در هر محیط درست ست کنید؛ `start_url` اشتباه، نصب را روی `/404` باز می‌کند.
- تغییر assetها بدون bump `src/lib/swVersion.ts` کش قدیمی را زنده نگه می‌دارد.
- `sw.js` با تأخیر ۱۵۰۰ms ثبت می‌شود تا با بارگذاری اولیه رقابت نکند؛ روی `http` غیر-localhost ثبت نمی‌شود (`isSecureContext`).

## محدودیت شناخته‌شده
- چهار وابستگی بالا در `package.json` اعلان نشده‌اند (پیش از این تسک). برای بیلد تمیز باید به `dependencies` اضافه شوند یا issue جداگانه ثبت شود.
