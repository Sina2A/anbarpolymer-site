/* eslint-disable no-restricted-globals */
/**
 * Service Worker دست‌نویس — انبار پلیمر (بدون Serwist/Workbox).
 *
 * اصل طراحی: DEFAULT-DENY. این SW فقط برای دو دسته event.respondWith()
 * صدا می‌زند:
 *   (الف) asset استاتیک (CSS/JS/fonthash‌شده، آیکون، لوگو) → cache-first
 *   (ب) ناوبریِ صفحات عمومیِ غیرتراکنشی            → network-first
 * هر درخواست دیگری — شامل همه‌ی /api/*، صفحات معامله، ادمین، حمل‌ونقل،
 * auth و قیمت — اصلاً intercept نمی‌شود و رفتار خالص شبکه دارد.
 *
 * این جهت‌گیری عمدی است: مسیر جدیدی که بعداً اضافه شود به‌طور پیش‌فرض
 * NetworkOnly می‌ماند، نه اینکه با یک matcher باز کش شود. برای یک سایت
 * تراکنشی/مالی، «کش نشدن ناخواسته» باید حالت پیش‌فرض باشد.
 *
 * ⚠️ قفل‌های ایمنی (همه لازم‌اند):
 *   1. NEVER_CACHE قبل از هر منطق دیگری بررسی می‌شود.
 *   2. پاسخ دارای Set-Cookie هرگز در کش نوشته نمی‌شود (HTML شخصی‌سازی‌شده).
 *   3. پاسخ !ok هرگز کش نمی‌شود.
 *   4. URL با query string هرگز کش نمی‌شود (توکن/ID اغلب آنجاست).
 *   5. /_next/image کش نمی‌شود — پراکسی تصویر است و ممکن است محتوای
 *      خصوصی را با URL پارامتری سرو کند.
 *   6. پاسخ cross-origin دست‌نخورده می‌ماند (opaque cache نشود).
 *
 * نسخه: با src/lib/swVersion.ts همگام نگه داشته شود. تغییر asset‌ها
 * بدون bump نسخه، کش قدیمی را زنده نگه می‌دارد.
 */

const CACHE_VERSION = 'ap-v1'
const STATIC_CACHE = CACHE_VERSION + '-static'
const PAGES_CACHE = CACHE_VERSION + '-pages'

/**
 * denylist صریح — هرگز کش نمی‌شوند، حتی اگر اشتباهاً یک matcher عمومی
 * روی آن‌ها صدازده شود. این فهرست قبل از همه‌چیز بررسی می‌شود.
 */
const NEVER_CACHE_PREFIXES = [
  '/api/', // همه‌ی ۷ route فعلی: exchange-rates, material-listings, payment-receipt, ...
  '/dashboard',
  '/my-', // my-deals, my-orders, my-listings, my-requests, my-tasks
  '/admin-', // ۱۹ صفحه‌ی ادمین
  '/transport-panel',
  '/driver/',
  '/login',
  '/logout',
  '/signup',
  '/account',
  '/proformas',
  '/verification',
  '/custom-request',
  '/new-listing',
  '/price-alerts',
  '/forgot-password',
  '/support',
  '/sw.js',
  '/manifest.webmanifest',
  '/_next/image', // پراکسی تصویر — پارامتری و بالقوه خصوصی
]

/**
 * allowlist صریحِ تنها صفحاتی که ممکن است آفلاین از کش سرو شوند.
 * همه‌ی این‌ها عمومی و غیرتراکنشی‌اند و هیچ‌کدام قیمت/معامله‌ی زنده
 * در HTML اولیه‌ی کش‌شدنی خود ندارند (داده‌ی زنده از /api/* می‌آید که
 * NetworkOnly است). '/offline' هم اینجاست تا خودش قابل سرو باشد.
 */
const PUBLIC_PAGES = [
  '/',
  '/about',
  '/contact',
  '/grades',
  '/market',
  '/warehouses',
  '/services',
  '/rfq',
  '/reports',
  '/offline',
]

/** تنها assetهایی که cache-first می‌شوند. */
const STATIC_DESTINATIONS = ['style', 'script', 'font', 'image', 'worker']
const STATIC_PATH_PREFIXES = ['/_next/static/', '/fonts/']
const STATIC_EXT = /\.(?:png|svg|ico|webp|jpg|jpeg|gif|woff2?|ttf|css|js|map)$/

function isNeverCache(pathname) {
  return NEVER_CACHE_PREFIXES.some(function (p) {
    return pathname.startsWith(p)
  })
}

function isPublicPage(pathname) {
  return PUBLIC_PAGES.some(function (p) {
    return pathname === p || pathname.startsWith(p + '/')
  })
}

function isStaticAsset(request, url) {
  if (url.pathname.startsWith('/_next/static/')) return true
  if (STATIC_PATH_PREFIXES.some(function (p) { return url.pathname.startsWith(p) })) return true
  if (STATIC_DESTINATIONS.indexOf(request.destination) !== -1) {
    return STATIC_EXT.test(url.pathname)
  }
  return STATIC_EXT.test(url.pathname) && request.destination === ''
}

/**
 * آیا پاسخ امن است که در کش نوشته شود؟
 * Set-Cookie یعنی HTML شخصی‌سازی‌شده — برای سایت مالی هرگز کش نشود.
 */
function isCacheableResponse(response) {
  if (!response || !response.ok) return false
  if (response.type !== 'basic') return false // opaque / cors را نکش
  if (response.headers.has('set-cookie')) return false
  const cc = response.headers.get('cache-control') || ''
  if (/no-store|private/i.test(cc)) return false
  return true
}

/** asset‌های hash‌دارِ یک صفحه‌ی HTML را پیدا و precache کن. */
async function precachePageAssets(path) {
  try {
    const res = await fetch(path, { credentials: 'same-origin' })
    if (!res.ok) return
    const html = await res.text()
    const re = /(?:\/_next\/static\/|\/fonts\/)[^"'\s)<>]+/g
    const found = html.match(re) || []
    const uniq = Array.from(new Set(found))
    if (!uniq.length) return
    const cache = await caches.open(STATIC_CACHE)
    await Promise.all(
      uniq.map(function (u) {
        // cache.add به‌تنهایی خطا را می‌بلعد؛ یک asset ناموفق نباید
        // کل precache را بشکند.
        return cache.add(u).catch(function () { /* نادیده */ })
      })
    )
  } catch (e) {
    // صفحه هنوز build نشده یا آفلاین — نصب را نمی‌شکنیم.
  }
}

self.addEventListener('install', function (event) {
  event.waitUntil(
    (async function () {
      const cache = await caches.open(PAGES_CACHE)
      // پوسته‌ی آفلاین باید قبل از هر قطعی شبکه در کش باشد.
      try {
        await cache.add('/offline')
      } catch (e) {
        // اگر /offline در دسترس نبود، نصب را شکست نده؛ SW همچنان
        // برای assetهای استاتیک مفید است.
      }
      await precachePageAssets('/offline')
      await self.skipWaiting()
    })()
  )
})

/**
 * SwRegister.tsx برای فعال‌سازی فوری یک SW منتظر این پیام را می‌فرستد.
 * چون هیچ داده‌ی تراکنشی کش نمی‌شود، فعال‌سازی فوری ریسک نمایش داده‌ی
 * قدیمی ندارد.
 */
self.addEventListener('message', function (event) {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting()
  }
})

self.addEventListener('activate', function (event) {
  event.waitUntil(
    (async function () {
      const keys = await caches.keys()
      await Promise.all(
        keys
          .filter(function (k) { return k.indexOf(CACHE_VERSION) !== 0 })
          .map(function (k) { return caches.delete(k) })
      )
      await self.clients.claim()
    })()
  )
})

/** network-first با timeout؛ fallback به کش و سپس /offline. */
async function networkFirst(request) {
  const url = new URL(request.url)
  try {
    const response = await Promise.race([
      fetch(request),
      new Promise(function (_, reject) {
        setTimeout(function () { reject(new Error('sw-timeout')) }, 4000)
      }),
    ])
    if (isCacheableResponse(response)) {
      const cache = await caches.open(PAGES_CACHE)
      // put را منتظر نمی‌شویم تا پاسخ سریع‌تر برسد.
      cache.put(request, response.clone()).catch(function () { /* نادیده */ })
    }
    return response
  } catch (e) {
    // شبکه نیست یا timeout — هرگز داده‌ی کش‌شده‌ی یک صفحه‌ی تراکنشی را
    // نشان نمی‌دهیم. چون اینجا فقط PUBLIC_PAGES می‌رسند، کش امن است.
    const cached = await caches.match(request, { ignoreSearch: false })
    if (cached) return cached
    const offline = await caches.match('/offline')
    if (offline) return offline
    // آخرین راه: یک پاسخ متنی صریح، نه صفحه‌ی خالی بی‌هشدار.
    return new Response(
      '<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8">' +
      '<title>آفلاین — انبار پلیمر</title>' +
      '<body style="font-family:Vazirmatn,Tahoma,sans-serif;background:#f7f8fa;' +
      'display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0">' +
      '<div style="text-align:center;padding:24px"><h1 style="color:#1e357b">' +
      'اتصال اینترنت برقرار نیست</h1>' +
      '<p style="color:#697386">اطلاعات معاملات، قیمت‌ها و وضعیت پرداخت‌ها ' +
      'فقط در حالت آنلاین قابل‌مشاهده است.</p></div></body></html>',
      { status: 503, statusText: 'Offline', headers: { 'content-type': 'text/html; charset=utf-8' } }
    )
  }
}

self.addEventListener('fetch', function (event) {
  const request = event.request

  // فقط GET؛ POST/PUT/PATCH/DELETE (معاملات، پرداخت) هرگز کش نمی‌شوند.
  if (request.method !== 'GET') return

  let url
  try {
    url = new URL(request.url)
  } catch (e) {
    return
  }

  // cross-origin → دست نمی‌زنیم (opaque cache نشود).
  if (url.origin !== self.location.origin) return

  // قفل ۱: denylist صریح، قبل از هر چیز.
  if (isNeverCache(url.pathname)) return

  // قفل ۴: URL با query string کش نمی‌شود (توکن/فیلتر/ID).
  const hasQuery = url.search !== ''

  // --- asset استاتیک: cache-first ---
  if (isStaticAsset(request, url)) {
    if (hasQuery) return // asset پارامتری → شبکه
    event.respondWith(
      (async function () {
        const hit = await caches.match(request)
        if (hit) return hit
        try {
          const response = await fetch(request)
          if (isCacheableResponse(response)) {
            const cache = await caches.open(STATIC_CACHE)
            cache.put(request, response.clone()).catch(function () { /* نادیده */ })
          }
          return response
        } catch (e) {
          // asset استاتیک آفلاین و بدون کش — پاسخ 504 صریح بهتر از
          // hang کردن است؛ مرورگر خطای خودش را نشان می‌دهد.
          return new Response('', { status: 504, statusText: 'Offline asset' })
        }
      })()
    )
    return
  }

  // --- ناوبری: فقط صفحات عمومیِ allowlist، بدون query ---
  if (request.mode === 'navigate') {
    if (hasQuery) return           // ناوبری پارامتری → شبکه‌ی خالص
    if (!isPublicPage(url.pathname)) return // تراکنشی/ادمین/ناشناس → شبکه‌ی خالص
    event.respondWith(networkFirst(request))
    return
  }

  // هر چیز دیگر: بدون respondWith → رفتار خالص شبکه.
})
