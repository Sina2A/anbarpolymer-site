import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getUserKycLevel } from '@/lib/kyc'
import KycStatusBanner from '@/components/KycStatusBanner'
import UserNav from '@/components/UserNav'

export const dynamic = 'force-dynamic'

export default async function DashboardPage() {
  const user = await getCurrentUser()
  const kycLevel = await getUserKycLevel(user.id)

  // کارت‌های آماری — شمارش واقعی
  const [orderCount, activeListingsCount, pendingPurchaseReqs, inTransitDeals, openTickets] = await Promise.all([
    prisma.order.count({ where: { userId: user.id } }),
    prisma.materialListing.count({ where: { userId: user.id, validityStatus: 'active' } }),
    prisma.purchaseRequest.count({ where: { userId: user.id, status: 'open' } }),
    prisma.deal.count({
      where: {
        status: 'in_transit',
        OR: [{ buyerId: user.id }, { materialListing: { userId: user.id } }],
      },
    }),
    prisma.supportTicket.count({ where: { userId: user.id, status: { not: 'closed' } } }),
  ])

  // سفارش‌های اخیر
  const recentOrders = await prisma.order.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    take: 5,
    include: { items: { include: { grade: true } } },
  })

  // محموله‌های در حال حمل
  const transitDeals = await prisma.deal.findMany({
    where: {
      status: 'in_transit',
      OR: [{ buyerId: user.id }, { materialListing: { userId: user.id } }],
    },
    orderBy: { updatedAt: 'desc' },
    take: 3,
    include: { materialListing: { include: { grade: true } } },
  })

  // تیکت‌های اخیر
  const recentTickets = await prisma.supportTicket.findMany({
    where: { userId: user.id, status: { not: 'closed' } },
    orderBy: { updatedAt: 'desc' },
    take: 3,
  })

  return (
    <div style={pageStyle}>
      <div style={{ maxWidth: 1100, margin: '0 auto', display: 'flex', gap: 24 }} className="admin-page-wrap">
        <UserNav currentUserName={user.companyName} activeSection="dashboard" />
        <div style={{ flex: 1, minWidth: 0 }}>
          <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>داشبورد</h1>
          <p style={{ fontSize: 13, color: '#9199a3', marginBottom: 20 }}>
            نمای کلی فعالیت‌های شما در انبار پلیمر
          </p>

          <KycStatusBanner level={kycLevel} />

          {/* کارت‌های آماری */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 14, marginBottom: 20 }}>
            <div style={statCardStyle}>
              <div style={{ fontSize: 11, color: '#6f7680', marginBottom: 4 }}>سفارش‌های فعال</div>
              <div style={{ fontSize: 26, fontWeight: 800, color: '#1e357b' }}>{orderCount}</div>
            </div>
            <div style={statCardStyle}>
              <div style={{ fontSize: 11, color: '#6f7680', marginBottom: 4 }}>آگهی‌های فعال</div>
              <div style={{ fontSize: 26, fontWeight: 800, color: '#e65716' }}>{activeListingsCount}</div>
            </div>
            <div style={statCardStyle}>
              <div style={{ fontSize: 11, color: '#6f7680', marginBottom: 4 }}>درخواست‌های خرید باز</div>
              <div style={{ fontSize: 26, fontWeight: 800, color: '#92400e' }}>{pendingPurchaseReqs}</div>
            </div>
          </div>

          {/* سفارش‌های اخیر */}
          <div style={cardStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <b style={{ fontSize: 14 }}>سفارش‌های اخیر</b>
              <a href="/my-orders" style={linkStyle}>همه →</a>
            </div>
            {recentOrders.length === 0 ? (
              <div style={emptyStyle}>هیچ سفارشی ثبت نشده.</div>
            ) : (
              <div>
                {recentOrders.map((o) => (
                  <div key={o.id} style={listItemStyle}>
                    <div>
                      <b style={{ fontSize: 12.5, fontFamily: 'monospace' }}>#{o.id.slice(0, 8)}</b>
                      <span style={{ fontSize: 11, color: '#9199a3', marginRight: 8 }}>
                        {o.items.length} قلم — {new Date(o.createdAt).toLocaleDateString('fa-IR')}
                      </span>
                    </div>
                    <span style={statusBadge(o.status)}>{translateOrderStatus(o.status)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* محموله‌های در حال حمل */}
          <div style={cardStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <b style={{ fontSize: 14 }}>محموله‌های در حال حمل</b>
              {inTransitDeals > 0 && <a href="/transport" style={linkStyle}>ردیابی →</a>}
            </div>
            {transitDeals.length === 0 ? (
              <div style={emptyStyle}>هیچ محموله‌ای در حال حمل نیست.</div>
            ) : (
              <div>
                {transitDeals.map((d) => (
                  <div key={d.id} style={listItemStyle}>
                    <div>
                      <b style={{ fontSize: 12.5 }}>{d.materialListing?.grade.code ?? 'محموله'}</b>
                      <span style={{ fontSize: 11, color: '#9199a3', marginRight: 8 }}>
                        {d.quantity} — {new Date(d.updatedAt).toLocaleDateString('fa-IR')}
                      </span>
                    </div>
                    <span style={{ ...statusBadge('in_transit'), background: '#fef3c7', color: '#92400e' }}>در مسیر</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* تیکت‌های پشتیبانی */}
          <div style={cardStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <b style={{ fontSize: 14 }}>تیکت‌های پشتیبانی</b>
              <a href="/support" style={linkStyle}>همه →</a>
            </div>
            {recentTickets.length === 0 ? (
              <div style={emptyStyle}>تیکت بازی ندارید.</div>
            ) : (
              <div>
                {recentTickets.map((t) => (
                  <div key={t.id} style={listItemStyle}>
                    <div>
                      <b style={{ fontSize: 12.5 }}>{t.subject}</b>
                      <span style={{ fontSize: 11, color: '#9199a3', marginRight: 8 }}>
                        {new Date(t.createdAt).toLocaleDateString('fa-IR')}
                      </span>
                    </div>
                    <span style={statusBadge(t.status)}>{translateTicketStatus(t.status)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

// ── ترجمه ────────────────────────────────────────────────────────────
function translateOrderStatus(status: string): string {
  const map: Record<string, string> = {
    pending: 'در انتظار',
    priced: 'قیمت‌گذاری‌شده',
    confirmed: 'تایید‌شده',
    completed: 'تکمیل‌شده',
    cancelled: 'لغو‌شده',
  }
  return map[status] ?? status
}

function translateTicketStatus(status: string): string {
  const map: Record<string, string> = {
    open: 'باز',
    answered: 'پاسخ‌داده‌شده',
    closed: 'بسته',
  }
  return map[status] ?? status
}

// ── استایل‌ها ──────────────────────────────────────────────────────────
function statusBadge(status: string): React.CSSProperties {
  let bg = '#f1efe8'
  let color = '#4f5560'

  if (['confirmed', 'active', 'paid', 'completed', 'answered'].includes(status)) {
    bg = '#d1fae5'
    color = '#065f46'
  } else if (['in_transit', 'priced', 'open'].includes(status)) {
    bg = '#fef3c7'
    color = '#92400e'
  } else if (['cancelled'].includes(status)) {
    bg = '#fee2e2'
    color = '#991b1b'
  }

  return {
    fontSize: 10,
    fontWeight: 700,
    background: bg,
    color: color,
    borderRadius: 6,
    padding: '3px 8px',
    display: 'inline-block',
  }
}

const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: '#faf8f4',
  padding: '32px 20px',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const statCardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 18,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const cardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 18,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
  marginBottom: 14,
}
const emptyStyle: React.CSSProperties = { fontSize: 12, color: '#9199a3', padding: '12px 0' }
const listItemStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  padding: '10px 0',
  borderBottom: '1px solid #f1efe8',
}
const linkStyle: React.CSSProperties = { fontSize: 12, color: '#1e357b', textDecoration: 'none', fontWeight: 600 }
