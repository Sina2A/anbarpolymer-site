'use server'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'

export async function submitCustomRfqAction(formData: FormData) {
  const user = await getCurrentUser()

  const polymerType = formData.get('polymerType') as string
  const mfiRangeMin = formData.get('mfiRangeMin') as string
  const mfiRangeMax = formData.get('mfiRangeMax') as string
  const densityMin = formData.get('densityMin') as string
  const densityMax = formData.get('densityMax') as string
  const quantityTon = formData.get('quantityTon') as string
  const requirements = formData.get('requirements') as string
  const suggestedGradeCode = formData.get('suggestedGradeCode') as string

  if (!polymerType || !quantityTon) {
    throw new Error('نوع پلیمر و مقدار درخواستی الزامی است')
  }

  const qty = parseFloat(quantityTon)
  if (isNaN(qty) || qty <= 0) {
    throw new Error('مقدار درخواستی باید عدد مثبت باشد')
  }

  await prisma.customRfq.create({
    data: {
      userId: user.id,
      polymerType,
      mfiRangeMin: mfiRangeMin ? parseFloat(mfiRangeMin) : null,
      mfiRangeMax: mfiRangeMax ? parseFloat(mfiRangeMax) : null,
      densityMin: densityMin ? parseFloat(densityMin) : null,
      densityMax: densityMax ? parseFloat(densityMax) : null,
      quantityTon: qty,
      requirements: requirements || null,
      suggestedGradeCode: suggestedGradeCode || null,
      status: 'open',
    },
  })

  revalidatePath('/custom-request')
  redirect('/custom-request')
}