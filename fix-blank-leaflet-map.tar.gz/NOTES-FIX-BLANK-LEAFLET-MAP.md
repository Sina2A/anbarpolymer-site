# NOTES — رفع نقشه‌ی Leaflet خالی/سفید (افزودن leaflet.css)

## علامت
- `/warehouses` و فرمِ `admin-warehouses` (`LocationPicker`): جعبه‌ی نقشه کاملاً سفید،
  هیچ کاشیِ OSM دیده نمی‌شد، **بدون هیچ پیام خطا**.
- مقادیرِ `Latitude`/`Longitude` زیرِ نقشه درست پر می‌شدند (۳۱.۸۱۶۲۴۴ / ۵۴.۴۵۸۵۶۳) —
  یعنی داده و منطق سالم بود، فقط رندرِ بصریِ نقشه خراب.

## علت واقعی (فرضیه‌ی CSS — **تایید شد**)
Leaflet برای جای‌گیریِ کاشی‌ها و لایه‌ها به CSS پایه‌ی خودش تکیه می‌کند:
کلاس‌های `.leaflet-container` / `.leaflet-pane` / `.leaflet-tile` / `.leaflet-tile-container`
با `position:absolute` و `transform` چیده می‌شوند. بدونِ `leaflet.css`، کاشی‌ها در DOM
حاضر‌اند ولی با موقعیت/ابعادِ درهم روی هم می‌افتند → جعبه‌ی سفیدِ خالی، بدون خطا.

شواهدِ تایید:
- grep: `leaflet.css` هیچ‌جای پروژه import **نشده بود**.
- مستند رسمی react-leaflet (start-setup): **«Make sure Leaflet's CSS is loaded»** —
  یکی از سه پیش‌نیازِ نمایشِ درست.
- `node_modules/leaflet/dist/leaflet.css` موجود بود (۱۴٬۸۰۶ بایت، شاملِ قواعدِ positioning).

## چرا تصمیمِ قبلیِ «بدون leaflet.css» اشتباه بود
در تسکِ revert فرض شد `TransportMap.tsx` بدونِ CSS کار می‌کند. در واقع `TransportMap`
هم همین باگِ نهفته را داشت — فقط دیده نشده بود چون پشتِ گیتِ «معاملاتِ in_transit» و یک
آکاردئونِ `<details>`ِ جمع‌شده است، پس عملاً کسی کاشیِ واقعی‌اش را باز نکرده بود.

## تغییرات

### `src/app/layout.tsx` — اصلِ رفع
افزودنِ یک importِ سراسری (کنارِ `./globals.css`):
```ts
import 'leaflet/dist/leaflet.css'
```
- یک import در ریشه، **هر سه** کامپوننتِ نقشه را هم‌زمان درست می‌کند:
  `WarehousesMap`، `LocationPicker`/`LocationPickerMap`، و `TransportMap`.
- `layout.tsx` یک Server Component است؛ چون این فقط CSS است (نه کدِ وابسته به `window`)،
  importِ سراسری امن است و SSR را نمی‌شکند. (خودِ کامپوننت‌های نقشه همچنان `ssr:false` می‌مانند.)

### `src/components/WarehousesMap.tsx` و `src/components/LocationPickerMap.tsx`
فقط اصلاحِ کامنت‌های گمراه‌کننده‌ی «بدون leaflet.css» تا با واقعیت هم‌خوان شوند.
هیچ تغییرِ رفتاری/کدی نداشتند.

## نکته درباره‌ی آیکنِ مارکر
آیکنِ پیش‌فرضِ مارکرِ Leaflet در باندلرها مسیرِ تصویرش می‌شکند. چون ما از `CircleMarker`
(SVG) استفاده می‌کنیم، این باگ اصلاً ما را ندارد — نیازی به patchِ آیکن نبود.

## راستی‌آزمایی (اجراشده)
- `npx tsc --noEmit` → **EXIT 0**
- `npx next build` → **EXIT 0**
- تاییدِ باندل: چانکِ CSSِ خروجی (`.next/static/chunks/*.css`) شاملِ **۶۹ کلاسِ `leaflet-*`**
  از جمله قاعده‌ی حیاتیِ `.leaflet-tile,.leaflet-tile-container,... { position:absolute }` است.

---

## محتوای این بسته
```
NOTES-FIX-BLANK-LEAFLET-MAP.md       (همین فایل)
src/app/layout.tsx                    (افزودن import 'leaflet/dist/leaflet.css')
src/components/WarehousesMap.tsx      (فقط کامنت)
src/components/LocationPickerMap.tsx  (فقط کامنت)
```

## نحوه‌ی اعمال روی مخزن
```bash
tar -xzf fix-blank-leaflet-map.tar.gz
npx tsc --noEmit
npx next build
```
> پیش‌نیاز: بسته‌ی revert-to-leaflet قبلاً اعمال شده باشد (leaflet/react-leaflet نصب باشند).
> این بسته چیزی به package.json اضافه نمی‌کند؛ `leaflet` از قبل اعلام‌شده است.
