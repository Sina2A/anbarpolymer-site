import type { Metadata, Viewport } from 'next'
import './globals.css'
// CSS پایه‌ی Leaflet — لازم برای جای‌گیری درستِ کاشی‌ها/لایه‌ها (position/transform).
// بدون آن، نقشه به‌صورت جعبه‌ی سفیدِ خالی رندر می‌شود. یک import سراسری، هر سه کامپوننتِ
// نقشه (WarehousesMap، LocationPicker/LocationPickerMap، TransportMap) را پوشش می‌دهد.
import 'leaflet/dist/leaflet.css'
import ClientProviders from './ClientProviders'
import OfflineBanner from '@/components/OfflineBanner'
import CookieNotice from '@/components/CookieNotice'

export const metadata: Metadata = {
  title: 'انبار پلیمر',
  icons: {
    apple: '/apple-touch-icon.png',
  },
}

/**
 * viewport جدا از metadata است — در Next 16 themeColor زیر viewport می‌رود،
 * نه metadata. مقدار ثابت است تا رندر استاتیک layout نشکند.
 * navy برند از src/lib/styles/tokens.ts: colors.navy = '#1e357b'.
 */
export const viewport: Viewport = {
  themeColor: '#1e357b',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="fa" dir="rtl">
      <body>
        {/* بنر سراسری آفلاین — وقتی آنلاین است چیزی رندر نمی‌کند */}
        <OfflineBanner />
        <CookieNotice />
        <ClientProviders>
          {children}
        </ClientProviders>
      </body>
    </html>
  )
}
