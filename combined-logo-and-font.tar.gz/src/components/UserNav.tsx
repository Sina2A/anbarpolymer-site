import { logoutAction } from '@/app/logout/actions'
import { SidebarBrand } from '@/components/BrandMark'
import {
  sidebarStyle,
  sidebarGroupTitleStyle,
  sidebarItemStyle,
  sidebarComingSoonBadgeStyle,
} from '@/lib/styles/shared'
import { colors } from '@/lib/styles/tokens'
import type { CSSProperties } from 'react'

// ──────────────────────────────────────────────────────────
// گروه‌بندی منوی کاربری
// ──────────────────────────────────────────────────────────
const MENU_GROUPS: { title: string; items: Item[] }[] = [
  {
    title: '',
    items: [
      { key: 'dashboard', label: 'پیشخوان', href: '/dashboard', isReal: true },
    ],
  },
  {
    title: 'بازرگانی',
    items: [
      { key: 'requests', label: 'درخواست‌های خرید من', href: '/my-requests', isReal: true },
      { key: 'purchase-requests', label: 'اعلام نیاز خرید (بازار)', href: '/purchase-requests', isReal: true },
      { key: 'orders', label: 'سفارش‌های من', href: '/my-orders', isReal: true },
      { key: 'proformas', label: 'پیش‌فاکتورهای من', href: '/proformas', isReal: true },
      { key: 'listings', label: 'شبکه عرضه مواد اولیه من', href: '/my-listings', isReal: true },
      { key: 'deals', label: 'معاملات من', href: '/my-deals', isReal: true },
      { key: 'transport', label: 'حمل و نقل', href: '/transport', isReal: true },
    ],
  },
  {
    title: 'حساب و پشتیبانی',
    items: [
      { key: 'verification', label: 'احراز هویت', href: '/verification', isReal: true },
      { key: 'rfq', label: 'استعلام قیمت', href: '/rfq', isReal: true },
      { key: 'account', label: 'ویرایش حساب کاربری', href: '/account', isReal: true },
      { key: 'custom-request', label: 'درخواست محصول غیرکاتالوگی', href: '/custom-request', isReal: true },
      { key: 'price-alerts', label: 'هشدار قیمت', href: '#', isReal: false },
      { key: 'support', label: 'پشتیبانی', href: '/support', isReal: true },
    ],
  },
]

type Item = {
  key: string
  label: string
  href: string
  isReal: boolean
}

export default function UserNav({
  currentUserName,
  activeSection,
}: {
  currentUserName: string
  activeSection?: string
}) {
  const initial = currentUserName?.trim()?.charAt(0) || '?'

  return (
    <div style={sidebarStyle}>
      <SidebarBrand />
      <div style={userBoxStyle}>
        <div style={avatarStyle}>{initial}</div>
        <div>
          <div style={userNameStyle}>{currentUserName}</div>
          <div style={userRoleStyle}>پنل بازرگانی</div>
        </div>
      </div>

      <nav style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {MENU_GROUPS.map((group, gi) => (
          <div key={group.title || gi}>
            {group.title && <div style={sidebarGroupTitleStyle}>{group.title}</div>}
            {group.items.map((item) => {
              if (!item.isReal) {
                return (
                  <span
                    key={item.key}
                    style={{
                      ...sidebarItemStyle(false),
                      color: colors.textMuted,
                      cursor: 'default',
                    }}
                    title="هنوز صفحه‌ی این بخش ساخته نشده"
                  >
                    {item.label}
                    <span style={sidebarComingSoonBadgeStyle}>به‌زودی</span>
                  </span>
                )
              }

              return (
                <a
                
                  key={item.key}
                  href={item.href}
                  style={sidebarItemStyle(item.key === activeSection)}
                >
                  {item.label}
                </a>
              )
            })}
          </div>
        ))}
      </nav>

      <div style={dividerStyle} />
      <form action={logoutAction}>
        <button
          type="submit"
          style={{
            ...sidebarItemStyle(false),
            color: colors.dangerText,
            cursor: 'pointer',
            width: '100%',
            textAlign: 'right' as const,
            background: 'transparent',
            border: 'none',
            fontFamily: 'inherit',
          }}
        >
          خروج از حساب
        </button>
      </form>
    </div>
  )
}

const userBoxStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 12,
  paddingBottom: 20,
  marginBottom: 20,
  borderBottom: `1px solid ${colors.borderSubtle}`,
}

const avatarStyle: CSSProperties = {
  width: 44,
  height: 44,
  borderRadius: '50%',
  background: colors.navy,
  color: '#fff',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontWeight: 700,
  fontSize: 16,
  flexShrink: 0,
}

const userNameStyle: CSSProperties = {
  fontWeight: 700,
  fontSize: 15,
  color: colors.navy,
}

const userRoleStyle: CSSProperties = {
  fontSize: 12,
  color: colors.textMuted,
}

const dividerStyle: CSSProperties = {
  height: 1,
  background: colors.borderSubtle,
  margin: '10px 0',
}
