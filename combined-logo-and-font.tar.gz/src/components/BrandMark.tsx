import type { CSSProperties } from 'react'

const coinBase: CSSProperties = {
  background: '#fff',
  borderRadius: '50%',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  flexShrink: 0,
}

export function BrandCoin({ coin = 34, mark = 24 }: { coin?: number; mark?: number }) {
  return (
    <span
      style={{ ...coinBase, width: coin, height: coin }}
      aria-hidden="true"
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src="/anbarpolymer-logo-icon.png"
        alt=""
        aria-hidden="true"
        width={mark}
        height={mark}
        style={{ width: mark, height: mark, objectFit: 'contain', display: 'block' }}
      />
    </span>
  )
}

export function SidebarBrand() {
  return (
    <>
      <a
        href="/"
        style={{
          display: 'flex',
          justifyContent: 'center',
          padding: '6px 0 12px',
        }}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/anbarpolymer-logo-full.png"
          alt="انبار پلیمر"
          style={{ width: '100%', maxWidth: 190, height: 'auto', display: 'block' }}
        />
      </a>
      <div style={{ height: 1, background: '#e3e8ee', marginBottom: 10 }} />
    </>
  )
}
