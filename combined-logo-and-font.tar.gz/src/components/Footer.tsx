// فوتر مشترک کل سایت — نسخهی ۴ستونهی نارنجی (منبع: contact/page.tsx).
// همهی صفحات عمومی و پنل از همین کامپوننت استفاده میکنن؛ هیچ نسخهی دوم/سادهشدهای وجود نداره.
// سال کپیرایت طبق رفتار فعلی فوتر اصلی ثابته (۱۴۰۵) — عمداً از new Date() استفاده نمیشه.
import { BrandCoin } from '@/components/BrandMark'

export default function Footer() {
  return (
    <footer className="site-footer">
      <div className="wrap">
        <div className="footer-cols">
          <div>
            <a href="/" className="logo" style={{ marginBottom: 14, display: 'flex' }}>
              <BrandCoin /> انبار پلیمر
            </a>
            <p style={{ color: 'var(--ink-dim)', fontSize: 13, maxWidth: 280 }}>
              واردکننده و فروشنده مستقیم مواد اولیه پلیمری برای کارخانه‌های تولیدی سراسر کشور.
            </p>
          </div>
          <div>
            <h5>محصولات</h5>
            <ul>
              <li><a href="/grades">پلی‌پروپیلن</a></li>
              <li><a href="/grades">پلی‌اتیلن</a></li>
              <li><a href="/grades">پی‌وی‌سی</a></li>
              <li><a href="/grades">پلی‌اتیلن ترفتالات</a></li>
            </ul>
          </div>
          <div>
            <h5>خدمات</h5>
            <ul>
              <li><a href="/rfq">استعلام قیمت آنلاین</a></li>
              <li><a href="/market">بازار صنعتی</a></li>
              <li><a href="/services">فروش سازمانی</a></li>
              <li><a href="/reports">گزارش بازار</a></li>
            </ul>
          </div>
          <div>
            <h5>اطلاعات تماس</h5>
            <ul>
              <li>تهران، خیابان ولیعصر، پلاک ۱۲۴</li>
              <li>انبار یزد — شهرک صنعتی یزد</li>
              <li style={{ direction: 'ltr', textAlign: 'right' }}>021-91234567</li>
            </ul>
          </div>
        </div>
        <div className="footer-bottom">
          <span>انبار پلیمر © ۱۴۰۵ — تمام حقوق محفوظ است</span>
        </div>
      </div>
    </footer>
  )
}