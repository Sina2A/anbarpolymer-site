'use server'

import prisma from '@/lib/prisma'
import { verifyPassword, createSession } from '@/lib/auth'
import { redirect } from 'next/navigation'

export async function loginAction(prevState: { error: string }, formData: FormData) {
  const identifier = String(formData.get('identifier') || '').trim()
  const password = String(formData.get('password') || '')

  if (!identifier || !password) {
    return { error: 'نام کاربری/شماره تماس و رمز عبور رو وارد کن.' }
  }

  // کاربر می‌تونه با username (کارشناس/مدیر) یا phone (خریدار) وارد بشه
  const user = await prisma.user.findFirst({
    where: { OR: [{ username: identifier }, { phone: identifier }] },
  })

  if (!user || !user.isActive) {
    return { error: 'نام کاربری یا رمز عبور اشتباهه.' }
  }

  const passwordOk = verifyPassword(password, user.passwordHash)
  if (!passwordOk) {
    return { error: 'نام کاربری یا رمز عبور اشتباهه.' }
  }

  await createSession(user.id)
  // توجه: /dashboard هنوز واقعی نیست (dashboard.html استاتیکه) — قبلاً این
  // خط مستقیم به /dashboard می‌فرستاد که یعنی خریدارها بعد از ورود موفق به
  // ۴۰۴ می‌خوردن. فعلاً به /my-orders (که واقعیه) می‌فرستیم؛ هروقت
  // dashboard.html مهاجرت کرد، این خط رو برگردون.
  redirect(user.role === 'buyer' ? '/my-orders' : '/admin-users')
}
