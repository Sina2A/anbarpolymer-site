// scripts/check-routes.mjs
//
// بررسی سلامت مسیرها + اتصال منوها — بدون مرورگر، فقط با fs + http داخلی Node.
// اجرا: node scripts/check-routes.mjs
//
// چیکار می‌کنه:
// ۱. از src/app لیست همه‌ی مسیرهای واقعی (که page.tsx دارن) رو می‌سازه.
// ۲. از src/lib/sections.ts (منوی ادمین) و src/components/UserNav.tsx
//    (منوی کاربری) و همه‌ی page.tsx های عمومی، لینک‌های href رو استخراج می‌کنه.
// ۳. چک می‌کنه هر لینک منو به یه مسیر واقعی موجود اشاره می‌کنه یا نه.
// ۴. برای هر مسیر واقعی (غیرپویا)، یه درخواست HTTP می‌زنه و وضعیتش رو می‌بینه.

import { readFileSync, readdirSync, statSync, existsSync } from 'fs'
import path from 'path'
import http from 'http'

const ROOT = process.cwd()
const APP_DIR = path.join(ROOT, 'src', 'app')

// ──────────────────────────────────────────────────────────
// بخش ۱ — استخراج همه‌ی مسیرهای واقعی از فایل‌سیستم
// ──────────────────────────────────────────────────────────
function walkRoutes(dir, base = '') {
  const routes = []
  let entries
  try {
    entries = readdirSync(dir)
  } catch {
    return routes
  }

  const hasPage = entries.includes('page.tsx') || entries.includes('page.ts')
  if (hasPage) {
    routes.push(base === '' ? '/' : base)
  }

  for (const entry of entries) {
    const full = path.join(dir, entry)
    if (!statSync(full).isDirectory()) continue
    // گروه‌های Next.js مثل (group) رو نادیده بگیر، ولی [param] رو نگه دار (پویا)
    if (entry.startsWith('(') && entry.endsWith(')')) {
      routes.push(...walkRoutes(full, base))
    } else {
      routes.push(...walkRoutes(full, `${base}/${entry}`))
    }
  }
  return routes
}

const allRoutes = walkRoutes(APP_DIR)
const staticRoutes = allRoutes.filter((r) => !r.includes('['))
const dynamicRoutes = allRoutes.filter((r) => r.includes('['))

// ──────────────────────────────────────────────────────────
// بخش ۲ — استخراج لینک‌های منو
// ──────────────────────────────────────────────────────────
function extractHrefs(content) {
  const matches = [...content.matchAll(/href=["'](\/[a-zA-Z0-9\-_/[\]]*)["']/g)]
  return [...new Set(matches.map((m) => m[1]))]
}

function safeRead(p) {
  try {
    return readFileSync(p, 'utf-8')
  } catch {
    return ''
  }
}

const menuLinks = new Map() // href -> [منبع‌ها]

function addLinks(hrefs, source) {
  for (const href of hrefs) {
    if (!menuLinks.has(href)) menuLinks.set(href, [])
    menuLinks.get(href).push(source)
  }
}

// منوی ادمین
const sectionsContent = safeRead(path.join(ROOT, 'src', 'lib', 'sections.ts'))
addLinks(extractHrefs(sectionsContent), 'sections.ts (منوی ادمین)')

// منوی کاربری
const userNavContent = safeRead(path.join(ROOT, 'src', 'components', 'UserNav.tsx'))
addLinks(extractHrefs(userNavContent), 'UserNav.tsx (منوی کاربری)')

// منوهای عمومی — همه‌ی page.tsx ها رو بگرد، فقط لینک‌های داخل <nav>/<header> رو بردار
function findAllPageFiles(dir) {
  const files = []
  let entries
  try {
    entries = readdirSync(dir)
  } catch {
    return files
  }
  for (const entry of entries) {
    const full = path.join(dir, entry)
    if (statSync(full).isDirectory()) {
      files.push(...findAllPageFiles(full))
    } else if (entry === 'page.tsx' || entry === 'page.ts') {
      files.push(full)
    }
  }
  return files
}

const pageFiles = findAllPageFiles(APP_DIR)
for (const file of pageFiles) {
  const content = safeRead(file)
  // فقط بلوک‌هایی که شبیه nav/header هستن (heuristic ساده)
  const navBlocks = content.match(/<(nav|header)[\s\S]*?<\/\1>/g) || []
  for (const block of navBlocks) {
    const hrefs = extractHrefs(block)
    addLinks(hrefs, `${path.relative(ROOT, file)} (منوی عمومی)`)
  }
}

// ──────────────────────────────────────────────────────────
// بخش ۳ — مقایسه‌ی استاتیک: لینک منو ↔ مسیر واقعی
// ──────────────────────────────────────────────────────────
function routeExists(href) {
  // href مثل /admin-orders یا /grades/ABC — پارامتر پویا رو با [..] مچ کن
  const parts = href.split('/').filter(Boolean)
  for (const route of allRoutes) {
    const routeParts = route.split('/').filter(Boolean)
    if (routeParts.length !== parts.length) continue
    let ok = true
    for (let i = 0; i < routeParts.length; i++) {
      if (routeParts[i].startsWith('[')) continue // پارامتر پویا، هرچی باشه قبوله
      if (routeParts[i] !== parts[i]) {
        ok = false
        break
      }
    }
    if (ok) return true
  }
  return false
}

const brokenLinks = []
for (const [href] of menuLinks) {
  if (href === '#' || href.startsWith('http') || href.startsWith('mailto:')) continue
  const cleanHref = href.split('?')[0]
  if (!routeExists(cleanHref)) {
    brokenLinks.push(href)
  }
}

// ──────────────────────────────────────────────────────────
// بخش ۴ — چک زنده‌ی HTTP برای هر مسیر واقعی (غیرپویا)
// ──────────────────────────────────────────────────────────
function checkUrl(port, urlPath) {
  return new Promise((resolve) => {
    const req = http.request(
      { hostname: 'localhost', port, path: urlPath, method: 'GET', timeout: 5000 },
      (res) => {
        resolve(res.statusCode)
        res.resume()
      }
    )
    req.on('error', () => resolve('ERROR'))
    req.on('timeout', () => {
      req.destroy()
      resolve('TIMEOUT')
    })
    req.end()
  })
}

const suspicious = []

async function checkAllRoutes() {
  for (const route of staticRoutes) {
    const isAdmin = route.startsWith('/admin-') || route === '/my-tasks'
    const port = isAdmin ? 3001 : 3000
    const status = await checkUrl(port, route)
    const ok = status === 200 || status === 307
    if (!ok) {
      suspicious.push({ route, port, status })
    }
  }
}

// ──────────────────────────────────────────────────────────
// اجرا و گزارش
// ──────────────────────────────────────────────────────────
async function main() {
  console.log('در حال بررسی مسیرهای زنده (ممکنه چند ثانیه طول بکشه)...\n')
  await checkAllRoutes()

  console.log('═══════════════════════════════════════════════')
  console.log('=== لینک‌های منو که به مسیر ناموجود اشاره می‌کنن ===')
  console.log('═══════════════════════════════════════════════')
  if (brokenLinks.length === 0) {
    console.log('هیچی — همه‌ی لینک‌های منو معتبرن ✅\n')
  } else {
    for (const href of brokenLinks) {
      console.log(`❌ ${href}`)
      console.log(`   منبع: ${menuLinks.get(href).join(', ')}`)
    }
    console.log('')
  }

  console.log('═══════════════════════════════════════════════')
  console.log('=== مسیرهای واقعی که HTTP سالم برنمی‌گردونن ===')
  console.log('═══════════════════════════════════════════════')
  if (suspicious.length === 0) {
    console.log('هیچی — همه‌ی مسیرها سالمن (۲۰۰ یا ۳۰۷) ✅\n')
  } else {
    console.log('مسیر | پورت | وضعیت واقعی')
    for (const s of suspicious) {
      console.log(`${s.route} | ${s.port} | ${s.status}`)
    }
    console.log('')
  }

  console.log('═══════════════════════════════════════════════')
  console.log('=== خلاصه ===')
  console.log('═══════════════════════════════════════════════')
  console.log(`تعداد کل مسیر واقعی: ${allRoutes.length} (${staticRoutes.length} ثابت + ${dynamicRoutes.length} پویا)`)
  console.log(`مسیرهای مشکوک (HTTP ناسالم): ${suspicious.length}`)
  console.log(`تعداد کل لینک منو: ${menuLinks.size}`)
  console.log(`لینک‌های ناموجود: ${brokenLinks.length}`)
}

main()
