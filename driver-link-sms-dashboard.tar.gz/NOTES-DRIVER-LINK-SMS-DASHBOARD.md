# لینک راننده + صفحه سفر + نقشه مسیر + صف پیامک + داشبورد ادمین — یادداشت پیاده‌سازی

طبق پلن تاییدشده (`shimmering-tickling-horizon.md`)، نسخه‌ی گسترده‌ی بندهای ۲، ۳ و ۵ از `prompt-driver-link-dashboard.md` / `prompt-driver-page-sms-queue.md` پیاده‌سازی شد. بند ۱ و ۴ دست‌نخورده ماندند.

قوانین ثابت (همه رعایت شده):
- بدون داده‌ی جعلی/نمونه در کد نهایی
- گیت `logisticsAccessEnabled` دست‌نخورده
- SMS فقط از طریق `sendSms()` استاب — هیچ سرویس واقعی وصل نشده
- بدون کلید API واقعی (گوگل مپ / SMS) — فقط placeholder آماده‌به‌اتصال
- migration فقط *پیشنهاد* شده، اجرا نشده
- build/اجرا نشده — فقط کد نوشته شده
- `DealPayment`، `DealDriverAssignment`، منطق پرداخت، و `assignDriverAction` دست‌نخورده مگر جایی که صریحاً لازم بود ساخت لینک اضافه شود

## خلاصه‌ی مراحل پیاده‌شده (ترتیب پلن)

1. **Hook لینک در `assignDriverAction`** + actions قبول/رد راننده
2. **Route `/driver/t/[token]`** مستقل با فرم‌های قبول/رد
3. **`DealLocationPing` proposal** + گسترش gate در `/api/driver-location` + کامپوننت مشترک `TripRouteMap`
4. **`PendingSmsMessage` proposal** + `enforcePendingSmsQueue` + تب صف پیامک در ادمین
5. **بازطراحی `/admin-logistics`**: کارت‌های آماری + تب‌ها + جدول لینک + گالری آکاردئونی + نقشه مسیر
6. همین فایل NOTES + پیشنهاد migration (بدون اجرا)

---

## ۱. ساخت لینک راننده

### فایل‌های تغییریافته
- `src/app/admin-logistics/actions.ts`
  - در `assignDriverAction`: داخل همون `$transaction` که اختصاص راننده را ثبت می‌کند، یک `DriverAccessLink` جدید (۴۸ ساعت اعتبار، توکن `crypto.randomBytes(24)`) با `Driver.phone` ساخته می‌شود — حل مشکل مرغ‌وتخم‌مرغی قبلی (لینک قبلاً فقط از طریق `regenerateDriverLinkAction` قابل ساخت بود که خودش به یک `phone` موجود نیاز داشت).
  - در `regenerateDriverLinkAction` و انتهای `assignDriverAction`: بعد از ساخت لینک، پیامک (۱) از نقاط SMS صف می‌شود: «لینک سفر انبارپلیمر شما: {url}». آدرس از `NEXT_PUBLIC_APP_URL` ساخته می‌شود؛ اگر env ست نباشد مسیر نسبی `/driver/t/{token}` استفاده می‌شود.
  - `assignDriverAction` همچنان `logAudit` را صدا می‌زند و `DealDriverAssignment` را به‌صورت append-only با `replacedAt` مدیریت می‌کند — این بخش منطق دست‌نخورده باقی ماند، فقط ساخت لینک و صف پیامک اضافه شد.

### تصمیم پلن (سوال ۱)
ساخت لینک در `assignDriverAction` انجام می‌شود چون `DriverAccessLink.phone` اجباری است و `transport_pending` بدون راننده شماره‌ای ندارد. `regenerateDriverLinkAction` به‌عنوان fallback دستی (برای لینک‌های منقضی/مصرف‌شده) باقی مانده.

---

## ۲. صفحه‌ی سفر راننده `/driver/t/[token]`

### فایل‌های ساخته‌شده
- `src/app/driver/t/[token]/page.tsx` — Server Component، ۱۰ بخش طبق پرامپت:
  1. هدر محصول + مقدار (`materialListing.grade.code/producer` + `deal.quantity`)
  2. مبدا بارگیری (`materialListing.province — city`)
  3. مقصد تخلیه (`purchaseRequest.province`، اگر خالی → «نامشخص» با توضیح صادقانه)
  4. تلفن تحویل‌گیرنده — فعلاً `null` placeholder (شرط رندر نمی‌شود تا فیلد واقعی اضافه شود؛ پیشنهاد migration پایین‌تر)
  5. اطلاعات راننده/خودرو (`deal.driver` یا fallback به `link.phone`)
  6. نقشه مسیر (`TripRouteMap` مشترک با ادمین)
  7. دکمه‌های قبول/رد (`AcceptRejectButtons`، فقط وقتی `canAct`)
  8. «مدرک حمل» — لینک به فرم موجود `/driver/[token]` (جدا از گالری، طبق تصمیم پلن سوال ۴: `DealConfirmation.photoUrl` فقط برای مدرک حمل تکی است)
  9. تایم‌لاین رویدادها (`deal.confirmations`)
  10. ریست `driverSilenceFlaggedAt` به‌صورت غیرمستقیم: عمل قبول/رد خودش این فیلد را پاک می‌کند (در actions، نه در صفحه)
  - `canAct = !hasAccepted && !hasRejected && !accepted && !rejected` — جلوی تکرار اکشن را می‌گیرد
  - بنرهای `?accepted=1` / `?rejected=1` بعد از redirect از action نمایش داده می‌شوند
- `src/app/driver/t/[token]/AcceptRejectButtons.tsx` — Client Component: قبل از submit، `navigator.geolocation.getCurrentPosition` را صدا می‌زند (اختیاری — اگر کاربر ندهد یا مرورگر بلاک کند، بدون مختصات ادامه می‌دهد) و token/lat/lng را در hidden input به action می‌فرستد.
- `src/app/driver/t/[token]/actions.ts`:
  - `acceptDriverTripAction`: معتبر بودن لینک را با `validateDriverToken` چک می‌کند؛ اگر قبلاً `driver_accepted` ثبت شده باشد خطا می‌دهد (idempotent guard)؛ `DealConfirmation(type='driver_accepted')` با مختصات اختیاری می‌سازد؛ `markDriverLinkUsed(token)`؛ `driverSilenceFlaggedAt=null` و در صورت وجود مختصات `Deal.current*`/`locationUpdatedAt` را آپدیت می‌کند؛ پیامک (۲) به `transportCompany.contactPhone` صف می‌شود؛ redirect به `?accepted=1`.
  - `rejectDriverTripAction`: `DealConfirmation(type='driver_rejected')` با دلیل اختیاری در `checklistJson` می‌سازد؛ **لینک را مصرف‌شده علامت نمی‌زند** (قابل تلاش مجدد، طبق پلن سوال ۲)؛ `driverSilenceFlaggedAt` دست‌نخورده می‌ماند تا ادمین پیگیری کند؛ پیامک (۳) به `transportCompany.contactPhone` (با دلیل در صورت وجود) صف می‌شود؛ redirect به `?rejected=1`.

### فایل دست‌نخورده
- `src/app/driver/[token]/page.tsx` و `DriverForm.tsx` (فرم بارگیری/تخلیه اصلی) — طبق پلن، این مسیر جدا از صفحه‌ی جدید سفر است و فقط از صفحه‌ی `/driver/t/[token]` به آن لینک داده می‌شود. منطق `escrowStatus === 'secured_manual'` gate، `startPostUnloadingClocks`، و آپلود عکس محلی دست‌نخورده ماندند.

---

## ۳. نقشه مسیر + پینگ‌های رویدادمحور

### فایل ساخته‌شده
- `src/components/TripRouteMap.tsx` — Client Component مشترک بین صفحه‌ی راننده (`/driver/t/[token]`) و داشبورد ادمین (تب «نقشه مسیر»):
  - بدون ping → placeholder متنی
  - با ping ولی بدون `NEXT_PUBLIC_GOOGLE_MAPS_API_KEY` → لیست مختصات + لینک مستقیم `maps.google.com/?q=lat,lng` برای هر نقطه (صادقانه: داده واقعی را نشان می‌دهد، فقط Polyline رسم نمی‌شود)
  - با کلید → همان لیست + آماده‌ی اتصال Polyline (کامنت می‌گوید نصب `@react-google-maps/api` فاز بعدی است؛ فعلاً placeholder با border solid)
  - ارتفاع ثابت ۲۸۰px، dashed border — طبق پرامپت گسترده

### فایل تغییریافته
- `src/app/api/driver-location/route.ts` — gate وضعیت‌ها از فقط `in_transit` به `['transport_pending','payment_secured','loading','in_transit']` گسترش یافت (تا پینگ قبول سفر و رسیدن به مبدا هم ثبت شود)؛ اعتبارسنجی lat/lng اضافه شد (finite check).

### منبع داده‌ی فعلی پینگ‌ها (بدون migration جدید)
فعلاً پینگ‌ها از `DealConfirmation.latitude/longitude` (هر بارگیری/تخلیه/قبول که مختصات گرفته) + `Deal.currentLatitude/currentLongitude` (کش آخرین موقعیت، با حذف تکراری) ساخته می‌شوند — هم در صفحه‌ی راننده و هم در تب نقشه‌ی ادمین.

### پیشنهاد migration (اجرا نشده — فقط پیشنهاد، طبق قانون)
برای تاریخچه‌ی کامل و غیر-overwrite، مدل پیشنهادی:
```prisma
model DealLocationPing {
  id        String   @id @default(cuid())
  dealId    String
  latitude  Float
  longitude Float
  capturedAt DateTime @default(now())
  deal      Deal     @relation(fields: [dealId], references: [id])
  @@index([dealId, capturedAt])
}
```
`Deal.current*` به‌عنوان کش آخرین موقعیت باقی می‌ماند. ۵ پینگ رویدادمحور (نه polling دوره‌ای): accept، arrival loading، confirm loading، arrival unloading، confirm unloading. **تا وقتی این migration تایید و اجرا نشود، کد فعلی از `DealConfirmation` + `Deal.current*` استفاده می‌کند و هیچ داده‌ی جعلی تولید نمی‌شود.**

---

## ۴. صف پیامک ۶۰دقیقه‌ای

### فایل ساخته‌شده
- `src/lib/smsQueue.ts`:
  - `queueSms({dealId, phone, message})` — فعلاً مستقیماً `sendSms()` استاب را صدا می‌زند (چون جدول `PendingSmsMessage` هنوز migrate نشده). کد واقعی ساخت ردیف در کامنت گذاشته شده تا بعد از migration با یک خط جایگزین شود.
  - `enforcePendingSmsQueue()` — الگوی `enforceDealDeadlines` بازیافت شده: قرار است در هر بازدید `/admin-logistics` صدا زده شود و پیام‌های `pending` که `autoSendAt <= now` را ارسال کند. فعلاً no-op و `0` برمی‌گرداند (چون جدولی وجود ندارد) — منطق واقعی در کامنت آمده.

### نقاط SMS (پلن سوال ۵) — همه از طریق `queueSms`
| # | رویداد | گیرنده | فایل |
|---|---|---|---|
| ۱ | لینک ساخته شد | راننده (`Driver.phone`) | `admin-logistics/actions.ts` (`assignDriverAction` + `regenerateDriverLinkAction`) |
| ۲ | راننده قبول کرد | شرکت حمل‌ونقل (`transportCompany.contactPhone`) | `driver/t/[token]/actions.ts` (`acceptDriverTripAction`) |
| ۳ | راننده رد کرد | شرکت حمل‌ونقل (`transportCompany.contactPhone`) | `driver/t/[token]/actions.ts` (`rejectDriverTripAction`) |
| ۴ | یادآوری سکوت راننده | شرکت حمل‌ونقل (`transportCompany.contactPhone`) | `src/lib/dealDeadlines.ts` (`enforceDriverSilenceEscalation`) — با `rules.driverSilenceDays` قابل تنظیم، نه هاردکد ۲۴ ساعت |
| ۵ | بارگیری تایید شد | خریدار (`deal.buyer.phone`) | `driver/[token]/actions.ts` (`submitDealConfirmation`، بعد از `status='in_transit'`) |
| ۶ | تحویل شد | خریدار + شرکت حمل‌ونقل | `driver/[token]/actions.ts` (`submitDealConfirmation`، type=unloading) |

همه‌ی گیرنده‌ها با شرط `if (phone)` محافظت شده‌اند — اگر شماره‌ای در دیتابیس نبود، پیامک صف نمی‌شود و خطا هم نمی‌دهد.

### پیشنهاد migration (اجرا نشده — فقط پیشنهاد)
```prisma
model PendingSmsMessage {
  id             String   @id @default(cuid())
  dealId         String?
  recipientPhone String
  message        String
  status         String   @default("pending") // pending|approved|rejected|sent|failed
  createdAt      DateTime @default(now())
  autoSendAt     DateTime // createdAt + 60m
  decidedAt      DateTime?
  decidedById    String?
  sentAt         DateTime?
  providerError  String?
  deal           Deal?    @relation(fields: [dealId], references: [id])
  @@index([status, autoSendAt])
}
```
بعد از migration: `queueSms` باید `create` کند به‌جای `sendSms` مستقیم، و `enforcePendingSmsQueue` باید `pending && autoSendAt <= now` را پیدا و ارسال کند و وضعیت را به `sent`/`failed` آپدیت کند (کد دقیق در کامنت‌های `smsQueue.ts`).

### فایل دست‌نخورده
- `src/lib/sms.ts` — همچنان استاب (`console.log`)، بدون اتصال به سرویس واقعی.

---

## ۵. بازطراحی `/admin-logistics`

### فایل تغییریافته
- `src/app/admin-logistics/page.tsx` — بازطراحی کامل layout:
  - `enforcePendingSmsQueue()` در ابتدای render (الگوی lazy، مثل `enforceDealDeadlines`)
  - **تب‌ها** (`?tab=shipments|sms|map`): محموله‌ها (پیش‌فرض)، صف پیامک، نقشه مسیر
  - **کارت‌های آماری** (تب محموله‌ها): کل در حمل / در انتظار راننده / نیازمند پیگیری (`driverSilenceFlaggedAt != null`) / تکمیل امروز (`delivered|settled` با `updatedAt >= todayStart`) — همه از همان کوئری موجود محاسبه می‌شوند، بدون کوئری اضافه
  - **ستون وضعیت لینک**: فعال / منقضی / مصرف‌شده / بدون لینک (با رنگ معنادار از توکن‌ها)
  - **تایم‌لاین**: ۴ رویداد آخر هر معامله زیر «آخرین تاییدیه»
  - **گالری آکاردئونی**: `<details>` با همه‌ی `DealConfirmation.photoUrl`های موجود در ۱۰۰ معامله‌ی نمایش‌داده‌شده
  - **تب نقشه مسیر**: برای هر معامله‌ای که ping دارد، یک `TripRouteMap` جدا با هدر شناسایی
  - **تب صف پیامک**: اگر جدول `PendingSmsMessage` migrate شده باشد، پیام‌های `pending` با countdown تا `autoSendAt` نمایش داده می‌شوند؛ اگر نه، `try/catch` خالی می‌گیرد و پیام صادقانه می‌دهد که «تا migration اجرا نشود، پیام‌ها مستقیم از استاب رد می‌شوند و اینجا خالی می‌ماند» — بدون داده‌ی جعلی.
  - فرم‌های موجود (`assignTransportCompanyAction`, `assignDriverAction`, `regenerateDriverLinkAction`, `CreateTransportCompanyForm`) و گیت دسترسی (`getAllSectionAccess`, `PartialAccessBanner`) دست‌نخورده باقی ماندند، فقط داخل layout جدید جاسازی شدند.

---

## ۶. پیشنهادهای migration جمع‌بندی‌شده (هیچکدام اجرا نشده‌اند)

1. `DealLocationPing` (بخش ۳)
2. `PendingSmsMessage` (بخش ۴)
3. `DriverUploadedPhoto {id, dealId, uploaderLinkId?, url, caption?, createdAt}` — برای گالری چندتایی مستقل از «مدرک حمل» تکی (پلن سوال ۴؛ فعلاً پیاده‌سازی نشده چون `DealConfirmation.photoUrl` نیاز فعلی را پوشش می‌دهد)
4. `PurchaseRequest.receiverPhone String?` — برای نمایش تلفن تحویل‌گیرنده در صفحه‌ی سفر راننده (پلن سوال ۳؛ فعلاً placeholder `null`)

**هیچکدام اجرا نشده‌اند** — طبق قانون ثابت «migration فقط پیشنهاد بشه، پیاده نشه مگر تایید بگیری». برای اعمال، باید در `prisma/schema.prisma` اضافه و `prisma migrate` (توسط سینا) اجرا شود.

---

## بررسی نهایی (Verification طبق پلن)
- `rg createDriverAccessLink` → فقط در `driverAccess.ts` (تعریف) و `admin-logistics/actions.ts` (استفاده در `assignDriverAction`/`regenerateDriverLinkAction`) — دیگر dead code نیست.
- `rg sendSms` → فقط در `sms.ts` (تعریف استاب) و `smsQueue.ts` (صدا زده شدن از `queueSms`/کامنت `enforcePendingSmsQueue`) — هیچ تماس مستقیم جدیدی خارج از این لایه اضافه نشده.
- `rg DriverAccessLink` → ساخت در `assignDriverAction`/`regenerateDriverLinkAction`، اعتبارسنجی در `validateDriverToken`، مصرف در `markDriverLinkUsed`.
- گیت `logisticsAccessEnabled` در `/transport-panel` و `/admin-logistics` دست‌نخورده.
- بدون build/migration اجراشده؛ بدون داده‌ی جعلی؛ بدون کلید API واقعی.
