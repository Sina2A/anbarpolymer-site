import { sendSms } from './sms'
import prisma from './prisma'

/**
 * صف پیامک ۱ساعته — طرح پیشنهادی مدل:
 *
 * model PendingSmsMessage {
 *   id             String   @id @default(cuid())
 *   dealId         String?
 *   recipientPhone String
 *   message        String
 *   status         String   @default("pending") // pending|approved|rejected|sent|failed
 *   createdAt      DateTime @default(now())
 *   autoSendAt     DateTime // createdAt + 60m
 *   decidedAt      DateTime?
 *   decidedById    String?
 *   sentAt         DateTime?
 *   providerError  String?
 *   deal           Deal?    @relation(fields: [dealId], references: [id])
 * }
 *
 * تا وقتی migration اجرا نشده، queueSms مستقیماً sendSms را صدا می‌زند (stub).
 * بعد از migration، queueSms ردیف PendingSmsMessage می‌سازد و enforcePendingSmsQueue
 * در بازدید /admin-logistics پیام‌های pending که autoSendAt <= now را ارسال می‌کند.
 */

export async function queueSms(params: { dealId?: string; phone: string; message: string }) {
  // فاز فعلی: بدون جدول — مستقیم stub
  // فاز بعدی (بعد از migration):
  // await prisma.pendingSmsMessage.create({ data: { dealId: params.dealId, recipientPhone: params.phone, message: params.message, autoSendAt: new Date(Date.now()+60*60*1000) } })
  await sendSms(params.phone, params.message)
}

/**
 * الگوی enforceDealDeadlines بازاستفاده می‌شود: هر بازدید /admin-logistics
 * این را صدا می‌زند و پیام‌های منقضیِ تاییدنشده را خودکار می‌فرستد.
 * فعلاً no-op تا جدول ساخته شود.
 */
export async function enforcePendingSmsQueue(): Promise<number> {
  // بعد از migration:
  // const due = await prisma.pendingSmsMessage.findMany({ where: { status: 'pending', autoSendAt: { lte: new Date() } } })
  // for (const m of due) { const r = await sendSms(m.recipientPhone, m.message); await prisma.pendingSmsMessage.update({ where:{id:m.id}, data:{ status: r.success?'sent':'failed', sentAt:new Date(), providerError: r.error } }) }
  // return due.length
  return 0
}
