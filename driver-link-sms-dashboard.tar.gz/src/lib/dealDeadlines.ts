import prisma from './prisma'
import { calculateBusinessHoursDeadline } from './businessHours'
import { logStatusEvent } from './statusEvents'
import { evaluateApprovalRequirement } from './priceEngine'
import { resolveSellerId } from './dealRoles'
import { queueSms } from './smsQueue'

const RESTRICTION_HOURS = 24 // Ã˜Â§Ã›Å’Ã™â€  Ã›Å’ÃšÂ©Ã›Å’ Ã˜Â¬Ã˜Â¯Ã˜Â§ Ã˜Â§Ã˜Â² Ã™â€šÃ™Ë†Ã˜Â§Ã™â€ Ã›Å’Ã™â€  Ã™â€¦Ã˜Â¹Ã˜Â§Ã™â€¦Ã™â€žÃ™â€¡Ã¢â‚¬Å’Ã˜Â³Ã˜Âª (Ã™â€¦Ã˜Â­Ã˜Â¯Ã™Ë†Ã˜Â¯Ã›Å’Ã˜Âª Ã˜Â­Ã˜Â³Ã˜Â§Ã˜Â¨Ã˜Å’ Ã™â€ Ã™â€¡ Ã™â€¦Ã™â€¡Ã™â€žÃ˜Âª Ã™â€¦Ã˜Â¹Ã˜Â§Ã™â€¦Ã™â€žÃ™â€¡)Ã˜Å’ Ã™ÂÃ˜Â¹Ã™â€žÃ˜Â§Ã™â€¹ Ã˜Â«Ã˜Â§Ã˜Â¨Ã˜Âª Ã™â€¦Ã›Å’Ã¢â‚¬Å’Ã™â€¦Ã™Ë†Ã™â€ Ã™â€¡

// Ã™â€¦Ã™â€šÃ˜Â§Ã˜Â¯Ã›Å’Ã˜Â± Ã™Â¾Ã›Å’Ã˜Â´Ã¢â‚¬Å’Ã™ÂÃ˜Â±Ã˜Â¶ Ã¢â‚¬â€ Ã˜Â¯Ã™â€šÃ›Å’Ã™â€šÃ˜Â§Ã™â€¹ Ã™â€¡Ã™â€¦Ã™Ë†Ã™â€  Ãšâ€ Ã›Å’Ã˜Â²Ã›Å’ ÃšÂ©Ã™â€¡ Ã˜ÂªÃ˜Â§ Ã˜Â§Ã™â€¦Ã˜Â±Ã™Ë†Ã˜Â² Ã˜ÂªÃ™Ë†Ã›Å’ ÃšÂ©Ã˜Â¯ Ã˜Â«Ã˜Â§Ã˜Â¨Ã˜Âª Ã˜Â¨Ã™Ë†Ã˜Â¯. Ã˜Â§ÃšÂ¯Ã™â€¡ Ã™â€¡Ã›Å’Ãšâ€ Ã¢â‚¬Å’Ã™Ë†Ã™â€šÃ˜Âª
// ÃšÂ©Ã˜Â§Ã˜Â±Ã˜Â´Ã™â€ Ã˜Â§Ã˜Â³Ã›Å’ Ã˜Â§Ã˜Â² Ã™Â¾Ã™â€ Ã™â€ž Ã˜ÂªÃ™â€ Ã˜Â¸Ã›Å’Ã™â€¦Ã˜Â´ Ã™â€ ÃšÂ©Ã™â€ Ã™â€¡Ã˜Å’ Ã˜Â±Ã™ÂÃ˜ÂªÃ˜Â§Ã˜Â± Ã˜Â³Ã˜Â§Ã›Å’Ã˜Âª Ã™â€¡Ã›Å’Ãšâ€  Ã™ÂÃ˜Â±Ã™â€šÃ›Å’ Ã™â€ Ã™â€¦Ã›Å’Ã¢â‚¬Å’ÃšÂ©Ã™â€ Ã™â€¡.
const DEFAULT_RULES = {
  sellerFeeHours: 24,
  buyerPaymentHours: 72,
  discrepancyReportHours: 4,
  fundReleaseHours: 8,
  driverSilenceDays: 5,
  proformaConfirmHours: 8,
}

export type DealRuleValues = typeof DEFAULT_RULES

/** Ã˜Â®Ã™Ë†Ã˜Â§Ã™â€ Ã˜Â¯Ã™â€  Ã™â€¦Ã™â€šÃ˜Â§Ã˜Â¯Ã›Å’Ã˜Â± Ã™ÂÃ˜Â¹Ã™â€žÃ›Å’ Ã™â€šÃ™Ë†Ã˜Â§Ã™â€ Ã›Å’Ã™â€  Ã¢â‚¬â€ Ã˜Â§ÃšÂ¯Ã™â€¡ Ã™â€¡Ã™â€ Ã™Ë†Ã˜Â² Ã™â€¡Ã›Å’Ãšâ€ Ã¢â‚¬Å’ÃšÂ©Ã˜Â³ Ã˜ÂªÃ™â€ Ã˜Â¸Ã›Å’Ã™â€¦Ã›Å’ Ã™â€ Ã˜Â³Ã˜Â§Ã˜Â®Ã˜ÂªÃ™â€¡Ã˜Å’ Ã™Â¾Ã›Å’Ã˜Â´Ã¢â‚¬Å’Ã™ÂÃ˜Â±Ã˜Â¶Ã¢â‚¬Å’Ã™â€¡Ã˜Â§ Ã˜Â¨Ã˜Â±Ã™â€¦Ã›Å’Ã¢â‚¬Å’ÃšÂ¯Ã˜Â±Ã˜Â¯Ã™â€ . */
export async function getDealRuleSettings(): Promise<DealRuleValues> {
  const row = await prisma.dealRuleSettings.findUnique({ where: { id: 'singleton' } })
  if (!row) return DEFAULT_RULES
  return {
    sellerFeeHours: row.sellerFeeHours,
    buyerPaymentHours: row.buyerPaymentHours,
    discrepancyReportHours: row.discrepancyReportHours,
    fundReleaseHours: row.fundReleaseHours,
    driverSilenceDays: row.driverSilenceDays,
    proformaConfirmHours: row.proformaConfirmHours,
  }
}

export async function updateDealRuleSettings(values: DealRuleValues, updatedById: string) {
  await prisma.dealRuleSettings.upsert({
    where: { id: 'singleton' },
    update: { ...values, updatedById },
    create: { id: 'singleton', ...values, updatedById },
  })
}

/**
 * Ã˜Â§Ã›Å’Ã™â€  Ã˜ÂªÃ˜Â§Ã˜Â¨Ã˜Â¹ Ã˜Â±Ã™Ë† Ã˜Â¨Ã˜Â§Ã›Å’Ã˜Â¯ Ã™â€¡Ã˜Â± Ã˜Â¬Ã˜Â§ Ã˜ÂµÃ™ÂÃ˜Â­Ã™â€¡Ã¢â‚¬Å’Ã›Å’ Ã™â€¦Ã˜Â±Ã˜ÂªÃ˜Â¨Ã˜Â· Ã™â€žÃ™Ë†Ã˜Â¯ Ã™â€¦Ã›Å’Ã¢â‚¬Å’Ã˜Â´Ã™â€¡ Ã˜ÂµÃ˜Â¯Ã˜Â§ Ã˜Â²Ã˜Â¯ (Ã˜Â¨Ã˜Â§Ã˜Â²Ã˜Â§Ã˜Â± Ã˜ÂµÃ™â€ Ã˜Â¹Ã˜ÂªÃ›Å’Ã˜Å’ Ã™Â¾Ã™â€ Ã™â€ž ÃšÂ©Ã˜Â§Ã˜Â±Ã˜Â¨Ã˜Â±Ã›Å’Ã˜Å’ Ã™Â¾Ã™â€ Ã™â€ž Ã˜Â§Ã˜Â¯Ã™â€¦Ã›Å’Ã™â€ ).
 * Ãšâ€ Ã™Ë†Ã™â€  Ã™â€¡Ã™â€ Ã™Ë†Ã˜Â² job scheduler/cron Ã˜Â¬Ã˜Â¯Ã˜Â§ Ã™â€ Ã˜Â¯Ã˜Â§Ã˜Â±Ã›Å’Ã™â€¦Ã˜Å’ Ã˜Â¨Ã™â€¡Ã¢â‚¬Å’Ã˜Â¬Ã˜Â§Ã˜Â´ Ã™â€¡Ã˜Â± Ã˜Â¨Ã˜Â§Ã˜Â± ÃšÂ©Ã™â€¡ Ã›Å’ÃšÂ©Ã›Å’ Ã˜Â§Ã˜Â² Ã˜Â§Ã›Å’Ã™â€  Ã˜ÂµÃ™ÂÃ˜Â­Ã˜Â§Ã˜Âª Ã˜Â¨Ã˜Â§Ã˜Â² Ã™â€¦Ã›Å’Ã¢â‚¬Å’Ã˜Â´Ã™â€¡Ã˜Å’
 * Ã˜Â§Ã›Å’Ã™â€  Ã˜ÂªÃ˜Â§Ã˜Â¨Ã˜Â¹ Ã˜Â®Ã™Ë†Ã˜Â¯Ã˜Â´ Ãšâ€ ÃšÂ© Ã™â€¦Ã›Å’Ã¢â‚¬Å’ÃšÂ©Ã™â€ Ã™â€¡ Ã˜Â¢Ã›Å’Ã˜Â§ Ã™â€¦Ã™â€¡Ã™â€žÃ˜ÂªÃ›Å’ ÃšÂ¯Ã˜Â°Ã˜Â´Ã˜ÂªÃ™â€¡ Ã›Å’Ã˜Â§ Ã™â€ Ã™â€¡ Ã¢â‚¬â€ Ã›Å’Ã™â€¡ Ã˜Â§Ã™â€žÃšÂ¯Ã™Ë†Ã›Å’ Ã˜Â³Ã˜Â§Ã˜Â¯Ã™â€¡ Ã™Ë† Ã˜Â±Ã˜Â§Ã›Å’Ã˜Â¬ Ã˜Â¨Ã˜Â±Ã˜Â§Ã›Å’ MVPÃ˜Å’
 * Ã˜Â¨Ã˜Â¯Ã™Ë†Ã™â€  Ã™â€ Ã›Å’Ã˜Â§Ã˜Â² Ã˜Â¨Ã™â€¡ Ã˜Â²Ã›Å’Ã˜Â±Ã˜Â³Ã˜Â§Ã˜Â®Ã˜Âª Ã˜Â¬Ã˜Â¯Ã˜Â§ÃšÂ¯Ã˜Â§Ã™â€ Ã™â€¡.
 */
export async function enforceDealDeadlines() {
  const rules = await getDealRuleSettings()
  const sellerExpired = await enforceSellerFeeDeadlines()
  const buyerExpired = await enforceBuyerPaymentDeadlines()
  const dealSellerExpired = await enforceDealSellerFeeDeadlines()
  const discrepancyWindowClosed = await enforceDiscrepancyWindowClose()
  const driverSilenceFlagged = await enforceDriverSilenceEscalation(rules)
  return {
    cancelledCount: sellerExpired + buyerExpired + dealSellerExpired,
    qualityAutoAcceptedCount: discrepancyWindowClosed,
    driverSilenceFlaggedCount: driverSilenceFlagged,
  }
}

/**
 * enforcement سطح معامله: هر Deal در وضعیت confirmed که مهلت پرداخت کارمزد فروشنده‌اش (sellerFeeDeadline)
 * گذشته باشد لغو می‌شود. اگر معامله به یک لیست متصل باشد، آن لیست دوباره active شده و فروشنده‌اش
 * به مدت RESTRICTION_HOURS محدود می‌شود؛ در غیر این صورت فقط لغو می‌شود (فروشنده‌ای برای محدود کردن نیست).
 * این تابع با enforceSellerFeeDeadlines (که روی MaterialListing کار می‌کند) تفاوت دارد و آن را نقض نمی‌کند.
 */
async function enforceDealSellerFeeDeadlines() {
  const now = new Date()
  const overdue = await prisma.deal.findMany({
    where: {
      status: 'confirmed',
      sellerFeeDeadline: { not: null, lt: now },
    },
    include: { materialListing: true },
  })

  for (const deal of overdue) {
    await prisma.deal.update({
      where: { id: deal.id },
      data: { status: 'cancelled' },
    })

    // آزادسازی listing فقط وقتی معامله به آگهی متصل است (معامله‌ی BUY آگهی ندارد)
    if (deal.materialListingId) {
      await prisma.materialListing.update({
        where: { id: deal.materialListingId },
        data: { validityStatus: 'active' },
      })
    }

    // فروشنده = snapshotِ sellerId با فالبک به آگهی (legacy) — این‌طور BUY هم پوشش داده می‌شود
    const sellerId = resolveSellerId(deal)
    if (sellerId) {
      await restrictUser(sellerId, RESTRICTION_HOURS, 'کارمزد فروش در مهلت مقرر پرداخت نشد')
    }
  }

  return overdue.length
}

/**
 * Ã™ÂÃ˜Â±Ã™Ë†Ã˜Â´Ã™â€ Ã˜Â¯Ã™â€¡ ÃšÂ©Ã˜Â§Ã˜Â±Ã™â€¦Ã˜Â²Ã˜Â¯ Ã˜Â±Ã™Ë† Ã˜Â³Ã˜Â± Ã™Ë†Ã™â€šÃ˜Âª Ã™â€ Ã˜Â¯Ã˜Â§Ã˜Â¯Ã™â€¡ Ã¢â€ â€™ Ã˜Â¢ÃšÂ¯Ã™â€¡Ã›Å’ Ã˜Â¨Ã™â€¡Ã¢â‚¬Å’Ã˜Â¬Ã˜Â§Ã›Å’ Ã˜Â¨Ã˜Â§Ã˜Â²ÃšÂ¯Ã˜Â´Ã˜Âª Ã™ÂÃ™Ë†Ã˜Â±Ã›Å’ Ã˜Â¨Ã™â€¡ Ã˜Â¨Ã˜Â§Ã˜Â²Ã˜Â§Ã˜Â±Ã˜Å’ Ã™â€¦Ã›Å’Ã¢â‚¬Å’Ã˜Â±Ã™â€¡
 * Ã˜ÂªÃ™Ë† Ã˜Â­Ã˜Â§Ã™â€žÃ˜Âª Ã‚Â«Ã™â€ Ã›Å’Ã˜Â§Ã˜Â²Ã™â€¦Ã™â€ Ã˜Â¯ Ã˜Â¨Ã˜Â±Ã˜Â±Ã˜Â³Ã›Å’ Ã™â€¦Ã˜Â¬Ã˜Â¯Ã˜Â¯Ã‚Â» (needs_reverification) Ã¢â‚¬â€ Ãšâ€ Ã™Ë†Ã™â€  Ã™â€¦Ã™â€¦ÃšÂ©Ã™â€ Ã™â€¡ Ã™â€¦Ã™Ë†Ã˜Â¬Ã™Ë†Ã˜Â¯Ã›Å’
 * Ã™ÂÃ˜Â±Ã™Ë†Ã˜Â´Ã™â€ Ã˜Â¯Ã™â€¡ Ã™Ë†Ã˜Â§Ã™â€šÃ˜Â¹Ã˜Â§Ã™â€¹ Ã˜Â¹Ã™Ë†Ã˜Â¶ Ã˜Â´Ã˜Â¯Ã™â€¡ Ã˜Â¨Ã˜Â§Ã˜Â´Ã™â€¡. ÃšÂ©Ã˜Â§Ã˜Â±Ã˜Â´Ã™â€ Ã˜Â§Ã˜Â³ Ã˜Â¨Ã˜Â§Ã›Å’Ã˜Â¯ Ã˜Â¯Ã˜Â³Ã˜ÂªÃ›Å’ Ã˜ÂªÃ˜Â§Ã›Å’Ã›Å’Ã˜Â¯ ÃšÂ©Ã™â€ Ã™â€¡.
 * Ã˜ÂªÃ™Ë†Ã˜Â¬Ã™â€¡: Ã˜Â·Ã™Ë†Ã™â€ž Ã˜Â®Ã™Ë†Ã˜Â¯Ã™Â Ã™â€¦Ã™â€¡Ã™â€žÃ˜Âª (feeDeadline) Ã™â€šÃ˜Â¨Ã™â€žÃ˜Â§Ã™â€¹ Ã˜ÂªÃ™Ë†Ã›Å’ startSellerFeeDeadline Ã˜Â¨Ã˜Â§
 * Ã™â€¦Ã™â€šÃ˜Â¯Ã˜Â§Ã˜Â± Ã™Ë†Ã™â€šÃ˜ÂªÃ™Â Ã˜Â¢Ã™â€  Ã™â€žÃ˜Â­Ã˜Â¸Ã™â€¡ Ã™â€¦Ã˜Â­Ã˜Â§Ã˜Â³Ã˜Â¨Ã™â€¡ Ã™Ë† Ã˜Â°Ã˜Â®Ã›Å’Ã˜Â±Ã™â€¡ Ã˜Â´Ã˜Â¯Ã™â€¡ Ã¢â‚¬â€ Ã˜Â§Ã›Å’Ã™â€  Ã˜ÂªÃ˜Â§Ã˜Â¨Ã˜Â¹ Ã™ÂÃ™â€šÃ˜Â· Ãšâ€ ÃšÂ© Ã™â€¦Ã›Å’Ã¢â‚¬Å’ÃšÂ©Ã™â€ Ã™â€¡ ÃšÂ¯Ã˜Â°Ã˜Â´Ã˜ÂªÃ™â€¡ Ã›Å’Ã˜Â§ Ã™â€ Ã™â€¡.
 */
async function enforceSellerFeeDeadlines() {
  const now = new Date()
  const overdue = await prisma.materialListing.findMany({
    where: {
      feeStatus: 'unpaid',
      feeDeadline: { lt: now },
      validityStatus: 'reserved',
    },
  })

  for (const listing of overdue) {
    await prisma.materialListing.update({
      where: { id: listing.id },
      data: { validityStatus: 'needs_reverification', feeDeadline: null },
    })

    await prisma.user.update({
      where: { id: listing.userId },
      data: {
        restrictedUntil: new Date(now.getTime() + RESTRICTION_HOURS * 60 * 60 * 1000),
        restrictionReason: 'ÃšÂ©Ã˜Â§Ã˜Â±Ã™â€¦Ã˜Â²Ã˜Â¯ Ã™ÂÃ˜Â±Ã™Ë†Ã˜Â´ Ã˜Â±Ã˜Â§ Ã˜Â¸Ã˜Â±Ã™Â Ã™â€¦Ã™â€¡Ã™â€žÃ˜Âª Ã™â€¦Ã™â€šÃ˜Â±Ã˜Â± Ã™Â¾Ã˜Â±Ã˜Â¯Ã˜Â§Ã˜Â®Ã˜Âª Ã™â€ ÃšÂ©Ã˜Â±Ã˜Â¯',
      },
    })

    await prisma.deal.updateMany({
      where: { materialListingId: listing.id, status: { in: ['draft', 'confirmed'] } },
      data: { status: 'cancelled' },
    })
  }

  return overdue.length
}

/**
 * Ã˜Â®Ã˜Â±Ã›Å’Ã˜Â¯Ã˜Â§Ã˜Â± Ã˜Â¨Ã˜Â¹Ã˜Â¯ Ã˜Â§Ã˜Â² Ã˜ÂªÃ˜Â§Ã›Å’Ã›Å’Ã˜Â¯Ã˜Å’ Ã™Â¾Ã˜Â±Ã˜Â¯Ã˜Â§Ã˜Â®Ã˜Âª ÃšÂ©Ã˜Â§Ã™â€¦Ã™â€ž Ã˜Â±Ã™Ë† Ã˜ÂªÃšÂ©Ã™â€¦Ã›Å’Ã™â€ž Ã™â€ ÃšÂ©Ã˜Â±Ã˜Â¯Ã™â€¡ Ã¢â€ â€™ Ã˜Â±Ã˜Â²Ã˜Â±Ã™Ë† ÃšÂ©Ã™â€ Ã˜Â³Ã™â€žÃ˜Å’ Ã˜Â¢ÃšÂ¯Ã™â€¡Ã›Å’ Ã˜Â¢Ã˜Â²Ã˜Â§Ã˜Â¯ Ã™â€¦Ã›Å’Ã¢â‚¬Å’Ã˜Â´Ã™â€¡.
 */
async function enforceBuyerPaymentDeadlines() {
  const now = new Date()
  const overdue = await prisma.deal.findMany({
    where: {
      status: 'confirmed',
      escrowStatus: 'pending',
      buyerConfirmDeadline: { lt: now },
    },
    include: { materialListing: true },
  })

  for (const deal of overdue) {
    await prisma.deal.update({
      where: { id: deal.id },
      data: { status: 'cancelled' },
    })

    if (deal.materialListingId) {
      await prisma.materialListing.update({
        where: { id: deal.materialListingId },
        data: { validityStatus: 'active' },
      })
    }

    await prisma.user.update({
      where: { id: deal.buyerId },
      data: {
        restrictedUntil: new Date(now.getTime() + RESTRICTION_HOURS * 60 * 60 * 1000),
        restrictionReason: 'Ã˜Â±Ã˜Â²Ã˜Â±Ã™Ë† Ã˜Â±Ã˜Â§ Ã˜ÂªÃ˜Â§Ã›Å’Ã›Å’Ã˜Â¯ ÃšÂ©Ã˜Â±Ã˜Â¯ Ã™Ë†Ã™â€žÃ›Å’ Ã™Â¾Ã˜Â±Ã˜Â¯Ã˜Â§Ã˜Â®Ã˜Âª Ã˜Â±Ã˜Â§ Ã˜Â¸Ã˜Â±Ã™Â Ã™â€¦Ã™â€¡Ã™â€žÃ˜Âª Ã™â€¦Ã™â€šÃ˜Â±Ã˜Â± Ã˜ÂªÃšÂ©Ã™â€¦Ã›Å’Ã™â€ž Ã™â€ ÃšÂ©Ã˜Â±Ã˜Â¯',
      },
    })
  }

  return overdue.length
}

/**
 * Ã™Ë†Ã™â€šÃ˜ÂªÃ›Å’ Ã˜Â±Ã˜Â§Ã™â€ Ã™â€ Ã˜Â¯Ã™â€¡ Ã‚Â«Ã˜ÂªÃ˜Â§Ã›Å’Ã›Å’Ã˜Â¯ Ã˜ÂªÃ˜Â®Ã™â€žÃ›Å’Ã™â€¡Ã‚Â» Ã˜Â±Ã™Ë† Ã˜Â«Ã˜Â¨Ã˜Âª Ã™â€¦Ã›Å’Ã¢â‚¬Å’ÃšÂ©Ã™â€ Ã™â€¡Ã˜Å’ Ã˜Â§Ã›Å’Ã™â€  Ã˜Â±Ã™Ë† Ã˜ÂµÃ˜Â¯Ã˜Â§ Ã˜Â¨Ã˜Â²Ã™â€ . Ã˜Â§Ã˜Â² Ã™â€¡Ã™â€¦Ã›Å’Ã™â€  Ã™â€žÃ˜Â­Ã˜Â¸Ã™â€¡ Ã˜Â¯Ã™Ë†
 * Ã˜ÂªÃ˜Â§Ã›Å’Ã™â€¦Ã˜Â± Ã™â€¦Ã˜Â³Ã˜ÂªÃ™â€šÃ™â€ž Ã˜Â´Ã˜Â±Ã™Ë†Ã˜Â¹ Ã™â€¦Ã›Å’Ã¢â‚¬Å’Ã˜Â´Ã™â€¡ Ã¢â‚¬â€ Ã˜Â·Ã™Ë†Ã™â€ž Ã™â€¡Ã˜Â±Ã˜Â¯Ã™Ë† Ã˜Â§Ã˜Â² Ã˜ÂªÃ™â€ Ã˜Â¸Ã›Å’Ã™â€¦Ã˜Â§Ã˜Âª Ã™ÂÃ˜Â¹Ã™â€žÃ›Å’ (Ã™â€šÃ˜Â§Ã˜Â¨Ã™â€žÃ¢â‚¬Å’Ã˜ÂªÃ˜ÂºÃ›Å’Ã›Å’Ã˜Â± Ã˜ÂªÃ™Ë†Ã˜Â³Ã˜Â·
 * ÃšÂ©Ã˜Â§Ã˜Â±Ã˜Â´Ã™â€ Ã˜Â§Ã˜Â³) Ã˜Â®Ã™Ë†Ã™â€ Ã˜Â¯Ã™â€¡ Ã™â€¦Ã›Å’Ã¢â‚¬Å’Ã˜Â´Ã™â€¡Ã˜Å’ Ã™â€ Ã™â€¡ Ã˜Â¹Ã˜Â¯Ã˜Â¯ Ã˜Â«Ã˜Â§Ã˜Â¨Ã˜Âª.
 */
export async function startPostUnloadingClocks(dealId: string, unloadingConfirmedAt: Date) {
  const rules = await getDealRuleSettings()
  const [discrepancyDeadline, releaseDeadline] = await Promise.all([
    calculateBusinessHoursDeadline(unloadingConfirmedAt, rules.discrepancyReportHours),
    calculateBusinessHoursDeadline(unloadingConfirmedAt, rules.fundReleaseHours),
  ])
  await prisma.deal.update({
    where: { id: dealId },
    data: {
      status: 'delivered',
      discrepancyReportDeadline: discrepancyDeadline,
      fundReleaseDeadline: releaseDeadline,
    },
  })
  return { discrepancyDeadline, releaseDeadline }
}

/**
 * Ã™Â¾Ã˜Â§Ã›Å’Ã˜Â§Ã™â€  Ã™â€¦Ã™â€¡Ã™â€žÃ˜Âª ÃšÂ¯Ã˜Â²Ã˜Â§Ã˜Â±Ã˜Â´ Ã™â€¦Ã˜ÂºÃ˜Â§Ã›Å’Ã˜Â±Ã˜Âª: Ã˜Â§ÃšÂ¯Ã™â€¡ Ã˜Â®Ã˜Â±Ã›Å’Ã˜Â¯Ã˜Â§Ã˜Â± Ã™â€¡Ã›Å’Ãšâ€  Ã™â€¦Ã˜ÂºÃ˜Â§Ã›Å’Ã˜Â±Ã˜ÂªÃ›Å’ Ã˜Â«Ã˜Â¨Ã˜Âª Ã™â€ ÃšÂ©Ã˜Â±Ã˜Â¯Ã™â€¡ Ã˜Â¨Ã˜Â§Ã˜Â´Ã™â€¡Ã˜Å’ Ã˜Â³Ã›Å’Ã˜Â³Ã˜ÂªÃ™â€¦
 * Ã˜Â®Ã™Ë†Ã˜Â¯Ã˜Â´ auto_no_discrepancy Ã˜Â±Ã™Ë† Ã˜Â«Ã˜Â¨Ã˜Âª Ã™â€¦Ã›Å’Ã¢â‚¬Å’ÃšÂ©Ã™â€ Ã™â€¡.
 */
async function enforceDiscrepancyWindowClose() {
  const now = new Date()
  const overdue = await prisma.deal.findMany({
    where: {
      discrepancyReportDeadline: { lt: now },
      status: 'delivered',
      qualityAutoAccepted: false,
    },
    include: { confirmations: true },
  })

  let count = 0
  for (const deal of overdue) {
    const alreadyReported = deal.confirmations.some((c) => c.type === 'buyer_confirm')
    if (alreadyReported) {
      await prisma.deal.update({ where: { id: deal.id }, data: { qualityAutoAccepted: true } })
      continue
    }

    await prisma.dealConfirmation.create({
      data: {
        dealId: deal.id,
        type: 'buyer_confirm',
        finalVerdict: 'auto_no_discrepancy',
        checklistJson: '{}',
      },
    })
    await prisma.deal.update({
      where: { id: deal.id },
      data: { qualityAutoAccepted: true },
    })
    count++
  }
  return count
}

/**
 * Ã˜Â§ÃšÂ¯Ã™â€¡ Ã˜Â±Ã˜Â§Ã™â€ Ã™â€ Ã˜Â¯Ã™â€¡ Ã˜Â¨Ã˜Â¹Ã˜Â¯ Ã˜Â§Ã˜Â² Ã‚Â«Ã˜ÂªÃ˜Â§Ã›Å’Ã›Å’Ã˜Â¯ Ã˜Â¨Ã˜Â§Ã˜Â±ÃšÂ¯Ã›Å’Ã˜Â±Ã›Å’Ã‚Â» Ã˜ÂªÃ˜Â§ Ã˜Â¢Ã˜Â³Ã˜ÂªÃ˜Â§Ã™â€ Ã™â€¡Ã¢â‚¬Å’Ã›Å’ Ã˜ÂªÃ™â€ Ã˜Â¸Ã›Å’Ã™â€¦Ã¢â‚¬Å’Ã˜Â´Ã˜Â¯Ã™â€¡ (Ã™Â¾Ã›Å’Ã˜Â´Ã¢â‚¬Å’Ã™ÂÃ˜Â±Ã˜Â¶ Ã›Âµ Ã˜Â±Ã™Ë†Ã˜Â²
 * Ã˜ÂªÃ™â€šÃ™Ë†Ã›Å’Ã™â€¦Ã›Å’) Ã™â€¡Ã›Å’Ãšâ€  Ã˜Â±Ã™Ë†Ã›Å’Ã˜Â¯Ã˜Â§Ã˜Â¯ Ã˜Â¯Ã›Å’ÃšÂ¯Ã™â€¡Ã¢â‚¬Å’Ã˜Â§Ã›Å’ Ã˜Â«Ã˜Â¨Ã˜Âª Ã™â€ ÃšÂ©Ã™â€ Ã™â€¡Ã˜Å’ Ã˜Â§Ã›Å’Ã™â€  Ã™Â¾Ã˜Â±Ãšâ€ Ã™â€¦ Ã™â€¦Ã›Å’Ã¢â‚¬Å’Ã˜Â®Ã™Ë†Ã˜Â±Ã™â€¡.
 */
async function enforceDriverSilenceEscalation(rules: DealRuleValues) {
  const now = new Date()
  const cutoff = new Date(now.getTime() - rules.driverSilenceDays * 24 * 60 * 60 * 1000)

  const inTransitDeals = await prisma.deal.findMany({
    where: { status: 'in_transit', driverSilenceFlaggedAt: null },
    include: { confirmations: { orderBy: { confirmedAt: 'desc' } } },
  })

  let count = 0
  for (const deal of inTransitDeals) {
    const lastEvent = deal.confirmations[0]
    if (lastEvent && lastEvent.confirmedAt < cutoff) {
      await prisma.deal.update({
        where: { id: deal.id },
        data: { driverSilenceFlaggedAt: now },
      })
      count++
      // نقطه‌ی ۴ پلن: سکوت راننده به حد نصاب رسید → اطلاع به شرکت حمل‌ونقل (در صف ۶۰دقیقه‌ای)
      if (deal.transportCompanyId) {
        const company = await prisma.transportCompany.findUnique({
          where: { id: deal.transportCompanyId },
          select: { contactPhone: true },
        })
        if (company?.contactPhone) {
          await queueSms({
            dealId: deal.id,
            phone: company.contactPhone,
            message: `هشدار سکوت راننده: محموله‌ی ${deal.id.slice(0, 8)} بیش از ${rules.driverSilenceDays} روز بدون رویداد مانده — لطفاً پیگیری کنید — انبارپلیمر`,
          })
        }
      }
    }
  }
  return count
}

/** Ã˜Â¨Ã˜Â±Ã˜Â§Ã›Å’ Ãšâ€ ÃšÂ©Ã¢â‚¬Å’ÃšÂ©Ã˜Â±Ã˜Â¯Ã™â€  Ã™â€šÃ˜Â¨Ã™â€ž Ã˜Â§Ã˜Â² Ã˜Â§Ã˜Â¬Ã˜Â§Ã˜Â²Ã™â€¡ Ã˜Â¯Ã˜Â§Ã˜Â¯Ã™â€  Ã˜Â¨Ã™â€¡ Ã˜Â«Ã˜Â¨Ã˜Âª Ã˜Â¢ÃšÂ¯Ã™â€¡Ã›Å’/Ã˜Â±Ã˜Â²Ã˜Â±Ã™Ë† Ã˜Â¬Ã˜Â¯Ã›Å’Ã˜Â¯ */
export async function isUserRestricted(userId: string) {
  const user = await prisma.user.findUnique({ where: { id: userId } })
  if (!user?.restrictedUntil) return { restricted: false as const }
  if (user.restrictedUntil < new Date()) return { restricted: false as const }
  return { restricted: true as const, until: user.restrictedUntil, reason: user.restrictionReason }
}

/**
 * طول‌های مجاز جریمه (به ساعت) که ادمین هنگام رد پرداخت انتخاب می‌کند — §۵ سند.
 * ۳۰ دقیقه = ۰٫۵ ساعت؛ بقیه مستقیماً ساعت‌اند.
 */
export const PENALTY_HOURS_OPTIONS = [0.5, 1, 3, 24, 72] as const

/**
 * محدودسازی موقت کاربر — تعمیمِ الگوی تکراریِ restrictedUntil (که در enforcerهای این
 * فایل با ثابتِ RESTRICTION_HOURS به‌صورت درجا نوشته شده) به یک helper با طول دلخواه.
 * اگر کاربر همین حالا محدودیتِ فعالِ طولانی‌تری دارد، سقفِ دو مقدار گرفته می‌شود تا
 * جریمه‌ی جدید، محدودیتِ قبلیِ سنگین‌تر را کوتاه نکند.
 */
export async function restrictUser(userId: string, hours: number, reason: string) {
  const candidate = new Date(Date.now() + hours * 60 * 60 * 1000)
  const existing = await prisma.user.findUnique({
    where: { id: userId },
    select: { restrictedUntil: true },
  })
  const until =
    existing?.restrictedUntil && existing.restrictedUntil > candidate
      ? existing.restrictedUntil
      : candidate
  await prisma.user.update({
    where: { id: userId },
    data: { restrictedUntil: until, restrictionReason: reason },
  })
  return until
}

/** Ã™â€¦Ã™Ë†Ã™â€šÃ˜Â¹ Ã˜ÂªÃ˜Â§Ã›Å’Ã›Å’Ã˜Â¯ Ã˜Â§Ã˜Â¯Ã™â€¦Ã›Å’Ã™â€  Ã˜Â±Ã™Ë†Ã›Å’ Ã›Å’Ã™â€¡ Ã˜Â±Ã˜Â²Ã˜Â±Ã™Ë†Ã˜Å’ Ã˜Â§Ã›Å’Ã™â€  Ã˜Â±Ã™Ë† Ã˜ÂµÃ˜Â¯Ã˜Â§ Ã˜Â¨Ã˜Â²Ã™â€  Ã˜ÂªÃ˜Â§ Ã™â€¦Ã™â€¡Ã™â€žÃ˜Âª ÃšÂ©Ã˜Â§Ã˜Â±Ã™â€¦Ã˜Â²Ã˜Â¯ Ã™ÂÃ˜Â±Ã™Ë†Ã˜Â´Ã™â€ Ã˜Â¯Ã™â€¡ Ã˜Â´Ã˜Â±Ã™Ë†Ã˜Â¹ Ã˜Â¨Ã˜Â´Ã™â€¡ */
export async function startSellerFeeDeadline(materialListingId: string) {
  const rules = await getDealRuleSettings()
  const deadline = await calculateBusinessHoursDeadline(new Date(), rules.sellerFeeHours)
  await prisma.materialListing.update({
    where: { id: materialListingId },
    data: { validityStatus: 'reserved', feeDeadline: deadline },
  })
  return deadline
}

/** Ã™â€¦Ã™Ë†Ã™â€šÃ˜Â¹ Ã˜ÂªÃ˜Â§Ã›Å’Ã›Å’Ã˜Â¯ ÃšÂ©Ã˜Â§Ã˜Â±Ã™â€¦Ã˜Â²Ã˜Â¯ Ã™ÂÃ˜Â±Ã™Ë†Ã˜Â´Ã™â€ Ã˜Â¯Ã™â€¡Ã˜Å’ Ã˜Â§Ã›Å’Ã™â€  Ã˜Â±Ã™Ë† Ã˜ÂµÃ˜Â¯Ã˜Â§ Ã˜Â¨Ã˜Â²Ã™â€  Ã˜ÂªÃ˜Â§ Ã™â€¦Ã™â€¡Ã™â€žÃ˜Âª Ã™Â¾Ã˜Â±Ã˜Â¯Ã˜Â§Ã˜Â®Ã˜Âª ÃšÂ©Ã˜Â§Ã™â€¦Ã™â€ž Ã˜Â®Ã˜Â±Ã›Å’Ã˜Â¯Ã˜Â§Ã˜Â± Ã˜Â´Ã˜Â±Ã™Ë†Ã˜Â¹ Ã˜Â¨Ã˜Â´Ã™â€¡ */
export async function startBuyerPaymentDeadline(dealId: string, skipApprovalCheck: boolean = false) {
  const rules = await getDealRuleSettings()

  // Ã˜Â¨Ã˜Â§Ã˜Â±ÃšÂ¯Ã›Å’Ã˜Â±Ã›Å’ Deal Ã˜Â¨Ã˜Â±Ã˜Â§Ã›Å’ Ãšâ€ ÃšÂ© ÃšÂ©Ã˜Â±Ã˜Â¯Ã™â€  agreedPrice
  const deal = await prisma.deal.findUnique({ where: { id: dealId } })
  if (!deal) throw new Error('Ã™â€¦Ã˜Â¹Ã˜Â§Ã™â€¦Ã™â€žÃ™â€¡ Ã™Â¾Ã›Å’Ã˜Â¯Ã˜Â§ Ã™â€ Ã˜Â´Ã˜Â¯.')

  let finalStatus = 'confirmed'
  let approvalLevel: string | null = null

  if (deal.agreedPrice && !skipApprovalCheck) {
    approvalLevel = await evaluateApprovalRequirement('Deal', deal.agreedPrice)
    if (approvalLevel) {
      finalStatus = 'awaiting_approval'
    }
  }

  const deadline = await calculateBusinessHoursDeadline(new Date(), rules.buyerPaymentHours)
  // مهلت پرداخت کارمزد فروشنده فقط وقتی معامله به confirmed می‌رسد آغاز می‌شود؛
  // در حالت awaiting_approval null می‌ماند و بعداً (approveDealAction → startBuyerPaymentDeadline(..., true)) ست می‌شود
  const sellerFeeDeadline =
    finalStatus === 'confirmed'
      ? await calculateBusinessHoursDeadline(new Date(), rules.sellerFeeHours)
      : null
  await prisma.deal.update({
    where: { id: dealId },
    data: {
      status: finalStatus,
      buyerConfirmDeadline: approvalLevel ? null : deadline,
      sellerFeeDeadline,
    },
  })
  return deadline
}

/** Ã™â€¦Ã™Ë†Ã™â€šÃ˜Â¹ Ã˜Â«Ã˜Â¨Ã˜Âª Ã™â€šÃ›Å’Ã™â€¦Ã˜Âª Ã™â€ Ã™â€¡Ã˜Â§Ã›Å’Ã›Å’ Ã˜Â³Ã™ÂÃ˜Â§Ã˜Â±Ã˜Â´ Ã˜ÂªÃ™Ë†Ã˜Â³Ã˜Â· ÃšÂ©Ã˜Â§Ã˜Â±Ã˜Â´Ã™â€ Ã˜Â§Ã˜Â³ Ã™ÂÃ˜Â±Ã™Ë†Ã˜Â´ Ã¢â‚¬â€ Ã™â€¦Ã™â€¡Ã™â€žÃ˜Âª Ã˜ÂªÃ˜Â§Ã›Å’Ã›Å’Ã˜Â¯ Ã™Â¾Ã›Å’Ã˜Â´Ã¢â‚¬Å’Ã™ÂÃ˜Â§ÃšÂ©Ã˜ÂªÃ™Ë†Ã˜Â± Ã˜ÂªÃ™Ë†Ã˜Â³Ã˜Â· Ã™â€¦Ã˜Â´Ã˜ÂªÃ˜Â±Ã›Å’ Ã˜Â´Ã˜Â±Ã™Ë†Ã˜Â¹ Ã™â€¦Ã›Å’Ã¢â‚¬Å’Ã˜Â´Ã™â€¡ */
export async function startProformaDeadline(orderId: string) {
  const rules = await getDealRuleSettings()
  const deadline = await calculateBusinessHoursDeadline(new Date(), rules.proformaConfirmHours)
  await prisma.order.update({
    where: { id: orderId },
    data: { status: 'priced', proformaDeadline: deadline },
  })
  return deadline
}

/**
 * Ã™â€¦Ã™â€¡Ã™â€žÃ˜Âª Ã˜ÂªÃ˜Â§Ã›Å’Ã›Å’Ã˜Â¯ Ã™Â¾Ã›Å’Ã˜Â´Ã¢â‚¬Å’Ã™ÂÃ˜Â§ÃšÂ©Ã˜ÂªÃ™Ë†Ã˜Â± ÃšÂ¯Ã˜Â°Ã˜Â´Ã˜ÂªÃ™â€¡ Ã™Ë† Ã™â€¦Ã˜Â´Ã˜ÂªÃ˜Â±Ã›Å’ Ã™â€¡Ã™â€ Ã™Ë†Ã˜Â² Ã˜ÂªÃ˜Â§Ã›Å’Ã›Å’Ã˜Â¯ Ã™â€ ÃšÂ©Ã˜Â±Ã˜Â¯Ã™â€¡ Ã¢â€ â€™ Ã˜Â³Ã™ÂÃ˜Â§Ã˜Â±Ã˜Â´ Ã˜Â®Ã™Ë†Ã˜Â¯ÃšÂ©Ã˜Â§Ã˜Â± Ã˜Â¨Ã˜Â§Ã˜Â·Ã™â€ž
 * Ã™â€¦Ã›Å’Ã¢â‚¬Å’Ã˜Â´Ã™â€¡ (status=rejected Ã˜Â¨Ã˜Â§ Ã˜ÂªÃ™Ë†Ã˜Â¶Ã›Å’Ã˜Â­ Ã™â€¦Ã˜ÂªÃ™â€¦Ã˜Â§Ã›Å’Ã˜Â² Ã˜Â¯Ã˜Â± StatusEvent) Ã™Ë† Ã™â€¦Ã™Ë†Ã˜Â¬Ã™Ë†Ã˜Â¯Ã›Å’ Ã™â€šÃ™ÂÃ™â€žÃ¢â‚¬Å’Ã˜Â´Ã˜Â¯Ã™â€¡Ã¢â‚¬Å’Ã›Å’
 * Ã™â€¡Ã˜Â± Ã™â€šÃ™â€žÃ™â€¦ Ã˜Â¨Ã™â€¡ Ã˜Â§Ã™â€ Ã˜Â¨Ã˜Â§Ã˜Â± Ã˜Â¨Ã˜Â±Ã™â€¦Ã›Å’Ã¢â‚¬Å’ÃšÂ¯Ã˜Â±Ã˜Â¯Ã™â€¡ Ã¢â‚¬â€ Ã™â€¡Ã™â€¦Ã™Ë†Ã™â€  Ã˜ÂªÃ˜Â±Ã˜Â§ÃšÂ©Ã™â€ Ã˜Â´Ã›Å’ ÃšÂ©Ã™â€¡ rejectOrder Ã˜Â¯Ã˜Â³Ã˜ÂªÃ›Å’ Ã˜Â§Ã™â€ Ã˜Â¬Ã˜Â§Ã™â€¦ Ã™â€¦Ã›Å’Ã¢â‚¬Å’Ã˜Â¯Ã™â€¡.
 * Ã™â€¦Ã˜Â«Ã™â€ž Ã˜Â¨Ã™â€šÃ›Å’Ã™â€¡Ã¢â‚¬Å’Ã›Å’ enforceÃ™â€¡Ã˜Â§Ã˜Å’ Ã˜Â¨Ã™â€¡Ã¢â‚¬Å’Ã˜Â¬Ã˜Â§Ã›Å’ cron Ã™â€¦Ã™Ë†Ã™â€šÃ˜Â¹ Ã™â€žÃ™Ë†Ã˜Â¯ Ã˜ÂµÃ™ÂÃ˜Â­Ã™â€¡Ã¢â‚¬Å’Ã™â€¡Ã˜Â§Ã›Å’ /proformas Ã˜ÂµÃ˜Â¯Ã˜Â§ Ã˜Â²Ã˜Â¯Ã™â€¡ Ã™â€¦Ã›Å’Ã¢â‚¬Å’Ã˜Â´Ã™â€¡.
 */
export async function enforceProformaDeadlines() {
  const now = new Date()
  const overdue = await prisma.order.findMany({
    where: { status: 'priced', proformaDeadline: { lt: now } },
    include: { items: true },
  })

  for (const order of overdue) {
    const itemsWithWarehouse = order.items.filter((item) => item.warehouseId)
    await prisma.$transaction([
      ...itemsWithWarehouse.map((item) =>
        prisma.warehouseStock.updateMany({
          where: { warehouseId: item.warehouseId as string, gradeId: item.gradeId },
          data: { quantityTon: { increment: item.quantity } },
        })
      ),
      prisma.order.update({ where: { id: order.id }, data: { status: 'rejected' } }),
    ])

    await logStatusEvent({
      recordType: 'Order',
      recordId: order.id,
      newStageKey: 'rejected',
      note: 'Ã™â€¦Ã™â€¡Ã™â€žÃ˜Âª Ã˜ÂªÃ˜Â§Ã›Å’Ã›Å’Ã˜Â¯ Ã™Â¾Ã›Å’Ã˜Â´Ã¢â‚¬Å’Ã™ÂÃ˜Â§ÃšÂ©Ã˜ÂªÃ™Ë†Ã˜Â± ÃšÂ¯Ã˜Â°Ã˜Â´Ã˜Âª Ã¢â‚¬â€ Ã˜Â³Ã™ÂÃ˜Â§Ã˜Â±Ã˜Â´ Ã˜Â®Ã™Ë†Ã˜Â¯ÃšÂ©Ã˜Â§Ã˜Â± Ã˜Â¨Ã˜Â§Ã˜Â·Ã™â€ž Ã˜Â´Ã˜Â¯ Ã™Ë† Ã™â€¦Ã™Ë†Ã˜Â¬Ã™Ë†Ã˜Â¯Ã›Å’ Ã˜Â¨Ã™â€¡ Ã˜Â§Ã™â€ Ã˜Â¨Ã˜Â§Ã˜Â± Ã˜Â¨Ã˜Â±ÃšÂ¯Ã˜Â´Ã˜Âª',
    })
  }

  return overdue.length
}
