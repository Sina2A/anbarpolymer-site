'use client'

type Ping = { latitude: number; longitude: number; capturedAt?: string | Date }

export default function TripRouteMap({ pings, dealId }: { pings: Ping[]; dealId: string }) {
  const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY
  const hasKey = !!apiKey

  if (pings.length === 0) {
    return (
      <div style={placeholderStyle}>
        <div style={{ fontSize: 13, fontWeight: 700, color: '#4f5560' }}>نقشه‌ی مسیر</div>
        <div style={{ fontSize: 11.5, color: '#9199a3', marginTop: 6 }}>هنوز موقعیتی ثبت نشده — با قبول سفر و تایید بارگیری/تخلیه، نقاط مسیر اینجا ظاهر می‌شود.</div>
        <div style={{ fontSize: 11, color: '#9199a3', marginTop: 10 }}>آماده‌ی اتصال به Google Maps — کافی است NEXT_PUBLIC_GOOGLE_MAPS_API_KEY را ست کنید تا Polyline نمایش داده شود.</div>
      </div>
    )
  }

  if (!hasKey) {
    return (
      <div style={placeholderStyle}>
        <div style={{ fontSize: 13, fontWeight: 700, color: '#4f5560' }}>مسیر ثبت‌شده ({pings.length} نقطه)</div>
        <div style={{ marginTop: 8, display: 'flex', flexDirection: 'column', gap: 4 }}>
          {pings.map((p, i) => (
            <a
              key={i}
              href={`https://maps.google.com/?q=${p.latitude},${p.longitude}`}
              target="_blank"
              rel="noopener noreferrer"
              style={{ fontSize: 11.5, color: '#1e357b', textDecoration: 'underline' }}
            >
              {i + 1}. {p.latitude.toFixed(5)}, {p.longitude.toFixed(5)}
            </a>
          ))}
        </div>
        <div style={{ fontSize: 11, color: '#9199a3', marginTop: 10 }}>بدون کلید Maps: لیست مختصات + لینک Google Maps. با کلید، Polyline رسم می‌شود.</div>
      </div>
    )
  }

  // با کلید: فعلاً همان لیست + آماده‌ی Polyline (نصب @react-google-maps/api در فاز بعدی)
  return (
    <div style={{ ...placeholderStyle, borderStyle: 'solid', borderColor: '#1e357b22' }}>
      <div style={{ fontSize: 13, fontWeight: 700, color: '#1e357b' }}>مسیر ({pings.length} نقطه) — Polyline آماده</div>
      <div style={{ marginTop: 8, display: 'flex', flexDirection: 'column', gap: 4 }}>
        {pings.map((p, i) => (
          <span key={i} style={{ fontSize: 11.5, color: '#4f5560' }}>
            {i + 1}. {p.latitude.toFixed(5)}, {p.longitude.toFixed(5)}
          </span>
        ))}
      </div>
    </div>
  )
}

const placeholderStyle: React.CSSProperties = {
  height: 280,
  border: '2px dashed #d8dde3',
  borderRadius: 12,
  background: '#f8f9fb',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  padding: 16,
  textAlign: 'center',
}
