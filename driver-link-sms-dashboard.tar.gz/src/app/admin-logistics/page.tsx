import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import AdminNav, { PartialAccessBanner } from '@/components/AdminNav'
import TripRouteMap from '@/components/TripRouteMap'
import { regenerateDriverLinkAction, assignTransportCompanyAction, assignDriverAction } from './actions'
import CreateTransportCompanyForm from './CreateTransportCompanyForm'
import { colors, radius, fontSize, shadow, spacing } from '@/lib/styles/tokens'
import { enforcePendingSmsQueue } from '@/lib/smsQueue'
import {
  pageStyle as sharedPageStyle,
  pageWrapStyle as sharedPageWrapStyle,
  contentStyle as sharedContentStyle,
  cardStyle as sharedCardStyle,
  tableStyle as sharedTableStyle,
  thStyle as sharedThStyle,
  tdStyle as sharedTdStyle,
  emptyStateStyle as sharedEmptyStateStyle,
  badgeStyle,
} from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

type TabId = 'shipments' | 'sms' | 'map'
const TAB_LABELS: Record<TabId, string> = { shipments: 'محموله‌ها', sms: 'صف پیامک', map: 'نقشه مسیر' }
function parseTab(raw: string | string[] | undefined): TabId {
  if (raw === 'sms' || raw === 'map') return raw
  return 'shipments'
}

export default async function AdminLogisticsPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>
}) {
  const sp = await searchParams
  await enforcePendingSmsQueue()
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)
  const level = isAdmin ? 'full' : myAccess?.logistics ?? 'none'
  const hasAccess = level !== 'none'
  const canEdit = level === 'edit' || level === 'full'
  const activeTab = parseTab(sp.tab)

  const feedback =
    typeof sp.regenerated === 'string'
      ? 'لینک راننده دوباره ساخته شد.'
      : typeof sp.assigned === 'string'
        ? 'شرکت حمل‌ونقل به‌روزرسانی شد.'
        : sp.driver === 'assigned'
          ? 'راننده به معامله اختصاص یافت.'
          : sp.driver === 'replaced'
            ? 'راننده‌ی معامله جایگزین شد.'
            : null

  const deals = hasAccess
    ? await prisma.deal.findMany({
        where: {
          OR: [
            { status: { in: ['transport_pending', 'payment_secured', 'loading', 'in_transit'] } },
            { confirmations: { some: {} } },
            { driverLinks: { some: {} } },
          ],
        },
        include: {
          buyer: { select: { companyName: true } },
          materialListing: { include: { grade: { select: { code: true } } } },
          confirmations: { orderBy: { confirmedAt: 'desc' }, take: 10 },
          driverLinks: { orderBy: { createdAt: 'desc' }, take: 1 },
          transportCompany: { select: { name: true } },
          driver: { select: { id: true, fullName: true, phone: true } },
        },
        orderBy: { id: 'desc' },
        take: 100,
      })
    : []

  // آمار کارت‌ها — از همین ۱۰۰ رکورد محاسبه می‌شود (برای داشبورد داخلی کافی است)
  const todayStart = new Date()
  todayStart.setHours(0, 0, 0, 0)
  const stats = hasAccess
    ? {
        totalActive: deals.filter((d) => ['transport_pending', 'payment_secured', 'loading', 'in_transit'].includes(d.status)).length,
        awaitingDriver: deals.filter((d) => !d.driverId && ['transport_pending', 'payment_secured', 'loading', 'in_transit'].includes(d.status)).length,
        needsFollowUp: deals.filter((d) => d.driverSilenceFlaggedAt != null).length,
        completedToday: deals.filter((d) => ['delivered', 'settled'].includes(d.status) && new Date(d.updatedAt) >= todayStart).length,
      }
    : null

  const transportCompanies = hasAccess && canEdit
    ? await prisma.transportCompany.findMany({ where: { isActive: true }, select: { id: true, name: true } })
    : []

  const relevantCompanyIds = canEdit
    ? Array.from(new Set(deals.map((d) => d.transportCompanyId).filter((id): id is string => !!id)))
    : []
  const drivers = relevantCompanyIds.length
    ? await prisma.driver.findMany({
        where: { isActive: true, transportCompanyId: { in: relevantCompanyIds } },
        select: { id: true, fullName: true, phone: true, transportCompanyId: true },
        orderBy: { fullName: 'asc' },
      })
    : []
  const driversByCompany = new Map<string, typeof drivers>()
  for (const d of drivers) {
    const list = driversByCompany.get(d.transportCompanyId) ?? []
    list.push(d)
    driversByCompany.set(d.transportCompanyId, list)
  }

  // پیام‌های صف — اگر جدول هنوز migrate نشده باشد، catch و placeholder
  let pendingSms: Array<{ id: string; recipientPhone: string; message: string; status: string; autoSendAt: Date; createdAt: Date }> = []
  if (hasAccess && activeTab === 'sms') {
    try {
      const raw = await (prisma as unknown as { pendingSmsMessage: { findMany: (a: unknown) => Promise<typeof pendingSms> } }).pendingSmsMessage.findMany({
        where: { status: 'pending' },
        orderBy: { autoSendAt: 'asc' },
        take: 50,
      })
      pendingSms = raw
    } catch {
      pendingSms = []
    }
  }

  return (
    <div style={sharedPageStyle}>
      <div style={sharedPageWrapStyle} className="admin-page-wrap">
        <AdminNav currentUserName={currentUser.companyName} currentUsername={currentUser.username} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="logistics" />
        <div style={sharedContentStyle}>
          <h1 style={{ fontSize: fontSize.xxl, fontWeight: 800, color: colors.textPrimary, margin: '0 0 4px' }}>حمل و نقل — هماهنگی داخلی</h1>
          <p style={{ fontSize: fontSize.base, color: colors.textMuted, margin: '0 0 20px' }}>
            نمای نظارتی داخلی روی همه‌ی معاملاتی که وارد مرحله‌ی حمل‌ونقل شدن — جدا از پنل شرکت حمل‌ونقل (`/transport-panel`) و ردیابی خریدار/فروشنده (`/transport`).
          </p>

          <PartialAccessBanner level={level} sectionLabel="حمل و نقل — هماهنگی داخلی" />

          {feedback && (
            <div style={{ background: colors.successBg, color: colors.successText, borderRadius: radius.md, padding: '10px 14px', fontSize: fontSize.base, marginBottom: 14 }}>
              {feedback}
            </div>
          )}

          {!hasAccess && <div style={sharedEmptyStateStyle}>به این بخش دسترسی نداری.</div>}

          {canEdit && (
            <div style={{ ...sharedCardStyle, boxShadow: shadow.card, marginBottom: 20 }}>
              <div style={{ marginBottom: 14 }}>
                <b style={{ fontSize: fontSize.md }}>ساخت شرکت حمل‌ونقل و حساب مدیر</b>
                <p style={{ fontSize: fontSize.sm, color: colors.textMuted, margin: '4px 0 0' }}>
                  شرکت حمل‌ونقل جدید به‌همراه حساب کاربری مدیرش در یک عملیات ساخته می‌شود. دسترسی پنل شرکت به‌صورت پیش‌فرض غیرفعاله و بعداً از «مدیریت کاربران» فعال می‌شه.
                </p>
              </div>
              <CreateTransportCompanyForm />
            </div>
          )}

          {hasAccess && stats && (
            <>
              {/* کارت‌های آماری */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: spacing.md, marginBottom: 16 }}>
                <StatCard label="کل در حمل" value={stats.totalActive} bg={colors.infoBg} color={colors.infoText} />
                <StatCard label="در انتظار راننده" value={stats.awaitingDriver} bg={colors.warningBg} color={colors.warningText} />
                <StatCard label="نیازمند پیگیری" value={stats.needsFollowUp} bg={stats.needsFollowUp ? colors.dangerBg : colors.neutralBg} color={stats.needsFollowUp ? colors.dangerText : colors.neutralText} />
                <StatCard label="تکمیل امروز" value={stats.completedToday} bg={colors.successBg} color={colors.successText} />
              </div>

              {/* تب‌ها */}
              <div style={{ display: 'flex', gap: 6, marginBottom: 14, borderBottom: `1px solid ${colors.borderSubtle}`, paddingBottom: 8 }}>
                {(Object.keys(TAB_LABELS) as TabId[]).map((tab) => {
                  const active = tab === activeTab
                  return (
                    <a
                      key={tab}
                      href={`/admin-logistics?tab=${tab}`}
                      style={{
                        fontSize: fontSize.sm,
                        fontWeight: active ? 800 : 600,
                        color: active ? colors.navy : colors.textMuted,
                        background: active ? colors.bgActiveTint : 'transparent',
                        border: `1px solid ${active ? colors.borderStrong : 'transparent'}`,
                        borderRadius: radius.sm,
                        padding: '6px 14px',
                        textDecoration: 'none',
                      }}
                    >
                      {TAB_LABELS[tab]}
                    </a>
                  )
                })}
              </div>

              {/* محتوای تب */}
              {activeTab === 'shipments' && (
                <ShipmentsTab deals={deals} transportCompanies={transportCompanies} driversByCompany={driversByCompany} canEdit={canEdit} />
              )}

              {activeTab === 'sms' && (
                <SmsQueueTab pendingSms={pendingSms} />
              )}

              {activeTab === 'map' && (
                <MapTab deals={deals} />
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}

function StatCard({ label, value, bg, color }: { label: string; value: number; bg: string; color: string }) {
  return (
    <div style={{ background: colors.bgCard, border: `1px solid ${colors.borderSubtle}`, borderRadius: radius.lg, padding: '14px 16px', boxShadow: shadow.card }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: colors.textMuted, marginBottom: 6 }}>{label}</div>
      <div style={{ fontSize: 22, fontWeight: 800, color }}>{value}</div>
      <div style={{ marginTop: 8, height: 4, borderRadius: 999, background: bg, position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0, background: color, opacity: 0.85, width: value ? '100%' : '0' }} />
      </div>
    </div>
  )
}

type DealRow = Awaited<ReturnType<typeof prisma.deal.findMany>>[number] & {
  buyer: { companyName: string } | null
  materialListing: { grade: { code: string } | null } | null
  confirmations: Array<{ id: string; type: string; driverName: string | null; confirmedAt: Date; photoUrl: string | null; latitude: number | null; longitude: number | null }>
  driverLinks: Array<{ token: string; expiresAt: Date; usedAt: Date | null; createdAt: Date }>
  transportCompany: { name: string } | null
  driver: { id: string; fullName: string; phone: string } | null
  transportCompanyId: string | null
  driverId: string | null
  status: string
  driverSilenceFlaggedAt: Date | null
  currentLatitude: number | null
  currentLongitude: number | null
  updatedAt: Date
}

function ShipmentsTab({
  deals,
  transportCompanies,
  driversByCompany,
  canEdit,
}: {
  deals: DealRow[]
  transportCompanies: Array<{ id: string; name: string }>
  driversByCompany: Map<string, Array<{ id: string; fullName: string; phone: string; transportCompanyId: string }>>
  canEdit: boolean
}) {
  if (deals.length === 0) {
    return <div style={sharedEmptyStateStyle}>فعلاً هیچ معامله‌ای وارد مرحله‌ی حمل‌ونقل نشده.</div>
  }

  return (
    <div style={{ ...sharedCardStyle, boxShadow: shadow.card }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
        <b style={{ fontSize: fontSize.md }}>معاملات در جریان حمل‌ونقل</b>
        <span style={countBadgeStyle}>{deals.length}</span>
      </div>

      <div style={{ overflowX: 'auto' }}>
        <table style={sharedTableStyle}>
          <thead>
            <tr style={{ background: colors.bgPage }}>
              <th style={sharedThStyle}>شناسه</th>
              <th style={sharedThStyle}>گرید</th>
              <th style={sharedThStyle}>خریدار</th>
              <th style={sharedThStyle}>آخرین تاییدیه</th>
              <th style={sharedThStyle}>شرکت حمل‌ونقل</th>
              <th style={sharedThStyle}>راننده</th>
              <th style={sharedThStyle}>لینک راننده</th>
              <th style={sharedThStyle}>پیگیری</th>
              {canEdit && <th style={sharedThStyle}>عملیات</th>}
            </tr>
          </thead>
          <tbody>
            {deals.map((deal) => {
              const lastConfirmation = deal.confirmations[0]
              const lastLink = deal.driverLinks[0]
              const linkStatus = !lastLink
                ? 'بدون لینک'
                : lastLink.usedAt
                  ? 'استفاده‌شده'
                  : new Date(lastLink.expiresAt) < new Date()
                    ? 'منقضی'
                    : 'فعال'
              const linkStatusColor =
                linkStatus === 'فعال'
                  ? colors.darkGreenText
                  : linkStatus === 'استفاده‌شده'
                    ? colors.infoText
                    : colors.textMuted

              const eligibleDrivers = deal.transportCompanyId
                ? (driversByCompany.get(deal.transportCompanyId) ?? []).filter((dr) => dr.id !== deal.driverId)
                : []

              const photoCount = deal.confirmations.filter((c) => c.photoUrl).length
              const timeline = deal.confirmations.slice(0, 4)

              return (
                <tr key={deal.id}>
                  <td style={{ ...sharedTdStyle, fontFamily: 'monospace', fontSize: fontSize.xs }}>{deal.id.slice(0, 8)}</td>
                  <td style={sharedTdStyle}>{deal.materialListing?.grade?.code ?? '—'}</td>
                  <td style={sharedTdStyle}>{deal.buyer?.companyName ?? '—'}</td>
                  <td style={{ ...sharedTdStyle, fontSize: 12 }}>
                    {lastConfirmation
                      ? `${translateConfirmationType(lastConfirmation.type)} — ${lastConfirmation.driverName ?? 'بدون نام'}`
                      : '—'}
                    {timeline.length > 1 && (
                      <div style={{ marginTop: 4, display: 'flex', flexDirection: 'column', gap: 2 }}>
                        {timeline.slice(1).map((c) => (
                          <span key={c.id} style={{ fontSize: 11, color: colors.textMuted }}>
                            {translateConfirmationType(c.type)} · {new Date(c.confirmedAt).toLocaleDateString('fa-IR')}
                          </span>
                        ))}
                      </div>
                    )}
                    {photoCount > 0 && (
                      <div style={{ marginTop: 4 }}>
                        <span style={{ ...badgeStyle('neutral'), fontSize: 10 }}>{photoCount} عکس</span>
                      </div>
                    )}
                  </td>
                  <td style={{ ...sharedTdStyle, fontSize: 12 }}>
                    {canEdit ? (
                      <form action={assignTransportCompanyAction} style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                        <input type="hidden" name="dealId" value={deal.id} />
                        <select
                          name="transportCompanyId"
                          defaultValue={deal.transportCompanyId ?? ''}
                          style={{ fontSize: 11.5, padding: '4px 6px', borderRadius: radius.sm, border: `1px solid ${colors.borderStrong}`, fontFamily: 'inherit' }}
                        >
                          <option value="">— بدون شرکت —</option>
                          {transportCompanies.map((tc) => (
                            <option key={tc.id} value={tc.id}>{tc.name}</option>
                          ))}
                        </select>
                        <button type="submit" style={smallBtnStyle}>ثبت</button>
                      </form>
                    ) : (
                      deal.transportCompany?.name ?? '—'
                    )}
                  </td>
                  <td style={{ ...sharedTdStyle, fontSize: 12 }}>
                    {canEdit ? (
                      !deal.transportCompanyId ? (
                        <span style={{ color: colors.textMuted }}>اول شرکت را مشخص کن</span>
                      ) : (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                          {deal.driver && (
                            <span style={{ fontWeight: 700, color: colors.textPrimary }}>
                              {deal.driver.fullName}
                              <span style={{ fontWeight: 400, color: colors.textMuted, marginRight: 4 }}>({deal.driver.phone})</span>
                            </span>
                          )}
                          {eligibleDrivers.length === 0 ? (
                            !deal.driver && <span style={{ color: colors.textMuted }}>راننده‌ی فعالی نیست</span>
                          ) : (
                            <form action={assignDriverAction} style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                              <input type="hidden" name="dealId" value={deal.id} />
                              <select name="driverId" defaultValue="" required style={{ fontSize: 11.5, padding: '4px 6px', borderRadius: radius.sm, border: `1px solid ${colors.borderStrong}`, fontFamily: 'inherit' }}>
                                <option value="" disabled>{deal.driver ? '— جایگزینی —' : '— انتخاب —'}</option>
                                {eligibleDrivers.map((dr) => (
                                  <option key={dr.id} value={dr.id}>{dr.fullName} — {dr.phone}</option>
                                ))}
                              </select>
                              <button type="submit" style={smallBtnStyle}>{deal.driver ? 'جایگزینی' : 'اختصاص'}</button>
                            </form>
                          )}
                        </div>
                      )
                    ) : (
                      deal.driver ? `${deal.driver.fullName} (${deal.driver.phone})` : '—'
                    )}
                  </td>
                  <td style={{ ...sharedTdStyle, color: linkStatusColor, fontWeight: 700, fontSize: 12 }}>{linkStatus}</td>
                  <td style={sharedTdStyle}>
                    {deal.driverSilenceFlaggedAt ? (
                      <span style={badgeStyle('danger')}>نیازمند پیگیری</span>
                    ) : (
                      <span style={{ fontSize: 11.5, color: colors.textMuted }}>عادی</span>
                    )}
                  </td>
                  {canEdit && (
                    <td style={sharedTdStyle}>
                      <form action={regenerateDriverLinkAction}>
                        <input type="hidden" name="dealId" value={deal.id} />
                        <button type="submit" style={smallBtnStyle}>لینک دوباره</button>
                      </form>
                    </td>
                  )}
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      {/* گالری آکاردئونی — عکس‌های مدرک حمل */}
      <GalleryAccordion deals={deals} />
    </div>
  )
}

function GalleryAccordion({ deals }: { deals: DealRow[] }) {
  const photos = deals.flatMap((d) =>
    d.confirmations
      .filter((c) => c.photoUrl)
      .map((c) => ({ dealId: d.id, photoUrl: c.photoUrl!, type: c.type, confirmedAt: c.confirmedAt }))
  )
  if (photos.length === 0) return null
  return (
    <details style={{ marginTop: 16, border: `1px solid ${colors.borderSubtle}`, borderRadius: radius.md, padding: '10px 14px' }}>
      <summary style={{ fontSize: fontSize.sm, fontWeight: 700, color: colors.textPrimary, cursor: 'pointer', listStyle: 'revert' }}>
        گالری مدرک حمل ({photos.length} عکس)
      </summary>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(120px, 1fr))', gap: 10, marginTop: 12 }}>
        {photos.map((p, i) => (
          <a key={i} href={p.photoUrl} target="_blank" rel="noopener noreferrer" style={{ display: 'block', borderRadius: radius.sm, overflow: 'hidden', border: `1px solid ${colors.borderSubtle}` }}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={p.photoUrl} alt={`${p.type} — ${p.dealId.slice(0, 8)}`} style={{ width: '100%', height: 90, objectFit: 'cover', display: 'block' }} />
            <div style={{ fontSize: 10, color: colors.textMuted, padding: '4px 6px', textAlign: 'center' }}>
              {translateConfirmationType(p.type)} · {p.dealId.slice(0, 8)}
            </div>
          </a>
        ))}
      </div>
    </details>
  )
}

function SmsQueueTab({
  pendingSms,
}: {
  pendingSms: Array<{ id: string; recipientPhone: string; message: string; status: string; autoSendAt: Date; createdAt: Date }>
}) {
  return (
    <div style={{ ...sharedCardStyle, boxShadow: shadow.card }}>
      <b style={{ fontSize: fontSize.md }}>صف پیامک — تایید ۶۰دقیقه‌ای</b>
      <p style={{ fontSize: fontSize.sm, color: colors.textMuted, margin: '6px 0 14px' }}>
        هر پیام ابتدا ۶۰ دقیقه در وضعیت «در انتظار تایید» می‌ماند؛ ادمین می‌تواند قبل از ارسال خودکار آن را تایید یا رد کند. الگوی <code>enforceDealDeadlines</code> بازیافت شده: هر بازدید این صفحه پیام‌های منقضیِ تاییدنشده را خودکار ارسال می‌کند.
      </p>

      {pendingSms.length === 0 ? (
        <div style={sharedEmptyStateStyle}>
          پیامی در صف نیست.
          <div style={{ fontSize: 11, color: colors.textMuted, marginTop: 8 }}>
            تا migration جدول <code>PendingSmsMessage</code> اجرا نشود، پیام‌ها مستقیماً از طریق <code>sendSms()</code> استاب ارسال می‌شوند و اینجا خالی می‌ماند.
            طرح پیشنهادی migration در فایل <code>NOTES-TRANSPORT-SHIPMENTS-PAGES.md</code> آمده (فقط پیشنهاد، بدون اجرا).
          </div>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {pendingSms.map((m) => {
            const remainMs = new Date(m.autoSendAt).getTime() - Date.now()
            const remainMin = Math.max(0, Math.ceil(remainMs / 60000))
            return (
              <div key={m.id} style={{ border: `1px solid ${colors.borderSubtle}`, borderRadius: radius.md, padding: '10px 12px', display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'center' }}>
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontSize: 12, color: colors.textPrimary, wordBreak: 'break-word' }}>{m.message}</div>
                  <div style={{ fontSize: 11, color: colors.textMuted, marginTop: 4, direction: 'ltr', textAlign: 'right' }}>{m.recipientPhone} · {new Date(m.createdAt).toLocaleString('fa-IR')}</div>
                </div>
                <div style={{ flexShrink: 0, textAlign: 'center' }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: remainMin <= 10 ? colors.dangerText : colors.textMuted }}>{remainMin} دقیقه تا ارسال</div>
                  <div style={{ fontSize: 10, color: colors.textMuted }}>وضعیت: {m.status}</div>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}

function MapTab({ deals }: { deals: DealRow[] }) {
  const dealsWithPings = deals
    .map((d) => {
      const pings = d.confirmations
        .filter((c) => c.latitude != null && c.longitude != null)
        .map((c) => ({ latitude: c.latitude!, longitude: c.longitude!, capturedAt: c.confirmedAt }))
      if (d.currentLatitude != null && d.currentLongitude != null) {
        const exists = pings.some((p) => p.latitude === d.currentLatitude && p.longitude === d.currentLongitude)
        if (!exists) pings.push({ latitude: d.currentLatitude, longitude: d.currentLongitude })
      }
      return { deal: d, pings }
    })
    .filter((x) => x.pings.length > 0)

  if (dealsWithPings.length === 0) {
    return (
      <div style={{ ...sharedCardStyle, boxShadow: shadow.card }}>
        <div style={sharedEmptyStateStyle}>
          هنوز نقطه‌ی مسیری ثبت نشده — با قبول سفر و تایید بارگیری/تخلیه، نقاط رویدادمحور (۵ نقطه: accept/arrival-loading/confirm-loading/arrival-unloading/confirm-unloading) اینجا ظاهر می‌شود.
          <div style={{ marginTop: 12 }}>
            <TripRouteMap pings={[]} dealId="" />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      {dealsWithPings.map(({ deal, pings }) => (
        <div key={deal.id} style={{ ...sharedCardStyle, boxShadow: shadow.card }}>
          <div style={{ fontSize: fontSize.sm, fontWeight: 700, color: colors.textPrimary, marginBottom: 8 }}>
            #{deal.id.slice(0, 8)} · {deal.materialListing?.grade?.code ?? '—'} · {deal.buyer?.companyName ?? '—'}
            <span style={{ fontWeight: 400, color: colors.textMuted, marginRight: 8 }}>{pings.length} نقطه</span>
          </div>
          <TripRouteMap pings={pings} dealId={deal.id} />
        </div>
      ))}
    </div>
  )
}

function translateConfirmationType(type: string): string {
  const map: Record<string, string> = {
    loading: 'بارگیری',
    unloading: 'تخلیه',
    driver_confirm: 'تایید راننده',
    buyer_confirm: 'تایید خریدار',
    driver_accepted: 'پذیرش سفر',
    driver_rejected: 'رد سفر',
  }
  return map[type] ?? type
}

const countBadgeStyle: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 700,
  background: colors.orange,
  color: '#fff',
  borderRadius: radius.md,
  padding: '2px 10px',
}
const smallBtnStyle: React.CSSProperties = {
  background: colors.navy,
  color: '#fff',
  border: 'none',
  borderRadius: radius.sm,
  padding: '6px 12px',
  fontSize: 11.5,
  fontWeight: 700,
  cursor: 'pointer',
  fontFamily: 'inherit',
}
