import { NextRequest, NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { validateDriverToken } from '@/lib/driverAccess'

/**
 * موقعیت راننده — قبل از in_transit هم مجاز است (مثلاً هنگام «قبول سفر» یا
 * رسیدن به محل بارگیری). فقط وقتی Deal در وضعیت‌های باطل/لغو/تسویه است رد می‌شود.
 */
const ALLOWED_STATUSES = new Set(['transport_pending', 'payment_secured', 'loading', 'in_transit'])

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { token, latitude, longitude } = body

    if (!token || latitude == null || longitude == null) {
      return NextResponse.json({ error: 'فیلدهای الزامی ناقص است' }, { status: 400 })
    }

    const lat = Number(latitude)
    const lng = Number(longitude)
    if (!Number.isFinite(lat) || !Number.isFinite(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) {
      return NextResponse.json({ error: 'مختصات نامعتبر است' }, { status: 400 })
    }

    const { valid, link } = await validateDriverToken(token)
    if (!valid || !link) {
      return NextResponse.json({ error: 'توکن نامعتبر است' }, { status: 401 })
    }

    const deal = link.deal
    if (!ALLOWED_STATUSES.has(deal.status)) {
      return NextResponse.json({ error: 'معامله در مرحله‌ی حمل نیست' }, { status: 400 })
    }

    await prisma.deal.update({
      where: { id: deal.id },
      data: {
        currentLatitude: lat,
        currentLongitude: lng,
        locationUpdatedAt: new Date(),
      },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Driver location update error:', error)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
