'use client'

import { useState } from 'react'
import { acceptDriverTripAction, rejectDriverTripAction } from './actions'

export default function AcceptRejectButtons({ token }: { token: string }) {
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null)
  const [locating, setLocating] = useState(false)

  function captureLocation(): Promise<{ lat: number; lng: number } | null> {
    if (!navigator.geolocation) return Promise.resolve(null)
    setLocating(true)
    return new Promise((resolve) => {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const c = { lat: pos.coords.latitude, lng: pos.coords.longitude }
          setCoords(c)
          setLocating(false)
          resolve(c)
        },
        () => { setLocating(false); resolve(null) },
        { enableHighAccuracy: true, timeout: 8000 }
      )
    })
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      <form
        action={async (fd: FormData) => {
          const c = coords ?? (await captureLocation())
          if (c) { fd.set('latitude', String(c.lat)); fd.set('longitude', String(c.lng)) }
          await acceptDriverTripAction(fd)
        }}
        style={{ display: 'flex', gap: 8 }}
      >
        <input type="hidden" name="token" value={token} />
        {coords && (
          <>
            <input type="hidden" name="latitude" value={coords.lat} />
            <input type="hidden" name="longitude" value={coords.lng} />
          </>
        )}
        <button
          type="submit"
          disabled={locating}
          style={primaryBtnStyle}
          onMouseEnter={() => { if (!coords) captureLocation() }}
        >
          {locating ? 'در حال گرفتن موقعیت...' : 'قبول می‌کنم — شروع سفر'}
        </button>
      </form>

      <form action={rejectDriverTripAction} style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
        <input type="hidden" name="token" value={token} />
        <input
          name="reason"
          placeholder="دلیل رد (اختیاری)"
          style={{ flex: 1, padding: '8px 10px', border: '1px solid #d8dde3', borderRadius: 8, fontSize: 12.5, fontFamily: 'inherit' }}
        />
        <button type="submit" style={ghostBtnStyle}>رد می‌کنم</button>
      </form>
      <div style={{ fontSize: 11, color: '#8792a2', textAlign: 'center' }}>
        با «قبول»، موقعیت فعلی شما (در صورت اجازه‌ی مرورگر) همراه تایید ثبت می‌شود.
      </div>
    </div>
  )
}

const primaryBtnStyle: React.CSSProperties = {
  flex: 1, background: '#065f46', color: '#fff', border: 'none', borderRadius: 10, padding: '12px 0', fontSize: 14, fontWeight: 800, cursor: 'pointer', fontFamily: 'inherit',
}
const ghostBtnStyle: React.CSSProperties = {
  background: '#fff', color: '#4f5560', border: '1px solid #d8dde3', borderRadius: 8, padding: '8px 14px', fontSize: 12.5, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit',
}
