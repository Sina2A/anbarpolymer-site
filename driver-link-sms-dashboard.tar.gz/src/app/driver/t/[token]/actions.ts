'use server'

import prisma from '@/lib/prisma'
import { validateDriverToken, markDriverLinkUsed } from '@/lib/driverAccess'
import { queueSms } from '@/lib/smsQueue'
import { redirect } from 'next/navigation'

/**
 * راننده درخواست حمل را صریح می‌پذیرد.
 * - فقط وقتی لینک معتبر و استفاده‌نشده است
 * - DealConfirmation type=driver_accepted ثبت می‌شود
 * - لینک مصرف‌شده علامت می‌خورد (usedAt)
 * - سکوت راننده ریست می‌شود
 * - مختصات اختیاری (ارسال‌شده از کلاینت) روی Deal.current* ذخیره می‌شود
 */
export async function acceptDriverTripAction(formData: FormData) {
  const token = String(formData.get('token') || '')
  const latRaw = formData.get('latitude')
  const lngRaw = formData.get('longitude')
  const latitude = latRaw ? parseFloat(String(latRaw)) : null
  const longitude = lngRaw ? parseFloat(String(lngRaw)) : null

  const { valid, link } = await validateDriverToken(token)
  if (!valid || !link) throw new Error('لینک نامعتبر یا منقضی‌شده.')

  const dealId = link.dealId
  const deal = await prisma.deal.findUnique({ where: { id: dealId } })
  if (!deal) throw new Error('معامله پیدا نشد.')

  const alreadyAccepted = await prisma.dealConfirmation.findFirst({
    where: { dealId, type: 'driver_accepted' },
  })
  if (alreadyAccepted) throw new Error('این سفر قبلاً پذیرفته شده.')

  const alreadyRejected = await prisma.dealConfirmation.findFirst({
    where: { dealId, type: 'driver_rejected' },
    orderBy: { confirmedAt: 'desc' },
  })
  // رد قبلی مانع پذیرش دوباره نیست مگر اینکه ادمین دوباره لینک ساخته باشد — لینک جدید همین را حل می‌کند

  await prisma.dealConfirmation.create({
    data: {
      dealId,
      type: 'driver_accepted',
      driverPhone: link.phone,
      checklistJson: '{}',
      latitude,
      longitude,
      confirmedAt: new Date(),
    },
  })

  await markDriverLinkUsed(token)

  const updateData: Record<string, unknown> = { driverSilenceFlaggedAt: null }
  if (latitude != null && longitude != null && !Number.isNaN(latitude) && !Number.isNaN(longitude)) {
    updateData.currentLatitude = latitude
    updateData.currentLongitude = longitude
    updateData.locationUpdatedAt = new Date()
  }
  await prisma.deal.update({ where: { id: dealId }, data: updateData })

  // اطلاع به شرکت حمل‌ونقل که راننده قبول کرده (در صف ۶۰دقیقه‌ای)
  const company = deal.transportCompanyId
    ? await prisma.transportCompany.findUnique({ where: { id: deal.transportCompanyId }, select: { contactPhone: true } })
    : null
  if (company?.contactPhone) {
    await queueSms({ dealId, phone: company.contactPhone, message: `راننده سفر محموله‌ی ${dealId.slice(0, 8)} را پذیرفت — انبارپلیمر` })
  }

  redirect(`/driver/t/${token}?accepted=1`)
}

export async function rejectDriverTripAction(formData: FormData) {
  const token = String(formData.get('token') || '')
  const reason = String(formData.get('reason') || '').trim() || null

  const { valid, link } = await validateDriverToken(token)
  if (!valid || !link) throw new Error('لینک نامعتبر یا منقضی‌شده.')

  const dealId = link.dealId

  await prisma.dealConfirmation.create({
    data: {
      dealId,
      type: 'driver_rejected',
      driverPhone: link.phone,
      checklistJson: JSON.stringify(reason ? { reason } : {}),
      confirmedAt: new Date(),
    },
  })

  // رد کردن لینک را مصرف نمی‌کند — راننده یا ادمین می‌تواند دوباره تلاش کند
  // driverSilenceFlaggedAt دست‌نخورده می‌ماند تا ادمین پیگیری کند

  // نقطه‌ی ۳ پلن: راننده رد کرد → اطلاع به شرکت حمل‌ونقل
  const deal = await prisma.deal.findUnique({
    where: { id: dealId },
    select: { transportCompanyId: true },
  })
  const company = deal?.transportCompanyId
    ? await prisma.transportCompany.findUnique({ where: { id: deal.transportCompanyId }, select: { contactPhone: true } })
    : null
  if (company?.contactPhone) {
    await queueSms({
      dealId,
      phone: company.contactPhone,
      message: reason
        ? `راننده سفر محموله‌ی ${dealId.slice(0, 8)} را رد کرد — دلیل: ${reason} — انبارپلیمر`
        : `راننده سفر محموله‌ی ${dealId.slice(0, 8)} را رد کرد — انبارپلیمر`,
    })
  }

  redirect(`/driver/t/${token}?rejected=1`)
}
