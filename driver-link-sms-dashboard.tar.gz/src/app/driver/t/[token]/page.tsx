import { validateDriverToken } from '@/lib/driverAccess'
import prisma from '@/lib/prisma'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import TripRouteMap from '@/components/TripRouteMap'
import AcceptRejectButtons from './AcceptRejectButtons'

export const dynamic = 'force-dynamic'

export default async function DriverTripPage({
  params,
  searchParams,
}: {
  params: Promise<{ token: string }>
  searchParams: Promise<Record<string, string | string[] | undefined>>
}) {
  const { token } = await params
  const sp = await searchParams
  const accepted = typeof sp.accepted === 'string'
  const rejected = typeof sp.rejected === 'string'

  const { valid, reason, link } = await validateDriverToken(token)
  if (!valid || !link) {
    return (
      <div style={pageStyle}>
        <div style={cardStyle}>
          <h1 style={{ fontSize: fontSize.lg, fontWeight: 800, color: colors.dangerText, marginBottom: spacing.sm }}>دسترسی ممکن نیست</h1>
          <p style={{ fontSize: fontSize.md, color: colors.neutralText }}>{reason}</p>
        </div>
      </div>
    )
  }

  const deal = await prisma.deal.findUnique({
    where: { id: link.dealId },
    include: {
      materialListing: { include: { grade: { select: { code: true, producer: true } } } },
      purchaseRequest: { select: { province: true } },
      driver: { select: { fullName: true, phone: true } },
      confirmations: { orderBy: { confirmedAt: 'desc' } },
    },
  })
  if (!deal) {
    return (
      <div style={pageStyle}>
        <div style={cardStyle}><p style={{ color: colors.dangerText }}>معامله پیدا نشد.</p></div>
      </div>
    )
  }

  const origin = deal.materialListing ? `${deal.materialListing.province} — ${deal.materialListing.city}` : '—'
  const destination = deal.purchaseRequest?.province ?? 'نامشخص'
  // receiverPhone: فعلاً روی PurchaseRequest نداریم — اگر اضافه شد اینجا نمایش داده می‌شود
  const receiverPhone: string | null = null

  const hasAccepted = deal.confirmations.some((c) => c.type === 'driver_accepted')
  const hasRejected = deal.confirmations.some((c) => c.type === 'driver_rejected')
  const pings = deal.confirmations
    .filter((c) => c.latitude != null && c.longitude != null)
    .map((c) => ({ latitude: c.latitude!, longitude: c.longitude!, capturedAt: c.confirmedAt }))

  // اگر Deal.current* هم نقطه دارد و در لیست نیست، اضافه کن (cache آخرین موقعیت)
  if (deal.currentLatitude != null && deal.currentLongitude != null) {
    const exists = pings.some((p) => p.latitude === deal.currentLatitude && p.longitude === deal.currentLongitude)
    if (!exists) pings.push({ latitude: deal.currentLatitude, longitude: deal.currentLongitude })
  }

  const canAct = !hasAccepted && !hasRejected && !accepted && !rejected

  return (
    <div style={pageStyle}>
      <div style={{ maxWidth: 520, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 14 }}>

        {accepted && (
          <div style={bannerStyle(colors.successBg, colors.successText)}>سفر با موفقیت پذیرفته شد — موقعیت شما ثبت شد.</div>
        )}
        {rejected && (
          <div style={bannerStyle(colors.warningBg, colors.warningText)}>درخواست شما ثبت شد — ادمین بررسی می‌کند.</div>
        )}

        {/* ۱. محصول + مقدار */}
        <div style={cardStyle}>
          <div style={{ fontSize: 11, color: colors.textMuted, fontWeight: 700 }}>محصول</div>
          <div style={{ fontSize: fontSize.lg, fontWeight: 800, color: colors.textPrimary }}>
            {deal.materialListing?.grade?.code ?? '—'} {deal.materialListing?.grade?.producer ? `— ${deal.materialListing.grade.producer}` : ''}
          </div>
          <div style={{ fontSize: fontSize.base, color: colors.neutralText, marginTop: 4 }}>مقدار: {deal.quantity}</div>
          <div style={{ fontSize: 11, color: colors.textMuted, marginTop: 6, fontFamily: 'monospace' }}>#{deal.id.slice(0, 8)}</div>
        </div>

        {/* ۲. مبدا */}
        <div style={cardStyle}>
          <div style={sectionLabelStyle}>مبدا بارگیری</div>
          <div style={{ fontSize: fontSize.md }}>{origin}</div>
        </div>

        {/* ۳. مقصد */}
        <div style={cardStyle}>
          <div style={sectionLabelStyle}>مقصد تخلیه</div>
          <div style={{ fontSize: fontSize.md }}>{destination}</div>
          {destination === 'نامشخص' && <div style={{ fontSize: 11.5, color: colors.textMuted, marginTop: 4 }}>استان مقصد در درخواست خرید ثبت نشده.</div>}
        </div>

        {/* ۴. تلفن تحویل‌گیرنده */}
        {receiverPhone && (
          <div style={cardStyle}>
            <div style={sectionLabelStyle}>تلفن تحویل‌گیرنده</div>
            <a href={`tel:${receiverPhone}`} style={{ fontSize: fontSize.md, color: colors.navy, direction: 'ltr' }}>{receiverPhone}</a>
          </div>
        )}

        {/* ۵. اطلاعات راننده/خودرو */}
        <div style={cardStyle}>
          <div style={sectionLabelStyle}>راننده / خودرو</div>
          <div style={{ fontSize: fontSize.md }}>
            {deal.driver ? `${deal.driver.fullName} — ${deal.driver.phone}` : `شماره‌ی لینک: ${link.phone}`}
          </div>
          {hasAccepted && <div style={{ fontSize: 11.5, color: colors.successText, marginTop: 4 }}>سفر پذیرفته شده</div>}
          {hasRejected && <div style={{ fontSize: 11.5, color: colors.warningText, marginTop: 4 }}>درخواست رد شده — در انتظار بررسی ادمین</div>}
        </div>

        {/* ۶. نقشه مسیر */}
        <TripRouteMap pings={pings} dealId={deal.id} />

        {/* ۷. دکمه‌های قبول/رد */}
        {canAct && <AcceptRejectButtons token={token} />}

        {/* ۸. مدرک حمل — لینک به فرم موجود */}
        <div style={cardStyle}>
          <div style={sectionLabelStyle}>مدرک حمل</div>
          <div style={{ fontSize: 11.5, color: colors.textMuted, marginBottom: 8 }}>
            برای ثبت بارگیری/تخلیه و آپلود عکس، از فرم اختصاصی استفاده کنید:
          </div>
          <a href={`/driver/${token}`} style={linkBtnStyle}>رفتن به فرم بارگیری/تخلیه</a>
        </div>

        {/* ۹. تایم‌استمپ‌ها */}
        <div style={cardStyle}>
          <div style={sectionLabelStyle}>تایم‌لاین</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {deal.confirmations.length === 0 ? (
              <span style={{ fontSize: 12, color: colors.textMuted }}>هنوز رویدادی ثبت نشده.</span>
            ) : (
              deal.confirmations.slice(0, 10).map((c) => (
                <div key={c.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12 }}>
                  <span style={{ color: colors.textPrimary }}>{labelForType(c.type)}</span>
                  <span style={{ color: colors.textMuted, direction: 'ltr' }}>
                    {new Date(c.confirmedAt).toLocaleString('fa-IR')}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

function labelForType(t: string) {
  const m: Record<string, string> = {
    driver_accepted: 'پذیرش سفر',
    driver_rejected: 'رد سفر',
    loading: 'بارگیری',
    unloading: 'تخلیه',
    driver_confirm: 'تایید راننده',
    buyer_confirm: 'تایید خریدار',
  }
  return m[t] ?? t
}

const pageStyle: React.CSSProperties = {
  minHeight: '100vh', background: colors.bgPage, padding: `${spacing.xl}px ${spacing.lg}px`,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl',
}
const cardStyle: React.CSSProperties = {
  background: colors.bgCard, border: `1px solid ${colors.borderSubtle}`, borderRadius: 12, padding: 14,
}
const sectionLabelStyle: React.CSSProperties = { fontSize: 11, fontWeight: 700, color: colors.textMuted, marginBottom: 6 }
function bannerStyle(bg: string, col: string): React.CSSProperties {
  return { background: bg, color: col, borderRadius: radius.md, padding: '10px 14px', fontSize: fontSize.base, fontWeight: 700, textAlign: 'center' }
}
const linkBtnStyle: React.CSSProperties = {
  display: 'inline-block', background: colors.navy, color: '#fff', borderRadius: radius.md, padding: '8px 14px', fontSize: 12.5, fontWeight: 700, textDecoration: 'none',
}
