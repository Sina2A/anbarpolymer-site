import prisma from './prisma'

export async function submitReview(params: {
  dealId: string
  raterUserId: string
  ratedUserId: string
  rating: number
  comment?: string
}) {
  const deal = await prisma.deal.findUnique({ where: { id: params.dealId } })
  if (!deal) throw new Error('معامله پیدا نشد.')
  if (deal.status !== 'settled') {
    throw new Error('فقط بعد از تسویه‌ی کامل معامله می‌شه امتیاز داد.')
  }
  if (params.rating < 1 || params.rating > 5) {
    throw new Error('امتیاز باید بین ۱ تا ۵ باشه.')
  }

  // @@unique([dealId, raterUserId]) روی schema جلوی امتیاز دوباره رو می‌گیره —
  // اگه دوباره امتحان کنه، همین‌جا خطای Prisma می‌گیریم.
  return prisma.review.create({
    data: {
      dealId: params.dealId,
      raterUserId: params.raterUserId,
      ratedUserId: params.ratedUserId,
      rating: params.rating,
      comment: params.comment || null,
    },
  })
}

export async function getAverageRating(userId: string) {
  const result = await prisma.review.aggregate({
    where: { ratedUserId: userId },
    _avg: { rating: true },
    _count: true,
  })
  return {
    average: result._avg.rating ?? null,
    count: result._count,
  }
}
