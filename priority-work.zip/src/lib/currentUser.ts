import prisma from './prisma'
import { getSessionUser } from './auth'
import { redirect } from 'next/navigation'

/**
 * قبلاً این تابع یه پل موقت بود (انتخاب کاربر از dropdown چون سیستم ورود
 * نداشتیم). حالا واقعاً از روی کوکی نشست، کاربر لاگین‌شده رو برمی‌گردونه.
 * اگه لاگین نباشه، مستقیم به /login هدایت می‌کنه.
 */
export async function getCurrentUser() {
  const user = await getSessionUser()
  if (!user) {
    redirect('/login')
  }
  return user
}

/** نسخه‌ای که ریدایرکت نمی‌کنه — برای جاهایی که فقط می‌خوایم چک کنیم لاگینه یا نه */
export async function getCurrentUserOrNull() {
  return getSessionUser()
}

export async function getAllStaffForPicker() {
  return prisma.user.findMany({
    where: { role: { in: ['staff', 'admin'] }, isActive: true },
    orderBy: { createdAt: 'asc' },
  })
}
