import prisma from './prisma'
import { SECTION_KEYS, SectionKey, AccessLevel } from './sections'

// این فایل، برخلاف sections.ts، prisma رو import می‌کنه — یعنی سرور-فقطه.
// هر Client Component که فقط به SECTION_KEYS/AccessLevel نیاز داره، باید مستقیم
// از './sections' بخونه، نه از اینجا — وگرنه دوباره خطای «pg رو نمی‌شه برای مرورگر
// bundle کرد» برمی‌گرده.
export { SECTION_KEYS }
export type { SectionKey, AccessLevel }

/**
 * سطح دسترسی یک کاربر به یک بخش رو برمی‌گردونه.
 * نقش «مدیر» هم از همین جدول می‌خونه — هیچ نقشی خودکار full access نمی‌گیره،
 * طبق تصمیمی که گرفته شد (همه‌چیز دستی و صریح).
 */
export async function getSectionAccess(userId: string, section: SectionKey): Promise<AccessLevel> {
  const perm = await prisma.permission.findUnique({
    where: { userId_section: { userId, section } },
  })
  if (!perm || (!perm.canView && !perm.canEdit)) return 'none'
  if (perm.canView && perm.canEdit) return 'full'
  return perm.canView ? 'view' : 'edit'
}

export async function getAllSectionAccess(userId: string): Promise<Record<SectionKey, AccessLevel>> {
  const perms = await prisma.permission.findMany({ where: { userId } })
  const map = {} as Record<SectionKey, AccessLevel>
  for (const sec of SECTION_KEYS) {
    const perm = perms.find((p) => p.section === sec.key)
    if (!perm || (!perm.canView && !perm.canEdit)) map[sec.key] = 'none'
    else if (perm.canView && perm.canEdit) map[sec.key] = 'full'
    else map[sec.key] = perm.canView ? 'view' : 'edit'
  }
  return map
}

// ==================== قانون تک‌مدیر ====================

/**
 * فقط یک نفر می‌تونه هم‌زمان نقش «مدیر» داشته باشه.
 * قبل از هر create/update که می‌خواد role رو admin کنه، این رو صدا بزن.
 * اگه از قبل یه مدیرِ دیگه (با id متفاوت) وجود داشته باشه، پیام خطا برمی‌گردونه.
 */
export async function assertSingleAdmin(candidateUserId: string | null): Promise<string | null> {
  const existingAdmin = await prisma.user.findFirst({ where: { role: 'admin', isActive: true } })
  if (existingAdmin && existingAdmin.id !== candidateUserId) {
    return `همین الان «${existingAdmin.companyName}» نقش مدیر رو داره. طبق قانون سیستم، فقط یک نفر می‌تونه هم‌زمان مدیر باشه — اول باید نقش اون رو عوض کنی.`
  }
  return null
}

// بخش‌هایی که تغییرشون حساسه و باید قبل از اعمال، تاییدیه‌ی صریح بگیره
export const SENSITIVE_ACTIONS = new Set(['change-role', 'edit-user-info', 'deactivate-user', 'grant-admin-permission'])
