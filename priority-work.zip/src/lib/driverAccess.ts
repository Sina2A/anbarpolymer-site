import crypto from 'crypto'
import prisma from './prisma'

const LINK_VALID_HOURS = 48

/**
 * برای هر Deal که وارد مرحله‌ی بارگیری یا تخلیه می‌شه، این تابع صدا زده می‌شه.
 * یه توکن یک‌بارمصرف می‌سازه که فقط با همون لینک (نه با ساخت حساب) قابل‌دسترسیه.
 * ارسال واقعی پیامک هنوز جدا و نیاز به یه سرویس SMS داره — این فقط لینک رو می‌سازه.
 */
export async function createDriverAccessLink(dealId: string, phone: string) {
  const token = crypto.randomBytes(24).toString('hex')
  const expiresAt = new Date(Date.now() + LINK_VALID_HOURS * 60 * 60 * 1000)

  await prisma.driverAccessLink.create({
    data: { dealId, phone, token, expiresAt },
  })

  return token
}

export async function validateDriverToken(token: string) {
  const link = await prisma.driverAccessLink.findUnique({
    where: { token },
    include: { deal: { include: { confirmations: true } } },
  })

  if (!link) return { valid: false, reason: 'لینک نامعتبره.' as const, link: null }
  if (link.usedAt) return { valid: false, reason: 'این لینک قبلاً استفاده شده.' as const, link: null }
  if (link.expiresAt < new Date()) return { valid: false, reason: 'این لینک منقضی شده.' as const, link: null }

  return { valid: true, reason: null, link }
}

export async function markDriverLinkUsed(token: string) {
  await prisma.driverAccessLink.update({
    where: { token },
    data: { usedAt: new Date() },
  })
}
