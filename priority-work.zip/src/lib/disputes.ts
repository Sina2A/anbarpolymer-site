import prisma from './prisma'

/**
 * وقتی تاییدیه‌ی نهایی خریدار «مغایرت دارد» یا «رد» باشه، این تابع خودکار
 * یه Dispute باز می‌کنه — قبلاً فقط یه چک‌باکس بود که «بعدش چی می‌شه»
 * نداشت؛ الان یه رکورد واقعی می‌سازه که ادمین می‌تونه پیگیریش کنه.
 */
export async function raiseDisputeIfNeeded(params: {
  dealId: string
  raisedById: string
  finalVerdict: string | null
}) {
  if (params.finalVerdict !== 'accept_with_discrepancy' && params.finalVerdict !== 'reject') {
    return null
  }

  const reason =
    params.finalVerdict === 'reject'
      ? 'خریدار تحویل بار را رد کرد'
      : 'خریدار بار را با مغایرت تایید کرد'

  return prisma.dispute.create({
    data: {
      dealId: params.dealId,
      raisedById: params.raisedById,
      reason,
      status: 'open',
    },
  })
}

export async function resolveDispute(params: {
  disputeId: string
  resolvedById: string
  resolution: string
  status: 'resolved' | 'rejected'
}) {
  return prisma.dispute.update({
    where: { id: params.disputeId },
    data: {
      status: params.status,
      resolution: params.resolution,
      resolvedById: params.resolvedById,
      resolvedAt: new Date(),
    },
  })
}
