const PRICE_VALIDITY_HOURS = 24

/**
 * قفل قیمت لحظه‌ی ثبت RFQ — طبق تصمیمی که گرفتیم: قیمت مرجع فعلی رو
 * snapshot می‌گیریم، نه لینک زنده به قیمت روز. با مهلت اعتبار ۲۴ساعته.
 * بعد از این مهلت، کارشناس فروش باید قیمت رو دوباره تایید کنه.
 */
export function computePriceSnapshot(currentReferencePrice: number) {
  const now = new Date()
  const validUntil = new Date(now.getTime() + PRICE_VALIDITY_HOURS * 60 * 60 * 1000)
  return {
    price: currentReferencePrice,
    priceSnapshotAt: now,
    priceValidUntil: validUntil,
  }
}

export function isPriceStillValid(priceValidUntil: Date) {
  return new Date(priceValidUntil) > new Date()
}
