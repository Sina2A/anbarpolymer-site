import crypto from 'crypto'
import { cookies } from 'next/headers'
import prisma from './prisma'

const SESSION_COOKIE = 'anbar_session'
const SESSION_DAYS = 7

/**
 * هش کردن رمز عبور با scrypt — بخشی از خودِ Node.js است، نیازی به هیچ
 * پکیج بیرونی (مثل bcrypt که کامپایل native می‌خواد) نیست. با توجه به
 * تاریخچه‌ی این سرور با خطاهای build، این انتخاب عمدیه.
 */
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex')
  const derivedKey = crypto.scryptSync(password, salt, 64)
  return `${salt}:${derivedKey.toString('hex')}`
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const [salt, key] = storedHash.split(':')
  if (!salt || !key) return false
  const derivedKey = crypto.scryptSync(password, salt, 64)
  const keyBuffer = Buffer.from(key, 'hex')
  if (keyBuffer.length !== derivedKey.length) return false
  return crypto.timingSafeEqual(keyBuffer, derivedKey)
}

/**
 * بعد از ورود موفق، یه نشست جدید توی دیتابیس می‌سازه و توکنش رو توی یه
 * کوکی httpOnly می‌ذاره — یعنی جاوااسکریپت سمت مرورگر اصلاً نمی‌تونه
 * بهش دسترسی داشته باشه (محافظت در برابر XSS).
 */
export async function createSession(userId: string) {
  const token = crypto.randomBytes(32).toString('hex')
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000)

  await prisma.session.create({ data: { userId, token, expiresAt } })

  const cookieStore = await cookies()
  cookieStore.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    expires: expiresAt,
    path: '/',
  })

  await prisma.user.update({ where: { id: userId }, data: { lastLoginAt: new Date() } })
}

/** کاربر واقعیِ لاگین‌شده رو از روی کوکی نشست برمی‌گردونه — یا null اگه لاگین نیست. */
export async function getSessionUser() {
  const cookieStore = await cookies()
  const token = cookieStore.get(SESSION_COOKIE)?.value
  if (!token) return null

  const session = await prisma.session.findUnique({ where: { token }, include: { user: true } })
  if (!session) return null
  if (session.expiresAt < new Date()) {
    await prisma.session.delete({ where: { token } }).catch(() => {})
    return null
  }
  if (!session.user.isActive) return null

  return session.user
}

export async function destroySession() {
  const cookieStore = await cookies()
  const token = cookieStore.get(SESSION_COOKIE)?.value
  if (token) {
    await prisma.session.delete({ where: { token } }).catch(() => {})
  }
  cookieStore.delete(SESSION_COOKIE)
}
