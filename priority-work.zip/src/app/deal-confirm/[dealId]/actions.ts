'use server'

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { raiseDisputeIfNeeded } from '@/lib/disputes'
import { redirect } from 'next/navigation'

export async function submitBuyerConfirmation(formData: FormData) {
  const user = await getCurrentUser()
  const dealId = String(formData.get('dealId'))
  const verdict = String(formData.get('verdict')) // full_accept | accept_with_discrepancy | reject
  const note = String(formData.get('note') || '').trim()

  const deal = await prisma.deal.findUnique({ where: { id: dealId } })
  if (!deal) throw new Error('معامله پیدا نشد.')
  if (deal.buyerId !== user.id) throw new Error('این معامله مال شما نیست.')

  await prisma.dealConfirmation.create({
    data: {
      dealId,
      type: 'buyer_confirm',
      finalVerdict: verdict,
      checklistJson: '{}',
    },
  })

  // اگه مغایرت یا رد بود، خودکار یه Dispute باز می‌شه — دیگه فقط یه
  // چک‌باکس بی‌عاقبت نیست.
  await raiseDisputeIfNeeded({ dealId, raisedById: user.id, finalVerdict: verdict })

  if (verdict === 'full_accept') {
    await prisma.deal.update({ where: { id: dealId }, data: { status: 'delivered' } })
  }

  redirect('/my-orders')
}
