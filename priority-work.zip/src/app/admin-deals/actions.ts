'use server'

import prisma from '@/lib/prisma'
import { revalidatePath } from 'next/cache'

/**
 * این دو تابع هیچ تراکنش بانکی واقعی انجام نمی‌دن — فقط وضعیتی رو ثبت می‌کنن
 * که تیم حسابداری، بیرون از سایت، بین خودش و بانک انجام داده. طبق تصمیمی که
 * گرفته شد: «سایت قرار نیست به سیستم بانکی وصل بشه، این برای بخش حسابداریه.»
 */
export async function confirmFundsSecured(formData: FormData) {
  const dealId = String(formData.get('dealId'))
  const confirmedById = String(formData.get('confirmedById') || '')

  await prisma.deal.update({
    where: { id: dealId },
    data: {
      escrowStatus: 'secured_manual',
      escrowConfirmedById: confirmedById || null,
      escrowConfirmedAt: new Date(),
      status: 'payment_secured',
    },
  })
  revalidatePath('/admin-deals')
}

export async function confirmFundsReleased(formData: FormData) {
  const dealId = String(formData.get('dealId'))
  const confirmedById = String(formData.get('confirmedById') || '')

  await prisma.deal.update({
    where: { id: dealId },
    data: {
      escrowStatus: 'released_manual',
      escrowConfirmedById: confirmedById || null,
      escrowConfirmedAt: new Date(),
      status: 'settled',
    },
  })
  revalidatePath('/admin-deals')
}
