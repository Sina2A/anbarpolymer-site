'use server'

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { revalidatePath } from 'next/cache'

async function getMyTransportCompany() {
  const user = await getCurrentUser()
  const company = await prisma.transportCompany.findUnique({ where: { managerUserId: user.id } })
  if (!company) throw new Error('این حساب به هیچ شرکت حمل‌ونقلی وصل نیست.')
  return company
}

export async function addDriver(formData: FormData) {
  const company = await getMyTransportCompany()

  const fullName = String(formData.get('fullName') || '').trim()
  const phone = String(formData.get('phone') || '').trim()
  const nationalId = String(formData.get('nationalId') || '').trim()
  const licenseNumber = String(formData.get('licenseNumber') || '').trim()

  if (!fullName || !phone) return

  await prisma.driver.create({
    data: {
      transportCompanyId: company.id,
      fullName,
      phone,
      nationalId: nationalId || null,
      licenseNumber: licenseNumber || null,
    },
  })
  revalidatePath('/transport-panel')
}

export async function toggleDriverActive(formData: FormData) {
  const company = await getMyTransportCompany()
  const driverId = String(formData.get('driverId'))
  const value = formData.get('value') === 'true'

  // مطمئن شو این راننده واقعاً مال همین شرکته، نه یه شرکت دیگه
  const driver = await prisma.driver.findFirst({ where: { id: driverId, transportCompanyId: company.id } })
  if (!driver) return

  await prisma.driver.update({ where: { id: driverId }, data: { isActive: value } })
  revalidatePath('/transport-panel')
}
