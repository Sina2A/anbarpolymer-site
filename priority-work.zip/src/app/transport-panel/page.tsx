import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { addDriver, toggleDriverActive } from './actions'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'

export const dynamic = 'force-dynamic'

export default async function TransportPanelPage() {
  const user = await getCurrentUser()

  const company = await prisma.transportCompany.findUnique({
    where: { managerUserId: user.id },
    include: {
      drivers: {
        orderBy: { createdAt: 'asc' },
        include: {
          confirmations: {
            orderBy: { confirmedAt: 'desc' },
            take: 10,
            include: { deal: true },
          },
        },
      },
    },
  })

  if (!company) {
    return (
      <div style={pageStyle}>
        <div style={cardStyle}>
          <h1 style={{ fontSize: 18, fontWeight: 800, marginBottom: 8 }}>دسترسی ندارید</h1>
          <p style={{ fontSize: 13.5, color: '#4f5560' }}>این حساب به هیچ شرکت حمل‌ونقلی وصل نیست. با پشتیبانی انبار پلیمر تماس بگیرید.</p>
        </div>
      </div>
    )
  }

  return (
    <div style={pageStyle}>
      <div style={{ maxWidth: 780, margin: '0 auto' }}>
        <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>پنل {company.name}</h1>
        <p style={{ fontSize: 13, color: '#9199a3', marginBottom: 24 }}>مدیریت راننده‌ها و تاریخچه‌ی سفرهای تایید‌شده</p>

        <div style={purposeBoxStyle}>
          <b>هدف این پنل چیه؟</b>
          <p style={{ margin: '6px 0 0', lineHeight: 1.9 }}>
            این بخش فقط برای <b>احراز هویت راننده و مسیر طی‌شده</b>‌ست — به‌خاطر حساسیت صنعت مواد اولیه پتروشیمی در ایران.
            انبار پلیمر با رقم دقیق مسافتِ طی‌شده‌ی هیچ راننده‌ای کاری نداره و این داده رو برای ارزیابی عملکرد یا هزینه استفاده نمی‌کنه —
            فقط جهت تایید این‌که سفر واقعاً و توسط همون راننده‌ی ثبت‌شده انجام شده.
          </p>
        </div>

        <div style={cardStyle}>
          <h3 style={{ fontSize: 14.5, fontWeight: 800, marginBottom: 14 }}>افزودن راننده‌ی جدید</h3>
          <form action={addDriver} style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 12 }}>
            <input name="fullName" placeholder="نام و نام خانوادگی" required style={inputStyle} />
            <input name="phone" placeholder="شماره موبایل" required style={{ ...inputStyle, direction: 'ltr' }} />
            <input name="nationalId" placeholder="کد ملی (اختیاری)" style={{ ...inputStyle, direction: 'ltr' }} />
            <input name="licenseNumber" placeholder="شماره گواهینامه (اختیاری)" style={{ ...inputStyle, direction: 'ltr' }} />
            <button type="submit" style={btnStyle}>افزودن راننده</button>
          </form>
        </div>

        <h3 style={{ fontSize: 15, fontWeight: 800, margin: '28px 0 14px' }}>راننده‌ها ({company.drivers.length})</h3>

        {company.drivers.length === 0 && (
          <div style={{ padding: 28, textAlign: 'center', color: '#9199a3', border: '1px dashed #d8dde3', borderRadius: 12 }}>هنوز راننده‌ای ثبت نشده.</div>
        )}

        {company.drivers.map((driver) => (
          <div key={driver.id} style={cardStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
              <div>
                <b style={{ fontSize: 14 }}>{driver.fullName}</b>{' '}
                <span style={{ fontSize: 12, color: '#9199a3', direction: 'ltr', display: 'inline-block' }}>— {driver.phone}</span>
              </div>
              <form action={toggleDriverActive}>
                <input type="hidden" name="driverId" value={driver.id} />
                <input type="hidden" name="value" value={(!driver.isActive).toString()} />
                <ConfirmSubmitButton
                  message={driver.isActive ? `«${driver.fullName}» غیرفعال بشه؟` : `«${driver.fullName}» دوباره فعال بشه؟`}
                  style={{ ...statusBtn, ...(driver.isActive ? activeStatus : inactiveStatus) }}
                >
                  {driver.isActive ? 'فعال' : 'غیرفعال'}
                </ConfirmSubmitButton>
              </form>
            </div>

            {driver.confirmations.length > 0 && (
              <div style={{ borderTop: '1px dashed #eceff3', paddingTop: 10, marginTop: 4 }}>
                <div style={{ fontSize: 11, color: '#9199a3', marginBottom: 6 }}>آخرین سفرهای تایید‌شده:</div>
                {driver.confirmations.map((c) => (
                  <div key={c.id} style={tripRowStyle}>
                    <span>{c.type === 'loading' ? 'بارگیری' : 'تخلیه'} — معامله #{c.dealId.slice(0, 8)}</span>
                    <span style={{ color: '#9199a3' }}>{new Date(c.confirmedAt).toLocaleDateString('fa-IR')}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}

        <div style={{ ...cardStyle, background: '#eef4fd', borderColor: '#1e357b' }}>
          <h3 style={{ fontSize: 14, fontWeight: 800, color: '#1e357b', marginBottom: 8 }}>پشتیبانی فنی</h3>
          <p style={{ fontSize: 12.5, color: '#4f5560', margin: 0 }}>برای هر مشکل فنی در این پنل، با تیم انبار پلیمر تماس بگیرید: <span style={{ direction: 'ltr', display: 'inline-block', fontWeight: 700 }}>۰۲۱-۹۱۲۳۴۵۶۷</span></p>
        </div>
      </div>
    </div>
  )
}

const pageStyle: React.CSSProperties = { minHeight: '100vh', background: '#faf8f4', padding: '32px 20px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl' }
const cardStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 12, padding: 18, marginBottom: 14, background: '#fff', boxShadow: '0 1px 4px rgba(27,30,36,.05)' }
const purposeBoxStyle: React.CSSProperties = { background: '#fef3c7', color: '#92400e', borderRadius: 10, padding: '14px 16px', fontSize: 12.5, marginBottom: 20 }
const inputStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 8, padding: '9px 12px', fontSize: 13, fontFamily: 'inherit' }
const btnStyle: React.CSSProperties = { background: '#1e357b', color: '#fff', border: 'none', borderRadius: 8, padding: '9px 16px', fontSize: 13, fontWeight: 700, cursor: 'pointer', gridColumn: 'span 1' }
const statusBtn: React.CSSProperties = { fontSize: 10.5, fontWeight: 700, borderRadius: 5, padding: '4px 12px', border: 'none', cursor: 'pointer' }
const activeStatus: React.CSSProperties = { background: '#dcfce7', color: '#146c3a' }
const inactiveStatus: React.CSSProperties = { background: '#fee2e2', color: '#a8241a' }
const tripRowStyle: React.CSSProperties = { display: 'flex', justifyContent: 'space-between', fontSize: 12, padding: '5px 0', color: '#4f5560' }
