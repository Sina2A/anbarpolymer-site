'use server'

import { getCurrentUser } from '@/lib/currentUser'
import { resolveDispute } from '@/lib/disputes'
import { revalidatePath } from 'next/cache'

export async function resolveDisputeAction(formData: FormData) {
  const user = await getCurrentUser()
  const disputeId = String(formData.get('disputeId'))
  const resolution = String(formData.get('resolution') || '').trim()
  const status = String(formData.get('status')) as 'resolved' | 'rejected'

  if (!resolution) {
    throw new Error('توضیح نتیجه‌ی رسیدگی الزامیه.')
  }

  await resolveDispute({ disputeId, resolvedById: user.id, resolution, status })
  revalidatePath('/admin-disputes')
}
