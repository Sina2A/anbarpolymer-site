import { validateDriverToken } from '@/lib/driverAccess'
import DriverForm from './DriverForm'

export const dynamic = 'force-dynamic'

export default async function DriverAccessPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params
  const { valid, reason, link } = await validateDriverToken(token)

  if (!valid || !link) {
    return (
      <div style={pageStyle}>
        <div style={cardStyle}>
          <h1 style={{ fontSize: 18, fontWeight: 800, color: '#a8241a', marginBottom: 8 }}>دسترسی ممکن نیست</h1>
          <p style={{ fontSize: 14, color: '#4f5560' }}>{reason}</p>
        </div>
      </div>
    )
  }

  const deal = link.deal
  let formType: 'loading' | 'unloading' | null = null
  if (deal.status === 'confirmed' || deal.status === 'payment_secured') formType = 'loading'
  else if (deal.status === 'in_transit') formType = 'unloading'

  if (!formType) {
    return (
      <div style={pageStyle}>
        <div style={cardStyle}>
          <h1 style={{ fontSize: 18, fontWeight: 800, marginBottom: 8 }}>الان کاری برای ثبت نیست</h1>
          <p style={{ fontSize: 14, color: '#4f5560' }}>وضعیت فعلی این معامله («{deal.status}») نیازی به فرم بارگیری یا تخلیه نداره.</p>
        </div>
      </div>
    )
  }

  return (
    <div style={pageStyle}>
      <div style={cardStyle}>
        <h1 style={{ fontSize: 19, fontWeight: 800, marginBottom: 4 }}>
          {formType === 'loading' ? 'تایید بارگیری' : 'تایید تخلیه'}
        </h1>
        <p style={{ fontSize: 13, color: '#9199a3', marginBottom: 20 }}>
          معامله #{deal.id.slice(0, 8)} — مقدار {deal.quantity}
        </p>
        <DriverForm token={token} type={formType} />
      </div>
    </div>
  )
}

const pageStyle: React.CSSProperties = {
  minHeight: '100vh', background: '#faf8f4', padding: '24px 16px',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl',
}
const cardStyle: React.CSSProperties = {
  maxWidth: 460, margin: '0 auto', background: '#fff', border: '1px solid #d8dde3',
  borderRadius: 14, padding: '24px 20px', boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
