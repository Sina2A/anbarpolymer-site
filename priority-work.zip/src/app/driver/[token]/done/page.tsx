export default function DriverDonePage() {
  return (
    <div style={{ minHeight: '100vh', background: '#faf8f4', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16, fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl' }}>
      <div style={{ maxWidth: 400, textAlign: 'center', background: '#fff', border: '1px solid #d8dde3', borderRadius: 14, padding: '32px 24px' }}>
        <div style={{ fontSize: 40, marginBottom: 12 }}>✓</div>
        <h1 style={{ fontSize: 18, fontWeight: 800, color: '#146c3a', marginBottom: 8 }}>ثبت شد، متشکریم</h1>
        <p style={{ fontSize: 13.5, color: '#4f5560' }}>فرم شما با موفقیت ثبت شد. می‌تونید این صفحه رو ببندید.</p>
      </div>
    </div>
  )
}
