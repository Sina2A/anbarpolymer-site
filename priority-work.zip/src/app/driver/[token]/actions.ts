'use server'

import prisma from '@/lib/prisma'
import { validateDriverToken, markDriverLinkUsed } from '@/lib/driverAccess'
import fs from 'fs/promises'
import path from 'path'
import crypto from 'crypto'
import { redirect } from 'next/navigation'

const UPLOAD_ROOT = path.join(process.cwd(), 'public', 'uploads', 'deals')

/**
 * ذخیره‌ی عکس روی دیسک محلی سرور (نه فضای ابری) — چون هنوز فاز Storage
 * واقعی نساختیم. برای همین حجم فعلی کاملاً کافیه؛ وقتی حجم بار زیاد شد،
 * این تابع باید با یه سرویس ابری جایگزین بشه (فقط همین یه تابع، بقیه‌ی
 * کد دست‌نخورده می‌مونه چون همه‌جا فقط از photoUrl استفاده می‌کنن).
 */
async function savePhotoToLocalDisk(dealId: string, file: File): Promise<string> {
  const dealDir = path.join(UPLOAD_ROOT, dealId)
  await fs.mkdir(dealDir, { recursive: true })

  const ext = (file.name.split('.').pop() || 'jpg').toLowerCase().replace(/[^a-z0-9]/g, '') || 'jpg'
  const fileName = `${Date.now()}-${crypto.randomBytes(4).toString('hex')}.${ext}`
  const filePath = path.join(dealDir, fileName)

  const buffer = Buffer.from(await file.arrayBuffer())
  await fs.writeFile(filePath, buffer)

  return `/uploads/deals/${dealId}/${fileName}`
}

export async function submitDealConfirmation(formData: FormData) {
  const token = String(formData.get('token') || '')
  const type = String(formData.get('type') || '') // loading | unloading

  const { valid, link } = await validateDriverToken(token)
  if (!valid || !link) {
    throw new Error('لینک نامعتبر یا منقضی‌شده — فرم ثبت نشد.')
  }

  const dealId = link.dealId

  const driverName = String(formData.get('driverName') || '').trim()
  const driverPhone = String(formData.get('driverPhone') || '').trim()
  const vehiclePlate = String(formData.get('vehiclePlate') || '').trim()
  const vehicleType = String(formData.get('vehicleType') || '')
  const receiverName = String(formData.get('receiverName') || '').trim()
  const receiverRole = String(formData.get('receiverRole') || '')

  const latitude = formData.get('latitude') ? parseFloat(String(formData.get('latitude'))) : null
  const longitude = formData.get('longitude') ? parseFloat(String(formData.get('longitude'))) : null
  const gpsAccuracy = formData.get('gpsAccuracy') ? parseFloat(String(formData.get('gpsAccuracy'))) : null

  // چک‌لیست: هر آیتمی که توی فرم تیک خورده، از formData میاد (checkbox های هم‌نام)
  const checklistItems = formData.getAll('checklist') as string[]
  const checklistJson = JSON.stringify(checklistItems.reduce((acc, key) => ({ ...acc, [key]: true }), {}))

  let photoUrl: string | null = null
  const photoFile = formData.get('photo') as File | null
  if (photoFile && photoFile.size > 0) {
    photoUrl = await savePhotoToLocalDisk(dealId, photoFile)
  }

  await prisma.dealConfirmation.create({
    data: {
      dealId,
      type,
      driverName: driverName || null,
      driverPhone: driverPhone || null,
      vehiclePlate: vehiclePlate || null,
      vehicleType: vehicleType || null,
      receiverName: receiverName || null,
      receiverRole: receiverRole || null,
      checklistJson,
      photoUrl,
      latitude,
      longitude,
      gpsAccuracy,
    },
  })

  // آپدیت وضعیت کلی معامله متناسب با نوع رویداد.
  // توجه: تایم‌لاین خودِ Deal همین رکوردهای DealConfirmation هستن (هرکدوم با
  // زمان دقیق) — نیازی به دوباره‌نویسی توی StatusEvent نیست، چون آن سیستم
  // برای Order/MaterialListing/SupportTicket طراحی شده، نه Deal.
  const nextDealStatus = type === 'loading' ? 'in_transit' : type === 'unloading' ? 'delivered' : undefined
  if (nextDealStatus) {
    await prisma.deal.update({ where: { id: dealId }, data: { status: nextDealStatus } })
  }

  await markDriverLinkUsed(token)

  redirect(`/driver/${token}/done`)
}
