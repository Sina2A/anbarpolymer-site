'use server'

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { logStatusEvent } from '@/lib/statusEvents'
import { revalidatePath } from 'next/cache'

/**
 * کارشناس فروش قیمت نهایی هر قلم رو ثبت می‌کنه — این قیمت جدا از price
 * (که فقط snapshot مرجعه) ذخیره می‌شه، تا سفارش وارد مرحله‌ی «priced» بشه
 * و مشتری بتونه توی /my-orders تاییدش کنه.
 */
export async function setOrderPricing(formData: FormData) {
  const user = await getCurrentUser()
  const orderId = String(formData.get('orderId'))

  const order = await prisma.order.findUnique({ where: { id: orderId }, include: { items: true } })
  if (!order) throw new Error('سفارش پیدا نشد.')

  await prisma.$transaction(
    order.items.map((item) =>
      prisma.orderItem.update({
        where: { id: item.id },
        data: { finalPrice: parseFloat(String(formData.get(`finalPrice-${item.id}`) || item.price)) },
      })
    )
  )

  await prisma.order.update({ where: { id: orderId }, data: { status: 'priced' } })

  await logStatusEvent({
    recordType: 'Order',
    recordId: orderId,
    newStageKey: 'priced',
    performedById: user.id,
    note: 'قیمت نهایی توسط کارشناس فروش ثبت شد',
  })

  revalidatePath('/admin-orders')
}

/**
 * رد سفارش — موجودی قفل‌شده باید برگرده به انبار، وگرنه برای همیشه
 * از دسترس خارج می‌مونه بدون این‌که واقعاً فروخته شده باشه.
 */
export async function rejectOrder(formData: FormData) {
  const user = await getCurrentUser()
  const orderId = String(formData.get('orderId'))

  const order = await prisma.order.findUnique({ where: { id: orderId }, include: { items: true } })
  if (!order) throw new Error('سفارش پیدا نشد.')
  if (order.status !== 'pending') throw new Error('فقط سفارش‌های در انتظار قیمت‌گذاری قابل‌رد کردنن.')

  const itemsWithWarehouse = order.items.filter((item) => item.warehouseId)

  await prisma.$transaction([
    ...itemsWithWarehouse.map((item) =>
      prisma.warehouseStock.update({
        where: { id: item.warehouseId as string },
        data: { quantityTon: { increment: item.quantity } },
      })
    ),
    prisma.order.update({ where: { id: orderId }, data: { status: 'rejected' } }),
  ])

  await logStatusEvent({
    recordType: 'Order',
    recordId: orderId,
    newStageKey: 'rejected',
    performedById: user.id,
    note: 'سفارش توسط کارشناس رد شد — موجودی به انبار برگشت',
  })

  revalidatePath('/admin-orders')
}
