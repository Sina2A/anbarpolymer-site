import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import RfqCart from './RfqCart'

export const dynamic = 'force-dynamic'

export default async function RfqPage() {
  await getCurrentUser() // فقط مطمئن می‌شه لاگینه؛ اگه نه، خودش به /login می‌فرسته

  const stock = await prisma.warehouseStock.findMany({
    where: { quantityTon: { gt: 0 } },
    include: { grade: true, warehouse: true },
    orderBy: { grade: { code: 'asc' } },
  })

  const items = stock.map((s) => ({
    warehouseId: s.id,
    gradeId: s.gradeId,
    gradeCode: s.grade.code,
    producer: s.grade.producer,
    warehouseName: s.warehouse.name,
    warehouseCity: s.warehouse.city,
    availableTon: s.quantityTon,
    priceRial: s.priceRial,
  }))

  return (
    <div style={pageStyle}>
      <div style={{ maxWidth: 820, margin: '0 auto' }}>
        <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>استعلام قیمت</h1>
        <p style={{ fontSize: 13, color: '#9199a3', marginBottom: 24 }}>
          محصولات رو به سبد اضافه کن و درخواست ثبت کن. قیمت لحظه‌ی ثبت قفل می‌شه و تا ۲۴ ساعت معتبره.
        </p>
        <RfqCart items={items} />
      </div>
    </div>
  )
}

const pageStyle: React.CSSProperties = { minHeight: '100vh', background: '#faf8f4', padding: '32px 20px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl' }
