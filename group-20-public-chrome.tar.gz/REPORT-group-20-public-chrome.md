# گروه ۲۰ — همسان‌سازی کروم صفحات عمومی (بخش الف تریاژ امنیتی)

تاریخ: ۱۴۰۵ / 2026-09-03
مرجع: `prompt-security-triage.md` → بخش الف (قطعی، رفع کن)

## مسئله

پنج صفحه‌ی عمومی با الگوی سالم `market/page.tsx` هم‌راستا نبودند. مهم‌ترین مورد: دکمه‌ی
هدر در همه‌شان **هاردکد** روی «ورود / ثبت‌نام» بود — یعنی کاربر لاگین‌شده هم دکمه‌ی ورود
می‌دید (هدر ثابت / static header). به‌علاوه لینک `/market` در ناوبری و ستون خدماتِ فوتر
جا افتاده بود و دو صفحه هنوز کروم inline قدیمی (هدر سفید با ۴ لینک) داشتند.

## فایل‌های این گروه

| # | فایل | نوع تغییر |
|---|---|---|
| ۱ | `src/app/grades/page.tsx` | تکمیل کروم + دکمه شرطی |
| ۲ | `src/app/contact/page.tsx` | جایگزینی کامل کروم قدیمی |
| ۳ | `src/app/warehouses/page.tsx` | جایگزینی کامل کروم قدیمی |
| ۴ | `src/app/grades/[code]/page.tsx` | دکمه شرطی + ناوبری + فوتر |
| ۵ | `src/app/page.tsx` | فقط افزودن CurrencyTicker |

## جزئیات هر فایل

### ۱ — `src/app/grades/page.tsx`
- import `getCurrentUserOrNull` و `CurrencyTicker`
- `const user = await getCurrentUserOrNull()` قبل از return
- `<CurrencyTicker />` اولین فرزند fragment
- ناوبری: افزودن `<a href="/market">بازار صنعتی</a>` (۷ → ۸ لینک)
- دکمه‌ی هدر شرطی: `user ? پیشخوان(/dashboard) : ورود / ثبت‌نام(/login)`
- فوتر ستون خدمات: «ارسال و لجستیک → /services» ← «بازار صنعتی → /market»
- دست‌نخورده: `URL_FIELDS`، whereBuilder، `grade.findMany`، فیلترهای distinct،
  فرم GET (q/category/family)، گرید کارت‌ها، همه‌ی style object‌ها

### ۲ — `src/app/contact/page.tsx`
- import `getCurrentUserOrNull`؛ `const user = await getCurrentUserOrNull()`
- حذف `<div style={pageStyle}>` و کروم inline → fragment با `.topbar` / `.site-header`
- ناوبری: ۴ لینک قدیمی → ۸ لینک استاندارد (با `className="active"` روی `/contact`)
- دکمه‌ی هدر شرطی
- فوتر inline قدیمی → `.site-footer` با ۴ ستون
- حذف استایل‌های کروم: pageStyle, headerStyle, headerInner, brandStyle, brandIcon,
  navStyle, navLinkStyle, navLoginStyle, mainStyle, heroStyle, heroTitle, heroSub,
  footerStyle, footerInner, footerLinks, footerLink, dot
- دست‌نخورده: `submitContactAction`، بنر `?sent=1`، فرم (name/contact/body با
  maxLength 80/120/2000)، استایل‌های فرم (formCardStyle, labelStyle, hintInline,
  inputStyle, hintStyle, submitBtnStyle, successBanner)

### ۳ — `src/app/warehouses/page.tsx`
- import `getCurrentUserOrNull`؛ `const user = await getCurrentUserOrNull()`
- حذف کروم inline → کروم کلاسی (CurrencyTicker از قبل بود، جای آن اصلاح شد)
- ناوبری: ۴ لینک قدیمی → ۸ لینک استاندارد
- دکمه‌ی هدر شرطی
- `<main>` → `<section>` + `.wrap` با eyebrow/sec-title/sec-sub
- فوتر inline قدیمی → `.site-footer` با ۴ ستون
- دست‌نخورده: `warehouse.findMany`، فیلتر `withLocation`، کامپوننت `WarehousesMap`
  (فقط داده‌ی عمومی انبار می‌گیرد)، کارت‌ها و استایل‌های محتوا

### ۴ — `src/app/grades/[code]/page.tsx`
- import `getCurrentUserOrNull`؛ `const user = await getCurrentUserOrNull()`
- ناوبری: افزودن `/market` (۷ → ۸ لینک)
- دکمه‌ی هدر شرطی (قبلاً هاردکد `/login`)
- فوتر ستون خدمات: «ارسال و لجستیک» ← «بازار صنعتی → /market»
- دست‌نخورده: `grade.findUnique` + include documents، `review.aggregate`،
  `warehouseStock.findFirst`، `findSimilarGrades`، بلوک امتیاز، دکمه‌ی هوشمند
  موجودی/RFQ، جدول مشخصات، اسناد فنی، گریدهای مشابه، `KeyCell`، همه‌ی استایل‌ها

### ۵ — `src/app/page.tsx`
- فقط `import CurrencyTicker` + `<CurrencyTicker />` به‌عنوان اولین فرزند

> ⚠️ **نکته‌ی مهم:** این صفحه هنوز قالب پیش‌فرض `create-next-app` است
> (لوگوی next.svg، «To get started, edit the page.tsx file»، لینک‌های Vercel).
> صفحه‌ی اصلی سایت واقعی نیست. بازنویسی کامل آن یک کار جداگانه است و در این
> گروه انجام نشده — چون دستور بخش الف صرفاً «افزودن CurrencyTicker» بود.

## امنیت

هیچ کوئری‌ای در این گروه تغییر نکرد. `getCurrentUserOrNull()` فقط برای تصمیم‌گیری
درباره‌ی متن دکمه استفاده می‌شود و **هیچ فیلدی از آبجکت user به JSX یا کامپوننت
کلاینتی پاس داده نمی‌شود** — پس چیزی به payload صفحه‌ی عمومی اضافه نشد.

## نصب روی سرور

```
cd /var/www/anbarpolymer-app
tar -xzf /tmp/group-20-public-chrome.tar.gz
npm run build
pm2 restart anbarpolymer
```

- ❌ `prisma migrate` **نیاز نیست** — هیچ تغییری در schema نیست
- ❌ `prisma generate` **نیاز نیست**
- ❌ پکیج جدید **نیاز نیست**
- ✅ فقط build + restart

## بررسی پس از نصب

1. `/grades` — بدون لاگین: دکمه «ورود / ثبت‌نام»؛ با لاگین: «پیشخوان»
2. `/grades/<code>` — همان تست + وجود لینک «بازار صنعتی» در ناوبری
3. `/contact` — کروم جدید، تب «تماس با ما» فعال، ارسال فرم → بنر `?sent=1`
4. `/warehouses` — کروم جدید + نقشه سالم رندر شود
5. `/` — نوار ارز بالای صفحه ظاهر شود (بقیه‌ی صفحه هنوز قالب پیش‌فرض)
