# NOTES-COMBINED.md — خلاصه بازطراحی جدول بازار + صفحه درباره ما

تاریخ: ۱۴۰۵/۰۶/۲۳

---

## بخش اول: بازطراحی جدول بازار صنعتی

### هدف
جایگزینی کارت‌های بلند فشرده با جدول استاندارد اکسل‌مانند که در هر ویوپورت ۱۰–۱۵ ردیف نمایش بدهد (نه ۱–۲ کارت).

### تغییرات اعمال‌شده

| فایل | وضعیت |
|---|---|
| `src/app/market/page.tsx` | ویرایش — حذف import‌های بی‌استفاده، جایگزینی بلاک رندر supply/demand با هدر Grid + ردیف‌های کلاینتی |
| `src/components/SupplyTableRow.tsx` | ایجاد — ردیف فشرده عرضه |
| `src/components/DemandTableRow.tsx` | ایجاد — ردیف فشرده تقاضا |
| `src/components/TrustCardModal.tsx` | ایجاد — مودال Trust Card (عرضه و تقاضا) |
| `src/components/ListingDetailModal.tsx` | ویرایش — export `ListingDetailDialog` + export `countryLabel` + اضافه‌شدن Trust Card |
| `src/components/PurchaseRequestDetailModal.tsx` | ویرایش — export `PurchaseRequestDialog` + اضافه‌شدن Trust Card |
| `src/app/globals.css` | ویرایش — کلاس `.market-row-hover` |

### قاعده minmax(0, Xfr)
برای جلوگیری از «CSS Grid Blowout» (محتوای بلند مثل «در حال معامله» یا نام تولیدکننده بلند، همراستایی ستون‌ها رو در یک ردیف خاص به هم می‌ریزه)، تمام `fr`‌ها در `gridTemplateColumns` به شکل `minmax(0, Xfr)` نوشته شده‌اند — نه `Xfr` خام. این قاعده در کامنت هر فایل توضیح داده شده.

### معماری مودال دوگانه
هر ردیف دو state مجزا دارد:
1. **`open`** → `ListingDetailDialog` / `PurchaseRequestDialog` — با کلیک روی هرجای ردیف (به‌جز دکمه‌ها) باز می‌شود
2. **`trustOpen`** → `TrustCardModal` — فقط با کلیک روی دکمه `ⓘ` باز می‌شود

کلیک‌های روی دکمه‌ها با `e.stopPropagation()` جلوی باز شدن پاپ‌آپ جزئیات را می‌گیرند.

### نگاشت Trust Card
| تب | نسخه | عنوان | مخاطب |
|---|---|---|---|
| عرضه | Version 2 | «فرآیند این پیشنهاد» | خریدار |
| تقاضا | Version 1 | «فرآیند این درخواست» | فروشنده/تأمین‌کننده |

متون به‌صورت کلمه‌به‌کلمه از فایل `trust-card-texts.md` کپی شده‌اند (ZWNJ حفظ شده).

### رفتار دکمه‌ها (سیستم گیت)
**تب عرضه:**
- مهمان → «عضو شوید» → `/signup`
- `kycLevel < 1` → «احراز هویت» → `/verification`
- `kycLevel >= 1` → «پیشنهاد خرید» (غیرفعال، آماده فعال‌سازی)

**تب تقاضا:**
- وارد شده → «پیشنهاد فروش» → `/new-listing?request=ID`
- مهمان → «ورود برای پاسخ» → `/login`

### ریسپانسیو
- عرضه: `minWidth: 760px` + `overflowX: auto`
- تقاضا: `minWidth: 680px` + `overflowX: auto`
- موبایل: اسکرول افقی با momentum

### امنیت
- کامنت‌های امنیتی `market/page.tsx` دقیقاً حفظ شده‌اند:
  - «NOTE: do NOT include `user` here — the full listing is passed to the <ListingDetailModal> client component and would serialize User.passwordHash (and phone/email) into the public page payload. The modal never uses it.»
  - «نکته‌ی امنیتی: include: { user } ممنوعه — این صفحه عمومیه و User شامل passwordHash/phone/email میشه»
- کوئری‌ها و فیلترها بدون تغییر باقی مانده‌اند.

---

## بخش دوم: بازطراحی صفحه درباره ما (UX)

### هدف
تبدیل صفحه معرفی ساده به صفحه‌ی ساختاریافته شش‌بخشی با هدف ارزش‌پیشنهادی، مسیر خرید و Trust — حفظ هویت بصری navy+orange.

### فایل تغییریافته
| فایل | وضعیت |
|---|---|
| `src/app/about/page.tsx` | بازنویسی کامل |

### ساختار شش‌بخشی

1. **Hero: ارزش پیشنهادی** — eyebrow + h1 + پاراگراف + ۴ چک‌مارک
2. **مسئله و راه‌حل** — دو کارت کنار هم: روشن (بازار سنتی: ۴ چالش) + تیره navy (راه‌حل: ۴ راهکار)
3. **ارزش پیشنهادی** — ۴ کارت شماره‌دار با حاشیه راست orange
4. **مسیر خرید** — ۶ قدم افقی با دایره‌های شماره‌دار
5. **اصول معامله** — ۳ کارت مستقل (شفافیت قیمت / اصالت کالا / امنیت معامله)
6. **CTA نهایی** — دو دکمه: «مشاهده گریدها» → `/grades` + «خدمات سازمانی» → `/services`

### حفظ شده از نسخه قبل
- `export const dynamic = 'force-dynamic'`
- `getCurrentUserOrNull()` — هدر با لاگین/لاگاوت
- `CurrencyTicker` + `PublicHeader(activePage="/about")` + `Footer`
- KPI `Promise.all` — شمارش گرید، آگهی، انبار، مقاله + میانگین رضایت
- ریتینگ‌لاین با فرمت فارسی `toLocaleString('fa-IR')`

### متون
تمام متون فارسی مستقیماً از فایل HTML مرجع (`anbar-polymer-about-ux-redesign.html`) کپی شده‌اند — ZWNJ‌ها حفظ شده‌اند.

### توکن‌ها و استایل‌ها
- از `@/lib/styles/tokens` برای رنگ‌ها، spacing، radius، fontSize
- از کلاس‌های موجود globals.css: `.wrap`, `.eyebrow`, `.sec-title`, `.sec-sub`, `.section-line`, `.kpi-row`, `.kpi`, `.btn`, `.btn-cyan`, `.btn-outline`
- بقیه layout با inline style objects — بدون hardcoded hex

### ریسپانسیو
- مقادیر Grid برای صفحات کوچک‌تر با `@media` rules تنظیم می‌شوند (در globals.css یا inline)
- CTA: flexWrap برای شکستن دکمه‌ها در موبایل
