'use client'

import { colors, radius, fontSize } from '@/lib/styles/tokens'

type Variant = 'supply' | 'demand'

const COPY: Record<Variant, { eyebrow: string; title: string; body: string[]; closing: string }> = {
  // تب عرضه → مخاطب خریدار → نسخه‌ی «پیشنهاد فروش»
  supply: {
    eyebrow: 'شفافیت فرآیند',
    title: 'فرآیند این پیشنهاد',
    body: [
      'پیشنهاد فروشی که مشاهده می‌کنید، در پاسخ به درخواست شما در سامانه‌ی انبار پلیمر ثبت شده است.',
      'پذیرش یک پیشنهاد به‌معنای پایان فرآیند نیست؛ در صورت تأیید، مراحل بعدی — از جمله توافق نهایی، پرداخت و پیگیری تحویل — در همان مسیر معاملاتی سامانه ادامه پیدا می‌کند.',
      'اطلاعات مربوط به هر معامله (شامل پیشنهاد، زمان ثبت و وضعیت آن) در سامانه نگهداری می‌شود تا در صورت نیاز، قابل بازبینی باشد.',
    ],
    closing: 'انبار پلیمر، همراه معامله از ثبت درخواست تا تکمیل فرآیند.',
  },
  // تب تقاضا → مخاطب فروشنده/تأمین‌کننده → نسخه‌ی «درخواست خرید»
  demand: {
    eyebrow: 'شفافیت فرآیند',
    title: 'فرآیند این درخواست',
    body: [
      'این درخواست خرید در سامانه‌ی انبار پلیمر ثبت شده و اطلاعات اصلی آن — گرید، مقدار، محل بار و مبدأ — پیش از ارائه‌ی پیشنهاد در اختیار شما قرار می‌گیرد.',
      'پیشنهادی که ثبت می‌کنید نیز در همین سامانه نگهداری می‌شود؛ شامل زمان ثبت و وضعیت آن. این کار برای مواقعی که چند درخواست یا مذاکره را هم‌زمان پیش می‌برید، مشخص‌بودن وضعیت هرکدام را ساده‌تر می‌کند.',
      'اگر پیشنهاد شما مورد پذیرش قرار بگیرد، مراحل بعدی معامله (مانند تأیید نهایی و پرداخت) در همان مسیر معاملاتی سامانه دنبال می‌شود.',
    ],
    closing: 'انبار پلیمر، بستری برای ثبت و پیگیری فرآیند معامله — نه فقط اعلام قیمت.',
  },
}

export default function TrustCardModal({ variant, onClose }: { variant: Variant; onClose: () => void }) {
  const c = COPY[variant]
  return (
    <div style={overlayStyle} onClick={onClose}>
      <div style={cardStyle} onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true" aria-label={c.title}>
        {/* top accent */}
        <div style={accentStyle} />
        {/* header */}
        <div style={headerStyle}>
          <div>
            <div style={eyebrowStyle}>{c.eyebrow}</div>
            <h3 style={titleStyle}>{c.title}</h3>
          </div>
          <button onClick={onClose} style={closeBtnStyle} aria-label="بستن">
            <svg width="18" height="18" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M6 6l8 8M14 6l-8 8" strokeLinecap="round" />
            </svg>
          </button>
        </div>

        <div style={bodyStyle}>
          {c.body.map((p, i) => (
            <p key={i} style={paraStyle}>
              {p}
            </p>
          ))}
        </div>

        <div style={closingWrapStyle}>
          <span style={closingDotStyle} />
          <p style={closingStyle}>{c.closing}</p>
        </div>
      </div>
    </div>
  )
}

// ── styles ──
const overlayStyle: React.CSSProperties = {
  position: 'fixed',
  inset: 0,
  background: 'rgba(12,22,56,0.48)',
  zIndex: 1000,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  padding: 16,
}
const cardStyle: React.CSSProperties = {
  background: colors.bgCard,
  borderRadius: 16,
  width: '100%',
  maxWidth: 480,
  maxHeight: '90vh',
  overflowY: 'auto',
  boxShadow: '0 16px 48px rgba(15,30,70,0.22)',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
  position: 'relative',
  border: `1px solid ${colors.borderSubtle}`,
}
const accentStyle: React.CSSProperties = {
  height: 4,
  borderRadius: '16px 16px 0 0',
  background: `linear-gradient(90deg, ${colors.navy} 0%, ${colors.orange} 100%)`,
}
const headerStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'flex-start',
  gap: 12,
  padding: '18px 22px 14px',
  borderBottom: `1px solid ${colors.borderSubtle}`,
}
const eyebrowStyle: React.CSSProperties = {
  fontSize: 10,
  fontWeight: 700,
  letterSpacing: '0.06em',
  color: colors.orange,
  marginBottom: 6,
}
const titleStyle: React.CSSProperties = {
  fontSize: 16,
  fontWeight: 800,
  color: colors.navy,
  margin: 0,
  lineHeight: 1.5,
}
const closeBtnStyle: React.CSSProperties = {
  background: colors.bgHover,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: 8,
  width: 32,
  height: 32,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  color: colors.textMuted,
  cursor: 'pointer',
  flexShrink: 0,
}
const bodyStyle: React.CSSProperties = {
  padding: '16px 22px 10px',
  display: 'flex',
  flexDirection: 'column',
  gap: 12,
}
const paraStyle: React.CSSProperties = {
  fontSize: 13,
  lineHeight: 2,
  color: '#2a3447',
  margin: 0,
}
const closingWrapStyle: React.CSSProperties = {
  display: 'flex',
  gap: 10,
  alignItems: 'flex-start',
  margin: '6px 22px 18px',
  padding: '12px 14px',
  background: '#fff7f0',
  border: '1px solid #ffe3d1',
  borderRadius: 10,
}
const closingDotStyle: React.CSSProperties = {
  width: 8,
  height: 8,
  borderRadius: 50,
  background: colors.orange,
  marginTop: 7,
  flexShrink: 0,
  boxShadow: `0 0 0 4px ${colors.orangeBg}`,
}
const closingStyle: React.CSSProperties = {
  fontSize: 12.5,
  fontWeight: 700,
  lineHeight: 1.9,
  color: colors.navy,
  margin: 0,
}
