'use client'

import { useState } from 'react'
import { createPortal } from 'react-dom'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { cardStyle as sharedCardStyle, badgeStyle } from '@/lib/styles/shared'
import TrustCardModal from '@/components/TrustCardModal'

type Props = {
  request: any
  isLoggedIn: boolean
}

export default function PurchaseRequestDetailModal({ request, isLoggedIn }: Props) {
  const [open, setOpen] = useState(false)
  const [trustOpen, setTrustOpen] = useState(false)

  return (
    <>
      {/* ── کارت تقاضا — همان کارت قبلی صفحه‌ی بازار؛ کلیک روی هرجای کارت (به‌جز دکمه‌ها) پاپ‌آپ رو باز می‌کنه ── */}
      <div style={cardStyle} onClick={() => setOpen(true)}>
        <div style={headStyle}>
          <div>
            <span style={{ fontSize: fontSize.md, fontWeight: 800 }}>{request.grade.code}</span>{' '}
            <span style={{ fontSize: fontSize.xs, color: colors.textMuted }}>
              {request.grade.producer} ({request.grade.category})
            </span>
          </div>
          <span style={openTagStyle}>باز</span>
        </div>

        <div style={gridStyle}>
          <div>
            <div style={cellLabelStyle}>مقدار درخواستی</div>
            <div style={{ fontSize: fontSize.sm, fontWeight: 700 }}>{request.quantityTon} تن</div>
          </div>
          <div>
            <div style={cellLabelStyle}>سقف قیمت خریدار</div>
            <div style={{ fontSize: fontSize.sm, fontWeight: 700, color: colors.orange }}>
              {request.maxPriceToman
                ? `${request.maxPriceToman.toLocaleString('fa-IR')} تومان/کیلو`
                : 'اعلام نشده'}
            </div>
          </div>
          <div>
            <div style={cellLabelStyle}>استان تحویل</div>
            <div style={{ fontSize: fontSize.sm, fontWeight: 600 }}>{request.province || 'مهم نیست'}</div>
          </div>
          <div>
            <div style={cellLabelStyle}>آگهی‌های ثبت‌شده</div>
            <div style={{ fontSize: fontSize.sm, fontWeight: 600 }}>{request._count.listings} آگهی</div>
          </div>
        </div>

        {request.description && (
          <div style={{ fontSize: fontSize.sm, color: colors.neutralText, lineHeight: 1.8, marginBottom: 10 }}>
            {request.description}
          </div>
        )}

        <div style={footStyle}>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
            <span>ثبت: {new Date(request.createdAt).toLocaleDateString('fa-IR')}</span>
            {request.expiresAt && (
              <>
                <span>•</span>
                <span>اعتبار تا: {new Date(request.expiresAt).toLocaleDateString('fa-IR')}</span>
              </>
            )}
            <span>•</span>
            <span style={{ fontFamily: 'monospace', direction: 'ltr' }}>#{request.id.slice(0, 8)}</span>
          </div>
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            {isLoggedIn ? (
              <a
                href={`/new-listing?request=${request.id}`}
                style={respondBtnStyle}
                onClick={(e) => e.stopPropagation()}
              >
                پیشنهاد فروش
              </a>
            ) : (
              <a href="/login" style={respondBtnStyle} onClick={(e) => e.stopPropagation()}>
                ورود برای پاسخ
              </a>
            )}
            {/* Info icon — trust card (جدا از پاپ‌آپ جزئیات) */}
            <button
              onClick={(e) => {
                e.stopPropagation()
                setTrustOpen(true)
              }}
              style={iconButtonStyle}
              title="فرآیند این درخواست"
              aria-label="فرآیند این درخواست"
            >
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
                <circle cx="8" cy="8" r="6" />
                <path d="M8 11V7.5" strokeLinecap="round" />
                <path d="M8 5.2h.01" strokeLinecap="round" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* ── Overlay + Dialog — portaled to <body> so it isn't nested inside the cards column ── */}
      {open &&
        createPortal(
          <PurchaseRequestDialog
            request={request}
            isLoggedIn={isLoggedIn}
            onClose={() => setOpen(false)}
          />,
          document.body,
        )}
      {trustOpen && createPortal(<TrustCardModal variant="demand" onClose={() => setTrustOpen(false)} />, document.body)}
    </>
  )
}

// Rendered via createPortal into <body> (see above) so the fixed overlay isn't
// clipped by card overflow. Only mounts after a client-side click.
// Exported so DemandTableRow can reuse it.
export function PurchaseRequestDialog({
  request,
  isLoggedIn,
  onClose,
}: {
  request: any
  isLoggedIn: boolean
  onClose: () => void
}) {
  return (
    <div style={overlayStyle} onClick={onClose}>
      <div style={dialogStyle} onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div style={headerStyle}>
          <div>
            <div style={{ fontSize: fontSize.xs, color: colors.textMuted, fontFamily: 'monospace', marginBottom: 4 }}>
              #{request.id.slice(0, 8)}
            </div>
            <h3 style={{ fontSize: 17, fontWeight: 700, margin: 0, color: '#1b1e24' }}>
              {request.grade.code} — {request.grade.producer}
            </h3>
          </div>
          <button onClick={onClose} style={closeButtonStyle} aria-label="بستن">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M6 6l8 8M14 6l-8 8" strokeLinecap="round" />
            </svg>
          </button>
        </div>

        {/* Body */}
        <div style={bodyStyle}>
          <div style={detailRowStyle}>
            <span style={labelStyle}>تاریخ ثبت</span>
            <span style={valueStyle}>{new Date(request.createdAt).toLocaleDateString('fa-IR')}</span>
          </div>

          <div style={detailRowStyle}>
            <span style={labelStyle}>کد گرید</span>
            <span style={{ ...valueStyle, fontFamily: 'monospace' }}>{request.grade.code}</span>
          </div>

          <div style={detailRowStyle}>
            <span style={labelStyle}>دسته</span>
            <span style={valueStyle}>{request.grade.category}</span>
          </div>

          <div style={detailRowStyle}>
            <span style={labelStyle}>تولیدکننده</span>
            <span style={valueStyle}>{request.grade.producer}</span>
          </div>

          <div style={detailRowStyle}>
            <span style={labelStyle}>کاربرد</span>
            <span style={valueStyle}>{request.grade.applicationType ?? '—'}</span>
          </div>

          <div style={detailRowStyle}>
            <span style={labelStyle}>مقدار درخواستی</span>
            <span style={valueStyle}>
              <b>{request.quantityTon}</b> تن
            </span>
          </div>

          <div style={detailRowStyle}>
            <span style={labelStyle}>استان تحویل</span>
            <span style={valueStyle}>{request.province || 'مهم نیست'}</span>
          </div>

          {request.description && (
            <div style={{ ...detailRowStyle, alignItems: 'flex-start' }}>
              <span style={labelStyle}>توضیحات</span>
              <span style={{ ...valueStyle, lineHeight: 1.8 }}>{request.description}</span>
            </div>
          )}

          {request.expiresAt && (
            <div style={detailRowStyle}>
              <span style={labelStyle}>اعتبار تا</span>
              <span style={valueStyle}>{new Date(request.expiresAt).toLocaleDateString('fa-IR')}</span>
            </div>
          )}

          {/* Price — سقف قیمت خریدار، عمومی مثل خود کارت */}
          <div style={priceRowStyle}>
            <span style={{ fontSize: fontSize.base, fontWeight: 700, color: '#1b1e24' }}>سقف قیمت خریدار</span>
            <span style={{ fontSize: fontSize.lg, fontWeight: 800, color: colors.orange }}>
              {request.maxPriceToman
                ? `${request.maxPriceToman.toLocaleString('fa-IR')} تومان/کیلو`
                : 'اعلام نشده'}
            </span>
          </div>
        </div>

        {/* Footer — no KYC gate, like the card itself: مهمان فقط به لاگین هدایت می‌شه */}
        <div style={footerStyle}>
          {isLoggedIn ? (
            <a href={`/new-listing?request=${request.id}`} style={buyButtonStyle}>
              پیشنهاد فروش
            </a>
          ) : (
            <a href="/login" style={buyButtonStyle}>
              ورود برای پاسخ
            </a>
          )}
        </div>
      </div>
    </div>
  )
}

// ── Styles ──
// کارت: همان demandCardStyle/demandHeadStyle/demandGridStyle/demandFootStyle قبلی صفحه‌ی بازار
const cardStyle: React.CSSProperties = {
  ...sharedCardStyle,
  padding: 18,
  marginBottom: 0,
  cursor: 'pointer',
}
const headStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: spacing.md,
}
const openTagStyle: React.CSSProperties = {
  ...badgeStyle('success'),
  fontWeight: 700,
}
const gridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))',
  gap: 14,
  marginBottom: spacing.md,
}
const cellLabelStyle: React.CSSProperties = {
  fontSize: fontSize.xs,
  color: colors.textMuted,
  marginBottom: 3,
}
const footStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  flexWrap: 'wrap',
  gap: 10,
  borderTop: `1px solid ${colors.borderSubtle}`,
  paddingTop: spacing.md,
  fontSize: fontSize.xs,
  color: colors.textMuted,
}
const respondBtnStyle: React.CSSProperties = {
  background: colors.navy,
  color: '#fff',
  borderRadius: radius.md,
  padding: '8px 16px',
  fontSize: fontSize.sm,
  fontWeight: 700,
  textDecoration: 'none',
  whiteSpace: 'nowrap',
}
const iconButtonStyle: React.CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  width: 30,
  height: 30,
  padding: 0,
  borderRadius: radius.sm,
  border: `1px solid ${colors.borderStrong}`,
  background: colors.bgCard,
  color: colors.navy,
  cursor: 'pointer',
  flexShrink: 0,
}
// پاپ‌آپ: همان استایل‌های ListingDetailModal
const overlayStyle: React.CSSProperties = {
  position: 'fixed',
  inset: 0,
  background: 'rgba(0,0,0,0.45)',
  zIndex: 1000,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  padding: 16,
}
const dialogStyle: React.CSSProperties = {
  background: colors.bgCard,
  borderRadius: 16,
  padding: '20px 24px',
  width: '100%',
  maxWidth: 460,
  maxHeight: '90vh',
  overflowY: 'auto',
  boxShadow: '0 8px 40px rgba(0,0,0,0.18)',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const headerStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'flex-start',
  marginBottom: 16,
  paddingBottom: 14,
  borderBottom: '1px solid #f1efe8',
}
const closeButtonStyle: React.CSSProperties = {
  background: 'none',
  border: 'none',
  color: colors.textMuted,
  cursor: 'pointer',
  padding: 4,
  display: 'flex',
  flexShrink: 0,
}
const bodyStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
}
const detailRowStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  gap: 12,
  padding: '9px 0',
  borderBottom: '1px solid #f4f5f7',
  fontSize: fontSize.base,
}
const priceRowStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  gap: 12,
  background: '#fff4ee',
  margin: '8px -24px -4px',
  padding: '14px 24px',
}
const labelStyle: React.CSSProperties = {
  color: '#6f7680',
  flexShrink: 0,
}
const valueStyle: React.CSSProperties = {
  color: '#1b1e24',
  fontWeight: 600,
  textAlign: 'left',
}
const footerStyle: React.CSSProperties = {
  marginTop: 18,
  paddingTop: 16,
  borderTop: '1px solid #f1efe8',
}
const buyButtonStyle: React.CSSProperties = {
  display: 'block',
  width: '100%',
  textAlign: 'center',
  background: colors.navy,
  color: colors.bgCard,
  border: 'none',
  borderRadius: 10,
  padding: '13px 0',
  fontSize: fontSize.md,
  fontWeight: 800,
  textDecoration: 'none',
  cursor: 'pointer',
  fontFamily: 'inherit',
}
