# گزارش: گیتِ امنیتیِ `admin-orders` و اکشن‌های هم‌خانواده‌اش در `admin-deals`، `admin-users` و `admin-disputes`

> این گزارش کارِ تسکِ فوریِ «گیتِ امنیتیِ admin-orders» را مستند می‌کند. پلنِ مصوب در همین نشست تأیید شد: هر هفت تصمیم با پیش‌فرض، جز تصمیمِ ۷ (بررسیِ DBِ زنده) که لازم نبود و کاربر خودش جدا چک می‌کند.
> فایل‌های `src/app/admin-*` در git هنوز untracked هستند، پس `git diff` چیزی نشان نمی‌دهد؛ نسخه‌ی مرجع همین آرشیو است. هیچ commit/push انجام نشد.

## خلاصه

هر Server Action یک endpoint عمومیِ POST است. `getCurrentUser()` فقط login را چک می‌کند، نه نقش یا سطحِ دسترسیِ بخش، و مخفی‌کردنِ دکمه در UI مرزِ امنیتی نیست. طبق پلن، از ۱۷ تابعِ مشکل‌دار ۱۰ تا هیچ چکی نداشتند (حتی login) و ۷ تا فقط login. با دو اکشنِ KYC (تصمیمِ ۶) جمعاً **۱۹ اکشن در ۴ فایل** حالا داخلِ خودشان گیتِ نقش یا بخش دارند:

| فایل | اکشن | قبل (طبق پلن) | بعد |
|---|---|---|---|
| `admin-orders/actions.ts` | `setOrderPricing`، `rejectOrder`، `cancelProformaAction` | فقط login | ویرایش/کاملِ بخشِ `orders` — کدِ `A-SECTION-ORDERS` |
| همان | `approvePaymentReceiptAction`، `rejectPaymentReceiptAction` | فقط login | ویرایش/کاملِ بخشِ `payments` — `A-SECTION-PAYMENTS` |
| `admin-deals/actions.ts` | `confirmFundsReleased`، `adjustDeadlineAction` | هیچ | ویرایش/کاملِ بخشِ `deals` — `A-SECTION-DEALS` |
| همان | `addHolidayAction`، `removeHolidayAction`، `importHolidaysAction` | هیچ | فقط admin — `A-ROLE-DEALS` |
| `admin-users/actions.ts` | `createStaffUser`، `changeUserRole`، `toggleUserActive`، `updateUserInfo`، `setPermission` | هیچ | فقط admin — `A-ROLE-USERS` |
| همان | `reviewKycLevel1Action`، `reviewProducerLicenseAction` | بدنه‌شان در پلن بررسی نشده بود | ویرایش/کاملِ بخشِ `kyc` — `A-SECTION-KYC` |
| `admin-disputes/actions.ts` | `resolveDisputeAction` | فقط login | ویرایش/کاملِ بخشِ `disputes` |
| همان | `exportDisputeEvidenceAction` | فقط login | هر سطحی جز `none` در بخشِ `disputes` |

هلپرهای گیت در هر فایل private و export‌نشده‌اند (فایلِ `'use server'` هر export را به اکشنِ عمومی تبدیل می‌کند). admin همیشه عبور می‌کند، چون سطحِ بخشِ خودکار ندارد؛ بقیه باید `edit` یا `full` داشته باشند، وگرنه `AccessDeniedError` با کدِ `A-SECTION-*` یا `A-ROLE-*` پرتاب می‌شود. الگو از `requireLogisticsEditAccess` در `admin-logistics/actions.ts` کپی شد، بدونِ ماژولِ مشترک.

**اثرِ پیش از اصلاح (از روی کد؛ هیچ exploitی اجرا نشد):**

- **users:** `changeUserRole` قانونِ تک‌مدیر را فقط برای `newRole==='admin'` چک می‌کرد و `assertSingleAdmin` فقط مدیرِ فعال را می‌بیند؛ پس می‌شد مدیر را تنزل داد یا با `toggleUserActive` غیرفعال کرد و بعد کسِ دیگری را admin کرد. `setPermission` هر دسترسی‌ای می‌داد.
- **deals:** `confirmFundsReleased` معامله‌ی `secured_manual` را بدونِ تأییدِ واقعیِ حسابداری `settled` می‌کرد. شناسه‌ی تأییدکننده در آن و در `adjustDeadlineAction` از فیلدِ فرم می‌آمد و قابلِ جعل بود.
- **orders:** هر staff قیمتِ سفارش را در هر وضعیتی عوض می‌کرد. تأییدِ فیش وجودِ فیش را چک نمی‌کرد و روی سفارشِ `contracted` وضعیتِ `paid` می‌زد و فاکتورِ دائمی صادر می‌کرد. ردِ فیش، فیشِ قبلاً تأییدشده را هم پاک می‌کرد.
- **disputes:** هر staff می‌توانست اختلاف را حل کند و خروجیِ مدارک (طرفین، راننده، پلاک، GPS، لاگ‌ها) بگیرد.

---

## فایل‌های تغییر یافته

| فایل | وضعیت | تغییر |
|---|---|---|
| `src/lib/errorCodes.ts` | ویرایش | پنج کدِ جدید: `A-SECTION-ORDERS`، `A-SECTION-PAYMENTS`، `A-SECTION-DISPUTES`، `A-SECTION-DEALS`، `A-SECTION-KYC` (خط‌های ۹۷، ۱۰۱، ۱۰۵، ۱۰۹، ۱۱۳). `A-ROLE-USERS` و `A-ROLE-DEALS` از قبل بودند |
| `src/app/admin-orders/actions.ts` | ویرایش | هلپرهای `requireOrdersEditAccess` و `requirePaymentsEditAccess` و `assertReceiptPending`؛ سخت‌سازیِ داخلِ اکشن‌ها (پایین‌تر). `approveOrderAction` دست‌نخورده |
| `src/app/admin-orders/page.tsx` | ویرایش | گیتِ دیدن و بنرِ دسترسیِ جزئی؛ فرم‌ها و منوی فیش بر اساسِ سطحِ `orders` و `payments` |
| `src/app/admin-deals/actions.ts` | ویرایش | `requireDealsAdmin` و `requireDealsEditAccess`؛ شناسه‌ی عامل از session |
| `src/app/admin-deals/page.tsx` | ویرایش (**CRLF حفظ شد**، ۸۲۶ خط) | `canEditDeals` برای دکمه‌ی آزادسازیِ وجه؛ حذفِ hiddenهای `confirmedById` و `adjustedById` |
| `src/app/admin-users/actions.ts` | ویرایش | `requireAdminRole` و `requireKycReviewAccess` روی ۷ اکشن |
| `src/app/admin-users/page.tsx` | ویرایش | دکمه‌های بررسیِ KYC فقط با ویرایش/کاملِ `kyc` (`canReview`)؛ بقیه‌ی فرم‌ها فقط برای admin (از قبل) |
| `src/app/admin-disputes/actions.ts` | ویرایش | `requireDisputesAccess('edit')` برای ثبتِ نتیجه و `('view')` برای خروجیِ مدارک |
| `src/app/admin-disputes/page.tsx` | ویرایش | گیتِ دیدن: بدونِ دسترسی هیچ کوئری‌ای اجرا نمی‌شود؛ دسترسیِ جزئی بنر دارد و فرم‌ها «فقط مشاهده» می‌شوند |
| `tests/race-order-status.spec.ts` | ویرایش (فقط comment) | خط‌های ۱۰ تا ۱۳: توضیحِ اینکه چکِ `pending` در `setOrderPricing` خوانش-بعد-نوشتن است، نه اتمیک |
| `NOTES-ADMIN-ORDERS-SECURITY-GATE.md` | **جدید** | همین گزارش |
| `approveOrderAction` و بقیه‌ی اکشن‌های `admin-*` که در جدولِ بالا نیستند | **دست‌نخورده** | — |

---

## تصمیم‌های کلیدی و انحراف از پلن (با دلیل)

### تصمیم‌های مصوب

| # | تصمیم | وضعیت |
|---|---|---|
| ۱ | دامنه: همه‌ی ۱۷ تابعِ جدولِ پلن، نه فقط پنج تابعِ `admin-orders` | اجرا شد (به‌علاوه‌ی دو اکشنِ KYC از تصمیمِ ۶ = ۱۹) |
| ۲ | فیش‌ها: فقط بخشِ `payments`؛ منوی فیش در `/admin-orders` برای کسی که `payments` ندارد مخفی | اجرا شد |
| ۳ | `confirmFundsReleased` و `adjustDeadlineAction`: بخشِ `deals` | اجرا شد |
| ۴ | سخت‌سازیِ داخلِ اکشن‌ها (پایین‌تر) | اجرا شد |
| ۵ | گیتِ دیدن برای `/admin-orders` و `/admin-disputes`، مثلِ `admin-payments/page.tsx:27` | اجرا شد |
| ۶ | اکشن‌های KYC: پیش‌فرضِ پلن «فقط admin» | **با انحراف اجرا شد** (انحرافِ ۱) |
| ۷ | بررسیِ فقط‌خواندنیِ DBِ زنده | **اجرا نشد** — کاربر لازم ندانست و خودش جدا چک می‌کند |

### انحراف ۱ — KYC: بخشِ `kyc`، نه «فقط admin»

**چرا:** `/admin-users` فرمِ KYC را به کارشناس‌های دارای دسترسیِ `kyc` نشان می‌دهد؛ گیتِ «فقط admin» آن‌ها را بعد از دیدنِ فرم قفل می‌کرد. پس گیت روی ویرایش یا کاملِ بخشِ `kyc` رفت (admin همیشه مجاز). **برای «فقط admin»:** در `admin-users/actions.ts` در `reviewKycLevel1Action` و `reviewProducerLicenseAction`، `requireKycReviewAccess()` را با `requireAdminRole('…')` عوض کن.

### انحراف ۲ — `canEditDeals` در UIِ معاملات

دکمه‌ی آزادسازیِ وجه برای کاربرِ فقط‌مشاهده مخفی شد (`admin-deals/page.tsx:52` و `:757`). این کار بیرونِ پلن بود و فقط UI را عوض می‌کند؛ مرزِ امنیتی همان گیتِ داخلِ اکشن است.

### سخت‌سازیِ داخلِ اکشن‌ها (تصمیمِ ۴)

- **`setOrderPricing`:** فقط برای سفارشِ `pending` (خطِ ۷۲).
- **تأیید و ردِ فیش:** `assertReceiptPending` (خط‌های ۵۰ تا ۵۷). سفارش باید وجود داشته باشد، `paymentReceiptStatus` برابرِ `pending` باشد و URLِ فیش ثبت شده باشد. بدونِ این چک، POSTِ مستقیم روی سفارشِ بدونِ فیش `paid` می‌زد یا فیشِ تأییدشده را پاک می‌کرد.
- **`confirmedById` و `adjustedById`:** از `user.id`ِ session می‌آید، نه از فرم؛ hiddenهای فرم حذف شد.

---

## اصلاحِ دو جمله‌ی گزارشِ قبلیِ چت

۱. **`approveOrderAction` «کدِ مرده» نیست.** مصرف‌کننده ندارد (grep: فقط تعریفِ آن در `admin-orders/actions.ts:304` و دو comment در `tests/race-order-status.spec.ts`)، ولی تنها کدی است که سفارش را از `awaiting_approval` به `priced` می‌برد (`src/lib/workflow.ts:18` تا `:21`). امروز هیچ UIای آن را صدا نمی‌زند، پس سفارش‌های `awaiting_approval` از مسیرِ UI جلو نمی‌روند؛ حذفِ تابع این وضع را دائمی می‌کند. به همین دلیل دست‌نخورده ماند.

۲. جمله‌ی «`resolveDisputeAction` و `setOrderPricing` ورودی رو اعتبارسنجی نمی‌کنن (`parseFloat` برای `finalPrice`)» مبهم بود. `parseFloat` فقط در `setOrderPricing` است (خطِ ۷۸). `resolveDisputeAction` ورودیِ عددی ندارد؛ کمبودش اعتبارسنجیِ `status`، `resolution` و `disputeId` است، و پیش‌شرطِ `status:'open'` هم ندارد.

---

## مواردِ عمداً دست‌نخورده

این موارد در تسکِ پیگیری (اَبرتسکِ «موارد باقی‌مانده از گیت امنیتی admin-*») پلن می‌شوند و تا تأیید، کدشان تغییر نمی‌کند.

- **`/admin-deals` گیتِ دیدن ندارد.** کامنتِ خودِ صفحه هم می‌گوید گیتِ سخت جدا ندارد.
- **دستورِ پرداخت فقط نقش چک می‌کند.** `updateDealPaymentInstructionsAction` و `updateSellerPaymentInstructionsAction` فقط `admin` یا `staff` را می‌پذیرند، بدونِ چکِ بخش. همین الگو در `approvePaymentAction`، `rejectPaymentAction` و `reviewPurchaseRequestAction` هم هست (خارج از پلنِ این کار).
- **چکِ `pending` اتمیک نیست.** در `setOrderPricing` خوانش-بعد-نوشتن است و ردِ هم‌زمان می‌تواند وسطش بیفتد. `rejectOrder`، `cancelProformaAction` و `enforceProformaDeadlines` (در `src/lib/dealDeadlines.ts`) همین الگوی «خوانش، بعد بازگردانیِ موجودی» را دارند.
- **فیشِ ردشده گیر می‌کند.** در `src/lib/paymentReceipt.ts` (خط‌های ۶۳ تا ۷۱) آپلودِ مجدد فقط URL و زمان را می‌نویسد و `paymentReceiptStatus` را `pending` نمی‌کند؛ صف‌ها هم به `pending` نیاز دارند. قبلی بود و فقط از روی کد دیده شد.
- **نقش allowlist ندارد.** `createStaffUser` و `changeUserRole` رشته‌ی `role` را از فرم می‌گیرند.
- **خروجیِ مدارکِ اختلاف escape نمی‌شود.** `exportDisputeEvidenceAction` رشته‌های خام (نامِ شرکت، دلیلِ اختلاف، نامِ راننده، پلاک، پیامِ لاگ) را در HTML می‌گذارد و `ExportEvidenceButton` آن را با `document.write` در پنجره‌ی هم‌origin باز می‌کند. grep: `ExportEvidenceButton` تنها importerِ این اکشن است و جایی رندر نمی‌شود، پس محرکِ زنده ندارد.
- **اعتبارسنجیِ `resolveDisputeAction`** (بالا، اصلاحِ ۲).
- **نظافتِ کد:** `approveOrderAction` (بالا، اصلاحِ ۱)؛ comment کهنه‌ی `tests/race-deal-funds.spec.ts` خط ۵۶؛ سه hiddenِ بی‌اثرِ `reviewerId` در `admin-users/page.tsx` (خط‌های ۷۶، ۸۲، ۱۰۵).
- **`/api/payment-receipt`** (خارج از دامنه، فقط گزارش): هر کاربرِ واردشده می‌تواند برای هر شناسه‌ی سفارش یا معامله فیش ثبت کند؛ نه چکِ مالکیت هست و نه چکِ وضعیت.
- **`CODE_PATTERN` و `A-SECTION-MATERIAL-LISTINGS`** (`errorCodes.ts:85`، از قبل): این کد چهار بخش دارد و با `CODE_PATTERN` (`/^[UA]-[A-Z0-9]+-[A-Z]+$/`) جور نمی‌شود. کلیدش در جدولِ کدها هست، پس احتمالاً مشکلی نیست؛ تأثیرش بررسی نشد. پنج کدِ جدیدِ این کار سه‌بخشی‌اند و با الگو جورند.
- **بررسیِ DBِ زنده** (تصمیمِ ۷): کاربر خودش جدا انجام می‌دهد.
- پوشه‌های نقطه‌دارِ ریشه‌ی ریپو (مثلِ `.recover/` و `.agents/`)، `my-tasks/page.tsx.bak`، `HANDOFF.md` و بقیه‌ی NOTES و آرشیوهای قبلی — دست‌نخورده.

---

## امنیت

- **گیتِ اصلی داخلِ اکشن است.** صفحه‌ها فقط راحتیِ کاربرند؛ حتی با مخفی‌بودنِ دکمه، POSTِ مستقیم هم باید توسطِ گیتِ اکشن بررسی شود.
- **هویتِ عامل از session** می‌آید (`confirmedById`، `adjustedById`)، نه از فرم.
- **ردِ پا (audit):** در `admin-users/actions.ts` و `admin-disputes/actions.ts` هیچ `logAudit` نیست (شمارش: ۰) و این کار audit اضافه نکرد؛ یعنی خودِ این اکشن‌ها ردِ پایی ثبت نمی‌کنند. آزادسازیِ وجه در `admin-deals/actions.ts:100` با `user.id`ِ session لاگ می‌شود (وضعیتِ آن قبل از این کار بررسی نشد).
- هیچ exploitی اجرا نشد و به سرورِ زنده‌ی راه‌دور وصل نشدیم.

> ⚠️ **هشدار دیپلوی:** قبل از deploy ردیف‌های `Permission`ِ کارشناس‌ها را چک کن. هر کارشناسی که کارِ زیر را انجام می‌دهد باید `canEdit` همان بخش را داشته باشد، وگرنه بعد از deploy `A-SECTION-*` می‌گیرد:
> - `orders`: قیمت‌گذاری، ردِ سفارش، ابطالِ پیش‌فاکتور.
> - `payments`: تأیید و ردِ فیش. قبلاً از منوی `/admin-orders` هم ممکن بود؛ حالا فقط با `payments`.
> - `disputes`، `deals` و `kyc` برای اکشن‌های همان بخش.
>
> ساخت و ویرایشِ کاربر و تغییرِ نقش یا دسترسی از این به بعد فقط admin است. admin تحت تأثیر نیست؛ `/admin-users` از قبل فرم‌ها را فقط به admin نشان می‌داد.

---

## نتایجِ بررسی‌ها

این جدول‌ها نتیجه‌ی اجرای تسکِ ۵ هستند. در مرحله‌ی بسته‌بندی هیچ‌کدام دوباره اجرا نشد؛ فقط hash، تعدادِ خط و زمانِ ویرایشِ فایل‌ها با مقدارِ ثبت‌شده مقایسه شد (یکی بود).

### اجرا شد ✅

| بررسی | نتیجه |
|---|---|
| `npx tsc --noEmit` | exit 0 |
| `npm run build` | exit 0 — خروجیِ ذخیره‌شده با `next build exit: 0` تمام می‌شود. اسکنِ ایستای کد نشان می‌داد build به DB نمی‌زند؛ ترافیکِ شبکه مانیتور نشد |
| inventory با awk روی ۹۳ اکشنِ exportشده‌ی `admin-*` | هیچ‌کدام بدونِ مارکرِ authz نیست. کنترلِ مثبت: با regexِ بی‌اثر هر ۹۳ تا گزارش شدند. این چک فقط وجودِ مارکر را می‌گیرد، نه درستیِ منطق |
| ESLint روی ۹ فایلِ تغییرکرده | اکشن‌ها، صفحه‌ی disputes و `errorCodes.ts` تمیزند. خطاهای باقی‌مانده قدیمی‌اند (`any`، importِ بی‌استفاده، `Date.now` در render)؛ baselineِ git وجود ندارد که مقایسه شود |
| هم‌خوانیِ زمانی | همه‌ی فایل‌های `src` از آخرین `tsc` و build قدیمی‌ترند؛ پس نتیجه‌ی آن‌ها حالتِ نهاییِ `src` را پوشش می‌دهد |

### اجرا نشد ❌ (با دلیل — صادقانه)

| بررسی | چرا اجرا نشد |
|---|---|
| e2e (Playwright) | specها به یک سرورِ زنده‌ی راه‌دور می‌زنند و specهای race روی رکوردِ واقعی تغییر می‌دهند (فقط با `E2E_UNSAFE_RACE_MUTATIONS`). از روی خواندن: specهای ادمین با نقشِ admin کار می‌کنند و admin همیشه از گیت عبور می‌کند؛ هیچ specای به `confirmedById`، `adjustedById` یا `finalPrice` تکیه ندارد |
| تستِ runtime (login واقعی، POSTِ مستقیم با نقشِ staff) | انجام نشد؛ همه‌چیز از روی کد بررسی شد. **پیش از اتکا:** روی staging با یک کاربرِ staffِ بدونِ دسترسی هر اکشن را یک‌بار صدا بزن و `A-SECTION-*` یا `A-ROLE-*` را ببین |
| بررسیِ DBِ زنده (ردیف‌های `Permission`، کاربران و نقش‌ها) | کاربر لازم ندانست و خودش جدا چک می‌کند (تصمیمِ ۷) |
| `tsc` و build بعد از ویرایشِ comment در `tests/race-order-status.spec.ts` | فایل در محدوده‌ی `tsconfig` است (`**/*.ts`)، ولی ویرایش بعد از آخرین `tsc` و build و فقط comment داخلِ بلوکِ JSDocِ ابتدای فایل بود (خط‌های ۱۰ تا ۱۳)؛ دوباره اجرا نشد |
| تست‌های واحد | در تسکِ ۵ اجرا نشد. grep نشان داد هیچ تستِ واحدی به این فایل‌ها یا `errorCodes` اشاره نمی‌کند |
| تستِ جدید | اضافه نشد (خارج از محدوده‌ی تکلیف) |

> **نتیجه:** گیتِ ۱۹ اکشن بسته شد و `tsc` و `next build` سبزند. رفتارِ runtime (نقشِ staffِ واقعی، ردیف‌های `Permission`) در این محیط اجرا نشده است؛ پیش از اتکا آن را دستی تأیید کن.

---

## بسته‌بندی

آرشیوِ `ADMIN-ORDERS-SECURITY-GATE.tar.gz` فقط شاملِ **۱۰ فایلِ تغییرکننده‌ی این کار + همین گزارش** است (۱۱ فایل، به‌همراه ۹ ورودیِ پوشه؛ جمعاً ۲۰ عضو). مسیرها نسبت به ریشه‌ی پروژه‌اند (`./src/...`)؛ extract در ریشه آن ۱۰ فایل را بازنویسی می‌کند و گزارش را هم کنارشان می‌گذارد. **مستثنی:** فایل‌های `.env*`، `node_modules/`، `.next/`، `tsconfig.tsbuildinfo`، `package.json` و `package-lock.json` (جزوِ این کار نیستند)، `.recover/`، تغییراتِ نامرتبط، NOTES و آرشیوهای قبلی. مانیفستِ جدا در آرشیو نیست؛ فهرستِ فایل‌ها همین‌جاست.

**درباره‌ی git:** این فایل‌ها (مثلِ کلِ `src/app/admin-*`) در git untracked هستند، پس `git diff` تغییراتشان را نشان نمی‌دهد و baselineِ ریپو فقط یک «Initial commit» است. آرشیو نسخه‌ی مرجع است.

اثرانگشتِ فایل‌ها (هشت نویسه‌ی اولِ SHA-256، و تعدادِ خط):

| فایل | SHA-256 | خط |
|---|---|---|
| `src/lib/errorCodes.ts` | `00b9c3e9` | ۲۰۸ |
| `src/app/admin-orders/actions.ts` | `269793d0` | ۳۲۶ |
| `src/app/admin-orders/page.tsx` | `fc64cc60` | ۲۲۷ |
| `src/app/admin-deals/actions.ts` | `809bc454` | ۴۸۴ |
| `src/app/admin-deals/page.tsx` | `d4ecf574` | ۸۲۶ (CRLF) |
| `src/app/admin-users/actions.ts` | `89def1b6` | ۲۴۷ |
| `src/app/admin-users/page.tsx` | `c99a17f7` | ۴۱۶ |
| `src/app/admin-disputes/actions.ts` | `029b467c` | ۲۷۸ |
| `src/app/admin-disputes/page.tsx` | `3d7ec74e` | ۱۲۰ |
| `tests/race-order-status.spec.ts` | `5bac35a4` | ۲۷۵ |

هیچ commit/push انجام نشد. SHA-256 در فایلِ sidecar کنارِ آرشیو است.
