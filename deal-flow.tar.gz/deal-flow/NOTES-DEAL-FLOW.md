# یادداشت‌های پیاده‌سازی — جریان Deal (بررسی دستی)

تاریخ: ۱۳۹۵/۰۹/۲۴ (2026-09-15) · مدل: Opus 4.8
این فایل همراه با `deal-flow.tar.gz` است. آرشیو شامل **۹ فایل** (تغییریافته/جدید) در هر ۴ برش + همین یادداشت است.
مسیر ریشه‌ی کد: `D:\documents\Sina Radman Kavir\IMPORT FILES\WEB 2 - AnbarPolymer\aaaa\work-src`

---

## ۰) خلاصه‌ی وضعیت: آماده، با دو اصلاح که من انجام دادم
چهار برش موازی نوشته شدند و من **محتوای واقعی فایل‌ها را خواندم** (نه گزارش خودخوانده‌ی ایجنت‌ها) و به‌صورت central reconcile کردم. دو مورد را خودم اصلاح/حذف کردم:
1. **باگ دایالکت SQL** (SQLite → Postgres) — زیر توضیح داده شده.
2. **رفع TOCTOU در رزرو آگهی** (`market/actions.ts`) — دقیقاً سؤالی که پرسیدید، زیر بخش ۴.

---

## ۱) برش‌ها و فایل‌ها (۹ فایل)
| برش | فایل | نوع |
|---|---|---|
| A — ساخت پیشنهاد | `src/app/market/actions.ts` | جدید |
| A | `src/components/SupplyTableRow.tsx` | ویرایش (دکمه‌ی «پیشنهاد خرید») |
| B — پنل من | `src/app/my-deals/actions.ts` | جدید (۵ اکشن) |
| B | `src/app/my-deals/page.tsx` | ویرایش (بخش «پیشنهادهای دریافتی») |
| B | `src/app/my-deals/[id]/page.tsx` | ویرایش (رسید/مغایرت/لغو) |
| C — پنل ادمین | `src/app/admin-deals/actions.ts` | ویرایش (+۲ اکشن) |
| C | `src/app/admin-deals/page.tsx` | ویرایش (۳ صف جدید) |
| D — داده | `prisma/schema.prisma` | ویرایش (+۱ فیلد) |
| D | `src/lib/dealDeadlines.ts` | ویرایش (+تابع enforcement، سِت کردن مهلت) |

### اکشن‌های سرور جدید
- `market/actions.ts` → `createDealFromListingAction(formData)`
- `my-deals/actions.ts` → `acceptDealOfferAction(dealId)`, `rejectDealOfferAction(dealId)`, `uploadDealPaymentReceiptAction(formData)`, `reportDiscrepancyAction(formData)`, `cancelDealAction(formData)`
- `admin-deals/actions.ts` → `markSellerFeePaidAction(formData)`, `rejectDealPaymentAction(formData)` (سایر اکشن‌های قبلی دست‌نخورده)

### فیلدهای دیتابیس
- `Deal.sellerFeeDeadline DateTime?` اضافه شد (nullable، صرفاً افزودنی).
- هیچ جدول/رلییشن جدیدی ساخته نشد.

---

## ۲) تصمیمات پذیرفته‌شده (که در کد منعکس است)
- **بدون کانتراُفر:** فروشنده فقط می‌پذیرد یا رد می‌کند.
- **مهلت کارمزد فروشنده روی خود Deal** شروع می‌شود وقتی وضعیت به `confirmed` رسید (نه زمان رزرو). در حالت `awaiting_approval` مقدار `null` می‌ماند و بعداً با تأیید مدیر ست می‌شود.
-Deal‌هایی **بدون** `materialListingId` هم در جریان مشارکت دارند (مهلت روی خود Deal است).
- خریدار رسید را فقط در وضعیت‌های `confirmed` یا `seller_fee_paid` آپلود می‌کند.
- لغو دستی فقط پیش از `loading` (مجموعهٔ `draft/awaiting_approval/confirmed/seller_fee_paid`).

---

## ۳) ⚠️ باگ دایالکت SQL — کشف و اصلاح شد (نیاز به اقدام شما ندارد، فقط بدانید)
پلن فرض را روی **SQLite** گذاشته بود، ولی پروژه **PostgreSQL** است:
- `prisma/schema.prisma` خط ۶: `provider = "postgresql"`
- `.env`: `DATABASE_URL="postgresql://..."`

ایجنتِ برشِ داده دو فایل ساخت که هر دو SQLite بودند:
- `ALTER TABLE "Deal" ADD COLUMN "sellerFeeDeadline" DATETIME;` — و `DATETIME` در Postgres یک نوع معتبر **نیست** (Prisma نوع `DateTime` را به `TIMESTAMP(3)` نگاشت می‌کند). این migration هنگام apply شکست می‌خورد.
- کل پوشه‌ی `prisma/migrations/20260915134259_add_seller_fee_deadline_to_deal/` را **حذف کردم**.

**چرا اصلاً migration دستی لازم نبود:** پروژه **workflow نسخه‌بندی‌شده‌ی migration ندارد** — پوشهٔ `prisma/migrations/` خالی است و `migration_lock.toml` وجود ندارد، یعنی از **`prisma db push`** استفاده می‌کند. `db push` مستقیماً schema را با DB دیف می‌کند و هیچ `migration.sql` اجرا نمی‌کند. پس فیلد schema (که دایالکت‌مستقل است) درست است و مسیرِ درست همین `db push` است (بخش ۵).

---

## ۴) ⚠️ پاسخ سؤال شما: الگوی رفع race condition
**سؤال:** آیا دقیقاً همان الگوی `updateMany` + شرط `validityStatus:'active'` در `where` پیاده شده بود؟
**پاسخ صادقانه: خیر، پیاده نشده بود** — و ادعای «✓ race-safe» که در گزارش قبلی‌ام نوشته بودم **بیش‌ازحد خوش‌بینانه بود و پس گرفته می‌شود.**

چیزی که ایجنت نوشته بود این بود (الگوی check-then-act / TOCTOU):
```ts
const listing = await tx.materialListing.findUnique({ where: { id } })
if (!listing || listing.validityStatus !== 'active') throw ...   // خواندن
await tx.materialListing.update({ where: { id }, data: { validityStatus: 'reserved' } })  // نوشتن بدون شرط
```
خواندنِ `findUnique` در یک تراکنش، نوشتنِ `update` را **اتمیک** نمی‌کند. زیر ایزولاسیون پیش‌فرض Postgres (READ COMMITTED) دو تراکنش همزمان می‌توانند هر دو `active` ببینند و هر دو آگهی را رزرو کنند.

**الان اصلاحش کردم** به همان الگویی که خواسته بودید — شرط را داخل `WHERE` خودِ `UPDATE` بردم تا row-lock پستگرس آن را ببندد:
```ts
const reserved = await tx.materialListing.updateMany({
  where: { id: materialListingId, validityStatus: 'active' },
  data: { validityStatus: 'reserved' },
})
if (reserved.count === 0) {
  throw new Error('این آگهی دیگر در دسترس نیست یا رزرو شده است.')
}
```
نکته برای بررسی شما: چک `findUnique` بالای آن را **نگه داشتم** ولی نقشش الان فقط fast-path/پیام‌رسانی است؛ چیزی که واقعاً race را می‌بندد همین `count` روی `updateMany` است. اگر ترجیح می‌دهید `findUnique` حذف و فقط روی شرط WHERE تکیه شود، بگویید تا تمیزترش کنم.

---

## ۵) Runbook (از ریشهٔ واقعی app اجرا کنید؛ من نزدم — به DB/بیلد دست می‌زند)
```bash
npx prisma db push     # فیلد sellerFeeDeadline را روی Postgres اعمال می‌کند
npx prisma generate    # کلاینت را بازتولید می‌کند تا ارجاع admin-deals typecheck شود
npm run build          # تنها گیت باقی‌مانده: هر mismatch تایپ/ایمپورت بین‌فایلی
```
- فایل `package.json` داخل `work-src` یک **استاب** است (فقط `dependencies: @sentry/nextjs, @tanstack/react-table, echarts, lucide-react, zod`؛ بدون `scripts` و بدون `prisma`/`next`). پس `generate`/`db push`/`build` را از ریشه‌ی واقعی پروژه‌تان اجرا کنید، نه از `work-src`.
- اگر می‌خواهید تغییر را نسخه‌بندی کنید: `npx prisma migrate dev --name add_seller_fee_deadline_to_deal` (SQL درست `TIMESTAMP(3)` را خودش از schema می‌سازد) — ولی توجه کنید پروژه تا الان migration نسخه‌بندی‌شده نداشته.

---

## ۶) نکات باز برای تصمیم شما (باگ نیستند)
1. **فیلد `notes` در `Deal` جایی برای ذخیره ندارد**؛ در `createDealFromListingAction` خوانده ولی دور ریخته می‌شود (`void notes`). اگر لازم است، نیاز به فیلد جدید دارد.
2. **`agreedPrice` تخمین زده شد** (بدون فیلد auction روی `MaterialListing`): `offerPriceToman ?? askingPriceToman`. اگر منطق مزایده واقعاً لازم است، باید جدا اضافه شود.
3. **`quantity` روی Deal رشتهٔ نمایشی است** (`"${listing.quantityTon} تن"`). اگر فرم مقدار رشته‌ای می‌فرستد، همان برنده است.
4. **لغو توسط فروشنده:** اکشن `cancelDealAction` سمت سرور هر دو طرف را مجاز می‌داند، ولی صفحهٔ `my-deals/[id]` فقط Dealهای `buyerId === user` را لود می‌کند — یعنی فروشنده از این صفحه به دکمهٔ لغو نمی‌رسد. اگر خواستید، یک UI برای لغوی فروشنده لازم است (نه یک باگ).
5. **`sellerFeeDeadline` در `admin-deals/page.tsx`** قبل از `generate` به‌صورت type خطا نشان می‌دهد؛ بعد از `db push + generate` برطرف می‌شود.

---

## ۷) آنچه از بایت‌های واقعی تأیید شد
- `dealDeadlines.ts` خط ۶۹: تابع جدید `enforceDealSellerFeeDeadlines` وجود دارد؛ تابع خصوصی قبلی `enforceSellerFeeDeadlines` (خط ۱۱۲، روی `MaterialListing`) **دست‌نخورده** — بدون تداخل نام.
- `enforceDealDeadlines` (خط ۵۳) تابع جدید را صدا می‌زند و شمارش را در `cancelledCount` جمع می‌کند؛ بقیهٔ فراخوانی‌ها حفظ شده.
- `startBuyerPaymentDeadline` (خط ۳۱۳): فقط در `confirmed` مقدار `sellerFeeDeadline` ست می‌شود؛ منطق `buyerConfirmDeadline` تغییر نکرده.
- `my-deals/actions.ts`: طرفین از روی رکورد سمت سرور تشخیص داده می‌شوند (خریدار=`deal.buyerId`، فروشنده=`deal.materialListing.userId`) و به UI اطمینان نمی‌شود.
- کامنت‌های فارسی در ابزار ترمینال به‌صورت mojibake دیده می‌شوند، ولی بایت‌های روی دیسک UTF-8 سالم‌اند (ویرایش‌ها روی زیررشتهٔ ASCII لنگر شده بودند تا کامنت‌های موجود دست‌نخورده بمانند). در ادیتور خودتان رندر را تأیید کنید.
