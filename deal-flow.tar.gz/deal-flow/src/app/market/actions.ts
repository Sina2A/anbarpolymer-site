'use server'

import prisma from '@/lib/prisma'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import { getCurrentUser } from '@/lib/currentUser'
import { requireCompanyVerifiedFor } from '@/lib/kyc'
import { isUserRestricted, startSellerFeeDeadline } from '@/lib/dealDeadlines'
import { logAudit } from '@/lib/logger'

export async function createDealFromListingAction(formData: FormData) {
  const materialListingId = String(formData.get('materialListingId') || '').trim()
  const quantity = String(formData.get('quantity') || '').trim()
  const offerPriceRaw = String(formData.get('offerPriceToman') || '').trim()
  const notes = String(formData.get('notes') || '').trim()

  if (!materialListingId) throw new Error('آگهی انتخاب نشده است.')

  const user = await getCurrentUser()
  await requireCompanyVerifiedFor(user.id, 'U-KYC1-DEAL')

  const restriction = await isUserRestricted(user.id)
  if (restriction.restricted) throw new Error(restriction.reason || 'حساب کاربری شما موقتاً محدود شده است.')

  const offerPrice = offerPriceRaw ? Number(offerPriceRaw) : null
  const deal = await prisma.$transaction(async (tx) => {
    const listing = await tx.materialListing.findUnique({ where: { id: materialListingId } })
    if (!listing || listing.validityStatus !== 'active') {
      throw new Error('این آگهی دیگر در دسترس نیست یا رزرو شده است.')
    }
    if (listing.userId === user.id) throw new Error('خرید از آگهی خودتان امکان‌پذیر نیست.')

    const agreedPrice = offerPrice !== null && Number.isFinite(offerPrice)
      ? offerPrice
      : listing.askingPriceToman ?? null

    // رزرو اتمیک: شرط validityStatus:'active' داخل WHERE. اگر تراکنش همزمانی
    // زودتر آگهی را reserved کرده باشد، count صفر می‌شود و اینDeal ساخته نمی‌شود.
    // (تحت isolation پیش‌فرض Postgres یعنی READ COMMITTED، تنها همین شرطِ داخل
    //  UPDATE است که race را می‌بندد؛ چکِ findUnique بالاتر فقط fast-path است.)
    const reserved = await tx.materialListing.updateMany({
      where: { id: materialListingId, validityStatus: 'active' },
      data: { validityStatus: 'reserved' },
    })
    if (reserved.count === 0) {
      throw new Error('این آگهی دیگر در دسترس نیست یا رزرو شده است.')
    }

    return tx.deal.create({
      data: {
        buyerId: user.id,
        materialListingId,
        quantity: quantity || `${listing.quantityTon} تن`,
        agreedPrice,
        status: 'draft',
      },
    })
  })

  void notes
  await startSellerFeeDeadline(materialListingId)
  await logAudit('deal', 'پیشنهاد خرید جدید', user.id, { dealId: deal.id })
  revalidatePath('/my-deals')
  redirect('/my-deals')
}
