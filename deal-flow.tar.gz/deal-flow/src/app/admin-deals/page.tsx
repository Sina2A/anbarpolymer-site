import prisma from '@/lib/prisma'
import { getAllSectionAccess } from '@/lib/permissions'
import { getCurrentUser } from '@/lib/currentUser'
import { enforceDealDeadlines, getDealRuleSettings } from '@/lib/dealDeadlines'
import { listHolidays } from '@/lib/holidays'
import { getServerClockDriftMs } from '@/lib/onlineTime'
import { DEADLINE_FIELD_LABELS } from '@/lib/deadlineAdjustments'
import AdminNav from '@/components/AdminNav'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'
import RefundPolicyHint from '@/components/RefundPolicyHint'
import { confirmFundsSecured, confirmFundsReleased, addHolidayAction, removeHolidayAction, adjustDeadlineAction, importHolidaysAction, updateDealRulesAction, updateDealPaymentInstructionsAction, approveDealAction, markSellerFeePaidAction, rejectDealPaymentAction } from './actions'
import { pageStyle, pageWrapStyle, contentStyle, h1Style, subTitleStyle, cardStyle, tableStyle, theadRowStyle, thStyle, tdStyle, badgeStyle, btnPrimaryStyle, btnSecondaryStyle, btnDangerStyle, btnSmallStyle, inputStyle, selectStyle, labelStyle, emptyStateStyle } from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

const STATUS_LABELS: Record<string, string> = {
  draft: 'پیش‌نویس', confirmed: 'تایید شد', awaiting_approval: 'در انتظار تایید مدیر', payment_secured: 'وجه تضمین شد',
  loading: 'در حال بارگیری', in_transit: 'در مسیر ارسال', delivered: 'تحویل شد', settled: 'تسویه شد',
}
const CONFIRMATION_TYPE_LABELS: Record<string, string> = {
  loading: 'تایید بارگیری', unloading: 'تایید تخلیه', driver_confirm: 'تاییدیه راننده', buyer_confirm: 'تاییدیه خریدار',
}
const VERDICT_LABELS: Record<string, { label: string; color: string }> = {
  auto_no_discrepancy: { label: '✅ بدون مغایرت (خودکار)', color: '#146c3a' },
  discrepancy_minor: { label: '⚠️ مغایرت جزئی — فقط ثبت شد', color: '#92400e' },
  discrepancy_severe: { label: '🔴 مغایرت حساس — واریز متوقف شد', color: '#9b1c1c' },
}
const CHECKLIST_LABELS: Record<string, string> = {
  packagingIntact: 'بسته‌بندی سالم', quantityMatches: 'تعداد مطابق سفارش', palletsIntact: 'پالت‌ها سالم',
  productMatchesOrder: 'محصول مطابق سفارش', discrepancyObserved: 'مغایرت مشاهده شد',
  noTransitDamage: 'بدون آسیب حمل', productReceived: 'محصول دریافت شد', discrepancyExists: 'مغایرت وجود دارد',
}

export default async function AdminDealsPage({ searchParams }: { searchParams: Promise<{ imported?: string; skipped?: string }> }) {
  const currentUser = await getCurrentUser()
  const sp = await searchParams
  const importResult = sp.imported !== undefined ? { added: Number(sp.imported) || 0, skipped: Number(sp.skipped) || 0 } : null

  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)

  // چون هنوز cron جدا نداریم، هر بار این صفحه لود می‌شه، اول چک می‌کنه
  // آیا مهلت کارمزد فروشنده، پرداخت خریدار، یا بررسی کیفیت برای کسی گذشته —
  // اگه آره، خودکار لغو/تسویه + جریمه‌ی موقت (در مورد اولی) اعمال می‌شه.
  const { cancelledCount, qualityAutoAcceptedCount } = await enforceDealDeadlines()

  const deals = await prisma.deal.findMany({
    include: { buyer: true, confirmations: { orderBy: { confirmedAt: 'asc' } } },
    orderBy: { createdAt: 'desc' },
  })

  const holidays = isAdmin ? await listHolidays() : []
  const dealRules = isAdmin ? await getDealRuleSettings() : null
  const clockDriftMs = isAdmin ? await getServerClockDriftMs() : null

  const allAdjustments = await prisma.deadlineAdjustment.findMany({
    where: { dealId: { in: deals.map((d) => d.id) } },
    orderBy: { createdAt: 'asc' },
    include: { adjustedBy: true },
  })
  const adjustmentsByDeal = new Map<string, typeof allAdjustments>()
  for (const adj of allAdjustments) {
    const list = adjustmentsByDeal.get(adj.dealId) || []
    list.push(adj)
    adjustmentsByDeal.set(adj.dealId, list)
  }

  // صف‌های اقدام مدیر/کارشناس — از همون لیست deals فیلتر می‌شن (کوئری اضافه نمی‌زنیم)
  const awaitingApprovalDeals = deals.filter((d) => d.status === 'awaiting_approval')
  const awaitingPaymentDeals = deals.filter(
    (d) => !!d.paymentReceiptUrl && d.escrowStatus === 'pending' && (d.status === 'confirmed' || d.status === 'seller_fee_paid')
  )
  const sellerFeeDeals = deals.filter((d) => d.status === 'confirmed')

  return (
    <div style={pageStyle}>
      <div style={pageWrapStyle}>
        <AdminNav currentUserName={currentUser.companyName} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="deals" />

        <div style={contentStyle}>
          <h1 style={h1Style}>معاملات تجاری</h1>
          <p style={subTitleStyle}>
            این جدا از سفارش‌های مستقیم فروشگاهه — اینجا یه کارخانه‌ی دیگه می‌فروشه، انبار پلیمر فقط واسط وضعیته. هیچ تراکنش بانکی از این صفحه انجام نمی‌شه؛ فقط ثبت وضعیتیه که حسابداری بیرون از سایت انجام داده.
          </p>

          {cancelledCount > 0 && (
            <div style={{ background: '#fef3c7', color: '#92400e', borderRadius: 8, padding: '10px 16px', fontSize: 12.5, fontWeight: 600, marginBottom: 12 }}>
              ⏱ {cancelledCount} مورد به‌خاطر گذشتن مهلت (کارمزد یا پرداخت)، همین الان خودکار لغو و آگهیش دوباره آزاد شد.
            </div>
          )}

          {qualityAutoAcceptedCount > 0 && (
            <div style={{ background: '#fde8e8', color: '#9b1c1c', borderRadius: 8, padding: '10px 16px', fontSize: 12.5, fontWeight: 600, marginBottom: 20 }}>
              🔴 {qualityAutoAcceptedCount} مورد به‌خاطر عدم اقدام خریدار ظرف مهلت، همین الان به‌صورت خودکار تایید و تسویه شد — نیاز به آزادسازی وجه دستی (پایین کارت هر معامله).
            </div>
          )}

          {isAdmin && clockDriftMs !== null && Math.abs(clockDriftMs) > 5 * 60 * 1000 && (
            <div style={{ background: '#fef3c7', color: '#92400e', borderRadius: 8, padding: '8px 16px', fontSize: 11.5, fontWeight: 600, marginBottom: 12 }}>
              🕐 ساعت سرور با ساعت آنلاین حدود {Math.round(Math.abs(clockDriftMs) / 60000)} دقیقه اختلاف داره — این می‌تونه محاسبه‌ی مهلت‌ها رو کمی نادقیق کنه. بهتره تنظیمات ساعت/منطقه‌زمانی سرور (Asia/Tehran) رو چک کنی.
            </div>
          )}

          {isAdmin && (
            <div style={{ ...cardStyle, marginBottom: 24, background: '#fafbfc' }}>
              <h3 style={{ fontSize: 14, fontWeight: 800, marginBottom: 6 }}>⏱ زمان‌بندی و مهلت‌های معامله</h3>
              <p style={{ fontSize: 11.5, color: '#6f7680', marginBottom: 14, lineHeight: 1.9 }}>
                این بخش دو تنظیم کاملاً جداست: <b>«تقویم کاری»</b> مشخص می‌کنه چه روزهایی سایت اصلاً کار حساب می‌شه (برای محاسبه‌ی دقیق مهلت‌ها، نه روز تقویمی خام)،
                و <b>«طول مهلت‌ها»</b> مشخص می‌کنه هر مرحله از معامله چند ساعت/روز کاری فرصت داره. هردو روی محاسبه‌ی مهلت هر معامله اثر می‌ذارن — تقویم می‌گه «کِی»، طول مهلت می‌گه «چقدر».
              </p>

              <details style={{ border: '1px solid #e5e7eb', borderRadius: 10, padding: '10px 16px', marginBottom: 12, background: '#fff' }}>
                <summary style={{ cursor: 'pointer', fontSize: 12.5, fontWeight: 700 }}>📅 تقویم کاری — تعطیلات رسمی</summary>
                <p style={{ fontSize: 11.5, color: '#6f7680', margin: '10px 0' }}>
                  این‌جا فقط تعیین می‌کنه <b>«چه روزهایی سایت تعطیله»</b> — روی محاسبه‌ی همه‌ی مهلت‌های زیر اثر می‌ذاره (نه فقط یکی).
                  جمعه‌ها خودکار حساب می‌شن، لازم نیست اضافه بشن. فقط تعطیلات رسمی/عمومی دیگه رو اینجا اضافه کن.
                </p>

                {importResult && (
                  <div style={{ background: '#eaf6ee', color: '#146c3a', borderRadius: 8, padding: '8px 12px', fontSize: 12, marginBottom: 12, fontWeight: 600 }}>
                    ✓ {importResult.added} تعطیلی از فایل اضافه شد.
                    {importResult.skipped > 0 && ` (${importResult.skipped} خط قابل‌خوندن نبود و رد شد.)`}
                  </div>
                )}

                <form action={addHolidayAction} style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 14 }}>
                  <input type="date" name="date" required style={holidayInputStyle} />
                  <input type="text" name="title" placeholder="عنوان (اختیاری، مثلاً عید فطر)" style={{ ...holidayInputStyle, flex: 1, minWidth: 160 }} />
                  <button type="submit" style={btnPrimaryStyle}>افزودن</button>
                </form>

                <form action={importHolidaysAction} style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center', marginBottom: 16, borderTop: '1px dashed #e5e7eb', paddingTop: 12 }}>
                  <input type="file" name="csvFile" accept=".csv,text/csv" required style={{ fontSize: 11.5 }} />
                  <button type="submit" style={btnSecondaryStyle}>وارد کردن فایل CSV</button>
                  <span style={{ fontSize: 10.5, color: '#9199a3', width: '100%' }}>
                    فرمت هر خط: <code>تاریخ,عنوان</code> — تاریخ می‌تونه شمسی («۱۴۰۵/۰۱/۰۱») یا میلادی باشه، عنوان اختیاریه.
                  </span>
                </form>

                {holidays.length === 0 ? (
                  <div style={{ fontSize: 11.5, color: '#9199a3' }}>هنوز هیچ تعطیلی ثبت نشده.</div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                    {holidays.map((h) => (
                      <div key={h.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: 12, borderBottom: '1px dashed #e5e7eb', paddingBottom: 6 }}>
                        <span>{new Date(h.date).toLocaleDateString('fa-IR')} {h.title && `— ${h.title}`}</span>
                        <form action={removeHolidayAction}>
                          <input type="hidden" name="id" value={h.id} />
                          <button type="submit" style={{ background: 'none', border: 'none', color: '#9b1c1c', fontSize: 11.5, cursor: 'pointer' }}>حذف</button>
                        </form>
                      </div>
                    ))}
                  </div>
                )}
              </details>

              <div style={{ fontSize: 11, color: '#9199a3', margin: '10px 0' }}>
                🕐 ساعات کاری هفتگی (روزهای عادی هفته، نه تعطیلات خاص) توی صفحه‌ی <a href="/admin-users" style={{ color: '#1e357b', fontWeight: 700 }}>مدیریت کاربران و دسترسی‌ها</a> تنظیم می‌شه.
              </div>

              {dealRules && (
                <details open style={{ border: '1px solid #e5e7eb', borderRadius: 10, padding: '10px 16px', background: '#fff' }}>
                  <summary style={{ cursor: 'pointer', fontSize: 12.5, fontWeight: 700 }}>⏳ طول مهلت‌ها — چند ساعت/روز فرصت هر مرحله باشه</summary>
                  <p style={{ fontSize: 11.5, color: '#6f7680', margin: '10px 0 14px' }}>
                    این‌جا تعیین می‌کنه <b>«چقدر»</b> فرصت هر مرحله باشه — واحدها ساعتِ کاری (طبق تقویم بالا)، به‌جز سکوت راننده که تقویمیه.
                    تغییر هرکدوم، فقط روی معاملات بعدی اثر می‌ذاره؛ معاملات در جریان با همون مهلتی که موقع شروعشون محاسبه شده ادامه پیدا می‌کنن.
                  </p>
                  <form action={updateDealRulesAction} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                    <RuleRow name="sellerFeeHours" label="مهلت پرداخت کارمزد فروشنده" unit="ساعت کاری" defaultValue={dealRules.sellerFeeHours}
                      hint="از لحظه‌ای که ادمین رزرو رو تایید می‌کنه، فروشنده چند ساعت کاری وقت داره کارمزد رو بپردازه؟ بعد از این مهلت، آگهی به‌جای بازگشت خودکار، می‌ره تو حالت «نیازمند بررسی مجدد»." />
                    <RuleRow name="buyerPaymentHours" label="مهلت پرداخت کامل خریدار" unit="ساعت کاری" defaultValue={dealRules.buyerPaymentHours}
                      hint="از لحظه‌ای که فروشنده کارمزدش رو پرداخت می‌کنه، خریدار چند ساعت کاری وقت داره باقی مبلغ رو کامل بپردازه؟" />
                    <RuleRow name="discrepancyReportHours" label="مهلت گزارش مغایرت خریدار" unit="ساعت کاری" defaultValue={dealRules.discrepancyReportHours}
                      hint="از لحظه‌ی تخلیه‌ی بار، خریدار چند ساعت کاری وقت داره اگه مشکلی توی بار دید، گزارش کنه؟ بعدش خودکار «بدون مغایرت» ثبت می‌شه." />
                    <RuleRow name="fundReleaseHours" label="مهلت آماده‌شدن واریز وجه" unit="ساعت کاری" defaultValue={dealRules.fundReleaseHours}
                      hint="از لحظه‌ی تخلیه‌ی بار، بعد از چند ساعت کاری وجه فروشنده آماده‌ی آزادسازی می‌شه؟ (به‌شرطی که مغایرت حساسی گزارش نشده باشه — آزادسازی واقعی همیشه با کلیک دستی مدیره)" />
                    <RuleRow name="driverSilenceDays" label="آستانه‌ی هشدار سکوت راننده" unit="روز تقویمی" defaultValue={dealRules.driverSilenceDays}
                      hint="بعد از بارگیری، اگه راننده چند روز تقویمی (نه کاری، چون جاده تعطیلی نمی‌شناسه) هیچ رویدادی ثبت نکنه، پرچم هشدار قرمز فسفری بخوره؟" />
                    <RuleRow name="proformaConfirmHours" label="مهلت تایید پیش‌فاکتور توسط مشتری" unit="ساعت کاری" defaultValue={dealRules.proformaConfirmHours}
                      hint="از لحظه‌ای که کارشناس فروش قیمت نهایی سفارش رو ثبت می‌کنه، مشتری چند ساعت کاری وقت داره پیش‌فاکتور رو تایید کنه؟ بعد از این مهلت، سفارش خودکار باطل می‌شه و موجودی به انبار برمی‌گرده." />

                    <input type="hidden" name="updatedById" value={currentUser.id} />
                    <ConfirmSubmitButton
                      message="این تغییر روی همه‌ی معاملات بعدی اثر می‌ذاره. مطمئنی؟"
                      style={{ ...btnPrimaryStyle, alignSelf: 'flex-start', padding: '8px 22px', marginTop: 4 }}
                    >
                      ذخیره‌ی تغییرات
                    </ConfirmSubmitButton>
                  </form>
                </details>
              )}
            </div>
          )}

          {/* ---------- صف: در انتظار تایید ---------- */}
          <div style={{ ...cardStyle, marginBottom: 20 }}>
            <h3 style={{ fontSize: 14, fontWeight: 800, marginBottom: 4 }}>در انتظار تایید</h3>
            <p style={{ fontSize: 11.5, color: '#6f7680', marginBottom: 12 }}>معاملاتی که منتظر تایید مدیر هستن؛ با تایید، مهلت پرداخت خریدار شروع می‌شه.</p>
            {awaitingApprovalDeals.length === 0 ? (
              <div style={emptyStateStyle}>موردی در انتظار تایید نیست.</div>
            ) : (
              <table style={tableStyle}>
                <thead>
                  <tr style={theadRowStyle}>
                    <th style={thStyle}>شناسه</th>
                    <th style={thStyle}>خریدار</th>
                    <th style={thStyle}>مقدار</th>
                    <th style={thStyle}>سطح تایید</th>
                    <th style={thStyle}>اقدام</th>
                  </tr>
                </thead>
                <tbody>
                  {awaitingApprovalDeals.map((deal) => (
                    <tr key={deal.id}>
                      <td style={tdStyle}>#{deal.id.slice(0, 8)}</td>
                      <td style={tdStyle}>{deal.buyer.companyName}</td>
                      <td style={tdStyle}>{deal.quantity}</td>
                      <td style={tdStyle}>{deal.approvalLevel || '—'}</td>
                      <td style={tdStyle}>
                        <form action={approveDealAction.bind(null, deal.id)}>
                          <ConfirmSubmitButton message="این معامله تایید بشه و مهلت پرداخت خریدار شروع بشه؟" style={{ ...btnPrimaryStyle, ...btnSmallStyle }}>
                            تایید
                          </ConfirmSubmitButton>
                        </form>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {/* ---------- صف: در انتظار تایید پرداخت ---------- */}
          <div style={{ ...cardStyle, marginBottom: 20 }}>
            <h3 style={{ fontSize: 14, fontWeight: 800, marginBottom: 4 }}>در انتظار تایید پرداخت</h3>
            <p style={{ fontSize: 11.5, color: '#6f7680', marginBottom: 12 }}>خریدار فیش پرداخت بارگذاری کرده و منتظر بررسی حسابداریه.</p>
            {awaitingPaymentDeals.length === 0 ? (
              <div style={emptyStateStyle}>فیش پرداختی در انتظار بررسی نیست.</div>
            ) : (
              <table style={tableStyle}>
                <thead>
                  <tr style={theadRowStyle}>
                    <th style={thStyle}>شناسه</th>
                    <th style={thStyle}>خریدار</th>
                    <th style={thStyle}>مقدار</th>
                    <th style={thStyle}>فیش</th>
                    <th style={thStyle}>اقدام</th>
                  </tr>
                </thead>
                <tbody>
                  {awaitingPaymentDeals.map((deal) => (
                    <tr key={deal.id}>
                      <td style={tdStyle}>#{deal.id.slice(0, 8)}</td>
                      <td style={tdStyle}>{deal.buyer.companyName}</td>
                      <td style={tdStyle}>{deal.quantity}</td>
                      <td style={tdStyle}>
                        {deal.paymentReceiptUrl ? (
                          <a href={deal.paymentReceiptUrl} target="_blank" rel="noreferrer" style={{ fontSize: 11.5, color: '#1e357b', fontWeight: 700 }}>مشاهده‌ی فیش ↗</a>
                        ) : '—'}
                      </td>
                      <td style={tdStyle}>
                        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                          <form action={confirmFundsSecured}>
                            <input type="hidden" name="dealId" value={deal.id} />
                            <input type="hidden" name="confirmedById" value={currentUser.id} />
                            <ConfirmSubmitButton message="⚠️ تایید می‌کنی وجه از خریدار واقعاً دریافت شده (بیرون از سایت)؟" style={{ ...btnPrimaryStyle, ...btnSmallStyle }}>
                              تایید
                            </ConfirmSubmitButton>
                          </form>
                          <form action={rejectDealPaymentAction}>
                            <input type="hidden" name="dealId" value={deal.id} />
                            <ConfirmSubmitButton message="فیش پرداخت رد بشه؟ خریدار باید دوباره بارگذاری کنه." style={{ ...btnDangerStyle, ...btnSmallStyle }}>
                              رد
                            </ConfirmSubmitButton>
                          </form>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {/* ---------- صف: کارمزد فروشنده ---------- */}
          <div style={{ ...cardStyle, marginBottom: 20 }}>
            <h3 style={{ fontSize: 14, fontWeight: 800, marginBottom: 4 }}>کارمزد فروشنده</h3>
            <p style={{ fontSize: 11.5, color: '#6f7680', marginBottom: 12 }}>معاملات تاییدشده‌ای که منتظر پرداخت کارمزد فروشنده‌ان.</p>
            {sellerFeeDeals.length === 0 ? (
              <div style={emptyStateStyle}>موردی در انتظار کارمزد فروشنده نیست.</div>
            ) : (
              <table style={tableStyle}>
                <thead>
                  <tr style={theadRowStyle}>
                    <th style={thStyle}>شناسه</th>
                    <th style={thStyle}>خریدار</th>
                    <th style={thStyle}>مقدار</th>
                    <th style={thStyle}>مهلت کارمزد</th>
                    <th style={thStyle}>اقدام</th>
                  </tr>
                </thead>
                <tbody>
                  {sellerFeeDeals.map((deal) => (
                    <tr key={deal.id}>
                      <td style={tdStyle}>#{deal.id.slice(0, 8)}</td>
                      <td style={tdStyle}>{deal.buyer.companyName}</td>
                      <td style={tdStyle}>{deal.quantity}</td>
                      <td style={tdStyle}>{deal.sellerFeeDeadline ? new Date(deal.sellerFeeDeadline).toLocaleString('fa-IR') : '—'}</td>
                      <td style={tdStyle}>
                        <form action={markSellerFeePaidAction}>
                          <input type="hidden" name="dealId" value={deal.id} />
                          <ConfirmSubmitButton message="تایید می‌کنی کارمزد فروشنده پرداخت شده؟" style={{ ...btnPrimaryStyle, ...btnSmallStyle }}>
                            تایید کارمزد
                          </ConfirmSubmitButton>
                        </form>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {deals.length === 0 && (
            <div style={emptyStateStyle}>هنوز هیچ معامله‌ای ثبت نشده.</div>
          )}

          {deals.map((deal) => {
            const now = Date.now()
            const fundReleaseDue = !!deal.fundReleaseDeadline && new Date(deal.fundReleaseDeadline).getTime() < now && !deal.fundReleaseFrozen && deal.escrowStatus !== 'released_manual'
            const isFlagged = fundReleaseDue || !!deal.driverSilenceFlaggedAt || deal.fundReleaseFrozen
            return (
            <div key={deal.id} style={isFlagged ? { ...cardStyle, border: '15px solid #ff2d55' } : cardStyle}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, flexWrap: 'wrap', gap: 8 }}>
                <div>
                  <b style={{ fontSize: 14 }}>#{deal.id.slice(0, 8)}</b>{' '}
                  <span style={{ fontSize: 12.5, color: '#6f7680' }}>— {deal.buyer.companyName} — {deal.quantity}</span>
                </div>
                <span style={badgeStyle('info')}>{STATUS_LABELS[deal.status] || deal.status}</span>
              </div>

              {deal.driverSilenceFlaggedAt && (
                <div style={{ background: '#fde8e8', color: '#9b1c1c', borderRadius: 8, padding: '8px 12px', fontSize: 12, fontWeight: 700, marginBottom: 10 }}>
                  🔴 راننده از لحظه‌ی بارگیری تا ۵ روز هیچ رویدادی ثبت نکرده — نیازمند پیگیری فوری کارشناس حمل‌ونقل.
                </div>
              )}
              {deal.fundReleaseFrozen && (
                <div style={{ background: '#fde8e8', color: '#9b1c1c', borderRadius: 8, padding: '8px 12px', fontSize: 12, fontWeight: 700, marginBottom: 10 }}>
                  🔴 مغایرت حساس گزارش شده — واریز وجه متوقف شد، منتظر تصمیم مدیر (بخش اختلافات).
                </div>
              )}
              {fundReleaseDue && (
                <div style={{ background: '#eaf3de', color: '#27500a', borderRadius: 8, padding: '8px 12px', fontSize: 12, fontWeight: 700, marginBottom: 10 }}>
                  ✓ مهلت ۸ساعته‌ی واریز به پایان رسیده و مغایرت حساسی گزارش نشده — آماده‌ی آزادسازی وجه فروشنده.
                </div>
              )}

              <div style={{ fontSize: 12.5, color: '#4f5560', marginBottom: 14 }}>
                قیمت توافقی: {deal.agreedPrice !== null && deal.agreedPrice !== undefined ? `${deal.agreedPrice.toLocaleString('fa-IR')} ریال` : '—'} &nbsp;|&nbsp; وضعیت وجه: <b style={escrowColor(deal.escrowStatus)}>{escrowLabel(deal.escrowStatus)}</b> <RefundPolicyHint />
              </div>

              {deal.confirmations.length > 0 && (
                <div style={{ marginBottom: 14 }}>
                  {deal.confirmations.map((c) => {
                    let checklist: Record<string, boolean> = {}
                    try { checklist = JSON.parse(c.checklistJson) } catch {}
                    return (
                      <div key={c.id} style={timelineRow}>
                        <div style={{ fontWeight: 700, fontSize: 12.5, marginBottom: 4 }}>{CONFIRMATION_TYPE_LABELS[c.type] || c.type}</div>
                        {c.finalVerdict && VERDICT_LABELS[c.finalVerdict] && (
                          <div style={{ ...metaLine, color: VERDICT_LABELS[c.finalVerdict].color, fontWeight: 700 }}>
                            {VERDICT_LABELS[c.finalVerdict].label}
                          </div>
                        )}
                        {c.driverName && <div style={metaLine}>راننده: {c.driverName} — {c.driverPhone} — پلاک {c.vehiclePlate}</div>}
                        {c.receiverName && <div style={metaLine}>تحویل‌گیرنده: {c.receiverName} ({c.receiverRole})</div>}
                        <div style={metaLine}>
                          {Object.entries(checklist).filter(([, v]) => v).map(([k]) => CHECKLIST_LABELS[k] || k).join(' · ') || 'بدون آیتم تیک‌خورده'}
                        </div>
                        {c.latitude && c.longitude && (
                          <div style={metaLine}>موقعیت ثبت‌شده: {c.latitude.toFixed(5)}, {c.longitude.toFixed(5)} (سیگنال کمکی، نه مدرک قطعی)</div>
                        )}
                        {c.photoUrl && (
                          <a href={c.photoUrl} target="_blank" rel="noreferrer" style={{ fontSize: 11.5, color: '#1e357b' }}>مشاهده‌ی عکس ↗</a>
                        )}
                        <div style={{ fontSize: 10.5, color: '#9199a3', marginTop: 4 }}>{new Date(c.confirmedAt).toLocaleString('fa-IR')}</div>
                      </div>
                    )
                  })}
                </div>
              )}

              {(deal.buyerConfirmDeadline || deal.discrepancyReportDeadline || deal.fundReleaseDeadline) && (
                <div style={{ marginBottom: 14, background: '#fafbfc', borderRadius: 8, padding: '10px 14px' }}>
                  {deal.buyerConfirmDeadline && (
                    <div style={{ fontSize: 12, marginBottom: 4 }}>مهلت پرداخت کامل خریدار: <b>{new Date(deal.buyerConfirmDeadline).toLocaleString('fa-IR')}</b></div>
                  )}
                  {deal.discrepancyReportDeadline && (
                    <div style={{ fontSize: 12, marginBottom: 4 }}>مهلت گزارش مغایرت: <b>{new Date(deal.discrepancyReportDeadline).toLocaleString('fa-IR')}</b></div>
                  )}
                  {deal.fundReleaseDeadline && (
                    <div style={{ fontSize: 12 }}>مهلت واریز وجه: <b>{new Date(deal.fundReleaseDeadline).toLocaleString('fa-IR')}</b></div>
                  )}

                  {(adjustmentsByDeal.get(deal.id) || []).length > 0 && (
                    <div style={{ marginTop: 8, borderTop: '1px dashed #e5e7eb', paddingTop: 8 }}>
                      {(adjustmentsByDeal.get(deal.id) || []).map((a) => (
                        <div key={a.id} style={{ fontSize: 11, color: '#6f7680', marginBottom: 3 }}>
                          🔧 {DEADLINE_FIELD_LABELS[a.field as keyof typeof DEADLINE_FIELD_LABELS] || a.field}{' '}
                          {a.hoursDelta > 0 ? `${a.hoursDelta} ساعت تمدید شد` : `${Math.abs(a.hoursDelta)} ساعت کوتاه شد`}{' '}
                          توسط {a.adjustedBy.companyName} — «{a.reason}» — {new Date(a.createdAt).toLocaleString('fa-IR')}
                        </div>
                      ))}
                    </div>
                  )}

                  {isAdmin && (
                    <form action={adjustDeadlineAction} style={{ display: 'flex', gap: 6, flexWrap: 'wrap', alignItems: 'center', marginTop: 10, borderTop: '1px dashed #e5e7eb', paddingTop: 10 }}>
                      <input type="hidden" name="dealId" value={deal.id} />
                      <input type="hidden" name="adjustedById" value={currentUser.id} />
                      <select name="field" style={holidayInputStyle} required>
                        {deal.buyerConfirmDeadline && <option value="buyerConfirmDeadline">مهلت پرداخت خریدار</option>}
                        {deal.discrepancyReportDeadline && <option value="discrepancyReportDeadline">مهلت گزارش مغایرت</option>}
                        {deal.fundReleaseDeadline && <option value="fundReleaseDeadline">مهلت واریز وجه</option>}
                      </select>
                      <input type="number" name="hours" placeholder="مثلاً 12 یا -6" required style={{ ...holidayInputStyle, width: 90 }} />
                      <input type="text" name="reason" placeholder="دلیل (اجباری)" required style={{ ...holidayInputStyle, flex: 1, minWidth: 140 }} />
                      <ConfirmSubmitButton
                        message="⚠️ این مهلت رو دستی تغییر می‌ده و توی تاریخچه ثبت می‌شه. مطمئنی؟"
                        style={btnSecondaryStyle}
                      >
                        اعمال تغییر
                      </ConfirmSubmitButton>
                    </form>
                  )}
                </div>
              )}

              {/* ---------- دستور پرداخت خریدار (متن آزاد کارشناس) ---------- */}
              <details style={payInstrBox}>
                <summary style={{ cursor: 'pointer', fontSize: 12.5, fontWeight: 700 }}>
                  💬 دستور پرداخت برای خریدار
                  {deal.paymentInstructionsText
                    ? <span style={payInstrSetTag}>ثبت شده</span>
                    : <span style={payInstrEmptyTag}>خالی</span>}
                </summary>
                <p style={{ fontSize: 11, color: '#6f7680', margin: '10px 0', lineHeight: 1.8 }}>
                  این متن عیناً (بدون تغییر) بالای گزینه‌های پرداخت، توی صفحه‌ی معامله‌ی خریدار نشون داده می‌شه.
                  هر فرمتی قابل قبوله — شماره‌حساب، شبا، یا پیام «تماس بگیرید». خالی بذاری، هیچ راهنمایی نشون داده نمی‌شه.
                </p>
                <form action={updateDealPaymentInstructionsAction}>
                  <input type="hidden" name="dealId" value={deal.id} />
                  <textarea
                    name="paymentInstructionsText"
                    rows={4}
                    defaultValue={deal.paymentInstructionsText || ''}
                    placeholder="مثلاً: مبلغ را به حساب … واریز و فیش را همین‌جا بارگذاری کنید. / یا: برای هماهنگی پرداخت با شماره … تماس بگیرید."
                    style={payInstrTextarea}
                  />
                  <ConfirmSubmitButton
                    message="این متن برای خریدارِ همین معامله نمایش داده می‌شه. ذخیره بشه؟"
                    style={{ ...btnPrimaryStyle, marginTop: 8 }}
                  >
                    ذخیره‌ی دستور پرداخت
                  </ConfirmSubmitButton>
                </form>
              </details>

              {/* ---------- دکمه‌های وضعیت وجه (دستی) ---------- */}
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', borderTop: '1px dashed #e5e7eb', paddingTop: 12 }}>
                {deal.escrowStatus === 'pending' && (
                  <form action={confirmFundsSecured}>
                    <input type="hidden" name="dealId" value={deal.id} />
                    <input type="hidden" name="confirmedById" value={currentUser.id} />
                    <ConfirmSubmitButton
                      message="⚠️ این یعنی حسابداری تایید می‌کنه وجه از خریدار واقعاً دریافت شده (بیرون از سایت). مطمئنی؟"
                      style={btnPrimaryStyle}
                    >
                      تایید دریافت وجه از خریدار
                    </ConfirmSubmitButton>
                  </form>
                )}
                {deal.escrowStatus === 'secured_manual' && (
                  <form action={confirmFundsReleased}>
                    <input type="hidden" name="dealId" value={deal.id} />
                    <input type="hidden" name="confirmedById" value={currentUser.id} />
                    <ConfirmSubmitButton
                      message="⚠️ این یعنی حسابداری تایید می‌کنه وجه واقعاً به فروشنده پرداخت شده (بیرون از سایت). مطمئنی؟"
                      style={btnDangerStyle}
                    >
                      تایید پرداخت به فروشنده
                    </ConfirmSubmitButton>
                  </form>
                )}
                {deal.escrowStatus === 'released_manual' && (
                  <span style={{ fontSize: 12, color: '#146c3a', fontWeight: 600 }}>✓ این معامله کامل تسویه شده</span>
                )}
              </div>
            </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

function RuleRow({ name, label, unit, defaultValue, hint }: { name: string; label: string; unit: string; defaultValue: number; hint: string }) {
  return (
    <div style={{ borderBottom: '1px dashed #eceff3', paddingBottom: 10 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 12.5 }}>
        <span style={{ width: 210, fontWeight: 700 }}>{label}</span>
        <input type="number" name={name} min={1} max={999} defaultValue={defaultValue} style={{ ...holidayInputStyle, width: 70, padding: '5px 8px' }} />
        <span style={{ color: '#9199a3' }}>{unit}</span>
      </div>
      <div style={{ fontSize: 10.5, color: '#9199a3', marginTop: 4, lineHeight: 1.7 }}>{hint}</div>
    </div>
  )
}

function escrowLabel(status: string) {
  return status === 'pending' ? 'در انتظار' : status === 'secured_manual' ? 'نزد ما (تضمین‌شده)' : status === 'released_manual' ? 'به فروشنده پرداخت شد' : status
}
function escrowColor(status: string): React.CSSProperties {
  return { color: status === 'pending' ? '#92400e' : status === 'secured_manual' ? '#1e357b' : '#146c3a' }
}

const holidayInputStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 8, padding: '8px 10px', fontSize: 12, fontFamily: 'inherit' }
const timelineRow: React.CSSProperties = { borderRight: '2px solid #e5e7eb', paddingRight: 12, marginBottom: 10 }
const metaLine: React.CSSProperties = { fontSize: 11.5, color: '#6f7680', marginTop: 2 }
const payInstrBox: React.CSSProperties = { border: '1px solid #e5e7eb', borderRadius: 10, padding: '10px 14px', marginBottom: 14, background: '#fcfcfd' }
const payInstrSetTag: React.CSSProperties = { fontSize: 9.5, fontWeight: 700, background: '#eaf3de', color: '#146c3a', borderRadius: 20, padding: '2px 8px', marginRight: 8 }
const payInstrEmptyTag: React.CSSProperties = { fontSize: 9.5, fontWeight: 700, background: '#fef3c7', color: '#92400e', borderRadius: 20, padding: '2px 8px', marginRight: 8 }
const payInstrTextarea: React.CSSProperties = { width: '100%', border: '1px solid #d8dde3', borderRadius: 8, padding: '9px 12px', fontSize: 12.5, fontFamily: 'inherit', lineHeight: 1.9, direction: 'rtl', resize: 'vertical', boxSizing: 'border-box' }
