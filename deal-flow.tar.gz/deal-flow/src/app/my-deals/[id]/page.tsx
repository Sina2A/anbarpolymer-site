import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { notFound } from 'next/navigation'
import UserNav from '@/components/UserNav'
import PanelHeader from '@/components/PanelHeader'
import Footer from '@/components/Footer'
import DealBankPay from '@/components/DealBankPay'
import { enforceDealDeadlines } from '@/lib/dealDeadlines'
import { SEVERE_DISCREPANCY_ITEMS, MINOR_DISCREPANCY_ITEMS } from '@/lib/disputes'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { cardStyle as sharedCardStyle } from '@/lib/styles/shared'
import { uploadDealPaymentReceiptAction, reportDiscrepancyAction, cancelDealAction } from '../actions'

export const dynamic = 'force-dynamic'

/**
 * صفحه‌ی جزئیات معامله برای خریدار — هم‌الگوی proformas/[id]/page.tsx.
 * فقط buyerId مطابق با کاربر جاری دسترسی دارد (وگرنه 404 تا id لو نرود).
 * DealBankPay کامپوننت پرداخت را سوار می‌کند.
 */

const STATUS_TEXT: Record<string, string> = {
  draft: 'پیش‌نویس — در انتظار تایید کارشناس',
  confirmed: 'تایید شد — لطفاً پرداخت را تکمیل کنید',
  seller_fee_paid: 'کارمزد فروشنده پرداخت شد — در انتظار پرداخت شما',
  payment_secured: 'وجه تضمین شد — در انتظار بارگیری',
  loading: 'در حال بارگیری در انبار',
  in_transit: 'در مسیر ارسال',
  delivered: 'تحویل داده شد',
  settled: 'تسویه شد',
}

/** وضعیت‌هایی که خریدار هنوز می‌تواند پرداخت کند */
const PAYABLE_STATUSES = ['confirmed', 'seller_fee_paid']

/** وضعیت‌هایی که هنوز امکان لغو دستی معامله وجود دارد — قبل از مرحله‌ی بارگیری */
const CANCELABLE_STATUSES = ['draft', 'awaiting_approval', 'confirmed', 'seller_fee_paid']

export default async function MyDealDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const user = await getCurrentUser()

  await enforceDealDeadlines()

  // فقط معامله‌ی خودِ کاربر — 404 به‌جای 403 تا id دیگران لو نرود
  const deal = await prisma.deal.findFirst({
    where: { id, buyerId: user.id },
    include: { materialListing: { include: { grade: true } } },
  })
  if (!deal) notFound()

  const shortId = deal.id.slice(0, 8)
  const gradeCode = (deal.materialListing as unknown as { grade?: { code: string } })?.grade?.code || ''
  const canPay = PAYABLE_STATUSES.includes(deal.status)
  const receiptSent = Boolean(deal.paymentReceiptUrl)
  // فرم آپلود فیش فقط وقتی هنوز می‌شود پرداخت کرد و رسیدی ثبت نشده
  const canUploadReceipt = canPay && !receiptSent
  // پنجره‌ی گزارش مغایرت: فقط پس از تحویل، تا قبل از انقضای مهلت، و اگر هنوز خودکار تایید نشده
  const canReportDiscrepancy =
    deal.status === 'delivered' &&
    deal.discrepancyReportDeadline !== null &&
    deal.discrepancyReportDeadline > new Date() &&
    deal.qualityAutoAccepted === false
  const canCancel = CANCELABLE_STATUSES.includes(deal.status)

  return (
    <>
      <PanelHeader currentUserName={user.companyName} />
      <div style={pageStyle}>
      <div style={{ width: '100%', display: 'flex', gap: 24 }} className="admin-page-wrap">
        <UserNav currentUserName={user.companyName} activeSection="deals" />
        <div style={{ flex: 1, minWidth: 0 }}>

          {/* بازگشت */}
          <a href="/my-deals" style={{ fontSize: fontSize.sm, color: colors.textMuted, textDecoration: 'none', display: 'inline-block', marginBottom: spacing.md }}>
            → بازگشت به لیست معاملات
          </a>

          <h1 style={{ fontSize: fontSize.xxl, fontWeight: 800, marginBottom: spacing.xl, color: colors.textPrimary }}>
            معامله #{shortId}
            {gradeCode && <span style={{ fontFamily: 'monospace', fontSize: fontSize.lg, fontWeight: 400, marginRight: spacing.md, color: colors.neutralText }}>{gradeCode}</span>}
          </h1>

          {/* اطلاعات معامله */}
          <div style={whiteCard}>
            <div style={{ fontSize: fontSize.lg, fontWeight: 800, marginBottom: spacing.lg }}>جزئیات معامله</div>
            <div style={infoGrid}>
              <InfoRow label="مقدار" value={deal.quantity} mono />
              <InfoRow label="قیمت توافقی" value={deal.agreedPrice !== null && deal.agreedPrice !== undefined ? `${deal.agreedPrice.toLocaleString('fa-IR')} ریال` : 'ثبت نشده'} mono={deal.agreedPrice !== null && deal.agreedPrice !== undefined} />
              {gradeCode && <InfoRow label="گرید" value={gradeCode} mono />}
              <InfoRow label="تاریخ ایجاد" value={new Date(deal.createdAt).toLocaleDateString('fa-IR')} />
            </div>
          </div>

          {/* نوار وضعیت */}
          <div style={statusBar}>
            وضعیت: {STATUS_TEXT[deal.status] || deal.status}
          </div>

          {/* هشدار مهلت پرداخت */}
          {deal.buyerConfirmDeadline && (deal.status === 'confirmed' || deal.status === 'seller_fee_paid') && (
            <div style={deadlineWarn}>
              ⏳ مهلت پرداخت: {new Date(deal.buyerConfirmDeadline).toLocaleString('fa-IR', { dateStyle: 'short', timeStyle: 'short' })}
              &nbsp;— بعد از این زمان معامله خودکار لغو می‌شود
            </div>
          )}

          {/* بخش پرداخت */}
          {(canPay || deal.status === 'payment_secured') && !receiptSent && (
            <div style={{ marginTop: spacing.xl }}>
              <div style={{ fontSize: fontSize.md, fontWeight: 800, marginBottom: spacing.lg }}>روش پرداخت</div>
              <div style={{ display: 'flex', gap: spacing.lg, flexWrap: 'wrap' }}>
                {/* کارت پرداخت بانکی / مستقیم */}
                <div style={{ ...payCard, flex: '1 1 300px', border: `1.5px solid ${colors.orange}` }}>
                  <div style={{ fontSize: fontSize.lg, fontWeight: 800 }}>🏦 پرداخت معامله</div>
                  <div style={{ fontSize: fontSize.sm, color: colors.textMuted, margin: '6px 0 14px' }}>آپلود فیش یا تماس مستقیم</div>
                  <DealBankPay
                    dealId={deal.id}
                    amountLabel={deal.agreedPrice !== null && deal.agreedPrice !== undefined ? `${deal.agreedPrice.toLocaleString('fa-IR')} ریال` : 'مبلغ توافقی'}
                    purposeLabel={`پرداخت معامله #${shortId}`}
                    paymentInstructionsText={deal.paymentInstructionsText ?? undefined}
                    disabled={!canPay}
                    disabledHint="پرداخت در وضعیت جاری امکان‌پذیر نیست"
                  />
                </div>
                {/* کارت پرداخت آنلاین — به‌زودی */}
                <div style={{ ...payCard, flex: '1 1 300px' }}>
                  <div style={{ fontSize: fontSize.lg, fontWeight: 800 }}>💳 پرداخت آنلاین</div>
                  <div style={{ fontSize: fontSize.sm, color: colors.textMuted, margin: '6px 0 14px' }}>به‌زودی فعال می‌شود</div>
                  <button type="button" disabled style={disabledBtn}>غیرفعال</button>
                </div>
              </div>
            </div>
          )}

          {/* آپلود مستقیم فیش پرداخت — فقط وقتی هنوز قابل پرداخت است و رسیدی ثبت نشده */}
          {canUploadReceipt && (
            <form action={uploadDealPaymentReceiptAction} style={{ ...whiteCard, marginTop: spacing.xl }}>
              <input type="hidden" name="dealId" value={deal.id} />
              <div style={{ fontSize: fontSize.md, fontWeight: 800, marginBottom: spacing.sm }}>آپلود فیش پرداخت</div>
              <div style={{ fontSize: fontSize.sm, color: colors.textMuted, marginBottom: spacing.lg }}>
                فایل فیش را انتخاب کنید — JPG، PNG یا PDF، حداکثر ۵ مگابایت
              </div>
              <input type="file" name="receiptFile" accept=".jpg,.jpeg,.png,.pdf" required style={{ fontSize: fontSize.sm, marginBottom: spacing.lg, display: 'block' }} />
              <button type="submit" style={submitBtn}>ثبت فیش</button>
            </form>
          )}

          {/* وضعیت رسید — مدل Deal فیلد paymentReceiptStatus ندارد (فقط Order دارد)،
              پس تنها «ارسال شد» + تضمین وجه از escrowStatus نمایش داده می‌شود */}
          {receiptSent && (
            <div style={{ ...receiptTag, color: colors.successText, background: colors.successBg, marginTop: 18 }}>
              ✓ رسید پرداخت ارسال شد — در انتظار تایید کارشناس مالی
              {deal.paymentReceiptUploadedAt && (
                <span style={{ fontWeight: 400, marginRight: 8, color: colors.neutralText }}>
                  ({new Date(deal.paymentReceiptUploadedAt).toLocaleDateString('fa-IR')})
                </span>
              )}
            </div>
          )}
          {deal.escrowStatus === 'secured_manual' && (
            <div style={{ ...receiptTag, color: colors.successText, background: colors.successBg, marginTop: 10 }}>
              ✓ وجه توسط کارشناس مالی تضمین شد
            </div>
          )}

          {/* گزارش مغایرت — فقط پس از تحویل و در بازه‌ی مجاز */}
          {canReportDiscrepancy && (
            <form action={reportDiscrepancyAction} style={{ ...whiteCard, marginTop: spacing.xl }}>
              <input type="hidden" name="dealId" value={deal.id} />
              <div style={{ fontSize: fontSize.md, fontWeight: 800, marginBottom: spacing.sm }}>گزارش مغایرت</div>
              <div style={{ fontSize: fontSize.sm, color: colors.textMuted, marginBottom: spacing.lg }}>
                اگر کالای تحویلی با سفارش مغایرت دارد، موارد را انتخاب و ثبت کنید. مهلت گزارش تا{' '}
                {new Date(deal.discrepancyReportDeadline as Date).toLocaleString('fa-IR', { dateStyle: 'short', timeStyle: 'short' })} است.
              </div>

              <div style={{ fontSize: fontSize.sm, fontWeight: 700, color: colors.dangerText, marginBottom: spacing.sm }}>مغایرت‌های حساس</div>
              {SEVERE_DISCREPANCY_ITEMS.map((item) => (
                <label key={item} style={checkboxRow}>
                  <input type="checkbox" name="items" value={item} />
                  <span>{item}</span>
                </label>
              ))}

              <div style={{ fontSize: fontSize.sm, fontWeight: 700, color: colors.textSecondary, margin: `${spacing.md}px 0 ${spacing.sm}px` }}>مغایرت‌های جزئی</div>
              {MINOR_DISCREPANCY_ITEMS.map((item) => (
                <label key={item} style={checkboxRow}>
                  <input type="checkbox" name="items" value={item} />
                  <span>{item}</span>
                </label>
              ))}

              <textarea
                name="note"
                rows={3}
                placeholder="توضیح تکمیلی (اختیاری)"
                style={{ width: '100%', marginTop: spacing.md, padding: '9px 12px', borderRadius: radius.md, border: `1px solid ${colors.borderStrong}`, fontFamily: 'inherit', fontSize: fontSize.sm, resize: 'vertical' }}
              />
              <button type="submit" style={{ ...submitBtn, marginTop: spacing.md }}>ثبت گزارش مغایرت</button>
            </form>
          )}

          {/* لغو معامله — فقط پیش از مرحله‌ی بارگیری */}
          {canCancel && (
            <details style={{ ...whiteCard, marginTop: spacing.xl }}>
              <summary style={{ cursor: 'pointer', fontSize: fontSize.md, fontWeight: 800, color: colors.dangerText }}>لغو معامله</summary>
              <form action={cancelDealAction} style={{ marginTop: spacing.lg }}>
                <input type="hidden" name="dealId" value={deal.id} />
                <div style={{ fontSize: fontSize.sm, color: colors.textMuted, marginBottom: spacing.md }}>
                  با لغو معامله، این معامله دیگر قابل پیگیری نیست و آگهی مربوطه دوباره فعال می‌شود. این عمل قابل بازگشت نیست.
                </div>
                <textarea
                  name="reason"
                  rows={2}
                  placeholder="دلیل لغو (اختیاری)"
                  style={{ width: '100%', marginBottom: spacing.md, padding: '9px 12px', borderRadius: radius.md, border: `1px solid ${colors.borderStrong}`, fontFamily: 'inherit', fontSize: fontSize.sm, resize: 'vertical' }}
                />
                <button type="submit" style={cancelBtn}>لغو معامله</button>
              </form>
            </details>
          )}

        </div>
      </div>
    </div>
      <Footer />
    </>
  )
}

function InfoRow({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: `1px solid ${colors.borderSubtle}`, fontSize: fontSize.base }}>
      <span style={{ color: colors.textSecondary }}>{label}</span>
      <span style={{ fontWeight: 700, fontFamily: mono ? 'monospace' : 'inherit' }}>{value}</span>
    </div>
  )
}

const pageStyle: React.CSSProperties = {
  minHeight: '100vh', background: colors.bgPage, padding: `${spacing.xxl}px ${spacing.xl}px`,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl',
}
const whiteCard: React.CSSProperties = {
  ...sharedCardStyle, padding: 18, marginBottom: 14,
}
const infoGrid: React.CSSProperties = { display: 'flex', flexDirection: 'column' }
const statusBar: React.CSSProperties = {
  background: colors.warningBg, borderRadius: radius.lg, padding: '12px 16px',
  fontSize: fontSize.md, fontWeight: 700, color: colors.warningText,
}
const deadlineWarn: React.CSSProperties = {
  marginTop: 10, fontSize: fontSize.sm, fontWeight: 700, color: colors.warningText,
}
const payCard: React.CSSProperties = {
  ...sharedCardStyle, padding: 18, marginBottom: 0,
}
const disabledBtn: React.CSSProperties = {
  padding: '9px 22px', background: colors.neutralBg, color: colors.textMuted,
  border: 'none', borderRadius: radius.md, fontWeight: 700, fontSize: fontSize.base, cursor: 'not-allowed',
}
const receiptTag: React.CSSProperties = {
  display: 'inline-block', fontSize: fontSize.sm, fontWeight: 700,
  padding: '8px 16px', borderRadius: radius.md,
}
const submitBtn: React.CSSProperties = {
  padding: '9px 22px', background: colors.orange, color: '#fff',
  border: 'none', borderRadius: radius.md, fontWeight: 700, fontSize: fontSize.base, cursor: 'pointer', fontFamily: 'inherit',
}
const checkboxRow: React.CSSProperties = {
  display: 'flex', alignItems: 'center', gap: spacing.sm,
  fontSize: fontSize.sm, color: colors.textPrimary, padding: '4px 0', cursor: 'pointer',
}
const cancelBtn: React.CSSProperties = {
  padding: '9px 22px', background: colors.bgCard, color: colors.dangerText,
  border: `1.5px solid ${colors.dangerBg}`, borderRadius: radius.md, fontWeight: 700, fontSize: fontSize.base, cursor: 'pointer', fontFamily: 'inherit',
}
