'use client'

import { useState } from 'react'
import { createPortal } from 'react-dom'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { ListingDetailDialog, countryLabel } from '@/components/ListingDetailModal'
import TrustCardModal from '@/components/TrustCardModal'
import { createDealFromListingAction } from '@/app/market/actions'

type Props = {
  listing: any
  kycLevel: number
  isGuest: boolean
}

// ستون‌های جدول عرضه — دقیقاً مطابق market-table-preview.html.
// ⚠️ چون هر ردیف یک Grid مستقله، حتماً minmax(0, Xfr) (نه Xfr خام) —
// وگرنه محتوای بلند (نام تولیدکننده، «در حال معامله»…) باعث Grid Blowout و
// از همراستایی افتادن ستون‌های همون ردیف با بقیه‌ی ردیف‌ها/هدر می‌شه.
export const SUPPLY_TABLE_COLUMNS = 'minmax(0,1.4fr) minmax(0,.9fr) minmax(0,1fr) minmax(0,.6fr) minmax(0,.8fr) minmax(0,.6fr) minmax(0,.8fr) minmax(0,.8fr) minmax(0,.8fr) minmax(0,1.3fr)'

export default function SupplyTableRow({ listing, kycLevel, isGuest }: Props) {
  const [open, setOpen] = useState(false)
  const [trustOpen, setTrustOpen] = useState(false)

  const active = listing.validityStatus === 'active'
  const statusBg = active ? colors.darkGreenBg : colors.warningBg
  const statusColor = active ? colors.darkGreenText : colors.warningText
  const statusLabel = active ? 'آزاد' : 'در حال معامله'

  return (
    <>
      {/* ── ردیف فشرده — کلیک روی ردیف (به‌جز ⓘ و دکمه‌ی عملیات) → پاپ‌آپ جزئیات موجود ── */}
      <div className="market-row-hover" style={rowStyle} onClick={() => setOpen(true)}>
        <div style={gradeCellStyle}>
          <span style={gradeCodeStyle}>{listing.grade.code}</span>
          <span style={gradeNameStyle}>
            {listing.grade.producer} ({listing.grade.category})
          </span>
        </div>

        <div style={cellStyle}>
          <span style={{ ...badgeStyle, background: statusBg, color: statusColor }}>{statusLabel}</span>
        </div>

        <div style={priceCellStyle}>
          <span style={priceNumStyle}>{listing.askingPriceToman.toLocaleString('fa-IR')}</span>
          <span style={priceUnitStyle}>تومان/کیلو</span>
        </div>

        <div style={cellStyle}>{listing.quantityTon} تن</div>
        <div style={cellStyle}>{listing.city}، {listing.province}</div>
        <div style={cellStyle}>{countryLabel(listing.grade.originCountry)}</div>
        <div style={{ ...cellStyle, fontFamily: 'monospace', direction: 'ltr' }}>{listing.grade.mfi ?? '—'}</div>
        <div style={cellStyle}>{listing.grade.applicationType ?? '—'}</div>
        <div style={monoCellStyle}>{new Date(listing.createdAt).toLocaleDateString('fa-IR')}</div>

        <div style={actionsStyle} onClick={(e) => e.stopPropagation()}>
          {/* ⓘ → Trust Card — جدا و مستقل از پاپ‌آپ جزئیات */}
          <button
            onClick={() => setTrustOpen(true)}
            style={iconBtnStyle}
            title="فرآیند این پیشنهاد"
            aria-label="فرآیند این پیشنهاد"
          >
            <svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
              <circle cx="8" cy="8" r="6" />
              <path d="M8 11V7.5" strokeLinecap="round" />
              <path d="M8 5.2h.01" strokeLinecap="round" />
            </svg>
          </button>
          {/* دکمه‌ی عملیات — همان گیت قبل: مهمان→عضویت، بدون احراز→احراز، وگرنه غیرفعال */}
          {isGuest ? (
            <a href="/signup" style={actionBtnStyle}>عضو شوید</a>
          ) : kycLevel < 1 ? (
            <a href="/verification" style={actionBtnStyle}>احراز هویت</a>
          ) : active ? (
            <form action={createDealFromListingAction}>
              <input type="hidden" name="materialListingId" value={listing.id} />
              <button type="submit" style={actionBtnStyle}>پیشنهاد خرید</button>
            </form>
          ) : (
            <span style={actionDisabledStyle} title="این آگهی در حال معامله است">پیشنهاد خرید</span>
          )}
        </div>
      </div>

      {open &&
        createPortal(
          <ListingDetailDialog listing={listing} kycLevel={kycLevel} isGuest={isGuest} onClose={() => setOpen(false)} />,
          document.body,
        )}
      {trustOpen && <TrustCardModal variant="supply" onClose={() => setTrustOpen(false)} />}
    </>
  )
}

// ── سفارشی‌سازی استایل ردیف — با توکن‌های موجود، رنگ‌های پرکاربرد site-wide ──
const rowStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: SUPPLY_TABLE_COLUMNS,
  gap: 10,
  alignItems: 'center',
  background: colors.bgCard,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
  padding: '11px 16px',
  marginBottom: 8,
  fontSize: fontSize.sm,
  cursor: 'pointer',
  transition: 'border-color .15s, box-shadow .15s',
}
const gradeCellStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 1,
  minWidth: 0,
  lineHeight: 1.5,
}
const gradeCodeStyle: React.CSSProperties = {
  fontFamily: 'monospace',
  fontWeight: 800,
  fontSize: 13,
  color: colors.navy,
  whiteSpace: 'nowrap',
}
const gradeNameStyle: React.CSSProperties = {
  fontSize: fontSize.xs,
  color: colors.textMuted,
  whiteSpace: 'nowrap',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
}
const cellStyle: React.CSSProperties = {
  minWidth: 0,
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  whiteSpace: 'nowrap',
}
const monoCellStyle: React.CSSProperties = {
  ...cellStyle,
  direction: 'ltr',
  fontFamily: 'monospace',
  color: colors.textMuted,
  fontSize: fontSize.xs,
  unicodeBidi: 'plaintext',
}
const badgeStyle: React.CSSProperties = {
  display: 'inline-block',
  fontSize: 10,
  fontWeight: 700,
  padding: '3px 9px',
  borderRadius: 999,
  whiteSpace: 'nowrap',
}
const priceCellStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 1,
  minWidth: 0,
}
const priceNumStyle: React.CSSProperties = {
  fontFamily: 'monospace',
  direction: 'ltr',
  fontWeight: 800,
  color: colors.orange,
  whiteSpace: 'nowrap',
  unicodeBidi: 'plaintext',
}
const priceUnitStyle: React.CSSProperties = {
  fontSize: 9,
  color: colors.textMuted,
  whiteSpace: 'nowrap',
}
const actionsStyle: React.CSSProperties = {
  display: 'flex',
  gap: 6,
  alignItems: 'center',
  justifyContent: 'flex-start',
  flexShrink: 0,
  whiteSpace: 'nowrap',
}
const iconBtnStyle: React.CSSProperties = {
  width: 28,
  height: 28,
  borderRadius: radius.sm,
  border: `1px solid ${colors.borderSubtle}`,
  background: colors.bgPage,
  color: colors.textMuted,
  cursor: 'pointer',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: 12,
  flexShrink: 0,
  padding: 0,
}
const actionBtnStyle: React.CSSProperties = {
  background: colors.navy,
  color: '#fff',
  border: 'none',
  borderRadius: radius.sm,
  padding: '7px 14px',
  fontSize: fontSize.xs,
  fontWeight: 700,
  textDecoration: 'none',
  whiteSpace: 'nowrap',
}
const actionDisabledStyle: React.CSSProperties = {
  background: colors.bgCard,
  color: colors.textMuted,
  border: `1px solid ${colors.borderStrong}`,
  borderRadius: radius.sm,
  padding: '6px 13px',
  fontSize: fontSize.xs,
  fontWeight: 700,
  whiteSpace: 'nowrap',
}