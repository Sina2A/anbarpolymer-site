'use client'

import { useActionState } from 'react'
import { signupAction } from './actions'

export default function SignupPage() {
  const [state, formAction, isPending] = useActionState(signupAction, { error: '' })

  return (
    <div style={pageStyle}>
      <div style={cardStyle}>
        <h1 style={{ fontSize: 20, fontWeight: 800, marginBottom: 6, color: '#1e357b' }}>ساخت حساب جدید</h1>
        <p style={{ fontSize: 12.5, color: '#9199a3', marginBottom: 24 }}>برای خریداران — بعد از ثبت‌نام، کد تایید به شماره‌ات پیامک می‌شه.</p>

        <form action={formAction} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div>
            <label style={labelStyle}>نام شرکت / نام کامل</label>
            <input name="companyName" required autoFocus style={inputStyle} />
          </div>
          <div>
            <label style={labelStyle}>شماره موبایل</label>
            <input name="phone" type="tel" placeholder="09xxxxxxxxx" required style={inputStyle} dir="ltr" />
          </div>
          <div>
            <label style={labelStyle}>رمز عبور</label>
            <input name="password" type="password" minLength={8} required style={inputStyle} dir="ltr" />
          </div>
          <div>
            <label style={labelStyle}>تکرار رمز عبور</label>
            <input name="confirmPassword" type="password" minLength={8} required style={inputStyle} dir="ltr" />
          </div>

          {state.error && <div style={errorStyle}>{state.error}</div>}

          <button type="submit" disabled={isPending} style={btnStyle(isPending)}>
            {isPending ? 'در حال ثبت...' : 'ساخت حساب'}
          </button>

          <div style={{ textAlign: 'center', marginTop: 4 }}>
            <a href="/login" style={linkStyle}>حساب داری؟ وارد شو</a>
          </div>
        </form>
      </div>
    </div>
  )
}

const pageStyle: React.CSSProperties = {
  minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
  background: '#faf8f4', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', padding: 16,
}
const cardStyle: React.CSSProperties = {
  width: '100%', maxWidth: 380, background: '#fff', border: '1px solid #d8dde3',
  borderRadius: 14, padding: '28px 24px', boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const labelStyle: React.CSSProperties = { display: 'block', fontSize: 12, color: '#4f5560', marginBottom: 5, fontWeight: 600 }
const inputStyle: React.CSSProperties = { width: '100%', padding: '11px 12px', border: '1px solid #d8dde3', borderRadius: 8, fontSize: 14, fontFamily: 'inherit' }
const errorStyle: React.CSSProperties = { background: '#fee2e2', color: '#a8241a', fontSize: 12.5, padding: '10px 12px', borderRadius: 8 }
const linkStyle: React.CSSProperties = { fontSize: 12, color: '#1e357b', textDecoration: 'none' }
function btnStyle(pending: boolean): React.CSSProperties {
  return { padding: '13px 0', background: pending ? '#9199a3' : '#f6621b', color: '#fff', border: 'none', borderRadius: 9, fontSize: 15, fontWeight: 800, cursor: pending ? 'default' : 'pointer' }
}
