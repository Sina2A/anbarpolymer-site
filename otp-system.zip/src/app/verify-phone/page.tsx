import VerifyPhoneForm from './VerifyPhoneForm'

export const dynamic = 'force-dynamic'

export default async function VerifyPhonePage({ searchParams }: { searchParams: Promise<{ phone?: string }> }) {
  const { phone } = await searchParams

  return (
    <div style={pageStyle}>
      <div style={cardStyle}>
        <h1 style={{ fontSize: 18, fontWeight: 800, marginBottom: 6 }}>تایید شماره موبایل</h1>
        <p style={{ fontSize: 13, color: '#6f7680', marginBottom: 20 }}>
          یه کد ۶رقمی به شماره‌ات پیامک شد. برای فعال‌شدن حسابت، وارد کن.
        </p>
        <VerifyPhoneForm initialPhone={phone || ''} />
      </div>
    </div>
  )
}

const pageStyle: React.CSSProperties = { minHeight: '100vh', background: '#faf8f4', padding: '32px 20px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl' }
const cardStyle: React.CSSProperties = { maxWidth: 420, margin: '0 auto', background: '#fff', border: '1px solid #d8dde3', borderRadius: 14, padding: '24px 20px' }
