'use server'

import prisma from '@/lib/prisma'
import { requestOtp, verifyOtp } from '@/lib/otp'

export async function resendVerifyCode(formData: FormData) {
  const phone = String(formData.get('phone') || '').trim()
  if (!phone) return { ok: false, message: 'شماره موبایل نامعتبره.' }

  const result = await requestOtp(phone, 'signup_verify')
  if (result.reason === 'too_soon') {
    return { ok: false, message: `کمی صبر کن — تا ${result.waitSeconds} ثانیه‌ی دیگه می‌تونی دوباره درخواست بدی.` }
  }
  if (!result.sent) {
    return { ok: false, message: 'ارسال پیامک با خطا مواجه شد. دوباره امتحان کن.' }
  }
  return { ok: true, message: 'کد جدید پیامک شد.' }
}

export async function confirmPhoneVerification(formData: FormData) {
  const phone = String(formData.get('phone') || '').trim()
  const code = String(formData.get('code') || '').trim()

  if (!phone || !code) return { ok: false, message: 'شماره و کد رو کامل وارد کن.' }

  const result = await verifyOtp(phone, code, 'signup_verify')

  if (!result.valid) {
    const messages: Record<string, string> = {
      not_found: 'کدی برای این شماره پیدا نشد — یه کد جدید بگیر.',
      expired: 'مهلت این کد گذشته — یه کد جدید بگیر.',
      too_many_attempts: 'تعداد تلاش‌های اشتباه زیاد شد — یه کد جدید بگیر.',
      wrong_code: 'کد وارد‌شده اشتباهه.',
    }
    return { ok: false, message: messages[result.reason] || 'خطای نامشخص.' }
  }

  const user = await prisma.user.findUnique({ where: { phone } })
  if (!user) return { ok: false, message: 'کاربری با این شماره پیدا نشد.' }

  await prisma.user.update({
    where: { id: user.id },
    data: { phoneVerified: true, phoneVerifiedAt: new Date() },
  })

  return { ok: true, message: 'شماره موبایل تایید شد. حالا می‌تونی با رمز عبورت وارد بشی.', verified: true }
}
