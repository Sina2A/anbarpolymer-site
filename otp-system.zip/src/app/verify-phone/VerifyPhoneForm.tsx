'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { resendVerifyCode, confirmPhoneVerification } from './actions'

export default function VerifyPhoneForm({ initialPhone }: { initialPhone: string }) {
  const router = useRouter()
  const [phone, setPhone] = useState(initialPhone)
  const [code, setCode] = useState('')
  const [message, setMessage] = useState('')
  const [isError, setIsError] = useState(false)
  const [pending, setPending] = useState(false)

  async function handleResend() {
    setPending(true)
    setMessage('')
    const fd = new FormData()
    fd.set('phone', phone)
    const res = await resendVerifyCode(fd)
    setIsError(!res.ok)
    setMessage(res.message)
    setPending(false)
  }

  async function handleVerify(e: React.FormEvent) {
    e.preventDefault()
    setPending(true)
    setMessage('')
    const fd = new FormData()
    fd.set('phone', phone)
    fd.set('code', code)
    const res = await confirmPhoneVerification(fd)
    setIsError(!res.ok)
    setMessage(res.message)
    setPending(false)
    if (res.ok && res.verified) {
      setTimeout(() => router.push('/login'), 1500)
    }
  }

  return (
    <form onSubmit={handleVerify} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <input
        type="tel"
        placeholder="شماره موبایل"
        value={phone}
        onChange={(e) => setPhone(e.target.value)}
        required
        style={inputStyle}
        dir="ltr"
      />
      <input
        type="text"
        inputMode="numeric"
        placeholder="کد ۶رقمی"
        value={code}
        onChange={(e) => setCode(e.target.value)}
        required
        maxLength={6}
        style={{ ...inputStyle, textAlign: 'center', fontSize: 20, letterSpacing: 6, fontFamily: 'monospace' }}
        dir="ltr"
      />

      {message && (
        <div style={{ fontSize: 12.5, fontWeight: 600, color: isError ? '#9b1c1c' : '#146c3a', background: isError ? '#fde8e8' : '#eaf3de', borderRadius: 8, padding: '8px 12px' }}>
          {message}
        </div>
      )}

      <button type="submit" disabled={pending} style={submitBtnStyle}>
        {pending ? 'در حال بررسی...' : 'تایید کد'}
      </button>
      <button type="button" onClick={handleResend} disabled={pending} style={resendBtnStyle}>
        ارسال دوباره‌ی کد
      </button>
    </form>
  )
}

const inputStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 9, padding: '11px 14px', fontSize: 14, fontFamily: 'inherit' }
const submitBtnStyle: React.CSSProperties = { background: '#1e357b', color: '#fff', border: 'none', borderRadius: 9, padding: '13px 0', fontSize: 14, fontWeight: 800, cursor: 'pointer' }
const resendBtnStyle: React.CSSProperties = { background: 'none', border: 'none', color: '#6f7680', fontSize: 12.5, cursor: 'pointer', textDecoration: 'underline' }
