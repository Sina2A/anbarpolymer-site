import ForgotPasswordForm from './ForgotPasswordForm'

export default function ForgotPasswordPage() {
  return (
    <div style={pageStyle}>
      <div style={cardStyle}>
        <h1 style={{ fontSize: 18, fontWeight: 800, marginBottom: 6 }}>فراموشی رمز عبور</h1>
        <p style={{ fontSize: 13, color: '#6f7680', marginBottom: 20 }}>
          شماره موبایلت رو وارد کن تا کد بازیابی برات پیامک بشه.
        </p>
        <ForgotPasswordForm />
      </div>
    </div>
  )
}

const pageStyle: React.CSSProperties = { minHeight: '100vh', background: '#faf8f4', padding: '32px 20px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl' }
const cardStyle: React.CSSProperties = { maxWidth: 420, margin: '0 auto', background: '#fff', border: '1px solid #d8dde3', borderRadius: 14, padding: '24px 20px' }
