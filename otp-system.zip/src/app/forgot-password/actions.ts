'use server'

import prisma from '@/lib/prisma'
import { hashPassword } from '@/lib/auth'
import { requestOtp, verifyOtp } from '@/lib/otp'

export async function requestResetCode(formData: FormData) {
  const phone = String(formData.get('phone') || '').trim()
  if (!phone) return { ok: false, message: 'شماره موبایل رو وارد کن.' }

  const user = await prisma.user.findUnique({ where: { phone } })
  // عمداً حتی اگه کاربر پیدا نشد، همین پیام رو می‌دیم — تا کسی نتونه با
  // امتحان‌کردن شماره‌های مختلف بفهمه کدوم شماره توی سایت ثبت‌نام کرده.
  const genericOk = { ok: true, message: 'اگه این شماره توی سایت ثبت شده باشه، کد براش پیامک می‌شه.' }
  if (!user) return genericOk

  const result = await requestOtp(phone, 'password_reset')
  if (result.reason === 'too_soon') {
    return { ok: false, message: `کمی صبر کن — تا ${result.waitSeconds} ثانیه‌ی دیگه می‌تونی دوباره درخواست بدی.` }
  }
  return genericOk
}

export async function resetPassword(formData: FormData) {
  const phone = String(formData.get('phone') || '').trim()
  const code = String(formData.get('code') || '').trim()
  const newPassword = String(formData.get('newPassword') || '')
  const confirmPassword = String(formData.get('confirmPassword') || '')

  if (!phone || !code || !newPassword || !confirmPassword) {
    return { ok: false, message: 'همه‌ی فیلدها رو کامل کن.' }
  }
  if (newPassword !== confirmPassword) {
    return { ok: false, message: 'رمز عبور جدید و تکرارش یکی نیستن.' }
  }
  if (newPassword.length < 8) {
    return { ok: false, message: 'رمز عبور باید حداقل ۸ کاراکتر باشه.' }
  }

  const result = await verifyOtp(phone, code, 'password_reset')
  if (!result.valid) {
    const messages: Record<string, string> = {
      not_found: 'کدی برای این شماره پیدا نشد — یه کد جدید بگیر.',
      expired: 'مهلت این کد گذشته — یه کد جدید بگیر.',
      too_many_attempts: 'تعداد تلاش‌های اشتباه زیاد شد — یه کد جدید بگیر.',
      wrong_code: 'کد وارد‌شده اشتباهه.',
    }
    return { ok: false, message: messages[result.reason] || 'خطای نامشخص.' }
  }

  const user = await prisma.user.findUnique({ where: { phone } })
  if (!user) return { ok: false, message: 'کاربری با این شماره پیدا نشد.' }

  // رمز قدیمی همینجا بازنویسی می‌شه — passwordHash یه فیلد تکیه، رمز قبلی
  // با آپدیت این مقدار عملاً از دیتابیس حذف می‌شه، جای جداگانه‌ای نداره که
  // بخوایم صریح پاکش کنیم.
  await prisma.user.update({
    where: { id: user.id },
    data: { passwordHash: hashPassword(newPassword) },
  })

  return { ok: true, message: 'رمز عبور با موفقیت تغییر کرد. حالا با رمز جدید وارد شو.', done: true }
}
