'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { requestResetCode, resetPassword } from './actions'

export default function ForgotPasswordForm() {
  const router = useRouter()
  const [phone, setPhone] = useState('')
  const [codeSent, setCodeSent] = useState(false)
  const [code, setCode] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [message, setMessage] = useState('')
  const [isError, setIsError] = useState(false)
  const [pending, setPending] = useState(false)

  async function handleRequestCode(e: React.FormEvent) {
    e.preventDefault()
    setPending(true)
    setMessage('')
    const fd = new FormData()
    fd.set('phone', phone)
    const res = await requestResetCode(fd)
    setIsError(!res.ok)
    setMessage(res.message)
    setPending(false)
    if (res.ok) setCodeSent(true) // فیلدهای مرحله‌ی بعد همین‌جا زیر شماره باز می‌شن
  }

  async function handleResetPassword(e: React.FormEvent) {
    e.preventDefault()
    setPending(true)
    setMessage('')
    const fd = new FormData()
    fd.set('phone', phone)
    fd.set('code', code)
    fd.set('newPassword', newPassword)
    fd.set('confirmPassword', confirmPassword)
    const res = await resetPassword(fd)
    setIsError(!res.ok)
    setMessage(res.message)
    setPending(false)
    if (res.ok && res.done) {
      setTimeout(() => router.push('/login'), 1500)
    }
  }

  return (
    <form onSubmit={codeSent ? handleResetPassword : handleRequestCode} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <input
        type="tel"
        placeholder="شماره موبایل"
        value={phone}
        onChange={(e) => setPhone(e.target.value)}
        required
        disabled={codeSent}
        style={{ ...inputStyle, opacity: codeSent ? 0.6 : 1 }}
        dir="ltr"
      />

      {!codeSent && (
        <button type="submit" disabled={pending} style={submitBtnStyle}>
          {pending ? 'در حال ارسال...' : 'ارسال کد بازیابی'}
        </button>
      )}

      {codeSent && (
        <>
          <input
            type="text"
            inputMode="numeric"
            placeholder="کد ۶رقمی"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            required
            maxLength={6}
            style={{ ...inputStyle, textAlign: 'center', fontSize: 18, letterSpacing: 5, fontFamily: 'monospace' }}
            dir="ltr"
          />
          <input
            type="password"
            placeholder="رمز عبور جدید (حداقل ۸ کاراکتر)"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            required
            minLength={8}
            style={inputStyle}
            dir="ltr"
          />
          <input
            type="password"
            placeholder="تکرار رمز عبور جدید"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
            minLength={8}
            style={inputStyle}
            dir="ltr"
          />
          <button type="submit" disabled={pending} style={submitBtnStyle}>
            {pending ? 'در حال ثبت...' : 'ثبت رمز عبور جدید'}
          </button>
        </>
      )}

      {message && (
        <div style={{ fontSize: 12.5, fontWeight: 600, color: isError ? '#9b1c1c' : '#146c3a', background: isError ? '#fde8e8' : '#eaf3de', borderRadius: 8, padding: '8px 12px' }}>
          {message}
        </div>
      )}
    </form>
  )
}

const inputStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 9, padding: '11px 14px', fontSize: 14, fontFamily: 'inherit' }
const submitBtnStyle: React.CSSProperties = { background: '#1e357b', color: '#fff', border: 'none', borderRadius: 9, padding: '13px 0', fontSize: 14, fontWeight: 800, cursor: 'pointer' }
