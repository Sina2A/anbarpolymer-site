'use server'

import prisma from '@/lib/prisma'
import { createSession } from '@/lib/auth'
import { requestOtp, verifyOtp } from '@/lib/otp'
import { redirect } from 'next/navigation'

export async function requestLoginCode(formData: FormData) {
  const phone = String(formData.get('phone') || '').trim()
  if (!phone) return { ok: false, message: 'شماره موبایل رو وارد کن.' }

  const user = await prisma.user.findUnique({ where: { phone } })
  const genericOk = { ok: true, message: 'اگه این شماره ثبت‌نام شده باشه، کد ورود براش پیامک می‌شه.' }
  if (!user) return genericOk // همون منطق ضد کشف-شماره‌ی صفحه‌ی فراموشی رمز

  if (!user.isActive) return { ok: false, message: 'این حساب غیرفعال شده — با پشتیبانی تماس بگیر.' }

  const result = await requestOtp(phone, 'login')
  if (result.reason === 'too_soon') {
    return { ok: false, message: `کمی صبر کن — تا ${result.waitSeconds} ثانیه‌ی دیگه می‌تونی دوباره درخواست بدی.` }
  }
  return genericOk
}

export async function confirmLoginCode(formData: FormData) {
  const phone = String(formData.get('phone') || '').trim()
  const code = String(formData.get('code') || '').trim()
  if (!phone || !code) return { ok: false, message: 'شماره و کد رو کامل وارد کن.' }

  const result = await verifyOtp(phone, code, 'login')
  if (!result.valid) {
    const messages: Record<string, string> = {
      not_found: 'کدی برای این شماره پیدا نشد — یه کد جدید بگیر.',
      expired: 'مهلت این کد گذشته — یه کد جدید بگیر.',
      too_many_attempts: 'تعداد تلاش‌های اشتباه زیاد شد — یه کد جدید بگیر.',
      wrong_code: 'کد وارد‌شده اشتباهه.',
    }
    return { ok: false, message: messages[result.reason] || 'خطای نامشخص.' }
  }

  const user = await prisma.user.findUnique({ where: { phone } })
  if (!user || !user.isActive) return { ok: false, message: 'ورود ممکن نیست.' }

  await createSession(user.id)
  // توجه: /dashboard هنوز واقعی نیست (استاتیکه) — فعلاً به /my-orders می‌فرستیم
  // که واقعیه. هروقت dashboard.html مهاجرت کرد، این خط رو عوض کن.
  redirect('/my-orders')
}
