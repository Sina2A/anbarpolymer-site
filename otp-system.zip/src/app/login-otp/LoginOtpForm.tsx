'use client'

import { useState } from 'react'
import { requestLoginCode, confirmLoginCode } from './actions'

export default function LoginOtpForm() {
  const [phone, setPhone] = useState('')
  const [codeSent, setCodeSent] = useState(false)
  const [code, setCode] = useState('')
  const [message, setMessage] = useState('')
  const [isError, setIsError] = useState(false)
  const [pending, setPending] = useState(false)

  async function handleRequestCode(e: React.FormEvent) {
    e.preventDefault()
    setPending(true)
    setMessage('')
    const fd = new FormData()
    fd.set('phone', phone)
    const res = await requestLoginCode(fd)
    setIsError(!res.ok)
    setMessage(res.message)
    setPending(false)
    if (res.ok) setCodeSent(true)
  }

  async function handleConfirm(e: React.FormEvent) {
    e.preventDefault()
    setPending(true)
    setMessage('')
    const fd = new FormData()
    fd.set('phone', phone)
    fd.set('code', code)
    const res = await confirmLoginCode(fd)
    // توجه: در صورت موفقیت، خودِ اکشن با redirect() کاربر رو می‌فرسته؛
    // این خط‌ها فقط برای حالت خطا اجرا می‌شن.
    if (res && !res.ok) {
      setIsError(true)
      setMessage(res.message)
    }
    setPending(false)
  }

  return (
    <form onSubmit={codeSent ? handleConfirm : handleRequestCode} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <input
        type="tel"
        placeholder="شماره موبایل"
        value={phone}
        onChange={(e) => setPhone(e.target.value)}
        required
        disabled={codeSent}
        style={{ ...inputStyle, opacity: codeSent ? 0.6 : 1 }}
        dir="ltr"
      />

      {!codeSent && (
        <button type="submit" disabled={pending} style={submitBtnStyle}>
          {pending ? 'در حال ارسال...' : 'ارسال کد ورود'}
        </button>
      )}

      {codeSent && (
        <>
          <input
            type="text"
            inputMode="numeric"
            placeholder="کد ۶رقمی"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            required
            maxLength={6}
            style={{ ...inputStyle, textAlign: 'center', fontSize: 18, letterSpacing: 5, fontFamily: 'monospace' }}
            dir="ltr"
          />
          <button type="submit" disabled={pending} style={submitBtnStyle}>
            {pending ? 'در حال ورود...' : 'تایید و ورود'}
          </button>
        </>
      )}

      {message && (
        <div style={{ fontSize: 12.5, fontWeight: 600, color: isError ? '#9b1c1c' : '#146c3a', background: isError ? '#fde8e8' : '#eaf3de', borderRadius: 8, padding: '8px 12px' }}>
          {message}
        </div>
      )}
    </form>
  )
}

const inputStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 9, padding: '11px 14px', fontSize: 14, fontFamily: 'inherit' }
const submitBtnStyle: React.CSSProperties = { background: '#1e357b', color: '#fff', border: 'none', borderRadius: 9, padding: '13px 0', fontSize: 14, fontWeight: 800, cursor: 'pointer' }
