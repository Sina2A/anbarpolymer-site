import LoginOtpForm from './LoginOtpForm'

export default function LoginOtpPage() {
  return (
    <div style={pageStyle}>
      <div style={cardStyle}>
        <h1 style={{ fontSize: 18, fontWeight: 800, marginBottom: 6 }}>ورود با رمز پیامکی</h1>
        <p style={{ fontSize: 13, color: '#6f7680', marginBottom: 20 }}>
          به‌جای رمز عبور، با یه کد یک‌بارمصرف پیامکی وارد شو.
        </p>
        <LoginOtpForm />
        <div style={{ marginTop: 16, textAlign: 'center' }}>
          <a href="/login" style={{ fontSize: 12.5, color: '#1e357b' }}>ورود با رمز عبور</a>
        </div>
      </div>
    </div>
  )
}

const pageStyle: React.CSSProperties = { minHeight: '100vh', background: '#faf8f4', padding: '32px 20px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl' }
const cardStyle: React.CSSProperties = { maxWidth: 420, margin: '0 auto', background: '#fff', border: '1px solid #d8dde3', borderRadius: 14, padding: '24px 20px' }
