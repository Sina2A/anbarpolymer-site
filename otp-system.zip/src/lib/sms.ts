/**
 * لایه‌ی ارسال پیامک — عمداً جدا از منطق OTP، تا وقتی سرویس‌دهنده (کاوه‌نگار/
 * ملی‌پیامک/...) نهایی شد، فقط همین فایل عوض بشه، هیچ‌جای دیگه‌ی کد دست نخوره.
 *
 * فعلاً هیچ حساب پیامکی وصل نیست، پس بک‌اند به‌جای ارسال واقعی، کد رو توی
 * لاگ سرور می‌نویسه (safe fallback) — یعنی همین الان می‌شه کل جریان OTP رو
 * تست کرد (با نگاه‌کردن به لاگ pm2)، بدون این‌که منتظر تصمیم سرویس‌دهنده بمونیم.
 */

export type SmsSendResult = { success: boolean; error?: string }

async function sendViaStub(phone: string, message: string): Promise<SmsSendResult> {
  // eslint-disable-next-line no-console
  console.log(`[SMS STUB — سرویس واقعی وصل نشده] به ${phone}: ${message}`)
  return { success: true }
}

// -------------------------------------------------------------------------
// وقتی سرویس‌دهنده انتخاب شد، اینجا یه تابع جدید مثل sendViaKavenegar بساز
// (با fetch واقعی به API اونا) و توی سوییچ پایین یه case جدید براش اضافه کن.
// نمونه‌ی اسکلت (کاوه‌نگار، برای مرجع — فعلاً فعال نیست):
//
// async function sendViaKavenegar(phone: string, message: string): Promise<SmsSendResult> {
//   const apiKey = process.env.KAVENEGAR_API_KEY
//   const res = await fetch(`https://api.kavenegar.com/v1/${apiKey}/sms/send.json`, {
//     method: 'POST',
//     headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
//     body: new URLSearchParams({ receptor: phone, message, sender: process.env.KAVENEGAR_SENDER || '' }),
//   })
//   if (!res.ok) return { success: false, error: `HTTP ${res.status}` }
//   return { success: true }
// }
// -------------------------------------------------------------------------

async function sendViaProvider(phone: string, message: string): Promise<SmsSendResult> {
  const provider = process.env.SMS_PROVIDER // مثلاً 'kavenegar' | 'melipayamak'

  switch (provider) {
    // case 'kavenegar':
    //   return sendViaKavenegar(phone, message)
    default:
      return sendViaStub(phone, message)
  }
}

export async function sendSms(phone: string, message: string): Promise<SmsSendResult> {
  try {
    return await sendViaProvider(phone, message)
  } catch (e) {
    // هیچ‌وقت نباید یه خطای پیامک، کل فرآیند ثبت‌نام/ورود رو خراب کنه
    return { success: false, error: e instanceof Error ? e.message : 'خطای نامشخص در ارسال پیامک' }
  }
}
