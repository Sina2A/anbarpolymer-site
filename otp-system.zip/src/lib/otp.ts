import prisma from './prisma'
import { hashPassword, verifyPassword } from './auth'
import { sendSms } from './sms'

const OTP_LENGTH = 6
const OTP_EXPIRY_MINUTES = 2
const MAX_VERIFY_ATTEMPTS = 5 // بعد از این تعداد تلاش اشتباه، کد باطل می‌شه (ضد حدس‌زدن)
const MIN_SECONDS_BETWEEN_REQUESTS = 60 // ضد اسپم/هزینه‌تراشی روی پیامک

export type OtpPurpose = 'signup_verify' | 'password_reset' | 'login'

function generateSixDigitCode(): string {
  // Math.random کافیه چون خودِ کد کوتاه‌مدت و rate-limited هست؛ چیزی که واقعاً
  // امنیت رو تامین می‌کنه، هش‌شدن + محدودیت تلاش + انقضای ۲دقیقه‌ایه.
  return String(Math.floor(100000 + Math.random() * 900000))
}

/**
 * یه کد جدید می‌سازه و پیامک می‌کنه. اگه توی ۶۰ثانیه‌ی اخیر یه کد دیگه برای
 * همون شماره/همون منظور فرستاده شده، درخواست جدید رد می‌شه — برای جلوگیری
 * از سوءاستفاده (هزینه‌تراشی پیامکی روی حساب شما، یا مزاحمت برای صاحب شماره).
 */
export async function requestOtp(phone: string, purpose: OtpPurpose) {
  const recentCutoff = new Date(Date.now() - MIN_SECONDS_BETWEEN_REQUESTS * 1000)
  const recent = await prisma.otpCode.findFirst({
    where: { phone, purpose, createdAt: { gt: recentCutoff } },
    orderBy: { createdAt: 'desc' },
  })
  if (recent) {
    const waitSeconds = Math.ceil((recent.createdAt.getTime() + MIN_SECONDS_BETWEEN_REQUESTS * 1000 - Date.now()) / 1000)
    return { sent: false, reason: 'too_soon' as const, waitSeconds }
  }

  const code = generateSixDigitCode()
  const codeHash = hashPassword(code) // همون هش رمز عبور — امن و آماده، دلیلی برای دوباره‌سازی نیست
  const expiresAt = new Date(Date.now() + OTP_EXPIRY_MINUTES * 60 * 1000)

  await prisma.otpCode.create({ data: { phone, codeHash, purpose, expiresAt } })

  const messages: Record<OtpPurpose, string> = {
    signup_verify: `کد تایید شماره موبایل شما در انبار پلیمر: ${code}`,
    password_reset: `کد بازیابی رمز عبور شما در انبار پلیمر: ${code}`,
    login: `کد ورود شما به انبار پلیمر: ${code}`,
  }
  const result = await sendSms(phone, messages[purpose])

  return { sent: result.success, reason: result.success ? ('ok' as const) : ('sms_failed' as const), expiresInMinutes: OTP_EXPIRY_MINUTES }
}

/**
 * کد وارد‌شده رو با آخرین کد فعال (مصرف‌نشده) همون شماره/منظور مقایسه می‌کنه.
 * بعد از ۵ تلاش اشتباه یا گذشتن مهلت، کد باطل تلقی می‌شه و باید یه کد جدید
 * درخواست بشه — این عمداً محدودتر از مهلت‌های ساعت‌کاری بقیه‌ی سایته، چون
 * اینجا موضوع امنیت حسابه، نه یه فرآیند تجاری.
 */
export async function verifyOtp(phone: string, code: string, purpose: OtpPurpose) {
  const otp = await prisma.otpCode.findFirst({
    where: { phone, purpose, consumedAt: null },
    orderBy: { createdAt: 'desc' },
  })

  if (!otp) return { valid: false, reason: 'not_found' as const }
  if (otp.expiresAt < new Date()) return { valid: false, reason: 'expired' as const }
  if (otp.attempts >= MAX_VERIFY_ATTEMPTS) return { valid: false, reason: 'too_many_attempts' as const }

  const isCorrect = verifyPassword(code, otp.codeHash)

  if (!isCorrect) {
    await prisma.otpCode.update({ where: { id: otp.id }, data: { attempts: { increment: 1 } } })
    return { valid: false, reason: 'wrong_code' as const }
  }

  await prisma.otpCode.update({ where: { id: otp.id }, data: { consumedAt: new Date() } })
  return { valid: true as const }
}
