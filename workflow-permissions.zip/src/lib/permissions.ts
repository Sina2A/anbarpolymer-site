import prisma from './prisma'

// هر بخش از پنل ادمین که باید دسترسی جداگانه داشته باشه.
// این‌ها همون سکشن‌های موجود پنل ادمین هستن که قبلاً ساختیم.
export const SECTION_KEYS = [
  { key: 'orders', label: 'سفارش‌ها' },
  { key: 'pricing', label: 'مرکز قیمت‌گذاری (بنچمارک)' },
  { key: 'warehouses', label: 'انبارها و موجودی' },
  { key: 'grades', label: 'گریدها و مشخصات فنی' },
  { key: 'material-listings', label: 'شبکه عرضه مواد اولیه' },
  { key: 'payments', label: 'تایید فیش‌های پرداخت' },
  { key: 'logistics', label: 'حمل و نقل' },
  { key: 'articles', label: 'مقالات و اخبار' },
  { key: 'documents', label: 'اسناد (TDS/MSDS)' },
  { key: 'support', label: 'پشتیبانی و تیکت‌ها' },
  { key: 'buyers', label: 'خریداران' },
  { key: 'users', label: 'مدیریت کاربران و دسترسی‌ها' },
] as const

export type SectionKey = (typeof SECTION_KEYS)[number]['key']

/**
 * چک می‌کنه که یک کاربر مشخص، دسترسی دیدن/ویرایش یک بخش رو داره یا نه.
 * توجه: نقش admin هم باید صراحتاً Permission داشته باشه — هیچ نقشی خودکار
 * دسترسی نمی‌گیره، طبق تصمیمی که گرفته شد (همه‌چیز دستی و تایید‌شده).
 */
export async function hasPermission(userId: string, section: SectionKey, need: 'view' | 'edit' = 'view') {
  const perm = await prisma.permission.findUnique({
    where: { userId_section: { userId, section } },
  })
  if (!perm) return false
  return need === 'view' ? perm.canView || perm.canEdit : perm.canEdit
}

export async function getUserPermissions(userId: string) {
  return prisma.permission.findMany({ where: { userId } })
}
