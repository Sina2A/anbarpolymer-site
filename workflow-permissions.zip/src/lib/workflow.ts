// نقشه‌ی دقیق مراحل مجاز برای هر نوع رکورد.
// هدف: فیلد «مرحله بعد» هیچ‌وقت گمراه‌کننده نباشه — اگه چند مسیر ممکنه،
// به‌جای حدس زدن، پیام خنثی «منتظر وضعیت جاری» نشون داده می‌شه.

export type RecordType = 'Order' | 'MaterialListing' | 'SupportTicket'

export const AWAITING_CURRENT = 'AWAITING_CURRENT'

interface StageDef {
  key: string
  label: string // برچسب فارسی قابل‌نمایش برای کارشناس (فعل حال، مثل "در حال ...")
  possibleNext: string[] // کلید مراحل بعدی ممکن؛ اگه بیش از یکی بود، فیلد بعد مبهم می‌مونه
}

const ORDER_STAGES: StageDef[] = [
  { key: 'pending', label: 'در حال ثبت اولیه توسط مشتری', possibleNext: ['priced'] },
  { key: 'priced', label: 'در حال تعیین قیمت توسط کارشناس فروش', possibleNext: ['buyer_confirmed', 'pending'] },
  { key: 'buyer_confirmed', label: 'در حال تایید قیمت توسط مشتری', possibleNext: ['contracted'] },
  { key: 'contracted', label: 'در حال عقد قرارداد', possibleNext: ['paid'] },
  { key: 'paid', label: 'در حال بررسی و تایید پرداخت توسط کارشناس مالی', possibleNext: ['loading'] },
  { key: 'loading', label: 'در حال بارگیری در انبار', possibleNext: ['in_transit'] },
  { key: 'in_transit', label: 'در مسیر ارسال', possibleNext: ['delivered'] },
  { key: 'delivered', label: 'تحویل داده شده — سفارش بسته شد', possibleNext: [] },
]

const MATERIAL_LISTING_STAGES: StageDef[] = [
  { key: 'submitted', label: 'ثبت شد — در انتظار بررسی توسط پشتیبانی', possibleNext: ['approved', 'needs_correction'] },
  { key: 'needs_correction', label: 'نیاز به اصلاح اطلاعات توسط ثبت‌کننده', possibleNext: ['submitted'] },
  { key: 'approved', label: 'تایید شد — در سایت قابل مشاهده است', possibleNext: ['under_review_by_buyer'] },
  { key: 'under_review_by_buyer', label: 'در حال بررسی توسط یک خریدار', possibleNext: ['accepted_by_buyer', 'approved'] },
  { key: 'accepted_by_buyer', label: 'پذیرفته شد توسط خریدار — منتظر پرداخت کارمزد', possibleNext: ['fee_paid'] },
  { key: 'fee_paid', label: 'کارمزد پرداخت شد — در حال هماهنگی انتقال بار', possibleNext: ['completed'] },
  { key: 'completed', label: 'تکمیل شد — بار تحویل داده شد', possibleNext: [] },
]

const SUPPORT_TICKET_STAGES: StageDef[] = [
  { key: 'open', label: 'در حال بررسی اولیه توسط پشتیبانی', possibleNext: ['in_progress'] },
  { key: 'in_progress', label: 'در حال پیگیری توسط کارشناس پشتیبانی', possibleNext: ['resolved'] },
  { key: 'resolved', label: 'پاسخ داده شد — منتظر تایید نهایی مشتری', possibleNext: ['closed', 'in_progress'] },
  { key: 'closed', label: 'بسته شد', possibleNext: [] },
]

const WORKFLOWS: Record<RecordType, StageDef[]> = {
  Order: ORDER_STAGES,
  MaterialListing: MATERIAL_LISTING_STAGES,
  SupportTicket: SUPPORT_TICKET_STAGES,
}

function findStage(recordType: RecordType, key: string): StageDef | undefined {
  return WORKFLOWS[recordType].find((s) => s.key === key)
}

function findPrevStage(recordType: RecordType, currentKey: string): StageDef | undefined {
  return WORKFLOWS[recordType].find((s) => s.possibleNext.includes(currentKey))
}

/**
 * برای یک رکورد در یک مرحله‌ی مشخص، برچسب مرحله‌ی قبلی/حال/بعدی رو برمی‌گردونه.
 * اگه از این مرحله بیش از یک مسیر ممکن باشه، nextLabel خنثی («منتظر وضعیت جاری») می‌شه
 * — نه یه حدسِ گمراه‌کننده.
 */
export function describeTransition(recordType: RecordType, currentKey: string) {
  const current = findStage(recordType, currentKey)
  if (!current) {
    return { prevLabel: null, currentLabel: 'وضعیت نامشخص', nextLabel: null }
  }

  const prev = findPrevStage(recordType, currentKey)

  let nextLabel: string | null
  if (current.possibleNext.length === 0) {
    nextLabel = null // مرحله‌ی پایانی، مرحله‌ی بعدی وجود نداره
  } else if (current.possibleNext.length === 1) {
    const next = findStage(recordType, current.possibleNext[0])
    nextLabel = next ? next.label : null
  } else {
    nextLabel = 'منتظر وضعیت جاری' // چند مسیر ممکنه؛ گمراه‌کننده نشون ندیم
  }

  return {
    prevLabel: prev ? prev.label : null,
    currentLabel: current.label,
    nextLabel,
  }
}

export function getStages(recordType: RecordType): StageDef[] {
  return WORKFLOWS[recordType]
}
