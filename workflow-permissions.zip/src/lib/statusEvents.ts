import prisma from './prisma'
import { describeTransition, RecordType } from './workflow'

/**
 * وقتی یه کارشناس وضعیت یه رکورد رو تغییر می‌ده، این تابع رو صدا بزن.
 * خودش prevStage/currentStage/nextStage رو از روی نقشه‌ی workflow پر می‌کنه —
 * لازم نیست جایی این برچسب‌ها رو دستی بنویسی.
 *
 * مثال استفاده (وقتی کارشناس قیمت یه سفارش رو ثبت می‌کنه):
 *
 *   await logStatusEvent({
 *     recordType: 'Order',
 *     recordId: order.id,
 *     newStageKey: 'priced',
 *     performedById: currentUser.id,
 *     note: 'قیمت ۵۲,۰۰۰ ریال ثبت شد',
 *   })
 */
export async function logStatusEvent(params: {
  recordType: RecordType
  recordId: string
  newStageKey: string
  performedById?: string
  note?: string
}) {
  const { recordType, recordId, newStageKey, performedById, note } = params
  const { prevLabel, currentLabel, nextLabel } = describeTransition(recordType, newStageKey)

  return prisma.statusEvent.create({
    data: {
      recordType,
      recordId,
      prevStage: prevLabel,
      currentStage: currentLabel,
      nextStage: nextLabel,
      performedById,
      note,
    },
  })
}

export async function getTimeline(recordType: RecordType, recordId: string) {
  return prisma.statusEvent.findMany({
    where: { recordType, recordId },
    orderBy: { createdAt: 'asc' },
    include: { performedBy: true },
  })
}
