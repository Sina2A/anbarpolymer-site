import prisma from '@/lib/prisma'
import { SECTION_KEYS } from '@/lib/permissions'
import { isTerminalStage, getStageDef, RecordType } from '@/lib/workflow'

export const dynamic = 'force-dynamic'

const RECORD_TYPE_LABELS: Record<RecordType, string> = {
  Order: 'سفارش',
  MaterialListing: 'درخواست فروش مواد اولیه',
  SupportTicket: 'تیکت پشتیبانی',
}

// چون هنوز سیستم ورود واقعی وصل نیست (فاز ۴)، فعلاً از یه انتخابگر کاربر بالای صفحه استفاده می‌کنیم.
// وقتی Auth وصل شد، فقط همین userId رو از session بگیر، این dropdown اضافه‌ست و می‌شه حذفش کرد.
export default async function MyTasksPage({ searchParams }: { searchParams: Promise<{ userId?: string }> }) {
  const { userId: selectedUserId } = await searchParams

  const staff = await prisma.user.findMany({
    where: { role: { in: ['staff', 'admin'] }, isActive: true },
    orderBy: { createdAt: 'asc' },
  })

  const currentUser = selectedUserId ? staff.find((u) => u.id === selectedUserId) : staff[0]

  if (!currentUser) {
    return (
      <div style={pageStyle}>
        <h1 style={{ fontSize: 22, fontWeight: 800 }}>کارهای منتظر من</h1>
        <p style={{ color: '#9199a3', marginTop: 12 }}>
          هنوز هیچ کارشناسی ثبت نشده. اول از صفحه‌ی «مدیریت کاربران و دسترسی‌ها» یه کارشناس اضافه کن.
        </p>
      </div>
    )
  }

  const myPermissions = await prisma.permission.findMany({
    where: { userId: currentUser.id, canEdit: true },
  })
  const mySections = new Set(myPermissions.map((p) => p.section))

  // آخرین رویداد هر رکورد رو پیدا می‌کنیم (StatusEvent فقط اضافه می‌شه، هیچ‌وقت آپدیت نمی‌شه)
  const allEvents = await prisma.statusEvent.findMany({
    orderBy: { createdAt: 'asc' },
  })
  const latestByRecord = new Map<string, (typeof allEvents)[number]>()
  for (const ev of allEvents) {
    latestByRecord.set(`${ev.recordType}:${ev.recordId}`, ev) // چون به ترتیب صعودی مرتبه، آخری جایگزین قبلی می‌شه
  }

  const myTasks = Array.from(latestByRecord.values()).filter((ev) => {
    const recordType = ev.recordType as RecordType
    if (isTerminalStage(recordType, ev.stageKey)) return false
    // اگه این مرحله بخش مسئول نداشته باشه (مثلاً منتظر اقدام مشتریه، نه کارشناس)، توی صف کسی نمیاد
    const stageDef = getStageDef(recordType, ev.stageKey)
    if (!stageDef?.responsibleSection) return false
    return mySections.has(stageDef.responsibleSection)
  })

  const bySection = new Map<string, typeof myTasks>()
  for (const task of myTasks) {
    const recordType = task.recordType as RecordType
    const stageDef = getStageDef(recordType, task.stageKey)
    const section = stageDef?.responsibleSection ?? 'other'
    if (!bySection.has(section)) bySection.set(section, [])
    bySection.get(section)!.push(task)
  }

  return (
    <div style={pageStyle}>
      <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 8 }}>کارهای منتظر من</h1>
      <p style={{ color: '#6f7680', fontSize: 13.5, marginBottom: 20, lineHeight: 1.9 }}>
        رکوردهایی که الان توی مرحله‌ای هستن که مسئولیتش با یکی از بخش‌های شماست.
      </p>

      <form method="GET" style={{ marginBottom: 26, display: 'flex', gap: 10, alignItems: 'center' }}>
        <label style={{ fontSize: 13 }}>نمایش کارهای:</label>
        <select name="userId" defaultValue={currentUser.id} style={selectStyle}>
          {staff.map((u) => (
            <option key={u.id} value={u.id}>
              {u.companyName}
            </option>
          ))}
        </select>
        <button type="submit" style={submitBtnStyle}>نمایش</button>
        <span style={{ fontSize: 11.5, color: '#9199a3' }}>(این انتخابگر موقتیه — بعد از وصل شدن سیستم ورود، حذف می‌شه)</span>
      </form>

      {myTasks.length === 0 && (
        <div style={{ padding: 32, textAlign: 'center', color: '#9199a3', border: '1px dashed #d8dde3', borderRadius: 12 }}>
          هیچ کار منتظری نیست 🎉
        </div>
      )}

      {SECTION_KEYS.filter((sec) => bySection.has(sec.key)).map((sec) => (
        <div key={sec.key} style={cardStyle}>
          <h3 style={{ fontSize: 14.5, marginBottom: 14, display: 'flex', alignItems: 'center', gap: 8 }}>
            {sec.label}
            <span style={countTag}>{bySection.get(sec.key)!.length}</span>
          </h3>
          {bySection.get(sec.key)!.map((task) => (
            <div key={task.id} style={taskRow}>
              <div>
                <span style={typeTag}>{RECORD_TYPE_LABELS[task.recordType as RecordType]}</span>
                <span style={{ fontSize: 11.5, color: '#9199a3', fontFamily: 'monospace', marginRight: 8 }}>#{task.recordId.slice(0, 8)}</span>
              </div>
              <div style={{ fontSize: 13, fontWeight: 600, marginTop: 6 }}>{task.currentStage}</div>
              <div style={{ fontSize: 11.5, color: '#9199a3', marginTop: 4 }}>
                از {new Date(task.createdAt).toLocaleDateString('fa-IR')} منتظره
              </div>
            </div>
          ))}
        </div>
      ))}
    </div>
  )
}

const pageStyle: React.CSSProperties = { padding: '32px 24px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', maxWidth: 900, margin: '0 auto' }
const cardStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 12, padding: 20, marginBottom: 16, background: '#fff', boxShadow: '0 1px 4px rgba(27,30,36,.05)' }
const selectStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 8, padding: '7px 10px', fontSize: 13, fontFamily: 'inherit' }
const submitBtnStyle: React.CSSProperties = { background: '#1e357b', color: '#fff', border: 'none', borderRadius: 8, padding: '7px 16px', fontSize: 12.5, fontWeight: 700, cursor: 'pointer' }
const countTag: React.CSSProperties = { fontSize: 11, fontFamily: 'monospace', background: '#fff4ee', color: '#e65716', borderRadius: 5, padding: '1px 8px' }
const taskRow: React.CSSProperties = { borderTop: '1px solid #eceff3', padding: '12px 4px' }
const typeTag: React.CSSProperties = { fontSize: 10.5, fontWeight: 700, background: '#eef4fd', color: '#1e357b', borderRadius: 5, padding: '2px 9px' }
