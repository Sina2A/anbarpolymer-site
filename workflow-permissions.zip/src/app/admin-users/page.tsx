import prisma from '@/lib/prisma'
import { SECTION_KEYS } from '@/lib/permissions'
import { createStaffUser, setPermission, toggleUserActive } from './actions'

export const dynamic = 'force-dynamic'

export default async function AdminUsersPage() {
  const staff = await prisma.user.findMany({
    where: { role: { in: ['staff', 'admin'] } },
    include: { permissions: true },
    orderBy: { createdAt: 'asc' },
  })

  return (
    <div style={{ padding: '32px 24px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', maxWidth: 980, margin: '0 auto' }}>
      <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 8 }}>مدیریت کاربران و دسترسی‌ها</h1>
      <p style={{ color: '#6f7680', fontSize: 13.5, marginBottom: 28, lineHeight: 1.9 }}>
        هر کارشناس فقط به بخش‌هایی از پنل دسترسی داره که اینجا صراحتاً براش تیک خورده باشه — هیچ نقشی (حتی «مدیر») خودکار دسترسی نمی‌گیره.
      </p>

      <div style={cardStyle}>
        <h3 style={{ fontSize: 15, marginBottom: 14 }}>افزودن کارشناس جدید</h3>
        <form action={createStaffUser} style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
          <input name="companyName" placeholder="نام و نام خانوادگی" required style={inputStyle} />
          <input name="phone" placeholder="شماره تماس" required style={inputStyle} />
          <select name="role" style={inputStyle}>
            <option value="staff">کارشناس</option>
            <option value="admin">مدیر</option>
          </select>
          <button type="submit" style={btnStyle}>افزودن کارشناس</button>
        </form>
        <div style={{ fontSize: 11.5, color: '#9199a3', marginTop: 10 }}>
          ورود واقعی (رمز عبور) وقتی سیستم احراز هویت وصل بشه فعال می‌شه — این فرم فقط حساب و دسترسی‌ها رو از حالا آماده می‌کنه.
        </div>
      </div>

      {staff.length === 0 && (
        <div style={{ color: '#9199a3', fontSize: 13, padding: 20, textAlign: 'center' }}>هنوز هیچ کارشناسی اضافه نشده.</div>
      )}

      {staff.map((u) => (
        <div key={u.id} style={cardStyle}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <div>
              <b style={{ fontSize: 14 }}>{u.companyName}</b>{' '}
              <span style={{ color: '#9199a3', fontSize: 12, fontFamily: 'monospace', direction: 'ltr', display: 'inline-block' }}>— {u.phone}</span>
            </div>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <span style={roleTag(u.role)}>{u.role === 'admin' ? 'مدیر' : 'کارشناس'}</span>
              <form action={toggleUserActive}>
                <input type="hidden" name="userId" value={u.id} />
                <input type="hidden" name="value" value={(!u.isActive).toString()} />
                <button type="submit" style={{ ...statusBtn, ...(u.isActive ? activeStatus : inactiveStatus) }}>
                  {u.isActive ? 'فعال' : 'غیرفعال'}
                </button>
              </form>
            </div>
          </div>

          <table style={{ width: '100%', fontSize: 12.5, borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ color: '#6f7680', textAlign: 'right' }}>
                <th style={thStyle}>بخش پنل</th>
                <th style={{ ...thStyle, width: 90 }}>مشاهده</th>
                <th style={{ ...thStyle, width: 90 }}>ویرایش</th>
              </tr>
            </thead>
            <tbody>
              {SECTION_KEYS.map((sec) => {
                const perm = u.permissions.find((p) => p.section === sec.key)
                return (
                  <tr key={sec.key} style={{ borderTop: '1px solid #eceff3' }}>
                    <td style={tdStyle}>{sec.label}</td>
                    <td style={tdStyle}>
                      <form action={setPermission}>
                        <input type="hidden" name="userId" value={u.id} />
                        <input type="hidden" name="section" value={sec.key} />
                        <input type="hidden" name="field" value="canView" />
                        <input type="hidden" name="value" value={(!perm?.canView).toString()} />
                        <button type="submit" aria-label="مشاهده" style={{ ...checkBtn, background: perm?.canView ? '#22c55e' : '#eceff3', borderColor: perm?.canView ? '#22c55e' : '#c8d0da' }} />
                      </form>
                    </td>
                    <td style={tdStyle}>
                      <form action={setPermission}>
                        <input type="hidden" name="userId" value={u.id} />
                        <input type="hidden" name="section" value={sec.key} />
                        <input type="hidden" name="field" value="canEdit" />
                        <input type="hidden" name="value" value={(!perm?.canEdit).toString()} />
                        <button type="submit" aria-label="ویرایش" style={{ ...checkBtn, background: perm?.canEdit ? '#f6621b' : '#eceff3', borderColor: perm?.canEdit ? '#f6621b' : '#c8d0da' }} />
                      </form>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      ))}
    </div>
  )
}

function roleTag(role: string): React.CSSProperties {
  return {
    fontSize: 10.5,
    fontFamily: 'monospace',
    fontWeight: 700,
    borderRadius: 5,
    padding: '2px 9px',
    background: role === 'admin' ? '#eef4fd' : '#fff4ee',
    color: role === 'admin' ? '#1e357b' : '#e65716',
  }
}

const cardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 22,
  marginBottom: 16,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const inputStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 8, padding: '9px 12px', fontSize: 13, fontFamily: 'inherit' }
const btnStyle: React.CSSProperties = { background: '#1e357b', color: '#fff', border: 'none', borderRadius: 8, padding: '9px 18px', fontSize: 13, fontWeight: 700, cursor: 'pointer' }
const thStyle: React.CSSProperties = { padding: '6px 4px', fontWeight: 600 }
const tdStyle: React.CSSProperties = { padding: '8px 4px' }
const checkBtn: React.CSSProperties = { width: 20, height: 20, borderRadius: 5, border: '1px solid', cursor: 'pointer' }
const statusBtn: React.CSSProperties = { fontSize: 10.5, fontWeight: 700, borderRadius: 5, padding: '3px 10px', border: 'none', cursor: 'pointer' }
const activeStatus: React.CSSProperties = { background: '#dcfce7', color: '#146c3a' }
const inactiveStatus: React.CSSProperties = { background: '#fee2e2', color: '#a8241a' }
