'use server'

import prisma from '@/lib/prisma'
import { revalidatePath } from 'next/cache'
import crypto from 'crypto'

export async function createStaffUser(formData: FormData) {
  const companyName = String(formData.get('companyName') || '').trim()
  const phone = String(formData.get('phone') || '').trim()
  const role = String(formData.get('role') || 'staff')
  if (!companyName || !phone) return

  await prisma.user.create({
    data: {
      companyName,
      phone,
      role,
      // رمز موقت تصادفی — تا وقتی سیستم Auth واقعی (فاز ۴) وصل بشه، این حساب فقط
      // برای گرفتن دسترسی‌های پنل ساخته می‌شه؛ ورود واقعی بعداً اضافه می‌شه.
      passwordHash: crypto.randomBytes(16).toString('hex'),
    },
  })
  revalidatePath('/admin-users')
}

export async function toggleUserActive(formData: FormData) {
  const userId = String(formData.get('userId'))
  const value = formData.get('value') === 'true'
  await prisma.user.update({ where: { id: userId }, data: { isActive: value } })
  revalidatePath('/admin-users')
}

export async function setPermission(formData: FormData) {
  const userId = String(formData.get('userId'))
  const section = String(formData.get('section'))
  const field = String(formData.get('field')) as 'canView' | 'canEdit'
  const value = formData.get('value') === 'true'

  await prisma.permission.upsert({
    where: { userId_section: { userId, section } },
    update: { [field]: value },
    create: {
      userId,
      section,
      canView: field === 'canView' ? value : false,
      canEdit: field === 'canEdit' ? value : false,
    },
  })
  revalidatePath('/admin-users')
}
