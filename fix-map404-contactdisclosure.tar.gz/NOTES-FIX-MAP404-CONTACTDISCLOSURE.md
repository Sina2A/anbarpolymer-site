# رفع فوری — نقشه ۴۰۴ + آکاردئون تماس‌با‌ما

## ۱) نقشه ۴۰۴ — علت واقعی (با خواندن کد، نه حدس)

- مسیر fetch در `IranMap.tsx` درست است: `fetch('/geoBoundaries-IRN-ADM3.topojson')` ↔ `public/geoBoundaries-IRN-ADM3.topojson`. اختلاف مسیری وجود ندارد.
- **علت:** `middleware.ts` (آخرین نسخه از بسته‌ی `Fix-surface-buildtime`) فایل‌های استاتیک را فقط با این پسوندها از middleware مستثنا می‌کند: `png|svg|ico|webp|jpg|jpeg|gif|woff2?|ttf`.
  پسوند `.topojson` در این فهرست نیست ← درخواست فایل نقشه وارد middleware می‌شود ← روی `SURFACE=admin` چون مسیر با `/admin-` شروع نمی‌شود، به `/404` **rewrite** می‌شود.
  نتیجه: `LocationPicker` در `/admin-warehouses` و `/admin-kyc` روی سطح ادمین همیشه ۴۰۴ می‌گیرد.
- **رفع:** افزودن `topojson` به فهرست پسوندهای مستثنا در `matcher` (تست regex: `/geoBoundaries-IRN-ADM3.topojson` دیگر از middleware عبور نمی‌کند؛ `/admin-warehouses` و `/contact` مثل قبل عبور می‌کنند).

### ⚠️ نکته درباره‌ی `/warehouses`
پیام «هیچ انباری با موقعیت جغرافیایی ثبت‌شده وجود ندارد» **پیام خطای نقشه نیست**. این پیام در `WarehousesMap.tsx` فقط وقتی نشان داده می‌شود که هیچ انباری `latitude/longitude` نداشته باشد — در این حالت `IranMap` اصلاً mount نمی‌شود و fetch هم انجام نمی‌شود (خطای نقشه متن دیگری دارد: «بارگذاری نقشه ناموفق بود»).
یعنی: هنوز برای هیچ انباری مختصات ثبت نشده. بعد از نصب این بسته، از `/admin-warehouses` (که حالا نقشه‌اش باز می‌شود) مختصات انبارها را ثبت کنید تا نقشه‌ی `/warehouses` ظاهر شود.

## ۲) `ContactInfoDisclosure` رندر نمی‌شود — علت واقعی

کد تحویل قبلی (`contact/page.tsx` + `ContactInfoDisclosure.tsx`) درست است و هیچ شرط SSR/State که خروجی را خالی کند ندارد.
اما علامت دقیقِ گزارش‌شده («نه دکمه، نه کارت») فقط در یک ترکیب رخ می‌دهد — با Playwright در عرض ۳۹۰px تأیید شد:

| ترکیب روی سرور | دکمه | کارت‌ها |
|---|---|---|
| `page.tsx` **قدیمی** + `globals.css` **جدید** | ❌ | ❌ ← همین علامت |
| `page.tsx` جدید + `globals.css` جدید | ✅ | بسته (با کلیک باز) |

چون CSS جدید در موبایل `.contact-grid__info { display:none }` می‌گذارد و فقط با کلاس `is-open` (که تنها `ContactInfoDisclosure` اضافه می‌کند) نمایش می‌دهد. یعنی روی سرور `globals.css` جدید است ولی `src/app/contact/page.tsx` هنوز نسخه‌ی قبلی (بدون `ContactInfoDisclosure`) است — یا build جاری قبل از جایگزینی آن گرفته شده.

**چرا `tsc`/`build` این را نگرفت:** هر دو فایلِ قدیمی و جدید به‌تنهایی معتبرند؛ این یک ناهماهنگیِ نصب بین دو فایل روی سرور است، نه خطای کد. `tsc` و `build` فقط روی محیط سازنده اجرا شدند، نه روی فایل‌های واقعیِ سرور. به‌علاوه، قاعده‌ی CSS «خاموش» شکست می‌خورد (المان پنهان می‌شود، هیچ خطایی نمی‌دهد).

**رفع (مقاوم‌سازی):** قاعده‌ی پنهان‌کردن در `globals.css` محدود شد به `.contact-disclosure .contact-grid__info` — پس حتی اگر `page.tsx` قدیمی سرو شود، کارت‌ها دیگر ناپدید نمی‌شوند. `page.tsx` و `ContactInfoDisclosure.tsx` هم دوباره (بدون تغییر) ضمیمه شده‌اند تا نسخه‌ی درست روی سرور قرار بگیرد.

## فایل‌های این بسته
- `middleware.ts` — ✏️ افزودن `topojson` به matcher
- `src/app/globals.css` — ✏️ scope کردن قاعده‌ی پنهان‌سازیِ کارت‌ها
- `src/app/contact/page.tsx` — بدون تغییر (ضمیمه‌ی مجدد)
- `src/components/ContactInfoDisclosure.tsx` — بدون تغییر (ضمیمه‌ی مجدد)
- `public/geoBoundaries-IRN-ADM3.topojson` — بدون تغییر (ضمیمه‌ی مجدد، ۲.۷MB)

## بررسی روی سرور (قبل از نصب — برای تأیید تشخیص)
```bash
# فایل نقشه همین الان وجود دارد؟
ls -lh public/geoBoundaries-IRN-ADM3.topojson
# contact/page.tsx روی سرور نسخه‌ی جدید است؟ (خروجی خالی = قدیمی)
grep -n "ContactInfoDisclosure" src/app/contact/page.tsx
ls -l src/components/ContactInfoDisclosure.tsx
# پاسخ هر سطح به فایل نقشه (پورت‌ها را با پورت‌های واقعی جایگزین کنید)
curl -sI http://localhost:<PUBLIC_PORT>/geoBoundaries-IRN-ADM3.topojson | head -1
curl -sI http://localhost:<ADMIN_PORT>/geoBoundaries-IRN-ADM3.topojson | head -1
```

## نصب
```bash
tar -xzf fix-map404-contactdisclosure.tar.gz
grep -n "topojson" middleware.ts            # باید matcher را نشان دهد
grep -n "ContactInfoDisclosure" src/app/contact/page.tsx   # باید ۳ خط نشان دهد
npm run build        # حتماً بعد از extract (Next فقط فایل‌های public موجود در زمان build را سرو می‌کند)
# ری‌استارت هر سه سطح (public / admin / transport) طبق روال همیشگی
```
پس از ری‌استارت، روی موبایل یک‌بار صفحه را با کشیدن به پایین (refresh) باز کنید.
