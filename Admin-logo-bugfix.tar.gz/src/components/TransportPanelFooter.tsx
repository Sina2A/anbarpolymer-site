import { BrandCoin } from '@/components/BrandMark'

export default function TransportPanelFooter({ homeHref = '/' }: { homeHref?: string }) {
  return (
    <footer className="transport-panel-footer">
      <a className="transport-panel-footer-brand" href={homeHref}>
        <BrandCoin coin={36} mark={30} />
        <span>انبار پلیمر</span>
      </a>
      <p>© تمامی حقوق برای انبار پلیمر محفوظ است.</p>
      <a href="tel:+982191234567">پشتیبانی: ۰۲۱-۹۱۲۳۴۵۶۷</a>
    </footer>
  )
}
