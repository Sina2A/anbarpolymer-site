import prisma from '@/lib/prisma'
import { getAllSectionAccess } from '@/lib/permissions'
import { getCurrentUser } from '@/lib/currentUser'
import AdminNav, { PartialAccessBanner } from '@/components/AdminNav'
import { toggleReadAction, toggleArchiveAction } from './actions'
import {
  pageStyle, pageWrapStyle, contentStyle,
  h1Style, subTitleStyle, cardStyle,
  tableStyle, theadRowStyle, thStyle, tdStyle,
  badgeStyle, btnPrimaryStyle, btnSecondaryStyle, btnDangerStyle,
  inputStyle, selectStyle, labelStyle, emptyStateStyle,
} from '@/lib/styles/shared'
import { getSurfaceHome } from '@/lib/surfaceHome'

export const dynamic = 'force-dynamic'

type SearchParams = Promise<Record<string, string | string[] | undefined>>

function one(v: string | string[] | undefined): string | undefined {
  if (Array.isArray(v)) return v[0]
  return v
}

const TABS: { key: string; label: string }[] = [
  { key: 'all', label: 'فعال' },
  { key: 'unread', label: 'خوانده‌نشده' },
  { key: 'read', label: 'خوانده‌شده' },
  { key: 'archived', label: 'بایگانی' },
]

export default async function AdminContactPage({ searchParams }: { searchParams: SearchParams }) {
  const sp = await searchParams
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)
  const myLevel = isAdmin ? 'full' : (myAccess?.['contact'] ?? 'none')
  const canEdit = myLevel === 'full' || myLevel === 'edit'

  const activeTab = one(sp.tab) || 'all'

  // «فعال» یعنی بایگانی‌نشده؛ بایگانی‌شده‌ها تب خودشون رو دارن
  let where: { archived: boolean; isRead?: boolean }
  if (activeTab === 'archived') where = { archived: true }
  else if (activeTab === 'unread') where = { archived: false, isRead: false }
  else if (activeTab === 'read') where = { archived: false, isRead: true }
  else where = { archived: false }

  const messages = await prisma.contactMessage.findMany({
    where,
    orderBy: { createdAt: 'desc' },
  })

  // شمارش برای تب‌ها — گروه‌بندی روی ترکیب archived×isRead
  const groups = await prisma.contactMessage.groupBy({
    by: ['archived', 'isRead'],
    _count: { _all: true },
  })
  let unread = 0
  let read = 0
  let archivedTotal = 0
  for (const g of groups) {
    const n = g._count._all
    if (g.archived) archivedTotal += n
    else if (g.isRead) read += n
    else unread += n
  }
  const activeTotal = unread + read
  const tabCount: Record<string, number> = {
    all: activeTotal, unread, read, archived: archivedTotal,
  }

  return (
    <div style={pageStyle}>
      <div style={pageWrapStyle}>
        <AdminNav currentUserName={currentUser.companyName} currentUsername={currentUser.username} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="contact" homeHref={getSurfaceHome()} />

        <div style={contentStyle}>
          <PartialAccessBanner level={myLevel} sectionLabel="پیام‌های تماس با ما" />

          <h1 style={h1Style}>پیام‌های تماس با ما</h1>
          <p style={subTitleStyle}>
            پیام‌هایی که بازدیدکننده‌های مهمون از فرم عمومی /contact فرستادن — اینجا فقط خونده یا بایگانی می‌شن؛ جوابی از توی سیستم داده نمی‌شه.
          </p>

          {/* ── تب‌های فیلتر ── */}
          <div style={{ display: 'flex', gap: 8, marginBottom: 18, flexWrap: 'wrap' }}>
            {TABS.map((tab) => {
              const isActive = activeTab === tab.key
              const n = tabCount[tab.key] || 0
              return (
                <a
                  key={tab.key}
                  href={`/admin-contact?tab=${tab.key}`}
                  style={{
                    padding: '7px 16px', borderRadius: 8, fontSize: 12.5, fontWeight: 700,
                    textDecoration: 'none', border: '1px solid',
                    borderColor: isActive ? '#1e357b' : '#d8dde3',
                    background: isActive ? '#1e357b' : '#fff',
                    color: isActive ? '#fff' : '#4f5560',
                  }}
                >
                  {tab.label} <span style={{ opacity: 0.75, fontFamily: 'monospace' }}>({n})</span>
                </a>
              )
            })}
          </div>

          {/* ── لیست پیام‌ها ── */}
          {messages.length === 0 ? (
            <div style={emptyStateStyle}>پیامی در این دسته نیست.</div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {messages.map((m) => (
                <div key={m.id} style={cardStyle}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, marginBottom: 8, flexWrap: 'wrap' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                      <b style={{ fontSize: 14, color: '#1b1e24' }}>{m.name}</b>
                      {!m.isRead && <span style={badgeStyle('warning')}>جدید</span>}
                      {m.archived && <span style={badgeStyle('neutral')}>بایگانی‌شده</span>}
                    </div>
                    <span style={{ fontSize: 10.5, color: '#9199a3', direction: 'ltr', fontFamily: 'monospace' }}>
                      {new Date(m.createdAt).toLocaleDateString('fa-IR')} {new Date(m.createdAt).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  <div style={{ fontSize: 12, color: '#6f7680', marginBottom: 8 }}>
                    راه تماس: <b style={{ direction: 'ltr', fontFamily: 'monospace', color: '#4f5560', unicodeBidi: 'embed' }}>{m.contact}</b>
                  </div>

                  <div style={{ fontSize: 13, lineHeight: 1.8, whiteSpace: 'pre-wrap', color: '#1b1e24', borderTop: '1px solid #eceff3', paddingTop: 10 }}>
                    {m.body}
                  </div>

                  {canEdit && (
                    <div style={{ display: 'flex', gap: 8, marginTop: 12, paddingTop: 10, borderTop: '1px solid #eceff3', flexWrap: 'wrap' }}>
                      <form action={toggleReadAction}>
                        <input type="hidden" name="id" value={m.id} />
                        <input type="hidden" name="isRead" value={m.isRead ? '0' : '1'} />
                        <button type="submit" style={btnSecondaryStyle}>
                          {m.isRead ? 'علامت‌گذاری خوانده‌نشده' : 'علامت‌گذاری خوانده‌شده'}
                        </button>
                      </form>
                      <form action={toggleArchiveAction}>
                        <input type="hidden" name="id" value={m.id} />
                        <input type="hidden" name="archived" value={m.archived ? '0' : '1'} />
                        <button type="submit" style={m.archived ? btnSecondaryStyle : btnDangerStyle}>
                          {m.archived ? 'خروج از بایگانی' : 'بایگانی'}
                        </button>
                      </form>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {!canEdit && messages.length > 0 && (
            <p style={{ fontSize: 11.5, color: '#9199a3', marginTop: 12 }}>
              برای علامت‌گذاری یا بایگانی، دسترسی ویرایش این بخش لازمه.
            </p>
          )}
        </div>
      </div>
    </div>
  )
}
