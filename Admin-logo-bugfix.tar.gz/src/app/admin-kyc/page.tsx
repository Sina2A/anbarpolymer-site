import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import AdminNav from '@/components/AdminNav'
import { pageStyle, pageWrapStyle, contentStyle, h1Style, subTitleStyle, tableStyle, theadRowStyle, thStyle, tdStyle } from '@/lib/styles/shared'
import { getSurfaceHome } from '@/lib/surfaceHome'

export const dynamic = 'force-dynamic'

const LEVEL_LABELS = ['کاربر ساده', 'شرکت تایید‌شده', 'تولیدکننده‌ی تایید‌شده']
const LEVEL_COLORS = ['#6f7680', '#1e357b', '#146c3a']

export default async function AdminKycListPage() {
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'

  if (!isAdmin) {
    return (
      <div style={pageStyle}><div style={pageWrapStyle}>
        <AdminNav currentUserName={currentUser.companyName} currentUsername={currentUser.username} isAdmin={isAdmin} accessMap={{}} activeSection="kyc" homeHref={getSurfaceHome()} />
        <div style={contentStyle}>این بخش (نمایش/ویرایش کامل پرونده‌ی احراز هویت) فقط برای نقش «مدیر» در دسترسه. برای بررسی موارد در انتظار، از صفحه‌ی «مدیریت کاربران و دسترسی‌ها» استفاده کن.</div>
      </div></div>
    )
  }

  const companies = await prisma.company.findMany({
    include: { kyc: true, user: true },
    orderBy: { createdAt: 'desc' },
  })

  return (
    <div style={pageStyle}><div style={pageWrapStyle}>
      <AdminNav currentUserName={currentUser.companyName} currentUsername={currentUser.username} isAdmin={isAdmin} accessMap={{}} activeSection="kyc" homeHref={getSurfaceHome()} />

      <div style={contentStyle}>
        <h1 style={h1Style}>پرونده‌ی کامل احراز هویت</h1>
        <p style={subTitleStyle}>
          نمایش و ویرایش کامل هر فیلد — چه دستی پرشده چه (بعداً) از طریق API — فقط برای نقش «مدیر». برای بررسی سریع موارد در انتظار، صفحه‌ی «مدیریت کاربران و دسترسی‌ها» راحت‌تره؛ این‌جا برای وقتیه که نیاز به دیدن/اصلاح همه‌چیز داری.
        </p>

        <div style={{ border: '1px solid #d8dde3', borderRadius: 12, overflow: 'hidden' }}>
          <table style={tableStyle}>
            <thead>
              <tr style={theadRowStyle}>
                <th style={thStyle}>شرکت</th>
                <th style={thStyle}>شماره تماس</th>
                <th style={thStyle}>سطح فعلی</th>
                <th style={thStyle}>بج</th>
                <th style={thStyle}></th>
              </tr>
            </thead>
            <tbody>
              {companies.length === 0 ? (
                <tr><td colSpan={5} style={{ ...tdStyle, textAlign: 'center', color: '#9199a3', padding: 24 }}>هنوز هیچ شرکتی ثبت نشده.</td></tr>
              ) : companies.map((c) => {
                const level = c.kyc?.level ?? 0
                return (
                  <tr key={c.id} style={{ borderTop: '1px solid #eceff3' }}>
                    <td style={{ ...tdStyle, fontWeight: 700 }}>{c.companyName}</td>
                    <td style={{ ...tdStyle, fontFamily: 'monospace', direction: 'ltr', textAlign: 'right' }}>{c.user.phone}</td>
                    <td style={tdStyle}><span style={{ color: LEVEL_COLORS[level], fontWeight: 700 }}>{LEVEL_LABELS[level]}</span></td>
                    <td style={{ ...tdStyle, fontFamily: 'monospace', fontSize: 11 }}>{c.kyc?.badge ?? 'none'}</td>
                    <td style={tdStyle}><a href={`/admin-kyc/${c.id}`} style={{ color: '#1e357b', fontWeight: 700 }}>مشاهده/ویرایش کامل ↗</a></td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div></div>
  )
}
