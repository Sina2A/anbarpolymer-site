import prisma from '@/lib/prisma'
import { getSurfaceHome } from '@/lib/surfaceHome'
import { getCurrentUserOrNull } from '@/lib/currentUser'
import CurrencyTicker from '@/components/CurrencyTicker'
import PublicHeader from '@/components/PublicHeader'
import Footer from '@/components/Footer'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'

export const dynamic = 'force-dynamic'

export default async function AboutPage() {
  const user = await getCurrentUserOrNull()
  const now = new Date()

  // ── آمار زنده از دیتابیس ──
  // نکته‌ی امنیتی: هیچ رکورد User سریالایز نمی‌شود؛ فقط شمارش و میانگین.
  const [gradeCount, activeListingCount, warehouseCount, publishedArticleCount, reviewAgg] = await Promise.all([
    prisma.grade.count({ where: { isActive: true } }),
    prisma.materialListing.count({ where: { validityStatus: 'active' } }),
    prisma.warehouse.count(),
    prisma.article.count({ where: { isPublished: true, publishedAt: { not: null, lte: now } } }),
    prisma.review.aggregate({ _avg: { rating: true }, _count: true }),
  ])
  const ratingAvg = reviewAgg._avg.rating
  const ratingCount = reviewAgg._count

  return (
    <>
      <CurrencyTicker />
      <PublicHeader homeHref={getSurfaceHome()} activePage="/about" isLoggedIn={!!user} />

      {/* ═══ Hero: ارزش پیشنهادی — نه فقط معرفی ═══ */}
      <section style={heroSectionStyle}>
        <div className="wrap">
          <div style={heroInnerStyle}>
            <div style={eyebrowStyle}>درباره انبار پلیمر</div>
            <h1 style={heroH1Style}>تجارت مواد اولیه پلیمری، با اطلاعات شفاف‌تر و فرآیند مطمئن‌تر</h1>
            <p style={heroPStyle}>
              انبار پلیمر برای ساده‌تر کردن خرید، بررسی مشخصات و مدیریت فرآیند تأمین مواد اولیه پلیمری برای کارخانه‌های تولیدی ساخته شده است.
            </p>
            <div style={heroPointsStyle}>
              <span style={heroPointStyle}>✓ مشخصات فنی استاندارد</span>
              <span style={heroPointStyle}>✓ قیمت و شرایط شفاف</span>
              <span style={heroPointStyle}>✓ فرآیند مشخص تأمین</span>
              <span style={heroPointStyle}>✓ پیگیری تا تحویل</span>
            </div>
          </div>
        </div>
      </section>

      {/* ═══ Problem → Solution: دو کارت کنار هم، یکی روشن یکی تیره ═══ */}
      <section className="section-line" style={sectionPadStyle}>
        <div className="wrap">
          <div style={sectionHeadStyle}>
            <div style={eyebrowStyle}>مسئله و راه‌حل</div>
            <h2 style={h2Style}>چرا انبار پلیمر ساخته شد؟</h2>
            <p style={sectionHintStyle}>برای کاهش ابهام و ریسک‌هایی که در خرید سنتی مواد اولیه پلیمری وجود دارد.</p>
          </div>

          <div style={problemGridStyle}>
            <article style={problemCardLightStyle}>
              <div style={cardLabelLightStyle}>بازار سنتی</div>
              <h3 style={problemH3LightStyle}>چالش‌هایی که خریدار با آن روبه‌روست</h3>
              <div style={problemListStyle}>
                <div style={problemItemLightStyle}><span style={problemNumLightStyle}>01</span> اطلاعات فنی و تجاری در منابع مختلف پراکنده است.</div>
                <div style={problemItemLightStyle}><span style={problemNumLightStyle}>02</span> مقایسه گریدها و شرایط خرید همیشه ساده نیست.</div>
                <div style={problemItemLightStyle}><span style={problemNumLightStyle}>03</span> قیمت، شرایط پرداخت و تحویل می‌تواند مبهم باشد.</div>
                <div style={problemItemLightStyle}><span style={problemNumLightStyle}>04</span> احراز هویت و سوابق طرفین نیازمند بررسی جداگانه است.</div>
              </div>
            </article>

            <article style={problemCardDarkStyle}>
              <div style={cardLabelDarkStyle}>راه‌حل انبار پلیمر</div>
              <h3 style={problemH3DarkStyle}>یک فرآیند ساختاریافته برای تأمین</h3>
              <p style={problemDarkIntroStyle}>
                انبار پلیمر تلاش می‌کند اطلاعات محصول، مشخصات فنی و فرآیند معامله را در یک مسیر مشخص کنار هم قرار دهد تا تصمیم‌گیری برای خریدار ساده‌تر شود.
              </p>
              <div style={problemListStyle}>
                <div style={problemItemDarkStyle}><span style={problemNumDarkStyle}>✓</span> کاتالوگ گریدها با اطلاعات فنی قابل بررسی</div>
                <div style={problemItemDarkStyle}><span style={problemNumDarkStyle}>✓</span> استعلام قیمت و شرایط معامله</div>
                <div style={problemItemDarkStyle}><span style={problemNumDarkStyle}>✓</span> احراز هویت و ثبت سوابق فرآیند</div>
                <div style={problemItemDarkStyle}><span style={problemNumDarkStyle}>✓</span> پیگیری مراحل تا تحویل کالا</div>
              </div>
            </article>
          </div>
        </div>
      </section>

      {/* ═══ ارزش‌های اصلی — ۴ کارت مستقل شماره‌دار ═══ */}
      <section className="section-line" style={{ ...sectionPadStyle, background: '#fff' }}>
        <div className="wrap">
          <div style={sectionHeadStyle}>
            <div style={eyebrowStyle}>ارزش پیشنهادی</div>
            <h2 style={h2Style}>چرا انبار پلیمر؟</h2>
            <p style={sectionHintStyle}>چهار ویژگی که تجربه تأمین را برای خریدار صنعتی ساده‌تر و قابل‌کنترل‌تر می‌کند.</p>
          </div>

          <div style={valuesGridStyle}>
            <article style={valueCardStyle} className="about-hover-card">
              <div style={valueNoStyle}>01</div>
              <h3 style={valueH3Style}>شفافیت اطلاعات</h3>
              <p style={valuePStyle}>مشخصات فنی، گرید و مستندات محصول در قالبی منظم و قابل بررسی ارائه می‌شود.</p>
            </article>
            <article style={valueCardStyle} className="about-hover-card">
              <div style={valueNoStyle}>02</div>
              <h3 style={valueH3Style}>شفافیت قیمت</h3>
              <p style={valuePStyle}>قیمت و شرایط معامله بر اساس مشخصات محصول و شرایط واقعی خرید به خریدار اعلام می‌شود.</p>
            </article>
            <article style={valueCardStyle} className="about-hover-card">
              <div style={valueNoStyle}>03</div>
              <h3 style={valueH3Style}>کنترل فرآیند</h3>
              <p style={valuePStyle}>مراحل درخواست، تأیید، پرداخت، آماده‌سازی و تحویل در یک مسیر مشخص دنبال می‌شوند.</p>
            </article>
            <article style={valueCardStyle} className="about-hover-card">
              <div style={valueNoStyle}>04</div>
              <h3 style={valueH3Style}>امنیت معامله</h3>
              <p style={valuePStyle}>احراز هویت طرفین و ثبت سوابق، به کاهش ریسک‌های عملیاتی معامله کمک می‌کند.</p>
            </article>
          </div>
        </div>
      </section>

      {/* ═══ مسیر خرید — ۶ قدم افقی با خط اتصال ═══ */}
      <section className="section-line" style={sectionPadStyle}>
        <div className="wrap">
          <div style={sectionHeadStyle}>
            <div style={eyebrowStyle}>مسیر خرید</div>
            <h2 style={h2Style}>چطور با انبار پلیمر خرید می‌کنید؟</h2>
            <p style={sectionHintStyle}>یک مسیر روشن از انتخاب گرید تا تحویل کالا.</p>
          </div>

          <div style={processTrackStyle}>
            <div style={stepStyle}><div style={stepNoStyle}>01</div><h3 style={stepH3Style}>انتخاب گرید</h3><p style={stepPStyle}>پیدا کردن ماده مناسب</p></div>
            <div style={stepStyle}><div style={stepNoStyle}>02</div><h3 style={stepH3Style}>بررسی مشخصات</h3><p style={stepPStyle}>مطالعه مشخصات و مستندات</p></div>
            <div style={stepStyle}><div style={stepNoStyle}>03</div><h3 style={stepH3Style}>استعلام</h3><p style={stepPStyle}>دریافت قیمت و شرایط</p></div>
            <div style={stepStyle}><div style={stepNoStyle}>04</div><h3 style={stepH3Style}>تأیید معامله</h3><p style={stepPStyle}>تأیید شرایط خرید</p></div>
            <div style={stepStyle}><div style={stepNoStyle}>05</div><h3 style={stepH3Style}>پرداخت و آماده‌سازی</h3><p style={stepPStyle}>تکمیل مراحل مالی</p></div>
            <div style={stepStyle}><div style={stepNoAccentStyle}>06</div><h3 style={stepH3Style}>تحویل کالا</h3><p style={stepPStyle}>پیگیری تا تحویل</p></div>
          </div>
        </div>
      </section>

      {/* ═══ سه اصل معامله (Trust) — ۳ کارت مستقل ═══ */}
      <section className="section-line" style={{ ...sectionPadStyle, background: '#fff' }}>
        <div className="wrap">
          <div style={sectionHeadStyle}>
            <div style={eyebrowStyle}>اصول معامله</div>
            <h2 style={h2Style}>سه اصل اصلی که معامله را امن‌تر می‌کند</h2>
            <p style={sectionHintStyle}>همه امکانات انبار پلیمر حول این سه اصل طراحی شده‌اند.</p>
          </div>

          <div style={principlesGridStyle}>
            <article style={principleCardStyle} className="about-hover-card">
              <div style={principleNoStyle}>01</div>
              <h3 style={principleH3Style}>شفافیت قیمت</h3>
              <p style={principlePStyle}>قیمت و شرایط معامله باید برای خریدار قابل فهم، قابل بررسی و متناسب با مشخصات واقعی کالا باشد.</p>
            </article>
            <article style={principleCardStyle} className="about-hover-card">
              <div style={principleNoStyle}>02</div>
              <h3 style={principleH3Style}>اصالت و کیفیت کالا</h3>
              <p style={principlePStyle}>مشخصات فنی و مستندات کالا پیش از معامله در اختیار خریدار قرار می‌گیرد تا بررسی دقیق‌تری انجام شود.</p>
            </article>
            <article style={principleCardStyle} className="about-hover-card">
              <div style={principleNoStyle}>03</div>
              <h3 style={principleH3Style}>امنیت معامله</h3>
              <p style={principlePStyle}>احراز هویت طرفین و ثبت مراحل معامله، پرداخت و تحویل، ریسک عملیاتی معامله را کاهش می‌دهد.</p>
            </article>
          </div>
        </div>
      </section>

      {/* ═══ KPI زنده — مستقیم از دیتابیس ═══ */}
      <section className="section-line" style={sectionPadStyle}>
        <div className="wrap">
          <div style={sectionHeadStyle}>
            <div style={eyebrowStyle}>آمار به‌زبان اعداد</div>
            <h2 style={h2Style}>انبار پلیمر در یک نگاه</h2>
            <p style={sectionHintStyle}>آمار زنده، مستقیم از پلتفرم — نه عدد تبلیغاتی.</p>
          </div>
          <div className="kpi-row">
            <div className="kpi">
              <div className="k">گریدهای فعال</div>
              <div className="v">{gradeCount.toLocaleString('fa-IR')}</div>
            </div>
            <div className="kpi">
              <div className="k">آگهی‌های عرضه‌ی فعال</div>
              <div className="v">{activeListingCount.toLocaleString('fa-IR')}</div>
            </div>
            <div className="kpi">
              <div className="k">انبارهای زیر پوشش</div>
              <div className="v">{warehouseCount.toLocaleString('fa-IR')}</div>
            </div>
            <div className="kpi">
              <div className="k">گزارش‌های منتشرشده</div>
              <div className="v">{publishedArticleCount.toLocaleString('fa-IR')}</div>
            </div>
          </div>
          {ratingAvg !== null && ratingCount > 0 && (
            <p style={ratingLineStyle}>
              میانگین رضایت طرف‌های معامله:{' '}
              <b style={{ color: 'var(--ink)' }}>{(Math.round(ratingAvg * 10) / 10).toLocaleString('fa-IR')}</b> از ۵ —
              بر اساس {ratingCount.toLocaleString('fa-IR')} امتیاز ثبت‌شده پس از تحویل کالا.
            </p>
          )}
        </div>
      </section>

      {/* ═══ CTA نهایی — دو دکمه به تفکیک نیت کاربر ═══ */}
      <section style={ctaSectionStyle}>
        <div className="wrap">
          <div style={ctaBoxStyle}>
            <div>
              <h2 style={ctaH2Style}>آماده شروع هستید؟</h2>
              <p style={ctaPStyle}>برای خرید مواد اولیه، گرید موردنظر خود را بررسی کنید یا برای همکاری با ما در ارتباط باشید.</p>
            </div>
            <div style={ctaButtonsStyle}>
              <a href="/grades" style={ctaPrimaryBtnStyle}>مشاهده گریدها</a>
              <a href="/services" style={ctaSecondaryBtnStyle}>خدمات سازمانی</a>
            </div>
          </div>
        </div>
      </section>

      <Footer homeHref={getSurfaceHome()} />
    </>
  )
}

// ── Styles ──
const sectionPadStyle: React.CSSProperties = { padding: '60px 0' }

const eyebrowStyle: React.CSSProperties = {
  fontSize: 11,
  fontWeight: 700,
  letterSpacing: '0.06em',
  color: colors.orange,
  marginBottom: 8,
  display: 'flex',
  alignItems: 'center',
  gap: 8,
}
const h2Style: React.CSSProperties = {
  fontSize: 22,
  fontWeight: 800,
  color: colors.textPrimary,
  margin: '0 0 6px',
  lineHeight: 1.45,
}
const sectionHintStyle: React.CSSProperties = {
  fontSize: 12.5,
  color: colors.textSecondary,
  margin: 0,
  lineHeight: 1.9,
}
const sectionHeadStyle: React.CSSProperties = { marginBottom: 28 }

// ── Hero ──
const heroSectionStyle: React.CSSProperties = {
  padding: '56px 0 52px',
  borderBottom: `1px solid ${colors.borderSubtle}`,
  background: 'linear-gradient(180deg, #fbfcfe 0%, #f5f7fa 100%)',
  position: 'relative',
  overflow: 'hidden',
}
const heroInnerStyle: React.CSSProperties = { maxWidth: 790, position: 'relative', zIndex: 1 }
const heroH1Style: React.CSSProperties = {
  fontSize: 28,
  fontWeight: 800,
  lineHeight: 1.5,
  color: colors.textPrimary,
  margin: '0 0 10px',
  letterSpacing: '-0.02em',
}
const heroPStyle: React.CSSProperties = {
  fontSize: 13.5,
  color: colors.textSecondary,
  lineHeight: 2,
  margin: 0,
  maxWidth: 700,
}
const heroPointsStyle: React.CSSProperties = {
  display: 'flex',
  gap: 10,
  flexWrap: 'wrap',
  marginTop: 22,
}
const heroPointStyle: React.CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  gap: 6,
  background: colors.bgCard,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: 9,
  padding: '8px 13px',
  fontSize: 11.5,
  color: colors.textSecondary,
  fontWeight: 600,
  boxShadow: '0 6px 20px rgba(20,44,86,.035)',
}

// ── Problem / Solution ──
const problemGridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: '1fr 1.15fr',
  gap: 20,
  alignItems: 'stretch',
}
const problemCardLightStyle: React.CSSProperties = {
  background: colors.bgCard,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: 15,
  padding: 24,
  boxShadow: '0 10px 32px rgba(23,48,91,.045)',
}
const cardLabelLightStyle: React.CSSProperties = { fontSize: 10, fontWeight: 700, color: colors.orange, marginBottom: 14 }
const cardLabelDarkStyle: React.CSSProperties = { fontSize: 10, fontWeight: 700, color: '#ff9c70', marginBottom: 14 }
const problemH3LightStyle: React.CSSProperties = { fontSize: 16, fontWeight: 800, color: colors.textPrimary, margin: '0 0 14px' }
const problemH3DarkStyle: React.CSSProperties = { fontSize: 16, fontWeight: 800, color: '#fff', margin: '0 0 10px' }
const problemDarkIntroStyle: React.CSSProperties = { fontSize: 11.5, color: '#dce4f5', lineHeight: 2.1, margin: '0 0 14px' }
const problemListStyle: React.CSSProperties = { display: 'grid', gap: 9 }
const problemItemLightStyle: React.CSSProperties = { display: 'flex', alignItems: 'flex-start', gap: 9, fontSize: 11.5, lineHeight: 1.9, color: colors.textSecondary }
const problemItemDarkStyle: React.CSSProperties = { display: 'flex', alignItems: 'flex-start', gap: 9, fontSize: 11.5, lineHeight: 1.9, color: '#e8edf7' }
const problemNumLightStyle: React.CSSProperties = {
  flex: '0 0 21px',
  width: 21,
  height: 21,
  borderRadius: 6,
  display: 'grid',
  placeItems: 'center',
  background: colors.orangeBg,
  color: colors.orange,
  fontSize: 9,
  fontWeight: 800,
}
const problemNumDarkStyle: React.CSSProperties = {
  ...problemNumLightStyle,
  background: 'rgba(255,255,255,.12)',
  color: '#fff',
}
const problemCardDarkStyle: React.CSSProperties = {
  background: colors.navy,
  border: `1px solid ${colors.navy}`,
  borderRadius: 15,
  padding: 24,
  color: '#fff',
  position: 'relative',
  overflow: 'hidden',
}

// ── Values ──
const valuesGridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(4, 1fr)',
  gap: 14,
}
const valueCardStyle: React.CSSProperties = {
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: 14,
  padding: '22px 20px',
  background: colors.bgCard,
  position: 'relative',
  overflow: 'hidden',
  minHeight: 170,
  borderRight: `4px solid ${colors.orange}`,
}
const valueNoStyle: React.CSSProperties = {
  width: 31,
  height: 31,
  borderRadius: 8,
  background: colors.orangeBg,
  color: colors.orange,
  display: 'grid',
  placeItems: 'center',
  fontSize: 10,
  fontWeight: 800,
  marginBottom: 14,
}
const valueH3Style: React.CSSProperties = { fontSize: 14, fontWeight: 800, color: colors.textPrimary, margin: '0 0 7px' }
const valuePStyle: React.CSSProperties = { fontSize: 11.5, color: colors.textSecondary, lineHeight: 2, margin: 0 }

// ── Process (6 steps) ──
const processTrackStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(6, 1fr)',
  gap: 0,
  marginTop: 28,
}
const stepStyle: React.CSSProperties = { textAlign: 'center', padding: '0 8px', position: 'relative' }
const stepNoStyle: React.CSSProperties = {
  width: 40,
  height: 40,
  margin: '0 auto 12px',
  borderRadius: 50,
  display: 'grid',
  placeItems: 'center',
  background: colors.bgCard,
  border: `1px solid ${colors.borderStrong}`,
  color: colors.navy,
  fontSize: 10,
  fontWeight: 800,
  position: 'relative',
  zIndex: 1,
}
const stepNoAccentStyle: React.CSSProperties = { ...stepNoStyle, borderColor: colors.orange, color: colors.orange }
const stepH3Style: React.CSSProperties = { fontSize: 12, fontWeight: 700, color: colors.textPrimary, margin: '0 0 4px' }
const stepPStyle: React.CSSProperties = { fontSize: 10.5, color: colors.textMuted, lineHeight: 1.7, margin: 0 }

// ── Principles ──
const principlesGridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(3, 1fr)',
  gap: 16,
}
const principleCardStyle: React.CSSProperties = {
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: 14,
  padding: 24,
  background: colors.bgCard,
  minHeight: 150,
}
const principleNoStyle: React.CSSProperties = { fontSize: 11, color: colors.orange, fontWeight: 800, marginBottom: 14 }
const principleH3Style: React.CSSProperties = { fontSize: 15, fontWeight: 800, color: colors.textPrimary, margin: '0 0 7px' }
const principlePStyle: React.CSSProperties = { fontSize: 11.5, color: colors.textSecondary, lineHeight: 2.05, margin: 0 }

// ── KPI / Rating ──
const ratingLineStyle: React.CSSProperties = {
  fontSize: 13,
  color: colors.textSecondary,
  background: 'var(--panel-2)',
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: 10,
  padding: '14px 18px',
  marginTop: 16,
}

// ── CTA ──
const ctaSectionStyle: React.CSSProperties = { padding: '48px 0', background: colors.bgPage }
const ctaBoxStyle: React.CSSProperties = {
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: 16,
  background: colors.bgCard,
  padding: '32px 36px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  gap: 24,
  boxShadow: '0 12px 38px rgba(21,45,88,.05)',
  flexWrap: 'wrap',
}
const ctaH2Style: React.CSSProperties = { fontSize: 20, fontWeight: 800, color: colors.textPrimary, margin: '0 0 6px' }
const ctaPStyle: React.CSSProperties = { fontSize: 12, color: colors.textSecondary, margin: 0, lineHeight: 1.9 }
const ctaButtonsStyle: React.CSSProperties = { display: 'flex', gap: 10, flexShrink: 0, flexWrap: 'wrap' }
const ctaPrimaryBtnStyle: React.CSSProperties = {
  background: colors.navy,
  color: '#fff',
  border: `1px solid ${colors.navy}`,
  borderRadius: 10,
  padding: '11px 22px',
  fontSize: 12.5,
  fontWeight: 800,
  textDecoration: 'none',
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  boxShadow: '0 7px 16px rgba(30,53,123,.15)',
}
const ctaSecondaryBtnStyle: React.CSSProperties = {
  background: colors.bgCard,
  color: colors.navy,
  border: `1px solid ${colors.navy}`,
  borderRadius: 10,
  padding: '11px 22px',
  fontSize: 12.5,
  fontWeight: 700,
  textDecoration: 'none',
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
}
