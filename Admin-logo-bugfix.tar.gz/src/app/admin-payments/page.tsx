import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import type { AccessLevel } from '@/lib/sections'
import AdminNav, { PartialAccessBanner } from '@/components/AdminNav'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'
import { approvePaymentReceiptAction, rejectPaymentReceiptAction } from '../admin-orders/actions'
import { pageStyle, pageWrapStyle, contentStyle, h1Style, subTitleStyle, cardStyle, theadRowStyle, thStyle, tdStyle, badgeStyle, btnPrimaryStyle, btnDangerStyle, emptyStateStyle } from '@/lib/styles/shared'
import { getSurfaceHome } from '@/lib/surfaceHome'

export const dynamic = 'force-dynamic'

const VAT_RATE = 0.09

type OrderItemLike = { price: number; finalPrice: number | null; quantity: number }

function payableTotal(items: OrderItemLike[]) {
  const net = items.reduce((sum, it) => sum + (it.finalPrice ?? it.price) * it.quantity, 0)
  return Math.round(net * (1 + VAT_RATE))
}

export default async function AdminPaymentsPage() {
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)

  const level: AccessLevel = isAdmin ? 'full' : ((myAccess?.payments as AccessLevel) ?? 'none')
  const hasAccess = level !== 'none'
  const canReview = level === 'full' || level === 'edit'

  // فقط وقتی دسترسی هست کوئری می‌زنیم — بی‌دسترسی یعنی هیچ داده‌ای لود نشه
  const pending = hasAccess
    ? await prisma.order.findMany({
        where: { paymentReceiptUrl: { not: null }, paymentReceiptStatus: 'pending' },
        include: { user: true, items: true },
        orderBy: { paymentReceiptUploadedAt: 'desc' },
      })
    : []

  // رد کردن فیش، paymentReceiptUrl رو null می‌کنه — پس تاریخچه باید روی
  // paymentReceiptReviewedAt کلید بخوره، نه روی وجود فایل
  const reviewed = hasAccess
    ? await prisma.order.findMany({
        where: { paymentReceiptReviewedAt: { not: null } },
        include: { user: true, items: true },
        orderBy: { paymentReceiptReviewedAt: 'desc' },
      })
    : []

  // رابطه‌ی نام‌دار برای بررسی‌کننده توی اسکیما نیست (فقط فیلد اسکالر id) —
  // پس اسم‌ها رو با یه کوئری جدا می‌گیریم
  const reviewerIds = Array.from(
    new Set(reviewed.map((o) => o.paymentReceiptReviewedById).filter((id): id is string => !!id)),
  )
  const reviewers = reviewerIds.length
    ? await prisma.user.findMany({ where: { id: { in: reviewerIds } }, select: { id: true, companyName: true } })
    : []
  const reviewerMap = new Map(reviewers.map((r) => [r.id, r.companyName]))

  return (
    <div style={pageStyle}>
      <div style={pageWrapStyle}>
        <AdminNav
          currentUserName={currentUser.companyName} currentUsername={currentUser.username}
          isAdmin={isAdmin}
          accessMap={myAccess || {}}
          activeSection="payments" homeHref={getSurfaceHome()}
        />

        <div style={contentStyle}>
          <h1 style={h1Style}>تایید فیش‌های پرداخت</h1>
          <p style={subTitleStyle}>
            صف بررسی فیش‌های آپلودشده توسط خریدار و تاریخچه‌ی بررسی‌ها
          </p>

          <PartialAccessBanner level={level} sectionLabel="تایید فیش‌های پرداخت" />

          {!hasAccess && (
            <div style={emptyStateStyle}>به بخش «تایید فیش‌های پرداخت» دسترسی نداری.</div>
          )}

          {hasAccess && (
            <>
              <div style={h1Style}>
                🔴 در انتظار بررسی
                {pending.length > 0 && <span style={badgeStyle('danger')}>{pending.length}</span>}
              </div>

              {pending.length === 0 ? (
                <div style={emptyStateStyle}>فیش در انتظار بررسی‌ای نیست.</div>
              ) : (
                <div style={cardStyle}>
                  <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                    <thead>
                      <tr style={theadRowStyle}>
                        <th style={thStyle}>سفارش</th>
                        <th style={thStyle}>خریدار</th>
                        <th style={thStyle}>مبلغ با مالیات</th>
                        <th style={thStyle}>زمان آپلود</th>
                        <th style={thStyle}>فیش</th>
                        <th style={thStyle}>عملیات</th>
                      </tr>
                    </thead>
                    <tbody>
                      {pending.map((order) => {
                        const shortId = order.id.slice(0, 8)
                        return (
                          <tr key={order.id} style={{ borderTop: '1px solid #eceff3' }}>
                            <td style={{ ...tdStyle, fontFamily: 'monospace' }}>#{shortId}</td>
                            <td style={tdStyle}>{order.user.companyName}</td>
                            <td style={{ ...tdStyle, fontFamily: 'monospace' }}>
                              {payableTotal(order.items).toLocaleString('en-US')} ریال
                            </td>
                            <td style={{ ...tdStyle, fontSize: 11.5, color: '#6f7680' }}>
                              {order.paymentReceiptUploadedAt
                                ? new Date(order.paymentReceiptUploadedAt).toLocaleString('fa-IR')
                                : '—'}
                            </td>
                            <td style={tdStyle}>
                              {order.paymentReceiptUrl ? (
                                <a
                                  href={order.paymentReceiptUrl}
                                  target="_blank"
                                  rel="noreferrer"
                                  style={fileLinkStyle}
                                >
                                  مشاهده‌ی فیش ↗
                                </a>
                              ) : (
                                '—'
                              )}
                            </td>
                            <td style={tdStyle}>
                              {canReview ? (
                                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                                  <form action={approvePaymentReceiptAction.bind(null, order.id)}>
                                    <ConfirmSubmitButton
                                      message={`⚠️ فیش پرداخت سفارش #${shortId} تایید بشه؟`}
                                      style={btnPrimaryStyle}
                                    >
                                      تایید فیش
                                    </ConfirmSubmitButton>
                                  </form>
                                  <form action={rejectPaymentReceiptAction.bind(null, order.id)}>
                                    <ConfirmSubmitButton
                                      message={`⚠️ فیش پرداخت سفارش #${shortId} رد بشه؟ خریدار باید فیش جدید آپلود کنه.`}
                                      style={btnDangerStyle}
                                    >
                                      رد فیش
                                    </ConfirmSubmitButton>
                                  </form>
                                </div>
                              ) : (
                                <span style={{ fontSize: 11.5, color: '#9199a3' }}>فقط مشاهده</span>
                              )}
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              )}

              <div style={{ ...h1Style, marginTop: 28 }}>تاریخچه‌ی بررسی‌ها</div>

              {reviewed.length === 0 ? (
                <div style={emptyStateStyle}>هنوز فیشی بررسی نشده.</div>
              ) : (
                <div style={cardStyle}>
                  <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                    <thead>
                      <tr style={theadRowStyle}>
                        <th style={thStyle}>سفارش</th>
                        <th style={thStyle}>خریدار</th>
                        <th style={thStyle}>مبلغ با مالیات</th>
                        <th style={thStyle}>نتیجه</th>
                        <th style={thStyle}>بررسی‌کننده</th>
                        <th style={thStyle}>زمان بررسی</th>
                      </tr>
                    </thead>
                    <tbody>
                      {reviewed.map((order) => {
                        const approved = order.paymentReceiptStatus === 'approved'
                        return (
                          <tr key={order.id} style={{ borderTop: '1px solid #eceff3' }}>
                            <td style={{ ...tdStyle, fontFamily: 'monospace' }}>#{order.id.slice(0, 8)}</td>
                            <td style={tdStyle}>{order.user.companyName}</td>
                            <td style={{ ...tdStyle, fontFamily: 'monospace' }}>
                              {payableTotal(order.items).toLocaleString('en-US')} ریال
                            </td>
                            <td style={tdStyle}>
                              <span style={approved ? badgeStyle('success') : badgeStyle('danger')}>
                                {approved ? 'تایید شد' : 'رد شد'}
                              </span>
                            </td>
                            <td style={tdStyle}>
                              {(order.paymentReceiptReviewedById &&
                                reviewerMap.get(order.paymentReceiptReviewedById)) ||
                                '—'}
                            </td>
                            <td style={{ ...tdStyle, fontSize: 11.5, color: '#6f7680' }}>
                              {order.paymentReceiptReviewedAt
                                ? new Date(order.paymentReceiptReviewedAt).toLocaleString('fa-IR')
                                : '—'}
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}

const fileLinkStyle: React.CSSProperties = { color: '#1e357b', fontWeight: 700, fontSize: 12, textDecoration: 'none' }
