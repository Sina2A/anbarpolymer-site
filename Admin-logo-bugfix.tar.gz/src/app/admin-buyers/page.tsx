import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import type { AccessLevel } from '@/lib/sections'
import AdminNav, { PartialAccessBanner } from '@/components/AdminNav'
import { toggleBuyerStatusAction, updateBuyerNoteAction } from './actions'
import {
  pageStyle, pageWrapStyle, contentStyle,
  h1Style, subTitleStyle,
  cardStyle,
  tableStyle, theadRowStyle, thStyle, tdStyle,
  badgeStyle, btnPrimaryStyle, btnDangerStyle, btnSecondaryStyle, btnSmallStyle,
  inputStyle, emptyStateStyle,
} from '@/lib/styles/shared'
import { colors, spacing, fontSize } from '@/lib/styles/tokens'
import { getSurfaceHome } from '@/lib/surfaceHome'

export const dynamic = 'force-dynamic'

export default async function AdminBuyersPage({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>
}) {
  const params = await searchParams
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)

  const level: AccessLevel = isAdmin ? 'full' : ((myAccess?.buyers as AccessLevel) ?? 'none')
  const hasAccess = level !== 'none'
  const canEdit = level === 'edit' || level === 'full'

  const buyers = hasAccess
    ? await prisma.user.findMany({
        where: { role: 'buyer' },
        include: {
          company: {
            select: {
              id: true,
              nationalId: true,
              registrationNumber: true,
              internalNote: true,
              kyc: { select: { level: true } },
            },
          },
          _count: {
            select: {
              orders: true,
              purchaseRequests: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      })
    : []

  const feedback =
    typeof params.updated === 'string'
      ? 'وضعیت خریدار تغییر یافت.'
      : typeof params.note === 'string'
        ? 'یادداشت ذخیره شد.'
        : null

  return (
    <div style={pageStyle}>
      <div style={pageWrapStyle} className="admin-page-wrap">
        <AdminNav
          currentUserName={currentUser.companyName} currentUsername={currentUser.username}
          isAdmin={isAdmin}
          accessMap={myAccess || {}}
          activeSection="buyers" homeHref={getSurfaceHome()}
        />

        <div style={contentStyle}>
          <h1 style={h1Style}>مدیریت خریداران</h1>
          <p style={subTitleStyle}>نمای مدیریتی کاربران با نقش خریدار — {buyers.length} خریدار</p>

          <PartialAccessBanner level={level} sectionLabel="خریداران" />

          {!hasAccess && <div style={emptyStateStyle}>به بخش «خریداران» دسترسی نداری.</div>}

          {hasAccess && (
            <>
              {feedback && (
                <div style={{ ...badgeStyle('success'), padding: '10px 16px', marginBottom: spacing.lg, display: 'block' }}>
                  {feedback}
                </div>
              )}

              {buyers.length === 0 ? (
                <div style={emptyStateStyle}>هیچ خریداری ثبت نشده.</div>
              ) : (
                <div style={cardStyle}>
                  <div style={{ overflowX: 'auto' }}>
                    <table style={tableStyle}>
                      <thead>
                        <tr style={theadRowStyle}>
                          <th style={thStyle}>نام شرکت</th>
                          <th style={thStyle}>شناسه ملی</th>
                          <th style={thStyle}>شماره ثبت</th>
                          <th style={thStyle}>وضعیت</th>
                          <th style={thStyle}>وضعیت KYC</th>
                          <th style={thStyle}>سفارش‌ها</th>
                          <th style={thStyle}>درخواست‌ها</th>
                          <th style={thStyle}>تاریخ عضویت</th>
                          {canEdit && <th style={thStyle}>عملیات</th>}
                        </tr>
                      </thead>
                      <tbody>
                        {buyers.map((buyer) => {
                          const kycLevel = buyer.company?.kyc?.level ?? 0

                          const kycBadge =
                            kycLevel === 0 ? (
                              <span style={badgeStyle('neutral')}>احراز نشده</span>
                            ) : kycLevel === 1 ? (
                              <span style={badgeStyle('warning')}>سطح ۱</span>
                            ) : (
                              <span style={badgeStyle('success')}>سطح ۲</span>
                            )

                          const statusBadge = buyer.isActive ? (
                            <span style={badgeStyle('success')}>فعال</span>
                          ) : (
                            <span style={badgeStyle('danger')}>غیرفعال</span>
                          )

                          return (
                            <tr key={buyer.id} className="stripe-row-hover">
                              <td style={{ ...tdStyle, fontWeight: 700 }}>{buyer.companyName}</td>
                              <td style={{ ...tdStyle, fontFamily: 'monospace', direction: 'ltr', textAlign: 'right' }}>
                                {buyer.company?.nationalId || '—'}
                              </td>
                              <td style={{ ...tdStyle, fontFamily: 'monospace', direction: 'ltr', textAlign: 'right' }}>
                                {buyer.company?.registrationNumber || '—'}
                              </td>
                              <td style={tdStyle}>{statusBadge}</td>
                              <td style={tdStyle}>{kycBadge}</td>
                              <td style={{ ...tdStyle, fontFamily: 'monospace', textAlign: 'center' }}>
                                {buyer._count.orders}
                              </td>
                              <td style={{ ...tdStyle, fontFamily: 'monospace', textAlign: 'center' }}>
                                {buyer._count.purchaseRequests}
                              </td>
                              <td style={{ ...tdStyle, fontSize: fontSize.xs, color: colors.textSecondary }}>
                                {new Date(buyer.createdAt).toLocaleDateString('fa-IR')}
                              </td>
                              {canEdit && (
                                <td style={{ ...tdStyle, whiteSpace: 'nowrap' }}>
                                  <form action={toggleBuyerStatusAction} style={{ display: 'inline' }}>
                                    <input type="hidden" name="id" value={buyer.id} />
                                    <button
                                      type="submit"
                                      style={
                                        buyer.isActive
                                          ? { ...btnDangerStyle, ...btnSmallStyle, background: colors.dangerText, color: '#fff', border: 'none' }
                                          : { ...btnPrimaryStyle, ...btnSmallStyle }
                                      }
                                    >
                                      {buyer.isActive ? 'غیرفعال' : 'فعال‌سازی'}
                                    </button>
                                  </form>
                                  {buyer.company && (
                                    <form action={updateBuyerNoteAction} style={{ display: 'inline-flex', gap: 4, marginInlineStart: spacing.sm, alignItems: 'center' }}>
                                      <input type="hidden" name="id" value={buyer.id} />
                                      <input
                                        type="text"
                                        name="note"
                                        defaultValue={buyer.company.internalNote || ''}
                                        placeholder="یادداشت..."
                                        style={{ ...inputStyle, width: 160, padding: '4px 8px', fontSize: fontSize.xs }}
                                      />
                                      <button type="submit" style={{ ...btnSecondaryStyle, ...btnSmallStyle }}>
                                        ذخیره
                                      </button>
                                    </form>
                                  )}
                                </td>
                              )}
                            </tr>
                          )
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}
