import prisma from '@/lib/prisma'
import { getAllSectionAccess } from '@/lib/permissions'
import { getCurrentUser } from '@/lib/currentUser'
import { isPriceStillValid } from '@/lib/pricing'
import AdminNav from '@/components/AdminNav'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'
import RecordActionsMenu from '@/components/RecordActionsMenu'
import { setOrderPricing, rejectOrder, cancelProformaAction, approvePaymentReceiptAction, rejectPaymentReceiptAction } from './actions'
import { pageStyle, pageWrapStyle, contentStyle, h1Style, subTitleStyle, cardStyle, tableStyle, theadRowStyle, thStyle, tdStyle, badgeStyle, orderStatusBadgeStyle, ORDER_STATUS_CONFIG, btnPrimaryStyle, btnSecondaryStyle, btnDangerStyle, inputStyle, selectStyle, labelStyle, emptyStateStyle } from '@/lib/styles/shared'
import { getSurfaceHome } from '@/lib/surfaceHome'

export const dynamic = 'force-dynamic'

const STATUS_LABELS: Record<string, string> = {
  pending: 'در انتظار قیمت‌گذاری',
  priced: 'قیمت ثبت شد — منتظر تایید مشتری',
  awaiting_approval: 'در انتظار تایید مدیر',
  buyer_confirmed: 'تایید شد توسط مشتری',
  ...Object.fromEntries(Object.entries(ORDER_STATUS_CONFIG).map(([k, v]) => [k, v.label])),
  rejected: 'رد شد',
}

export default async function AdminOrdersPage() {
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)

  const orders = await prisma.order.findMany({
    include: { user: true, items: { include: { grade: true, warehouse: true } } },
    orderBy: { createdAt: 'desc' },
  })

  const pendingOrders = orders.filter((o) => o.status === 'pending')
  const otherOrders = orders.filter((o) => o.status !== 'pending')

  return (
    <div style={pageStyle}>
      <div style={pageWrapStyle}>
        <AdminNav currentUserName={currentUser.companyName} currentUsername={currentUser.username} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="orders" homeHref={getSurfaceHome()} />

        <div style={contentStyle}>
          <h1 style={h1Style}>سفارش‌ها</h1>
          <p style={subTitleStyle}>سفارش‌های در انتظار قیمت‌گذاری بالای صفحه‌ن — بقیه پایین، به‌عنوان تاریخچه.</p>

          {/* ================= بخش ۱: نیاز به اقدام فوری ================= */}
          <h2 style={sectionHeadStyle}>
            🔴 نیاز به قیمت‌گذاری
            <span style={countBadge}>{pendingOrders.length}</span>
          </h2>

          {pendingOrders.length === 0 && (
            <div style={emptyStateStyle}>هیچ سفارش در انتظاری نیست.</div>
          )}

          {pendingOrders.map((order) => (
            <form key={order.id} action={setOrderPricing} style={pendingCardStyle}>
              <input type="hidden" name="orderId" value={order.id} />
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
                <div>
                  <b style={{ fontSize: 14.5 }}>سفارش #{order.id.slice(0, 8)}</b>
                  <span style={{ fontSize: 12, color: '#6f7680', marginRight: 10 }}>{order.user.companyName}</span>
                </div>
                <span style={{ fontSize: 11, color: '#9199a3' }}>{new Date(order.createdAt).toLocaleString('fa-IR')}</span>
              </div>

              <table style={tableStyle}>
                <thead>
                  <tr style={theadRowStyle}>
                    <th style={thStyle}>گرید</th>
                    <th style={thStyle}>انبار</th>
                    <th style={thStyle}>مقدار</th>
                    <th style={thStyle}>قیمت مرجع</th>
                    <th style={thStyle}>وضعیت اعتبار</th>
                    <th style={thStyle}>قیمت نهایی</th>
                  </tr>
                </thead>
                <tbody>
                  {order.items.map((item) => {
                    const valid = isPriceStillValid(item.priceValidUntil)
                    return (
                      <tr key={item.id} style={{ borderBottom: '1px solid #f1efe8' }}>
                        <td style={tdStyle}><b style={{ fontFamily: 'monospace' }}>{item.grade.code}</b></td>
                        <td style={tdStyle}>{item.warehouse?.name}</td>
                        <td style={tdStyle}>{item.quantity} تن</td>
                        <td style={{ ...tdStyle, fontFamily: 'monospace' }}>{item.price.toLocaleString('en-US')}</td>
                        <td style={tdStyle}>
                          <span style={valid ? badgeStyle('success') : badgeStyle('danger')}>{valid ? 'معتبر' : 'منقضی — بررسی کن'}</span>
                        </td>
                        <td style={tdStyle}>
                          <input
                            name={`finalPrice-${item.id}`}
                            type="number"
                            defaultValue={item.price}
                            style={priceInputStyle}
                          />
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>

              <div style={{ display: 'flex', gap: 10 }}>
                <ConfirmSubmitButton
                  message="قیمت‌های ثبت‌شده برای مشتری ارسال بشه؟"
                  style={{ background: '#1e357b', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 18px', fontSize: 13, fontWeight: 700, cursor: 'pointer' }}
                >
                  ثبت قیمت‌ها و ارسال به مشتری
                </ConfirmSubmitButton>
              </div>
            </form>
          ))}

          {/* دکمه‌ی رد سفارش جدا، چون moment فرم دیگه‌ایه */}
          {pendingOrders.map((order) => (
            <form key={`reject-${order.id}`} action={rejectOrder} style={{ marginTop: -10, marginBottom: 20 }}>
              <input type="hidden" name="orderId" value={order.id} />
              <ConfirmSubmitButton
                message={`⚠️ سفارش #${order.id.slice(0, 8)} رد بشه؟ موجودی قفل‌شده به انبار برمی‌گرده.`}
                style={{ background: 'transparent', color: '#dc2626', border: '1px solid #dc2626', borderRadius: 8, padding: '8px 16px', fontSize: 12, fontWeight: 700, cursor: 'pointer' }}
              >
                رد این سفارش
              </ConfirmSubmitButton>
            </form>
          ))}

          {/* ================= بخش ۲: تاریخچه ================= */}
          <h2 style={{ ...sectionHeadStyle, marginTop: 36 }}>تاریخچه‌ی سفارش‌ها</h2>
          {otherOrders.length === 0 && <div style={emptyStateStyle}>هنوز سفارشی به این مرحله نرسیده.</div>}
          {otherOrders.map((order) => {
            const isProforma = order.status === 'priced' || order.status === 'buyer_confirmed'
            const receiptPending = !!order.paymentReceiptUrl && order.paymentReceiptStatus === 'pending'
            const shortId = order.id.slice(0, 8)

            // دکمه‌های پراکنده‌ی قبلی (ابطال/تایید فیش/رد فیش) حالا توی یه منوی واحد جمع شدن.
            // هر اکشن به order.id همون سفارش bind می‌شه — فقط id به کلاینت می‌ره، نه کل آبجکت order.
            const menuActions = [
              ...(receiptPending
                ? [
                    { label: 'تایید فیش', action: approvePaymentReceiptAction.bind(null, order.id), confirmMessage: `⚠️ فیش پرداخت سفارش #${shortId} تایید بشه؟` },
                    { label: 'رد فیش', action: rejectPaymentReceiptAction.bind(null, order.id), confirmMessage: `⚠️ فیش پرداخت سفارش #${shortId} رد بشه؟ خریدار باید فیش جدید آپلود کنه.`, danger: true },
                  ]
                : []),
              ...(isProforma
                ? [
                    { label: 'ابطال پیش‌فاکتور', action: cancelProformaAction.bind(null, order.id), confirmMessage: `⚠️ پیش‌فاکتور سفارش #${shortId} ابطال بشه؟ موجودی قفل‌شده به انبار برمی‌گرده و این کار قابل‌بازگشت نیست.`, danger: true },
                  ]
                : []),
            ]

            return (
            <div key={order.id} style={historyCardStyle}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <b style={{ fontSize: 13.5 }}>#{shortId}</b>
                  <span style={{ fontSize: 11.5, color: '#6f7680', marginRight: 8 }}>{order.user.companyName}</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <span style={orderStatusBadgeStyle(order.status)}>{STATUS_LABELS[order.status] || order.status}</span>
                  <RecordActionsMenu extraActions={menuActions} />
                </div>
              </div>

              {receiptPending && (
                <div style={{ marginTop: 12, borderTop: '1px dashed #e5e7eb', paddingTop: 12, background: '#fff4ee', borderRadius: 8, padding: '12px 14px' }}>
                  <div style={{ fontSize: 12, color: '#7a3a10', fontWeight: 700, marginBottom: 8 }}>
                    فیش پرداخت آپلود شده — در انتظار بررسی
                  </div>
                  <a href={order.paymentReceiptUrl as string} target="_blank" rel="noreferrer" style={{ fontSize: 12, color: '#1e357b', fontWeight: 700 }}>
                    مشاهده‌ی فیش آپلودی ↗
                  </a>
                  <div style={{ fontSize: 11, color: '#9199a3', marginTop: 8 }}>
                    تایید یا رد فیش از منوی اقدامات (کنار وضعیت، بالای کارت).
                  </div>
                </div>
              )}
            </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

const sectionHeadStyle: React.CSSProperties = { fontSize: 15, fontWeight: 800, display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }
const countBadge: React.CSSProperties = { background: '#fee2e2', color: '#a8241a', fontSize: 11, fontWeight: 800, borderRadius: 20, padding: '2px 10px' }
const pendingCardStyle: React.CSSProperties = { border: '1.5px solid #f6621b', borderRadius: 12, padding: 18, marginBottom: 10, background: '#fff', boxShadow: '0 1px 4px rgba(27,30,36,.05)' }
const historyCardStyle: React.CSSProperties = { border: '1px solid #eceff3', borderRadius: 10, padding: '12px 16px', marginBottom: 8, background: '#fff' }
const priceInputStyle: React.CSSProperties = { width: 110, border: '1px solid #d8dde3', borderRadius: 6, padding: '6px 8px', fontSize: 12, fontFamily: 'monospace' }
