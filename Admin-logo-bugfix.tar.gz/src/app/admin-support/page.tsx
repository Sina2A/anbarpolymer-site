import prisma from '@/lib/prisma'
import { getAllSectionAccess } from '@/lib/permissions'
import { getCurrentUser } from '@/lib/currentUser'
import AdminNav from '@/components/AdminNav'
import {
  pageStyle,
  pageWrapStyle,
  contentStyle,
  h1Style,
  subTitleStyle,
  cardStyle,
  tableStyle,
  theadRowStyle,
  thStyle,
  tdStyle,
  badgeStyle,
  btnPrimaryStyle,
  btnSecondaryStyle,
  btnDangerStyle,
  inputStyle,
  selectStyle,
  labelStyle,
  emptyStateStyle,
} from '@/lib/styles/shared'
import { getSurfaceHome } from '@/lib/surfaceHome'

export const dynamic = 'force-dynamic'

type SearchParams = Promise<Record<string, string | string[] | undefined>>

function one(v: string | string[] | undefined): string | undefined {
  if (Array.isArray(v)) return v[0]
  return v
}

const STATUS_TABS: { key: string; label: string }[] = [
  { key: 'all', label: 'همه' },
  { key: 'open', label: 'باز' },
  { key: 'answered', label: 'پاسخ‌داده‌شده' },
  { key: 'closed', label: 'بسته' },
]

export default async function AdminSupportPage({ searchParams }: { searchParams: SearchParams }) {
  const sp = await searchParams
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)

  const activeStatus = one(sp.status) || 'all'
  const where = activeStatus === 'all' ? {} : { status: activeStatus }

  const tickets = await prisma.supportTicket.findMany({
    where,
    include: {
      user: { select: { companyName: true, phone: true } },
      _count: { select: { messages: true } },
    },
    orderBy: { updatedAt: 'desc' },
  })

  // شمارش هر وضعیت برای نشان‌دادن روی تب‌ها
  const counts = await prisma.supportTicket.groupBy({
    by: ['status'],
    _count: { _all: true },
  })
  const countMap: Record<string, number> = {}
  let total = 0
  for (const c of counts) {
    countMap[c.status] = c._count._all
    total += c._count._all
  }

  return (
    <div style={pageStyle}>
      <div style={pageWrapStyle}>
        <AdminNav currentUserName={currentUser.companyName} currentUsername={currentUser.username} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="support" homeHref={getSurfaceHome()} />

        <div style={contentStyle}>
          <h1 style={h1Style}>پشتیبانی و تیکت‌ها</h1>
          <p style={subTitleStyle}>
            تیکت‌های کاربران — برای پاسخ‌دادن یا تغییر وضعیت، روی هر تیکت کلیک کن.
          </p>

          {/* ── تب‌های فیلتر وضعیت ── */}
          <div style={{ display: 'flex', gap: 8, marginBottom: 18, flexWrap: 'wrap' }}>
            {STATUS_TABS.map((tab) => {
              const isActive = activeStatus === tab.key
              const n = tab.key === 'all' ? total : (countMap[tab.key] || 0)
              return (
                <a
                  key={tab.key}
                  href={`/admin-support?status=${tab.key}`}
                  style={{
                    padding: '7px 16px', borderRadius: 8, fontSize: 12.5, fontWeight: 700,
                    textDecoration: 'none', border: '1px solid',
                    borderColor: isActive ? '#1e357b' : '#d8dde3',
                    background: isActive ? '#1e357b' : '#fff',
                    color: isActive ? '#fff' : '#4f5560',
                  }}
                >
                  {tab.label} <span style={{ opacity: 0.75, fontFamily: 'monospace' }}>({n})</span>
                </a>
              )
            })}
          </div>

          {/* ── جدول تیکت‌ها ── */}
          {tickets.length === 0 ? (
            <div style={{ padding: 32, textAlign: 'center', color: '#9199a3', border: '1px dashed #d8dde3', borderRadius: 12 }}>
              تیکتی در این وضعیت نیست.
            </div>
          ) : (
            <div style={{ border: '1px solid #d8dde3', borderRadius: 12, overflow: 'hidden', background: '#fff' }}>
              <table style={tableStyle}>
                <thead>
                  <tr style={{ background: '#f7f8fa', color: '#6f7680', textAlign: 'right' }}>
                    <th style={thStyle}>موضوع</th>
                    <th style={thStyle}>کاربر</th>
                    <th style={thStyle}>پیام‌ها</th>
                    <th style={thStyle}>وضعیت</th>
                    <th style={thStyle}>آخرین بروزرسانی</th>
                  </tr>
                </thead>
                <tbody>
                  {tickets.map((t) => (
                    <tr key={t.id} style={{ borderTop: '1px solid #eceff3' }}>
                      <td style={tdStyle}>
                        <a href={`/admin-support/${t.id}`} style={{ color: '#1e357b', fontWeight: 700, textDecoration: 'none' }}>
                          {t.subject}
                        </a>
                        <div style={{ fontSize: 10.5, color: '#9199a3', fontFamily: 'monospace', marginTop: 3 }}>#{t.id.slice(0, 8)}</div>
                      </td>
                      <td style={tdStyle}>
                        <div style={{ fontWeight: 600 }}>{t.user.companyName || '—'}</div>
                        <div style={{ fontSize: 11, color: '#9199a3', direction: 'ltr', fontFamily: 'monospace' }}>{t.user.phone}</div>
                      </td>
                      <td style={tdStyle}>{t._count.messages}</td>
                      <td style={tdStyle}><span style={badgeStyle(statusToKind(t.status))}>{translateStatus(t.status)}</span></td>
                      <td style={{ ...tdStyle, color: '#6f7680', whiteSpace: 'nowrap' }}>
                        {new Date(t.updatedAt).toLocaleDateString('fa-IR')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// ── ترجمه و رنگ وضعیت ─────────────────────────────────────────────────
function translateStatus(status: string): string {
  const map: Record<string, string> = { open: 'باز', answered: 'پاسخ‌داده‌شده', closed: 'بسته' }
  return map[status] ?? status
}

function statusToKind(status: string): 'success' | 'warning' | 'danger' | 'info' | 'neutral' {
  if (status === 'open') return 'warning'
  if (status === 'answered') return 'success'
  if (status === 'closed') return 'neutral'
  return 'neutral'
}
