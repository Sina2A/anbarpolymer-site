import prisma from '@/lib/prisma'
import { getAllSectionAccess } from '@/lib/permissions'
import { getCurrentUser } from '@/lib/currentUser'
import AdminNav, { PartialAccessBanner } from '@/components/AdminNav'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'
import { notFound } from 'next/navigation'
import { replyToTicketAction, updateTicketStatusAction } from '../actions'
import {
  pageStyle, pageWrapStyle, contentStyle,
  h1Style, cardStyle, emptyStateStyle,
  inputStyle, labelStyle,
  btnPrimaryStyle, btnSecondaryStyle, btnSmallStyle,
  badgeStyle,
} from '@/lib/styles/shared'
import { getSurfaceHome } from '@/lib/surfaceHome'

export const dynamic = 'force-dynamic'

type Props = { params: Promise<{ id: string }> }

export default async function AdminSupportTicketPage({ params }: Props) {
  const { id } = await params
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)
  const myLevel = isAdmin ? 'full' : (myAccess?.['support'] ?? 'none')
  const canEdit = myLevel === 'full' || myLevel === 'edit'

  const ticket = await prisma.supportTicket.findUnique({
    where: { id },
    include: {
      user: { select: { companyName: true, phone: true, email: true } },
      messages: { orderBy: { createdAt: 'asc' } },
    },
  })
  if (!ticket) notFound()

  // اسم کارشناسی که آخرین بار پاسخ داده — با کوئری جدا، چون answeredById رابطه‌ی نام‌دار نداره
  const answeredBy = ticket.answeredById
    ? await prisma.user.findUnique({ where: { id: ticket.answeredById }, select: { companyName: true, username: true } })
    : null

  return (
    <div style={pageStyle}>
      <div style={pageWrapStyle}>
        <AdminNav currentUserName={currentUser.companyName} currentUsername={currentUser.username} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="support" homeHref={getSurfaceHome()} />

        <div style={contentStyle}>
          <PartialAccessBanner level={myLevel} sectionLabel="پشتیبانی و تیکت‌ها" />

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', gap: 12, marginBottom: 18 }}>
            <div>
              <h1 style={h1Style}>{ticket.subject}</h1>
              <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
                <span style={badgeStyle(statusBadgeKind(ticket.status))}>{translateStatus(ticket.status)}</span>
                <span style={{ fontSize: 11.5, color: '#9199a3', fontFamily: 'monospace' }}>#{ticket.id.slice(0, 8)}</span>
                <span style={{ fontSize: 11.5, color: '#9199a3' }}>
                  ثبت: {new Date(ticket.createdAt).toLocaleDateString('fa-IR')}
                </span>
              </div>
            </div>
            <a href="/admin-support" style={btnSecondaryStyle}>→ بازگشت به لیست</a>
          </div>

          {/* ── اطلاعات کاربر ── */}
          <div style={{ ...cardStyle, marginBottom: 14 }}>
            <b style={{ fontSize: 13.5, display: 'block', marginBottom: 10 }}>ثبت‌کننده</b>
            <div style={{ display: 'flex', gap: 24, flexWrap: 'wrap', fontSize: 12.5, color: '#4f5560' }}>
              <span>شرکت: <b style={{ color: '#1b1e24' }}>{ticket.user.companyName || '—'}</b></span>
              <span>موبایل: <b style={{ direction: 'ltr', fontFamily: 'monospace', color: '#1b1e24' }}>{ticket.user.phone || '—'}</b></span>
              {ticket.user.email && (
                <span>ایمیل: <b style={{ direction: 'ltr', fontFamily: 'monospace', color: '#1b1e24' }}>{ticket.user.email}</b></span>
              )}
              {answeredBy && (
                <span>آخرین پیگیری: <b style={{ color: '#146c3a' }}>{answeredBy.companyName || answeredBy.username}</b></span>
              )}
            </div>
          </div>

          {/* ── تایم‌لاین گفتگو ── */}
          <div style={cardStyle}>
            <b style={{ fontSize: 13.5, display: 'block', marginBottom: 12 }}>گفتگو</b>
            {ticket.messages.length === 0 ? (
              <div style={emptyStateStyle}>هنوز پیامی ثبت نشده.</div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {ticket.messages.map((m) => {
                  const isUser = m.senderType === 'user'
                  return (
                    <div
                      key={m.id}
                      style={{
                        alignSelf: isUser ? 'flex-start' : 'flex-end',
                        maxWidth: '85%',
                        background: isUser ? '#fff4ee' : '#eef4fd',
                        border: '1px solid',
                        borderColor: isUser ? '#fbd9c4' : '#d3e2fb',
                        borderRadius: 12,
                        padding: '11px 14px',
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, marginBottom: 5 }}>
                        <span style={{ fontSize: 10.5, fontWeight: 700, color: isUser ? '#b2500b' : '#1e357b' }}>
                          {isUser ? 'کاربر' : 'کارشناس'}
                        </span>
                        <span style={{ fontSize: 10, color: '#9199a3', direction: 'ltr', fontFamily: 'monospace' }}>
                          {new Date(m.createdAt).toLocaleDateString('fa-IR')} {new Date(m.createdAt).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <div style={{ fontSize: 13, lineHeight: 1.8, whiteSpace: 'pre-wrap', color: '#1b1e24' }}>{m.body}</div>
                    </div>
                  )
                })}
              </div>
            )}

            {/* ── فرم پاسخ کارشناس ── */}
            {canEdit ? (
              <form action={replyToTicketAction} style={{ marginTop: 18, borderTop: '1px solid #eceff3', paddingTop: 16 }}>
                <input type="hidden" name="ticketId" value={ticket.id} />
                <div style={labelStyle}>پاسخ کارشناس</div>
                <textarea name="body" rows={4} required placeholder="پاسخت رو بنویس — با ارسال، وضعیت تیکت «پاسخ‌داده‌شده» می‌شه"
                  style={{ ...inputStyle, resize: 'vertical', marginBottom: 10 }} />
                <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                  <button type="submit" style={btnPrimaryStyle}>ارسال پاسخ</button>
                </div>
              </form>
            ) : (
              <div style={{ marginTop: 18, borderTop: '1px solid #eceff3', paddingTop: 16 }}>
                <div style={badgeStyle('warning')}>برای پاسخ‌دادن، دسترسی ویرایش بخش پشتیبانی لازمه.</div>
              </div>
            )}
          </div>

          {/* ── تغییر وضعیت ── */}
          {canEdit && (
            <div style={{ ...cardStyle, marginTop: 14 }}>
              <b style={{ fontSize: 13.5, display: 'block', marginBottom: 10 }}>تغییر وضعیت</b>
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                {ticket.status !== 'open' && (
                  <form action={updateTicketStatusAction}>
                    <input type="hidden" name="ticketId" value={ticket.id} />
                    <input type="hidden" name="status" value="open" />
                    <button type="submit" style={btnSecondaryStyle}>بازگرداندن به «باز»</button>
                  </form>
                )}
                {ticket.status !== 'closed' && (
                  <form action={updateTicketStatusAction}>
                    <input type="hidden" name="ticketId" value={ticket.id} />
                    <input type="hidden" name="status" value="closed" />
                    <ConfirmSubmitButton
                      message="این تیکت بسته بشه؟ کاربر بعد از این نمی‌تونه پیام جدید بفرسته."
                      style={{ background: 'none', border: 'none', color: '#9b1c1c', fontSize: 12.5, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit', padding: '8px 4px' }}
                    >
                      بستن تیکت
                    </ConfirmSubmitButton>
                  </form>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// ── ترجمه و رنگ وضعیت ─────────────────────────────────────────────────
function translateStatus(status: string): string {
  const map: Record<string, string> = { open: 'باز', answered: 'پاسخ‌داده‌شده', closed: 'بسته' }
  return map[status] ?? status
}

function statusBadgeKind(status: string): 'success' | 'warning' | 'danger' | 'info' | 'neutral' {
  if (status === 'open') return 'warning'
  if (status === 'answered') return 'success'
  return 'neutral'
}
