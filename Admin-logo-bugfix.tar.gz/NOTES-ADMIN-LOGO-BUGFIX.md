# NOTES — Admin Sidebar Logo href Fix

## خلاصه
لوگوی سایدبار ادمین (`SidebarBrand` داخل `AdminNav`) به‌جای `/admin-orders` مقدار `/` برمی‌گرداند. علت: `BrandMark.tsx` مستقیم `getSurfaceHome()` را صدا می‌زد، اما تنها مصرف‌کننده‌اش `AdminNav.tsx` با `'use client'` است؛ بنابراین `BrandMark` هم Client-bundle می‌شود و `process.env.SURFACE` در باندل کلاینت زمان build اینلاینِ `""` می‌شود → fallback `/`. صفحات ادمین با وجود `force-dynamic` همچنان فرزند Client با مقدار build-time دارند.

## علت ریشه (تأییدشده)
- `src/components/BrandMark.tsx:1` — بدون `'use client'` اما `import { getSurfaceHome }`.
- `src/components/AdminNav.tsx:1` — `'use client'` + `import { SidebarBrand }`.
- قانون Next/Turbopack: هر ماژول ایمپورت‌شده از Client Component خودبه‌خود Client می‌شود → `getSurfaceHome()` در باندل کلاینت `"/"` برمی‌گرداند.
- حمل‌ونقل درست بود چون `src/app/transport-panel/layout.tsx` (Server) مقدار `getSurfaceHome()` را به `TransportPanelShell` به‌صورت `homeHref` prop می‌دهد.

## راه‌حل (الگوی prop-drilling — هم‌سو با فیکس قبلی PublicHeader/PanelHeader)
1. `src/components/BrandMark.tsx` — `SidebarBrand({ homeHref='/' })` و `<a href={homeHref}>`؛ حذف `import { getSurfaceHome }`.
2. `src/components/AdminNav.tsx` — prop `homeHref?: string` اضافه، `SidebarBrand` را با `homeHref` صدا می‌زند.
3. هر ۲۱ صفحه‌ی ادمین/تسک (`admin-*/page.tsx`, `my-tasks/page.tsx`, شامل `[id]`) — `getSurfaceHome()` را در Server صدا زده و به `AdminNav homeHref={getSurfaceHome()}` پاس می‌دهند.
4. سخت‌سازی اختیاری (همین PR): `Footer` و `TransportPanelFooter` هم به `homeHref` prop تبدیل شدند تا در برابر Client شدن آینده مقاوم باشند؛ هر ۲۳ صفحه‌ی مصرف‌کننده‌ی `Footer` حالا `homeHref` می‌دهند، و `transport-panel/layout.tsx` به `TransportPanelFooter` مقدار `homeHref` می‌دهد.

## فایل‌های تغییر‌یافته
- `src/components/BrandMark.tsx`
- `src/components/AdminNav.tsx`
- `src/components/Footer.tsx`
- `src/components/TransportPanelFooter.tsx`
- `src/app/transport-panel/layout.tsx`
- `src/app/admin-articles/page.tsx`, `src/app/admin-articles/[id]/page.tsx`
- `src/app/admin-buyers/page.tsx`, `src/app/admin-contact/page.tsx`, `src/app/admin-custom-request/page.tsx`
- `src/app/admin-deals/page.tsx`, `src/app/admin-disputes/page.tsx`, `src/app/admin-grades/page.tsx`
- `src/app/admin-kyc/page.tsx`, `src/app/admin-kyc/[companyId]/page.tsx`
- `src/app/admin-logistics/page.tsx`, `src/app/admin-logs/page.tsx`, `src/app/admin-material-listings/page.tsx`
- `src/app/admin-orders/page.tsx`, `src/app/admin-payments/page.tsx`, `src/app/admin-pricing/page.tsx`
- `src/app/admin-support/page.tsx`, `src/app/admin-support/[id]/page.tsx`
- `src/app/admin-users/page.tsx`, `src/app/admin-warehouses/page.tsx`, `src/app/my-tasks/page.tsx`
- همه‌ی صفحات دارای `Footer` (حدود ۲۳ فایل: `about`, `account`, `contact`, `custom-request`, `dashboard`, `grades`, `market`, `my-*`, `page.tsx`, `reports`, `rfq`, `services`, `support`, `transport`, `verification`, `warehouses`, ...)

## راستی‌آزمایی
- `npx tsc --noEmit` → EXIT 0
- `grep -rn getSurfaceHome src/components` → ۰ (هیچ Client bundle دیگر مستقیم env نمی‌خواند)
- `grep` ویژه‌ی AdminNav/Footer → همه‌ی `"<AdminNav"` و `"<Footer"` حالا `homeHref` دارند

## رفتار پس از فیکس
- روی `SURFACE=admin` مقدار `homeHref` برابر `/admin-orders` و لوگوی سایدبار به `/admin-orders` لینک می‌دهد.
- روی `SURFACE=transport` مقدار `/transport-panel` (از همان `surfaceHome.ts`).
- روی `public` مقدار `/` (fallback).

## نکات استقرار
- فقط فایل‌های `src/` تغییر کردند؛ `next.config.ts`/`middleware.ts`/`surfaceHome.ts` بدون تغییر.
- پس از deploy هر سه سرویس (`pm2 restart anbarpolymer-{public,admin,transport}`) لوگو را در `/admin-users` و `/transport-panel` چک کنید.
