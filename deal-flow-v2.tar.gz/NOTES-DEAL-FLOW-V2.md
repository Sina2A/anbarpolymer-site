# خلاصه‌ی فلوی معامله — مدل ۴نقشی (v2)

## تاریخ
۱۴۰۵/۰۶/۲۵

## هدف
جایگزینی فلوی تک‌مسیره و تک‌`status` قدیم با مدلی که سه مشکل ریشه‌ای سند `new-deal-flow.md` را حل کند:

1. **تله‌ی ترتیبِ پرداخت** — قبلاً تایید پرداخت خریدار (`payment_secured`) تایید کارمزد فروشنده را که به `status==='confirmed'` گیت بود برای همیشه قفل می‌کرد.
2. **بازار یک‌طرفه** — فقط مسیر «خریدار روی آگهی فروش» ساخته بود؛ تب درخواست خرید (`PurchaseRequest`) فقط نمایشی بود.
3. **نقش‌های ضمنی** — روی `Deal` فقط `buyerId` بود و فروشنده از `materialListing.userId` استنتاج می‌شد؛ منطق ابطال/جریمه به تفکیک صریح Requester/Acceptor نیاز داشت.

> ⚠️ این فاز فقط **کد** است — هیچ build / migrate / `prisma db push` / commit اجرا نشده.

---

## ۱. مدل نقش‌ها — ۴ FK مستقیم روی `Deal`

به‌جای جدول join، چهار فیلد nullable روی `Deal`:

| فیلد | معنا |
|------|------|
| `requesterId` | ثبت‌کننده‌ی درخواست اولیه |
| `acceptorId` | پذیرنده |
| `buyerId` | خریدارِ snapshot‌شده (موجود از قبل) |
| `sellerId` | فروشنده‌ی snapshot‌شده |
| `tradeDirection` | `'SELL'` \| `'BUY'` — جهتِ لحظه‌ی Match |

**قانون snapshot (در لحظه‌ی Match قفل می‌شود تا تغییر مالکیت بعدی نقش‌ها را جابه‌جا نکند):**

```
SELL (آگهی فروش)   ⇒ requester = seller ، acceptor = buyer
BUY  (درخواست خرید) ⇒ requester = buyer  ، acceptor = seller
```

`@@index` روی `requesterId`, `acceptorId`, `sellerId`, `driverId`.

---

## ۲. جداسازی state — `status` می‌شود «فاز»، نه گیتِ پرداخت

منبعِ حقیقتِ گیتِ پرداخت به ردیف‌های `DealPayment` منتقل شد. عبور به حمل‌ونقل دیگر با مقایسه‌ی enum نیست:

```ts
if (buyerGoods.status === 'APPROVED' && sellerFee.status === 'APPROVED')
  → status = 'transport_pending'
```

این ریشه‌ی تله‌ی ترتیب را می‌زند: هیچ اکشن پرداختی دیگر به `status==='confirmed'` گیت نمی‌شود.

---

## ۳. مدل‌های جدید

### `DealPayment` (تنها جدول کاملاً نو)
دو ردیف به‌ازای هر Deal، در لحظه‌ی Match ساخته می‌شوند:

```
id, dealId, kind: 'BUYER_GOODS'|'SELLER_FEE', amount?,
status: 'PENDING'|'SUBMITTED'|'APPROVED'|'REJECTED',
receiptUrl?, submittedAt?, reviewedById?, reviewedAt?, rejectionReason?
@@unique([dealId, kind])
```

مقادیر status **رشته‌ای**اند (کنوانسیون ریپو: بدون enum پریسما).

### `DealDriverAssignment` (تاریخچه‌ی append-only)
```
id, dealId, driverId, assignedById?, reason?, replacedAt?, createdAt
```
Replace اطلاعات راننده‌ی قبلی را پاک نمی‌کند — فقط `replacedAt` ردیف قبلی را می‌زند (§۷ — Audit کامل).

### `PurchaseRequest`
فیلد وضعیت جدید اضافه **نشد**. رزرو race-safe روی `status` موجود انجام می‌شود با افزودن مقدار `reserved` به دامنه (`open | reserved | closed | expired`). فقط رابطه‌ی معکوس `deals Deal[]` اضافه شد.

---

## ۴. نگاشت Backfill (رکوردهای در جریان)

برای هر `Deal` موجود (تنها مسیر قدیمی «خریدار روی آگهی فروش» بوده):

```
sellerId       = materialListing.userId
tradeDirection = 'SELL'
requesterId    = sellerId
acceptorId     = buyerId
DealPayment[BUYER_GOODS].status ← از escrowStatus فعلی
DealPayment[SELLER_FEE].status  ← از feeStatus فعلی
```

فیلدهای legacy (`escrowStatus`, `paymentReceiptUrl`, `buyerConfirmDeadline`, `sellerFeeDeadline`) **حذف نشدند** — تا پایان backfill می‌مانند و در فاز پاک‌سازیِ جدا کنار می‌روند (مهاجرت برگشت‌پذیر).

---

## ۵. فایل‌های تغییریافته

| فایل | تغییر |
|------|-------|
| `prisma/schema.prisma` | ۴ نقش + `driverId` + مدل‌های `DealPayment` / `DealDriverAssignment` + روابط معکوس |
| `market/actions.ts` | `createDealFromListingAction` (SELL) بازنویسی + `acceptPurchaseRequestAction` (BUY) جدید — هر دو snapshot نقش + ۲ `DealPayment` |
| `my-deals/actions.ts` | `acceptDealOfferAction`/`rejectDealOfferAction`/`cancelDealAction` — نقش صریح `sellerId`/`buyerId` به‌جای استنتاج |
| `admin-deals/actions.ts` | `approvePaymentAction` + `rejectPaymentAction` جدید (جای `confirmFundsSecured`/`markSellerFeePaidAction`/`rejectDealPaymentAction`) |
| `admin-logistics/actions.ts` | `assignDriverAction` جدید — Assign/Replace اتمیک + `logAudit` |
| `dealDeadlines.ts` | helper جریمه با طول انتخابی؛ گذارِ فاز نهایی به `settled` |
| `admin-deals/page.tsx` | صف‌های مستقلِ دو پرداخت + کنترل جریمه |
| `admin-logistics/page.tsx` | ستون راننده + انتخابگر Assign/Replace |
| `market/page.tsx` + `DemandTableRow.tsx` | فرم پذیرش درخواست خرید |

---

## ۶. منطق رد پرداخت (§۵ سند)

در `rejectPaymentAction(dealId, kind, penaltyHours?)`، بر پایه‌ی نقشِ ایجاد Match:

- فردِ پرداخت‌ردشده **Requester** بود ⇒ Deal→void + توقف Request + حذف از Market
- فردِ پرداخت‌ردشده **Acceptor** بود ⇒ Deal→void + جریمه با طول انتخابی (۳۰m / ۱h / ۳h / ۲۴h / ۷۲h)

جریمه در `SystemLog` با `logAudit` ثبت می‌شود؛ چون `logAudit` فقط یک `userId` دارد، کاربرِ هدف + مدت + دلیل در `meta` می‌روند. transactional.

---

## ۷. راننده (§۷)

`Deal.driverId` → مدل `Driver` (شرکت حمل‌ونقل چترِ بالادست می‌ماند). `assignDriverAction` یک اکشن واحد که از روی وضعیتِ فعلیِ DB تشخیص می‌دهد اختصاص جدید است یا جایگزینی؛ در یک تراکنش: `replacedAt` ردیف فعالِ قبلی + درج ردیف جدید + ست `Deal.driverId`. راننده باید از همان شرکتِ اختصاص‌داده‌شده باشد.

`assignTransportCompanyAction`, `driver/[token]`, `regenerateDriverLinkAction` **دست‌نخورده**.

---

## ۸. تایید نهایی خریدار (§۸)

ماشین موجود `enforceDiscrepancyWindowClose()` reuse شد — بعد از عبور `discrepancyReportDeadline` یک `DealConfirmation(type:'buyer_confirm', finalVerdict:'auto_no_discrepancy')` می‌سازد و `qualityAutoAccepted=true` می‌کند. بازنویسی نشد؛ فقط فاز نهایی Deal پس از آن به `settled` هدایت می‌شود. بدون deadline موازی.

---

## ۹. Verification

- `npx prisma validate` — پس از هم‌ترازی با introspect (بدون `db push`).
- `npx tsc --noEmit` — فایل‌های فلوی v2 **صفر خطا**؛ ۲۰ خطای موجود همه در فایل‌های نامرتبط (Benchmark charts, tests, PanelHeader, dashboard).
- تله‌ی ترتیب رفع شد: تایید پرداخت خریدار قبل از کارمزد فروشنده دیگر تایید کارمزد را قفل نمی‌کند.
- گاردِ `confirmFundsReleased`: آزادسازی وجه فقط از `escrowStatus='secured_manual'` و وضعیتِ غیرترمینال ممکن است (اتمیک با `updateMany` + چکِ `count===0`؛ idempotent). یک Deal در حالت `void`/`cancelled`/`settled` دیگر قابل settle‌شدنِ دستی نیست.

---

## ۱۰. یادداشت‌های بازبینی (findings)

### ۱۰.۱ — fallbackِ تاریخیِ نقش‌ها در `rejectPaymentAction` (عمدی، موقت)

در `rejectPaymentAction`، استخراج نقش با fallback نوشته شده:

```ts
const dir = deal.tradeDirection || 'SELL'
const requesterId = deal.requesterId ?? (dir === 'SELL' ? deal.sellerId : deal.buyerId)
const acceptorId  = deal.acceptorId  ?? (dir === 'SELL' ? deal.buyerId  : deal.sellerId)
```

**چرا:** فیلدهای `requesterId`/`acceptorId`/`tradeDirection` در این فاز nullable هستند (برای backfillِ برگشت‌پذیر، §۴). رکوردهای Dealِ پیش از backfill این فیلدها را `null` دارند؛ fallback همان قانونِ snapshotِ لحظه‌ی Match را بازتولید می‌کند (تنها مسیر قدیمی «خریدار روی آگهی فروش» = `SELL`)، پس منطقِ ابطال §۵ برای رکوردهای قدیمی هم درست کار می‌کند.

**سرنوشت:** بعد از کامل‌شدن backfill و سفت‌کردن constraintها (non-null در مهاجرتِ جدا، §۴)، این fallback تبدیل به کدِ مرده می‌شود و در همان فاز پاک‌سازی حذف می‌شود. تا آن‌موقع **عمداً** می‌ماند — حذفِ زودهنگامش رکوردهای در جریان را در مسیر رد پرداخت می‌شکند.

### ۱۰.۲ — نامتقارنیِ شروعِ مهلت کارمزد بین SELL و BUY (بررسی‌شده — رفع لازم نیست در این فاز)

**مشاهده:** مسیر SELL (`createDealFromListingAction`) در پایان `startSellerFeeDeadline(materialListingId)` را صدا می‌زند؛ مسیر BUY (`acceptPurchaseRequestAction`) هیچ معادلی ندارد.

**بررسی — سند چه می‌گوید:** `new-deal-flow.md` در بندهای ۱/۳/۹ دربارهٔ *لحظه‌ی شروعِ پنجره‌ی کارمزد* **سکوت** کرده؛ فقط می‌گوید Deal در لحظه‌ی accept ساخته می‌شود و دو Payment از همان ابتدا `PENDING`اند. مرحله‌ی `awaiting_approval`/`confirmed` در سند مدل نشده — آن یک آرتیفکتِ legacyِ تاییدِ قیمت است.

**چرا نامتقارنی اینجا مشکلِ رفتاری نیست:**

1. **تعهدِ واقعیِ v2 از قبل متقارن است.** هر دو مسیر همان لحظه‌ی Match دو ردیفِ `DealPayment` (`BUYER_GOODS` + `SELLER_FEE`, `PENDING`) می‌سازند — این دقیقاً چیزی است که سند (§۹) می‌خواهد. تعهدِ کارمزدِ فروشنده در هر دو مسیر یکسان ثبت می‌شود.
2. **`startSellerFeeDeadline` یک کلاکِ legacy است، نه گیتِ v2.** این تابع دو کارِ قدیمی می‌کند: (الف) رزروِ listing (`validityStatus → 'reserved'`)، (ب) ست‌کردنِ `materialListing.feeDeadline`. در BUY، رزرو از قبل با `purchaseRequest.status → 'reserved'` داخل تراکنش انجام شده، پس نیمِ اولِ کار لازم نیست.
3. **کلاکِ legacy روی Dealهای BUY اصلاً fire نمی‌شود.** دو enforcerِ کارمزد به این گیت‌ها بسته‌اند:
   - `enforceSellerFeeDeadlines` → `validityStatus='reserved'` (فقط `MaterialListing`).
   - `enforceDealSellerFeeDeadlines` → `deal.status='confirmed'`.
   
   Dealهای BUY در `status='draft'` می‌مانند و مستقیم به `transport_pending` می‌روند (هیچ‌چیز BUY را به `confirmed` نمی‌برد). پس حتی اگر `deal.sellerFeeDeadline` را همان لحظه‌ی ساختِ BUY ست کنیم، `enforceDealSellerFeeDeadlines` هرگز رویش کار نمی‌کند — فیلد صرفاً تزئینی می‌شد.

**نتیجه:** غریزهٔ تقارن درست است، ولی روی *تعهد* اعمال می‌شود که از قبل (با دو ردیف `DealPayment`) برقرار است. تکثیرِ `startSellerFeeDeadline` در BUY، مکانیزمِ اشتباه را هدف می‌گیرد (کلاکی که v2 دارد بازنشسته‌اش می‌کند) و روی Dealهای draft بی‌اثر است. رفعِ درست = enforcementِ یکنواختِ timeout بر پایه‌ی ردیفِ `SELLER_FEE` برای هر دو مسیر، که یک sweepِ جدید است و به **فاز پاک‌سازیِ جدا** (کنارِ حذفِ فیلدهای legacy و fallbackِ §۱۰.۱) موکول می‌شود، نه این فاز.
