'use server'

import prisma from '@/lib/prisma'
import { revalidatePath } from 'next/cache'
import { getCurrentUser } from '@/lib/currentUser'
import { startBuyerPaymentDeadline } from '@/lib/dealDeadlines'
import { savePaymentReceipt, attachPaymentReceipt } from '@/lib/paymentReceipt'
import { submitDiscrepancyReport } from '@/lib/disputes'
import { logAudit } from '@/lib/logger'

/**
 * کنش‌های سمت سرور پنل «معاملات من».
 * دو طرف معامله از روی خود رکورد Deal تشخیص داده می‌شن:
 *   خریدار  = deal.buyerId
 *   فروشنده = deal.materialListing.userId
 * همه‌ی چک‌های دسترسی همین‌جا و مستقل از UI انجام می‌شن.
 */

/** وضعیت‌هایی که خریدار هنوز می‌تونه رسید پرداخت آپلود کنه */
const RECEIPT_UPLOAD_STATUSES = ['confirmed', 'seller_fee_paid']

/** وضعیت‌هایی که معامله (قبل از بارگیری) قابل لغو دستی‌ست */
const CANCELABLE_STATUSES = ['draft', 'awaiting_approval', 'confirmed', 'seller_fee_paid']

/**
 * فروشنده، پیشنهادِ پیش‌نویس یک خریدار رو می‌پذیره. بعد از پذیرش، مهلت
 * پرداخت خریدار شروع می‌شه؛ اگه قیمت توافقی نیاز به تایید کارشناس داشته
 * باشه، startBuyerPaymentDeadline خودش وضعیت رو روی awaiting_approval می‌ذاره.
 */
export async function acceptDealOfferAction(dealId: string) {
  const user = await getCurrentUser()

  const deal = await prisma.deal.findUnique({
    where: { id: dealId },
    include: { materialListing: true },
  })
  if (!deal || !deal.materialListing) throw new Error('معامله پیدا نشد.')
  if (deal.status !== 'draft') throw new Error('این پیشنهاد دیگر در وضعیت پذیرش نیست.')
  if (user.id !== deal.materialListing.userId) throw new Error('فقط فروشنده‌ی آگهی می‌تونه پیشنهاد رو بپذیره.')

  // در هر دو حالت (قیمت‌دار / بدون قیمت) همین تابع وضعیت و مهلت رو می‌چینه
  await startBuyerPaymentDeadline(dealId, false)

  await logAudit('deal', 'قبول پیشنهاد', user.id, { dealId, action: 'offer_accepted' })
  revalidatePath('/my-deals')
}

/**
 * فروشنده، پیشنهادِ پیش‌نویس رو رد می‌کنه: معامله لغو و آگهی دوباره فعال می‌شه.
 */
export async function rejectDealOfferAction(dealId: string) {
  const user = await getCurrentUser()

  const deal = await prisma.deal.findUnique({
    where: { id: dealId },
    include: { materialListing: true },
  })
  if (!deal || !deal.materialListing) throw new Error('معامله پیدا نشد.')
  if (deal.status !== 'draft') throw new Error('این پیشنهاد دیگر در وضعیت پذیرش نیست.')
  if (user.id !== deal.materialListing.userId) throw new Error('فقط فروشنده‌ی آگهی می‌تونه پیشنهاد رو رد کنه.')

  await prisma.deal.update({ where: { id: dealId }, data: { status: 'cancelled' } })
  if (deal.materialListingId) {
    await prisma.materialListing.update({
      where: { id: deal.materialListingId },
      data: { validityStatus: 'active' },
    })
  }

  await logAudit('deal', 'رد پیشنهاد', user.id, { dealId, action: 'offer_rejected' })
  revalidatePath('/my-deals')
}

/**
 * خریدار، فیش/رسید پرداخت رو آپلود می‌کنه — فقط تا قبل از تضمین وجه
 * (وضعیت confirmed یا seller_fee_paid) و وقتی رسیدی ثبت نشده باشه.
 */
export async function uploadDealPaymentReceiptAction(formData: FormData) {
  const dealId = String(formData.get('dealId') || '')
  const file = formData.get('receiptFile') as File | null

  const user = await getCurrentUser()
  if (!dealId || !file || file.size === 0) return

  const deal = await prisma.deal.findUnique({ where: { id: dealId } })
  if (!deal) throw new Error('معامله پیدا نشد.')
  if (user.id !== deal.buyerId) throw new Error('فقط خریدار می‌تونه رسید پرداخت رو ثبت کنه.')
  if (!RECEIPT_UPLOAD_STATUSES.includes(deal.status)) throw new Error('در وضعیت جاری امکان ثبت رسید پرداخت وجود ندارد.')

  const url = await savePaymentReceipt(file)
  await attachPaymentReceipt('deal', dealId, url, user.id)

  revalidatePath(`/my-deals/${dealId}`)
}

/**
 * خریدار، گزارش مغایرت کیفی رو توی پنجره‌ی مهلت اعلام می‌کنه. موارد انتخابی
 * از formData.getAll('items') گرفته می‌شن؛ submitDiscrepancyReport خودش حساس/جزئی
 * بودن رو تشخیص می‌ده و در صورت لزوم تایمر واریز رو فریز و Dispute باز می‌کنه.
 */
export async function reportDiscrepancyAction(formData: FormData) {
  const dealId = String(formData.get('dealId') || '')
  const note = String(formData.get('note') || '').trim()
  const selectedItems = formData.getAll('items').map((v) => String(v)).filter(Boolean)

  const user = await getCurrentUser()
  if (!dealId || selectedItems.length === 0) return

  const deal = await prisma.deal.findUnique({ where: { id: dealId } })
  if (!deal) throw new Error('معامله پیدا نشد.')
  if (user.id !== deal.buyerId) throw new Error('فقط خریدار می‌تونه مغایرت گزارش کنه.')

  await submitDiscrepancyReport({ dealId, raisedById: user.id, selectedItems, note })

  await logAudit('deal', 'ثبت گزارش مغایرت', user.id, { dealId, action: 'discrepancy_reported', count: selectedItems.length })
  revalidatePath(`/my-deals/${dealId}`)
}

/**
 * لغو دستی معامله — خریدار یا فروشنده، فقط تا پیش از مرحله‌ی بارگیری
 * (draft/awaiting_approval/confirmed/seller_fee_paid). آگهی دوباره فعال می‌شه.
 */
export async function cancelDealAction(formData: FormData) {
  const dealId = String(formData.get('dealId') || '')
  const reason = String(formData.get('reason') || '').trim()

  const user = await getCurrentUser()
  if (!dealId) return

  const deal = await prisma.deal.findUnique({
    where: { id: dealId },
    include: { materialListing: true },
  })
  if (!deal) throw new Error('معامله پیدا نشد.')

  const isBuyer = user.id === deal.buyerId
  const isSeller = Boolean(deal.materialListing && user.id === deal.materialListing.userId)
  if (!isBuyer && !isSeller) throw new Error('شما طرف این معامله نیستید.')
  if (!CANCELABLE_STATUSES.includes(deal.status)) throw new Error('این معامله در وضعیت جاری قابل لغو نیست.')

  await prisma.deal.update({ where: { id: dealId }, data: { status: 'cancelled' } })
  if (deal.materialListingId) {
    await prisma.materialListing.update({
      where: { id: deal.materialListingId },
      data: { validityStatus: 'active' },
    })
  }

  await logAudit('deal', 'لغو معامله', user.id, { dealId, action: 'deal_cancelled', reason: reason || null })
  revalidatePath('/my-deals')
  revalidatePath(`/my-deals/${dealId}`)
}
