'use server'

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import { AccessDeniedError } from '@/lib/errorCodes'
import { logAudit } from '@/lib/logger'
import { hashPassword } from '@/lib/auth'
import { getPasswordPolicy, validatePassword } from '@/lib/passwordPolicy'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import crypto from 'crypto'
import type { CreateTransportCompanyState } from './types'

async function requireLogisticsEditAccess() {
  const user = await getCurrentUser()
  if (user.role === 'admin') return user
  const access = await getAllSectionAccess(user.id)
  if (access.logistics !== 'edit' && access.logistics !== 'full') {
    throw new AccessDeniedError(
      'A-SECTION-LOGISTICS',
      'دسترسی مدیریت حمل‌ونقل داخلی رو نداری — از مدیر بخواه بهت بده.'
    )
  }
  return user
}

/** شرکت حمل‌ونقل و حساب مدیرش رو در یک عملیات اتمیک می‌سازه. */
export async function createTransportCompanyAction(
  _prevState: CreateTransportCompanyState,
  formData: FormData
): Promise<CreateTransportCompanyState> {
  const currentUser = await requireLogisticsEditAccess()
  const companyName = String(formData.get('companyName') || '').trim()
  const contactPhone = String(formData.get('contactPhone') || '').trim()
  const managerIdentifier = String(formData.get('managerIdentifier') || '').trim()
  const initialPassword = String(formData.get('initialPassword') || '')

  if (!companyName || !contactPhone || !managerIdentifier || !initialPassword) {
    return { status: 'error', message: 'همه‌ی فیلدها رو کامل کن.' }
  }
  if (companyName.length > 120) {
    return { status: 'error', message: 'نام شرکت نباید بیشتر از ۱۲۰ کاراکتر باشه.' }
  }
  if (!/^09\d{9}$/.test(contactPhone)) {
    return { status: 'error', message: 'تلفن تماس شرکت باید به‌شکل ۰۹xxxxxxxxx باشه.' }
  }

  const looksLikePhone = /^\d+$/.test(managerIdentifier)
  if (looksLikePhone && !/^09\d{9}$/.test(managerIdentifier)) {
    return { status: 'error', message: 'شماره‌ی مدیر باید به‌شکل ۰۹xxxxxxxxx باشه.' }
  }
  if (!looksLikePhone && (managerIdentifier.length < 3 || managerIdentifier.length > 64 || /\s/.test(managerIdentifier))) {
    return { status: 'error', message: 'نام کاربری مدیر باید بین ۳ تا ۶۴ کاراکتر و بدون فاصله باشه.' }
  }

  const policy = await getPasswordPolicy()
  const passwordCheck = validatePassword(initialPassword, policy)
  if (!passwordCheck.valid) {
    return { status: 'error', message: passwordCheck.errors[0] }
  }

  // لاگین هر دو ستون رو جست‌وجو می‌کنه؛ بررسی متقاطع جلوی شناسه‌ی مبهم رو می‌گیره.
  const existingUser = await prisma.user.findFirst({
    where: {
      OR: [{ username: managerIdentifier }, { phone: managerIdentifier }],
    },
    select: { id: true },
  })
  if (existingUser) {
    return { status: 'error', message: 'این نام کاربری یا شماره‌ی مدیر قبلاً ثبت شده.' }
  }

  try {
    const company = await prisma.transportCompany.create({
      data: {
        name: companyName,
        contactPhone,
        isActive: true,
        logisticsAccessEnabled: false,
        managerUser: {
          create: {
            companyName,
            username: looksLikePhone ? null : managerIdentifier,
            phone: looksLikePhone ? managerIdentifier : null,
            passwordHash: hashPassword(initialPassword),
            passwordChangedAt: new Date(),
            role: 'transport_manager',
            isActive: true,
          },
        },
      },
      select: { id: true, managerUserId: true },
    })

    await logAudit('logistics', 'شرکت حمل‌ونقل و حساب مدیر آن ساخته شد', currentUser.id, {
      transportCompanyId: company.id,
      managerUserId: company.managerUserId,
    })
  } catch (error) {
    if ((error as { code?: string }).code === 'P2002') {
      return { status: 'error', message: 'این نام کاربری یا شماره‌ی مدیر قبلاً ثبت شده.' }
    }
    throw error
  }

  revalidatePath('/admin-logistics')
  return { status: 'success', message: 'شرکت حمل‌ونقل و حساب مدیر با موفقیت ساخته شد.' }
}

/**
 * لینک راننده‌ی جدید برای یه Deal می‌سازه — برای وقتی که لینک قبلی منقضی/گم
 * شده. مهلت اعتبار پیش‌فرض: ۴۸ ساعت (هم‌الگوی سایر لینک‌های موقت پروژه).
 */
export async function regenerateDriverLinkAction(formData: FormData) {
  const user = await requireLogisticsEditAccess()
  const dealId = String(formData.get('dealId') || '').trim()
  if (!dealId) throw new Error('شناسه‌ی معامله مشخص نیست.')

  const deal = await prisma.deal.findUnique({ where: { id: dealId } })
  if (!deal) throw new Error('معامله پیدا نشد.')

  // شماره‌ی تماس راننده: از آخرین DealConfirmation (اگه ثبت شده) یا آخرین
  // DriverAccessLink قبلی می‌گیریم — این فیلد اجباریه، پس نمی‌تونیم خالی بذاریم
  const lastConfirmation = await prisma.dealConfirmation.findFirst({
    where: { dealId, driverPhone: { not: null } },
    orderBy: { confirmedAt: 'desc' },
  })
  const lastLink = await prisma.driverAccessLink.findFirst({
    where: { dealId },
    orderBy: { createdAt: 'desc' },
  })
  const phone = lastConfirmation?.driverPhone ?? lastLink?.phone
  if (!phone) {
    throw new Error('شماره‌ی تماس راننده برای این معامله موجود نیست — اول باید یه تاییدیه یا لینک قبلی داشته باشه.')
  }

  const token = crypto.randomBytes(24).toString('hex')
  const expiresAt = new Date(Date.now() + 48 * 60 * 60 * 1000)

  await prisma.driverAccessLink.create({
    data: { dealId, token, phone, expiresAt },
  })

  await logAudit('logistics', `لینک راننده برای معامله‌ی ${dealId.slice(0, 8)} دوباره ساخته شد`, user.id, { dealId })

  revalidatePath('/admin-logistics')
  redirect('/admin-logistics?regenerated=1')
}

/**
 * اختصاص/تغییر شرکت حمل‌ونقل یه معامله — Deal.transportCompanyId (تایید‌شده
 * از schema واقعی سرور). transportCompanyId خالی = برداشتن اختصاص (null).
 */
export async function assignTransportCompanyAction(formData: FormData) {
  const user = await requireLogisticsEditAccess()
  const dealId = String(formData.get('dealId') || '').trim()
  const transportCompanyId = String(formData.get('transportCompanyId') || '').trim() || null

  if (!dealId) throw new Error('شناسه‌ی معامله مشخص نیست.')

  await prisma.deal.update({
    where: { id: dealId },
    data: { transportCompanyId },
  })

  await logAudit('logistics', `شرکت حمل‌ونقل برای معامله‌ی ${dealId.slice(0, 8)} تغییر کرد`, user.id, {
    dealId,
    transportCompanyId,
  })

  revalidatePath('/admin-logistics')
  redirect('/admin-logistics?assigned=1')
}

/**
 * اختصاص یا جایگزینیِ راننده‌ی مشخصِ یک معامله (§۷ سند — Assign/Replace با Audit کامل).
 * یک اکشن واحد که خودش از روی وضعیتِ فعلیِ DB تشخیص می‌ده اختصاص جدیده یا جایگزینی:
 *   - اگر اختصاص فعالی هست (رکورد DealDriverAssignment با replacedAt=null) ⇒ جایگزینی:
 *     replacedAt رکورد قبلی زده می‌شه (نه حذف — تاریخچه append-only) و ردیف جدید درج می‌شه.
 *   - اگر نیست ⇒ اختصاص جدید.
 * در هر دو حالت Deal.driverId هم به‌روزرسانی می‌شه؛ همه در یک تراکنش تا تاریخچه و driverId
 * هیچ‌وقت ناهماهنگ نشن. راننده باید از همون شرکت حمل‌ونقلِ اختصاص‌داده‌شده به معامله باشه
 * (شرکت = چترِ بالادست، طبق تصمیم قفل‌شده‌ی سند).
 */
export async function assignDriverAction(formData: FormData) {
  const user = await requireLogisticsEditAccess()
  const dealId = String(formData.get('dealId') || '').trim()
  const driverId = String(formData.get('driverId') || '').trim()
  const reason = String(formData.get('reason') || '').trim() || null

  if (!dealId) throw new Error('شناسه‌ی معامله مشخص نیست.')
  if (!driverId) throw new Error('راننده انتخاب نشده.')

  // منبعِ حقیقت را server-side می‌خوانیم — کلاینت فقط dealId/driverId می‌فرستد (کنوانسیون امنیتیِ Server Actions).
  const deal = await prisma.deal.findUnique({
    where: { id: dealId },
    select: { id: true, status: true, transportCompanyId: true, driverId: true },
  })
  if (!deal) throw new Error('معامله پیدا نشد.')
  if (deal.status === 'void' || deal.status === 'cancelled') {
    throw new Error('این معامله باطل/لغو شده — امکان اختصاص راننده نیست.')
  }
  if (!deal.transportCompanyId) {
    throw new Error('اول باید شرکت حمل‌ونقلِ این معامله مشخص بشه، بعد راننده‌ای از همون شرکت اختصاص داده بشه.')
  }

  const driver = await prisma.driver.findUnique({
    where: { id: driverId },
    select: { id: true, isActive: true, transportCompanyId: true },
  })
  if (!driver) throw new Error('راننده پیدا نشد.')
  if (!driver.isActive) throw new Error('این راننده غیرفعاله — نمی‌شه اختصاصش داد.')
  if (driver.transportCompanyId !== deal.transportCompanyId) {
    throw new Error('راننده باید از همون شرکت حمل‌ونقلِ اختصاص‌داده‌شده به این معامله باشه.')
  }
  if (deal.driverId === driverId) {
    throw new Error('این راننده همین حالا راننده‌ی فعالِ این معامله‌ست.')
  }

  const isReplace = !!deal.driverId

  // تاریخچه‌ی append-only: رکورد فعالِ قبلی (اگه بود) replacedAt می‌خوره، ردیف جدید درج می‌شه،
  // و Deal.driverId ست می‌شه — اتمیک.
  await prisma.$transaction(async (tx) => {
    await tx.dealDriverAssignment.updateMany({
      where: { dealId, replacedAt: null },
      data: { replacedAt: new Date() },
    })
    await tx.dealDriverAssignment.create({
      data: { dealId, driverId, assignedById: user.id, reason },
    })
    await tx.deal.update({
      where: { id: dealId },
      data: { driverId },
    })
  })

  await logAudit(
    'logistics',
    isReplace
      ? `راننده‌ی معامله‌ی ${dealId.slice(0, 8)} جایگزین شد`
      : `راننده به معامله‌ی ${dealId.slice(0, 8)} اختصاص یافت`,
    user.id,
    { dealId, driverId, previousDriverId: deal.driverId, isReplace, reason }
  )

  revalidatePath('/admin-logistics')
  redirect(`/admin-logistics?driver=${isReplace ? 'replaced' : 'assigned'}`)
}
