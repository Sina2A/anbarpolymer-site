'use server'

import prisma from '@/lib/prisma'
import { revalidatePath } from 'next/cache'
import { addHoliday, removeHoliday, importHolidaysFromCsv } from '@/lib/holidays'
import { adjustDealDeadline, AdjustableDeadlineField } from '@/lib/deadlineAdjustments'
import { updateDealRuleSettings, restrictUser, PENALTY_HOURS_OPTIONS } from '@/lib/dealDeadlines'
import { getCurrentUser } from '@/lib/currentUser'
import { AccessDeniedError } from '@/lib/errorCodes'
import { logAudit } from '@/lib/logger'
import { redirect } from 'next/navigation'

/**
 * این تابع هیچ تراکنش بانکی واقعی انجام نمی‌ده — فقط وضعیتی رو ثبت می‌کنه که تیم
 * حسابداری، بیرون از سایت، بین خودش و بانک انجام داده. طبق تصمیمی که گرفته شد:
 * «سایت قرار نیست به سیستم بانکی وصل بشه، این برای بخش حسابداریه.»
 *
 * توجه (v2): confirmFundsSecured قدیمی که status را به 'payment_secured' می‌برد حذف شد —
 * همان تابع بود که تله‌ی ترتیب می‌ساخت (بعدش markSellerFeePaid با شرط status==='confirmed'
 * برای همیشه قفل می‌شد). تاییدِ پرداخت خریدار حالا از مسیر approvePaymentAction روی ردیفِ
 * DealPayment(kind:'BUYER_GOODS') انجام می‌شه؛ گیتِ عبور به حمل بر پایه‌ی دو ردیف است نه status.
 */
export async function confirmFundsReleased(formData: FormData) {
  const dealId = String(formData.get('dealId'))
  const confirmedById = String(formData.get('confirmedById') || '')

  // گاردِ #1: آزادسازی وجه فقط وقتی مجاز است که (الف) وجه خریدار واقعاً نزد ما تضمین شده
  // باشد (escrowStatus==='secured_manual') و (ب) معامله در وضعیتِ مرده/نهایی نباشد
  // (void/cancelled/settled). بدون این شرط، اگر رد یک پرداخت معامله را void کرده باشد،
  // زدنِ همین دکمه void را به settled برمی‌گرداند و وجهی را که هرگز تضمین/باید آزاد نمی‌شد
  // «آزادشده» ثبت می‌کند. شرط داخل updateMany اتمیک است؛ count===0 یعنی حالت غیرمجاز →
  // نه تغییری اعمال می‌شود و نه لاگِ آزادسازیِ کاذب ثبت می‌گردد. همین شرط idempotent هم هست
  // (روی معامله‌ی از قبل released_manual دوباره اجرا نمی‌شود).
  const released = await prisma.deal.updateMany({
    where: {
      id: dealId,
      escrowStatus: 'secured_manual',
      status: { notIn: ['void', 'cancelled', 'settled'] },
    },
    data: {
      escrowStatus: 'released_manual',
      escrowConfirmedById: confirmedById || null,
      escrowConfirmedAt: new Date(),
      status: 'settled',
    },
  })
  if (released.count === 0) {
    throw new Error('آزادسازی وجه در وضعیت جاری معامله مجاز نیست (وجه تضمین‌نشده یا معامله لغو/باطل/تسویه‌شده است).')
  }
  await logAudit('deal', `آزادسازی وجه معامله ${dealId.slice(0, 8)}`, confirmedById || null, { dealId, action: 'funds_released' })
  revalidatePath('/admin-deals')
}

export async function addHolidayAction(formData: FormData) {
  const date = String(formData.get('date') || '')
  const title = String(formData.get('title') || '')
  if (!date) return
  await addHoliday(date, title)
  revalidatePath('/admin-deals')
}

export async function removeHolidayAction(formData: FormData) {
  const id = String(formData.get('id') || '')
  if (!id) return
  await removeHoliday(id)
  revalidatePath('/admin-deals')
}

export async function adjustDeadlineAction(formData: FormData) {
  const dealId = String(formData.get('dealId') || '')
  const field = String(formData.get('field') || '') as AdjustableDeadlineField
  const hours = Number(formData.get('hours'))
  const reason = String(formData.get('reason') || '')
  const adjustedById = String(formData.get('adjustedById') || '')

  if (!dealId || !field || !Number.isFinite(hours) || !adjustedById) return

  await adjustDealDeadline({ dealId, field, hoursDelta: hours, reason, adjustedById })
  revalidatePath('/admin-deals')
}

export async function importHolidaysAction(formData: FormData) {
  const file = formData.get('csvFile') as File | null
  if (!file || file.size === 0) return

  const csvText = await file.text()
  const { addedCount, skippedLines } = await importHolidaysFromCsv(csvText)

  revalidatePath('/admin-deals')
  redirect(`/admin-deals?imported=${addedCount}&skipped=${skippedLines}`)
}

// توجه: تنظیم ساعات کاری هفتگی (upsertWeeklyHourAction) از اینجا به
// src/app/admin-users/actions.ts منتقل شد — چون سینا خواست این تنظیم کنار
// بقیه‌ی مدیریت کاربران/دسترسی‌ها باشه، نه توی صفحه‌ی معاملات.

/**
 * تنظیم طول مهلت‌های معامله — فقط مدیر (چک سمت سرور، مستقل از UI)، چون این
 * روی محاسبه‌ی مهلت مالی همه‌ی معاملات بعدی اثر می‌ذاره.
 */
export async function updateDealRulesAction(formData: FormData) {
  const currentUser = await getCurrentUser()
  if (currentUser.role !== 'admin') {
    throw new AccessDeniedError('A-ROLE-DEALS', 'فقط نقش مدیر مجاز به تغییر قوانین معامله‌ست.')
  }

  const clampInt = (raw: FormDataEntryValue | null, fallback: number) => {
    const n = Math.round(Number(raw))
    if (!Number.isFinite(n) || n < 1) return fallback
    return Math.min(999, n)
  }

  await updateDealRuleSettings(
    {
      sellerFeeHours: clampInt(formData.get('sellerFeeHours'), 24),
      buyerPaymentHours: clampInt(formData.get('buyerPaymentHours'), 72),
      discrepancyReportHours: clampInt(formData.get('discrepancyReportHours'), 4),
      fundReleaseHours: clampInt(formData.get('fundReleaseHours'), 8),
      driverSilenceDays: clampInt(formData.get('driverSilenceDays'), 5),
      proformaConfirmHours: clampInt(formData.get('proformaConfirmHours'), 8),
    },
    currentUser.id
  )
  revalidatePath('/admin-deals')
}

/**
 * دستور پرداختِ اختصاصیِ یک معامله — متن آزادِ کارشناس حسابداری برای خریدار
 * (شماره‌حساب یا پیام «تماس بگیرید»، هر فرمتی). عیناً توی پاپ‌آپ پرداختِ خریدار
 * (DealPaymentModal) بالای گزینه‌ها نشون داده می‌شه. فقط نقش‌های پنل (admin/staff).
 */
export async function updateDealPaymentInstructionsAction(formData: FormData) {
  const currentUser = await getCurrentUser()
  if (currentUser.role !== 'admin' && currentUser.role !== 'staff') {
    throw new AccessDeniedError('A-ROLE-DEALS', 'فقط کاربران پنل (مدیر یا کارشناس) مجاز به ثبت دستور پرداختند.')
  }

  const dealId = String(formData.get('dealId') || '')
  if (!dealId) return
  const text = String(formData.get('paymentInstructionsText') || '').trim()

  await prisma.deal.update({
    where: { id: dealId },
    data: { paymentInstructionsText: text || null },
  })
  await logAudit('deal', `ثبت/ویرایش دستور پرداخت معامله ${dealId.slice(0, 8)}`, currentUser.id, { dealId, action: 'payment_instructions_updated' })
  revalidatePath('/admin-deals')
}

/**
 * تایید معامله توسط مدیر — بعد از این، مهلت پرداخت خریدار شروع می‌شه
 */
export async function approveDealAction(dealId: string) {
  const currentUser = await getCurrentUser()
  if (currentUser.role !== 'admin') throw new Error('فقط مدیر می‌تونه معامله رو تایید کنه.')

  const deal = await prisma.deal.findUnique({ where: { id: dealId } })
  if (!deal) throw new Error('معامله پیدا نشد.')
  if (deal.status !== 'awaiting_approval') throw new Error('فقط معاملات در انتظار تایید قابل تصویبن.')

  await prisma.deal.update({
    where: { id: dealId },
    data: { status: 'confirmed' },
  })

  // مهلت پرداخت خریدار شروع بشه — skipApprovalCheck=true چون همین الان مدیر
  // تاییدش کرد؛ بدون این پرچم، تابع دوباره ارزیابی می‌کنه و status رو برمی‌گردونه
  // به awaiting_approval (حلقه‌ی منطقی)
  const { startBuyerPaymentDeadline } = await import('@/lib/dealDeadlines')
  await startBuyerPaymentDeadline(dealId, true)

  await logAudit('deal', `تایید معامله ${dealId.slice(0, 8)} توسط مدیر`, currentUser.id, { dealId, action: 'deal_approved' })
  revalidatePath('/admin-deals')
}

/**
 * تایید یک پرداخت (v2) — جای markSellerFeePaidAction را می‌گیرد. هر ردیف DealPayment
 * (BUYER_GOODS یا SELLER_FEE) مستقل و بدون ترتیب تایید می‌شود؛ هیچ اکشنی دیگر به
 * status==='confirmed' گیت نمی‌شود (ریشه‌ی تله‌ی ترتیب همین بود). وقتی هر دو ردیف APPROVED
 * شدند، فاز معامله به transport_pending می‌رود. فقط کاربران پنل (مدیر یا کارشناس).
 */
export async function approvePaymentAction(formData: FormData) {
  const currentUser = await getCurrentUser()
  if (currentUser.role !== 'admin' && currentUser.role !== 'staff') {
    throw new AccessDeniedError('A-ROLE-DEALS', 'فقط کاربران پنل (مدیر یا کارشناس) مجاز به تایید پرداختند.')
  }

  const dealId = String(formData.get('dealId') || '')
  const kind = String(formData.get('kind') || '')
  if (!dealId) return
  if (kind !== 'BUYER_GOODS' && kind !== 'SELLER_FEE') throw new Error('نوع پرداخت نامعتبر است.')

  const result = await prisma.$transaction(async (tx) => {
    // فقط از PENDING/SUBMITTED می‌شود APPROVED کرد؛ count===0 یعنی نبود یا قبلاً بررسی شده.
    const reviewed = await tx.dealPayment.updateMany({
      where: { dealId, kind, status: { in: ['PENDING', 'SUBMITTED'] } },
      data: { status: 'APPROVED', reviewedById: currentUser.id, reviewedAt: new Date() },
    })
    if (reviewed.count === 0) throw new Error('این پرداخت پیدا نشد یا قبلاً بررسی شده است.')

    // تاییدِ وجه کالای خریدار = وجه نزد ما تضمین شد (جایگزینِ confirmFundsSecuredِ حذف‌شده).
    // فقط از pending جلو می‌رود تا idempotent باشد و released_manual را برنگرداند. همین گیتِ
    // دکمه‌ی «تایید پرداخت به فروشنده» را باز می‌کند که تنها مسیرِ رسیدن به settled است.
    if (kind === 'BUYER_GOODS') {
      await tx.deal.updateMany({
        where: { id: dealId, escrowStatus: 'pending' },
        data: { escrowStatus: 'secured_manual' },
      })
    }

    // گیتِ عبور به حمل: مقایسه‌ی وضعیت دو ردیف، نه enumِ status.
    const payments = await tx.dealPayment.findMany({ where: { dealId } })
    const bothApproved = payments.length >= 2 && payments.every((p) => p.status === 'APPROVED')
    let transitioned = false
    if (bothApproved) {
      const deal = await tx.deal.findUnique({ where: { id: dealId } })
      if (deal && ['draft', 'awaiting_approval', 'confirmed'].includes(deal.status)) {
        await tx.deal.update({
          where: { id: dealId },
          data: { status: 'transport_pending', sellerFeeDeadline: null, buyerConfirmDeadline: null },
        })
        transitioned = true
      }
    }
    return { transitioned }
  })

  await logAudit('deal', `تایید پرداخت ${kind} معامله ${dealId.slice(0, 8)}`, currentUser.id, {
    dealId,
    kind,
    action: 'payment_approved',
    transportPending: result.transitioned,
  })
  revalidatePath('/admin-deals')
}

/**
 * رد یک پرداخت (v2) — جای rejectDealPaymentAction را می‌گیرد. منطق ابطال §۵ بر پایه‌ی
 * نقشِ ایجاد Match فردِ پرداخت‌ردشده است، نه نقش تجاری‌اش:
 *   • اگر Requester بود ⇒ Deal→void + توقف origin + حذف از بازار (بدون جریمه).
 *   • اگر Acceptor بود ⇒ Deal→void + release origin به مالک اصلی + جریمه‌ی acceptor با طول انتخابی.
 * void‌کردن + تغییر origin اتمیک است؛ جریمه بعد از commit با restrictUser اعمال می‌شود
 * (restrictUser روی prismaِ سراسری کار می‌کند نه tx، پس بیرون از تراکنش می‌ماند تا اتمیک‌بودنِ
 * هسته حفظ شود). فقط کاربران پنل (مدیر یا کارشناس).
 */
export async function rejectPaymentAction(formData: FormData) {
  const currentUser = await getCurrentUser()
  if (currentUser.role !== 'admin' && currentUser.role !== 'staff') {
    throw new AccessDeniedError('A-ROLE-DEALS', 'فقط کاربران پنل (مدیر یا کارشناس) مجاز به رد پرداختند.')
  }

  const dealId = String(formData.get('dealId') || '')
  const kind = String(formData.get('kind') || '')
  const reason = String(formData.get('reason') || '').trim()
  if (!dealId) return
  if (kind !== 'BUYER_GOODS' && kind !== 'SELLER_FEE') throw new Error('نوع پرداخت نامعتبر است.')

  const penaltyRaw = Number(formData.get('penaltyHours'))
  const penaltyHours = (PENALTY_HOURS_OPTIONS as readonly number[]).includes(penaltyRaw) ? penaltyRaw : 24

  const outcome = await prisma.$transaction(async (tx) => {
    const rejected = await tx.dealPayment.updateMany({
      where: { dealId, kind, status: { in: ['PENDING', 'SUBMITTED', 'APPROVED'] } },
      data: { status: 'REJECTED', reviewedById: currentUser.id, reviewedAt: new Date(), rejectionReason: reason || null },
    })
    if (rejected.count === 0) throw new Error('این پرداخت پیدا نشد یا قبلاً رد شده است.')

    const deal = await tx.deal.findUnique({ where: { id: dealId } })
    if (!deal) throw new Error('معامله پیدا نشد.')
    // اگر ردِ پرداختِ قبلی همین معامله را کشته، فقط ردِ همین ردیف ثبت شد و کافی است.
    if (deal.status === 'void' || deal.status === 'cancelled') {
      return { branch: 'already_dead' as const, penalizedUserId: null as string | null }
    }

    // نقش‌ها با fallback برای رکوردهای legacy/backfill (همان قانونِ لحظه‌ی Match).
    const dir = deal.tradeDirection || 'SELL'
    const payerId = kind === 'BUYER_GOODS' ? deal.buyerId : deal.sellerId
    const requesterId = deal.requesterId ?? (dir === 'SELL' ? deal.sellerId : deal.buyerId)
    const acceptorId = deal.acceptorId ?? (dir === 'SELL' ? deal.buyerId : deal.sellerId)

    await tx.deal.update({ where: { id: dealId }, data: { status: 'void' } })

    const payerIsRequester = payerId != null && payerId === requesterId
    if (payerIsRequester) {
      // توقف origin + حذف از بازار (مالکِ درخواست خودش نکول کرده).
      if (dir === 'BUY' && deal.purchaseRequestId) {
        await tx.purchaseRequest.update({ where: { id: deal.purchaseRequestId }, data: { status: 'closed' } })
      } else if (deal.materialListingId) {
        await tx.materialListing.update({ where: { id: deal.materialListingId }, data: { validityStatus: 'cancelled' } })
      }
      return { branch: 'requester' as const, penalizedUserId: null as string | null }
    }

    // release origin به مالک اصلی (بی‌گناه) تا دوباره در بازار قابل‌مچ شود؛ جریمه بعد از commit.
    if (dir === 'BUY' && deal.purchaseRequestId) {
      await tx.purchaseRequest.update({ where: { id: deal.purchaseRequestId }, data: { status: 'open' } })
    } else if (deal.materialListingId) {
      await tx.materialListing.update({ where: { id: deal.materialListingId }, data: { validityStatus: 'active' } })
    }
    return { branch: 'acceptor' as const, penalizedUserId: acceptorId }
  })

  // جریمه بیرون از تراکنش (restrictUser از prismaِ سراسری استفاده می‌کند).
  if (outcome.branch === 'acceptor' && outcome.penalizedUserId) {
    await restrictUser(outcome.penalizedUserId, penaltyHours, reason || 'رد پرداخت در معامله')
  }

  await logAudit('deal', `رد پرداخت ${kind} معامله ${dealId.slice(0, 8)}`, currentUser.id, {
    dealId,
    kind,
    action: 'payment_rejected',
    branch: outcome.branch,
    penalizedUserId: outcome.penalizedUserId,
    penaltyHours: outcome.branch === 'acceptor' ? penaltyHours : null,
    reason: reason || null,
  })
  revalidatePath('/admin-deals')
}
