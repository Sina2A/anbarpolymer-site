import prisma from '@/lib/prisma'
import { getCurrentUserOrNull } from '@/lib/currentUser'
import SupplyTableRow, { SUPPLY_TABLE_COLUMNS } from '@/components/SupplyTableRow'
import DemandTableRow, { DEMAND_TABLE_COLUMNS } from '@/components/DemandTableRow'
import CurrencyTicker from '@/components/CurrencyTicker'
import PublicHeader from '@/components/PublicHeader'
import Footer from '@/components/Footer'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { inputStyle as sharedInputStyle, selectStyle as sharedSelectStyle, emptyStateStyle } from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

const POLYMER_FAMILY_OPTIONS = ['PP', 'HDPE', 'LDPE', 'LLDPE', 'PVC', 'PET', 'PS', 'EPS', 'ABS', 'سایر']

function one(v: string | string[] | undefined): string | undefined {
  if (Array.isArray(v)) return v[0]
  return v
}

export default async function MarketPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>
}) {
  const sp = await searchParams
  const q = one(sp.q)?.trim() || ''
  const family = one(sp.family)?.trim() || ''
  const category = one(sp.category)?.trim() || ''
  const applicationType = one(sp.applicationType)?.trim() || ''
  const producer = one(sp.producer)?.trim() || ''
  const province = one(sp.province)?.trim() || ''
  // بازار دوطرفه: تب «عرضه» (آگهی فروشنده‌ها) و تب «تقاضا» (درخواست خرید خریدارها)
  const view = one(sp.view)?.trim() === 'demand' ? 'demand' : 'supply'

  // ── Check auth/KYC level ──
  const user = await getCurrentUserOrNull()
  let kycLevel = 0
  if (user) {
    const comp = await prisma.company.findUnique({
      where: { userId: user.id },
      select: { kyc: { select: { level: true } } },
    })
    kycLevel = comp?.kyc?.level ?? 0
  }

  // ── Build where (تب عرضه) ──
  const where: Record<string, unknown> = { validityStatus: 'active' }

  if (q) {
    ;(where as any).OR = [
      { grade: { code: { contains: q, mode: 'insensitive' } } },
      { grade: { producer: { contains: q, mode: 'insensitive' } } },
      { grade: { category: { contains: q, mode: 'insensitive' } } },
    ]
  }
  if (family) where.grade = { ...((where.grade as any) || {}), polymerFamily: family }
  if (category) where.grade = { ...((where.grade as any) || {}), category }
  if (applicationType) where.grade = { ...((where.grade as any) || {}), applicationType }
  if (producer) where.grade = { ...((where.grade as any) || {}), producer }
  if (province) where.province = province

  // ── Query ──
  // NOTE: do NOT include `user` here — the full listing is passed to the
  // <ListingDetailModal> client component and would serialize User.passwordHash
  // (and phone/email) into the public page payload. The modal never uses it.
  const listings = await prisma.materialListing.findMany({
    where: where as any,
    include: { grade: true },
    orderBy: { createdAt: 'desc' },
  })

  // ── Filter options ──
  const [allCategories, allApplicationTypes, allProducers, allProvinces] = await Promise.all([
    prisma.grade.findMany({
      where: { isActive: true },
      distinct: ['category'],
      select: { category: true },
      orderBy: { category: 'asc' },
    }),
    prisma.grade.findMany({
      where: { isActive: true, applicationType: { not: null } },
      distinct: ['applicationType'],
      select: { applicationType: true },
      orderBy: { applicationType: 'asc' },
    }),
    prisma.grade.findMany({
      where: { isActive: true },
      distinct: ['producer'],
      select: { producer: true },
      orderBy: { producer: 'asc' },
    }),
    prisma.materialListing.findMany({
      where: { validityStatus: 'active' },
      distinct: ['province'],
      select: { province: true },
      orderBy: { province: 'asc' },
    }),
  ])

  const categories = allCategories.map((r) => r.category)
  const applicationTypes = allApplicationTypes.map((r) => r.applicationType).filter((v): v is string => !!v)
  const producers = allProducers.map((r) => r.producer)
  const provinces = allProvinces.map((r) => r.province)

  // ── تب تقاضا: درخواست‌های خرید باز — حالا با همان فیلترهای تب عرضه ──
  // شمارش همیشه اجرا می‌شه (عددِ روی تب)، لیست کامل فقط وقتی تب تقاضا فعاله.
  // «باز» یعنی status=open و منقضی‌نشده — انقضا تنبل حساب می‌شه، مثل
  // /purchase-requests. درخواست با ساخته‌شدن آگهی بسته نمی‌شه، پس چند
  // فروشنده می‌تونن روی یک درخواست رقابت کنن.
  // فیلترها عین تب عرضه‌اند: q روی کد/تولیدکننده/دسته‌ی گرید، بقیه فیلترها روی
  // grade و province روی خودِ درخواست. چون شرط انقضا خودش OR داره، همه‌ی
  // شرط‌ها داخل AND جمع می‌شن تا OR روی هم نوشته نشه — otherwise the expiry
  // OR would be silently overwritten by the search OR.
  // نکته‌ی امنیتی: include: { user } ممنوعه — این صفحه عمومیه و User شامل
  // passwordHash/phone/email می‌شه؛ همون قاعده‌ی کوئری آگهی‌ها.
  const demandAnd: Record<string, unknown>[] = [
    { OR: [{ expiresAt: null }, { expiresAt: { gte: new Date() } }] },
  ]
  if (q) {
    demandAnd.push({
      OR: [
        { grade: { code: { contains: q, mode: 'insensitive' } } },
        { grade: { producer: { contains: q, mode: 'insensitive' } } },
        { grade: { category: { contains: q, mode: 'insensitive' } } },
      ],
    })
  }
  if (family) demandAnd.push({ grade: { polymerFamily: family } })
  if (category) demandAnd.push({ grade: { category } })
  if (applicationType) demandAnd.push({ grade: { applicationType } })
  if (producer) demandAnd.push({ grade: { producer } })
  const openRequestWhere: Record<string, unknown> = { status: 'open', AND: demandAnd }
  if (province) openRequestWhere.province = province
  const demandCount = await prisma.purchaseRequest.count({ where: openRequestWhere as any })
  const demandRequests =
    view === 'demand'
      ? await prisma.purchaseRequest.findMany({
          where: openRequestWhere as any,
          orderBy: { createdAt: 'desc' },
          include: {
            grade: { select: { code: true, producer: true, category: true, applicationType: true } },
            _count: { select: { listings: true } },
          },
        })
      : []

  // ── فرم فیلتر مشترک هر دو تب ──
  // GET form submits *replace* the action URL's query string, so the hidden
  // `view` input is what actually keeps the demand tab active after submit —
  // the `?view=demand` in the action alone would be dropped.
  const filterForm = (
    <form method="GET" action={view === 'demand' ? '/market?view=demand' : '/market'} style={filterFormStyle}>
      {view === 'demand' && <input type="hidden" name="view" value="demand" />}

      <input
        name="q"
        defaultValue={q}
        placeholder="جستجو: کد گرید، تولیدکننده، دسته…"
        style={inputStyle}
      />

      {/* Quick chips — لینک‌ها view فعلی رو حفظ می‌کنن تا کلیک، تب رو عوض نکنه */}
      <div style={chipRow}>
        {POLYMER_FAMILY_OPTIONS.map((f) => (
          <a
            key={f}
            href={view === 'demand' ? `/market?view=demand&family=${encodeURIComponent(f)}` : `/market?family=${encodeURIComponent(f)}`}
            style={{
              ...chipStyle,
              background: family === f ? colors.warningBg : colors.neutralBg,
              color: family === f ? colors.orange : colors.neutralText,
              fontWeight: family === f ? 700 : 400,
            }}
          >
            {f}
          </a>
        ))}
      </div>

      <select name="category" defaultValue={category} style={selectStyle}>
        <option value="">همه‌ی دسته‌ها</option>
        {categories.map((c) => (
          <option key={c} value={c}>
            {c}
          </option>
        ))}
      </select>
      <select name="applicationType" defaultValue={applicationType} style={selectStyle}>
        <option value="">همه‌ی کاربردها</option>
        {applicationTypes.map((a) => (
          <option key={a} value={a}>
            {a}
          </option>
        ))}
      </select>
      <select name="producer" defaultValue={producer} style={selectStyle}>
        <option value="">همه‌ی تولیدکنندگان</option>
        {producers.map((p) => (
          <option key={p} value={p}>
            {p}
          </option>
        ))}
      </select>
      <select name="province" defaultValue={province} style={selectStyle}>
        <option value="">همه‌ی استان‌ها</option>
        {provinces.map((pr) => (
          <option key={pr} value={pr}>
            {pr}
          </option>
        ))}
      </select>
      <button type="submit" className="btn btn-sm" style={{ whiteSpace: 'nowrap' }}>
        اعمال فیلتر
      </button>
      {(q || family || category || applicationType || producer || province) && (
        <a
          href={view === 'demand' ? '/market?view=demand' : '/market'}
          className="btn btn-sm btn-outline"
          style={{ whiteSpace: 'nowrap' }}
        >
          پاک کردن
        </a>
      )}
    </form>
  )

  return (
    <>
      <CurrencyTicker />
      <PublicHeader activePage="/market" isLoggedIn={!!user} />

      <section>
        <div className="wrap">
          <div className="eyebrow">خرید و فروش مواد اولیه</div>
          <div className="sec-title">بازار صنعتی پلیمر</div>
          <div className="sec-sub" style={{ marginBottom: spacing.lg }}>
            {view === 'supply' ? (
              <>
                آگهی‌های فروش مواد اولیه پلیمری از تولیدکنندگان و فروشندگان سراسر کشور —{' '}
                <b style={{ color: colors.orange }}>{listings.length} آگهی فعال</b>
              </>
            ) : (
              <>
                نیازِ خریدها که خریدارها اعلام کرده‌ن — اگه بار داری، می‌تونی روی همون‌جا آگهی بذاری —{' '}
                <b style={{ color: colors.orange }}>{demandRequests.length} درخواست باز</b>
              </>
            )}
          </div>

          {/* ── تب‌های بازار دوطرفه ── */}
          <div style={tabRowStyle}>
            <a href="/market" style={view === 'supply' ? tabActiveStyle : tabStyle}>
              عرضه‌ی فروشنده‌ها ({listings.length})
            </a>
            <a href="/market?view=demand" style={view === 'demand' ? tabActiveStyle : tabStyle}>
              تقاضای خریدارها ({demandCount})
            </a>
          </div>

          {/* ── Guest CTA ── */}
          {!user && (
            <div style={guestBanner}>
              برای مشاهده‌ی جزئیات کامل، قیمت و خرید،{' '}
              <a href="/signup" style={{ color: colors.orange, fontWeight: 700, textDecoration: 'underline' }}>
                عضو شوید ←
              </a>
            </div>
          )}

          {view === 'supply' ? (
            <>
              {/* ── Filters (همان فرم مشترک) ── */}
              {filterForm}

              {/* ── جدول فشرده‌ی عرضه: هدر + ردیف‌ها؛ روی موبایل اسکرول افقی ── */}
              {listings.length === 0 ? (
                <div style={emptyStyle}>هیچ آگهی فعالی با این فیلتر یافت نشد.</div>
              ) : (
                <div style={tableScrollStyle}>
                  <div style={supplyTableStyle}>
                    <div style={{ ...headRowStyle, gridTemplateColumns: SUPPLY_TABLE_COLUMNS } as React.CSSProperties}>
                      <div style={headCell}>گرید</div>
                      <div style={headCell}>وضعیت</div>
                      <div style={headCell}>قیمت</div>
                      <div style={headCell}>مقدار</div>
                      <div style={headCell}>محل بار</div>
                      <div style={headCell}>مبدأ</div>
                      <div style={headCell}>MFI</div>
                      <div style={headCell}>کاربرد</div>
                      <div style={headCell}>ثبت</div>
                      <div />
                    </div>
                    {listings.map((listing) => (
                      <SupplyTableRow key={listing.id} listing={listing} kycLevel={kycLevel} isGuest={!user} />
                    ))}
                  </div>
                </div>
              )}
            </>
          ) : (
            <>
              {/* ── Filters (همان فرم مشترک) ── */}
              {filterForm}

              {/* ── جدول فشرده‌ی تقاضا: هدر + ردیف‌ها؛ روی موبایل اسکرول افقی ── */}
              {demandRequests.length === 0 ? (
                <div style={emptyStyle}>در حال حاضر هیچ درخواست خرید بازی ثبت نشده.</div>
              ) : (
                <div style={tableScrollStyle}>
                  <div style={demandTableStyle}>
                    <div style={{ ...headRowStyle, gridTemplateColumns: DEMAND_TABLE_COLUMNS } as React.CSSProperties}>
                      <div style={headCell}>گرید</div>
                      <div style={headCell}>مقدار موردنیاز</div>
                      <div style={headCell}>سقف قیمت</div>
                      <div style={headCell}>استان</div>
                      <div style={headCell}>انقضا</div>
                      <div style={headCell}>وضعیت</div>
                      <div style={headCell}>ثبت</div>
                      <div />
                    </div>
                    {demandRequests.map((req) => (
                      <DemandTableRow key={req.id} request={req} isLoggedIn={!!user} />
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </section>

      <Footer />
    </>
  )
}

// ── Styles ──
const guestBanner: React.CSSProperties = {
  background: colors.warningBg,
  color: colors.warningText,
  borderRadius: radius.md,
  padding: '10px 16px',
  fontSize: fontSize.base,
  fontWeight: 600,
  marginBottom: 20,
  textAlign: 'center',
}
const filterFormStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: spacing.md,
  marginBottom: 20,
  padding: spacing.md,
  background: colors.bgHover,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
}
const inputStyle: React.CSSProperties = {
  ...sharedInputStyle,
}
const chipRow: React.CSSProperties = {
  display: 'flex',
  flexWrap: 'wrap',
  gap: 6,
}
const chipStyle: React.CSSProperties = {
  fontSize: fontSize.xs,
  borderRadius: 20,
  padding: '4px 12px',
  textDecoration: 'none',
  transition: 'background .15s',
  cursor: 'pointer',
}
const selectStyle: React.CSSProperties = {
  ...sharedSelectStyle,
  minWidth: 140,
}
const emptyStyle: React.CSSProperties = {
  ...emptyStateStyle,
  padding: 40,
  border: `1px dashed ${colors.borderStrong}`,
  borderRadius: radius.lg,
}
const tabRowStyle: React.CSSProperties = {
  display: 'flex',
  gap: spacing.sm,
  marginBottom: 20,
  borderBottom: `2px solid ${colors.borderSubtle}`,
}
const tabStyle: React.CSSProperties = {
  padding: '10px 18px',
  fontSize: fontSize.base,
  fontWeight: 600,
  color: colors.textMuted,
  textDecoration: 'none',
  borderBottom: '2px solid transparent',
  marginBottom: -2,
  cursor: 'pointer',
}
const tabActiveStyle: React.CSSProperties = {
  ...tabStyle,
  color: colors.navy,
  fontWeight: 800,
  borderBottom: `2px solid ${colors.navy}`,
}
// جدول عرضه: ستون‌هایی با ترکیبی از serif/Sans و حفاظت از wrap کردن
const tableScrollStyle: React.CSSProperties = {
  overflowX: 'auto',
  WebkitOverflowScrolling: 'touch',
  marginBottom: spacing.lg,
}
const supplyTableStyle: React.CSSProperties = {
  minWidth: 760,
}
const demandTableStyle: React.CSSProperties = {
  minWidth: 680,
}
const headRowStyle: React.CSSProperties = {
  display: 'grid',
  gap: 10,
  alignItems: 'center',
  background: colors.navy,
  borderRadius: radius.md,
  padding: '11px 16px',
  marginBottom: 10,
}
const headCell: React.CSSProperties = {
  fontSize: fontSize.xs,
  fontWeight: 700,
  color: '#fff',
  letterSpacing: '0.02em',
  whiteSpace: 'nowrap',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
}
