# نصب آرشیو Deal Flow v2 روی سرور

این آرشیو فقط فایل‌های **تغییریافته/جدیدِ فلوی معامله‌ی v2** را دارد (طبق `NOTES-DEAL-FLOW-V2.md` §۵). فایل‌های پایه‌ی اپ داخلش **نیست** — فرض بر این است که سرور از قبل اپ پایه را دارد.

## ۱. محتوای آرشیو (۱۰ فایل کد + ۲ سند)

```
prisma/schema.prisma
src/app/market/actions.ts
src/app/market/page.tsx
src/app/my-deals/actions.ts
src/app/admin-deals/actions.ts
src/app/admin-deals/page.tsx
src/app/admin-logistics/actions.ts
src/app/admin-logistics/page.tsx
src/lib/dealDeadlines.ts
src/components/DemandTableRow.tsx
NOTES-DEAL-FLOW-V2.md
DEPLOY-README-DEAL-FLOW-V2.md
```

## ۲. روش استخراج

از **ریشه‌ی پروژه** روی سرور (مسیرها نسبی‌اند و سرجای خودشان می‌نشینند):

```bash
sha256sum -c deal-flow-v2.tar.gz.sha256   # تأیید سلامت
tar xzf deal-flow-v2.tar.gz               # استخراج روی ریشه‌ی اپ
```

قبل از استخراج، از فایل‌های فعلی نسخه‌ی پشتیبان بگیرید (این آرشیو ۱۰ فایل موجود را overwrite می‌کند).

## ۳. مهاجرت دیتابیس — الزامی

`schema.prisma` مدل‌های نو (`DealPayment`, `DealDriverAssignment`) + ۴ نقش روی `Deal` + `driverId` را اضافه می‌کند. **هیچ migrate/`db push` در فاز کد اجرا نشده.** روی سرور:

```bash
npx prisma migrate deploy   # یا: npx prisma db push  (طبق روال همین پروژه)
npx prisma generate
```

سپس مستقر بودن جدول را تأیید کنید (چیزی که قرار است با هم مطمئن شویم):

```sql
SELECT to_regclass('"DealPayment"');  -- نباید NULL باشد
```

## ۴. وابستگی‌ها — باید از قبل روی سرور باشند

فایل‌های v2 این ماژول‌های پایه را import می‌کنند ولی داخل آرشیو نیستند. اگر سرور عقب‌تر است و یکی نبود، کامپایل می‌شکند:

- `components/`: AdminNav, ConfirmSubmitButton, CurrencyTicker, Footer, PublicHeader, PurchaseRequestDetailModal, RefundPolicyHint, SupplyTableRow, TrustCardModal
- `lib/`: auth, currentUser, deadlineAdjustments, disputes, errorCodes, holidays, kyc, logger, onlineTime, passwordPolicy, paymentReceipt, permissions, prisma, styles/shared, styles/tokens

مدل `PurchaseRequest` هم باید مقدار `reserved` را در دامنه‌ی `status` بپذیرد (مسیر BUY).

## ۵. بعد از استخراج

```bash
npx tsc --noEmit   # فایل‌های v2 باید صفر خطا بدهند
```

خطاهای موجود در `lucide-react` / `@tanstack/react-table` / `echarts` / `tests/*` **بی‌ربط به v2**اند (وابستگی‌های نصب‌نشده‌ی node_modules) و در baseline هم بودند.

## ۶. تسکِ بعدی (جدا از این آرشیو)

زنگ‌هشدارِ یکپارچه‌ی timeout بر پایه‌ی ردیف `SELLER_FEE` — بعد از تأیید استقرار `DealPayment` روی سرور ساخته می‌شود. جزئیات در `NOTES-DEAL-FLOW-V2.md` §۱۰.
