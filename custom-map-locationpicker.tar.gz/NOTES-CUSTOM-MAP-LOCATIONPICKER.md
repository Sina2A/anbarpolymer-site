# NOTES — نقشه‌ی اختصاصی ایران + انتخابگر موقعیت مشترک (LocationPicker)

## خلاصه

این بسته چهار بخش مرتبط را پیاده می‌کند:

1. **آکاردئون `/contact` (فقط موبایل، زیر ۸۹۹px):** در موبایل، فرم پیام **اول** نمایش داده می‌شود و کارت‌های اطلاعات تماس به‌صورت پیش‌فرض **جمع‌شده** زیر دکمه‌ی «راه‌های تماس ▾» قرار می‌گیرند. چیدمان دو‌ستونه‌ی دسکتاپ **بدون تغییر** است.
2. **`/warehouses` — فهرست و نقشه با هم (بدون کلید تعویض):** دسکتاپ دو‌ستونه (فهرست چپ، نقشه‌ی چسبان راست)؛ موبایل نقشه‌ی فشرده بالا + فهرست پایین. منطق مهمان (لینک و متن شرطی CTA) **کلمه‌به‌کلمه** در هر دو breakpoint حفظ شده است.
3. **نقشه‌ی اختصاصی:** کامپوننت قدیمی مبتنی بر Leaflet/OSM با نقشه‌ی SVG اختصاصی روی مرزهای رسمی (TopoJSON پیوست) جایگزین شد. بدون کالیبراسیون دستی، بدون استفاده از محتوای مستقیم Google Maps.
4. **`LocationPicker` مشترک:** یک کامپوننت تعاملی/فقط‌خواندنیِ قابل‌استفاده‌ی مجدد که روی چهار سطح فعال است: انبارهای مدیریت، احراز هویت، فرم حساب کاربری، و پرونده‌ی KYC مدیریت. به‌همراه مهاجرت Prisma برای افزودن مختصات به `Company` و `Kyc`.

**قواعد رعایت‌شده:** بدون داده‌ی جعلی · بدون محتوای مستقیم Google Maps · هر دو گیت وارسی سبز (`npx tsc --noEmit` → EXIT 0، `npx next build` → موفق).

---

## ⚠️ نکات مهم پیش از نصب (تفاوت با بسته‌های قبلی)

این بسته برخلاف بسته‌های قبلی **دو تغییر زیرساختی** دارد که هنگام نصب باید انجام شوند:

1. **وابستگی جدید:** `react-simple-maps@^5.0.5` (به‌همراه `d3-geo` و `topojson-client`) به `package.json` و `package-lock.json` اضافه شده است → روی سرور حتماً `npm install` اجرا شود.
2. **مهاجرت پایگاه‌داده:** چهار ستون‌ nullable جدید اضافه می‌شود → روی سرور حتماً `npx prisma migrate deploy` اجرا شود.

بدون این دو مرحله، build یا اجرا شکست می‌خورد.

---

## فایل‌های تغییریافته

### جدید
- `src/components/IranMap.tsx` — هسته‌ی نقشه‌ی SVG اختصاصی (react-simple-maps + d3-geo؛ کلیک→مختصات با `projection.invert()`).
- `src/components/LocationPicker.tsx` — انتخابگر موقعیت مشترک (تعاملی/فقط‌خواندنی). پشتیبانی هم‌زمان از فرم‌های FormData (ورودی‌های `name`دار) و فرم‌های JSON (پراپ اختیاری `onChange`).
- `src/components/ContactInfoDisclosure.tsx` — کامپوننت کلاینتیِ آکاردئون کارت‌های تماس (موبایل).
- `src/types/topojson-client.d.ts` — تعریف تایپ ambient برای `topojson-client`.
- `prisma/migrations/20260927000000_add_location_coordinates/migration.sql` — چهار ستون `DOUBLE PRECISION` nullable.
- `public/geoBoundaries-IRN-ADM3.topojson` — دارایی نقشه‌ی مرزهای ایران (۲.۷ مگابایت، در زمان اجرا توسط `IranMap` fetch می‌شود).

### ویرایش‌شده
- `src/components/WarehousesMap.tsx` — بازنویسی روی `IranMap` (به‌جای Leaflet).
- `src/components/AccountForm.tsx` — state مختصات + `LocationPicker` با `onChange` (فرم JSON)؛ ارسال `latitude/longitude` در بدنه‌ی POST.
- `src/app/warehouses/page.tsx` — چیدمان فهرست+نقشه با هم (بدون کلید تعویض)؛ منطق مهمان حفظ شد.
- `src/app/contact/page.tsx` — فرمِ اول + `ContactInfoDisclosure` برای کارت‌های تماس.
- `src/app/globals.css` — بلوک‌های `.contact-grid`/`.contact-disclosure` و `.wh-layout` و سوییچ‌های ۸۹۹px.
- `src/app/admin-warehouses/page.tsx` — `LocationPicker` تعاملی در فرم ساخت + فرم ویرایشِ هر انبار (`<details>`) متصل به `updateWarehouseAction`.
- `src/app/admin-warehouses/actions.ts` — پشتیبانی `updateWarehouseAction` از مختصات.
- `src/app/verification/page.tsx` — `LocationPicker` در گام شرکت (`latitude/longitude`) و گام کارخانه (`factoryLatitude/factoryLongitude`).
- `src/app/verification/actions.ts` — خواندن مختصات از FormData (`toFloatOrNull`).
- `src/app/admin-kyc/[companyId]/page.tsx` — `LocationPicker` در فرم هویت شرکت و فرم تولیدکننده.
- `src/app/admin-kyc/[companyId]/actions.ts` — نوشتن مختصات در `updateCompanyIdentityAction` و `updateProducerFieldsAction`.
- `src/app/api/account/route.ts` — `toFloatOrNull` + نوشتن `latitude/longitude` در create و update.
- `src/lib/kyc.ts` — پارامترهای مختصات در `submitCompanyDocuments` و `submitProducerLicense`.
- `prisma/schema.prisma` — `Company.latitude/longitude` و `Kyc.factoryLatitude/factoryLongitude` (همه `Float?`).
- `package.json` / `package-lock.json` — افزودن `react-simple-maps@^5.0.5`.

---

## بخش‌ها (جزئیات)

### بخش ۱ — آکاردئون `/contact`
- کامپوننت کلاینتیِ `ContactInfoDisclosure` با `useState` باز/بسته می‌شود؛ در دسکتاپ دکمه با CSS پنهان و کارت‌ها همیشه باز هستند (چون `<details>` نیتیو نمی‌تواند «دسکتاپ همیشه‌باز بدون دکمه» و «موبایل پیش‌فرض جمع» را با CSS خالص هم‌زمان بدهد).
- زیر ۸۹۹px: `.contact-grid__form { order: 1 }` و `.contact-disclosure { order: 2 }` → فرم اول.
- داده‌ها فقط واقعی: تلفن `021-91234567` (`direction:ltr`)، دفتر مرکزی «تهران، خیابان ولیعصر، پلاک ۱۲۴»، انبار «انبار یزد — شهرک صنعتی یزد».

### بخش ۲ — `/warehouses` فهرست+نقشه
- بدون هیچ کلید تعویض؛ هر دو هم‌زمان دیده می‌شوند.
- منطق مهمان دست‌نخورده: `href={user ? \`/warehouses/${w.id}\` : '/login'}` و متن شرطیِ CTA.

### بخش ۳ — نقشه‌ی اختصاصی
- `IranMap` از طریق کش ماژول، `public/geoBoundaries-IRN-ADM3.topojson` را fetch می‌کند؛ آبجکت `IRNADM3gbOpen`؛ `geoMercator().fitExtent([[10,10],[790,630]], features)`.
- تبدیل کلیک به مختصات با `getScreenCTM()` + `DOMPoint` + `projection.invert()` — بدون کالیبراسیون دستی.
- بارگذاری در کلاینت با `next/dynamic` و `ssr:false` (فقط داخل Client Component).

### بخش ۴ — `LocationPicker` + مهاجرت
- پراپ‌ها: `latName, lngName, initialLat?, initialLng?, readOnly?, height=340, markerLabel?, contextMarkers?, onChange?`.
- تمام تغییرات state از تابع واحد `apply()` عبور می‌کنند تا `onChange` همیشه شلیک شود (سازگاری با فرم JSONِ `AccountForm`).
- در حالت تعاملی دو `<input type="number" step="any" name={latName}/{lngName}>` رندر می‌شود (سازگاری با Server Actionهای FormData).
- مهاجرت: چهار ستون nullable `DOUBLE PRECISION` (بدون تغییر مخرب، بدون مقدار پیش‌فرض جعلی).

---

## تأیید

- `npx tsc --noEmit` → **EXIT 0**.
- `npx next build` → **موفق**؛ صفحات `/contact`، `/warehouses`، `/warehouses/[id]`، `/account`، `/verification`، `/admin-warehouses`، `/admin-kyc/[companyId]`، `/api/account` کامپایل شدند.
- ۷ نمونه‌ی تعاملی `LocationPicker` روی چهار سطح موردنیاز.
- دارایی نقشه (۲.۷MB) و client تولیدشده‌ی Prisma با فیلدهای جدید حاضر.

> توجه: در این محیط `DATABASE_URL` مقدار placeholder دارد و پایگاه‌داده در دسترس نیست؛ به‌همین دلیل مهاجرت به‌صورت SQL دستی نوشته شده تا روی سرور با `prisma migrate deploy` اجرا شود. `prisma generate` به‌صورت offline اجرا شده تا client فیلدهای جدید را بشناسد.

---

## نصب روی سرور

```bash
# ۱) در ریشه‌ی پروژه، بسته را باز کنید (مسیرها repo-relative هستند)
tar -xzf custom-map-locationpicker.tar.gz

# ۲) وابستگی جدید (react-simple-maps + d3-geo + topojson-client) نصب شود
npm install

# ۳) مهاجرت پایگاه‌داده — الزامی (چهار ستون مختصات)
npx prisma migrate deploy

# ۴) تولید client (در صورت نیاز)
npx prisma generate

# ۵) اطمینان از حضور دارایی نقشه در public/
ls -lh public/geoBoundaries-IRN-ADM3.topojson

# ۶) build تولید
npm run build

# ۷) ری‌استارت سرویس (مطابق روال همیشگی؛ مثلاً pm2/systemd)
#    pm2 restart <app>   یا   systemctl restart <service>
```

**بازگردانی (rollback):** مهاجرت فقط ستون nullable اضافه می‌کند و داده‌ای را تغییر نمی‌دهد؛ برای بازگشت کافی است چهار ستون حذف شوند (`Company.latitude`, `Company.longitude`, `Kyc.factoryLatitude`, `Kyc.factoryLongitude`) و نسخه‌ی قبلی فایل‌ها بازگردانده شود.
