// Ambient types for topojson-client (the package ships no .d.ts and no
// @types/topojson-client is installed). Only the members we use are declared.
// topojson-client is a transitive dep of react-simple-maps and resolves at runtime.
declare module 'topojson-client' {
  import type { Topology, Properties, GeometryObject } from 'topojson-specification'
  import type { Feature, FeatureCollection, Geometry, MultiLineString } from 'geojson'

  // A GeometryCollection object yields a FeatureCollection; any other single
  // geometry yields a Feature. We return the union and narrow on `.type`.
  export function feature(
    topology: Topology,
    object: GeometryObject<Properties> | string,
  ): Feature<Geometry> | FeatureCollection<Geometry>

  export function mesh(
    topology: Topology,
    object?: GeometryObject<Properties> | string,
    filter?: (a: GeometryObject<Properties>, b: GeometryObject<Properties>) => boolean,
  ): MultiLineString
}
