'use client'

// نقشه‌ی انبارها — نسخه‌ی سفارشیِ SVG (بخش ۳). جایگزینِ کاملِ نسخه‌ی قبلیِ Leaflet/OSM.
// هیچ محتوای Google در این نقشه نیست؛ مرزها از geoBoundaries (مجوز باز) می‌آیند.
// همان امضای prop قبلی ({ warehouses }) حفظ شده تا صفحه‌ی /warehouses بدون تغییرِ import کار کند.

import dynamic from 'next/dynamic'
import type { IranMapMarker } from './IranMap'
import { colors } from '@/lib/styles/tokens'

// IranMap فقط در کلاینت اجرا می‌شود (مثل الگوی Leaflet قبلی: ssr:false).
const IranMap = dynamic(() => import('./IranMap'), {
  ssr: false,
  loading: () => <div style={loadingStyle}>در حال بارگذاری نقشه…</div>,
})

type Warehouse = {
  id: string
  name: string
  city: string
  latitude: number | null
  longitude: number | null
  address: string | null
  description: string | null
}

export default function WarehousesMap({
  warehouses,
  height = 420,
}: {
  warehouses: Warehouse[]
  height?: number
}) {
  const withLocation = warehouses.filter((w) => w.latitude != null && w.longitude != null)

  if (withLocation.length === 0) {
    return <div style={emptyStyle}>هیچ انباری با موقعیت جغرافیایی ثبت‌شده وجود ندارد.</div>
  }

  const markers: IranMapMarker[] = withLocation.map((w) => ({
    id: w.id,
    lat: w.latitude as number,
    lng: w.longitude as number,
    label: `${w.name} — ${w.city}`,
    color: colors.navy,
  }))

  return <IranMap height={height} markers={markers} ariaLabel="نقشه‌ی انبارهای فعال" />
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const loadingStyle: React.CSSProperties = {
  height: 420,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: 13,
  color: '#6f7680',
  border: '1px solid #d8dde3',
  borderRadius: 12,
  background: '#fff',
}
const emptyStyle: React.CSSProperties = {
  padding: '40px 20px',
  textAlign: 'center',
  fontSize: 13,
  color: '#6b7280',
  border: '1px solid #d8dde3',
  borderRadius: 12,
  background: '#fff',
}
