'use client'

// آکاردئونِ کارت‌های تماس (بخش ۱ — فقط موبایل).
// دسکتاپ (≥۹۰۰px): دکمه پنهان و کارت‌ها همیشه دیده می‌شوند (کنترل با CSS).
// موبایل (≤۸۹۹px): کارت‌ها به‌صورت پیش‌فرض جمع‌اند و با دکمه‌ی «راه‌های تماس ▾» باز می‌شوند.
// کارت‌ها به‌صورت children پاس داده می‌شوند تا مارک‌آپ و استایلشان عیناً حفظ شود.

import { useState } from 'react'

export default function ContactInfoDisclosure({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false)

  return (
    <div className="contact-disclosure">
      <button
        type="button"
        className="contact-disclosure__summary"
        aria-expanded={open}
        aria-controls="contact-info-panel"
        onClick={() => setOpen((v) => !v)}
      >
        <span>راه‌های تماس</span>
        <svg
          className={`contact-disclosure__chevron${open ? ' is-open' : ''}`}
          width="18"
          height="18"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth={2}
          aria-hidden="true"
        >
          <path d="M6 9l6 6 6-6" />
        </svg>
      </button>

      <div id="contact-info-panel" className={`contact-grid__info${open ? ' is-open' : ''}`}>
        {children}
      </div>
    </div>
  )
}
