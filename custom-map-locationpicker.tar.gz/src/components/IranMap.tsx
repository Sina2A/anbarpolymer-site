'use client'

// نقشه‌ی پایه‌ی ایران (SVG برداری) — هسته‌ی مشترکِ WarehousesMap و LocationPicker.
// منبع مرزها: geoBoundaries (سطح شهرستان/ADM3) — مجوز باز، بدون هیچ محتوای Google.
// پروجکشن با geoMercator().fitExtent از روی مختصات واقعیِ خودِ فایل ساخته می‌شود
// (کالیبراسیون خودکار، بدون Bounding Box یا نقطه‌ی مرجع دستی). همان پروجکشن هم برای
// رندر پین‌ها و هم برای invert کردنِ کلیک (پیکسل → طول/عرض) استفاده می‌شود.

import { useEffect, useMemo, useRef, useState } from 'react'
import { ComposableMap, Geographies, Geography, Marker } from 'react-simple-maps'
import { geoMercator, type GeoProjection } from 'd3-geo'
import { feature } from 'topojson-client'
import type { FeatureCollection, Geometry } from 'geojson'
import type { Topology } from 'topojson-specification'
import { colors } from '@/lib/styles/tokens'

export type IranMapMarker = {
  id: string
  lat: number
  lng: number
  label?: string
  color?: string
}

type IranMapProps = {
  /** ارتفاع رَپر به پیکسل. SVG داخلش کامل و متناسب جا می‌شود. */
  height?: number
  /** پین‌های نمایشی (انبارها و…). */
  markers?: IranMapMarker[]
  /** اگر داده شود، نقشه تعاملی می‌شود: کلیک → (lat, lng). */
  onSelect?: (lat: number, lng: number) => void
  /** پینِ انتخاب‌شده/در‌انتظار (حالت تعاملی). */
  selected?: { lat: number; lng: number } | null
  /** برچسب دسترس‌پذیری. */
  ariaLabel?: string
}

// فضای مختصاتِ داخلیِ SVG (viewBox). نسبت ~۱٫۲۵ نزدیک به کشیدگیِ ایران در مرکاتور.
const VIEW_W = 800
const VIEW_H = 640
const PAD = 10
// نام object داخل TopoJSON (تأییدشده با خواندنِ فایل).
const TOPO_OBJECT = 'IRNADM3gbOpen'

// کَش سطح-ماژول: فایل ۲٫۷مگابایتی فقط یک‌بار برای کل صفحه fetch/decode می‌شود.
let featuresCache: Promise<FeatureCollection<Geometry>> | null = null
function loadIranFeatures(): Promise<FeatureCollection<Geometry>> {
  if (!featuresCache) {
    featuresCache = fetch('/geoBoundaries-IRN-ADM3.topojson')
      .then((r) => {
        if (!r.ok) throw new Error(`map fetch failed: ${r.status}`)
        return r.json() as Promise<Topology>
      })
      .then((topo) => {
        const obj = topo.objects[TOPO_OBJECT]
        const fc = feature(topo, obj)
        // feature() روی یک GeometryCollection یک FeatureCollection برمی‌گرداند؛
        // در غیر این صورت یک Feature تکی که در FeatureCollection می‌پیچیمش.
        if (fc.type === 'FeatureCollection') return fc
        return { type: 'FeatureCollection', features: [fc] } as FeatureCollection<Geometry>
      })
  }
  return featuresCache
}

function round6(n: number): number {
  return Math.round(n * 1e6) / 1e6
}

export default function IranMap({
  height = 420,
  markers = [],
  onSelect,
  selected,
  ariaLabel,
}: IranMapProps) {
  const interactive = typeof onSelect === 'function'
  const [features, setFeatures] = useState<FeatureCollection<Geometry> | null>(null)
  const [failed, setFailed] = useState(false)
  const svgRef = useRef<SVGSVGElement | null>(null)

  useEffect(() => {
    let alive = true
    loadIranFeatures()
      .then((fc) => {
        if (alive) setFeatures(fc)
      })
      .catch(() => {
        if (alive) setFailed(true)
      })
    return () => {
      alive = false
    }
  }, [])

  // پروجکشنِ خودکار از روی مرزهای واقعیِ فایل — همین یک نمونه هم رندر هم invert می‌کند.
  const projection = useMemo<GeoProjection | null>(() => {
    if (!features) return null
    return geoMercator().fitExtent(
      [
        [PAD, PAD],
        [VIEW_W - PAD, VIEW_H - PAD],
      ],
      features,
    )
  }, [features])

  if (failed) {
    return <div style={boxMsgStyle(height)}>بارگذاری نقشه ناموفق بود.</div>
  }
  if (!features || !projection) {
    return <div style={boxMsgStyle(height)}>در حال بارگذاری نقشه…</div>
  }

  function handleClick(e: React.MouseEvent<SVGSVGElement>) {
    if (!interactive || !onSelect) return
    const svg = svgRef.current
    if (!svg) return
    const ctm = svg.getScreenCTM()
    if (!ctm) return
    // پیکسلِ صفحه → مختصاتِ viewBox (مستقل از اسکیلِ CSS و RTL)، سپس invert → [lng, lat].
    const pt = new DOMPoint(e.clientX, e.clientY).matrixTransform(ctm.inverse())
    const inv = projection!.invert?.([pt.x, pt.y])
    if (!inv) return
    const [lng, lat] = inv
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return
    onSelect(round6(lat), round6(lng))
  }

  return (
    <div style={{ ...wrapStyle, height }}>
      <ComposableMap
        // نمونه‌ی پروجکشن عیناً استفاده می‌شود (rsm اگر function باشد همان را برمی‌گرداند).
        projection={projection}
        width={VIEW_W}
        height={VIEW_H}
        ref={svgRef}
        role="img"
        aria-label={ariaLabel ?? 'نقشه‌ی ایران'}
        onClick={interactive ? handleClick : undefined}
        style={{
          width: '100%',
          height: '100%',
          display: 'block',
          cursor: interactive ? 'crosshair' : 'default',
        }}
      >
        <Geographies geography={features}>
          {({ geographies }) =>
            geographies.map((geo) => (
              <Geography
                key={geo.rsmKey}
                geography={geo}
                fill="#eef1f6"
                stroke="#cfd6e0"
                strokeWidth={0.3}
                tabIndex={-1}
                style={{ outline: 'none', pointerEvents: interactive ? 'none' : undefined }}
              />
            ))
          }
        </Geographies>

        {markers.map((m) => (
          <Marker key={m.id} coordinates={[m.lng, m.lat]}>
            <g transform="translate(0,0)" style={{ pointerEvents: interactive ? 'none' : 'auto' }}>
              <circle r={6} fill={m.color ?? colors.navy} stroke="#fff" strokeWidth={1.5} />
              <circle r={2} fill="#fff" />
              {m.label ? <title>{m.label}</title> : null}
            </g>
          </Marker>
        ))}

        {selected ? (
          <Marker coordinates={[selected.lng, selected.lat]}>
            <g style={{ pointerEvents: 'none' }}>
              <circle r={8} fill={colors.orange} stroke="#fff" strokeWidth={2} />
              <circle r={2.5} fill="#fff" />
            </g>
          </Marker>
        ) : null}
      </ComposableMap>
    </div>
  )
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const wrapStyle: React.CSSProperties = {
  width: '100%',
  borderRadius: 12,
  overflow: 'hidden',
  border: `1px solid ${colors.borderStrong}`,
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
  background: '#f7f8fa',
  boxSizing: 'border-box',
}
function boxMsgStyle(height: number): React.CSSProperties {
  return {
    height,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: 13,
    color: colors.textMuted,
    border: `1px solid ${colors.borderStrong}`,
    borderRadius: 12,
    background: '#fff',
  }
}
