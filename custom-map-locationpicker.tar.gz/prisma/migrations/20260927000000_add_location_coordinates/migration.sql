-- Add map-picker coordinates (LocationPicker) to Company and Kyc.
-- All nullable -> backward-safe: existing rows keep NULL until a location is chosen.
-- Warehouse already carries latitude/longitude, so no change there.

-- Company: company/office location
ALTER TABLE "Company" ADD COLUMN "latitude" DOUBLE PRECISION;
ALTER TABLE "Company" ADD COLUMN "longitude" DOUBLE PRECISION;

-- Kyc: producer factory location (paired with factoryAddress)
ALTER TABLE "Kyc" ADD COLUMN "factoryLatitude" DOUBLE PRECISION;
ALTER TABLE "Kyc" ADD COLUMN "factoryLongitude" DOUBLE PRECISION;
