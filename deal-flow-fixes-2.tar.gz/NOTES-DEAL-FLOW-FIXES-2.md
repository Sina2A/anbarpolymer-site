# NOTES — Deal Flow Fixes v2 (بسته‌ی دوم)

سه رفعِ مستقل، هر سه فقط «نوشتن» (بدون build/run/migration/install). تصمیم‌های سینا:
- تقویم شمسی: فقط `Intl` — هیچ dependency نصب نشد.
- مهلت‌های در جریان: اصلاح دستی نشد (توضیح در بخش ۳).
- یادداشت: همین فایلِ مستقل (نه append به `NOTES-DEAL-FLOW-V2.md`).

---

## زنجیره‌ی وضعیت واقعی Deal (مرجع)
از `prisma/schema.prisma:329-331` و اکشن‌ها:
```
draft → confirmed → seller_fee_paid → payment_secured → transport_pending → loading → in_transit → delivered → settled
```
+ `awaiting_approval` (قیمت نیاز به تایید مدیر)، `cancelled`، `void`.

**تصمیم فروشنده** (`src/app/my-deals/actions.ts`):
- `acceptDealOfferAction` فقط روی `draft` کار می‌کند → `startBuyerPaymentDeadline` وضعیت را `confirmed` یا (اگر قیمت تایید می‌خواهد) `awaiting_approval` می‌کند.
- `rejectDealOfferAction` فقط روی `draft` → `cancelled`.
- نتیجه: «فروشنده هنوز تصمیم نگرفته» **دقیقاً** `status === 'draft'` است.

---

## بخش ۱ — گیت پرداخت خریدار پشت تصمیم فروشنده
**فایل:** `src/app/my-deals/[id]/page.tsx`

**باگ:** خط ۶۷ قبلی `canUploadBuyerReceipt = isBuyer && Boolean(buyerPayment) && !buyerPayment!.receiptUrl` هیچ‌جا `deal.status` را چک نمی‌کرد → خریدار حتی در `draft` (قبل از تصمیم فروشنده) کارت پرداخت را می‌دید.

**تغییر:**
- افزوده شد: `const sellerHasDecided = deal.status !== 'draft'`.
- `canUploadBuyerReceipt` حالا شاملِ `&& sellerHasDecided` است.
- افزوده شد: `buyerWaitingForSeller = isBuyer && !sellerHasDecided && Boolean(buyerPayment)`.
- در JSX، پیش از کارت پرداختِ خریدار، یک کارتِ پیام «⏳ در انتظار تایید انبار پلیمر» اضافه شد که فقط وقتی `buyerWaitingForSeller` است نمایش داده می‌شود.
- کارت `SELLER_FEE` (`canUploadSellerReceipt`) **دست‌نخورده** ماند — گیت فقط برای خریدار است.

**چرا `!== 'draft'` نه `=== 'confirmed'`:** در `awaiting_approval` فروشنده *تصمیم گرفته* (قبول کرده)؛ اگر شرط `=== 'confirmed'` بود، خریدار غلط پیامِ «منتظر فروشنده» می‌دید. ضمناً در `awaiting_approval` مقدار `buyerConfirmDeadline` هنوز `null` است، پس ادامه‌ی فرآیند به‌درستی گیت‌شده می‌ماند.

**دست‌نخورده:** `isDealSeller`/`dealRoles.ts`، hrefها، سروراکشن‌ها.

---

## بخش ۲ — admin-logistics معاملات تازه‌ی transport_pending را نمایش می‌دهد
**فایل:** `src/app/admin-logistics/page.tsx` (~خط ۴۸)

**مشکل:** کوئری قبلی `where: { OR: [{ confirmations: { some: {} } }, { driverLinks: { some: {} } }] }` معامله‌های `transport_pending` را که هنوز نه تاییدیه دارند نه راننده (یعنی دقیقاً همان‌هایی که ادمین باید اولین‌بار برایشان اقدام کند) از قلم می‌انداخت.

**تغییر (توسعه، نه تعویض):**
```ts
where: {
  OR: [
    { status: { in: ['transport_pending', 'payment_secured', 'loading', 'in_transit'] } },
    { confirmations: { some: {} } },   // حفظِ legacy
    { driverLinks: { some: {} } },     // حفظِ legacy
  ],
},
```
- افزوده شد: شرط `status: { in: [...] }` — از `transport_pending` تا پیش از `delivered`/`settled`.
- شامل وضعیت‌های legacy: `payment_secured`, `loading`, `in_transit`.
- بیرون: `draft`, `confirmed`, `awaiting_approval`, `delivered`, `settled`, `cancelled`, `void`.
- دو شرطِ قدیمی `OR` **نگه داشته شد** تا هیچ معامله‌ی legacy از دست نرود.

**دست‌نخورده:** بقیه‌ی `include`، منطق تخصیص راننده، سایر بخش‌های صفحه.

---

## بخش ۳ — منطقه‌ی زمانی تهران در محاسبات ساعت کاری
**ریشه‌ی باگ (تایید‌شده با کد):** سرور روی `Etc/UTC` است. در `src/lib/businessHours.ts`:
- `dateKey` از `getFullYear/getMonth/getDate` (تاریخِ UTC)،
- `getDaySchedule` از `day.getDay()` (روزِ هفته‌ی UTC) و `start.setHours()/end.setHours()` (که ساعت را روی UTC می‌نشاند)،

استفاده می‌کرد. یعنی «کدام روز» و «۸ تا ۱۷ کاری» در UTC حساب می‌شد، نه تهران → خطای سیستماتیک ۳.۵ ساعته روی همه‌ی مهلت‌های Deal و Order.

### فایل جدید: `src/lib/tehranClock.ts`
کاملاً آفلاین، فقط `Intl.DateTimeFormat` با `timeZone: 'Asia/Tehran'` — بدون fetch، بدون افستِ دستیِ +۳:۳۰، بدون dependency:
- `tehranParts(at)` — اجزای سال/ماه/روز/ساعت/دقیقه/ثانیه/روزِ‌هفته به وقت تهران (weekday با کنوانسیون `getDay()`: یکشنبه=۰).
- `tehranDateKey(at)` — `YYYY-MM-DD` تهران.
- `tehranDayOfWeek(at)` — ۰..۶ تهران.
- `tehranHM(at)` — `{ h, m }` تهران.
- `tehranWallTimeToInstant(at, hh, mm)` — لحظه‌ی مطلقِ متناظر با «ساعتِ دیواریِ hh:mm در روزِ تهرانیِ at». افستِ تهران از خودِ `Intl` استخراج می‌شود (نه هاردکد).
- `tehranJalaliDisplay(at)` — تاریخ شمسی با `Intl('fa-IR-u-ca-persian')` (calendar persian built-in ICU).
- `tehranClockDisplay(at)` — `HH:MM` با ارقام فارسی.

### rewire در `src/lib/businessHours.ts` (نسخه‌ی موازی ساخته نشد)
- `pad2` و بدنه‌ی قدیمیِ `dateKey` حذف شد؛ `dateKey` حالا `tehranDateKey` را صدا می‌زند.
- `getDaySchedule`: `day.getDay()` → `tehranDayOfWeek(day)`؛ ساختِ `start`/`end` با `setHours` → `tehranWallTimeToInstant(day, ...)`.
- `calculateBusinessHoursDeadline`: لنگرِ روز `cursorDay` از `setHours(0,0,0,0)` (نیمه‌شبِ UTC) → `tehranWallTimeToInstant(cursor, 0, 0)` (نیمه‌شبِ تهران). گامِ `+24h` بدون تغییر (ایران DST ندارد، ۲۴ ساعت همیشه دقیقاً یک روز است).
- `isWithinBusinessHours`: همان لنگرِ روز به `tehranWallTimeToInstant(at, 0, 0)` اصلاح شد.

**چرا فقط businessHours.ts:** «لحظه‌ی مطلق» timezone-agnostic است؛ مقایسه‌ی `now < deadline` و ساختِ `Date.now()+hours` مستقل از timezoneاند و درست کار می‌کنند. تنها جایی که تبدیلِ instant→«ساعت/روزِ دیواری» رخ می‌دهد `businessHours.ts` بود. پس `dealDeadlines.ts` به‌جز بهره‌بردن از توابعِ اصلاح‌شده، **دست‌نخورده** ماند و نیازی نداشت.

**onlineTime.ts دست‌نخورده و بی‌استفاده در این راه‌حل:** آن ماژول یک fetch به worldtimeapi می‌زند و فقط برای هشدارِ drift به مدیر است؛ راه‌حلِ ما به آن وابسته نیست و آن را صدا نمی‌زند.

### نمایش در پنل: `src/app/admin-deals/page.tsx`
داخل کارتِ «⏱ زمان‌بندی و مهلت‌های معامله»، یک سطرِ سبزِ کوچک اضافه شد:
«🕒 الان به وقت تهران: [تاریخ شمسی] — ساعت [HH:MM]» — سروری render می‌شود (صفحه `force-dynamic` است). ادمین می‌تواند چشمی تایید کند که ساعتِ مبنا درست است.

### مهلت‌های در جریان — تصمیم
مهلت‌های ذخیره‌شده (`buyerConfirmDeadline`, `sellerFeeDeadline`, `discrepancyReportDeadline`, `fundReleaseDeadline`, `proformaDeadline`) به‌صورت instant مطلق‌اند. اگر با منطق UTC-غلطِ قبلی حساب شده باشند، مقدار ذخیره‌شده حداکثر حدود ۳.۵ ساعت جابه‌جاست.

**تصمیم (تاییدِ سینا): اصلاح دستی نمی‌شود.** دلایل:
1. این مهلت‌ها معمولاً چند ساعت/روزه‌اند؛ خطای ≤۳.۵ ساعته آن‌ها را فاجعه‌بار جابه‌جا نمی‌کند.
2. هر معامله‌ی جدید از لحظه‌ی این fix درست حساب می‌شود.
3. دست‌کاری دستیِ مهلت‌های فعال ریسکِ ناسازگاری دارد.

اگر بعداً لازم شد، پنلِ موجودِ «تنظیم دستی مهلت» (`adjustDeadlineAction`) امکانِ اصلاحِ تک‌تکِ مهلت‌های فعال را می‌دهد — بدون اسکریپتِ خودکار.

---

## چک‌لیست فایل‌های تغییریافته
| فایل | نوع |
|---|---|
| `src/lib/tehranClock.ts` | جدید |
| `src/lib/businessHours.ts` | rewire به tehranClock |
| `src/app/my-deals/[id]/page.tsx` | گیت status + پیام انتظار |
| `src/app/admin-logistics/page.tsx` | افزودن status به OR کوئری |
| `src/app/admin-deals/page.tsx` | سطر نمایشیِ ساعت تهران |
| `NOTES-DEAL-FLOW-FIXES-2.md` | این فایل |

## رعایتِ قوانین ثابت
- اعداد «چند ساعت کاری» (`sellerFeeHours` و غیره) دست‌نخورده.
- هیچ fetch اینترنتی/API خارجی برای زمان اضافه نشد (فقط `Intl`).
- هیچ dependency نصب نشد؛ `package.json`/lockfile دست‌نخورده.
- منطق دسترسی، hrefها، `isDealSeller`/`dealRoles.ts` دست‌نخورده.
- build/run/migration انجام نشد.
