/**
 * ساعت تهران — تبدیل «لحظه‌ی مطلق» (Date/UTC) به اجزای «ساعتِ دیواریِ تهران».
 *
 * چرا این ماژول: سرور روی UTC تنظیمه (نه Asia/Tehran). متدهای بومیِ Date مثل
 * getDay()/getHours()/getFullYear() اجزای زمان را در منطقه‌ی زمانیِ *سرور* (UTC)
 * می‌دهند — پس محاسبه‌ی «امروز چه روزیه» و «ساعت کاری ۸ تا ۱۷» با ۳.۵ ساعت خطا
 * انجام می‌شد. اینجا همه‌چیز با Intl.DateTimeFormat و timeZone='Asia/Tehran'
 * حساب می‌شه — یه محاسبه‌ی خالصِ آفلاین (نه fetch، نه افستِ دستیِ +3:30).
 *
 * نکته‌ی معماری: «لحظه‌ی مطلق» timezone-agnostic است؛ مقایسه‌ی دو Date (now < deadline)
 * هیچ‌وقت به timezone وابسته نیست. تنها جایی که timezone مهمه، تبدیلِ
 * instant → «ساعت/روزِ دیواری» است — که فقط همین‌جا و در businessHours.ts رخ می‌ده.
 */

function pad2(n: number) {
  return String(n).padStart(2, '0')
}

/** اجزای عددیِ لحظه، به وقت تهران. weekday با کنوانسیون getDay(): یکشنبه=۰ ... شنبه=۶ */
export type TehranParts = {
  year: number
  month: number // ۱..۱۲
  day: number // ۱..۳۱
  hour: number // ۰..۲۳
  minute: number
  second: number
  weekday: number // ۰=یکشنبه ... ۶=شنبه (مطابق Date.getDay)
}

const WEEKDAY_INDEX: Record<string, number> = {
  Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6,
}

const partsFormatter = new Intl.DateTimeFormat('en-US', {
  timeZone: 'Asia/Tehran',
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
  hour: '2-digit',
  minute: '2-digit',
  second: '2-digit',
  hour12: false,
  weekday: 'short',
})

/** لحظه‌ی مطلق را به اجزای ساعتِ دیواریِ تهران می‌شکند (بدون افست دستی). */
export function tehranParts(at: Date = new Date()): TehranParts {
  const map: Record<string, string> = {}
  for (const p of partsFormatter.formatToParts(at)) {
    if (p.type !== 'literal') map[p.type] = p.value
  }
  // Intl گاهی hour را '24' می‌دهد در مرزِ نیمه‌شب؛ به ۰ نرمال می‌کنیم.
  let hour = parseInt(map.hour, 10)
  if (hour === 24) hour = 0
  return {
    year: parseInt(map.year, 10),
    month: parseInt(map.month, 10),
    day: parseInt(map.day, 10),
    hour,
    minute: parseInt(map.minute, 10),
    second: parseInt(map.second, 10),
    weekday: WEEKDAY_INDEX[map.weekday] ?? 0,
  }
}

/** کلید روز به وقت تهران: 'YYYY-MM-DD' — جایگزینِ dateKey مبتنی بر UTC. */
export function tehranDateKey(at: Date = new Date()): string {
  const p = tehranParts(at)
  return `${p.year}-${pad2(p.month)}-${pad2(p.day)}`
}

/** روزِ هفته به وقت تهران (۰=یکشنبه ... ۶=شنبه، مطابق Date.getDay). */
export function tehranDayOfWeek(at: Date = new Date()): number {
  return tehranParts(at).weekday
}

/** ساعت و دقیقه به وقت تهران. */
export function tehranHM(at: Date = new Date()): { h: number; m: number } {
  const p = tehranParts(at)
  return { h: p.hour, m: p.minute }
}

/**
 * افستِ منطقه‌ی زمانیِ تهران در یک لحظه‌ی مشخص، به میلی‌ثانیه (تهران منهای UTC).
 * ایران DST ندارد پس عملاً همیشه +۳:۳۰ است، اما به‌جای هاردکد، از خودِ Intl
 * استخراج می‌شود تا اصولی و مقاوم به تغییرِ آینده باشد.
 */
function tehranOffsetMs(at: Date): number {
  const p = tehranParts(at)
  // لحظه‌ای بساز که اجزای UTCاش دقیقاً برابر اجزای دیواریِ تهرانِ همین لحظه باشد.
  const asUtc = Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second)
  // اختلافِ آن با میلی‌ثانیه‌ی واقعی = افستِ تهران (روی ثانیه گِرد می‌شود).
  const actual = Math.floor(at.getTime() / 1000) * 1000
  return asUtc - actual
}

/**
 * لحظه‌ی مطلقِ متناظر با «ساعتِ دیواریِ hh:mm در همان روزِ تهرانیِ at» را می‌سازد.
 * برای ساختِ مرزهای بازه‌ی کاری (open/close) به‌صورت instant مطلق لازم است —
 * تا مقایسه با cursor/now (که Date مطلق‌اند) درست باشد.
 */
export function tehranWallTimeToInstant(at: Date, hh: number, mm: number): Date {
  const p = tehranParts(at)
  const offset = tehranOffsetMs(at)
  // ساعتِ دیواریِ تهران را به‌عنوان اجزای UTC بساز، بعد افست را کم کن تا instant واقعی به‌دست آید.
  const wallAsUtc = Date.UTC(p.year, p.month - 1, p.day, hh, mm, 0)
  return new Date(wallAsUtc - offset)
}

const jalaliFormatter = new Intl.DateTimeFormat('fa-IR-u-ca-persian', {
  timeZone: 'Asia/Tehran',
  year: 'numeric',
  month: 'long',
  day: 'numeric',
  weekday: 'long',
})

/**
 * نمایشِ تاریخِ شمسیِ لحظه به وقت تهران (مثلاً «شنبه ۲۶ مهر ۱۴۰۴»).
 * کاملاً آفلاین و built-in (تقویم persian در ICUِ Node) — بدون هیچ dependency.
 */
export function tehranJalaliDisplay(at: Date = new Date()): string {
  return jalaliFormatter.format(at)
}

/** نمایشِ ساعتِ تهران به‌صورت 'HH:MM' (ارقام فارسی، جهتِ نمایش). */
export function tehranClockDisplay(at: Date = new Date()): string {
  const { h, m } = tehranHM(at)
  return `${pad2(h)}:${pad2(m)}`.replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[Number(d)])
}
