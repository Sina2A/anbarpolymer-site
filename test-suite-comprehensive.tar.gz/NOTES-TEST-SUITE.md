# Comprehensive Playwright E2E Suite

## Scope

This suite covers the public market and its modal/gate branches, logistics administration and transport-manager creation, public reports/about pages, and concurrency/race-condition probes.

The suite is read-only by default. No test deletes data. Tests that necessarily exercise a real state transition are disabled unless `E2E_UNSAFE_RACE_MUTATIONS=1` is explicitly set; use that flag only against an isolated staging database, never production.

## Files

- `tests/public-market.spec.ts` — market page structure, supply/demand tabs, rows, hover state, detail dialogs, trust cards, search, header active state, and public-payload PII checks.
- `tests/public-market-gates.spec.ts` — guest, buyer-KYC, and seller demand-action gate branches.
- `tests/admin-logistics.spec.ts` — logistics authorization, structure, feedback banners, link-status rendering, and an opt-in-gated assignment mutation.
- `tests/admin-logistics-transport-company.spec.ts` — transport-company form structure, validation, duplicate handling, successful e2e-prefixed creation, manager login routing, and access gating. The test password is never logged or included in this note.
- `tests/public-reports.spec.ts` — archive/detail rendering, featured carousel, search, pagination, TipTap semantics, TOC anchors, and same-origin font requests.
- `tests/public-about.spec.ts` — HTTP/RTL metadata, six sections, header state, ticker, KPIs, footer, same-origin fonts, and computed typography.
- `tests/race-*.spec.ts` — concurrency probes for driver-token consumption, duplicate RFQ, deal funds, listing status, order status, and benchmark publishing. Every one is opt-in gated because its target is a real server record.
- `tests/helpers/race-utils.ts` — base URLs, authenticated contexts, unique `e2e-` tags, and concurrency helpers.

## Safety rules

- No build, migration, browser installation, or test execution was performed while assembling this bundle.
- New records created by the transport-company flow use recognizable `e2e-` prefixes where applicable.
- Race specs intentionally target existing records to probe transaction boundaries; therefore they skip by default.
- `assignTransportCompanyAction` and `regenerateDriverLinkAction` were not changed.
- Password values are not printed, asserted in logs, or persisted in this note.
- The transport-manager redirect assertion checks `/transport-panel` without assuming a port; the application default is port 4000 unless configured otherwise.

## Known source discrepancies (tests assert actual behavior)

- Sufficient-KYC supply action on `/market` is a styled disabled `<span>` («صفحه‌ی شروع معامله به‌زودی»), not a popup — the test asserts the span and that clicking navigates nowhere.
- `/market` detail/trust modals wire no Escape handler — the test documents that Escape keeps the modal open; closing works only via the `بستن` button.
- The deployed `PublicHeader` includes a sliding indicator (indicator state updated by `useLayoutEffect`, using `offsetLeft`/`offsetWidth`); the `/market` test positively verifies that it is visible and aligned beneath the active link. The local `work-src` snapshot is stale for this component and still shows only inline color/fontWeight active styling.
- `/market` has no loading skeleton (no `loading.tsx`, server-rendered) — the skeleton test skips gracefully.
- Guest gates: supply → `/signup`, demand → `/login`; seller demand → `/new-listing?request=<id>`.
- `ReportsSearchBar` filters the count text client-side only; it does not re-filter the server-rendered news grid — the test asserts cards stay put.
- The `work-src` snapshot of `globals.css` still carries a Google Fonts `@import` on line 2. The same-origin font tests enforce the self-hosting requirement and will legitimately fail until that import is removed on the deployed app.

## Configuration

`playwright.config.ts` uses one worker and `fullyParallel: false`, drives the already-installed system Chromium at `/usr/bin/chromium-browser`, and wires setup dependencies for buyer, seller, and admin storage states. The `public` project matches `public-*.spec.ts`; the `admin` project matches both logistics specs; the `race` project matches `race-*.spec.ts`.

## Running later

Run the read-only portions against an approved staging environment with the existing Playwright setup and system Chromium. Do not run `npx playwright install`. To deliberately enable race mutation probes, set `E2E_UNSAFE_RACE_MUTATIONS=1` only after confirming the target is disposable staging data.

The suite feature-detects absent live listings, reports, logistics rows, and KYC branches and skips or records an informational pass rather than creating seed data.
