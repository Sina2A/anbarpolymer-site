import { defineConfig, devices } from '@playwright/test';

/**
 * System Chromium: the CDN (cdn.playwright.dev) is blocked on the server, so we do
 * NOT download a browser. `npx playwright install` must never be run there.
 * `channel: 'chrome'` makes Playwright drive the already-installed system Chrome
 * on the server instead of a downloaded build.
 */

export default defineConfig({
  timeout: 30_000,
  retries: 0,
  workers: 1,
  fullyParallel: false,
  reporter: [['list'], ['html', { open: 'never' }]],
  use: {
    launchOptions: { executablePath: '/usr/bin/chromium-browser' },
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
  },
  projects: [
    {
      name: 'setup-buyer',
      testMatch: /.*auth\/buyer\.setup\.ts/,
      use: { baseURL: 'http://185.164.73.143:3000' },
    },
    {
      name: 'setup-admin',
      testMatch: /.*auth\/admin\.setup\.ts/,
      use: { baseURL: 'http://185.164.73.143:3001' },
    },
    {
      name: 'setup-seller',
      testMatch: /.*auth\/seller\.setup\.ts/,
      use: { baseURL: 'http://185.164.73.143:3000' },
    },
    {
      // Buyer-side pages on :3000 — plus the multi-actor specs that drive the
      // buyer flow (they open their own :3001 admin context via browser.newContext).
      name: 'buyer',
      dependencies: ['setup-buyer'],
      testMatch:
        /health-check\.buyer\.spec\.ts$|rfq-flow|support-flow|custom-request-flow|load-test|button-health/,
      use: {
        ...devices['Desktop Chrome'],
        baseURL: 'http://185.164.73.143:3000',
        storageState: '.auth/buyer.json',
      },
      testIgnore: /.*auth\/.*/,
    },
    {
      // Admin-side pages on :3001 — health-check plus /admin-logistics specs
      // (read/structure checks and transport-company creation). Specs open
      // their own contexts via helpers/race-utils.
      name: 'admin',
      dependencies: ['setup-admin'],
      testMatch: /health-check\.admin\.spec\.ts$|admin-logistics/,
      use: {
        ...devices['Desktop Chrome'],
        baseURL: 'http://185.164.73.143:3001',
        storageState: '.auth/admin.json',
      },
      testIgnore: /.*auth\/.*/,
    },
    {
      // Seller-side pages on :3000 — multi-actor market listing flow runs here
      // exactly once. Depends on all three setups: the spec opens buyer, seller
      // AND admin contexts (scenarios 1/3 cancel via /admin-material-listings).
      name: 'seller',
      dependencies: ['setup-buyer', 'setup-seller', 'setup-admin'],
      testMatch: /market-listing-flow/,
      use: {
        ...devices['Desktop Chrome'],
        baseURL: 'http://185.164.73.143:3000',
        storageState: '.auth/seller.json',
      },
      testIgnore: /.*auth\/.*/,
    },
    {
      // Public pages (/reports, /about, /market) — no auth required for basic
      // rendering, but market gate-branch specs open buyer/seller contexts,
      // so the setups must run first to produce the storage states.
      name: 'public',
      dependencies: ['setup-buyer', 'setup-seller'],
      testMatch: /public-.*\.spec\.ts$/,
      use: {
        ...devices['Desktop Chrome'],
        baseURL: 'http://185.164.73.143:3000',
      },
      testIgnore: /.*auth\/.*/,
    },
    {
      // Race-condition / concurrency tests — multi-actor specs that open
      // their own browser contexts (admin + buyer). Depend on both setups.
      // Longer timeout because they wait for concurrent navigations.
      name: 'race',
      dependencies: ['setup-buyer', 'setup-admin'],
      testMatch: /race-.*\.spec\.ts$/,
      timeout: 45_000,
      use: {
        ...devices['Desktop Chrome'],
        baseURL: 'http://185.164.73.143:3001',
        storageState: '.auth/admin.json',
      },
      testIgnore: /.*auth\/.*/,
    },
  ],
});
