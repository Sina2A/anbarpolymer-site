/**
 * Playwright E2E tests — /reports (public archive) and /reports/[id] (detail)
 *
 * Covers:
 *   - Archive loads without auth (guest context, no storageState, no /login redirect)
 *   - Page hero heading ("گزارش‌ها و تحلیل‌های بازار پلیمر") + ReportsSearchBar presence
 *   - FeaturedReportCarousel renders when articles exist; prev/next buttons advance
 *     the featured card (title changes); graceful skip when no articles
 *   - Search input filters the report list count text and drops visible news cards;
 *     clearing restores
 *   - Pagination: next link navigates to ?page=2 and back (skip when single page)
 *   - Detail page: title (h1), Persian date in meta row, TipTap body rendered as
 *     real HTML semantics inside .article-content; no raw HTML leakage as text
 *   - TOC: link count matches h2+h3 count; clicking a TOC link anchors (URL hash)
 *     and the target heading reaches the viewport
 *   - Self-hosted fonts: zero network requests to external font origins during load
 *     of /reports and a detail page (all font/woff requests must be same-origin)
 *
 * Data safety:
 *   - READ-ONLY: no forms are submitted, nothing is mutated.
 *   - All tests degrade gracefully via test.skip() + console.log when the live
 *     article table is empty (remote server data, not seeded by these specs).
 *   - Every guest context is closed before skip and at test end.
 *
 * Persian strings below are copied byte-exact from source
 * (src/app/reports/page.tsx, src/app/reports/[id]/page.tsx,
 *  src/components/FeaturedReportCarousel.tsx, src/components/ReportsSearchBar.tsx,
 *  src/components/ArticleTOC.tsx) — ZWNJ (U+200C) characters preserved.
 */

import { test, expect, type Page } from '@playwright/test';
import { BUYER_BASE } from './helpers/race-utils';

// ─── Shared constants ──────────────────────────────────────────────────────────

// External font origins that must NEVER appear in network traffic (self-hosted
// fonts mandate). NOTE: the work-src snapshot of globals.css still carries a
// Google Fonts @import on line 2 — these tests enforce the self-hosting
// requirement and will fail until that import is removed on the deployed app.
const EXTERNAL_FONT_HOSTS = [
  'fonts.googleapis.com',
  'fonts.gstatic.com',
  'fonts.bunny.net',
];

const NAV_TIMEOUT = 20_000; // remote server — generous

/** Persian numerals map for asserting count text like «۳ گزارش» */
const FA_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
function toFaDigits(n: number): string {
  return String(n)
    .split('')
    .map((ch) => (/\d/.test(ch) ? FA_DIGITS[Number(ch)] : ch))
    .join('');
}

/** Collect every request URL; call before goto, read after load settles. */
function collectRequests(page: Page): string[] {
  const urls: string[] = [];
  page.on('request', (req) => urls.push(req.url()));
  return urls;
}

/** A font-ish request: stylesheet, font file, or URL path mentioning font/woff. */
function isFontRequest(url: string): boolean {
  const lower = url.toLowerCase();
  if (EXTERNAL_FONT_HOSTS.some((h) => lower.includes(h))) return true;
  if (/(fonts?\.bunny\.net)/.test(lower)) return true;
  // font file extensions or explicit font paths — covers jsdelivr font paths too
  if (/\.(woff2?|ttf|otf|eot)(\?|$)/.test(lower)) return true;
  if (lower.includes('font') && lower.includes('cdn.jsdelivr.net')) return true;
  return false;
}

function sameOrigin(url: string, base: string): boolean {
  try {
    return new URL(url).origin === new URL(base).origin;
  } catch {
    return false;
  }
}

/** Assert none of the collected requests fetch fonts from external origins. */
function expectNoExternalFonts(requestUrls: string[], base: string) {
  const offenders = requestUrls.filter(
    (u) => isFontRequest(u) && !sameOrigin(u, base)
  );
  // Also flag ANY request (font or not) that goes to a known external font host
  const hostOffenders = requestUrls.filter((u) =>
    EXTERNAL_FONT_HOSTS.some((h) => u.toLowerCase().includes(h))
  );
  expect(
    offenders,
    `External font requests found: ${offenders.join(', ')}`
  ).toHaveLength(0);
  expect(
    hostOffenders,
    `Requests to external font hosts found: ${hostOffenders.join(', ')}`
  ).toHaveLength(0);
}

/** Get the first published report link from the archive (grid card, or the
 *  carousel CTA when the grid is empty because <4 reports exist), or null. */
async function firstReportHref(page: Page): Promise<string | null> {
  const card = page.locator('a.news-card[href^="/reports/"]').first();
  if ((await card.count()) > 0) return card.getAttribute('href');
  // Grid skips the first 3 (carousel) articles — fall back to the carousel CTA
  const cta = page.getByRole('link', { name: 'مطالعه گزارش ←' }).first();
  if ((await cta.count()) > 0) return cta.getAttribute('href');
  return null;
}

// ─── Tests ─────────────────────────────────────────────────────────────────────

test.describe('/reports — archive (public, guest)', () => {
  test('loads without auth: hero heading renders and no redirect to /login', async ({ browser }) => {
    const ctx = await browser.newContext({ baseURL: BUYER_BASE });
    const page = await ctx.newPage();

    const response = await page.goto('/reports', { waitUntil: 'domcontentloaded', timeout: NAV_TIMEOUT });
    expect(response?.status()).toBe(200);

    // Still on /reports — public page, no auth redirect
    expect(page.url()).not.toContain('/login');
    await page.waitForURL(/\/reports/, { timeout: NAV_TIMEOUT });

    // Hero heading — exact text from src/app/reports/page.tsx
    await expect(page.locator('.sec-title').first()).toHaveText('گزارش‌ها و تحلیل‌های بازار پلیمر', { timeout: NAV_TIMEOUT });

    await page.close();
    await ctx.close();
  });

  test('featured-report carousel renders when articles exist (graceful skip otherwise)', async ({ browser }) => {
    const ctx = await browser.newContext({ baseURL: BUYER_BASE });
    const page = await ctx.newPage();

    await page.goto('/reports', { waitUntil: 'domcontentloaded', timeout: NAV_TIMEOUT });

    // Empty archive → page shows the documented empty state, skip carousel checks
    const emptyState = page.locator('.empty-state');
    if ((await emptyState.count()) > 0 && (await emptyState.first().isVisible())) {
      console.log('[skip] No published reports on server — carousel not rendered (empty state visible)');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    // Carousel card markers from FeaturedReportCarousel.tsx:
    // the featured article contains the kicker «تحلیل بازار» and the CTA «مطالعه گزارش ←»
    const ctaLink = page.getByRole('link', { name: 'مطالعه گزارش ←' });
    await expect(ctaLink.first()).toBeVisible({ timeout: NAV_TIMEOUT });
    await expect(page.getByText('تحلیل بازار').first()).toBeVisible();

    // The CTA must point at a real report detail URL
    const href = await ctaLink.first().getAttribute('href');
    expect(href).toMatch(/^\/reports\/.+/);

    await page.close();
    await ctx.close();
  });

  test('carousel prev/next buttons advance the featured card', async ({ browser }) => {
    const ctx = await browser.newContext({ baseURL: BUYER_BASE });
    const page = await ctx.newPage();

    await page.goto('/reports', { waitUntil: 'domcontentloaded', timeout: NAV_TIMEOUT });

    const emptyState = page.locator('.empty-state');
    if ((await emptyState.count()) > 0 && (await emptyState.first().isVisible())) {
      console.log('[skip] No published reports on server — carousel navigation not testable');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    // Nav buttons only render when >1 article (FeaturedReportCarousel.tsx:
    // `articles.length > 1 && <button ...>`). Prev = «→», Next = «←» (RTL).
    const prevBtn = page.getByRole('button', { name: '→', exact: true });
    const nextBtn = page.getByRole('button', { name: '←', exact: true });

    if ((await nextBtn.count()) === 0) {
      console.log('[skip] Only one featured report on server — carousel nav buttons not rendered');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    await expect(nextBtn.first()).toBeVisible();
    // RTL carousel starts at index 0 — the prev button («→») is disabled there
    await expect(prevBtn.first()).toBeDisabled();

    // Featured title lives in an h3 inside the carousel card; capture before/after
    const featuredH3 = page.locator('article h3').first();
    const titleBefore = (await featuredH3.textContent()) ?? '';

    await nextBtn.first().click();
    // React state update — no navigation; wait for title to change
    await expect
      .poll(async () => (await featuredH3.textContent()) ?? '', { timeout: 10_000 })
      .not.toBe(titleBefore);

    // On index ≥1 the prev button must now be enabled (was disabled at index 0)
    await expect(prevBtn.first()).toBeEnabled();

    // And going back restores the original featured title
    await prevBtn.first().click();
    await expect
      .poll(async () => (await featuredH3.textContent()) ?? '', { timeout: 10_000 })
      .toBe(titleBefore);

    await page.close();
    await ctx.close();
  });

  test('search input filters the report list; clearing restores', async ({ browser }) => {
    const ctx = await browser.newContext({ baseURL: BUYER_BASE });
    const page = await ctx.newPage();

    await page.goto('/reports', { waitUntil: 'domcontentloaded', timeout: NAV_TIMEOUT });

    // ReportsSearchBar.tsx renders <input type="search" placeholder="جست‌وجو در گزارش‌ها...">
    const searchInput = page.locator('input[type="search"]');
    await expect(searchInput).toHaveCount(1);
    await expect(searchInput).toHaveAttribute('placeholder', 'جست‌وجو در گزارش‌ها...');

    const emptyState = page.locator('.empty-state');
    if ((await emptyState.count()) > 0 && (await emptyState.first().isVisible())) {
      console.log('[skip] No published reports on server — search filtering not testable');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    // Baseline: count text «N گزارش» (N in Persian digits) with empty query
    const countText = page.getByText(/گزارش$/, { exact: false }).first();
    const initialText = (await countText.textContent()) ?? '';
    expect(initialText).toContain('گزارش');
    const initialCount = parseInt(initialText.replace(/[۰-۹]/g, (d) => String(FA_DIGITS.indexOf(d))).replace(/\D/g, ''), 10);
    expect(initialCount).toBeGreaterThan(0);

    const gridCountBefore = await page.locator('a.news-card').count();

    // Type a Persian string that matches nothing → count text drops to «۰ گزارش»
    await searchInput.fill('موجود-نیست-تست-پلی‌رایت');
    await expect
      .poll(
        async () =>
          ((await countText.textContent()) ?? '').replace(/[۰-۹]/g, (d) => String(FA_DIGITS.indexOf(d))),
        { timeout: 10_000 }
      )
      .toContain('0');

    // Documented source behavior: the search bar is client-side only and does
    // NOT re-filter the server-rendered news grid — visible cards stay put.
    expect(await page.locator('a.news-card').count()).toBe(gridCountBefore);

    // Clear → count restores to the original total
    await searchInput.fill('');
    await expect
      .poll(async () => (await countText.textContent()) ?? '', { timeout: 10_000 })
      .toBe(initialText);

    await page.close();
    await ctx.close();
  });

  test('pagination navigates to page 2 and back (skip when single page)', async ({ browser }) => {
    const ctx = await browser.newContext({ baseURL: BUYER_BASE });
    const page = await ctx.newPage();

    await page.goto('/reports', { waitUntil: 'domcontentloaded', timeout: NAV_TIMEOUT });

    const emptyState = page.locator('.empty-state');
    if ((await emptyState.count()) > 0 && (await emptyState.first().isVisible())) {
      console.log('[skip] No published reports on server — pagination not rendered');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    // Pagination markup (reports/page.tsx): links «بعدی →» / «← قبلی» + info «صفحه X از Y»
    const nextLink = page.getByRole('link', { name: /بعدی/ });
    if ((await nextLink.count()) === 0) {
      console.log('[skip] Only one page of reports — pagination links not rendered');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    // Next → page 2
    await Promise.all([
      page.waitForURL(/\/reports\?page=2/, { timeout: NAV_TIMEOUT }),
      nextLink.first().click(),
    ]);
    // Info line must reflect page 2 («صفحه ۲ از ...»)
    await expect(page.getByText(/صفحه\s+۲\s+از/).first()).toBeVisible({ timeout: NAV_TIMEOUT });
    // Page 2 must still render report cards (grid skips the 3 carousel articles;
    // if the grid is empty here the server has <14 articles — skip rather than fail)
    const cardsOnP2 = page.locator('a.news-card[href^="/reports/"]');
    if ((await cardsOnP2.count()) === 0) {
      console.log('[skip] Page 2 exists but grid is empty (fewer than 14 reports) — skipping round-trip card assert');
    } else {
      await expect(cardsOnP2.first()).toBeVisible();
    }

    // Back to page 1 via «← قبلی»
    const prevLink = page.getByRole('link', { name: /قبلی/ });
    await expect(prevLink.first()).toBeVisible({ timeout: NAV_TIMEOUT });
    await Promise.all([
      page.waitForURL(/\/reports(\?page=1)?$/, { timeout: NAV_TIMEOUT }),
      prevLink.first().click(),
    ]);

    await page.close();
    await ctx.close();
  });

  test('self-hosted fonts: /reports load makes zero external font requests', async ({ browser }) => {
    const ctx = await browser.newContext({ baseURL: BUYER_BASE });
    const page = await ctx.newPage();

    const urls = collectRequests(page);
    await page.goto('/reports', { waitUntil: 'networkidle', timeout: 30_000 });

    expectNoExternalFonts(urls, BUYER_BASE);

    // Every font-file request actually made must be same-origin (self-hosted)
    const fontFiles = urls.filter((u) => /\.(woff2?|ttf|otf)(\?|$)/i.test(u));
    for (const u of fontFiles) {
      expect(sameOrigin(u, BUYER_BASE), `font file not same-origin: ${u}`).toBe(true);
    }

    await page.close();
    await ctx.close();
  });
});

test.describe('/reports/[id] — detail page (public, guest)', () => {
  test('renders title, Persian date, and TipTap body with real HTML semantics — no raw HTML leakage', async ({ browser }) => {
    const ctx = await browser.newContext({ baseURL: BUYER_BASE });
    const page = await ctx.newPage();

    await page.goto('/reports', { waitUntil: 'domcontentloaded', timeout: NAV_TIMEOUT });

    const href = await firstReportHref(page);
    if (!href) {
      console.log('[skip] No published reports on server — detail page not testable');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    const response = await page.goto(href, { waitUntil: 'domcontentloaded', timeout: NAV_TIMEOUT });
    expect(response?.status()).toBe(200);
    expect(page.url()).not.toContain('/login');

    // Back link to the archive (reports/[id]/page.tsx: «← همه‌ی گزارش‌ها»)
    await expect(page.getByRole('link', { name: '← همه‌ی گزارش‌ها' }).first()).toBeVisible({ timeout: NAV_TIMEOUT });

    // Title h1 (reports/[id]/page.tsx renders <h1 style={titleStyle}>{article.title}</h1>)
    const h1 = page.locator('h1').first();
    await expect(h1).toBeVisible({ timeout: NAV_TIMEOUT });
    const titleText = (await h1.textContent()) ?? '';
    expect(titleText.trim().length).toBeGreaterThan(0);

    // Meta row shows the Persian publish date (faDate → fa-IR numerals)
    const bodyText = (await page.locator('body').innerText()) ?? '';
    expect(bodyText).toMatch(/[۰-۹]{2,}/);

    // TipTap body: .article-content must contain at least one real block element
    const prose = page.locator('.article-content');
    await expect(prose).toBeVisible({ timeout: NAV_TIMEOUT });
    const blockCount = await prose.locator('h2, h3, p, ul, ol, li, blockquote, table').count();
    expect(blockCount, '.article-content has no heading/list/paragraph elements — body not rendered as HTML').toBeGreaterThan(0);

    // No raw HTML leakage: visible text must not contain markup tokens
    const visibleText = (await prose.textContent()) ?? '';
    expect(visibleText).not.toContain('<h2>');
    expect(visibleText).not.toContain('<div');
    expect(visibleText).not.toContain('&nbsp;');
    expect(visibleText).not.toContain('<p>');
    expect(visibleText).not.toContain('</');

    await page.close();
    await ctx.close();
  });

  test('table of contents matches rendered h2/h3 and anchors on click', async ({ browser }) => {
    const ctx = await browser.newContext({ baseURL: BUYER_BASE });
    const page = await ctx.newPage();

    await page.goto('/reports', { waitUntil: 'domcontentloaded', timeout: NAV_TIMEOUT });

    const href = await firstReportHref(page);
    if (!href) {
      console.log('[skip] No published reports on server — TOC not testable');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    await page.goto(href, { waitUntil: 'domcontentloaded', timeout: NAV_TIMEOUT });

    // ArticleTOC renders title «فهرست مطالب» only when headings exist
    const tocTitle = page.getByText('فهرست مطالب');
    const bodyHeadings = page.locator('.article-content h2, .article-content h3');

    if ((await tocTitle.count()) === 0) {
      // No TOC → article must genuinely have no h2/h3 (documented behavior, not a bug)
      expect(await bodyHeadings.count()).toBe(0);
      console.log('[info] Article has no h2/h3 headings — TOC correctly absent');
      await page.close();
      await ctx.close();
      return;
    }

    await expect(tocTitle.first()).toBeVisible();

    // TOC link count === rendered h2+h3 count (injectHeadingIds + extractTOC, 1:1)
    const tocLinks = page.locator('a[href^="#section-"]');
    const tocCount = await tocLinks.count();
    const headingCount = await bodyHeadings.count();
    expect(tocCount).toBeGreaterThan(0);
    expect(tocCount, 'TOC link count does not match rendered h2/h3 count').toBe(headingCount);

    // Clicking the last TOC link anchors: URL gains the hash and the target
    // heading scrolls into the viewport
    const lastLink = tocLinks.last();
    const targetId = (await lastLink.getAttribute('href')) ?? '';
    expect(targetId).toMatch(/^#section-\d+$/);

    await lastLink.click();
    await page.waitForURL(new RegExp(`${targetId.slice(1)}$`), { timeout: 10_000 });

    const target = page.locator(`.article-content ${targetId}`);
    await expect(target).toBeInViewport({ timeout: 10_000 });

    await page.close();
    await ctx.close();
  });

  test('self-hosted fonts: report detail load makes zero external font requests', async ({ browser }) => {
    const ctx = await browser.newContext({ baseURL: BUYER_BASE });
    const page = await ctx.newPage();

    await page.goto('/reports', { waitUntil: 'domcontentloaded', timeout: NAV_TIMEOUT });
    const href = await firstReportHref(page);
    if (!href) {
      console.log('[skip] No published reports on server — detail font check not testable');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    const urls = collectRequests(page);
    await page.goto(href, { waitUntil: 'networkidle', timeout: 30_000 });

    expectNoExternalFonts(urls, BUYER_BASE);

    await page.close();
    await ctx.close();
  });
});
