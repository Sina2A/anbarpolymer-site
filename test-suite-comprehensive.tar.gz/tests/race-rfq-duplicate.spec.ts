/**
 * Race-Condition Test — Duplicate RFQ Submission
 *
 * Surface: The RFQ submission flow (buyer adds items to cart, submits)
 *          creates an Order with OrderItems and decrements WarehouseStock.
 *
 * The stock decrement is done via `prisma.warehouseStock.updateMany`
 * with `quantityTon: { decrement }` — but the availability check happens
 * before the decrement.  Two simultaneous RFQ submissions for the same
 * stock can both pass the availability check, both decrement, and drive
 * stock negative.
 *
 * Additionally: a user double-clicking "submit" (no client-side debounce
 * guard beyond disabling the button via React state) can create two
 * identical orders.
 *
 * What this test does:
 *   1. Open two buyer contexts to /rfq.
 *   2. Both add the same grade/warehouse to their cart.
 *   3. Both submit simultaneously.
 *   4. Check: both succeed → possible stock underflow.
 *
 * Data safety:
 *   - Creates Orders with e2e- prefixed notes (where possible).
 *   - Never deletes orders.
 *   - Uses test warehouse stock (TEST_GRADE_CODE = 'PP H110MA').
 */

import { test, expect } from '@playwright/test';
import { BUYER_BASE, buyerContext, uniqueTag } from './helpers/race-utils';

// Known test data — must exist on the server
const TEST_GRADE_CODE = 'PP H110MA';

// Mutation-safety gate — this spec creates REAL orders and decrements REAL
// WarehouseStock on the live server (potentially twice / negative on race).
// Skipped by default; opt in explicitly with E2E_UNSAFE_RACE_MUTATIONS=1,
// and only ever on a staging database.
const ALLOW_REAL_RACE_MUTATIONS = !!process.env.E2E_UNSAFE_RACE_MUTATIONS;

test.describe('Race: Duplicate RFQ Submission', () => {
  test.skip(
    !ALLOW_REAL_RACE_MUTATIONS,
    'creates real orders and decrements real stock — set E2E_UNSAFE_RACE_MUTATIONS=1 to enable (staging only)'
  );


  test('two simultaneous RFQ submissions for same stock should not both succeed if stock is limited', async ({
    browser,
  }) => {
    const tag = uniqueTag('e2e-rfq');

    // Open two independent buyer contexts (same user, separate sessions)
    const ctx1 = await buyerContext(browser);
    const ctx2 = await buyerContext(browser);
    const page1 = await ctx1.newPage();
    const page2 = await ctx2.newPage();

    // Navigate both to /rfq
    await Promise.all([
      page1.goto('/rfq', { waitUntil: 'networkidle', timeout: 15_000 }),
      page2.goto('/rfq', { waitUntil: 'networkidle', timeout: 15_000 }),
    ]);

    await expect(page1).not.toHaveURL(/\/login/);
    await expect(page2).not.toHaveURL(/\/login/);

    // Find the test grade row on both pages
    const findGradeRow = (page: typeof page1) =>
      page.locator('div, tr').filter({ hasText: TEST_GRADE_CODE }).first();

    const row1 = findGradeRow(page1);
    const row2 = findGradeRow(page2);

    if ((await row1.count()) === 0 || (await row2.count()) === 0) {
      console.log(`[skip] Test grade ${TEST_GRADE_CODE} not found on /rfq page`);
      await Promise.all([page1.close(), page2.close(), ctx1.close(), ctx2.close()]);
      test.skip();
      return;
    }

    // Try to add the grade to cart on both pages
    // The RFQ page likely has an "add to cart" button per row
    const findAddBtn = (page: typeof page1) =>
      page
        .locator('div, tr')
        .filter({ hasText: TEST_GRADE_CODE })
        .locator('button')
        .filter({ hasText: /افزودن|اضافه|add/i })
        .first();

    const addBtn1 = findAddBtn(page1);
    const addBtn2 = findAddBtn(page2);

    if ((await addBtn1.count()) === 0 || (await addBtn2.count()) === 0) {
      console.log('[skip] Add-to-cart button not found for test grade');
      await Promise.all([page1.close(), page2.close(), ctx1.close(), ctx2.close()]);
      test.skip();
      return;
    }

    // Add to cart on both
    await Promise.all([addBtn1.click(), addBtn2.click()]);

    // Wait a moment for cart UI to update
    await Promise.all([page1.waitForTimeout(1000), page2.waitForTimeout(1000)]);

    // Find and click the submit/checkout button on both
    const findSubmitBtn = (page: typeof page1) =>
      page.locator('button[type="submit"]').filter({ hasText: /ثبت|ارسال|submit/i }).first();

    const submitBtn1 = findSubmitBtn(page1);
    const submitBtn2 = findSubmitBtn(page2);

    if ((await submitBtn1.count()) === 0 || (await submitBtn2.count()) === 0) {
      console.log('[skip] Submit button not found after adding to cart');
      await Promise.all([page1.close(), page2.close(), ctx1.close(), ctx2.close()]);
      test.skip();
      return;
    }

    // Submit both simultaneously
    const [r1, r2] = await Promise.allSettled([
      (async () => {
        const [resp] = await Promise.all([
          page1.waitForNavigation({ timeout: 15_000 }).catch(() => null),
          submitBtn1.click(),
        ]);
        return { url: page1.url(), status: resp?.status() ?? null };
      })(),
      (async () => {
        const [resp] = await Promise.all([
          page2.waitForNavigation({ timeout: 15_000 }).catch(() => null),
          submitBtn2.click(),
        ]);
        return { url: page2.url(), status: resp?.status() ?? null };
      })(),
    ]);

    const isSuccessRedirect = (r: typeof r1) =>
      r.status === 'fulfilled' && (
        r.value.url.includes('/my-orders') ||
        r.value.url.includes('/dashboard') ||
        !r.value.url.includes('/rfq')  // redirected away from /rfq = success
      );

    const succeeded = [r1, r2].filter(isSuccessRedirect).length;

    console.log(`[race-result] Duplicate RFQ: ${succeeded}/2 submissions succeeded`);
    console.log('[race-result] Submit-1:', r1.status === 'fulfilled' ? r1.value : r1);
    console.log('[race-result] Submit-2:', r2.status === 'fulfilled' ? r2.value : r2);

    if (succeeded > 1) {
      console.warn(
        '⚠ RACE DETECTED: Both simultaneous RFQ submissions succeeded.\n' +
        '  If stock was limited, it may have gone negative.\n' +
        '  Two separate Order records were created for the same cart items.\n' +
        '  Fix: wrap stock check + decrement + order creation in a\n' +
        '  serializable transaction, or use SELECT ... FOR UPDATE on\n' +
        '  the WarehouseStock row.'
      );
    }

    await Promise.all([page1.close(), page2.close(), ctx1.close(), ctx2.close()]);
  });

  test('double-click submit on RFQ should not create duplicate orders', async ({
    browser,
  }) => {
    const ctx = await buyerContext(browser);
    const page = await ctx.newPage();

    await page.goto('/rfq', { waitUntil: 'networkidle', timeout: 15_000 });
    await expect(page).not.toHaveURL(/\/login/);

    // Find and add test grade
    const addBtn = page
      .locator('div, tr')
      .filter({ hasText: TEST_GRADE_CODE })
      .locator('button')
      .filter({ hasText: /افزودن|اضافه|add/i })
      .first();

    if ((await addBtn.count()) === 0) {
      console.log('[skip] Test grade not available for double-click test');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    await addBtn.click();
    await page.waitForTimeout(1000);

    const submitBtn = page
      .locator('button[type="submit"]')
      .filter({ hasText: /ثبت|ارسال|submit/i })
      .first();

    if ((await submitBtn.count()) === 0) {
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    // Double-click: two rapid clicks before navigation starts
    // This simulates the user clicking twice before the button disables
    const navPromise = page.waitForNavigation({ timeout: 15_000 }).catch(() => null);

    // Click twice in rapid succession (no await between)
    await submitBtn.click({ delay: 0 });
    await submitBtn.click({ delay: 0 }).catch(() => {
      // Button may already be disabled or page navigating — that's fine
    });

    await navPromise;

    const finalUrl = page.url();
    console.log(`[race-result] Double-click RFQ: landed on ${finalUrl}`);

    // Check if we ended up on /my-orders (success) or an error page
    if (finalUrl.includes('/my-orders') || finalUrl.includes('/dashboard')) {
      console.log('[race-result] Single order created (button was likely disabled after first click)');
    }

    // We can't easily detect a duplicate from the browser — the real test
    // would be checking the database.  But we log the behavior.
    console.log(
      '[race-note] To verify no duplicate was created, check the database:\n' +
      '  SELECT * FROM orders WHERE "userId" = <testbuyer_id>\n' +
      '  ORDER BY "createdAt" DESC LIMIT 5;'
    );

    await page.close();
    await ctx.close();
  });
});
