/**
 * Playwright E2E tests — /market auth & KYC gate branches
 *
 * Covers (gate logic from SupplyTableRow.tsx lines 72-78 and DemandTableRow.tsx lines 76-80):
 *   - Supply gate — guest: action button <a href="/signup">عضو شوید</a> → /signup
 *   - Supply gate — signed-in buyer, insufficient KYC: <a href="/verification">احراز هویت</a> → /verification
 *     (feature-detected: if testbuyer's KYC is already sufficient, log and pass — do NOT fail)
 *   - Supply gate — signed-in buyer, sufficient KYC: action is a disabled
 *     <span title="صفحه‌ی شروع معامله به‌زودی">پیشنهاد خرید</span> — NO popup exists in
 *     source; clicking must not navigate or open a dialog
 *     (feature-detected: if KYC is insufficient, log and pass)
 *   - Demand gate — guest: <a href="/login">ورود برای پاسخ</a> → /login
 *   - Demand gate — signed-in (seller): <a href="/new-listing?request=<id>">پیشنهاد فروش</a>
 *     → /new-listing?request=<id> with a truthy request param
 *
 * Data safety:
 *   - Pure read/navigation — zero mutations (no forms submitted, no data written).
 *   - KYC branches feature-detect the live account state and pass with a log when
 *     the other branch is active (testbuyer's real KYC level may vary).
 *   - Graceful skip (test.skip + console.log) whenever live data rows are absent.
 *   - Persian strings copied byte-exact from source.
 */

import { test, expect, type Browser } from '@playwright/test';
import { BUYER_BASE, buyerContext } from './helpers/race-utils';

const MARKET_URL = '/market';

// Local helper (do NOT edit tests/helpers/): fresh guest context —
// the `public` project's `use` has no storageState.
async function guestContext(browser: Browser) {
  return browser.newContext({ baseURL: BUYER_BASE });
}

// Local helper: seller context via the shared seller storage state.
async function sellerContext(browser: Browser) {
  return browser.newContext({
    baseURL: BUYER_BASE,
    storageState: '.auth/seller.json',
  });
}

test.describe('/market — Supply Gate (Guest)', () => {
  test('guest supply action → /signup', async ({ browser }) => {
    const ctx = await guestContext(browser);
    const page = await ctx.newPage();

    await page.goto(MARKET_URL, { waitUntil: 'domcontentloaded', timeout: 20_000 });

    const rows = page.locator('.market-row-hover');
    if ((await rows.count()) === 0) {
      console.log('[skip] No supply listings — cannot test guest supply gate');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    // Guest gate: <a href="/signup" ...>عضو شوید</a> (SupplyTableRow.tsx line 73)
    const actionBtn = rows.first().locator('a[href="/signup"]');
    if ((await actionBtn.count()) === 0) {
      console.log('[skip] No a[href="/signup"] in supply row — gate did not render for guest');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    await Promise.all([
      page.waitForURL(/\/signup/, { timeout: 20_000 }),
      actionBtn.click(),
    ]);
    expect(page.url()).toContain('/signup');

    await page.close();
    await ctx.close();
  });
});

test.describe('/market — Supply Gate (Buyer, KYC branches)', () => {
  test('insufficient KYC: action → /verification (feature-detected)', async ({ browser }) => {
    const ctx = await buyerContext(browser);
    const page = await ctx.newPage();

    await page.goto(MARKET_URL, { waitUntil: 'domcontentloaded', timeout: 20_000 });

    const rows = page.locator('.market-row-hover');
    if ((await rows.count()) === 0) {
      console.log('[skip] No supply listings — cannot test insufficient-KYC gate');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    // kycLevel < 1 gate: <a href="/verification" ...>احراز هویت</a> (line 75)
    const kycLink = rows.first().locator('a[href="/verification"]');
    if ((await kycLink.count()) === 0) {
      console.log(
        '[info] testbuyer KYC sufficient — insufficient-KYC branch not reachable; passing'
      );
      await page.close();
      await ctx.close();
      return; // pass, do NOT fail
    }

    await Promise.all([
      page.waitForURL(/\/verification/, { timeout: 20_000 }),
      kycLink.click(),
    ]);
    expect(page.url()).toContain('/verification');

    await page.close();
    await ctx.close();
  });

  test('sufficient KYC: action is a disabled span — no navigation, no popup (feature-detected)', async ({ browser }) => {
    const ctx = await buyerContext(browser);
    const page = await ctx.newPage();

    await page.goto(MARKET_URL, { waitUntil: 'domcontentloaded', timeout: 20_000 });

    const rows = page.locator('.market-row-hover');
    if ((await rows.count()) === 0) {
      console.log('[skip] No supply listings — cannot test sufficient-KYC gate');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    // kycLevel >= 1 gate: <span title="صفحه‌ی شروع معامله به‌زودی">پیشنهاد خرید</span>
    // (line 77) — a styled span, NOT a link/button; no popup exists in source.
    const buySpan = rows.first().locator('span[title*="معامله"]');
    if ((await buySpan.count()) === 0) {
      console.log(
        '[info] testbuyer KYC insufficient — sufficient-KYC branch not reachable; passing'
      );
      await page.close();
      await ctx.close();
      return; // pass, do NOT fail
    }

    await expect(buySpan).toBeVisible();
    await expect(buySpan).toHaveText('پیشنهاد خرید');

    // Title contains "به‌زودی" (dot tolerant of the ZWNJ in به‌زودی)
    const title = await buySpan.getAttribute('title');
    expect(title).toMatch(/به.زودی/);

    // Clicking the disabled span must do nothing: no navigation, no dialog.
    await buySpan.click();
    expect(page.url()).toContain('/market');
    await expect(rows.first()).toBeVisible(); // page did not navigate away
    await expect(
      page.locator('div[style*="position: fixed"][style*="inset: 0"]')
    ).toHaveCount(0);

    await page.close();
    await ctx.close();
  });
});

test.describe('/market — Demand Gate (Guest)', () => {
  test('guest demand action → /login', async ({ browser }) => {
    const ctx = await guestContext(browser);
    const page = await ctx.newPage();

    await page.goto(`${MARKET_URL}?view=demand`, { waitUntil: 'domcontentloaded', timeout: 20_000 });

    const rows = page.locator('.market-row-hover');
    if ((await rows.count()) === 0) {
      console.log('[skip] No demand requests — cannot test guest demand gate');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    // Guest gate: <a href="/login" ...>ورود برای پاسخ</a> (DemandTableRow.tsx line 79)
    const actionBtn = rows.first().locator('a[href="/login"]');
    if ((await actionBtn.count()) === 0) {
      console.log('[skip] No a[href="/login"] in demand row — gate did not render for guest');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    await Promise.all([
      page.waitForURL(/\/login/, { timeout: 20_000 }),
      actionBtn.click(),
    ]);
    expect(page.url()).toContain('/login');

    await page.close();
    await ctx.close();
  });
});

test.describe('/market — Demand Gate (Signed-in Seller)', () => {
  test('seller demand action → /new-listing?request=<id>', async ({ browser }) => {
    const ctx = await sellerContext(browser);
    const page = await ctx.newPage();

    await page.goto(`${MARKET_URL}?view=demand`, { waitUntil: 'domcontentloaded', timeout: 20_000 });

    const rows = page.locator('.market-row-hover');
    if ((await rows.count()) === 0) {
      console.log('[skip] No demand requests — cannot test seller demand gate');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    // Signed-in gate: <a href={`/new-listing?request=${request.id}`}>پیشنهاد فروش</a>
    // (DemandTableRow.tsx line 77)
    const actionBtn = rows.first().locator('a[href^="/new-listing?request="]');
    if ((await actionBtn.count()) === 0) {
      console.log('[skip] No /new-listing?request= link in demand row — seller session may be invalid');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    await Promise.all([
      page.waitForURL(/\/new-listing\?request=/, { timeout: 20_000 }),
      actionBtn.click(),
    ]);

    const requestId = new URL(page.url()).searchParams.get('request');
    expect(requestId).toBeTruthy();
    console.log(`[info] Seller routed to /new-listing?request=${requestId}`);

    await page.close();
    await ctx.close();
  });
});
