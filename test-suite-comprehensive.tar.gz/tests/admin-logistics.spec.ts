/**
 * Playwright E2E tests — /admin-logistics
 *
 * Covers:
 *   - Authorization: admin gets full access, unauthenticated gets redirected
 *   - Page structure: heading, table headers, transport-company select, action buttons
 *   - Transport-company assignment form (select + submit) for editable users
 *   - Driver-link regeneration button presence
 *   - Feedback banners for ?regenerated=1 and ?assigned=1 query params
 *
 * Data safety:
 *   - All mutation data uses `e2e-` prefix for identification.
 *   - No destructive cleanup (DELETE/DROP).
 *   - Passwords are never logged, asserted, or captured.
 */

import { test, expect } from '@playwright/test';
import { ADMIN_BASE, BUYER_BASE, uniqueTag, adminContext } from './helpers/race-utils';

test.describe('/admin-logistics — Authorization & Structure', () => {

  test('unauthenticated user is redirected to /login', async ({ browser }) => {
    // Explicit EMPTY storageState — a bare browser.newContext() inherits the admin
    // project's use.storageState and would run this test already authenticated.
    const ctx = await browser.newContext({ baseURL: ADMIN_BASE, storageState: { cookies: [], origins: [] } });
    const page = await ctx.newPage();

    const response = await page.goto('/admin-logistics', { waitUntil: 'networkidle', timeout: 15_000 });

    // Should redirect to login — either via HTTP redirect or client-side navigation
    const url = page.url();
    expect(url).toContain('/login');

    await page.close();
    await ctx.close();
  });

  test('admin user sees the logistics page heading and table structure', async ({ browser }) => {
    const ctx = await adminContext(browser);
    const page = await ctx.newPage();

    await page.goto('/admin-logistics', { waitUntil: 'networkidle', timeout: 15_000 });

    // Page heading
    await expect(page.locator('h1')).toContainText('حمل و نقل — هماهنگی داخلی');

    // Should NOT show the "no access" message for admin
    const noAccessMsg = page.getByText('به این بخش دسترسی نداری.');
    await expect(noAccessMsg).toHaveCount(0);

    // Table header row should contain expected columns
    const thead = page.locator('thead');
    if ((await thead.count()) > 0) {
      await expect(thead).toContainText('شناسه معامله');
      await expect(thead).toContainText('گرید');
      await expect(thead).toContainText('خریدار');
      await expect(thead).toContainText('شرکت حمل‌ونقل');
      await expect(thead).toContainText('وضعیت لینک راننده');
      // Admin has edit access → "عملیات" column should be present
      await expect(thead).toContainText('عملیات');
    }

    await page.close();
    await ctx.close();
  });

  test('admin sees transport-company assignment controls when deals exist', async ({ browser }) => {
    const ctx = await adminContext(browser);
    const page = await ctx.newPage();

    await page.goto('/admin-logistics', { waitUntil: 'networkidle', timeout: 15_000 });

    // Check if any deals are listed
    const tbody = page.locator('tbody');
    const dealRows = tbody.locator('tr');
    const dealCount = await dealRows.count();

    if (dealCount === 0) {
      // No deals in transit — the empty state should be visible
      const emptyMsg = page.getByText('فعلاً هیچ معامله‌ای وارد مرحله‌ی حمل‌ونقل نشده.');
      await expect(emptyMsg).toBeVisible();
      console.log('[info] No deals in logistics phase — skipping assignment control checks');
    } else {
      // At least one deal: check for transport-company select and submit button
      const firstSelect = page.locator('select[name="transportCompanyId"]').first();
      await expect(firstSelect).toBeVisible();

      // The select should have a "no company" default option
      const noCompanyOption = firstSelect.locator('option[value=""]');
      await expect(noCompanyOption).toHaveText('— بدون شرکت —');

      // Submit button for assignment
      const submitBtn = page.locator('form').filter({ has: page.locator('select[name="transportCompanyId"]') }).first().locator('button[type="submit"]');
      await expect(submitBtn).toContainText('ثبت');

      // Hidden dealId input should be present
      const hiddenDealId = page.locator('input[type="hidden"][name="dealId"]').first();
      await expect(hiddenDealId).toBeAttached();

      // Driver-link regeneration button should be present for admin
      const regenBtn = page.getByRole('button', { name: /ساخت دوباره‌ی لینک راننده/ });
      if ((await regenBtn.count()) > 0) {
        await expect(regenBtn.first()).toBeVisible();
      }
    }

    await page.close();
    await ctx.close();
  });

  test('link status badge shows one of the expected states', async ({ browser }) => {
    const ctx = await adminContext(browser);
    const page = await ctx.newPage();

    await page.goto('/admin-logistics', { waitUntil: 'networkidle', timeout: 15_000 });

    const dealRows = page.locator('tbody tr');
    const count = await dealRows.count();

    if (count === 0) {
      console.log('[info] No deals — skipping link-status check');
    } else {
      // Each deal row should show one of: بدون لینک / استفاده‌شده / منقضی / فعال
      const validStatuses = ['بدون لینک', 'استفاده‌شده', 'منقضی', 'فعال'];
      const firstRow = dealRows.first();
      const cells = firstRow.locator('td');
      const cellCount = await cells.count();

      // The "link status" is typically the second-to-last or third-to-last cell
      // We check if any cell in the first row contains a valid status
      let foundStatus = false;
      for (let i = 0; i < cellCount; i++) {
        const text = (await cells.nth(i).textContent()) ?? '';
        if (validStatuses.some((s) => text.includes(s))) {
          foundStatus = true;
          break;
        }
      }
      expect(foundStatus).toBe(true);
    }

    await page.close();
    await ctx.close();
  });
});

test.describe('/admin-logistics — Feedback Banners', () => {

  test('?regenerated=1 shows success feedback', async ({ browser }) => {
    const ctx = await adminContext(browser);
    const page = await ctx.newPage();

    await page.goto('/admin-logistics?regenerated=1', { waitUntil: 'networkidle', timeout: 15_000 });

    const feedback = page.getByText('لینک راننده دوباره ساخته شد.');
    await expect(feedback).toBeVisible();

    await page.close();
    await ctx.close();
  });

  test('?assigned=1 shows success feedback', async ({ browser }) => {
    const ctx = await adminContext(browser);
    const page = await ctx.newPage();

    await page.goto('/admin-logistics?assigned=1', { waitUntil: 'networkidle', timeout: 15_000 });

    const feedback = page.getByText('شرکت حمل‌ونقل به‌روزرسانی شد.');
    await expect(feedback).toBeVisible();

    await page.close();
    await ctx.close();
  });

  test('no query params shows no feedback banner', async ({ browser }) => {
    const ctx = await adminContext(browser);
    const page = await ctx.newPage();

    await page.goto('/admin-logistics', { waitUntil: 'networkidle', timeout: 15_000 });

    // Neither feedback message should be visible
    const regen = page.getByText('لینک راننده دوباره ساخته شد.');
    const assigned = page.getByText('شرکت حمل‌ونقل به‌روزرسانی شد.');
    await expect(regen).toHaveCount(0);
    await expect(assigned).toHaveCount(0);

    await page.close();
    await ctx.close();
  });
});

// Mutation-safety gate — the assignment test below submits
// assignTransportCompanyAction against a REAL deal on the live server
// (selecting the empty option nulls transportCompanyId, which clobbers a
// real assignment if one exists).  Skipped by default; opt in explicitly
// with E2E_UNSAFE_RACE_MUTATIONS=1, and only ever on a staging database.
const ALLOW_REAL_RACE_MUTATIONS = !!process.env.E2E_UNSAFE_RACE_MUTATIONS;

test.describe('/admin-logistics — Transport Company Assignment (mutation)', () => {
  test.skip(
    !ALLOW_REAL_RACE_MUTATIONS,
    'mutates a real deal’s transport-company assignment — set E2E_UNSAFE_RACE_MUTATIONS=1 to enable (staging only)'
  );


  test('assigning a transport company redirects with ?assigned=1 feedback', async ({ browser }) => {
    const ctx = await adminContext(browser);
    const page = await ctx.newPage();

    await page.goto('/admin-logistics', { waitUntil: 'networkidle', timeout: 15_000 });

    // We need at least one deal and at least one transport company in the select
    const selects = page.locator('select[name="transportCompanyId"]');
    const selectCount = await selects.count();

    if (selectCount === 0) {
      console.log('[skip] No deals with transport-company selects — cannot test assignment');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    const firstSelect = selects.first();
    const options = firstSelect.locator('option');
    const optionCount = await options.count();

    if (optionCount <= 1) {
      // Only the "no company" option — no companies to assign
      console.log('[skip] No transport companies available to assign');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    // Select the "no company" option (safe non-destructive assignment)
    // This just sets transportCompanyId = null which is harmless
    await firstSelect.selectOption('');

    // Submit the form
    const form = page.locator('form').filter({ has: firstSelect }).first();
    const submitBtn = form.locator('button[type="submit"]');

    await Promise.all([
      page.waitForURL(/\/admin-logistics\?assigned=1/, { timeout: 15_000 }),
      submitBtn.click(),
    ]);

    // Verify feedback
    await expect(page.getByText('شرکت حمل‌ونقل به‌روزرسانی شد.')).toBeVisible();

    await page.close();
    await ctx.close();
  });
});
