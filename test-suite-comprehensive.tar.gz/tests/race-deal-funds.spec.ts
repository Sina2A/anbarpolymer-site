/**
 * Race-Condition Test — Deal Funds Confirmation Race
 *
 * Surface: `confirmFundsSecured` / `confirmFundsReleased`
 *          in src/app/admin-deals/actions.ts
 *
 * These actions have NO status precondition check.  `confirmFundsSecured`
 * blindly sets `escrowStatus = 'secured_manual'` and `status = 'payment_secured'`.
 * Two concurrent calls both succeed, double-writing the same fields.
 *
 * More critically: `confirmFundsReleased` sets `status = 'settled'` — if
 * called concurrently with `confirmFundsSecured`, the deal can flip between
 * 'payment_secured' and 'settled' unpredictably, and `escrowConfirmedAt`
 * gets overwritten.
 *
 * What this test does:
 *   1. Find a deal on /admin-deals that has a "تایید تامین وجه" button.
 *   2. Open two admin pages and click it simultaneously.
 *   3. Log whether both succeeded (→ race confirmed).
 *
 * Data safety:
 *   - Only calls confirmFundsSecured, which is an idempotent status change
 *     (writing the same values twice doesn't corrupt data, just wastes
 *     audit log entries).
 *   - Does NOT call confirmFundsReleased (which would prematurely settle
 *     a deal).
 *   - Never deletes deals.
 */

import { test, expect } from '@playwright/test';
import { adminContext } from './helpers/race-utils';

// Mutation-safety gate — this spec fires confirmFundsSecured at a REAL deal
// on the live server (whichever deal happens to have the button).  Skipped
// by default; opt in explicitly with E2E_UNSAFE_RACE_MUTATIONS=1, and only
// ever on a staging database.
const ALLOW_REAL_RACE_MUTATIONS = !!process.env.E2E_UNSAFE_RACE_MUTATIONS;

test.describe('Race: Deal Funds Confirmation', () => {
  test.skip(
    !ALLOW_REAL_RACE_MUTATIONS,
    'mutates real server records — set E2E_UNSAFE_RACE_MUTATIONS=1 to enable (staging only)'
  );


  test('concurrent confirmFundsSecured on same deal should ideally be idempotent', async ({
    browser,
  }) => {
    const adminCtx = await adminContext(browser);
    const listPage = await adminCtx.newPage();

    await listPage.goto('/admin-deals', { waitUntil: 'networkidle', timeout: 15_000 });
    await expect(listPage).not.toHaveURL(/\/login/);

    // Find a deal row with escrow confirmation form
    // confirmFundsSecured uses formData with 'dealId' and 'confirmedById'
    // Look for any form that has these inputs
    const secureForm = listPage
      .locator('form')
      .filter({
        has: listPage.locator('input[name="dealId"]'),
      })
      .filter({
        has: listPage.locator('button', { hasText: /تایید.*وجه|تامین|secured|confirm.*fund/i }),
      })
      .first();

    if ((await secureForm.count()) === 0) {
      // Alternative: look for any button text related to funds
      const altForm = listPage
        .locator('form')
        .filter({
          has: listPage.locator('button', { hasText: /تایید تامین/ }),
        })
        .first();

      if ((await altForm.count()) === 0) {
        console.log(
          '[skip] No fund-securing forms found on /admin-deals.\n' +
          '  This test needs a deal in "confirmed" status that hasn\'t\n' +
          '  had its funds secured yet.'
        );
        await listPage.close();
        await adminCtx.close();
        test.skip();
        return;
      }
    }

    // Get the dealId
    const dealIdInput = secureForm.locator('input[name="dealId"]');
    if ((await dealIdInput.count()) === 0) {
      await listPage.close();
      await adminCtx.close();
      test.skip();
      return;
    }

    const dealId = await dealIdInput.inputValue();
    await listPage.close();

    if (!dealId) {
      test.skip();
      return;
    }

    console.log(`[race-test] Testing double-confirm-funds on deal: ${dealId.slice(0, 8)}...`);

    // Open two pages
    const page1 = await adminCtx.newPage();
    const page2 = await adminCtx.newPage();

    await Promise.all([
      page1.goto('/admin-deals', { waitUntil: 'networkidle', timeout: 15_000 }),
      page2.goto('/admin-deals', { waitUntil: 'networkidle', timeout: 15_000 }),
    ]);

    const findSecureBtn = (page: typeof page1) =>
      page
        .locator('form')
        .filter({ has: page.locator(`input[name="dealId"][value="${dealId}"]`) })
        .locator('button[type="submit"]')
        .first();

    const btn1 = findSecureBtn(page1);
    const btn2 = findSecureBtn(page2);

    if ((await btn1.count()) === 0 || (await btn2.count()) === 0) {
      console.log('[skip] Could not find fund-confirmation buttons on both pages');
      await Promise.all([page1.close(), page2.close(), adminCtx.close()]);
      test.skip();
      return;
    }

    page1.on('dialog', (d) => d.accept());
    page2.on('dialog', (d) => d.accept());

    const [r1, r2] = await Promise.allSettled([
      (async () => {
        const [resp] = await Promise.all([
          page1.waitForNavigation({ timeout: 15_000 }).catch(() => null),
          btn1.click(),
        ]);
        return { url: page1.url(), status: resp?.status() ?? null };
      })(),
      (async () => {
        const [resp] = await Promise.all([
          page2.waitForNavigation({ timeout: 15_000 }).catch(() => null),
          btn2.click(),
        ]);
        return { url: page2.url(), status: resp?.status() ?? null };
      })(),
    ]);

    const succeeded = [r1, r2].filter((r) => r.status === 'fulfilled').length;

    console.log(`[race-result] Double-confirm-funds: ${succeeded}/2 completed`);
    console.log('[race-result] Confirm-1:', r1.status === 'fulfilled' ? r1.value : r1);
    console.log('[race-result] Confirm-2:', r2.status === 'fulfilled' ? r2.value : r2);

    if (succeeded > 1) {
      console.warn(
        '⚠ RACE DETECTED: Both concurrent fund confirmations succeeded.\n' +
        '  escrowConfirmedAt was overwritten by the second call.\n' +
        '  Two audit log entries were created for the same action.\n' +
        '  Impact: low (idempotent data), but audit trail is noisy.\n' +
        '  Fix: add WHERE escrowStatus != "secured_manual" to the update,\n' +
        '  or use updateMany and check the affected count.'
      );
    }

    await Promise.all([page1.close(), page2.close(), adminCtx.close()]);
  });
});
