import { test, expect, type Page } from '@playwright/test';
import { BUYER_BASE } from './helpers/race-utils';

/**
 * Public /about surface: document structure, navigation, market data, KPIs,
 * footer, typography, and self-hosted font behavior. Read-and-verify only:
 * these specs create guest contexts and never mutate application data.
 */

const EXTERNAL_FONT_HOSTS = [
  'fonts.googleapis.com',
  'fonts.gstatic.com',
  'fonts.bunny.net',
];
const NAV_TIMEOUT = 20_000;

function collectRequests(page: Page): string[] {
  const urls: string[] = [];
  page.on('request', request => urls.push(request.url()));
  return urls;
}

function isFontRequest(url: string): boolean {
  const parsed = new URL(url);
  return /\.(?:woff2?|ttf|otf|eot)(?:[?#]|$)/i.test(parsed.pathname)
    || (parsed.hostname === 'cdn.jsdelivr.net' && /font/i.test(parsed.pathname));
}

function expectNoExternalFonts(urls: string[], baseURL: string): void {
  const externalFonts = urls.filter(url => {
    const parsed = new URL(url);
    return EXTERNAL_FONT_HOSTS.includes(parsed.hostname)
      || (parsed.hostname === 'cdn.jsdelivr.net' && isFontRequest(url));
  }).filter(isFontRequest);
  const externalHostRequests = urls.filter(url =>
    EXTERNAL_FONT_HOSTS.includes(new URL(url).hostname)
    || new URL(url).hostname === 'cdn.jsdelivr.net' && isFontRequest(url));
  expect(externalFonts, 'font files must be self-hosted').toEqual([]);
  expect(externalHostRequests, 'font CDN hosts must not be contacted').toEqual([]);
  expect(urls.filter(isFontRequest).every(url => new URL(url).origin === new URL(baseURL).origin)).toBeTruthy();
}

async function openAbout(browser: Parameters<typeof test>[0]['browser']) {
  const context = await browser.newContext({ baseURL: BUYER_BASE });
  const page = await context.newPage();
  return { context, page };
}

test.describe('/about public page', () => {
  test('returns HTTP 200, RTL metadata, hero heading, and no auth redirect', async ({ browser }) => {
    const { context, page } = await openAbout(browser);
    const response = await page.goto('/about', { waitUntil: 'domcontentloaded', timeout: NAV_TIMEOUT });
    expect(response?.status()).toBe(200);
    await expect(page).not.toHaveURL(/\/login/);
    await expect(page.locator('html')).toHaveAttribute('dir', 'rtl');
    await expect(page.locator('html')).toHaveAttribute('lang', 'fa');
    await expect(page.locator('h1').first()).toHaveText('تجارت مواد اولیه پلیمری، با اطلاعات شفاف‌تر و فرآیند مطمئن‌تر');
    await context.close();
  });

  test('renders all six about sections in document order', async ({ browser }) => {
    const { context, page } = await openAbout(browser);
    await page.goto('/about', { waitUntil: 'domcontentloaded', timeout: NAV_TIMEOUT });
    await expect(page.locator('h2')).toHaveText([
      'چرا انبار پلیمر ساخته شد؟',
      'چرا انبار پلیمر؟',
      'چطور با انبار پلیمر خرید می‌کنید؟',
      'سه اصل اصلی که معامله را امن‌تر می‌کند',
      'انبار پلیمر در یک نگاه',
      'آماده شروع هستید؟',
    ]);
    await expect(page.getByRole('link', { name: 'مشاهده گریدها' })).toHaveAttribute('href', '/grades');
    await context.close();
  });

  test('marks About active and Market inactive in PublicHeader', async ({ browser }) => {
    const { context, page } = await openAbout(browser);
    await page.goto('/about', { waitUntil: 'domcontentloaded', timeout: NAV_TIMEOUT });
    const about = page.locator('nav[data-public-nav="true"] a[href="/about"]');
    const market = page.locator('nav[data-public-nav="true"] a[href="/market"]');
    const nav = page.locator('nav[data-public-nav="true"]');
    await expect(about).toBeVisible();
    await expect(about).toHaveCSS('color', 'rgb(255, 255, 255)');
    await expect(about).toHaveCSS('font-weight', '700');
    await expect(market).not.toHaveCSS('color', 'rgb(255, 255, 255)');

    const indicator = nav.locator('[data-nav-indicator]');
    await expect(indicator).toBeVisible();
    const aboutBox = await about.boundingBox();
    const indicatorBox = await indicator.boundingBox();
    expect(aboutBox).not.toBeNull();
    expect(indicatorBox).not.toBeNull();
    expect(Math.abs(indicatorBox!.x - aboutBox!.x)).toBeLessThanOrEqual(2);
    expect(Math.abs(indicatorBox!.width - aboutBox!.width)).toBeLessThanOrEqual(2);
    await context.close();
  });

  test('renders CurrencyTicker when market rates are available', async ({ browser }) => {
    const { context, page } = await openAbout(browser);
    await page.goto('/about', { waitUntil: 'domcontentloaded', timeout: NAV_TIMEOUT });
    const ticker = page.getByText('نرخ لحظه‌ای:');
    if (await ticker.count() === 0) {
      console.log('CurrencyTicker is absent because live rates are unavailable.');
      await context.close();
      test.skip();
      return;
    }
    await expect(ticker).toBeVisible();
    await expect(page.getByText('دلار')).toBeVisible();
    await expect(page.getByText('تومان')).toBeVisible();
    await context.close();
  });

  test('renders visible KPI values', async ({ browser }) => {
    const { context, page } = await openAbout(browser);
    await page.goto('/about', { waitUntil: 'domcontentloaded', timeout: NAV_TIMEOUT });
    const kpis = page.locator('.kpi');
    await expect(kpis).toHaveCount(4, { timeout: NAV_TIMEOUT });
    await expect(kpis.locator('.k')).toContainText(['گریدهای فعال', 'آگهی‌های عرضه‌ی فعال', 'انبارهای زیر پوشش', 'گزارش‌های منتشرشده']);
    for (const value of await kpis.locator('.v').all()) await expect(value).not.toBeEmpty();
    await context.close();
  });

  test('renders expected footer content', async ({ browser }) => {
    const { context, page } = await openAbout(browser);
    await page.goto('/about', { waitUntil: 'domcontentloaded', timeout: NAV_TIMEOUT });
    const footer = page.locator('footer.site-footer');
    await expect(footer).toBeVisible();
    await expect(footer).toContainText(['محصولات', 'خدمات', 'اطلاعات تماس', 'تهران، خیابان ولیعصر، پلاک ۱۲۴', 'انبار یزد — شهرک صنعتی یزد', '021-91234567', 'انبار پلیمر © ۱۴۰۵ — تمام حقوق محفوظ است']);
    await expect(footer.locator('a[href="/reports"]')).toContainText('گزارش بازار');
    await context.close();
  });

  test('uses only same-origin fonts on /about', async ({ browser }) => {
    const { context, page } = await openAbout(browser);
    const requests = collectRequests(page);
    await page.goto('/about', { waitUntil: 'networkidle', timeout: 30_000 });
    expectNoExternalFonts(requests, BUYER_BASE);
    await context.close();
  });

  test('uses a non-default computed font family', async ({ browser }) => {
    const { context, page } = await openAbout(browser);
    await page.goto('/about', { waitUntil: 'domcontentloaded', timeout: NAV_TIMEOUT });
    for (const locator of [page.locator('body'), page.locator('h1').first()]) {
      const family = await locator.evaluate(element => getComputedStyle(element).fontFamily);
      expect(family.trim()).not.toBe('');
      expect(family).not.toContain('Times New Roman');
    }
    await context.close();
  });
});
