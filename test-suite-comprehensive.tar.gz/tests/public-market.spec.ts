/**
 * Playwright E2E tests — /market (public market page: structure & interactions)
 *
 * Covers:
 *   - Page load: title, two tabs (عرضه supply / تقاضا demand), default tab active
 *   - Tab switching: demand tab navigation + active-state swap (inline fontWeight,
 *     source has no aria-selected — tabs are plain <a> links)
 *   - Table headers per tab, or documented empty state when DB is empty
 *   - Loading skeleton (graceful skip — source has none: app/market has only page.tsx,
 *     server-rendered, no Suspense skeleton)
 *   - Table rows: expected cells, market-row-hover class on hover
 *   - ListingDetailDialog: opens on row click, closes via its close button;
 *     source has NO Escape handler (documented — Escape keeps modal open)
 *   - PurchaseRequestDialog: same for the demand tab
 *   - TrustCardModal: opens from ⓘ (aria-label buttons), closes via close button
 *   - Search: q filter filters rows / shows empty state; پاک کردن restores rows
 *   - PublicHeader: /market nav link active via inline color/fontWeight and the
 *     sliding indicator is visible and aligned beneath the active link; /about inactive
 *   - No PII leak: HTML contains no passwordHash/"phone"/"email" keys; visible page
 *     text contains no owner email or 09xxxxxxxxx mobile patterns
 *
 * Data safety:
 *   - Pure read/navigation — no mutations at all.
 *   - Graceful skip (test.skip + console.log) whenever live data is absent.
 *   - Persian strings copied byte-exact from source (ZWNJ preserved where present).
 */

import { test, expect, type Browser } from '@playwright/test';
import { BUYER_BASE } from './helpers/race-utils';

const MARKET_URL = '/market';

// Local helper: fresh guest context (public project has no storageState)
async function guestContext(browser: Browser) {
  return browser.newContext({ baseURL: BUYER_BASE });
}

// Count data rows currently rendered (both tabs use .market-row-hover on rows)
function dataRows(page: import('@playwright/test').Page) {
  return page.locator('.market-row-hover');
}

// ─────────────────────────────────────────────────────────────────────────────

test.describe('/market — Page Load & Structure', () => {
  test('page renders with both tabs; supply tab is the default active tab', async ({ browser }) => {
    const ctx = await guestContext(browser);
    const page = await ctx.newPage();

    await page.goto(MARKET_URL, { waitUntil: 'domcontentloaded', timeout: 20_000 });

    // Page title (from market/page.tsx: sec-title)
    await expect(page.locator('.sec-title')).toContainText('بازار صنعتی پلیمر');

    // Both tab links exist (they are plain <a> links in source, not buttons)
    const supplyTab = page.locator('a[href="/market"]').filter({ hasText: 'عرضه' });
    const demandTab = page.locator('a[href="/market?view=demand"]');
    await expect(supplyTab).toBeVisible();
    await expect(demandTab).toBeVisible();

    // Active state in source is inline style: tabActiveStyle has fontWeight 800,
    // inactive tabStyle 600 (no aria-selected / active class exists).
    const supplyWeight = await supplyTab.evaluate((el) => window.getComputedStyle(el).fontWeight);
    const demandWeight = await demandTab.evaluate((el) => window.getComputedStyle(el).fontWeight);
    expect(parseInt(supplyWeight, 10)).toBe(800);
    expect(parseInt(demandWeight, 10)).toBe(600);

    await page.close();
    await ctx.close();
  });

  test('supply view shows table header columns or the documented empty state', async ({ browser }) => {
    const ctx = await guestContext(browser);
    const page = await ctx.newPage();

    await page.goto(MARKET_URL, { waitUntil: 'domcontentloaded', timeout: 20_000 });
    await expect(page.locator('.sec-title')).toBeVisible();

    // Empty state text (exact, from market/page.tsx line 277)
    const supplyEmpty = page.getByText('هیچ آگهی فعالی با این فیلتر یافت نشد.');

    if ((await supplyEmpty.count()) > 0) {
      console.log('[info] No supply listings on live server — empty state shown');
      await expect(supplyEmpty).toBeVisible();
    } else {
      // Supply header cells (exact, from market/page.tsx lines 282-291)
      // "محل بار" and "مبدأ" are unique to the supply table header
      await expect(page.getByText('محل بار', { exact: true })).toBeVisible();
      await expect(page.getByText('مبدأ', { exact: true })).toBeVisible();
      await expect(page.getByText('وضعیت', { exact: true })).toBeVisible();
    }

    await page.close();
    await ctx.close();
  });

  test('demand view shows its table header columns or the documented empty state', async ({ browser }) => {
    const ctx = await guestContext(browser);
    const page = await ctx.newPage();

    await page.goto(`${MARKET_URL}?view=demand`, { waitUntil: 'domcontentloaded', timeout: 20_000 });
    await expect(page.locator('.sec-title')).toBeVisible();

    // Empty state text (exact, from market/page.tsx line 307)
    const demandEmpty = page.getByText('در حال حاضر هیچ درخواست خرید بازی ثبت نشده.');

    if ((await demandEmpty.count()) > 0) {
      console.log('[info] No demand requests on live server — empty state shown');
      await expect(demandEmpty).toBeVisible();
    } else {
      // Demand header cells (exact, from market/page.tsx lines 312-319)
      // "مقدار موردنیاز" and "سقف قیمت" are unique to the demand table header
      await expect(page.getByText('مقدار موردنیاز', { exact: true })).toBeVisible();
      await expect(page.getByText('سقف قیمت', { exact: true })).toBeVisible();
    }

    await page.close();
    await ctx.close();
  });

  test('loading skeleton before data (graceful skip — source defines none)', async ({ browser }) => {
    const ctx = await guestContext(browser);
    const page = await ctx.newPage();

    await page.goto(MARKET_URL, { waitUntil: 'commit', timeout: 20_000 });

    // Look for common skeleton markers; app/market contains only page.tsx
    // (force-dynamic server component, no loading.tsx / Suspense skeleton).
    const skeletons = page.locator('[class*="skeleton"], [data-skeleton], [aria-busy="true"]');
    const skeletonCount = await skeletons.count();

    if (skeletonCount === 0) {
      console.log(
        '[info] No skeleton selector found — /market is server-rendered with no loading.tsx ' +
        '(documented in source; skeleton check skipped)'
      );
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    await expect(skeletons.first()).toBeVisible();
    // Data rows eventually replace the skeleton
    await expect(page.locator('.market-row-hover').first()).toBeVisible({ timeout: 20_000 });

    await page.close();
    await ctx.close();
  });
});

test.describe('/market — Tab Switching', () => {
  test('clicking the demand tab navigates to ?view=demand and moves the active state', async ({ browser }) => {
    const ctx = await guestContext(browser);
    const page = await ctx.newPage();

    await page.goto(MARKET_URL, { waitUntil: 'domcontentloaded', timeout: 20_000 });

    const supplyTab = page.locator('a[href="/market"]').filter({ hasText: 'عرضه' });
    const demandTab = page.locator('a[href="/market?view=demand"]');

    // Full-page navigation via plain <a href> — wait for URL then DOM
    await Promise.all([
      page.waitForURL(/\/market\?view=demand/, { timeout: 20_000 }),
      demandTab.click(),
    ]);
    await page.waitForLoadState('domcontentloaded');

    // Active indicator moved: demand tab now fontWeight 800, supply 600
    const demandWeight = await demandTab.evaluate((el) => window.getComputedStyle(el).fontWeight);
    const supplyWeight = await supplyTab.evaluate((el) => window.getComputedStyle(el).fontWeight);
    expect(parseInt(demandWeight, 10)).toBe(800);
    expect(parseInt(supplyWeight, 10)).toBe(600);

    await page.close();
    await ctx.close();
  });
});

test.describe('/market — Table Rows & Hover', () => {
  test('first supply row renders expected cells and carries market-row-hover on hover', async ({ browser }) => {
    const ctx = await guestContext(browser);
    const page = await ctx.newPage();

    await page.goto(MARKET_URL, { waitUntil: 'domcontentloaded', timeout: 20_000 });

    const rows = dataRows(page);
    const count = await rows.count();
    if (count === 0) {
      console.log('[skip] No supply listings — cannot verify row cells / hover');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    const firstRow = rows.first();
    await expect(firstRow).toBeVisible();

    // Expected cell content (from SupplyTableRow.tsx):
    // price unit "تومان/کیلو", quantity unit "تن",
    // status badge is exactly one of 'آزاد' / 'در حال معامله'
    await expect(firstRow).toContainText('تومان/کیلو');
    await expect(firstRow).toContainText('تن');
    const rowText = (await firstRow.textContent()) ?? '';
    expect(rowText.includes('آزاد') || rowText.includes('در حال معامله')).toBe(true);

    // Hover style class (globals.css: .market-row-hover{...:hover{border-color,box-shadow}})
    await firstRow.hover();
    const classList = await firstRow.evaluate((el) => Array.from(el.classList));
    expect(classList).toContain('market-row-hover');

    await page.close();
    await ctx.close();
  });

  test('demand rows render with market-row-hover class', async ({ browser }) => {
    const ctx = await guestContext(browser);
    const page = await ctx.newPage();

    await page.goto(`${MARKET_URL}?view=demand`, { waitUntil: 'domcontentloaded', timeout: 20_000 });

    const rows = dataRows(page);
    const count = await rows.count();
    if (count === 0) {
      console.log('[skip] No demand requests — cannot verify demand row hover');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    const firstRow = rows.first();
    await expect(firstRow).toBeVisible();

    // Expected demand cell content: quantity unit "تن", status badge "باز"
    await expect(firstRow).toContainText('تن');
    await expect(firstRow.getByText('باز', { exact: true })).toBeVisible();

    await firstRow.hover();
    const classList = await firstRow.evaluate((el) => Array.from(el.classList));
    expect(classList).toContain('market-row-hover');

    await page.close();
    await ctx.close();
  });
});

test.describe('/market — Listing Detail Modal (Supply)', () => {
  test('clicking a supply row opens ListingDetailDialog; close button closes it', async ({ browser }) => {
    const ctx = await guestContext(browser);
    const page = await ctx.newPage();

    await page.goto(MARKET_URL, { waitUntil: 'domcontentloaded', timeout: 20_000 });

    const rows = dataRows(page);
    const count = await rows.count();
    if (count === 0) {
      console.log('[skip] No supply listings — cannot test listing detail modal');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    // Row click (anywhere but the action buttons) opens the dialog, portaled to <body>
    await rows.first().click();

    // Dialog identified by its unique label "قیمت درخواستی" (ListingDetailModal.tsx line 269)
    const modal = page
      .locator('div[style*="position: fixed"][style*="inset: 0"]')
      .filter({ hasText: 'قیمت درخواستی' });
    await expect(modal).toBeVisible({ timeout: 10_000 });
    await expect(modal).toContainText('تاریخ ثبت');
    await expect(modal).toContainText('کشور مبدأ');

    // Close via the dialog close button (aria-label="بستن")
    await modal.locator('button[aria-label="بستن"]').click();
    await expect(modal).toHaveCount(0, { timeout: 5_000 });

    await page.close();
    await ctx.close();
  });

  test('Escape does NOT close the dialog — source wires no Escape handler (documented)', async ({ browser }) => {
    const ctx = await guestContext(browser);
    const page = await ctx.newPage();

    await page.goto(MARKET_URL, { waitUntil: 'domcontentloaded', timeout: 20_000 });

    const rows = dataRows(page);
    const count = await rows.count();
    if (count === 0) {
      console.log('[skip] No supply listings — cannot test Escape behavior');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    await rows.first().click();
    const modal = page
      .locator('div[style*="position: fixed"][style*="inset: 0"]')
      .filter({ hasText: 'قیمت درخواستی' });
    await expect(modal).toBeVisible({ timeout: 10_000 });

    // ListingDetailDialog only closes via close button / overlay click — no keydown
    // listener exists in source, so Escape must leave it open.
    await page.keyboard.press('Escape');
    await page.waitForTimeout(500); // allow any (absent) handler to run
    await expect(modal).toBeVisible();

    // Overlay click closes (source: overlay div has onClick={onClose})
    await modal.locator('button[aria-label="بستن"]').click();
    await expect(modal).toHaveCount(0, { timeout: 5_000 });

    await page.close();
    await ctx.close();
  });
});

test.describe('/market — Purchase Request Detail Modal (Demand)', () => {
  test('clicking a demand row opens PurchaseRequestDialog; close button closes it', async ({ browser }) => {
    const ctx = await guestContext(browser);
    const page = await ctx.newPage();

    await page.goto(`${MARKET_URL}?view=demand`, { waitUntil: 'domcontentloaded', timeout: 20_000 });

    const rows = dataRows(page);
    const count = await rows.count();
    if (count === 0) {
      console.log('[skip] No demand requests — cannot test purchase-request detail modal');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    await rows.first().click();

    // Dialog identified by its unique label "سقف قیمت خریدار" (PurchaseRequestDetailModal.tsx line 209)
    const modal = page
      .locator('div[style*="position: fixed"][style*="inset: 0"]')
      .filter({ hasText: 'سقف قیمت خریدار' });
    await expect(modal).toBeVisible({ timeout: 10_000 });
    await expect(modal).toContainText('تاریخ ثبت');
    await expect(modal).toContainText('استان تحویل');

    await modal.locator('button[aria-label="بستن"]').click();
    await expect(modal).toHaveCount(0, { timeout: 5_000 });

    await page.close();
    await ctx.close();
  });
});

test.describe('/market — Trust Card Modal', () => {
  test('ⓘ on a supply row opens TrustCardModal "فرآیند این پیشنهاد"; close button closes it', async ({ browser }) => {
    const ctx = await guestContext(browser);
    const page = await ctx.newPage();

    await page.goto(MARKET_URL, { waitUntil: 'domcontentloaded', timeout: 20_000 });

    const rows = dataRows(page);
    const count = await rows.count();
    if (count === 0) {
      console.log('[skip] No supply listings — cannot test Trust Card');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    // ⓘ button: aria-label="فرآیند این پیشنهاد" (SupplyTableRow.tsx line 63)
    const infoBtn = rows.first().locator('button[aria-label="فرآیند این پیشنهاد"]');
    if ((await infoBtn.count()) === 0) {
      console.log('[skip] Trust Card ⓘ button not rendered in supply row');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }
    await infoBtn.click();

    // TrustCardModal has role="dialog" aria-modal="true" aria-label={title}
    const trustModal = page.locator('div[role="dialog"][aria-modal="true"]');
    await expect(trustModal).toBeVisible({ timeout: 10_000 });
    await expect(trustModal).toHaveAttribute('aria-label', 'فرآیند این پیشنهاد');
    await expect(trustModal).toContainText('شفافیت فرآیند');

    await trustModal.locator('button[aria-label="بستن"]').click();
    await expect(trustModal).toHaveCount(0, { timeout: 5_000 });

    await page.close();
    await ctx.close();
  });

  test('ⓘ on a demand row opens TrustCardModal "فرآیند این درخواست"; close button closes it', async ({ browser }) => {
    const ctx = await guestContext(browser);
    const page = await ctx.newPage();

    await page.goto(`${MARKET_URL}?view=demand`, { waitUntil: 'domcontentloaded', timeout: 20_000 });

    const rows = dataRows(page);
    const count = await rows.count();
    if (count === 0) {
      console.log('[skip] No demand requests — cannot test Trust Card');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    // ⓘ button: aria-label="فرآیند این درخواست" (DemandTableRow.tsx line 68)
    const infoBtn = rows.first().locator('button[aria-label="فرآیند این درخواست"]');
    if ((await infoBtn.count()) === 0) {
      console.log('[skip] Trust Card ⓘ button not rendered in demand row');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }
    await infoBtn.click();

    const trustModal = page.locator('div[role="dialog"][aria-modal="true"]');
    await expect(trustModal).toBeVisible({ timeout: 10_000 });
    await expect(trustModal).toHaveAttribute('aria-label', 'فرآیند این درخواست');
    await expect(trustModal).toContainText('شفافیت فرآیند');

    await trustModal.locator('button[aria-label="بستن"]').click();
    await expect(trustModal).toHaveCount(0, { timeout: 5_000 });

    await page.close();
    await ctx.close();
  });
});

test.describe('/market — Search (q filter)', () => {
  test('searching filters rows / shows empty state; پاک کردن restores rows', async ({ browser }) => {
    const ctx = await guestContext(browser);
    const page = await ctx.newPage();

    await page.goto(MARKET_URL, { waitUntil: 'domcontentloaded', timeout: 20_000 });

    // Search input: <input name="q"> in the GET filter form (market/page.tsx line 156)
    const searchInput = page.locator('input[name="q"]');
    if ((await searchInput.count()) === 0) {
      console.log('[info] No search input (input[name="q"]) on /market — documented absence, skipping');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    const rowsBefore = await dataRows(page).count();
    if (rowsBefore === 0) {
      console.log('[skip] No supply listings — cannot test search filtering');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    // Apply a query guaranteed to match nothing (e2e- prefix per suite convention)
    await searchInput.fill('e2e-nonexistent-tag');
    const applyBtn = page.locator('button[type="submit"]').filter({ hasText: 'اعمال فیلتر' });
    await Promise.all([
      page.waitForURL(/\/market\?.*q=e2e-nonexistent-tag/, { timeout: 20_000 }),
      applyBtn.click(),
    ]);
    await page.waitForLoadState('domcontentloaded');

    // Either zero rows or the documented filtered empty state (exact, line 277)
    const rowsAfter = await dataRows(page).count();
    const emptyState = page.getByText('هیچ آگهی فعالی با این فیلتر یافت نشد.');
    expect(rowsAfter === 0 || (await emptyState.count()) > 0).toBe(true);

    // Clear via پاک کردن link (rendered only while a filter is active, line 216-222)
    const clearLink = page.locator('a.btn-outline').filter({ hasText: 'پاک کردن' });
    await expect(clearLink).toBeVisible();
    await Promise.all([
      page.waitForURL((url) => !url.searchParams.has('q'), { timeout: 20_000 }),
      clearLink.click(),
    ]);
    await page.waitForLoadState('domcontentloaded');

    // Rows return
    await expect(dataRows(page).first()).toBeVisible({ timeout: 20_000 });
    expect(await dataRows(page).count()).toBe(rowsBefore);

    await page.close();
    await ctx.close();
  });
});

test.describe('/market — PublicHeader Active State', () => {
  test('بازار صنعتی nav link and sliding indicator are active and aligned; درباره ما is not', async ({ browser }) => {
    const ctx = await guestContext(browser);
    const page = await ctx.newPage();

    await page.goto(MARKET_URL, { waitUntil: 'domcontentloaded', timeout: 20_000 });

    // Desktop nav (viewport 1280 wide → nav visible; hidden below 900px per globals.css)
    const nav = page.locator('nav[data-public-nav="true"]');
    await expect(nav).toBeVisible();

    const marketLink = nav.locator('a[href="/market"]');
    await expect(marketLink).toHaveText('بازار صنعتی');

    // Active mechanism: active gets color #ffffff + fontWeight 700; inactive
    // gets rgba(255,255,255,0.78) + 600.
    const marketWeight = await marketLink.evaluate((el) => window.getComputedStyle(el).fontWeight);
    expect(parseInt(marketWeight, 10)).toBe(700);

    const aboutLink = nav.locator('a[href="/about"]');
    const aboutWeight = await aboutLink.evaluate((el) => window.getComputedStyle(el).fontWeight);
    expect(parseInt(aboutWeight, 10)).toBeLessThan(700); // 600 in source

    // The deployed PublicHeader renders the indicator span with data-nav-indicator="true".
    const indicator = nav.locator('[data-nav-indicator]');
    await expect(indicator).toBeVisible();
    const linkBox = await marketLink.boundingBox();
    const indicatorBox = await indicator.boundingBox();
    expect(linkBox).not.toBeNull();
    expect(indicatorBox).not.toBeNull();
    expect(Math.abs(indicatorBox!.x - linkBox!.x)).toBeLessThanOrEqual(2);
    expect(Math.abs(indicatorBox!.width - linkBox!.width)).toBeLessThanOrEqual(2);

    await page.close();
    await ctx.close();
  });
});

test.describe('/market — No PII Leak', () => {
  test('page exposes no passwordHash / user phone / user email', async ({ browser }) => {
    const ctx = await guestContext(browser);
    const page = await ctx.newPage();

    await page.goto(MARKET_URL, { waitUntil: 'domcontentloaded', timeout: 20_000 });
    await expect(page.locator('.sec-title')).toBeVisible();

    // 1) Raw HTML (includes the RSC flight payload that serializes listing objects):
    //    the security NOTE in market/page.tsx forbids including `user` because it
    //    would serialize User.passwordHash / phone / email into the public payload.
    const html = await page.content();
    expect(html).not.toContain('passwordHash');
    expect(html).not.toContain('"phone"');
    expect(html).not.toContain('"email"');

    // 2) Visible text: no owner email / mobile number rendered anywhere.
    //    (Legit contact info in header/footer is 021-91234567 landline only.)
    const bodyText = await page.locator('body').innerText();
    expect(bodyText).not.toMatch(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/);
    expect(bodyText).not.toMatch(/\b09\d{9}\b/);

    await page.close();
    await ctx.close();
  });
});
