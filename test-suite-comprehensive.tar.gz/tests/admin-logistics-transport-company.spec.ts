/**
 * Playwright E2E tests — /admin-logistics Phase-1 transport-company creation
 *
 * Covers:
 *   - Form presence & structure (admin context)
 *   - Validation errors (invalid phone, manager identifier with space, duplicate)
 *   - Successful creation (e2e- prefixed data)
 *   - transport_manager login routing to TRANSPORT_PORT (:4000)
 *   - Form hidden for non-edit users (logistics access level)
 *
 * Data safety:
 *   - ALL created data carries `e2e-` prefix (company name, manager identifier).
 *   - Manager identifier = username branch (never random 09… phones to avoid real-user collision).
 *   - No cleanup/DELETE — stale e2e- rows are acceptable.
 *   - Password value NEVER appears in logs/console output.
 *
 * Deployment uncertainty:
 *   - The live server may NOT have Phase-1 deployed (work-src snapshot is stale).
 *   - Every test feature-detects first: look for submit button `ساخت شرکت و حساب مدیر`.
 *   - If absent → log skip reason + close contexts + test.skip().
 */

import { test, expect } from '@playwright/test';
import { ADMIN_BASE, BUYER_BASE, uniqueTag, adminContext } from './helpers/race-utils';

// Module-level storage for the created manager identifier (used in duplicate/routing tests)
let createdManagerIdentifier = '';

test.describe.configure({ mode: 'serial' });

test.describe('/admin-logistics — Phase-1 Transport Company Creation', () => {

  test('form presence & structure (admin)', async ({ browser }) => {
    const ctx = await adminContext(browser);
    const page = await ctx.newPage();

    await page.goto('/admin-logistics', { waitUntil: 'networkidle', timeout: 15_000 });

    // Feature detection: submit button with exact text
    const submitBtn = page.getByRole('button', { name: 'ساخت شرکت و حساب مدیر' });
    if ((await submitBtn.count()) === 0) {
      console.log('[skip] Phase-1 transport-company form not deployed on live server');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    // Form should be visible
    await expect(submitBtn).toBeVisible();

    // All four labeled inputs with correct name attrs
    await expect(page.locator('input[name="companyName"]')).toBeVisible();
    await expect(page.locator('input[name="contactPhone"]')).toBeVisible();
    await expect(page.locator('input[name="managerIdentifier"]')).toBeVisible();
    await expect(page.locator('input[name="initialPassword"]')).toBeVisible();

    // Password input type=password + autoComplete=new-password
    const pwInput = page.locator('input[name="initialPassword"]');
    await expect(pwInput).toHaveAttribute('type', 'password');
    await expect(pwInput).toHaveAttribute('autocomplete', 'new-password');

    // Hint paragraph present
    await expect(page.getByText(/پسورد باید مطابق سیاست فعلی رمز عبور سامانه باشد/)).toBeVisible();

    // Labels (check a few key ones)
    await expect(page.getByText('نام شرکت')).toBeVisible();
    await expect(page.getByText('تلفن تماس')).toBeVisible();
    await expect(page.getByText('نام‌کاربری/شماره‌تلفن مدیر')).toBeVisible();
    await expect(page.getByText('پسورد اولیه')).toBeVisible();

    await page.close();
    await ctx.close();
  });

  test('validation error: invalid contact phone', async ({ browser }) => {
    const ctx = await adminContext(browser);
    const page = await ctx.newPage();

    await page.goto('/admin-logistics', { waitUntil: 'networkidle', timeout: 15_000 });

    const submitBtn = page.getByRole('button', { name: 'ساخت شرکت و حساب مدیر' });
    if ((await submitBtn.count()) === 0) {
      console.log('[skip] Phase-1 transport-company form not deployed on live server');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    // Fill with invalid contact phone (native pattern may block submission)
    // Disable native validation so server-side message is exercised
    await page.evaluate(() => {
      const form = document.querySelector('input[name="contactPhone"]')?.closest('form');
      if (form) form.setAttribute('novalidate', 'true');
    });

    await page.locator('input[name="companyName"]').fill('e2e-test-company');
    await page.locator('input[name="contactPhone"]').fill('12345');
    await page.locator('input[name="managerIdentifier"]').fill('e2e-test-manager');
    await page.locator('input[name="initialPassword"]').fill('E2e-Transport-2026');

    await submitBtn.click();

    // Wait for error feedback role=alert
    const errorMsg = page.locator('[role="alert"]:not(#__next-route-announcer__)');
    await expect(errorMsg).toBeVisible({ timeout: 10_000 });
    await expect(errorMsg).toContainText('تلفن تماس شرکت باید به‌شکل ۰۹xxxxxxxxx باشه.');

    await page.close();
    await ctx.close();
  });

  test('validation error: manager identifier with space', async ({ browser }) => {
    const ctx = await adminContext(browser);
    const page = await ctx.newPage();

    await page.goto('/admin-logistics', { waitUntil: 'networkidle', timeout: 15_000 });

    const submitBtn = page.getByRole('button', { name: 'ساخت شرکت و حساب مدیر' });
    if ((await submitBtn.count()) === 0) {
      console.log('[skip] Phase-1 transport-company form not deployed on live server');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    await page.locator('input[name="companyName"]').fill('e2e-test-company');
    await page.locator('input[name="contactPhone"]').fill('09123456789');
    await page.locator('input[name="managerIdentifier"]').fill('e2e manager bad');
    await page.locator('input[name="initialPassword"]').fill('E2e-Transport-2026');

    await submitBtn.click();

    const errorMsg = page.locator('[role="alert"]:not(#__next-route-announcer__)');
    await expect(errorMsg).toBeVisible({ timeout: 10_000 });
    await expect(errorMsg).toContainText('نام کاربری مدیر باید بین ۳ تا ۶۴ کاراکتر و بدون فاصله باشه.');

    await page.close();
    await ctx.close();
  });

  test('successful creation (e2e- data)', async ({ browser }) => {
    const ctx = await adminContext(browser);
    const page = await ctx.newPage();

    await page.goto('/admin-logistics', { waitUntil: 'networkidle', timeout: 15_000 });

    const submitBtn = page.getByRole('button', { name: 'ساخت شرکت و حساب مدیر' });
    if ((await submitBtn.count()) === 0) {
      console.log('[skip] Phase-1 transport-company form not deployed on live server');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    const tag = uniqueTag();
    const companyName = `e2e-transport-company-${tag}`;
    const managerIdentifier = `e2e-manager-${tag}`;
    const password = 'E2e-Transport-2026';

    // Store for later tests
    createdManagerIdentifier = managerIdentifier;

    await page.locator('input[name="companyName"]').fill(companyName);
    await page.locator('input[name="contactPhone"]').fill('09123456789');
    await page.locator('input[name="managerIdentifier"]').fill(managerIdentifier);
    await page.locator('input[name="initialPassword"]').fill(password);

    await submitBtn.click();

    // Wait for success feedback role=status
    const successMsg = page.locator('[role="status"]');
    await expect(successMsg).toBeVisible({ timeout: 10_000 });
    await expect(successMsg).toContainText('شرکت حمل‌ونقل و حساب مدیر با موفقیت ساخته شد.');

    // Form should reset (companyName input value becomes '')
    await expect(page.locator('input[name="companyName"]')).toHaveValue('');

    await page.close();
    await ctx.close();
  });

  test('validation error: duplicate manager identifier', async ({ browser }) => {
    const ctx = await adminContext(browser);
    const page = await ctx.newPage();

    await page.goto('/admin-logistics', { waitUntil: 'networkidle', timeout: 15_000 });

    const submitBtn = page.getByRole('button', { name: 'ساخت شرکت و حساب مدیر' });
    if ((await submitBtn.count()) === 0) {
      console.log('[skip] Phase-1 transport-company form not deployed on live server');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    if (!createdManagerIdentifier) {
      console.log('[skip] No manager identifier from previous creation test');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    // Use the same managerIdentifier from the successful creation test
    await page.locator('input[name="companyName"]').fill('e2e-duplicate-company');
    await page.locator('input[name="contactPhone"]').fill('09123456789');
    await page.locator('input[name="managerIdentifier"]').fill(createdManagerIdentifier);
    await page.locator('input[name="initialPassword"]').fill('E2e-Transport-2026');

    await submitBtn.click();

    const errorMsg = page.locator('[role="alert"]:not(#__next-route-announcer__)');
    await expect(errorMsg).toBeVisible({ timeout: 10_000 });
    await expect(errorMsg).toContainText('این نام کاربری یا شماره‌ی مدیر قبلاً ثبت شده.');

    await page.close();
    await ctx.close();
  });

  test('transport_manager login routing', async ({ browser }) => {
    if (!createdManagerIdentifier) {
      console.log('[skip] No manager identifier from previous creation test');
      test.skip();
      return;
    }

    // Fresh guest context on BUYER_BASE login page — explicit empty storageState
    // so the admin project's use.storageState is not inherited.
    const ctx = await browser.newContext({ baseURL: BUYER_BASE, storageState: { cookies: [], origins: [] } });
    const page = await ctx.newPage();

    await page.goto('/login', { waitUntil: 'networkidle', timeout: 15_000 });

    // Fill login form (name attrs: identifier, password)
    await page.locator('input[name="identifier"]').fill(createdManagerIdentifier);
    await page.locator('input[name="password"]').fill('E2e-Transport-2026');

    // Submit and wait for navigation (may redirect to unreachable :4000)
    try {
      await Promise.all([
        page.waitForNavigation({ timeout: 10_000 }).catch(() => null),
        page.locator('button[type="submit"]').click(),
      ]);
    } catch (e) {
      // Navigation may fail if :4000 is unreachable — check URL anyway
    }
    // Give a client-side redirect (server action) a moment to commit
    await page.waitForTimeout(1_500).catch(() => null);

    // Assert URL contains /transport-panel (any host/port)
    const url = page.url();
    expect(url).toContain('/transport-panel');
    console.log(`[info] Redirected to: ${url}`);

    // If the target is reachable and renders the gating heading, assert it
    // NOTE: the heading in transport-panel/page.tsx line 81 is:
    // "پنل شرکت حملونقل — دسترسی غیرفعال" (NO ZWNJ in حملونقل)
    // and body line 84: "دسترسی پنل حملونقل برای {company.name} در حال حاضر غیرفعاله..."
    try {
      const gatingHeading = page.getByRole('heading', { name: /پنل شرکت حملونقل — دسترسی غیرفعال/ });
      if ((await gatingHeading.count()) > 0) {
        await expect(gatingHeading).toBeVisible({ timeout: 5_000 });
        console.log('[info] Gating message verified: logisticsAccessEnabled=false for new company');
      } else {
        console.log('[info] Gating heading not found (target may be unreachable or different)');
      }
    } catch (e) {
      console.log('[info] Could not verify gating message (page may not have loaded)');
    }

    await page.close();
    await ctx.close();
  });

  test('form hidden for non-edit user', async ({ browser }) => {
    // Login as Testlogistic / @12345678 (real account with logistics view/read)
    // Guest context — explicit empty storageState so the admin project's
    // use.storageState is not inherited before the Testlogistic UI login.
    const ctx = await browser.newContext({ baseURL: ADMIN_BASE, storageState: { cookies: [], origins: [] } });
    const page = await ctx.newPage();

    await page.goto('/login', { waitUntil: 'networkidle', timeout: 15_000 });

    await page.locator('input[name="identifier"]').fill('Testlogistic');
    await page.locator('input[name="password"]').fill('@12345678');

    try {
      await Promise.all([
        page.waitForNavigation({ timeout: 10_000 }),
        page.locator('button[type="submit"]').click(),
      ]);
    } catch (e) {
      console.log('[skip] Testlogistic login failed (account may not exist live)');
      await page.close();
      await ctx.close();
      test.skip();
      return;
    }

    // Navigate to /admin-logistics
    await page.goto('/admin-logistics', { waitUntil: 'networkidle', timeout: 15_000 });

    // EITHER the no-access message is visible, OR the page renders WITHOUT the creation form
    const noAccessMsg1 = page.getByText('دسترسی مدیریت حمل‌ونقل داخلی رو نداری — از مدیر بخواه بهت بده.');
    const noAccessMsg2 = page.getByText('به این بخش دسترسی نداری.');
    const submitBtn = page.getByRole('button', { name: 'ساخت شرکت و حساب مدیر' });

    const hasNoAccess = (await noAccessMsg1.count()) > 0 || (await noAccessMsg2.count()) > 0;
    const hasForm = (await submitBtn.count()) > 0;

    if (hasNoAccess) {
      console.log('[info] No-access message shown for Testlogistic');
      expect(hasNoAccess).toBe(true);
    } else if (!hasForm) {
      console.log('[info] Page renders without creation form for Testlogistic');
      expect(hasForm).toBe(false);
    } else {
      // Form is visible — this is unexpected for a view/read user
      console.log('[warn] Form is visible for Testlogistic (unexpected)');
      expect(hasForm).toBe(false);
    }

    await page.close();
    await ctx.close();
  });
});
