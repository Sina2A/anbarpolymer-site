/**
 * Race-Condition Test — Listing Status Toggle Race
 *
 * Surface: `updateListingStatusAction` in
 *          src/app/admin-material-listings/actions.ts
 *
 * The code:
 *   1. Reads the listing: `findUnique({ where: { id } })`
 *   2. Computes target: `VALID_TRANSITIONS[listing.validityStatus]`
 *      (active → reserved, reserved → active)
 *   3. Updates: `update({ where: { id }, data: { validityStatus: newStatus } })`
 *
 * Race scenario: Two admins click "toggle" on the same active listing at the
 * same time.  Both read status='active', both compute target='reserved',
 * both write 'reserved'.  No data corruption in this case, but if one
 * intended to re-activate, the second toggle (which should flip back to
 * 'active') is lost.
 *
 * More dangerous: one admin toggles while another cancels.  Both read
 * the current status, but the final state depends on execution order.
 *
 * What this test does:
 *   - Finds an active listing on /admin-material-listings.
 *   - Opens two admin pages and clicks "toggle" simultaneously.
 *   - Checks that the final listing state is consistent (not stuck).
 *
 * Data safety:
 *   - Does not create listings; only toggles existing ones.
 *   - Status is reversible (active ↔ reserved).
 *   - If test toggles a listing to 'reserved', it logs the ID for
 *     manual re-activation if needed.
 */

import { test, expect } from '@playwright/test';
import { adminContext } from './helpers/race-utils';

// Mutation-safety gate — this spec toggles/cancels a REAL listing on the
// live server (whichever listing happens to be first).  Skipped by default;
// opt in explicitly with E2E_UNSAFE_RACE_MUTATIONS=1, and only ever on a
// staging database.
const ALLOW_REAL_RACE_MUTATIONS = !!process.env.E2E_UNSAFE_RACE_MUTATIONS;

test.describe('Race: Material Listing Status Toggle', () => {
  test.skip(
    !ALLOW_REAL_RACE_MUTATIONS,
    'mutates real server records — set E2E_UNSAFE_RACE_MUTATIONS=1 to enable (staging only)'
  );


  test('concurrent toggle of same listing should produce consistent state', async ({
    browser,
  }) => {
    const adminCtx = await adminContext(browser);
    const listPage = await adminCtx.newPage();

    await listPage.goto('/admin-material-listings', {
      waitUntil: 'networkidle',
      timeout: 15_000,
    });
    await expect(listPage).not.toHaveURL(/\/login/);

    // Find a listing row with a toggle form
    // The page has forms with action=toggle and hidden inputs for id and action
    const toggleForm = listPage
      .locator('form')
      .filter({ has: listPage.locator('input[name="action"][value="toggle"]') })
      .first();

    if ((await toggleForm.count()) === 0) {
      console.log('[skip] No toggle forms found on /admin-material-listings');
      await listPage.close();
      await adminCtx.close();
      test.skip();
      return;
    }

    // Get the listing ID
    const listingIdInput = toggleForm.locator('input[name="id"]');
    if ((await listingIdInput.count()) === 0) {
      console.log('[skip] No id input in toggle form');
      await listPage.close();
      await adminCtx.close();
      test.skip();
      return;
    }

    const listingId = await listingIdInput.inputValue();
    await listPage.close();

    if (!listingId) {
      test.skip();
      return;
    }

    console.log(`[race-test] Testing double-toggle on listing: ${listingId.slice(0, 12)}...`);

    // Open two pages
    const page1 = await adminCtx.newPage();
    const page2 = await adminCtx.newPage();

    await Promise.all([
      page1.goto('/admin-material-listings', { waitUntil: 'networkidle', timeout: 15_000 }),
      page2.goto('/admin-material-listings', { waitUntil: 'networkidle', timeout: 15_000 }),
    ]);

    const findToggleBtn = (page: typeof page1) =>
      page
        .locator('form')
        .filter({
          has: page.locator(`input[name="id"][value="${listingId}"]`),
        })
        .filter({
          has: page.locator('input[name="action"][value="toggle"]'),
        })
        .locator('button[type="submit"]')
        .first();

    const btn1 = findToggleBtn(page1);
    const btn2 = findToggleBtn(page2);

    if ((await btn1.count()) === 0 || (await btn2.count()) === 0) {
      console.log('[skip] Could not find toggle buttons for this listing on both pages');
      await Promise.all([page1.close(), page2.close(), adminCtx.close()]);
      test.skip();
      return;
    }

    // Accept any confirm dialogs
    page1.on('dialog', (d) => d.accept());
    page2.on('dialog', (d) => d.accept());

    // Click both simultaneously
    const [r1, r2] = await Promise.allSettled([
      (async () => {
        const [resp] = await Promise.all([
          page1.waitForNavigation({ timeout: 15_000 }).catch(() => null),
          btn1.click(),
        ]);
        return { url: page1.url(), status: resp?.status() ?? null };
      })(),
      (async () => {
        const [resp] = await Promise.all([
          page2.waitForNavigation({ timeout: 15_000 }).catch(() => null),
          btn2.click(),
        ]);
        return { url: page2.url(), status: resp?.status() ?? null };
      })(),
    ]);

    const succeeded = [r1, r2].filter((r) => r.status === 'fulfilled').length;

    console.log(`[race-result] Double-toggle listing: ${succeeded}/2 completed`);
    console.log('[race-result] Toggle-1:', r1.status === 'fulfilled' ? r1.value : r1);
    console.log('[race-result] Toggle-2:', r2.status === 'fulfilled' ? r2.value : r2);

    // Now check the final state — reload the page and check the listing
    const checkPage = await adminCtx.newPage();
    await checkPage.goto('/admin-material-listings', {
      waitUntil: 'networkidle',
      timeout: 15_000,
    });

    // The listing should exist and have a definite status
    const listingRow = checkPage
      .locator('form')
      .filter({ has: checkPage.locator(`input[name="id"][value="${listingId}"]`) })
      .first();

    const stillExists = (await listingRow.count()) > 0;
    console.log(`[race-result] Listing ${listingId.slice(0, 12)} still visible: ${stillExists}`);

    if (succeeded > 1) {
      // Both toggles went through.  If original was 'active':
      //   - Correct: toggle1 → reserved, toggle2 reads 'reserved' → back to active
      //   - Race: both read 'active' → both write 'reserved' → listing stuck in reserved
      // We can't easily tell from the outside, but we log for investigation.
      console.warn(
        '⚠ POTENTIAL RACE: Both concurrent toggle operations completed.\n' +
        '  If both read the same initial state before either wrote, the\n' +
        '  second toggle was a no-op (same transition applied twice).\n' +
        '  Fix: use updateMany with WHERE validityStatus = <expected>\n' +
        '  and check the count to detect the conflict.'
      );
    }

    await Promise.all([checkPage.close(), page1.close(), page2.close(), adminCtx.close()]);
  });

  test('concurrent toggle + cancel of same listing is a conflicting state change', async ({
    browser,
  }) => {
    const adminCtx = await adminContext(browser);
    const listPage = await adminCtx.newPage();

    await listPage.goto('/admin-material-listings', {
      waitUntil: 'networkidle',
      timeout: 15_000,
    });
    await expect(listPage).not.toHaveURL(/\/login/);

    // Find a listing with both toggle and cancel forms
    const listingForms = listPage.locator('form').filter({
      has: listPage.locator('input[name="action"][value="toggle"]'),
    });

    if ((await listingForms.count()) === 0) {
      await listPage.close();
      await adminCtx.close();
      test.skip();
      return;
    }

    // Get the first listing's ID
    const firstForm = listingForms.first();
    const idInput = firstForm.locator('input[name="id"]');
    const listingId = await idInput.inputValue();
    await listPage.close();

    if (!listingId) {
      test.skip();
      return;
    }

    console.log(`[race-test] Testing toggle+cancel race on listing: ${listingId.slice(0, 12)}...`);

    const page1 = await adminCtx.newPage();
    const page2 = await adminCtx.newPage();

    await Promise.all([
      page1.goto('/admin-material-listings', { waitUntil: 'networkidle', timeout: 15_000 }),
      page2.goto('/admin-material-listings', { waitUntil: 'networkidle', timeout: 15_000 }),
    ]);

    // Page1 → toggle, Page2 → cancel (if a cancel form exists for this listing)
    const toggleBtn = page1
      .locator('form')
      .filter({ has: page1.locator(`input[name="id"][value="${listingId}"]`) })
      .filter({ has: page1.locator('input[name="action"][value="toggle"]') })
      .locator('button[type="submit"]')
      .first();

    const cancelBtn = page2
      .locator('form')
      .filter({ has: page2.locator(`input[name="id"][value="${listingId}"]`) })
      .filter({ has: page2.locator('input[name="action"][value="cancel"]') })
      .locator('button[type="submit"]')
      .first();

    if ((await toggleBtn.count()) === 0 || (await cancelBtn.count()) === 0) {
      console.log('[skip] Could not find both toggle and cancel buttons for this listing');
      await Promise.all([page1.close(), page2.close(), adminCtx.close()]);
      test.skip();
      return;
    }

    page1.on('dialog', (d) => d.accept());
    page2.on('dialog', (d) => d.accept());

    const [r1, r2] = await Promise.allSettled([
      (async () => {
        const [resp] = await Promise.all([
          page1.waitForNavigation({ timeout: 15_000 }).catch(() => null),
          toggleBtn.click(),
        ]);
        return { action: 'toggle', url: page1.url(), status: resp?.status() ?? null };
      })(),
      (async () => {
        const [resp] = await Promise.all([
          page2.waitForNavigation({ timeout: 15_000 }).catch(() => null),
          cancelBtn.click(),
        ]);
        return { action: 'cancel', url: page2.url(), status: resp?.status() ?? null };
      })(),
    ]);

    console.log('[race-result] Toggle+Cancel:');
    console.log('  Toggle:', r1.status === 'fulfilled' ? r1.value : r1);
    console.log('  Cancel:', r2.status === 'fulfilled' ? r2.value : r2);

    const both = [r1, r2].filter((r) => r.status === 'fulfilled').length;
    if (both > 1) {
      console.warn(
        '⚠ RACE DETECTED: Both toggle and cancel succeeded concurrently.\n' +
        '  Final listing status depends on DB execution order.\n' +
        '  Fix: cancel action should also use conditional WHERE clause.'
      );
    }

    await Promise.all([page1.close(), page2.close(), adminCtx.close()]);
  });
});
