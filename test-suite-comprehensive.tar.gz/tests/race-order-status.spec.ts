/**
 * Race-Condition Test — Order Status Transition Races
 *
 * Surfaces in src/app/admin-orders/actions.ts:
 *
 * 1. **Double-reject**: `rejectOrder` guards `status !== 'pending'` then
 *    updates + restores inventory.  Two concurrent rejects both read
 *    status='pending' → both restore inventory → stock inflated.
 *
 * 2. **Price + reject race**: `setOrderPricing` has NO status guard —
 *    an admin can price an order while another admin rejects it.
 *    The order ends up rejected but with stale pricing data.
 *
 * 3. **Double-approve**: `approveOrderAction` guards `status !== 'awaiting_approval'`
 *    then starts proforma deadline.  Two concurrent approves → double proforma
 *    start.
 *
 * 4. **Approve + reject payment receipt**: Both `approvePaymentReceiptAction`
 *    and `rejectPaymentReceiptAction` can run concurrently on the same order.
 *
 * What this test does:
 *   - Finds existing orders in appropriate states and attempts concurrent
 *     conflicting operations on them.
 *   - Uses e2e- prefixed data where applicable.
 *   - Never deletes orders; only reads and attempts state transitions.
 *
 * IMPORTANT: These tests probe the live server's actual behavior.
 * They are designed to DOCUMENT race conditions, not necessarily fail.
 * A race that is exploitable logs a ⚠ warning with a fix suggestion.
 */

import { test, expect } from '@playwright/test';
import { adminContext } from './helpers/race-utils';

// Mutation-safety gate — this spec rejects/approves REAL orders on the live
// server (double-reject restores real inventory twice; double-approve starts
// a real proforma deadline twice).  Skipped by default; opt in explicitly
// with E2E_UNSAFE_RACE_MUTATIONS=1, and only ever on a staging database.
const ALLOW_REAL_RACE_MUTATIONS = !!process.env.E2E_UNSAFE_RACE_MUTATIONS;

test.describe('Race: Order Status Transitions', () => {
  test.skip(
    !ALLOW_REAL_RACE_MUTATIONS,
    'mutates real server records — set E2E_UNSAFE_RACE_MUTATIONS=1 to enable (staging only)'
  );


  test('concurrent reject of same pending order should not double-restore inventory', async ({
    browser,
  }) => {
    const adminCtx = await adminContext(browser);
    const listPage = await adminCtx.newPage();

    await listPage.goto('/admin-orders', { waitUntil: 'networkidle', timeout: 15_000 });
    await expect(listPage).not.toHaveURL(/\/login/);

    // Find a pending order row
    // The admin-orders page renders a table with status badges.
    // Look for a row that contains 'pending' status text
    const pendingRow = listPage.locator('tr').filter({
      has: listPage.locator('td', { hasText: /pending|در انتظار/ }),
    }).first();

    if ((await pendingRow.count()) === 0) {
      console.log('[skip] No pending orders found on /admin-orders — cannot test reject race');
      await listPage.close();
      await adminCtx.close();
      test.skip();
      return;
    }

    // Find the reject form/button for this order.
    // rejectOrder uses formData with 'orderId' — the page likely has a form
    // with a submit button for rejection.
    const rejectForm = pendingRow.locator('form').filter({
      has: listPage.locator('button', { hasText: /رد|reject|لغو/ }),
    }).first();

    if ((await rejectForm.count()) === 0) {
      console.log('[skip] No reject button found in pending order row');
      await listPage.close();
      await adminCtx.close();
      test.skip();
      return;
    }

    // Get the orderId from a hidden input in the form
    const orderIdInput = rejectForm.locator('input[name="orderId"]');
    if ((await orderIdInput.count()) === 0) {
      console.log('[skip] No orderId hidden input in reject form');
      await listPage.close();
      await adminCtx.close();
      test.skip();
      return;
    }

    const orderId = await orderIdInput.inputValue();
    await listPage.close();

    if (!orderId) {
      test.skip();
      return;
    }

    console.log(`[race-test] Testing double-reject on order: ${orderId.slice(0, 8)}...`);

    // Open two pages, both viewing the admin-orders page
    const page1 = await adminCtx.newPage();
    const page2 = await adminCtx.newPage();

    await Promise.all([
      page1.goto('/admin-orders', { waitUntil: 'networkidle', timeout: 15_000 }),
      page2.goto('/admin-orders', { waitUntil: 'networkidle', timeout: 15_000 }),
    ]);

    // Find the reject button for our specific order on both pages
    const findRejectBtn = (page: typeof page1) =>
      page
        .locator('form')
        .filter({ has: page.locator(`input[name="orderId"][value="${orderId}"]`) })
        .locator('button[type="submit"]')
        .first();

    const btn1 = findRejectBtn(page1);
    const btn2 = findRejectBtn(page2);

    if ((await btn1.count()) === 0 || (await btn2.count()) === 0) {
      console.log('[skip] Could not find reject buttons for this order on both pages');
      await Promise.all([page1.close(), page2.close(), adminCtx.close()]);
      test.skip();
      return;
    }

    // Handle confirm dialogs (ConfirmSubmitButton may trigger browser confirm)
    page1.on('dialog', (d) => d.accept());
    page2.on('dialog', (d) => d.accept());

    // Submit both simultaneously
    const [r1, r2] = await Promise.allSettled([
      (async () => {
        const [resp] = await Promise.all([
          page1.waitForNavigation({ timeout: 15_000 }).catch(() => null),
          btn1.click(),
        ]);
        return { url: page1.url(), status: resp?.status() ?? null };
      })(),
      (async () => {
        const [resp] = await Promise.all([
          page2.waitForNavigation({ timeout: 15_000 }).catch(() => null),
          btn2.click(),
        ]);
        return { url: page2.url(), status: resp?.status() ?? null };
      })(),
    ]);

    const succeeded = [r1, r2].filter((r) => r.status === 'fulfilled').length;

    console.log(`[race-result] Double-reject: ${succeeded}/2 completed`);
    console.log('[race-result] Reject-1:', r1.status === 'fulfilled' ? r1.value : r1);
    console.log('[race-result] Reject-2:', r2.status === 'fulfilled' ? r2.value : r2);

    if (succeeded > 1) {
      console.warn(
        '⚠ RACE DETECTED: Both concurrent reject calls succeeded.\n' +
        '  Inventory may have been restored twice (stock inflation).\n' +
        '  Fix: use $transaction with WHERE status = "pending" in the\n' +
        '  order update, or use prisma.order.updateMany with a status\n' +
        '  precondition and check the count before restoring stock.'
      );
    }

    await Promise.all([page1.close(), page2.close(), adminCtx.close()]);
  });

  test('concurrent approve of same awaiting_approval order should not double-start proforma', async ({
    browser,
  }) => {
    const adminCtx = await adminContext(browser);
    const listPage = await adminCtx.newPage();

    await listPage.goto('/admin-orders', { waitUntil: 'networkidle', timeout: 15_000 });
    await expect(listPage).not.toHaveURL(/\/login/);

    // Find an awaiting_approval order
    const awaitingRow = listPage.locator('tr').filter({
      has: listPage.locator('td', { hasText: /awaiting_approval|در انتظار تایید/ }),
    }).first();

    if ((await awaitingRow.count()) === 0) {
      console.log('[skip] No awaiting_approval orders found');
      await listPage.close();
      await adminCtx.close();
      test.skip();
      return;
    }

    // Look for an approve action — approveOrderAction is called with orderId directly
    // The page likely has a button/link that triggers approval
    const approveBtn = awaitingRow.locator('button', { hasText: /تایید|approve/ }).first();

    if ((await approveBtn.count()) === 0) {
      console.log('[skip] No approve button found in awaiting_approval order row');
      await listPage.close();
      await adminCtx.close();
      test.skip();
      return;
    }

    // We need to identify the order to open two pages targeting it
    // Look for any identifier on the row
    const rowText = await awaitingRow.textContent();
    console.log(`[race-test] Found awaiting_approval order row: ${rowText?.slice(0, 80)}...`);

    await listPage.close();

    // Open two pages
    const page1 = await adminCtx.newPage();
    const page2 = await adminCtx.newPage();

    await Promise.all([
      page1.goto('/admin-orders', { waitUntil: 'networkidle', timeout: 15_000 }),
      page2.goto('/admin-orders', { waitUntil: 'networkidle', timeout: 15_000 }),
    ]);

    const findApproveBtn = (page: typeof page1) =>
      page.locator('tr')
        .filter({ has: page.locator('td', { hasText: /awaiting_approval|در انتظار تایید/ }) })
        .first()
        .locator('button', { hasText: /تایید|approve/ })
        .first();

    const btn1 = findApproveBtn(page1);
    const btn2 = findApproveBtn(page2);

    if ((await btn1.count()) === 0 || (await btn2.count()) === 0) {
      await Promise.all([page1.close(), page2.close(), adminCtx.close()]);
      test.skip();
      return;
    }

    page1.on('dialog', (d) => d.accept());
    page2.on('dialog', (d) => d.accept());

    const [r1, r2] = await Promise.allSettled([
      (async () => {
        const [resp] = await Promise.all([
          page1.waitForNavigation({ timeout: 15_000 }).catch(() => null),
          btn1.click(),
        ]);
        return { url: page1.url(), status: resp?.status() ?? null };
      })(),
      (async () => {
        const [resp] = await Promise.all([
          page2.waitForNavigation({ timeout: 15_000 }).catch(() => null),
          btn2.click(),
        ]);
        return { url: page2.url(), status: resp?.status() ?? null };
      })(),
    ]);

    const succeeded = [r1, r2].filter((r) => r.status === 'fulfilled').length;

    console.log(`[race-result] Double-approve order: ${succeeded}/2 completed`);

    if (succeeded > 1) {
      console.warn(
        '⚠ RACE DETECTED: Both concurrent approve calls succeeded.\n' +
        '  startProformaDeadline may have been called twice.\n' +
        '  Fix: conditional update WHERE status = "awaiting_approval".'
      );
    }

    await Promise.all([page1.close(), page2.close(), adminCtx.close()]);
  });
});
