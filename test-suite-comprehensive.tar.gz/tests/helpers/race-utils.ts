/**
 * Shared helpers for race-condition / concurrency e2e tests.
 *
 * Convention:
 *   - All mutation data uses `e2e-` prefix for easy identification.
 *   - Tests never run destructive cleanup (DELETE rows); stale e2e- records
 *     are harmless and can be purged manually if desired.
 *   - Each helper produces a unique tag per invocation so parallel runs
 *     don't collide.
 */

import { type Page, type BrowserContext, type Browser } from '@playwright/test';

// ─── Server URLs ───────────────────────────────────────────────────────────────
export const BUYER_BASE  = 'http://185.164.73.143:3000';
export const ADMIN_BASE  = 'http://185.164.73.143:3001';

// ─── Test accounts ─────────────────────────────────────────────────────────────
export const ADMIN_CREDS  = { username: 'SinaAbouei',  password: '404696417SKj' };
export const BUYER_CREDS  = { username: 'testbuyer',   password: 'Test@1234' };
export const SELLER_CREDS = { username: 'testseller',  password: 'Test@1234' };

// ─── Unique tag generator ──────────────────────────────────────────────────────
let _counter = 0;
export function uniqueTag(prefix = 'e2e'): string {
  return `${prefix}-${Date.now()}-${++_counter}`;
}

// ─── Open an authenticated admin context ───────────────────────────────────────
export async function adminContext(browser: Browser): Promise<BrowserContext> {
  return browser.newContext({
    baseURL: ADMIN_BASE,
    storageState: '.auth/admin.json',
  });
}

// ─── Open an authenticated buyer context ───────────────────────────────────────
export async function buyerContext(browser: Browser): Promise<BrowserContext> {
  return browser.newContext({
    baseURL: BUYER_BASE,
    storageState: '.auth/buyer.json',
  });
}

/**
 * Fire N concurrent requests to the same URL by submitting the same form
 * from N independent pages (all sharing one context → same auth session).
 *
 * Returns an array of { status, url } for each response.
 */
export async function fireParallelFormSubmissions(
  ctx: BrowserContext,
  url: string,
  fillForm: (page: Page) => Promise<void>,
  n: number
): Promise<Array<{ status: number | null; url: string; error?: string }>> {
  const pages = await Promise.all(
    Array.from({ length: n }, () => ctx.newPage())
  );

  // Navigate all pages to the target
  await Promise.all(pages.map((p) => p.goto(url, { waitUntil: 'networkidle' })));

  // Fill all forms (but don't submit yet)
  await Promise.all(pages.map((p) => fillForm(p)));

  // Now submit all simultaneously
  const results = await Promise.allSettled(
    pages.map(async (page) => {
      const [response] = await Promise.all([
        page.waitForNavigation({ timeout: 15_000 }).catch(() => null),
        page.locator('button[type="submit"]').first().click(),
      ]);
      return {
        status: response?.status() ?? null,
        url: page.url(),
      };
    })
  );

  // Cleanup pages
  await Promise.all(pages.map((p) => p.close()));

  return results.map((r) =>
    r.status === 'fulfilled'
      ? r.value
      : { status: null, url: '', error: String((r as PromiseRejectedResult).reason) }
  );
}

/**
 * Fire N concurrent fetches via page.evaluate (for API-route concurrency).
 */
export async function fireParallelFetches(
  page: Page,
  url: string,
  options: RequestInit,
  n: number
): Promise<Array<{ status: number; body: string }>> {
  return page.evaluate(
    async ({ url, options, n }) => {
      const promises = Array.from({ length: n }, () =>
        fetch(url, options).then(async (r) => ({
          status: r.status,
          body: await r.text(),
        }))
      );
      return Promise.all(promises);
    },
    { url, options, n }
  );
}
