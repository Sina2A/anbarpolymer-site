'use server'

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { AccessDeniedError } from '@/lib/errorCodes'
import { revalidatePath } from 'next/cache'

export async function cleanupOldLogsAction() {
  const currentUser = await getCurrentUser()
  if (currentUser.role !== 'admin') {
    throw new AccessDeniedError('A-ROLE-LOGS', 'فقط نقش مدیر مجاز به پاکسازی لاگ‌هاست.')
  }

  const cutoff = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000)
  await prisma.systemLog.deleteMany({ where: { createdAt: { lt: cutoff } } })
  revalidatePath('/admin-logs')
}
