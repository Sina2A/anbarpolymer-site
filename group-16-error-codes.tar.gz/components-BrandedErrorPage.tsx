import { resolveErrorCode } from '@/lib/errorCodes'

interface BrandedErrorPageProps {
  error: Error & { digest?: string }
  reset?: () => void
}

export default function BrandedErrorPage({ error, reset }: BrandedErrorPageProps) {
  const resolved = resolveErrorCode(error)

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: '#faf8f4',
        fontFamily: "'Vazirmatn', Tahoma, sans-serif",
        direction: 'rtl',
        padding: '24px',
      }}
    >
      <div
        style={{
          maxWidth: 500,
          width: '100%',
          background: '#fff',
          border: '1px solid #d8dde3',
          borderRadius: 12,
          padding: '32px 24px',
          textAlign: 'center',
          boxShadow: '0 1px 4px rgba(27,30,36,.05)',
        }}
      >
        {/* آیکون خطا */}
        <div
          style={{
            width: 64,
            height: 64,
            margin: '0 auto 20px',
            borderRadius: '50%',
            background: '#fde8e8',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: 32,
          }}
        >
          ⚠️
        </div>

        {/* پیام اصلی */}
        <h1
          style={{
            fontSize: 18,
            fontWeight: 700,
            color: '#1b1e24',
            marginBottom: 12,
          }}
        >
          {resolved.message}
        </h1>

        {/* کد خطا برای پشتیبانی */}
        {resolved.code && (
          <p
            style={{
              fontSize: 11,
              color: '#9199a3',
              fontFamily: 'monospace',
              marginBottom: 24,
              direction: 'ltr',
            }}
          >
            کد خطا: {resolved.code}
          </p>
        )}

        {/* دکمه‌های اقدام */}
        <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
          {resolved.cta && (
            <a
              href={resolved.cta}
              style={{
                background: '#1e357b',
                color: '#fff',
                border: 'none',
                borderRadius: 8,
                padding: '10px 20px',
                fontSize: 13,
                fontWeight: 700,
                textDecoration: 'none',
                display: 'inline-block',
                cursor: 'pointer',
              }}
            >
              رفتن به صفحه مربوطه
            </a>
          )}

          {reset && (
            <button
              onClick={reset}
              style={{
                background: '#fff',
                color: '#1e357b',
                border: '1px solid #d8dde3',
                borderRadius: 8,
                padding: '10px 20px',
                fontSize: 13,
                fontWeight: 700,
                cursor: 'pointer',
              }}
            >
              تلاش دوباره
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
