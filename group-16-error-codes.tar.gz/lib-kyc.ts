import prisma from './prisma'
import { logAudit } from './logger'
import fs from 'fs/promises'
import path from 'path'
import crypto from 'crypto'

const UPLOAD_ROOT = path.join(process.cwd(), 'public', 'uploads', 'kyc')

/**
 * ذخیره‌ی مدرک روی دیسک محلی سرور — همون الگوی عکس راننده. وقتی حجم بالا رفت
 * و فاز Storage ابری ساخته شد، فقط همین تابع باید عوض بشه.
 */
async function saveDocumentToLocalDisk(userId: string, file: File, prefix: string): Promise<string> {
  const userDir = path.join(UPLOAD_ROOT, userId)
  await fs.mkdir(userDir, { recursive: true })

  const ext = (file.name.split('.').pop() || 'pdf').toLowerCase().replace(/[^a-z0-9]/g, '') || 'pdf'
  const fileName = `${prefix}-${Date.now()}-${crypto.randomBytes(4).toString('hex')}.${ext}`
  const filePath = path.join(userDir, fileName)

  const buffer = Buffer.from(await file.arrayBuffer())
  await fs.writeFile(filePath, buffer)

  return `/uploads/kyc/${userId}/${fileName}`
}

export async function getKycForUser(userId: string) {
  const company = await prisma.company.findUnique({
    where: { userId },
    include: { kyc: true },
  })
  return company
}

/**
 * سطح ۱ — هویت شرکت. طبق تصمیم نهایی: بدون آپلود مدرک — کارشناس با شناسه‌ی
 * ملی، از طریق سامانه‌ی رایگان و رسمی rrk.ir (روزنامه‌ی رسمی کشور) دستی
 * تطبیق می‌ده. اگه Company هنوز نساخته، همینجا می‌سازه.
 */
export async function submitCompanyDocuments(params: {
  userId: string
  companyName: string
  legalType: string
  nationalId: string
  registrationNumber: string
  province: string
  city: string
  address: string
}) {
  const { userId, ...companyData } = params

  const company = await prisma.company.upsert({
    where: { userId },
    update: {
      companyName: companyData.companyName,
      legalType: companyData.legalType,
      nationalId: companyData.nationalId,
      registrationNumber: companyData.registrationNumber,
      province: companyData.province,
      city: companyData.city,
      address: companyData.address,
    },
    create: {
      userId,
      companyName: companyData.companyName,
      legalType: companyData.legalType,
      nationalId: companyData.nationalId,
      registrationNumber: companyData.registrationNumber,
      province: companyData.province,
      city: companyData.city,
      address: companyData.address,
    },
  })

  await prisma.kyc.upsert({
    where: { companyId: company.id },
    update: { level: 1, documentsSubmittedAt: new Date() },
    create: { companyId: company.id, level: 1, documentsSubmittedAt: new Date() },
  })

  return company
}

/** سطح ۲ — احراز تولیدکننده. فقط بعد از سطح ۱ (باید Company از قبل ساخته شده باشه). */
export async function submitProducerLicense(params: {
  userId: string
  productionLicenseNumber: string
  productionLicenseIsSetup: boolean
  factoryAddress: string
  factoryActivityType: string
  factoryProducts: string
  licenseFile: File | null
}) {
  const { userId, licenseFile, ...licenseData } = params

  const company = await prisma.company.findUnique({ where: { userId } })
  if (!company) throw new Error('اول باید مدارک هویتی شرکت (سطح ۱) رو تکمیل کنی.')

  const licenseUrl = licenseFile ? await saveDocumentToLocalDisk(userId, licenseFile, 'license') : undefined

  await prisma.kyc.update({
    where: { companyId: company.id },
    data: {
      productionLicenseNumber: licenseData.productionLicenseNumber,
      productionLicenseIsSetup: licenseData.productionLicenseIsSetup,
      factoryAddress: licenseData.factoryAddress,
      factoryActivityType: licenseData.factoryActivityType,
      factoryProducts: licenseData.factoryProducts,
      productionLicenseFileUrl: licenseUrl,
      producerDocumentsSubmittedAt: new Date(),
      // level رو بالا نمی‌بریم تا کارشناس واقعاً تایید کنه — level=2 یعنی
      // «تایید شده»، نه فقط «مدرک فرستاده شده»
    },
  })
}

/** تصمیم کارشناس/مدیر بعد از تطبیق شناسه‌ی ملی با rrk.ir — تنها جایی که level واقعاً بالا می‌ره. */
export async function reviewKycLevel1(params: { companyId: string; approve: boolean; reviewerId: string; note?: string }) {
  await prisma.kyc.update({
    where: { companyId: params.companyId },
    data: {
      level: params.approve ? 1 : 0,
      badge: params.approve ? 'verified_company' : 'none',
      reviewedById: params.reviewerId,
      reviewedAt: new Date(),
      reviewNote: params.note || null,
    },
  })
  await logAudit('kyc', `سطح ۱ هویت شرکت ${params.companyId.slice(0, 8)} — ${params.approve ? 'تایید' : 'رد'}`, params.reviewerId, { companyId: params.companyId, approve: params.approve, level: params.approve ? 1 : 0 })
}

export async function reviewProducerLicense(params: {
  companyId: string
  approve: boolean
  reviewerId: string
  licenseVerifiedManually: boolean
  note?: string
}) {
  await prisma.kyc.update({
    where: { companyId: params.companyId },
    data: {
      level: params.approve ? 2 : 1,
      badge: params.approve ? 'verified_producer' : 'verified_company',
      producerLicenseVerifiedManually: params.licenseVerifiedManually,
      reviewedById: params.reviewerId,
      reviewedAt: new Date(),
      reviewNote: params.note || null,
    },
  })
  await logAudit('kyc', `احراز تولیدکننده شرکت ${params.companyId.slice(0, 8)} — ${params.approve ? 'تایید' : 'رد'}`, params.reviewerId, { companyId: params.companyId, approve: params.approve, level: params.approve ? 2 : 1 })
}

// ==================== دروازه‌های دسترسی ====================
// این‌ها رو هرجای دیگه‌ی سایت که نیاز به محدودکردن دسترسی بود صدا بزن.
//
// ── سیستم کد خطا (Group 16) ──
// KycRequiredError حالا فیلد code و digest داره تا error.tsx برندشده
// بتونه پیام درست + دکمه‌ی CTA نشون بده.
//   - code:  کد اختصاصی (مثلاً 'U-KYC1-PURCHASEREQ') — برای resolveErrorCode
//   - digest: Next.js این رو تا کلاینت حفظ می‌کنه (فقط digest از سرور به کلاینت می‌رسه)
//
// جایی که code صریح داده نشه (fcallهای existing)، digest = یه کد عمومی
// مثل 'U-KYC1-GENERAL' می‌شه و resolveErrorCode با مچ متنی legacy مدیریتش می‌کنه.

export class KycRequiredError extends Error {
  requiredLevel: number
  currentLevel: number
  code?: string
  digest: string

  constructor(requiredLevel: number, currentLevel: number, code?: string) {
    super(
      requiredLevel === 1
        ? 'برای این بخش، باید اول مدارک هویتی شرکت رو تکمیل و تایید کنی.'
        : 'برای فروش در سیستم، باید احراز تولیدکننده (پروانه بهره‌برداری) تکمیل و تایید بشه.'
    )
    this.name = 'KycRequiredError'
    this.requiredLevel = requiredLevel
    this.currentLevel = currentLevel
    this.code = code
    // digest = code اگه داده شده، وگرنه کد عمومی. Next digest رو تا کلاینت حفظ می‌کنه
    this.digest = code ?? (requiredLevel === 1 ? 'U-KYC1-GENERAL' : 'U-KYC2-GENERAL')
  }
}

/** سطح ۱ — برای بخش‌هایی که فقط هویت شرکت لازم دارن (مثلاً دیدن قیمت دقیق، ارسال RFQ). */
export async function requireCompanyVerified(userId: string) {
  const company = await prisma.company.findUnique({ where: { userId }, include: { kyc: true } })
  const level = company?.kyc?.level ?? 0
  if (level < 1) throw new KycRequiredError(1, level)
}

/** سطح ۲ — فقط برای فروش (ثبت آگهی توی شبکه عرضه). */
export async function requireVerifiedProducer(userId: string) {
  const company = await prisma.company.findUnique({ where: { userId }, include: { kyc: true } })
  const level = company?.kyc?.level ?? 0
  if (level < 2) throw new KycRequiredError(2, level)
}

// ── نسخه‌های parametric با کد اختصاصی (Group 16) ──
// همون logic بالا، ولی کد خطا رو از caller می‌گیره تا error.tsx بتونه
// مسیر درست رو نشون بده. از requireCompanyVerified اصلی کپی شده
// (هر دو prisma query یکیه، abstract نکردیم چون خوانایی مهم‌تره).

/**
 * سطح ۱ — نسخه‌ی parametric.
 * @example await requireCompanyVerifiedFor(user.id, 'U-KYC1-CUSTOMREQ')
 */
export async function requireCompanyVerifiedFor(userId: string, code: string) {
  const company = await prisma.company.findUnique({ where: { userId }, include: { kyc: true } })
  const level = company?.kyc?.level ?? 0
  if (level < 1) throw new KycRequiredError(1, level, code)
}

/**
 * سطح ۲ — نسخه‌ی parametric.
 * @example await requireVerifiedProducerFor(user.id, 'U-KYC2-LISTING')
 */
export async function requireVerifiedProducerFor(userId: string, code: string) {
  const company = await prisma.company.findUnique({ where: { userId }, include: { kyc: true } })
  const level = company?.kyc?.level ?? 0
  if (level < 2) throw new KycRequiredError(2, level, code)
}

/** برای نمایش شرطی توی UI (بدون throw) — مثلاً «آیا دکمه‌ی رزرو رو نشون بدم؟» */
export async function getUserKycLevel(userId: string): Promise<number> {
  const company = await prisma.company.findUnique({ where: { userId }, include: { kyc: true } })
  return company?.kyc?.level ?? 0
}
