'use server'

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { requireCompanyVerifiedFor } from '@/lib/kyc'
import { logAudit } from '@/lib/logger'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'

// ==================== ثبت درخواست خرید ====================

export async function createPurchaseRequestAction(formData: FormData) {
  const user = await getCurrentUser()

  // دروازه‌ی احراز هویت — سطح ۱ (هویت شرکت) کافیه برای خرید
  await requireCompanyVerifiedFor(user.id, 'U-KYC1-PURCHASEREQ')

  const gradeId = String(formData.get('gradeId') || '').trim()
  const quantityTon = parseFloat(String(formData.get('quantityTon') || ''))
  const maxPriceRaw = String(formData.get('maxPriceToman') || '').trim()
  const maxPriceToman = maxPriceRaw ? parseFloat(maxPriceRaw) : null
  const province = String(formData.get('province') || '').trim() || null
  const description = String(formData.get('description') || '').trim() || null
  const expiresInDays = parseInt(String(formData.get('expiresInDays') || '14'), 10)

  if (!gradeId) throw new Error('گرید مشخص نیست.')
  if (!quantityTon || quantityTon <= 0) throw new Error('مقدار درخواستی باید بیشتر از صفر باشه.')
  if (maxPriceToman !== null && maxPriceToman <= 0) throw new Error('سقف قیمت باید بیشتر از صفر باشه.')

  // بررسی وجود گرید
  const grade = await prisma.grade.findUnique({ where: { id: gradeId }, select: { id: true, code: true } })
  if (!grade) throw new Error('گرید انتخاب‌شده وجود نداره.')

  // محاسبه‌ی تاریخ انقضا
  const validDays = expiresInDays > 0 && expiresInDays <= 90 ? expiresInDays : 14
  const expiresAt = new Date(Date.now() + validDays * 24 * 60 * 60 * 1000)

  await prisma.purchaseRequest.create({
    data: {
      userId: user.id,
      gradeId: grade.id,
      quantityTon,
      maxPriceToman,
      province,
      description,
      status: 'open',
      expiresAt,
    },
  })

  await logAudit('purchase-request', `درخواست خرید ${grade.code} — ${quantityTon} تن`, user.id, {
    gradeId: grade.id,
    quantityTon,
    maxPriceToman,
    province,
    expiresInDays: validDays,
  })

  revalidatePath('/purchase-requests')
  revalidatePath('/market')
  redirect('/purchase-requests')
}

// ==================== بستن درخواست توسط خریدار ====================

export async function closePurchaseRequestAction(formData: FormData) {
  const user = await getCurrentUser()

  const requestId = String(formData.get('requestId') || '').trim()
  if (!requestId) throw new Error('شناسه‌ی درخواست مشخص نیست.')

  const pr = await prisma.purchaseRequest.findUnique({ where: { id: requestId } })
  if (!pr) throw new Error('درخواست پیدا نشد.')
  if (pr.userId !== user.id) throw new Error('فقط خودِ خریدار می‌تونه درخواستش رو ببنده.')
  if (pr.status !== 'open') throw new Error('این درخواست قبلاً بسته شده.')

  await prisma.purchaseRequest.update({
    where: { id: requestId },
    data: { status: 'closed' },
  })

  await logAudit('purchase-request', `درخواست خرید ${requestId.slice(0, 8)} بسته شد`, user.id)

  revalidatePath('/purchase-requests')
  revalidatePath('/market')
}
