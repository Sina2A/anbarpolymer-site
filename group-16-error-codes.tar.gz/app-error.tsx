'use client'

import BrandedErrorPage from '@/components/BrandedErrorPage'

export default function Error({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return <BrandedErrorPage error={error} reset={reset} />
}
