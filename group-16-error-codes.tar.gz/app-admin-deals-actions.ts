'use server'

import prisma from '@/lib/prisma'
import { revalidatePath } from 'next/cache'
import { addHoliday, removeHoliday, importHolidaysFromCsv } from '@/lib/holidays'
import { adjustDealDeadline, AdjustableDeadlineField } from '@/lib/deadlineAdjustments'
import { updateDealRuleSettings } from '@/lib/dealDeadlines'
import { getCurrentUser } from '@/lib/currentUser'
import { AccessDeniedError } from '@/lib/errorCodes'
import { logAudit } from '@/lib/logger'
import { redirect } from 'next/navigation'

/**
 * این دو تابع هیچ تراکنش بانکی واقعی انجام نمی‌دن — فقط وضعیتی رو ثبت می‌کنن
 * که تیم حسابداری، بیرون از سایت، بین خودش و بانک انجام داده. طبق تصمیمی که
 * گرفته شد: «سایت قرار نیست به سیستم بانکی وصل بشه، این برای بخش حسابداریه.»
 */
export async function confirmFundsSecured(formData: FormData) {
  const dealId = String(formData.get('dealId'))
  const confirmedById = String(formData.get('confirmedById') || '')

  await prisma.deal.update({
    where: { id: dealId },
    data: {
      escrowStatus: 'secured_manual',
      escrowConfirmedById: confirmedById || null,
      escrowConfirmedAt: new Date(),
      status: 'payment_secured',
    },
  })
  await logAudit('deal', `تایید تامین وجه معامله ${dealId.slice(0, 8)}`, confirmedById || null, { dealId, action: 'funds_secured' })
  revalidatePath('/admin-deals')
}

export async function confirmFundsReleased(formData: FormData) {
  const dealId = String(formData.get('dealId'))
  const confirmedById = String(formData.get('confirmedById') || '')

  await prisma.deal.update({
    where: { id: dealId },
    data: {
      escrowStatus: 'released_manual',
      escrowConfirmedById: confirmedById || null,
      escrowConfirmedAt: new Date(),
      status: 'settled',
    },
  })
  await logAudit('deal', `آزادسازی وجه معامله ${dealId.slice(0, 8)}`, confirmedById || null, { dealId, action: 'funds_released' })
  revalidatePath('/admin-deals')
}

export async function addHolidayAction(formData: FormData) {
  const date = String(formData.get('date') || '')
  const title = String(formData.get('title') || '')
  if (!date) return
  await addHoliday(date, title)
  revalidatePath('/admin-deals')
}

export async function removeHolidayAction(formData: FormData) {
  const id = String(formData.get('id') || '')
  if (!id) return
  await removeHoliday(id)
  revalidatePath('/admin-deals')
}

export async function adjustDeadlineAction(formData: FormData) {
  const dealId = String(formData.get('dealId') || '')
  const field = String(formData.get('field') || '') as AdjustableDeadlineField
  const hours = Number(formData.get('hours'))
  const reason = String(formData.get('reason') || '')
  const adjustedById = String(formData.get('adjustedById') || '')

  if (!dealId || !field || !Number.isFinite(hours) || !adjustedById) return

  await adjustDealDeadline({ dealId, field, hoursDelta: hours, reason, adjustedById })
  revalidatePath('/admin-deals')
}

export async function importHolidaysAction(formData: FormData) {
  const file = formData.get('csvFile') as File | null
  if (!file || file.size === 0) return

  const csvText = await file.text()
  const { addedCount, skippedLines } = await importHolidaysFromCsv(csvText)

  revalidatePath('/admin-deals')
  redirect(`/admin-deals?imported=${addedCount}&skipped=${skippedLines}`)
}

// توجه: تنظیم ساعات کاری هفتگی (upsertWeeklyHourAction) از اینجا به
// src/app/admin-users/actions.ts منتقل شد — چون سینا خواست این تنظیم کنار
// بقیه‌ی مدیریت کاربران/دسترسی‌ها باشه، نه توی صفحه‌ی معاملات.

/**
 * تنظیم طول مهلت‌های معامله — فقط مدیر (چک سمت سرور، مستقل از UI)، چون این
 * روی محاسبه‌ی مهلت مالی همه‌ی معاملات بعدی اثر می‌ذاره.
 */
export async function updateDealRulesAction(formData: FormData) {
  const currentUser = await getCurrentUser()
  if (currentUser.role !== 'admin') {
    throw new AccessDeniedError('A-ROLE-DEALS', 'فقط نقش مدیر مجاز به تغییر قوانین معامله‌ست.')
  }

  const clampInt = (raw: FormDataEntryValue | null, fallback: number) => {
    const n = Math.round(Number(raw))
    if (!Number.isFinite(n) || n < 1) return fallback
    return Math.min(999, n)
  }

  await updateDealRuleSettings(
    {
      sellerFeeHours: clampInt(formData.get('sellerFeeHours'), 24),
      buyerPaymentHours: clampInt(formData.get('buyerPaymentHours'), 72),
      discrepancyReportHours: clampInt(formData.get('discrepancyReportHours'), 4),
      fundReleaseHours: clampInt(formData.get('fundReleaseHours'), 8),
      driverSilenceDays: clampInt(formData.get('driverSilenceDays'), 5),
      proformaConfirmHours: clampInt(formData.get('proformaConfirmHours'), 8),
    },
    currentUser.id
  )
  revalidatePath('/admin-deals')
}

/**
 * دستور پرداختِ اختصاصیِ یک معامله — متن آزادِ کارشناس حسابداری برای خریدار
 * (شماره‌حساب یا پیام «تماس بگیرید»، هر فرمتی). عیناً توی پاپ‌آپ پرداختِ خریدار
 * (DealPaymentModal) بالای گزینه‌ها نشون داده می‌شه. فقط نقش‌های پنل (admin/staff).
 */
export async function updateDealPaymentInstructionsAction(formData: FormData) {
  const currentUser = await getCurrentUser()
  if (currentUser.role !== 'admin' && currentUser.role !== 'staff') {
    throw new AccessDeniedError('A-ROLE-DEALS', 'فقط کاربران پنل (مدیر یا کارشناس) مجاز به ثبت دستور پرداختند.')
  }

  const dealId = String(formData.get('dealId') || '')
  if (!dealId) return
  const text = String(formData.get('paymentInstructionsText') || '').trim()

  await prisma.deal.update({
    where: { id: dealId },
    data: { paymentInstructionsText: text || null },
  })
  await logAudit('deal', `ثبت/ویرایش دستور پرداخت معامله ${dealId.slice(0, 8)}`, currentUser.id, { dealId, action: 'payment_instructions_updated' })
  revalidatePath('/admin-deals')
}
