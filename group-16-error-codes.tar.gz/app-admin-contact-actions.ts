'use server'

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import { AccessDeniedError } from '@/lib/errorCodes'
import { logAudit } from '@/lib/logger'
import { revalidatePath } from 'next/cache'

// گیت دسترسی — فقط مدیر یا کارشناسِ دارای دسترسی بخش «contact» مجازه.
// مدیر روی همه‌چیز دسترسی داره (مثل الگوی صفحات admin-* موجود).
async function requireContactAccess() {
  const user = await getCurrentUser()
  const isAdmin = user.role === 'admin'
  if (!isAdmin) {
    const access = await getAllSectionAccess(user.id)
    const level = access['contact'] ?? 'none'
    if (level === 'none') throw new AccessDeniedError('A-SECTION-CONTACT')
  }
  return { user, isAdmin }
}

// ==================== علامت‌گذاری خوانده‌شده / خوانده‌نشده ====================

export async function toggleReadAction(formData: FormData) {
  const { user } = await requireContactAccess()

  const id = String(formData.get('id') || '').trim()
  const isRead = String(formData.get('isRead')) === '1'

  if (!id) throw new Error('شناسه‌ی پیام مشخص نیست.')

  const message = await prisma.contactMessage.findUnique({ where: { id } })
  if (!message) throw new Error('پیام پیدا نشد.')

  await prisma.contactMessage.update({ where: { id }, data: { isRead } })

  await logAudit('contact', `${isRead ? 'خوانده‌شده' : 'خوانده‌نشده'}: پیام ${id.slice(0, 8)}`, user.id, { id, isRead })

  revalidatePath('/admin-contact')
}

// ==================== بایگانی / خروج از بایگانی ====================

export async function toggleArchiveAction(formData: FormData) {
  const { user } = await requireContactAccess()

  const id = String(formData.get('id') || '').trim()
  const archived = String(formData.get('archived')) === '1'

  if (!id) throw new Error('شناسه‌ی پیام مشخص نیست.')

  const message = await prisma.contactMessage.findUnique({ where: { id } })
  if (!message) throw new Error('پیام پیدا نشد.')

  await prisma.contactMessage.update({ where: { id }, data: { archived } })

  await logAudit('contact', `${archived ? 'بایگانی' : 'خروج از بایگانی'}: پیام ${id.slice(0, 8)}`, user.id, { id, archived })

  revalidatePath('/admin-contact')
}
