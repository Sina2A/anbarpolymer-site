'use client'

import BrandedErrorPage from '@/components/BrandedErrorPage'

export default function GlobalError({ error }: { error: Error & { digest?: string } }) {
  return (
    <html dir="rtl">
      <body>
        <BrandedErrorPage error={error} />
      </body>
    </html>
  )
}
