'use server'

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { AccessDeniedError } from '@/lib/errorCodes'
import { revalidatePath } from 'next/cache'

async function requireAdmin() {
  const user = await getCurrentUser()
  if (user.role !== 'admin') {
    throw new AccessDeniedError(
      'A-ROLE-KYC',
      'این بخش (ویرایش کامل پرونده‌ی احراز هویت) فقط برای نقش مدیره.'
    )
  }
  return user
}

/** بخش «هویت شرکت» — همون فیلدهایی که یا خودِ کاربر پر می‌کنه، یا مدیر دستی اصلاح می‌کنه. */
export async function updateCompanyIdentityAction(formData: FormData) {
  await requireAdmin()
  const companyId = String(formData.get('companyId') || '')

  await prisma.company.update({
    where: { id: companyId },
    data: {
      companyName: String(formData.get('companyName') || ''),
      legalType: String(formData.get('legalType') || ''),
      nationalId: String(formData.get('nationalId') || '') || null,
      registrationNumber: String(formData.get('registrationNumber') || '') || null,
      economicCode: String(formData.get('economicCode') || '') || null,
      taxNumber: String(formData.get('taxNumber') || '') || null,
      province: String(formData.get('province') || '') || null,
      city: String(formData.get('city') || '') || null,
      address: String(formData.get('address') || '') || null,
      postalCode: String(formData.get('postalCode') || '') || null,
      companyPhone: String(formData.get('companyPhone') || '') || null,
      website: String(formData.get('website') || '') || null,
    },
  })

  revalidatePath(`/admin-kyc/${companyId}`)
}

/** بخش «احراز تولیدکننده» — شماره پروانه و اطلاعات کارخانه. */
export async function updateProducerFieldsAction(formData: FormData) {
  await requireAdmin()
  const companyId = String(formData.get('companyId') || '')

  await prisma.kyc.update({
    where: { companyId },
    data: {
      productionLicenseNumber: String(formData.get('productionLicenseNumber') || '') || null,
      productionLicenseIsSetup: formData.get('productionLicenseIsSetup') === 'on',
      factoryAddress: String(formData.get('factoryAddress') || '') || null,
      factoryActivityType: String(formData.get('factoryActivityType') || '') || null,
      factoryProducts: String(formData.get('factoryProducts') || '') || null,
    },
  })

  revalidatePath(`/admin-kyc/${companyId}`)
}

/**
 * بخش «داده‌های استعلام API» — این فیلدها قراره بعداً خودکار از لینکا/api.ir
 * پر بشن؛ چون هنوز هیچ API‌ای وصل نیست، فعلاً مدیر می‌تونه دستی واردشون کنه
 * یا اصلاحشون کنه (مثلاً بعد از یه تماس تلفنی یا استعلام دستی مشابه).
 */
export async function updateApiFieldsAction(formData: FormData) {
  await requireAdmin()
  const companyId = String(formData.get('companyId') || '')

  await prisma.kyc.update({
    where: { companyId },
    data: {
      verificationSource: String(formData.get('verificationSource') || 'manual'),
      apiIntegrationUsed: String(formData.get('apiIntegrationUsed') || '') || null,
      companyManagerMatch: formData.get('companyManagerMatch') === 'true'
        ? true
        : formData.get('companyManagerMatch') === 'false'
        ? false
        : null,
      linkaCompanyName: String(formData.get('linkaCompanyName') || '') || null,
      linkaManagerName: String(formData.get('linkaManagerName') || '') || null,
      linkaCompanyStatus: String(formData.get('linkaCompanyStatus') || '') || null,
    },
  })

  revalidatePath(`/admin-kyc/${companyId}`)
}

/** بخش «نتیجه‌ی نهایی» — سطح و بج، به‌صورت مستقیم (بای‌پس روند عادی تایید/رد). فقط برای اصلاح دستی موارد خاص. */
export async function overrideLevelAction(formData: FormData) {
  const admin = await requireAdmin()
  const companyId = String(formData.get('companyId') || '')
  const level = Math.max(0, Math.min(3, Number(formData.get('level')) || 0))
  const badge = String(formData.get('badge') || 'none')
  const reviewNote = String(formData.get('reviewNote') || '')

  await prisma.kyc.update({
    where: { companyId },
    data: {
      level,
      badge,
      reviewedById: admin.id,
      reviewedAt: new Date(),
      reviewNote: reviewNote || null,
    },
  })

  revalidatePath(`/admin-kyc/${companyId}`)
}
