import CurrencyTicker from '@/components/CurrencyTicker'
import { getSurfaceHome } from '@/lib/surfaceHome'
import PublicHeader from '@/components/PublicHeader'
import { getCurrentUserOrNull } from '@/lib/currentUser'
import { submitContactAction } from './actions'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { pageWrapStyle, inputStyle as sharedInputStyle, badgeStyle } from '@/lib/styles/shared'
import Footer from '@/components/Footer'

export const dynamic = 'force-dynamic'

type SearchParams = Promise<Record<string, string | string[] | undefined>>

function one(v: string | string[] | undefined): string | undefined {
  if (Array.isArray(v)) return v[0]
  return v
}

export default async function ContactPage({ searchParams }: { searchParams: SearchParams }) {
  const sp = await searchParams
  const justSent = one(sp.sent) === '1'
  const user = await getCurrentUserOrNull()

  return (
    <div style={pageStyle}>
      <CurrencyTicker />
      <PublicHeader homeHref={getSurfaceHome()} activePage="/contact" isLoggedIn={!!user} />

      <main style={mainStyle}>
        <div style={heroStyle}>
          <div style={eyebrowStyle}>تماس با ما</div>
          <h1 style={heroTitle}>با انبار پلیمر در ارتباط باشید</h1>
          <p style={heroSub}>
            سوالی درباره‌ی مواد اولیه، قیمت یا همکاری داری؟ از راه‌های زیر با ما در تماس باش، یا فرم را پر کن — همکاران ما پیامت رو می‌بینن و از راهی که گذاشتی جواب می‌دن.
          </p>
        </div>

        {justSent && (
          <div style={successBanner}>
            ✅ پیامت رسید. ممنون! در صورت نیاز از راهی که گذاشتی باهات تماس می‌گیریم.
          </div>
        )}

        <div className="contact-grid">
          <div className="contact-grid__info">
            <div style={infoCardStyle} className="about-hover-card">
              <div style={infoChipStyle}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z" /></svg>
              </div>
              <div style={infoLabelStyle}>تلفن تماس</div>
              <div style={{ ...infoValueStyle, direction: 'ltr', textAlign: 'right' }}>021-91234567</div>
            </div>

            <div style={infoCardStyle} className="about-hover-card">
              <div style={infoChipStyle}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><path d="M3 21h18" /><path d="M5 21V7l8-4v18" /><path d="M19 21V11l-6-4" /><path d="M9 9v.01M9 12v.01M9 15v.01M9 18v.01" /></svg>
              </div>
              <div style={infoLabelStyle}>دفتر مرکزی</div>
              <div style={infoValueStyle}>تهران، خیابان ولیعصر، پلاک ۱۲۴</div>
            </div>

            <div style={infoCardStyle} className="about-hover-card">
              <div style={infoChipStyle}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><path d="M3 9l9-6 9 6v11a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z" /><path d="M9 21v-8h6v8" /></svg>
              </div>
              <div style={infoLabelStyle}>انبار</div>
              <div style={infoValueStyle}>انبار یزد — شهرک صنعتی یزد</div>
            </div>
          </div>

          <section style={formCardStyle}>
            <form action={submitContactAction}>
              <div style={{ marginBottom: 14 }}>
                <div style={labelStyle}>نام و نام خانوادگی</div>
                <input name="name" required maxLength={80} placeholder="مثلاً: علی رضایی"
                  style={inputStyle} />
              </div>
              <div style={{ marginBottom: 14 }}>
                <div style={labelStyle}>راه تماس <span style={hintInline}>(ایمیل یا شماره موبایل)</span></div>
                <input name="contact" required maxLength={120} placeholder="example@mail.com یا 09121234567"
                  style={{ ...inputStyle, direction: 'ltr', textAlign: 'left' }} />
              </div>
              <div style={{ marginBottom: 16 }}>
                <div style={labelStyle}>متن پیام</div>
                <textarea name="body" rows={6} required maxLength={2000} placeholder="سوال یا پیامت رو اینجا بنویس…"
                  style={{ ...inputStyle, resize: 'vertical' }} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
                <span style={hintStyle}>نیازی به ثبت‌نام نیست — پیامت مستقیم به تیم ما می‌رسه.</span>
                <button type="submit" style={submitBtnStyle}>ارسال پیام</button>
              </div>
            </form>
          </section>
        </div>
      </main>

      <Footer homeHref={getSurfaceHome()} />
    </div>
  )
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: colors.bgPage,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
  display: 'flex',
  flexDirection: 'column',
}
const mainStyle: React.CSSProperties = {
  ...pageWrapStyle,
  padding: '32px 24px',
  flex: 1,
  boxSizing: 'border-box',
}
const heroStyle: React.CSSProperties = {
  marginBottom: 28,
}
const heroTitle: React.CSSProperties = {
  fontSize: fontSize.xl,
  fontWeight: 800,
  color: colors.textPrimary,
  marginBottom: spacing.sm,
}
const heroSub: React.CSSProperties = {
  fontSize: fontSize.base,
  color: colors.textSecondary,
  lineHeight: 1.7,
}
const successBanner: React.CSSProperties = {
  ...badgeStyle('success'),
  borderRadius: radius.md,
  padding: '12px 16px',
  fontSize: fontSize.base,
  fontWeight: 600,
  marginBottom: 18,
}
const formCardStyle: React.CSSProperties = {
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
  padding: spacing.xl,
  background: colors.bgCard,
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
  maxWidth: 640,
}
const labelStyle: React.CSSProperties = {
  fontSize: fontSize.sm,
  fontWeight: 700,
  color: colors.neutralText,
  marginBottom: 5,
}
const hintInline: React.CSSProperties = {
  fontWeight: 400,
  color: colors.textMuted,
  fontSize: fontSize.xs,
}
const inputStyle: React.CSSProperties = {
  ...sharedInputStyle,
  width: '100%',
  boxSizing: 'border-box',
}
const hintStyle: React.CSSProperties = {
  fontSize: fontSize.xs,
  color: colors.textMuted,
}
const submitBtnStyle: React.CSSProperties = {
  background: colors.navy,
  color: '#fff',
  border: 'none',
  borderRadius: radius.md,
  padding: '10px 28px',
  fontSize: fontSize.base,
  fontWeight: 700,
  cursor: 'pointer',
  fontFamily: 'inherit',
}
const eyebrowStyle: React.CSSProperties = {
  fontSize: 11,
  fontWeight: 700,
  letterSpacing: '0.06em',
  color: colors.orange,
  marginBottom: 8,
}
const infoCardStyle: React.CSSProperties = {
  border: `1px solid ${colors.borderSubtle}`,
  borderRight: `4px solid ${colors.orange}`,
  borderRadius: 14,
  padding: '18px 18px',
  background: colors.bgCard,
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const infoChipStyle: React.CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  width: 34,
  height: 34,
  borderRadius: 8,
  background: colors.orangeBg,
  color: colors.orange,
  marginBottom: 12,
}
const infoLabelStyle: React.CSSProperties = {
  fontSize: 11.5,
  fontWeight: 700,
  color: colors.textMuted,
  marginBottom: 4,
}
const infoValueStyle: React.CSSProperties = {
  fontSize: fontSize.md,
  fontWeight: 700,
  color: colors.textPrimary,
  lineHeight: 1.7,
}
