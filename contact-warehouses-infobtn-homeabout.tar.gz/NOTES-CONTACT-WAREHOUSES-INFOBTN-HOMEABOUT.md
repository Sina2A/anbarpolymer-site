# بازطراحی /contact و /warehouses + رفع دکمه‌ی «ⓘ» + بخش «درباره ما» موبایلِ هوم — NOTES

## خلاصه
اَبرتسک چهار-بخشی، همه با پالت رسمی (`tokens.ts`) و زبان بصری خودِ سایت. بدون داده‌ی جعلی، بدون وابستگی جدید، بدون تغییر دسکتاپِ هوم.

## فایل‌های تغییریافته
- **ویرایش:** `src/app/contact/page.tsx` — بازنویسی `main` به دو‌ستونه + کارت‌های اطلاعات تماس سبک about؛ حذف کانست‌های مرده‌ی فوتر.
- **ویرایش:** `src/app/warehouses/page.tsx` — هیرو آماری + صیقلِ کارت‌ها؛ منطق مهمان دست‌نخورده.
- **ویرایش:** `src/app/warehouses/[id]/page.tsx` — گلیف «ⓘ» → حرف «i» + سخت‌سازی `infoBtnStyle`.
- **ویرایش:** `src/app/page.tsx` — درج `<section className="home-about-mobile">` بعد از `home-cta-wrap` (آخرین بخش `main`).
- **ویرایش:** `src/app/globals.css` — افزودن `.contact-grid` و `.home-about-mobile`/`.home-about-*` با سوییچ ۸۹۹px (بعد از بلوک ریسپانسیوِ هوم، قبل از بلوک ناوبری موبایل).

## بخش ۱ — `/contact`
- هدر سکشن سبک about: eyebrow «تماس با ما» → عنوان «با انبار پلیمر در ارتباط باشید» → هینت.
- گرید `.contact-grid`: دسکتاپ `340px 1fr` (کارت‌ها کنار فرم)؛ زیر ۸۹۹px تک‌ستون و کارت‌ها بالای فرم (`.contact-grid__info{order:-1}`).
- سه کارتِ لبه‌نارنجی (`borderRight:4px solid orange` + کلاس سراسری `about-hover-card`)، **فقط داده‌ی واقعیِ فوتر**: تلفن `021-91234567` (`direction:ltr`) · دفتر مرکزی «تهران، خیابان ولیعصر، پلاک ۱۲۴» · انبار «انبار یزد — شهرک صنعتی یزد». ساعت کاری/ایمیل در کدبیس نبود → ساخته نشد.
- فرم و `submitContactAction` و بنر `?sent=1` دست‌نخورده. کانست‌های مرده‌ی فوتر (`footerStyle/footerInner/footerLinks/footerLink/dot`) حذف شدند.

## ~۳۰٪ زبان بصری مشترک با /about
دو الگو عیناً از about تکرار شد: (۱) هدر سکشن eyebrow نارنجی→عنوان→هینت؛ (۲) کارتِ لبه‌نارنجی + چیپ مربعیِ `orangeBg`/`orange` + `about-hover-card`. اشتراک از راه یکسانیِ استایل است، نه import — به about دست زده نشد.

## بخش ۱ — `/warehouses` (منطق مهمان تأییداً دست‌نخورده)
- هیرو آماری: eyebrow + سه چیپ آمار واقعیِ DB — `warehouses.length` انبار فعال · `cityCount` شهر (`new Set(map(w=>w.city)).size`) · `withLocation.length` روی نقشه؛ `flexWrap:wrap` برای موبایل.
- کارت‌ها: لبه‌ی نارنجی + `about-hover-card`.
- **حفظ کلمه‌به‌کلمه (هر دو breakpoint):** `href={user ? `/warehouses/${w.id}` : '/login'}` و متن شرطیِ CTA (`user ? 'مشاهده‌ی موجودی این انبار ←' : 'برای مشاهده موجودی این انبار به حساب کاربری خود وارد شوید.'`). سکشن نقشه (`WarehousesMap`) عیناً حفظ.

## بخش ۲ — دکمه‌ی «ⓘ»
علت: محتوای خام کاراکترِ یونیکد «ⓘ» (U+24D8) بود که فونت سایت شش‌ضلعی/نامرکز رندر می‌کرد؛ رَپر (`infoBtnStyle`) از قبل دایره‌ی درست بود. رفع: محتوا → حرف ساده‌ی «i» + `aria-label="مشاهده‌ی مشخصات فنی گرید"`؛ به `infoBtnStyle` افزوده شد `fontStyle:'normal'`، `fontFamily:'Arial, Helvetica, sans-serif'`، `lineHeight:1`. دایره‌ی ۳۰×۳۰ با `borderRadius:999` و مرکزچینیِ flex حفظ. لینک `/grades/{code}` دست‌نخورده.

## بخش ۳ — «درباره ما» موبایلِ هوم (فقط زیر ۸۹۹px)
- `<section className="home-about-mobile">` دقیقاً بعد از `home-cta-wrap` و قبل از `</main>` (آخرین بخش صفحه).
- محتوا **فقط از /about واقعی**: eyebrow «درباره انبار پلیمر» + عنوان «درباره ما» + پاراگراف واقعیِ about (عیناً) + دکمه «درباره‌ی ما بیشتر بدانید ←» → `/about` (کلاس موجود `home-btn-primary`).
- استایل با هگزِ `home-*` هماهنگ (کارت `#fff`، حاشیه `#E4E7EC`، eyebrow `#E65716`، عنوان `#172033`).
- سوییچ: `.home-about-mobile{display:none}` پیش‌فرض → `@media (max-width:899px)` می‌شود `display:block`. **دسکتاپ (≥۹۰۰px) صفر تغییر.**

## تأیید
- `npx tsc --noEmit` — EXIT 0 (صفر خطا؛ حذفِ کانست‌های مرده هم بدون مرجعِ باقی‌مانده تأیید شد).
- `npx next build` — EXIT 0 (همه‌ی مسیرها از جمله `/contact`, `/warehouses`, `/warehouses/[id]`, `/` کامپایل شدند).

## نصب روی سرور
از ریشه‌ی `anbarpolymer-app` روی سرور، فایل‌ها را با ساختار مسیرِ داخل tar استخراج کن (۵ فایل با مسیرِ ریپو-نسبی)، سپس:
```bash
npm run build
# ری‌استارت سرویس طبق روال (pm2/systemd)
```
هیچ مهاجرت دیتابیس یا وابستگی جدیدی لازم نیست.
