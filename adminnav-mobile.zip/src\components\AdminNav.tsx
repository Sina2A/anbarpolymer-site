'use client'

import { SECTION_KEYS, AccessLevel } from '@/lib/sections'

/**
 * ناوبری پنل ادمین که بر اساس دسترسی کاربر رنگ می‌گیره:
 * - دسترسی کامل یا مدیر → لینک عادی
 * - دسترسی جزئی (فقط مشاهده یا فقط ویرایش) → لینک عادی، ولی خودِ صفحه باید بنر هشدار نشون بده
 * - بدون دسترسی → قرمز و غیرقابل‌کلیک (span، نه a — تا حتی href هم توی DOM نباشه)
 *
 * لینک پنل دیپلوی فقط برای role==='admin' رندر می‌شه — برای بقیه، این آیتم اصلاً
 * توی HTML خروجی وجود نداره (نه فقط مخفی با CSS)، چون این یه Server Component است
 * و شرط را قبل از رندر شدن هرگونه HTML چک می‌کنه.
 * چیدمان واکنش‌گرا:
 * روی دسکتاپ یک ستون ثابت ۲۳۰ پیکسلی کنار محتواست. روی موبایل (زیر ۹۰۰px)
 * تبدیل به دراپ‌داون می‌شه که پیش‌فرض بسته‌ست — قبلاً نصف عرض صفحه رو می‌گرفت.
 * از <details> استفاده شده نه state، چون:
 *   ۱. بدون جاوااسکریپت هم کار می‌کنه،
 *   ۲. با CSS محضِ globals.css می‌شه روی دسکتاپ همیشه‌باز نگهش داشت
 *      (details[open] رفتار پیش‌فرض + مخفی‌کردن summary)،
 *   ۳. دسترس‌پذیری (کیبورد و screen reader) رایگان به‌دست میاد.
 */
export default function AdminNav({
  currentUserName,
  isAdmin,
  accessMap,
  activeSection,
}: {
  currentUserName: string
  isAdmin: boolean
  accessMap: Record<string, AccessLevel>
  activeSection?: string
}) {
  // عنوانِ بخش فعال رو روی دکمه‌ی دراپ‌داون نشون می‌دیم تا کاربر موبایل
  // بدون بازکردن منو بدونه کجاست.
  const activeLabel =
    activeSection === 'tasks'
      ? 'کارهای منتظر من'
      : SECTION_KEYS.find((s) => s.key === activeSection)?.label ?? 'منوی پنل'

  return (
    <details className="admin-nav" open>
      <summary className="admin-nav-toggle">
        <span>☰ {activeLabel}</span>
        <span className="admin-nav-caret">▾</span>
      </summary>

      <div style={userBoxStyle}>
        <div style={{ fontSize: 13, fontWeight: 700 }}>{currentUserName}</div>
        <div style={{ fontSize: 11, color: '#9199a3' }}>{isAdmin ? 'مدیر' : 'کارشناس'}</div>
      </div>

      <nav style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {/* «کارهای منتظر من» یه بخش قابل‌گرنت‌شدن نیست، صرفاً صف شخصی خودِ کاربره — همیشه در دسترسه */}
        <a href="/my-tasks" style={{ ...linkStyle, ...(activeSection === 'tasks' ? activeLinkStyle : {}) }}>
          کارهای منتظر من
        </a>
        <div style={{ ...dividerStyle, margin: '6px 0' }} />
        {SECTION_KEYS.map((sec) => {
          const level: AccessLevel = isAdmin ? 'full' : accessMap[sec.key] ?? 'none'
          const active = sec.key === activeSection

          if (!sec.isReal) {
            return (
              <span key={sec.key} style={{ ...linkStyle, color: '#9199a3', cursor: 'default' }} title="هنوز صفحه‌ی این بخش ساخته نشده">
                {sec.label}
                <span style={comingSoonTag}>به‌زودی</span>
              </span>
            )
          }

          if (level === 'none') {
            return (
              <span key={sec.key} style={{ ...linkStyle, color: '#dc2626', cursor: 'not-allowed', opacity: 0.65 }} title="دسترسی نداری">
                {sec.label}
              </span>
            )
          }

          return (
            <a key={sec.key} href={sec.href} style={{ ...linkStyle, ...(active ? activeLinkStyle : {}) }}>
              {sec.label}
              {level !== 'full' && <span style={partialTag}>{level === 'view' ? 'فقط مشاهده' : 'فقط ویرایش'}</span>}
            </a>
          )
        })}
      </nav>

      {isAdmin && (
        <>
          <div style={dividerStyle} />
          <a
            href="#"
            style={{ ...linkStyle, color: '#f59e0b', fontWeight: 700 }}
            onClick={(e) => {
              e.preventDefault()
              window.open('http://' + window.location.hostname + ':4000', '_blank')
            }}
          >
            پنل دیپلوی (مدیریت سرور) ↗
          </a>
        </>
      )}
    </details>
  )
}

/**
 * برای بالای صفحه‌ی هر بخشی که کاربر فقط دسترسی جزئی (نه کامل) بهش داره.
 * وزن فونت عمدا Medium/Normal است، نه Bold — طبق درخواست، این یک اخطار ملایمه، نه یک هشدار قرمز تهاجمی.
 */
export function PartialAccessBanner({ level, sectionLabel }: { level: AccessLevel; sectionLabel: string }) {
  if (level !== 'view' && level !== 'edit') return null
  const text =
    level === 'view'
      ? `شما فقط به «${sectionLabel}» دسترسی مشاهده دارید — نمی‌توانید تغییری اعمال کنید.`
      : `شما فقط دسترسی ویرایش «${sectionLabel}» را دارید.`
  return (
    <div
      style={{
        background: '#fef3c7',
        color: '#92400e',
        borderRadius: 8,
        padding: '10px 16px',
        fontSize: 13,
        fontWeight: 500,
        marginBottom: 20,
      }}
    >
      {text}
    </div>
  )
}

// ظاهرِ خودِ قاب منو (عرض، حاشیه، پس‌زمینه) به کلاس .admin-nav در globals.css
// منتقل شده — چون باید در بریک‌پوینت موبایل override بشه و media query در
// استایل inline کار نمی‌کنه.
const userBoxStyle: React.CSSProperties = { paddingBottom: 12, marginBottom: 10, borderBottom: '1px solid #eceff3' }
const linkStyle: React.CSSProperties = { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '9px 8px', borderRadius: 6, fontSize: 13, color: '#4f5560', textDecoration: 'none' }
const activeLinkStyle: React.CSSProperties = { background: '#fff4ee', color: '#e65716', fontWeight: 700 }
const partialTag: React.CSSProperties = { fontSize: 9.5, fontFamily: 'monospace', background: '#fef3c7', color: '#92400e', borderRadius: 4, padding: '1px 6px' }
const comingSoonTag: React.CSSProperties = { fontSize: 9.5, fontFamily: 'monospace', background: '#f1efe8', color: '#9199a3', borderRadius: 4, padding: '1px 6px' }
const dividerStyle: React.CSSProperties = { height: 1, background: '#eceff3', margin: '10px 0' }
