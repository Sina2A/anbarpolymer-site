import { getCurrentUser } from '@/lib/currentUser'
import { createWaterfallRuleAction } from '../../actions'

export const dynamic = 'force-dynamic'

export default async function NewWaterfallPage() {
  await getCurrentUser()

  return (
    <div style={pageStyle}>
      <div style={{ maxWidth: 800, margin: '0 auto' }}>
        <a href="/admin-pricing?tab=waterfall" style={backLink}>← بازگشت</a>
        <h1 style={h1Style}>افزودن قانون آبشار</h1>

        <form action={createWaterfallRuleAction} style={formCard}>
          <div style={fieldGroup}>
            <label style={labelStyle}>اولویت (عدد کوچکتر = اولویت بالاتر)</label>
            <input type="number" name="priority" style={inputStyle} defaultValue="0" />
          </div>

          <div style={fieldGroup}>
            <label style={labelStyle}>نوع شرط <span style={{ color: '#9b1c1c' }}>*</span></label>
            <select name="conditionType" required style={inputStyle}>
              <option value="price_range">محدوده قیمت</option>
              <option value="grade_category">دسته گرید</option>
              <option value="specific_grade">گرید خاص</option>
            </select>
          </div>

          <div style={fieldGroup}>
            <label style={labelStyle}>مقدار شرط <span style={{ color: '#9b1c1c' }}>*</span></label>
            <input type="text" name="conditionValue" required style={inputStyle} placeholder="مثلاً: 1000000-5000000" />
          </div>

          <div style={fieldGroup}>
            <label style={labelStyle}>نوع تنظیم <span style={{ color: '#9b1c1c' }}>*</span></label>
            <select name="adjustmentType" required style={inputStyle}>
              <option value="percentage">درصد</option>
              <option value="fixed">مبلغ ثابت</option>
            </select>
          </div>

          <div style={fieldGroup}>
            <label style={labelStyle}>مقدار تنظیم <span style={{ color: '#9b1c1c' }}>*</span></label>
            <input type="number" step="0.01" name="adjustmentValue" required style={inputStyle} placeholder="مثلاً: -2.5 یا 50000" />
          </div>

          <div style={fieldGroup}>
            <label style={{ fontSize: 13 }}><input type="checkbox" name="isActive" defaultChecked /> فعال</label>
          </div>

          <button type="submit" style={btnStyle}>ذخیره قانون</button>
        </form>
      </div>
    </div>
  )
}

const pageStyle = { minHeight: '100vh', background: '#faf8f4', padding: '32px 20px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl' as const }
const backLink = { fontSize: 12.5, color: '#1e357b', textDecoration: 'none', display: 'inline-block', marginBottom: 16 }
const h1Style = { fontSize: 20, fontWeight: 800, marginBottom: 24 }
const formCard = { background: '#fff', border: '1px solid #d8dde3', borderRadius: 12, padding: 24 }
const fieldGroup = { marginBottom: 18 }
const labelStyle = { display: 'block', fontSize: 12.5, fontWeight: 600, marginBottom: 6 }
const inputStyle = { width: '100%', border: '1px solid #d8dde3', borderRadius: 8, padding: '9px 12px', fontSize: 13, fontFamily: 'inherit' }
const btnStyle = { background: '#1e357b', color: '#fff', border: 'none', borderRadius: 8, padding: '11px 24px', fontSize: 13, fontWeight: 700, cursor: 'pointer', width: '100%' }
