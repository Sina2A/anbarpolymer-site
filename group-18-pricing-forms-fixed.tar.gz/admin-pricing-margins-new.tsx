import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { createMarginGuidanceAction } from '../../actions'

export const dynamic = 'force-dynamic'

export default async function NewMarginPage() {
  await getCurrentUser()
  const gradesWithoutMargin = await prisma.grade.findMany({
    where: { isActive: true, marginGuidance: null },
    orderBy: { code: 'asc' },
  })

  return (
    <div style={pageStyle}>
      <div style={{ maxWidth: 800, margin: '0 auto' }}>
        <a href="/admin-pricing?tab=margins" style={backLink}>← بازگشت</a>
        <h1 style={h1Style}>افزودن سطوح حاشیه</h1>

        <form action={createMarginGuidanceAction} style={formCard}>
          <div style={fieldGroup}>
            <label style={labelStyle}>گرید <span style={{ color: '#9b1c1c' }}>*</span></label>
            <select name="gradeId" required style={inputStyle}>
              <option value="">انتخاب کنید</option>
              {gradesWithoutMargin.map(g => <option key={g.id} value={g.id}>{g.code}</option>)}
            </select>
          </div>

          <div style={fieldGroup}>
            <label style={labelStyle}>Floor (%) <span style={{ color: '#9b1c1c' }}>*</span></label>
            <input type="number" step="0.01" name="floorPercent" required style={inputStyle} />
          </div>

          <div style={fieldGroup}>
            <label style={labelStyle}>Target (%) <span style={{ color: '#9b1c1c' }}>*</span></label>
            <input type="number" step="0.01" name="targetPercent" required style={inputStyle} />
          </div>

          <div style={fieldGroup}>
            <label style={labelStyle}>Stretch (%) <span style={{ color: '#9b1c1c' }}>*</span></label>
            <input type="number" step="0.01" name="stretchPercent" required style={inputStyle} />
          </div>

          <div style={fieldGroup}>
            <label style={{ fontSize: 13 }}><input type="checkbox" name="isActive" defaultChecked /> فعال</label>
          </div>

          <button type="submit" style={btnStyle}>ذخیره سطوح</button>
        </form>
      </div>
    </div>
  )
}

const pageStyle = { minHeight: '100vh', background: '#faf8f4', padding: '32px 20px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl' as const }
const backLink = { fontSize: 12.5, color: '#1e357b', textDecoration: 'none', display: 'inline-block', marginBottom: 16 }
const h1Style = { fontSize: 20, fontWeight: 800, marginBottom: 24 }
const formCard = { background: '#fff', border: '1px solid #d8dde3', borderRadius: 12, padding: 24 }
const fieldGroup = { marginBottom: 18 }
const labelStyle = { display: 'block', fontSize: 12.5, fontWeight: 600, marginBottom: 6 }
const inputStyle = { width: '100%', border: '1px solid #d8dde3', borderRadius: 8, padding: '9px 12px', fontSize: 13, fontFamily: 'inherit' }
const btnStyle = { background: '#1e357b', color: '#fff', border: 'none', borderRadius: 8, padding: '11px 24px', fontSize: 13, fontWeight: 700, cursor: 'pointer', width: '100%' }
