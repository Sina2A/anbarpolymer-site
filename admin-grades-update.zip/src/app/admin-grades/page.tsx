import prisma from '@/lib/prisma'
import { getAllSectionAccess } from '@/lib/permissions'
import { getCurrentUser } from '@/lib/currentUser'
import { createGradeAction, updateGradeAction, toggleGradeActiveAction } from './actions'
import AdminNav, { PartialAccessBanner } from '@/components/AdminNav'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'

export const dynamic = 'force-dynamic'

const CATEGORY_OPTIONS = ['پلی‌پروپیلن', 'پلی‌اتیلن', 'پی‌وی‌سی', 'پلی‌اتیلن ترفتالات', 'پلی‌استایرن', 'ABS', 'پلی‌استایرن انبساطی', 'سایر']
const POLYMER_FAMILY_OPTIONS = ['PP', 'HDPE', 'LDPE', 'LLDPE', 'PVC', 'PET', 'PS', 'EPS', 'ABS', 'سایر']
const APPLICATION_OPTIONS = ['تزریقی (Injection)', 'اکستروژن (Extrusion)', 'بادی (Blow Molding)', 'فیلم (Film)', 'الیاف/رشته‌ای (Fiber/Raffia)', 'لوله (Pipe)', 'مستربچ (Masterbatch)', 'سایر']

export default async function AdminGradesPage() {
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)
  const access = isAdmin ? 'full' : myAccess?.grades ?? 'none'

  if (access === 'none') {
    return (
      <div style={{ display: 'flex', gap: 24, padding: '32px 24px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', maxWidth: 1100, margin: '0 auto' }}>
        <AdminNav currentUserName={currentUser.companyName} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="grades" />
        <div style={{ flex: 1 }}>دسترسی به این بخش نداری — از مدیر بخواه دسترسیت رو تنظیم کنه.</div>
      </div>
    )
  }

  const canEdit = access === 'edit' || access === 'full'

  const grades = await prisma.grade.findMany({
    orderBy: [{ isActive: 'desc' }, { producer: 'asc' }, { code: 'asc' }],
    include: { _count: { select: { materialListings: true, orderItems: true } } },
  })

  return (
    <div style={{ display: 'flex', gap: 24, padding: '32px 24px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', maxWidth: 1200, margin: '0 auto' }}>
      <AdminNav currentUserName={currentUser.companyName} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="grades" />

      <div style={{ flex: 1, minWidth: 0 }}>
        <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 8 }}>مدیریت گریدها و مشخصات فنی</h1>
        <p style={{ color: '#6f7680', fontSize: 13.5, marginBottom: 20, lineHeight: 1.9 }}>
          این کاتالوگ داخلی سایته — وقتی فروشنده آگهی ثبت می‌کنه یا خریدار سفارش می‌ده، اسم محصول از همین لیست انتخاب می‌شه،
          نه با تایپ آزاد. مجموعاً {grades.length} گرید ثبت شده.
        </p>
        {access !== 'full' && <PartialAccessBanner level={access} sectionLabel="مدیریت گریدها" />}

        {canEdit && (
          <div style={cardStyle}>
            <h3 style={{ fontSize: 15, marginBottom: 14 }}>افزودن گرید جدید</h3>
            <form action={createGradeAction} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <input name="code" placeholder="کد گرید (مثلاً PP H110MA) *" required style={inputStyle} />
              <input name="producer" placeholder="تولیدکننده *" required style={inputStyle} />

              <select name="category" required style={inputStyle} defaultValue="">
                <option value="" disabled>نوع ماده (دسته‌ی نمایشی) *</option>
                {CATEGORY_OPTIONS.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
              <select name="polymerFamily" style={inputStyle} defaultValue="">
                <option value="">خانواده‌ی پلیمر (فنی، اختیاری)</option>
                {POLYMER_FAMILY_OPTIONS.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>

              <select name="applicationType" style={inputStyle} defaultValue="">
                <option value="">نوع کاربرد (اختیاری)</option>
                {APPLICATION_OPTIONS.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
              <select name="originCountry" style={inputStyle} defaultValue="IR">
                <option value="IR">تولید داخلی (ایران)</option>
                <option value="foreign">وارداتی (خارجی)</option>
              </select>

              <input name="mfi" type="number" step="0.01" placeholder="MFI — شاخص جریان ذوب (g/10min)" style={inputStyle} />
              <input name="mfiTestCondition" placeholder="شرط تست MFI (مثلاً 230°C/2.16kg)" style={inputStyle} />

              <input name="density" type="number" step="0.001" placeholder="دانسیته (g/cm³)" style={inputStyle} />
              <input name="packagingType" placeholder="نوع بسته‌بندی (مثلاً کیسه ۲۵کیلویی)" style={inputStyle} />

              <textarea name="description" placeholder="توضیحات آزاد (کاربرد خاص، نکات فنی، و غیره)" rows={2} style={{ ...inputStyle, gridColumn: '1 / -1', fontFamily: 'inherit', resize: 'vertical' }} />

              <button type="submit" style={{ ...btnStyle, gridColumn: '1 / -1' }}>افزودن گرید</button>
            </form>
          </div>
        )}

        <div style={{ border: '1px solid #d8dde3', borderRadius: 12, overflow: 'hidden' }}>
          <table style={{ width: '100%', fontSize: 12.5, borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: '#f7f8fa', color: '#6f7680', textAlign: 'right' }}>
                <th style={thStyle}>کد گرید</th>
                <th style={thStyle}>تولیدکننده</th>
                <th style={thStyle}>نوع ماده</th>
                <th style={thStyle}>MFI</th>
                <th style={thStyle}>دانسیته</th>
                <th style={thStyle}>منشا</th>
                <th style={thStyle}>استفاده‌شده در</th>
                <th style={thStyle}>وضعیت</th>
                {canEdit && <th style={thStyle}></th>}
              </tr>
            </thead>
            <tbody>
              {grades.length === 0 ? (
                <tr><td colSpan={9} style={{ ...tdStyle, textAlign: 'center', color: '#9199a3', padding: 24 }}>هنوز هیچ گریدی ثبت نشده.</td></tr>
              ) : grades.map((g) => (
                <GradeRow key={g.id} grade={g} canEdit={canEdit} />
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

function GradeRow({ grade: g, canEdit }: { grade: any; canEdit: boolean }) {
  const usageCount = g._count.materialListings + g._count.orderItems
  return (
    <tr style={{ borderTop: '1px solid #eceff3', opacity: g.isActive ? 1 : 0.5 }}>
      <td style={{ ...tdStyle, fontFamily: 'monospace', fontWeight: 700 }}>{g.code}</td>
      <td style={tdStyle}>{g.producer}</td>
      <td style={tdStyle}>{g.category}{g.polymerFamily && <span style={{ color: '#9199a3' }}> ({g.polymerFamily})</span>}</td>
      <td style={{ ...tdStyle, fontFamily: 'monospace' }}>{g.mfi ?? '—'}</td>
      <td style={{ ...tdStyle, fontFamily: 'monospace' }}>{g.density ?? '—'}</td>
      <td style={tdStyle}>{g.originCountry === 'IR' ? 'داخلی' : 'وارداتی'}</td>
      <td style={tdStyle}>{usageCount > 0 ? `${usageCount} مورد` : '—'}</td>
      <td style={tdStyle}>
        <span style={{ fontSize: 11, fontWeight: 700, color: g.isActive ? '#146c3a' : '#9199a3' }}>
          {g.isActive ? 'فعال' : 'غیرفعال'}
        </span>
      </td>
      {canEdit && (
        <td style={tdStyle}>
          <form action={toggleGradeActiveAction}>
            <input type="hidden" name="id" value={g.id} />
            <input type="hidden" name="value" value={(!g.isActive).toString()} />
            <ConfirmSubmitButton
              message={g.isActive
                ? `«${g.code}» غیرفعال بشه؟ ${usageCount > 0 ? `توجه: ${usageCount} رکورد بهش ارجاع دارن، ولی حذف نمی‌شه، فقط از لیست انتخاب جدید خارج می‌شه.` : ''}`
                : `«${g.code}» دوباره فعال بشه؟`}
              style={{ background: 'none', border: 'none', color: g.isActive ? '#9b1c1c' : '#146c3a', fontSize: 11.5, cursor: 'pointer', fontWeight: 700 }}
            >
              {g.isActive ? 'غیرفعال کن' : 'فعال کن'}
            </ConfirmSubmitButton>
          </form>
        </td>
      )}
    </tr>
  )
}

const cardStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 12, padding: 20, marginBottom: 20, background: '#fff', boxShadow: '0 1px 4px rgba(27,30,36,.05)' }
const inputStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 8, padding: '9px 12px', fontSize: 13, fontFamily: 'inherit' }
const btnStyle: React.CSSProperties = { background: '#1e357b', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 18px', fontSize: 13, fontWeight: 700, cursor: 'pointer' }
const thStyle: React.CSSProperties = { padding: '10px 12px', fontWeight: 700 }
const tdStyle: React.CSSProperties = { padding: '9px 12px', verticalAlign: 'middle' }
