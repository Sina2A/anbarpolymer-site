'use server'

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import { revalidatePath } from 'next/cache'

/** چک دسترسی نوشتن — مدیر همیشه مجاز، کارشناس فقط اگه canEdit روی بخش «grades» داشته باشه. */
async function requireGradeEditAccess() {
  const user = await getCurrentUser()
  if (user.role === 'admin') return user
  const access = await getAllSectionAccess(user.id)
  if (access.grades !== 'edit' && access.grades !== 'full') {
    throw new Error('دسترسی ویرایش گریدها رو نداری — از مدیر بخواه بهت بده.')
  }
  return user
}

export async function createGradeAction(formData: FormData) {
  const user = await requireGradeEditAccess()

  const code = String(formData.get('code') || '').trim()
  const producer = String(formData.get('producer') || '').trim()
  const category = String(formData.get('category') || '').trim()
  if (!code || !producer || !category) {
    throw new Error('کد گرید، تولیدکننده، و نوع ماده اجباری‌ان.')
  }

  const mfiRaw = String(formData.get('mfi') || '').trim()
  const densityRaw = String(formData.get('density') || '').trim()

  await prisma.grade.create({
    data: {
      code,
      producer,
      category,
      polymerFamily: String(formData.get('polymerFamily') || '').trim() || null,
      applicationType: String(formData.get('applicationType') || '').trim() || null,
      mfi: mfiRaw ? parseFloat(mfiRaw) : null,
      mfiTestCondition: String(formData.get('mfiTestCondition') || '').trim() || null,
      density: densityRaw ? parseFloat(densityRaw) : null,
      originCountry: String(formData.get('originCountry') || 'IR').trim() || 'IR',
      packagingType: String(formData.get('packagingType') || '').trim() || null,
      description: String(formData.get('description') || '').trim() || null,
      createdById: user.id,
    },
  })

  revalidatePath('/admin-grades')
}

export async function updateGradeAction(formData: FormData) {
  await requireGradeEditAccess()

  const id = String(formData.get('id') || '')
  if (!id) throw new Error('گرید مشخص نیست.')

  const mfiRaw = String(formData.get('mfi') || '').trim()
  const densityRaw = String(formData.get('density') || '').trim()

  await prisma.grade.update({
    where: { id },
    data: {
      code: String(formData.get('code') || '').trim(),
      producer: String(formData.get('producer') || '').trim(),
      category: String(formData.get('category') || '').trim(),
      polymerFamily: String(formData.get('polymerFamily') || '').trim() || null,
      applicationType: String(formData.get('applicationType') || '').trim() || null,
      mfi: mfiRaw ? parseFloat(mfiRaw) : null,
      mfiTestCondition: String(formData.get('mfiTestCondition') || '').trim() || null,
      density: densityRaw ? parseFloat(densityRaw) : null,
      originCountry: String(formData.get('originCountry') || 'IR').trim() || 'IR',
      packagingType: String(formData.get('packagingType') || '').trim() || null,
      description: String(formData.get('description') || '').trim() || null,
    },
  })

  revalidatePath('/admin-grades')
}

/** غیرفعال/فعال‌سازی — نه حذف، چون سفارش/آگهی‌های قدیمی ممکنه بهش ارجاع داشته باشن. */
export async function toggleGradeActiveAction(formData: FormData) {
  await requireGradeEditAccess()

  const id = String(formData.get('id') || '')
  const value = formData.get('value') === 'true'
  await prisma.grade.update({ where: { id }, data: { isActive: value } })
  revalidatePath('/admin-grades')
}
