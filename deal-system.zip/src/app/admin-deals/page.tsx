import prisma from '@/lib/prisma'
import { getAllSectionAccess } from '@/lib/permissions'
import { getCurrentUser } from '@/lib/currentUser'
import AdminNav from '@/components/AdminNav'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'
import { confirmFundsSecured, confirmFundsReleased } from './actions'

export const dynamic = 'force-dynamic'

const STATUS_LABELS: Record<string, string> = {
  draft: 'پیش‌نویس', confirmed: 'تایید شد', payment_secured: 'وجه تضمین شد',
  loading: 'در حال بارگیری', in_transit: 'در مسیر ارسال', delivered: 'تحویل شد', settled: 'تسویه شد',
}
const CONFIRMATION_TYPE_LABELS: Record<string, string> = {
  loading: 'تایید بارگیری', unloading: 'تایید تخلیه', driver_confirm: 'تاییدیه راننده', buyer_confirm: 'تاییدیه خریدار',
}
const CHECKLIST_LABELS: Record<string, string> = {
  packagingIntact: 'بسته‌بندی سالم', quantityMatches: 'تعداد مطابق سفارش', palletsIntact: 'پالت‌ها سالم',
  productMatchesOrder: 'محصول مطابق سفارش', discrepancyObserved: 'مغایرت مشاهده شد',
  noTransitDamage: 'بدون آسیب حمل', productReceived: 'محصول دریافت شد', discrepancyExists: 'مغایرت وجود دارد',
}

export default async function AdminDealsPage({ searchParams }: { searchParams: Promise<{ userId?: string }> }) {
  const { userId: requestedUserId } = await searchParams
  const currentUser = await getCurrentUser(requestedUserId)
  if (!currentUser) return <div style={{ padding: 32 }}>هنوز هیچ کاربری ثبت نشده.</div>

  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)

  const deals = await prisma.deal.findMany({
    include: { buyer: true, confirmations: { orderBy: { confirmedAt: 'asc' } } },
    orderBy: { createdAt: 'desc' },
  })

  return (
    <div style={{ display: 'flex', gap: 24, padding: '32px 24px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', maxWidth: 1100, margin: '0 auto' }}>
      <AdminNav currentUserName={currentUser.companyName} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="deals" />

      <div style={{ flex: 1, minWidth: 0 }}>
        <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 8 }}>معاملات تجاری</h1>
        <p style={{ color: '#6f7680', fontSize: 13.5, marginBottom: 24, lineHeight: 1.9 }}>
          این جدا از سفارش‌های مستقیم فروشگاهه — اینجا یه کارخانه‌ی دیگه می‌فروشه، انبار پلیمر فقط واسط وضعیته. هیچ تراکنش بانکی از این صفحه انجام نمی‌شه؛ فقط ثبت وضعیتیه که حسابداری بیرون از سایت انجام داده.
        </p>

        {deals.length === 0 && (
          <div style={{ padding: 32, textAlign: 'center', color: '#9199a3', border: '1px dashed #d8dde3', borderRadius: 12 }}>هنوز هیچ معامله‌ای ثبت نشده.</div>
        )}

        {deals.map((deal) => (
          <div key={deal.id} style={cardStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, flexWrap: 'wrap', gap: 8 }}>
              <div>
                <b style={{ fontSize: 14 }}>#{deal.id.slice(0, 8)}</b>{' '}
                <span style={{ fontSize: 12.5, color: '#6f7680' }}>— {deal.buyer.companyName} — {deal.quantity}</span>
              </div>
              <span style={statusTag}>{STATUS_LABELS[deal.status] || deal.status}</span>
            </div>

            <div style={{ fontSize: 12.5, color: '#4f5560', marginBottom: 14 }}>
              قیمت توافقی: {deal.agreedPrice || '—'} &nbsp;|&nbsp; وضعیت وجه: <b style={escrowColor(deal.escrowStatus)}>{escrowLabel(deal.escrowStatus)}</b>
            </div>

            {/* ---------- تایم‌لاین رویدادها ---------- */}
            {deal.confirmations.length > 0 && (
              <div style={{ marginBottom: 14 }}>
                {deal.confirmations.map((c) => {
                  let checklist: Record<string, boolean> = {}
                  try { checklist = JSON.parse(c.checklistJson) } catch {}
                  return (
                    <div key={c.id} style={timelineRow}>
                      <div style={{ fontWeight: 700, fontSize: 12.5, marginBottom: 4 }}>{CONFIRMATION_TYPE_LABELS[c.type] || c.type}</div>
                      {c.driverName && <div style={metaLine}>راننده: {c.driverName} — {c.driverPhone} — پلاک {c.vehiclePlate}</div>}
                      {c.receiverName && <div style={metaLine}>تحویل‌گیرنده: {c.receiverName} ({c.receiverRole})</div>}
                      <div style={metaLine}>
                        {Object.entries(checklist).filter(([, v]) => v).map(([k]) => CHECKLIST_LABELS[k] || k).join(' · ') || 'بدون آیتم تیک‌خورده'}
                      </div>
                      {c.latitude && c.longitude && (
                        <div style={metaLine}>موقعیت ثبت‌شده: {c.latitude.toFixed(5)}, {c.longitude.toFixed(5)} (سیگنال کمکی، نه مدرک قطعی)</div>
                      )}
                      {c.photoUrl && (
                        <a href={c.photoUrl} target="_blank" rel="noreferrer" style={{ fontSize: 11.5, color: '#1e357b' }}>مشاهده‌ی عکس ↗</a>
                      )}
                      <div style={{ fontSize: 10.5, color: '#9199a3', marginTop: 4 }}>{new Date(c.confirmedAt).toLocaleString('fa-IR')}</div>
                    </div>
                  )
                })}
              </div>
            )}

            {/* ---------- دکمه‌های وضعیت وجه (دستی) ---------- */}
            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', borderTop: '1px dashed #e5e7eb', paddingTop: 12 }}>
              {deal.escrowStatus === 'pending' && (
                <form action={confirmFundsSecured}>
                  <input type="hidden" name="dealId" value={deal.id} />
                  <input type="hidden" name="confirmedById" value={currentUser.id} />
                  <ConfirmSubmitButton
                    message="⚠️ این یعنی حسابداری تایید می‌کنه وجه از خریدار واقعاً دریافت شده (بیرون از سایت). مطمئنی؟"
                    style={btnStyle('#1e357b')}
                  >
                    تایید دریافت وجه از خریدار
                  </ConfirmSubmitButton>
                </form>
              )}
              {deal.escrowStatus === 'secured_manual' && (
                <form action={confirmFundsReleased}>
                  <input type="hidden" name="dealId" value={deal.id} />
                  <input type="hidden" name="confirmedById" value={currentUser.id} />
                  <ConfirmSubmitButton
                    message="⚠️ این یعنی حسابداری تایید می‌کنه وجه واقعاً به فروشنده پرداخت شده (بیرون از سایت). مطمئنی؟"
                    style={btnStyle('#f6621b')}
                  >
                    تایید پرداخت به فروشنده
                  </ConfirmSubmitButton>
                </form>
              )}
              {deal.escrowStatus === 'released_manual' && (
                <span style={{ fontSize: 12, color: '#146c3a', fontWeight: 600 }}>✓ این معامله کامل تسویه شده</span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

function escrowLabel(status: string) {
  return status === 'pending' ? 'در انتظار' : status === 'secured_manual' ? 'نزد ما (تضمین‌شده)' : status === 'released_manual' ? 'به فروشنده پرداخت شد' : status
}
function escrowColor(status: string): React.CSSProperties {
  return { color: status === 'pending' ? '#92400e' : status === 'secured_manual' ? '#1e357b' : '#146c3a' }
}
function btnStyle(bg: string): React.CSSProperties {
  return { background: bg, color: '#fff', border: 'none', borderRadius: 8, padding: '9px 16px', fontSize: 12.5, fontWeight: 700, cursor: 'pointer' }
}

const cardStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 12, padding: 20, marginBottom: 16, background: '#fff', boxShadow: '0 1px 4px rgba(27,30,36,.05)' }
const statusTag: React.CSSProperties = { fontSize: 11, fontWeight: 700, background: '#eef4fd', color: '#1e357b', borderRadius: 6, padding: '4px 12px' }
const timelineRow: React.CSSProperties = { borderRight: '2px solid #e5e7eb', paddingRight: 12, marginBottom: 10 }
const metaLine: React.CSSProperties = { fontSize: 11.5, color: '#6f7680', marginTop: 2 }
