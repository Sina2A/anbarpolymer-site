import prisma from './prisma'

/**
 * پل موقت تا وقتی سیستم ورود واقعی (فاز ۴) وصل بشه.
 * وقتی Auth واقعی اضافه شد، این تابع فقط باید userId رو از session بخونه —
 * همه‌ی جاهایی که ازش استفاده کردیم بدون تغییر باقی می‌مونن.
 */
export async function getCurrentUser(requestedUserId?: string) {
  if (requestedUserId) {
    const user = await prisma.user.findUnique({ where: { id: requestedUserId } })
    if (user) return user
  }
  // پیش‌فرض: اولین مدیر فعال؛ اگه نبود، اولین کارشناس فعال
  const admin = await prisma.user.findFirst({ where: { role: 'admin', isActive: true } })
  if (admin) return admin
  return prisma.user.findFirst({ where: { role: 'staff', isActive: true } })
}

export async function getAllStaffForPicker() {
  return prisma.user.findMany({
    where: { role: { in: ['staff', 'admin'] }, isActive: true },
    orderBy: { createdAt: 'asc' },
  })
}
