// این فایل عمداً هیچ وابستگی به prisma یا هر چیز سرور-فقط نداره —
// چون توسط کامپوننت‌های کلاینتی (مثل AdminNav) هم import می‌شه.
// اگه چیزی اینجا رو به prisma وصل کنی، دوباره همون خطای بیلد قبلی برمی‌گرده
// (bundle شدن پکیج pg برای مرورگر که ممکن نیست).

export const SECTION_KEYS = [
  { key: 'orders', label: 'سفارش‌ها', href: '/admin-orders' },
  { key: 'pricing', label: 'مرکز قیمت‌گذاری (بنچمارک)', href: '/admin-pricing' },
  { key: 'warehouses', label: 'انبارها و موجودی', href: '/admin-warehouses' },
  { key: 'grades', label: 'گریدها و مشخصات فنی', href: '/grades' },
  { key: 'material-listings', label: 'شبکه عرضه مواد اولیه', href: '/admin-material-listings' },
  { key: 'deals', label: 'معاملات تجاری', href: '/admin-deals' },
  { key: 'payments', label: 'تایید فیش‌های پرداخت', href: '/admin-payments' },
  { key: 'logistics', label: 'حمل و نقل', href: '/admin-logistics' },
  { key: 'articles', label: 'مقالات و اخبار', href: '/admin-articles' },
  { key: 'documents', label: 'اسناد (TDS/MSDS)', href: '/admin-documents' },
  { key: 'support', label: 'پشتیبانی و تیکت‌ها', href: '/admin-support' },
  { key: 'buyers', label: 'خریداران', href: '/admin-buyers' },
  { key: 'users', label: 'مدیریت کاربران و دسترسی‌ها', href: '/admin-users' },
] as const

export type SectionKey = (typeof SECTION_KEYS)[number]['key']
export type AccessLevel = 'none' | 'view' | 'edit' | 'full'
