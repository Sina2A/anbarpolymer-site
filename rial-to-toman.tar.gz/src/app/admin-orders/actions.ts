'use server'

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { logStatusEvent } from '@/lib/statusEvents'
import { logAudit } from '@/lib/logger'
import { startProformaDeadline } from '@/lib/dealDeadlines'
import { issueInvoiceForOrder } from '@/lib/invoices'
import { evaluateApprovalRequirement } from '@/lib/priceEngine'
import { revalidatePath } from 'next/cache'

/**
 * کارشناس فروش قیمت نهایی هر قلم رو ثبت می‌کنه — این قیمت جدا از price
 * (که فقط snapshot مرجعه) ذخیره می‌شه، تا سفارش وارد مرحله‌ی «priced» بشه
 * و مشتری بتونه توی /my-orders تاییدش کنه.
 */
export async function setOrderPricing(formData: FormData) {
  const user = await getCurrentUser()
  const orderId = String(formData.get('orderId'))

  const order = await prisma.order.findUnique({ where: { id: orderId }, include: { items: true } })
  if (!order) throw new Error('سفارش پیدا نشد.')

  await prisma.$transaction(
    order.items.map((item) =>
      prisma.orderItem.update({
        where: { id: item.id },
        data: { finalPrice: parseFloat(String(formData.get(`finalPrice-${item.id}`) || item.price)) },
      })
    )
  )

  // محاسبه‌ی مبلغ کل (ریال)
  const updatedItems = await prisma.orderItem.findMany({ where: { orderId } })
  const totalAmount = updatedItems.reduce((sum, item) => sum + (item.finalPrice ?? item.price) * item.quantity, 0)

  // ارزیابی نیاز به تایید
  const approvalLevel = await evaluateApprovalRequirement('Order', totalAmount)

  if (approvalLevel) {
    // نیاز به تایید — وضعیت awaiting_approval
    await prisma.order.update({
      where: { id: orderId },
      data: { status: 'awaiting_approval' },
    })

    await logStatusEvent({
      recordType: 'Order',
      recordId: orderId,
      newStageKey: 'awaiting_approval',
      performedById: user.id,
      note: `مبلغ ${totalAmount.toLocaleString('fa-IR')} تومان نیاز به تایید ${approvalLevel} دارد`,
    })
  } else {
    // خودکار تایید — مسیر قبلی
    await startProformaDeadline(orderId)

    await logStatusEvent({
      recordType: 'Order',
      recordId: orderId,
      newStageKey: 'priced',
      performedById: user.id,
      note: 'قیمت نهایی توسط کارشناس فروش ثبت شد',
    })
  }

  revalidatePath('/admin-orders')
}

/**
 * رد سفارش — موجودی قفل‌شده باید برگرده به انبار، وگرنه برای همیشه
 * از دسترس خارج می‌مونه بدون این‌که واقعاً فروخته شده باشه.
 */
export async function rejectOrder(formData: FormData) {
  const user = await getCurrentUser()
  const orderId = String(formData.get('orderId'))

  const order = await prisma.order.findUnique({ where: { id: orderId }, include: { items: true } })
  if (!order) throw new Error('سفارش پیدا نشد.')
  if (order.status !== 'pending') throw new Error('فقط سفارش‌های در انتظار قیمت‌گذاری قابل‌رد کردنن.')

  const itemsWithWarehouse = order.items.filter((item) => item.warehouseId)

  await prisma.$transaction([
    ...itemsWithWarehouse.map((item) =>
      prisma.warehouseStock.updateMany({
        where: { warehouseId: item.warehouseId as string, gradeId: item.gradeId },
        data: { quantityTon: { increment: item.quantity } },
      })
    ),
    prisma.order.update({ where: { id: orderId }, data: { status: 'rejected' } }),
  ])

  await logStatusEvent({
    recordType: 'Order',
    recordId: orderId,
    newStageKey: 'rejected',
    performedById: user.id,
    note: 'سفارش توسط کارشناس رد شد — موجودی به انبار برگشت',
  })

  revalidatePath('/admin-orders')
}

/**
 * ابطال پیش‌فاکتور توسط کارشناس/ادمین — فارغ از مهلت.
 * موجودی قفل‌شده‌ی هر قلم به انبار برمی‌گرده (الگوی واحد rejectOrder/enforceProformaDeadlines).
 */
export async function cancelProformaAction(orderId: string) {
  const user = await getCurrentUser()

  const order = await prisma.order.findUnique({ where: { id: orderId }, include: { items: true } })
  if (!order) throw new Error('سفارش پیدا نشد.')
  if (!['priced', 'buyer_confirmed'].includes(order.status)) {
    throw new Error('فقط سفارش‌های در مرحله‌ی پیش‌فاکتور قابل ابطالن.')
  }

  const itemsWithWarehouse = order.items.filter((item) => item.warehouseId)

  await prisma.$transaction([
    ...itemsWithWarehouse.map((item) =>
      prisma.warehouseStock.updateMany({
        where: { warehouseId: item.warehouseId as string, gradeId: item.gradeId },
        data: { quantityTon: { increment: item.quantity } },
      })
    ),
    prisma.order.update({ where: { id: orderId }, data: { status: 'rejected' } }),
  ])

  await logStatusEvent({
    recordType: 'Order',
    recordId: orderId,
    newStageKey: 'rejected',
    performedById: user.id,
    note: 'پیش‌فاکتور توسط کارشناس/ادمین ابطال شد — موجودی به انبار برگشت',
  })

  revalidatePath('/admin-orders')
  revalidatePath('/proformas')
}

/**
 * تایید فیش پرداخت — وضعیت رسید از pending به approved تغییر می‌کنه و بلافاصله
 * فاکتور رسمی سفارش صادر می‌شه (شماره‌گذاری یکتا در lib/invoices).
 */
export async function approvePaymentReceiptAction(orderId: string) {
  const user = await getCurrentUser()

  // تصمیم تکه ۱: تایید فیش = مسیر contracted → paid (همون اکشن، نه اکشن جدا)
  // paymentReceiptStatus جدا میمونه؛ Order.status هم همزمان به paid میره.
  const orderBefore = await prisma.order.findUnique({ where: { id: orderId }, select: { status: true } })

  await prisma.order.update({
    where: { id: orderId },
    data: {
      paymentReceiptStatus: 'approved',
      paymentReceiptReviewedById: user.id,
      paymentReceiptReviewedAt: new Date(),
      ...(orderBefore?.status === 'contracted' ? { status: 'paid' as const } : {}),
    },
  })

  // اگر سفارش در contracted بود، یک ستون Order.status هم به paid رفت
  if (orderBefore?.status === 'contracted') {
    await logStatusEvent({
      recordType: 'Order',
      recordId: orderId,
      newStageKey: 'paid',
      performedById: user.id,
      note: 'پرداخت تایید شد — سفارش وارد مرحله پرداخت شده شد (contracted → paid)',
    })
  }

  await logStatusEvent({
    recordType: 'Order',
    recordId: orderId,
    newStageKey: 'receipt_approved',
    performedById: user.id,
    note: 'فیش پرداخت توسط کارشناس مالی تایید شد',
  })

  await logAudit('payment', `تایید فیش پرداخت سفارش ${orderId.slice(0, 8)}`, user.id, { orderId, action: 'receipt_approved' })

  // صدور فاکتور عمداً بعد از ثبت تایید و توی try جدا اجرا می‌شه: اگه صدور
  // شکست بخوره، خودِ تایید فیش نباید برگرده — فقط لاگ می‌شه تا کارشناس مالی
  // ببینه و دوباره تلاش کنه (تایید دوباره همون فاکتور قبلی رو برمی‌گردونه،
  // چون issueInvoiceForOrder بر اساس orderId idempotent هست).
  try {
    const invoice = await issueInvoiceForOrder(orderId, user.id)
    await logAudit('invoice', `صدور فاکتور ${invoice.number} برای سفارش ${orderId.slice(0, 8)}`, user.id, {
      orderId,
      invoiceId: invoice.id,
      number: invoice.number,
      totalAmount: invoice.totalAmount,
    })
  } catch (e) {
    await logAudit('invoice', `صدور فاکتور برای سفارش ${orderId.slice(0, 8)} ناموفق بود`, user.id, {
      orderId,
      action: 'issue_failed',
      error: String(e),
    })
  }

  revalidatePath('/admin-orders')
  revalidatePath('/proformas')
}

/**
 * رد فیش پرداخت — خریدار باید رسید جدید آپلود کنه.
 */
export async function rejectPaymentReceiptAction(orderId: string) {
  const user = await getCurrentUser()

  await prisma.order.update({
    where: { id: orderId },
    data: {
      paymentReceiptStatus: 'rejected',
      paymentReceiptReviewedById: user.id,
      paymentReceiptReviewedAt: new Date(),
      // رسید قبلی باطل می‌شه تا خریدار رسید جدید آپلود کنه
      paymentReceiptUrl: null,
      paymentReceiptUploadedAt: null,
    },
  })

  await logStatusEvent({
    recordType: 'Order',
    recordId: orderId,
    newStageKey: 'receipt_rejected',
    performedById: user.id,
    note: 'فیش پرداخت توسط کارشناس مالی رد شد — خریدار باید رسید جدید ارسال کنه',
  })

  await logAudit('payment', `رد فیش پرداخت سفارش ${orderId.slice(0, 8)}`, user.id, { orderId, action: 'receipt_rejected' })

  revalidatePath('/admin-orders')
  revalidatePath('/proformas')
}

/**
 * تایید سفارش توسط مدیر — بعد از این، مهلت پیش‌فاکتور شروع می‌شه
 */
export async function approveOrderAction(orderId: string) {
  const user = await getCurrentUser()
  if (user.role !== 'admin') throw new Error('فقط مدیر می‌تونه سفارش رو تایید کنه.')

  const order = await prisma.order.findUnique({ where: { id: orderId } })
  if (!order) throw new Error('سفارش پیدا نشد.')
  if (order.status !== 'awaiting_approval') throw new Error('فقط سفارش‌های در انتظار تایید قابل تصویبن.')

  await startProformaDeadline(orderId)

  await logStatusEvent({
    recordType: 'Order',
    recordId: orderId,
    newStageKey: 'priced',
    performedById: user.id,
    note: 'سفارش توسط مدیر تایید شد',
  })

  await logAudit('order', `تایید سفارش ${orderId.slice(0, 8)} توسط مدیر`, user.id, { orderId })

  revalidatePath('/admin-orders')
  revalidatePath('/proformas')
}
