import { test } from 'node:test'
import assert from 'node:assert/strict'
import {
  dealItemRef,
  reservationItemUrl,
  isReservationItemType,
  CLAIM_TTL_MS,
} from '../../src/lib/reservationQueue'

/**
 * تستِ واحدِ توابعِ «خالص» صف رزرو — همان‌هایی که به پایگاه‌داده دست نمی‌زنند، پس در
 * هر محیطی (بدون DB) قابل اجرا هستند. منطقِ FIFO/claim/انقضا (enterQueue, advanceQueue,
 * consumeClaimInTx, enforceReservationQueueClaims, getQueueSummaries) به prisma وابسته‌اند
 * و در تستِ integration با DB واقعی پوشش داده می‌شوند — نه اینجا.
 *
 * این سه تابع بارِ قراردادیِ واقعی دارند:
 *  - dealItemRef: مسیریابیِ معامله‌ی BUY/SELL/legacy به موردِ درست (همان کلاسِ عدم‌تقارنی که
 *    در dealRoles.test.ts پوشش داده شده). صفِ اشتباه = اعلان به نفرِ اشتباه.
 *  - reservationItemUrl: دیپ‌لینکِ داخل اعلانِ Novu. اشتباه در آن، کاربر را به تبِ غلط می‌برد.
 *  - isReservationItemType: نگهبانِ قراردادِ `kind`→نوع در actions. مقدار نامعتبر باید رد شود.
 *
 * اجرا: npx tsx --test tests/unit/reservationQueue.pure.test.ts
 */

const LISTING = 'lst_1'
const REQUEST = 'req_1'

// ── dealItemRef: معامله به کدام موردِ صف وصل است ─────────────────────────────

test('dealItemRef: معامله‌ی BUY ⇒ درخواست خرید (BUY)', () => {
  assert.deepEqual(
    dealItemRef({ tradeDirection: 'BUY', materialListingId: LISTING, purchaseRequestId: REQUEST }),
    { itemType: 'BUY', itemId: REQUEST },
  )
})

test('dealItemRef: معامله‌ی SELL ⇒ آگهی فروش (SELL)، حتی اگر purchaseRequestId ست باشد', () => {
  assert.deepEqual(
    dealItemRef({ tradeDirection: 'SELL', materialListingId: LISTING, purchaseRequestId: REQUEST }),
    { itemType: 'SELL', itemId: LISTING },
  )
})

test('dealItemRef: legacy بدون tradeDirection ⇒ SELL (هم‌راستا با `|| SELL`)', () => {
  assert.deepEqual(
    dealItemRef({ tradeDirection: null, materialListingId: LISTING, purchaseRequestId: null }),
    { itemType: 'SELL', itemId: LISTING },
  )
})

test('dealItemRef: BUY بدون purchaseRequestId ⇒ null (صف به موردِ بی‌شناسه وصل نمی‌شود)', () => {
  assert.equal(
    dealItemRef({ tradeDirection: 'BUY', materialListingId: LISTING, purchaseRequestId: null }),
    null,
  )
})

test('dealItemRef: SELL/legacy بدون materialListingId ⇒ null', () => {
  assert.equal(dealItemRef({ tradeDirection: 'SELL', materialListingId: null, purchaseRequestId: REQUEST }), null)
  assert.equal(dealItemRef({ tradeDirection: null, materialListingId: null, purchaseRequestId: REQUEST }), null)
})

// ── reservationItemUrl: دیپ‌لینکِ اعلان ──────────────────────────────────────

test('reservationItemUrl: SELL → تبِ supply', () => {
  assert.equal(reservationItemUrl('SELL', LISTING), `/market?view=supply&item=${LISTING}`)
})

test('reservationItemUrl: BUY → تبِ demand', () => {
  assert.equal(reservationItemUrl('BUY', REQUEST), `/market?view=demand&item=${REQUEST}`)
})

test('reservationItemUrl: شناسه‌ی خاص URL-encode می‌شود (دیپ‌لینکِ امن)', () => {
  const url = reservationItemUrl('SELL', 'a b&c=د')
  assert.equal(url, `/market?view=supply&item=${encodeURIComponent('a b&c=د')}`)
  assert.ok(!url.includes(' b'))
})

// ── isReservationItemType: نگهبانِ قراردادِ kind ─────────────────────────────

test('isReservationItemType: فقط SELL/BUY معتبرند', () => {
  assert.equal(isReservationItemType('SELL'), true)
  assert.equal(isReservationItemType('BUY'), true)
})

test('isReservationItemType: مقدارِ نامعتبر (تهی/حساس‌به‌حرف/kindِ خام) رد می‌شود', () => {
  assert.equal(isReservationItemType(''), false)
  assert.equal(isReservationItemType('sell'), false)
  assert.equal(isReservationItemType('listing'), false) // `kind` خام است، نه itemType — نگهبان ردش می‌کند
  assert.equal(isReservationItemType('request'), false)
})

// ── ثابتِ پنجره‌ی claim ──────────────────────────────────────────────────────

test('CLAIM_TTL_MS: پنجره‌ی فرصت دقیقاً ۱ ساعت است', () => {
  assert.equal(CLAIM_TTL_MS, 60 * 60 * 1000)
})
