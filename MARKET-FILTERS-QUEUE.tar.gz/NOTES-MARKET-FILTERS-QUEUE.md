# گزارش: بازطراحی فیلترهای بازار + رابط کاربریِ صف رزرو (FIFO Queue)

> این گزارش کارِ این نشست را مستند می‌کند. یادداشت‌های نشست‌های پیشین بازار در
> `NOTES-MARKET-REDESIGN.md` و `NOTES-MARKET-FLOW.md` هستند و اینجا تکرار نمی‌شوند.
> پلن مصوب: `~/.claude/plans/modular-tinkering-toucan.md`. هیچ commit/push انجام نشد.

## خلاصه

`/market` برای هر دو تبِ عرضه (فروشنده) و تقاضا (خریدار) بازطراحی شد: فیلترهای GET که
**بدون جاوااسکریپت** کار می‌کنند، چیپسِ خانواده‌های پلیمری، نوارِ فیلترهای فعال، شمارش‌های
دقیق، چهار حالتِ خالی، جدول دسکتاپ، کارت موبایل و شیتِ فیلتر موبایل. رفتارِ محفوظ
(محوِ قیمت برای مهمان، دیالوگِ جزئیات و کارتِ اعتماد، گیت‌های احراز هویت و KYC، اکشن‌های
معامله) دست‌نخورده ماند. رابطِ کاربریِ صف رزرو (ورود/خروج از صف و نمایشِ جایگاهِ بیننده)
روی هر دو تب سوار شد؛ یکپارچگیِ موجود با `/inbox` تغییری نکرد.

---

## فایل‌های تغییر یافته

| فایل | وضعیت | تغییر |
|---|---|---|
| `src/app/market/page.tsx` | ویرایش | Server Component؛ فیلترهای GET، شمارش‌ها، نوارِ فیلتر فعال، ۴ حالت خالی، رندرِ `MarketFilterSheet`، پاس‌دادن خلاصه‌ی صف به ردیف‌ها، `MARKET_FILTER_CSS` |
| `src/app/market/loading.tsx` | ویرایش | اسکلت با همان کلاس‌های ریسپانسیو (`mk-table`/`mk-thead`/`mk-row`) تا در موبایل مثل صفحه‌ی نهایی کارت شود |
| `src/app/market/actions.ts` | **دست‌نخورده** | فقط خوانده شد تا قراردادِ `parseQueueTarget` (فیلد `kind`) تأیید شود |
| `src/components/SupplyTableRow.tsx` | ویرایشِ جراحی | کلاس‌های ریسپانسیو + `data-label` روی سلول‌ها؛ گیتِ اکشن با `ReserveButton` در شاخه‌ی رزروشده؛ **CRLF** |
| `src/components/DemandTableRow.tsx` | ویرایشِ جراحی | همان الگو؛ شاخه‌ی `reserved` + شمارنده‌ی پیشنهادهای دریافتی |
| `src/components/ReserveButton.tsx` | **جدید** | دکمه‌ی صف با `useActionState`؛ فرمِ `kind`+`itemId`؛ نمایشِ جایگاه/خطا |
| `src/components/MarketFilterSheet.tsx` | **دست‌نخورده** | از قبل موجود بود ولی هرگز رندر نمی‌شد؛ در `page.tsx` mount شد |
| `src/lib/reservationQueue.ts` | **دست‌نخورده** (این نشست) | کرانِ retry نووُ (`strategy:'none'`) در نشستِ پیش اعمال شده بود؛ فقط تأیید شد |
| `tests/unit/reservationQueue.pure.test.ts` | **جدید** | تستِ توابعِ خالصِ صف (بدون DB) — ۱۱ تست، همه سبز |

---

## تصمیم‌های کلیدی و انحراف از پلن (با دلیل)

### ۱) تکاملِ `MarketFilterSheet` به‌جای `MarketFilterForm` + context موازی
پلن یک کامپوننتِ جدید (`MarketFilterForm.tsx`) و یک context (`MarketFilterToggle/Close`)
پیشنهاد می‌داد. در عمل `MarketFilterSheet.tsx` از قبل وجود داشت (۳۹ خط) ولی **import شده و
هرگز رندر نشده بود**. به‌جای ساختِ ساختارِ موازی، همان را mount کردم و CSS لازم را در
`MARKET_FILTER_CSS` نوشتم.

**چرا:** حذفِ کدِ تکراری؛ یک نقطه‌ی حقیقت برای شیت. state داخلیِ کامپوننت
(`open`/`enhanced`) نیاز به context را از بین می‌برد.

**حفظِ no-JS:** `enhanced` با `false` شروع می‌شود، پس تا قبل از mount کلاسِ
`.mk-filter-enhanced` غایب است و CSS پنل را `position:static` نگه می‌دارد و فرم همیشه
پیداست. فرم GET بدون جاوااسکریپت به‌طور معمول submit می‌شود.

### ۲) قراردادِ FormData اکشنِ صف: `kind` نه `itemType`  ⚠️ مهم‌ترین نکته
`parseQueueTarget` در `actions.ts` فیلد **`kind`** را با مقادیر `'listing'` (→ SELL) یا
`'request'` (→ BUY) می‌خواند — نه `itemType`. ارسال نامِ اشتباه روی **هر** کلیکِ صف
`مورد انتخاب‌شده نامعتبر است.` پرتاب می‌کرد؛ یک شکستِ زمانِ اجرا که tsc نمی‌گیرد (FormData
بدون تایپ است). `ReserveButton` اصلاح شد:
```tsx
const kind = itemType === 'SELL' ? 'listing' : 'request'
<input type="hidden" name="kind" value={kind} />
```

### ۳) سه تصحیح که §۹ اسپک را override می‌کنند
- گیتِ KYC تقاضا روی **سطح ۱** می‌ماند (`kycLevel < 1`) — هم‌ترازِ عرضه.
- اکشنِ موردِ آزادِ تقاضا همان **`acceptPurchaseRequestAction`** با برچسبِ **«پیشنهاد فروش»**.
- مدلِ تقاضا **first-click-wins** می‌ماند (تغییر نکرد).

### ۴) CSS صفحه-محلی، نه `globals.css`
تمام CSS جدید در ثابتِ `MARKET_FILTER_CSS` داخل `page.tsx` است و با
`<style dangerouslySetInnerHTML>` تزریق می‌شود. **چرا:** `globals.css` توسط بسته‌های دیگر
بازنویسی می‌شود؛ CSS صفحه-محلی با آن collide نمی‌کند. توکن‌ها فقط از `@/lib/styles/tokens`.

### ۵) اینلاین استایل در برابر media query
ویژگی‌های چیدمانی که باید با breakpoint عوض شوند **نمی‌توانند inline باشند** (inline روی
CSS می‌چربد). پس `filterFormStyle` به `marginBottom:20` تقلیل یافت و جعبه/چیدمان به CSS
سپرده شد. ستون‌های گرید از `minmax(0,Xfr)` استفاده می‌کنند (نه `Xfr` خام) تا **Grid Blowout**
از محتوای بلند رخ ندهد.

### ۶) کاراییِ صف
خلاصه‌ی صف فقط برای **ردیف‌های رزروشده** و فقط برای **تبِ فعال** کوئری می‌شود (تب غیرفعال
`{}` می‌گیرد). `getQueueSummaries` خودش تک-کوئری است (بدون N+1) و برای هر itemId یک کلید
برمی‌گرداند.

### ۷) ترتیب ردیف‌ها و معناِ شمارش‌ها
- `reservedLast<T>` (generic، stable sort): ردیف‌های رزروشده به آخر می‌روند، بقیه ترتیبِ
  ورودی را حفظ می‌کنند. هر دو تب از همین یکی استفاده می‌کنند.
- شمارشِ **تب** = تعدادِ ردیفِ دیده‌شده (شامل رزروشده).
- شمارشِ **زیرعنوان** = واقعاً قابل‌اکشن: «آگهی آزاد» / «درخواست باز» (بدون رزروشده).

### ۸) فیلدِ انقضای claim
فیلدِ انقضا **`claimExpiresAt`** است نه `expiresAt`. Client Componentها `QueueSummary` را
فقط **type-only** import می‌کنند (`import type`) — ماژول صف وابستگیِ server دارد.

### ۹) دکمه‌ها: فیدبک `:active`، بدون تغییرِ رنگِ hover
`.mk-press{transition}` + `:active{transform:scale(.96)!important; opacity:.82!important}`.
`!important` برای غلبه بر inline styleها. **هیچ** تغییرِ رنگِ hover اضافه نشد.

### ۱۰) قراردادِ z-index
هدر ۵۰ / ناوبری پایین ۴۰ / scrim ۴۱ / sheet ۴۲.

---

## مواردِ عمداً دست‌نخورده

- `src/app/market/actions.ts` — فقط خوانده شد (تأییدِ قراردادِ `kind`).
- `src/components/MarketFilterSheet.tsx` — بدون تغییر؛ فقط mount شد.
- `src/lib/reservationQueue.ts` — بدون تغییر در این نشست.
- یکپارچگیِ `/inbox` با صف — تغییر نکرد.
- پورتال‌های `ListingDetailDialog` و `TrustCardModal variant` در هر دو ردیف — محفوظ.
- `actionDisabledStyle` در `SupplyTableRow.tsx` اکنون **مرده** است ولی نگه داشته شد
  (tsconfig هیچ `noUnusedLocals` ندارد، پس tsc سبز می‌ماند). پاکسازیِ آن اختیاری است.
- **فرمِ ویرایشِ دستورالعملِ پرداختِ فروشنده** (که در اسپک ظاهر-محور بود) اضافه نشد —
  خارج از دامنه‌ی «فیلترهای بازار + صف» و صرفاً ظاهری بود.

---

## امنیت

- کوئری‌های عمومیِ آگهی/درخواست **هرگز** `include:{user}` ندارند — وگرنه
  `User.passwordHash`/phone/email در payload صفحه‌ی عمومی serialize می‌شد.
- مهمان اصلاً نمی‌تواند وارد صف شود (`ReserveButton` غیرفعال است و action هم throw می‌کند).
- `leaveQueueAction` فقط ورود را چک می‌کند — کاربرِ محدود باید همچنان بتواند **خارج** شود.
- `reservationItemUrl` شناسه را `encodeURIComponent` می‌کند (دیپ‌لینکِ امنِ اعلان).

---

## نتایجِ بررسی‌ها

### اجرا شد ✅
| بررسی | نتیجه |
|---|---|
| `npx tsc --noEmit` | **exit 0**، بدون خروجی |
| `npx next build` | **✓ Compiled successfully**؛ `/market` به‌درستی `ƒ (Dynamic)` |
| `npx tsx --test tests/unit/reservationQueue.pure.test.ts` | **۱۱/۱۱ سبز** — توابعِ خالصِ `dealItemRef`، `reservationItemUrl`، `isReservationItemType`، `CLAIM_TTL_MS` |
| `npx tsx --test tests/unit/dealRoles.test.ts` | **۸/۸ سبز** (رگرسیونِ موجود، تأییدِ سالم بودنِ رانر) |

### اجرا نشد ❌ (با دلیل — صادقانه)
| بررسی | چرا اجرا نشد |
|---|---|
| تست‌های integration صف (ترتیبِ FIFO، ردِ ورودِ تکراری، `consumeClaimInTx` هم‌زمان با یک برنده، انقضای ۱ ساعته → advance، خالی‌شدنِ کامل صف → `active`/`open`، ورودِ مجدد با `queueRunId` تازه، idempotency در دو tickِ کران) | **پایگاه‌داده از این محیط قابل دسترسی نیست.** یک کاوشِ مستقیم داد: `Raw query failed. Code: 28P01. Message: password authentication failed for user "user"` — `.env` به DB سرورِ ریموت اشاره دارد. همه‌ی توابعِ DB-محورِ صف (`enterQueue`, `advanceQueue`, `consumeClaimInTx`, `getQueueSummaries`, `enforceReservationQueueClaims`) به `prisma` سطح-ماژول bound هستند و بدون DB واقعی اجرا نمی‌شوند. این منطق با mock جعلی «تست» نشد تا اعتمادِ کاذب ندهد. |
| اسکرین‌شات‌های Playwright (۱۴۰۰ و ۳۹۰ DPR2 برای مهمان / واردِ تأییدنشده / واردِ تأییدشده × عرضه/تقاضا × فیلترشده/خالی/≥۱ رزرو) و بررسیِ `scrollWidth===390` و باز/بسته‌شدنِ شیت | **اسپک‌های Playwright به سرورِ زنده‌ی ریموت هدف می‌روند** (`http://185.164.73.143:3000` خریدار، `:3001` ادمین) با کردیت‌های hardcode و `storageState` از `.auth/*.json`. در این محیط آن سرور و آن DB در دسترس نیستند. |

> **نتیجه:** تغییرات از نظر تایپ و build سالم‌اند و منطقِ خالصِ صف تستِ واحدِ سبز دارد، اما
> رفتارِ زمانِ اجرایِ کاملِ صف و رندرِ بصری موبایل/دسکتاپ **در این محیط تأیید عملی نشده‌اند** و
> باید روی محیطی با DB و سرورِ زنده (یا `npm run dev` + DB معتبر) راستی‌آزمایی شوند.

---

## بسته‌بندی

آرشیوِ تحویلی فقط شامل **کدِ تغییر یافته‌ی این کار + همین گزارش** است:
`src/app/market/`، سه کامپوننتِ ردیف/دکمه، `tests/unit/reservationQueue.pure.test.ts` و این
`NOTES`. **مستثنی:** `.recover/`، فایل‌های env، تغییراتِ نامرتبط، و اسکریپت‌های موقت (پاک شدند).
هیچ commit/push انجام نشد. SHA-256 در فایلِ sidecar کنارِ آرشیو است.
