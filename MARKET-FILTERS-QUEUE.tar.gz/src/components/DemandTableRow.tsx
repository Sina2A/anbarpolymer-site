'use client'

import { useState } from 'react'
import { createPortal } from 'react-dom'
import { colors, radius, fontSize } from '@/lib/styles/tokens'
import { guestPriceBlurStyle } from '@/lib/styles/shared'
import { PURCHASE_REQUEST_STATUS_LABELS, MARKET_LISTING_LABEL_IN_DEAL } from '@/lib/statusLabels'
import { PurchaseRequestDialog } from '@/components/PurchaseRequestDetailModal'
import TrustCardModal from '@/components/TrustCardModal'
import ReserveButton from '@/components/ReserveButton'
import { acceptPurchaseRequestAction } from '@/app/market/actions'
import type { QueueSummary } from '@/lib/reservationQueue'

type Props = {
  request: any
  isLoggedIn: boolean
  kycLevel: number
  queue: QueueSummary
}

// ستون‌های تب تقاضا — دقیقاً مطابق market-table-preview.html.
// نکته‌ی minmax(0, Xfr) مثل Supply — برای جلوگیری از Grid Blowout.
export const DEMAND_TABLE_COLUMNS = 'minmax(0,1fr) minmax(0,.8fr) minmax(0,1fr) minmax(0,.8fr) minmax(0,.7fr) minmax(0,.7fr) minmax(0,.8fr) minmax(0,1.3fr)'

export default function DemandTableRow({ request, isLoggedIn, kycLevel, queue }: Props) {
  const [open, setOpen] = useState(false)
  const [trustOpen, setTrustOpen] = useState(false)

  // «در حال معامله» = درخواست رزرو شده؛ «باز» = پذیرای پاسخ.
  const reserved = request.status === 'reserved'
  const statusLabel = reserved ? MARKET_LISTING_LABEL_IN_DEAL : PURCHASE_REQUEST_STATUS_LABELS.open
  const statusBg = reserved ? colors.warningBg : colors.darkGreenBg
  const statusColor = reserved ? colors.warningText : colors.darkGreenText
  // تعداد پیشنهادهای دریافتی — صفر یعنی چیزی نمایش نمی‌دهیم.
  const offerCount: number = request._count?.listings ?? 0

  const expiresLabel = (() => {
    if (!request.expiresAt) return '—'
    const d = new Date(request.expiresAt)
    const diff = Math.ceil((d.getTime() - Date.now()) / (24 * 3600 * 1000))
    if (diff <= 0) return 'منقضی'
    if (diff === 1) return '۱ روز'
    return `${diff.toLocaleString('fa-IR')} روز`
  })()

  return (
    <>
      <div className="mk-row market-row-hover" style={rowStyle} onClick={() => setOpen(true)}>
        <div className="mk-cell mk-cell-grade" style={gradeCellStyle} data-label="گرید">
          <span style={gradeCodeStyle}>{request.grade.code}</span>
          <span style={gradeNameStyle}>
            {request.grade.producer} ({request.grade.category})
          </span>
        </div>

        <div className="mk-cell" style={cellStyle} data-label="مقدار">{request.quantityTon} تن</div>

        <div className="mk-cell mk-cell-price" style={priceCellStyle} data-label="سقف قیمت">
          {request.maxPriceToman ? (
            <>
              {/* قیمت مهمان تار می‌شود — بنر بالای صفحه دلیلش را می‌گوید */}
              <span
                style={!isLoggedIn ? { ...priceNumStyle, ...guestPriceBlurStyle } : priceNumStyle}
                aria-hidden={!isLoggedIn || undefined}
              >
                {request.maxPriceToman.toLocaleString('fa-IR')}
              </span>
              <span style={priceUnitStyle}>تومان/کیلو</span>
            </>
          ) : (
            <span style={cellStyle}>اعلام نشده</span>
          )}
        </div>

        <div className="mk-cell" style={cellStyle} data-label="استان">{request.province || 'مهم نیست'}</div>
        <div className="mk-cell" style={cellStyle} data-label="مهلت">{expiresLabel}</div>

        <div className="mk-cell mk-cell-status" style={statusCellStyle} data-label="وضعیت">
          <span style={{ ...badgeStyle, background: statusBg, color: statusColor }}>{statusLabel}</span>
          {offerCount > 0 && <span style={offerCountStyle}>{`${offerCount.toLocaleString('fa-IR')} پیشنهاد`}</span>}
        </div>

        <div className="mk-cell" style={monoCellStyle} data-label="ثبت">{new Date(request.createdAt).toLocaleDateString('fa-IR')}</div>

        <div className="mk-cell mk-cell-actions" style={actionsStyle} onClick={(e) => e.stopPropagation()}>
          <button
            onClick={() => setTrustOpen(true)}
            className="mk-press mk-info-btn"
            style={iconBtnStyle}
            title="فرآیند این درخواست"
            aria-label="فرآیند این درخواست"
          >
            <svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
              <circle cx="8" cy="8" r="6" />
              <path d="M8 11V7.5" strokeLinecap="round" />
              <path d="M8 5.2h.01" strokeLinecap="round" />
            </svg>
          </button>
          {/* گیت عملیات — مهمان→ورود، بدون احراز→احراز هویت، وگرنه پذیرش درخواست (اولین‌کلیک‌برنده)
              درخواستِ رزرو شده دیگر پذیرش مستقیم نمی‌گیرد؛ صفِ FIFO جایگزینش می‌شود. */}
          {!isLoggedIn ? (
            <a href="/login" className="mk-press mk-action-btn" style={actionBtnStyle}>ورود برای پاسخ</a>
          ) : kycLevel < 1 ? (
            <a href="/verification" className="mk-press mk-action-btn" style={actionBtnStyle}>احراز هویت</a>
          ) : reserved ? (
            <ReserveButton itemType="BUY" itemId={request.id} summary={queue} isLoggedIn={isLoggedIn} />
          ) : (
            <form action={acceptPurchaseRequestAction} className="mk-action-slot mk-reserve-form">
              <input type="hidden" name="purchaseRequestId" value={request.id} />
              <button type="submit" className="mk-press mk-action-btn" style={actionBtnStyle}>پیشنهاد فروش</button>
            </form>
          )}
        </div>
      </div>

      {open &&
        createPortal(
          <PurchaseRequestDialog request={request} isLoggedIn={isLoggedIn} kycLevel={kycLevel} onClose={() => setOpen(false)} />,
          document.body,
        )}
      {trustOpen && <TrustCardModal variant="demand" onClose={() => setTrustOpen(false)} />}
    </>
  )
}

const rowStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: DEMAND_TABLE_COLUMNS,
  gap: 10,
  alignItems: 'center',
  background: colors.bgCard,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
  padding: '11px 16px',
  marginBottom: 8,
  fontSize: fontSize.sm,
  cursor: 'pointer',
  transition: 'border-color .15s, box-shadow .15s',
}
const gradeCellStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 1,
  minWidth: 0,
  lineHeight: 1.5,
}
const gradeCodeStyle: React.CSSProperties = {
  fontFamily: 'monospace',
  fontWeight: 800,
  fontSize: 13,
  color: colors.navy,
  whiteSpace: 'nowrap',
}
const gradeNameStyle: React.CSSProperties = {
  fontSize: fontSize.xs,
  color: colors.textMuted,
  whiteSpace: 'nowrap',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
}
const cellStyle: React.CSSProperties = {
  minWidth: 0,
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  whiteSpace: 'nowrap',
}
const monoCellStyle: React.CSSProperties = {
  ...cellStyle,
  direction: 'ltr',
  textAlign: 'right',
  fontFamily: 'monospace',
  color: colors.textMuted,
  fontSize: fontSize.xs,
  unicodeBidi: 'plaintext',
}
const badgeStyle: React.CSSProperties = {
  display: 'inline-block',
  fontSize: 10,
  fontWeight: 700,
  padding: '3px 9px',
  borderRadius: 999,
  whiteSpace: 'nowrap',
}
// «n پیشنهاد» — شمارنده‌ی پاسخ‌های دریافتی؛ صفر نمایش داده نمی‌شود.
const offerCountStyle: React.CSSProperties = {
  fontSize: 10,
  fontWeight: 600,
  color: colors.textSecondary,
  whiteSpace: 'nowrap',
}
const priceCellStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 1,
  minWidth: 0,
}
// وضعیت + شمارنده‌ی پیشنهادهای دریافتی روی هم — مثل سلولِ قیمت.
const statusCellStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 2,
  alignItems: 'flex-start',
  minWidth: 0,
}
const priceNumStyle: React.CSSProperties = {
  fontFamily: 'monospace',
  direction: 'ltr',
  textAlign: 'right',
  fontWeight: 800,
  color: colors.orange,
  whiteSpace: 'nowrap',
  unicodeBidi: 'plaintext',
}
const priceUnitStyle: React.CSSProperties = {
  fontSize: 9,
  color: colors.textMuted,
  whiteSpace: 'nowrap',
}
const actionsStyle: React.CSSProperties = {
  display: 'flex',
  gap: 6,
  alignItems: 'center',
  justifyContent: 'flex-start',
  flexShrink: 0,
  whiteSpace: 'nowrap',
}
const iconBtnStyle: React.CSSProperties = {
  width: 28,
  height: 28,
  borderRadius: radius.sm,
  border: `1px solid ${colors.borderSubtle}`,
  background: colors.bgPage,
  color: colors.textMuted,
  cursor: 'pointer',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: 12,
  flexShrink: 0,
  padding: 0,
}
const actionBtnStyle: React.CSSProperties = {
  background: colors.navy,
  color: '#fff',
  border: 'none',
  borderRadius: radius.sm,
  padding: '7px 14px',
  fontSize: fontSize.xs,
  fontWeight: 700,
  textDecoration: 'none',
  whiteSpace: 'nowrap',
}
