'use client'

import { useActionState } from 'react'
import { colors, radius, fontSize } from '@/lib/styles/tokens'
import { enterQueueAction, leaveQueueAction, type QueueActionState } from '@/app/market/actions'
import type { QueueSummary } from '@/lib/reservationQueue'

type Props = {
  itemType: 'SELL' | 'BUY'
  itemId: string
  summary: QueueSummary
  isLoggedIn: boolean
}

export default function ReserveButton({ itemType, itemId, summary, isLoggedIn }: Props) {
  const [enterState, enterAction, enterPending] = useActionState(enterQueueAction, { error: null } as QueueActionState)
  const [leaveState, leaveAction, leavePending] = useActionState(leaveQueueAction, { error: null } as QueueActionState)

  const inQueue = summary.position !== null
  const label = inQueue ? 'خروج از صف' : 'رزرو'
  const action = inQueue ? leaveAction : enterAction
  const pending = inQueue ? leavePending : enterPending
  const error = inQueue ? leaveState.error : enterState.error

  const showPosition = inQueue && summary.label
  // مهمان اصلاً نمی‌تواند وارد صف شود (گیت در action هم throw می‌کند)؛ دکمه خاموش است.
  const disabled = !isLoggedIn || pending
  // قراردادِ action: فیلد `kind` با مقدار 'listing' (آگهی فروش → SELL) یا
  // 'request' (درخواست خرید → BUY) — نه `itemType`. به parseQueueAction نگاه کن.
  const kind = itemType === 'SELL' ? 'listing' : 'request'

  return (
    <div className="mk-action-slot" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <form action={action} className="mk-reserve-form" style={{ flex: 1 }}>
        <input type="hidden" name="kind" value={kind} />
        <input type="hidden" name="itemId" value={itemId} />
        <button type="submit" disabled={disabled} className="mk-press mk-reserve mk-action-btn" style={btnStyle}>
          {pending ? '…' : label}
        </button>
      </form>
      {showPosition && (
        <div className="mk-queue-pos" style={positionStyle} aria-live="polite">
          {summary.label}
        </div>
      )}
      {error && (
        <div className="mk-queue-err" style={errorStyle} role="alert">
          {error}
        </div>
      )}
    </div>
  )
}

const btnStyle: React.CSSProperties = {
  width: '100%',
  padding: '7px 14px',
  fontSize: fontSize.xs,
  fontWeight: 700,
  border: `1px solid ${colors.orange}`,
  borderRadius: radius.sm,
  background: colors.orangeBg,
  color: colors.orangeText,
  cursor: 'pointer',
  whiteSpace: 'nowrap',
}

const positionStyle: React.CSSProperties = {
  fontSize: fontSize.xs,
  color: colors.textSecondary,
  textAlign: 'center',
}

const errorStyle: React.CSSProperties = {
  fontSize: fontSize.xs,
  color: colors.dangerText,
  background: colors.dangerBg,
  padding: '4px 8px',
  borderRadius: radius.sm,
  textAlign: 'center',
}
