'use client'

import { useEffect, useState, type ReactNode } from 'react'

export default function MarketFilterSheet({ children, activeCount }: { children: ReactNode; activeCount: number }) {
  const [open, setOpen] = useState(false)
  const [enhanced, setEnhanced] = useState(false)

  useEffect(() => setEnhanced(true), [])
  useEffect(() => {
    if (!open) return
    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setOpen(false)
    }
    document.addEventListener('keydown', onKeyDown)
    return () => {
      document.body.style.overflow = previousOverflow
      document.removeEventListener('keydown', onKeyDown)
    }
  }, [open])

  return (
    <div className={enhanced ? 'mk-filter-enhanced' : ''} data-open={open}>
      <button type="button" className="mk-filter-toggle" onClick={() => setOpen(true)} aria-expanded={open} aria-controls="mk-filter-panel">
        فیلترها{activeCount ? ` (${activeCount.toLocaleString('fa-IR')})` : ''}
      </button>
      {open && <button type="button" className="mk-filter-scrim" aria-label="بستن فیلترها" onClick={() => setOpen(false)} />}
      <div id="mk-filter-panel" className="mk-filter-panel" role={open ? 'dialog' : undefined} aria-modal={open ? true : undefined} aria-label="فیلترهای بازار">
        <div className="mk-filter-heading">
          <strong>فیلترهای بازار</strong>
          <button type="button" onClick={() => setOpen(false)} aria-label="بستن فیلترها">✕</button>
        </div>
        {children}
      </div>
    </div>
  )
}
