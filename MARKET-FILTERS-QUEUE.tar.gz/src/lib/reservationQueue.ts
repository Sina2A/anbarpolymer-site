/**
 * صف رزرو (Reservation Queue) — هسته‌ی مکانیکِ صف انتظار برای موارد رزروشده‌ی بازار.
 *
 * وقتی یک آگهی فروش (MaterialListing) یا درخواست خرید (PurchaseRequest) رزرو می‌شود،
 * بقیه‌ی کاربران می‌توانند پشت آن در صف بایستند (FIFO بر اساس enteredAt). اگر معامله‌ی
 * فعلی لغو/رد/منقضی شود، مورد مستقیم به لیست فعال برنمی‌گردد؛ «نفر بعدیِ صف» برای یک
 * پنجره‌ی ۱ ساعته مطلع می‌شود (claim). اگر در آن پنجره پیشنهاد ندهد، claim منقضی می‌شود،
 * به او «نوبتت تمام شد» اعلام می‌شود و نفر بعدی مطلع می‌شود؛ وقتی صف خالی شد، مورد به
 * لیست فعال/باز برمی‌گردد.
 *
 * قراردادهای مهم (invariantها):
 *  - در تمام مدتِ claim، خودِ مورد reserved می‌ماند. انحصارِ نفرِ مطلع‌شده در لحظه‌ی ثبتِ
 *    پیشنهاد با consumeClaimInTx اعمال می‌شود (فقط نفرِ notified با claimExpiresAt>اکنون).
 *  - «آزادشدنِ» مورد (لغو/رد/انقضای معامله) همیشه از releaseItemInTx رد می‌شود که داخلِ
 *    همان تراکنشِ لغو اجرا می‌شود (اتمیک با لغو). اعلان‌ها فقط بعد از commit و با
 *    notifyPromoted فرستاده می‌شوند — هیچ‌وقت داخل تراکنش.
 *  - انقضای claim توسط کرانِ deadline (enforceReservationQueueClaims) به‌صورت idempotent
 *    اعمال می‌شود. منبع حقیقتِ زمان‌بندی ستون‌های Postgres است (enteredAt / claimExpiresAt).
 *  - queueRunId هر «نسل» از صف را از نسل بعدی جدا می‌کند: با اولین ورود پشت یک موردِ
 *    رزروشده یک runId تازه ساخته می‌شود و تا وقتی آن نسل تمام نشده (به pool برنگشته)
 *    همان runId استفاده می‌شود.
 *
 * لایه‌ی اعلان (Novu) عمداً fail-safe و env-driven است (کپیِ الگوی src/lib/sms.ts):
 * تا وقتی سرویس واقعی وصل نشده، stub در لاگ می‌نویسد و هیچ‌وقت throw نمی‌کند — یعنی
 * یک خطای اعلان هرگز جریان رزرو/لغو را خراب نمی‌کند.
 *
 * این ماژول prisma و @novu/api را وارد می‌کند؛ از هیچ Client Component ایمپورتش نکن
 * (برای تایپ‌ها فقط `import type`).
 */

import { randomUUID } from 'node:crypto'
import { Novu } from '@novu/api'
import prisma from './prisma'
import { logEvent } from './logger'

// ---------------------------------------------------------------------------
// انواع و ثابت‌ها
// ---------------------------------------------------------------------------

/** 'SELL' → MaterialListing (validityStatus)، 'BUY' → PurchaseRequest (status). */
export type ReservationItemType = 'SELL' | 'BUY'

export function isReservationItemType(v: string): v is ReservationItemType {
  return v === 'SELL' || v === 'BUY'
}

/** پنجره‌ی فرصتِ نفر مطلع‌شده برای ثبت پیشنهاد: ۱ ساعت. */
export const CLAIM_TTL_MS = 60 * 60 * 1000

/** شناسه‌ی workflow اعلانِ «نوبتت رسید» در Novu. */
export const NOVU_EVENT_RESERVATION_CLAIM = 'reservation-claim-available'

/** شناسه‌ی workflow اعلانِ «نوبتت تمام شد» (پس از ۱ ساعتِ بی‌پاسخ) در Novu. */
export const NOVU_EVENT_RESERVATION_EXPIRED = 'reservation-claim-expired'

/** وضعیتِ «در دسترس» هر نوع مورد (که مورد وقتی صف خالی شد به آن برمی‌گردد). */
const ITEM_ACTIVE_STATUS: Record<ReservationItemType, string> = { SELL: 'active', BUY: 'open' }

/** برچسبِ عمومیِ اعلان وقتی جزئیاتِ مورد در دسترس نیست (بدون داده‌ی ساختگی). */
const GENERIC_ITEM_LABEL: Record<ReservationItemType, string> = { SELL: 'آگهی فروش', BUY: 'درخواست خرید' }

const QUEUE_CATEGORY = 'reservation_queue'

/** وضعیت‌های «فعالِ» یک ردیف صف (کسی که هنوز در صف زنده است). */
const LIVE_ENTRY_STATUSES = ['waiting', 'notified'] as const

/** سقفِ انتظار برای پاسخِ Novu؛ یک Novuِ کند نباید اکشن‌های کاربر یا کران را معطل کند. */
const NOVU_TIMEOUT_MS = 8000

// کلاینتِ پایه و کلاینتِ داخل تراکنش هر دو همین delegateها را دارند، پس این Pick
// برای هر دو کار می‌کند (بدون وارد کردن تایپ‌های داخلیِ Prisma).
export type Db = Pick<typeof prisma, 'reservationQueueEntry' | 'materialListing' | 'purchaseRequest' | 'deal'>

const FA_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹']
function faNum(n: number): string {
  return String(n).replace(/[0-9]/g, (d) => FA_DIGITS[Number(d)])
}

function positionLabel(position: number, total: number): string {
  return `نفر ${faNum(position)} از ${faNum(total)}`
}

// ---------------------------------------------------------------------------
// کمکی‌های سطح‌پایین روی موردِ هدف (آگهی فروش یا درخواست خرید)
// ---------------------------------------------------------------------------

async function loadItemStatus(db: Db, itemType: ReservationItemType, itemId: string): Promise<string | null> {
  if (itemType === 'SELL') {
    const l = await db.materialListing.findUnique({ where: { id: itemId }, select: { validityStatus: true } })
    return l?.validityStatus ?? null
  }
  const r = await db.purchaseRequest.findUnique({ where: { id: itemId }, select: { status: true } })
  return r?.status ?? null
}

async function loadItemOwner(db: Db, itemType: ReservationItemType, itemId: string): Promise<string | null> {
  if (itemType === 'SELL') {
    const l = await db.materialListing.findUnique({ where: { id: itemId }, select: { userId: true } })
    return l?.userId ?? null
  }
  const r = await db.purchaseRequest.findUnique({ where: { id: itemId }, select: { userId: true } })
  return r?.userId ?? null
}

/**
 * تغییر وضعیتِ موردِ هدف به‌صورت اتمیک و شرطی (from → to). count برمی‌گرداند؛
 * اگر مورد دیگر در وضعیت from نباشد (مثلاً کسی زودتر تغییرش داده)، count صفر است.
 */
async function setItemStatus(
  db: Db,
  itemType: ReservationItemType,
  itemId: string,
  from: string,
  to: string,
): Promise<number> {
  if (itemType === 'SELL') {
    const r = await db.materialListing.updateMany({
      where: { id: itemId, validityStatus: from },
      data: { validityStatus: to },
    })
    return r.count
  }
  const r = await db.purchaseRequest.updateMany({
    where: { id: itemId, status: from },
    data: { status: to },
  })
  return r.count
}

/** runId نسلِ زنده‌ی فعلیِ صف برای این مورد را برمی‌گرداند (یا null اگر صف زنده‌ای نیست). */
async function currentRunId(db: Db, itemType: ReservationItemType, itemId: string): Promise<string | null> {
  const live = await db.reservationQueueEntry.findFirst({
    where: { itemType, itemId, status: { in: [...LIVE_ENTRY_STATUSES] } },
    orderBy: { enteredAt: 'asc' },
    select: { queueRunId: true },
  })
  return live?.queueRunId ?? null
}

/**
 * برچسبِ خوانا برای متنِ اعلان (آگهی‌ها فیلد عنوان ندارند، پس از گرید و مقدار ساخته می‌شود).
 * fail-safe است: روی هر خطا برچسبِ عمومی برمی‌گرداند و هیچ‌وقت throw نمی‌کند.
 * فقط بعد از commit و با کلاینتِ سراسری صدا زده می‌شود.
 */
async function loadItemLabel(itemType: ReservationItemType, itemId: string): Promise<string> {
  try {
    const select = { quantityTon: true, grade: { select: { code: true, producer: true } } } as const
    const row =
      itemType === 'SELL'
        ? await prisma.materialListing.findUnique({ where: { id: itemId }, select })
        : await prisma.purchaseRequest.findUnique({ where: { id: itemId }, select })
    if (!row) return GENERIC_ITEM_LABEL[itemType]
    return `${row.grade.producer} ${row.grade.code} — ${row.quantityTon.toLocaleString('fa-IR')} تن`
  } catch {
    return GENERIC_ITEM_LABEL[itemType]
  }
}

/** لینکِ عمیقِ مورد در بازار (صفحه‌ی جزئیاتِ جدا وجود ندارد؛ /market آیتم را هایلایت می‌کند). */
export function reservationItemUrl(itemType: ReservationItemType, itemId: string): string {
  const view = itemType === 'SELL' ? 'supply' : 'demand'
  return `/market?view=${view}&item=${encodeURIComponent(itemId)}`
}

/**
 * موردِ رزروشده‌ی یک معامله: معامله‌ی BUY ⇒ درخواست خرید، در غیر این صورت آگهی فروش
 * (معامله‌های قدیمیِ بدون tradeDirection همان SELL حساب می‌شوند — هم‌راستا با
 * `deal.tradeDirection || 'SELL'` در my-deals/actions). null اگر به هیچ موردی متصل نیست.
 */
export function dealItemRef(deal: {
  tradeDirection: string | null
  materialListingId: string | null
  purchaseRequestId: string | null
}): { itemType: ReservationItemType; itemId: string } | null {
  if (deal.tradeDirection === 'BUY') {
    return deal.purchaseRequestId ? { itemType: 'BUY', itemId: deal.purchaseRequestId } : null
  }
  return deal.materialListingId ? { itemType: 'SELL', itemId: deal.materialListingId } : null
}

// ---------------------------------------------------------------------------
// ورود/خروج/جایگاه در صف
// ---------------------------------------------------------------------------

/**
 * ورود کاربر به صفِ یک موردِ رزروشده. گیت‌های KYC/محدودیت در لایه‌ی server action
 * اعمال می‌شوند (هم‌راستا با createDealFromListingAction)؛ اینجا فقط مکانیک صف است.
 * ردیفِ تکراری ساخته نمی‌شود (اگر کاربر از قبل در صفِ زنده باشد، همان ردیف برمی‌گردد).
 */
export async function enterQueue(itemType: ReservationItemType, itemId: string, userId: string) {
  return prisma.$transaction(async (tx) => {
    const status = await loadItemStatus(tx, itemType, itemId)
    if (status === null) throw new Error('این مورد دیگر موجود نیست.')

    const activeStatus = ITEM_ACTIVE_STATUS[itemType]
    if (status === activeStatus) {
      throw new Error('این مورد هم‌اکنون در دسترس است؛ می‌توانید مستقیم پیشنهاد دهید.')
    }
    if (status !== 'reserved') {
      throw new Error('این مورد دیگر قابل رزرو نیست.')
    }

    const ownerId = await loadItemOwner(tx, itemType, itemId)
    if (ownerId === userId) {
      throw new Error('نمی‌توانید برای موردِ خودتان در صف رزرو قرار بگیرید.')
    }

    // طرفِ معامله‌ی جاریِ همین مورد (مثلاً پذیرنده‌ای که همین الان آن را رزرو کرده) پشت
    // خودش در صف نمی‌ایستد.
    const partyDeal = await tx.deal.findFirst({
      where: {
        ...(itemType === 'SELL' ? { materialListingId: itemId } : { purchaseRequestId: itemId }),
        status: { notIn: ['cancelled', 'rejected'] },
        OR: [{ requesterId: userId }, { acceptorId: userId }, { buyerId: userId }, { sellerId: userId }],
      },
      select: { id: true },
    })
    if (partyDeal) throw new Error('شما هم‌اکنون طرفِ معامله‌ی جاریِ این مورد هستید.')

    // معامله‌ی تسویه‌شده = مورد فروخته شده (وضعیتِ خودِ مورد 'reserved' می‌ماند)؛ صف برایش معنا ندارد.
    const sold = await tx.deal.findFirst({
      where: {
        ...(itemType === 'SELL' ? { materialListingId: itemId } : { purchaseRequestId: itemId }),
        status: 'settled',
      },
      select: { id: true },
    })
    if (sold) throw new Error('این مورد فروخته شده است.')

    const runId = (await currentRunId(tx, itemType, itemId)) ?? randomUUID()

    const existing = await tx.reservationQueueEntry.findFirst({
      where: { itemType, itemId, queueRunId: runId, userId, status: { in: [...LIVE_ENTRY_STATUSES] } },
    })
    if (existing) return existing

    return tx.reservationQueueEntry.create({
      data: { itemType, itemId, userId, queueRunId: runId, status: 'waiting' },
    })
  })
}

/**
 * خروج داوطلبانه از صف. اگر کاربر «نفرِ مطلع‌شده» (claim فعال) بوده، بعد از خروجش
 * نفر بعدی مطلع می‌شود (advance). اگر فقط در حال انتظار بوده، صف بدون تغییرِ claim می‌ماند.
 */
export async function leaveQueue(itemType: ReservationItemType, itemId: string, userId: string) {
  const result = await prisma.$transaction(async (tx) => {
    const runId = await currentRunId(tx, itemType, itemId)
    if (!runId) return { left: false, wasNotified: false }

    const entry = await tx.reservationQueueEntry.findFirst({
      where: { itemType, itemId, queueRunId: runId, userId, status: { in: [...LIVE_ENTRY_STATUSES] } },
      select: { id: true, status: true },
    })
    if (!entry) return { left: false, wasNotified: false }

    const upd = await tx.reservationQueueEntry.updateMany({
      where: { id: entry.id, status: { in: [...LIVE_ENTRY_STATUSES] } },
      data: { status: 'declined', declinedAt: new Date() },
    })
    return { left: upd.count > 0, wasNotified: entry.status === 'notified' }
  })

  await logEvent({
    level: 'info',
    category: QUEUE_CATEGORY,
    message: 'left queue',
    userId,
    meta: { itemType, itemId, wasNotified: result.wasNotified },
  })

  // اگر نفرِ مطلع‌شده صف را ترک کرد، نوبت باید به نفر بعدی برود.
  if (result.left && result.wasNotified) {
    await advanceQueue(itemType, itemId)
  }
  return result
}

/**
 * جایگاه کاربر در صفِ زنده به‌صورت «نفر X از Y» (اعداد فارسی). null یعنی در صف نیست.
 */
export async function getQueuePosition(
  itemType: ReservationItemType,
  itemId: string,
  userId: string,
): Promise<{ position: number; total: number; label: string; status: string } | null> {
  const runId = await currentRunId(prisma, itemType, itemId)
  if (!runId) return null

  const mine = await prisma.reservationQueueEntry.findFirst({
    where: { itemType, itemId, queueRunId: runId, userId, status: { in: [...LIVE_ENTRY_STATUSES] } },
    select: { enteredAt: true, status: true },
  })
  if (!mine) return null

  const total = await prisma.reservationQueueEntry.count({
    where: { itemType, itemId, queueRunId: runId, status: { in: [...LIVE_ENTRY_STATUSES] } },
  })
  const position = await prisma.reservationQueueEntry.count({
    where: {
      itemType,
      itemId,
      queueRunId: runId,
      status: { in: [...LIVE_ENTRY_STATUSES] },
      enteredAt: { lte: mine.enteredAt },
    },
  })

  return { position, total, label: positionLabel(position, total), status: mine.status }
}

/** خلاصه‌ی صفِ یک مورد برای رندرِ لیست (کاملاً serializable — مستقیم به Client Component پاس می‌شود). */
export type QueueSummary = {
  /** تعدادِ افرادِ زنده در صف (waiting + notified). */
  total: number
  /** جایگاهِ بیننده (۱-مبنا) یا null اگر در صف نیست. */
  position: number | null
  /** «نفر X از Y» برای بیننده یا null. */
  label: string | null
  /** وضعیتِ ردیفِ بیننده: 'waiting' | 'notified' | null. */
  status: string | null
  /** پایانِ پنجره‌ی ۱ ساعته‌ی بیننده (ISO) — فقط وقتی status='notified'. */
  claimExpiresAt: string | null
}

/**
 * خلاصه‌ی صف برای چند مورد با «یک» کوئری (بدون N+1). برای هر itemId حتماً یک کلید
 * برمی‌گرداند (موارد بدون صف total=۰). فقط نسلِ زنده‌ی هر مورد شمرده می‌شود.
 */
export async function getQueueSummaries(
  itemType: ReservationItemType,
  itemIds: string[],
  userId: string | null,
): Promise<Record<string, QueueSummary>> {
  const out: Record<string, QueueSummary> = {}
  for (const id of itemIds) {
    out[id] = { total: 0, position: null, label: null, status: null, claimExpiresAt: null }
  }
  if (itemIds.length === 0) return out

  const live = await prisma.reservationQueueEntry.findMany({
    where: { itemType, itemId: { in: itemIds }, status: { in: [...LIVE_ENTRY_STATUSES] } },
    orderBy: { enteredAt: 'asc' },
    select: { itemId: true, userId: true, status: true, queueRunId: true, claimExpiresAt: true },
  })

  // اولین ردیفِ زنده‌ی هر مورد (به‌ترتیب enteredAt) نسلِ فعلی را تعیین می‌کند.
  const runByItem = new Map<string, string>()
  for (const e of live) {
    const summary = out[e.itemId]
    if (!summary) continue

    const run = runByItem.get(e.itemId)
    if (run === undefined) runByItem.set(e.itemId, e.queueRunId)
    else if (run !== e.queueRunId) continue

    summary.total += 1
    if (userId && e.userId === userId) {
      summary.position = summary.total
      summary.status = e.status
      summary.claimExpiresAt = e.claimExpiresAt ? e.claimExpiresAt.toISOString() : null
    }
  }

  for (const summary of Object.values(out)) {
    if (summary.position !== null) summary.label = positionLabel(summary.position, summary.total)
  }
  return out
}

// ---------------------------------------------------------------------------
// پیشرویِ صف: مطلع‌کردن نفر بعدی یا برگرداندن مورد به pool
// ---------------------------------------------------------------------------

export type PromoteResult = {
  promoted: { userId: string; notificationTransactionId: string; claimExpiresAt: Date } | null
  finished: boolean
  returnedToPool?: boolean
}

/**
 * «آزادکردنِ مورد» به‌صورت queue-aware — تنها مسیرِ مجازِ برگرداندنِ یک موردِ رزروشده
 * به بازار. داخل تراکنشِ فراخوان اجرا می‌شود (فقط DB، بدون شبکه) تا با لغو/رد/انقضای
 * معامله اتمیک باشد؛ بعد از commit باید notifyPromoted صدا زده شود.
 *
 *  - اگر نفر بعدیِ waiting وجود داشته باشد: او notified می‌شود (claimExpiresAt = اکنون + ۱ ساعت
 *    و یک transactionId برای idempotencyِ اعلان) و مورد reserved می‌ماند.
 *  - اگر waiting‌ای نمانده باشد: مورد (شرطیِ from → active/open) به pool برمی‌گردد.
 *
 * from وضعیتِ فعلیِ مورد است: 'reserved' برای مسیرهای عادی، یا وضعیتِ «پنهان»
 * (needs_reverification / needs_review) وقتی ادمین دوباره تاییدش می‌کند؛ در آن حالت
 * اگر کسی در صف منتظر باشد مورد ابتدا به reserved برمی‌گردد و نوبتِ اولین نفر باز می‌شود.
 */
export async function releaseItemInTx(
  tx: Db,
  itemType: ReservationItemType,
  itemId: string,
  from: string = 'reserved',
): Promise<PromoteResult> {
  // ۱) تک‌مدعی: تا وقتی claimِ زنده‌ای (notified و نگذشته) هست، کسی را جابه‌جا نکن.
  const liveClaim = await tx.reservationQueueEntry.findFirst({
    where: { itemType, itemId, status: 'notified', claimExpiresAt: { gt: new Date() } },
    select: { id: true },
  })
  if (liveClaim) return { promoted: null, finished: false }

  // ۲) فراخوانِ کهنه: مورد دیگر reserved نیست (قبلاً آزاد/بسته شده) → کاری نکن.
  if (from === 'reserved') {
    const status = await loadItemStatus(tx, itemType, itemId)
    if (status !== 'reserved') return { promoted: null, finished: false }
  }

  let current = from
  // حلقه‌ی محدود: اگر نفرِ انتخاب‌شده هم‌زمان از صف خارج شد (waiting→notified شکست خورد)،
  // نفر بعدی را امتحان می‌کنیم تا مورد در حالت reservedِ بی‌صاحب گیر نکند.
  for (let attempt = 0; attempt < 3; attempt++) {
    const runId = await currentRunId(tx, itemType, itemId)
    if (!runId) break

    const next = await tx.reservationQueueEntry.findFirst({
      where: { itemType, itemId, queueRunId: runId, status: 'waiting' },
      orderBy: { enteredAt: 'asc' },
      select: { id: true, userId: true },
    })
    if (!next) break

    if (current !== 'reserved') {
      // خروج از وضعیتِ پنهان: اول reserved (نگه‌داشتن برای نفرِ صف)، نه مستقیم active/open.
      const flipped = await setItemStatus(tx, itemType, itemId, current, 'reserved')
      if (flipped === 0) return { promoted: null, finished: false }
      current = 'reserved'
    }

    // مهلتِ کارمزدِ کهنه نباید آگهیِ نگه‌داشته‌شده را (توسط enforceSellerFeeDeadlines) پنهان کند.
    // با ثبتِ پیشنهادِ نفرِ مطلع‌شده، startSellerFeeDeadline مهلتِ تازه می‌گذارد.
    if (itemType === 'SELL') {
      await tx.materialListing.updateMany({ where: { id: itemId }, data: { feeDeadline: null } })
    }

    const claimExpiresAt = new Date(Date.now() + CLAIM_TTL_MS)
    const transactionId = randomUUID()

    // ارتقای شرطی: اگر ردیف بین خواندن و نوشتن از waiting خارج شده باشد، count صفر می‌شود.
    const upd = await tx.reservationQueueEntry.updateMany({
      where: { id: next.id, status: 'waiting' },
      data: { status: 'notified', notifiedAt: new Date(), claimExpiresAt, notificationTransactionId: transactionId },
    })
    if (upd.count > 0) {
      return {
        promoted: { userId: next.userId, notificationTransactionId: transactionId, claimExpiresAt },
        finished: false,
      }
    }
  }

  // کسی در صف نمانده: مورد به pool برمی‌گردد (شرطی، از وضعیتِ فعلی).
  const flipped = await setItemStatus(tx, itemType, itemId, current, ITEM_ACTIVE_STATUS[itemType])
  return { promoted: null, finished: true, returnedToPool: flipped > 0 }
}

/**
 * اعلانِ بعد از commit برای نتیجه‌ی releaseItemInTx. اگر نفر بعدی مطلع شده باشد به او
 * «نوبتت رسید» می‌فرستد؛ اگر صف تمام شده باشد فقط لاگ می‌کند. هیچ‌وقت throw نمی‌کند.
 */
export async function notifyPromoted(
  itemType: ReservationItemType,
  itemId: string,
  res: PromoteResult,
): Promise<void> {
  if (res.promoted) {
    const itemLabel = await loadItemLabel(itemType, itemId)
    await triggerReservationNotification({
      subscriberId: res.promoted.userId,
      event: NOVU_EVENT_RESERVATION_CLAIM,
      transactionId: res.promoted.notificationTransactionId,
      payload: {
        itemType,
        itemId,
        itemLabel,
        url: reservationItemUrl(itemType, itemId),
        claimExpiresAt: res.promoted.claimExpiresAt.toISOString(),
      },
    })
    await logEvent({
      level: 'info',
      category: QUEUE_CATEGORY,
      message: 'next claimant notified',
      userId: res.promoted.userId,
      meta: { itemType, itemId },
    })
  } else if (res.finished) {
    await logEvent({
      level: 'info',
      category: QUEUE_CATEGORY,
      message: 'queue finished — item returned to pool',
      meta: { itemType, itemId, returnedToPool: res.returnedToPool ?? false },
    })
  }
}

/**
 * پیشرویِ صف با کلاینتِ سراسری (تراکنشِ خودش) + اعلان. برای مسیرهایی که تراکنشِ
 * بیرونی ندارند (مثل خروجِ نفرِ مطلع‌شده از صف)؛ seamهای لغو از releaseItemInTx استفاده می‌کنند.
 */
export async function advanceQueue(itemType: ReservationItemType, itemId: string): Promise<PromoteResult> {
  const res = await prisma.$transaction((tx) => releaseItemInTx(tx, itemType, itemId))
  await notifyPromoted(itemType, itemId, res)
  return res
}

/**
 * ثبتِ پیشنهادِ نفرِ مطلع‌شده (داخل تراکنشِ ساختِ Deal): ردیفِ او به‌صورت شرطی از
 * notified به accepted می‌رود، و فقط اگر پنجره‌ی ۱ ساعته هنوز باز باشد. true یعنی این
 * کاربر «مدعیِ معتبر» است و می‌تواند مورد reservedِ نگه‌داشته‌شده را بگیرد.
 * بقیه‌ی صف در همان نسل می‌ماند تا اگر این معامله هم آزاد شد، نوبت به نفر بعدی برسد.
 */
export async function consumeClaimInTx(
  tx: Db,
  itemType: ReservationItemType,
  itemId: string,
  userId: string,
): Promise<boolean> {
  const upd = await tx.reservationQueueEntry.updateMany({
    where: { itemType, itemId, userId, status: 'notified', claimExpiresAt: { gt: new Date() } },
    data: { status: 'accepted', acceptedAt: new Date() },
  })
  return upd.count > 0
}

/**
 * بستنِ کاملِ نسلِ فعلیِ صف (داخل تراکنشِ فراخوان) — وقتی مورد به‌طور دائم از دسترس
 * خارج می‌شود (فروخته/تکمیل/کنسل)، یا وقتی یک رزروِ تازه از pool شروع می‌شود تا ردیفِ
 * کهنه‌ی نسلِ قبل باقی نماند. همه‌ی ردیف‌های زنده expired می‌شوند. وضعیتِ خودِ مورد را
 * دست نمی‌زند (فراخوان مسئول completed/cancelled کردن آن است).
 */
export async function closeRunInTx(
  tx: Db,
  itemType: ReservationItemType,
  itemId: string,
): Promise<{ closed: number }> {
  const r = await tx.reservationQueueEntry.updateMany({
    where: { itemType, itemId, status: { in: [...LIVE_ENTRY_STATUSES] } },
    data: { status: 'expired', expiredAt: new Date() },
  })
  return { closed: r.count }
}

/** closeRunInTx با کلاینتِ سراسری + لاگ (برای مسیرهای بدون تراکنشِ بیرونی). */
export async function closeRun(itemType: ReservationItemType, itemId: string): Promise<{ closed: number }> {
  const res = await closeRunInTx(prisma, itemType, itemId)
  if (res.closed > 0) {
    await logEvent({
      level: 'info',
      category: QUEUE_CATEGORY,
      message: 'queue run closed',
      meta: { itemType, itemId, closed: res.closed },
    })
  }
  return res
}

/**
 * اعمالِ انقضای claimها — توسط کرانِ deadline صدا زده می‌شود (idempotent). هر ردیفِ
 * notified که claimExpiresAt‌اش گذشته در یک تراکنش expired می‌شود و همان‌جا صفِ مورد یک
 * قدم جلو می‌رود (نفر بعدی یا برگشت به pool)؛ بعد از commit به نفرِ منقضی‌شده «نوبتت
 * تمام شد» و به نفر بعدی «نوبتت رسید» اعلام می‌شود. فراخوانیِ دوباره بی‌اثر است
 * (شرطِ status='notified'). خطا در یک مورد بقیه را متوقف نمی‌کند.
 */
export async function enforceReservationQueueClaims(): Promise<{
  expiredClaims: number
  advanced: number
  returnedToPool: number
}> {
  const now = new Date()

  const expiredCandidates = await prisma.reservationQueueEntry.findMany({
    where: { status: 'notified', claimExpiresAt: { lt: now } },
    orderBy: { claimExpiresAt: 'asc' },
    select: { id: true, itemType: true, itemId: true, userId: true },
  })

  let expiredClaims = 0
  let advanced = 0
  let returnedToPool = 0

  for (const e of expiredCandidates) {
    if (!isReservationItemType(e.itemType)) continue
    const itemType = e.itemType

    try {
      // انقضای شرطی + پیشروی در یک تراکنش: اگر بینِ خواندن و نوشتن claim پذیرفته/رد شده
      // باشد، count صفر می‌شود و این ردیف رد می‌شود (idempotent).
      const res = await prisma.$transaction(async (tx) => {
        const upd = await tx.reservationQueueEntry.updateMany({
          where: { id: e.id, status: 'notified', claimExpiresAt: { lt: now } },
          data: { status: 'expired', expiredAt: new Date() },
        })
        if (upd.count === 0) return null
        return releaseItemInTx(tx, itemType, e.itemId)
      })
      if (!res) continue

      expiredClaims++
      await logEvent({
        level: 'info',
        category: QUEUE_CATEGORY,
        message: 'claim expired',
        userId: e.userId,
        meta: { itemType, itemId: e.itemId },
      })

      const itemLabel = await loadItemLabel(itemType, e.itemId)
      await triggerReservationNotification({
        subscriberId: e.userId,
        event: NOVU_EVENT_RESERVATION_EXPIRED,
        transactionId: `expired-${e.id}`,
        payload: { itemType, itemId: e.itemId, itemLabel, url: reservationItemUrl(itemType, e.itemId) },
      })

      await notifyPromoted(itemType, e.itemId, res)
      if (res.promoted) advanced++
      if (res.returnedToPool) returnedToPool++
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err)
      await logEvent({
        level: 'error',
        category: QUEUE_CATEGORY,
        message: 'claim expiry failed',
        userId: e.userId,
        meta: { entryId: e.id, itemType, itemId: e.itemId, error: msg },
      })
      try {
        await prisma.reservationQueueEntry.updateMany({
          where: { id: e.id },
          data: { lastError: msg },
        })
      } catch {
        // نادیده
      }
    }
  }

  return { expiredClaims, advanced, returnedToPool }
}

// ---------------------------------------------------------------------------
// لایه‌ی اعلان (Novu) — fail-safe و env-driven (کپیِ الگوی src/lib/sms.ts).
// تا وقتی سرویسِ واقعی وصل نشده، stub در لاگ می‌نویسد و هیچ‌وقت throw نمی‌کند.
// ---------------------------------------------------------------------------

export type NotifyResult = { success: boolean; error?: string }

type ReservationNotifyParams = {
  subscriberId: string
  event: string
  transactionId: string
  payload?: Record<string, unknown>
}

async function triggerViaStub(params: ReservationNotifyParams): Promise<NotifyResult> {
  // eslint-disable-next-line no-console
  console.log(
    `[NOVU STUB — سرویس اعلان واقعی وصل نشده] event=${params.event} subscriber=${params.subscriberId} tx=${params.transactionId}`,
  )
  return { success: true }
}

async function triggerViaNovu(params: ReservationNotifyParams): Promise<NotifyResult> {
  // Novuِ خودمیزبان: بدون NOVU_API_URL، SDK به آدرسِ پیش‌فرضِ ابریِ Novu می‌رود که برای
  // این استقرار اشتباه است؛ پس صریحاً خطا می‌دهیم.
  const serverURL = process.env.NOVU_API_URL
  if (!serverURL) return { success: false, error: 'NOVU_API_URL تنظیم نشده است.' }

  const novu = new Novu({ secretKey: process.env.NOVU_SECRET_KEY, serverURL, timeoutMs: NOVU_TIMEOUT_MS })
  const { result } = await novu.trigger({
    workflowId: params.event,
    to: { subscriberId: params.subscriberId },
    payload: params.payload ?? {},
    // idempotency — Novu بر اساس همین transactionId اعلانِ تکراری را نادیده می‌گیرد.
    transactionId: params.transactionId,
    // arg2 = idempotencyKey (استفاده نمی‌کنیم؛ transactionId خودش idempotency می‌دهد).
  }, undefined, {
    // retries:'none' → یک تلاش؛ جلوی retry خودکارِ SDK برای یک اعلانِ صف.
    // کرانِ کلی را enforceReservationQueueClaims اعمال می‌کند؛ اینجا فقط مطمئن
    // می‌شویم یک ارسالِ ناموفق claim را طولانی نگه نمی‌دارد (fail-safe: شکست
    // در لاگ warn می‌نشیند و جریانِ رزرو ادامه می‌یابد).
    retries: { strategy: 'none' },
  })

  if (result.acknowledged && result.status === 'processed') return { success: true }
  const detail = result.error && result.error.length > 0 ? ` — ${result.error.join('؛ ')}` : ''
  return { success: false, error: `Novu: ${result.status}${detail}` }
}

async function triggerViaProvider(params: ReservationNotifyParams): Promise<NotifyResult> {
  // فقط وقتی کلید ست شده باشد سراغِ سرویسِ واقعی می‌رویم؛ در غیر این صورت stub.
  if (!process.env.NOVU_SECRET_KEY) return triggerViaStub(params)

  switch (process.env.NOTIFICATION_PROVIDER) {
    case 'novu':
      return triggerViaNovu(params)
    default:
      return triggerViaStub(params)
  }
}

/**
 * ارسالِ اعلانِ رزرو. transactionId برای idempotency است (ارسالِ دوباره با همان
 * transactionId، اعلانِ تکراری نمی‌سازد). هیچ‌وقت throw نمی‌کند؛ شکست فقط در لاگ
 * (سطح warn) می‌نشیند تا بی‌صدا گم نشود.
 */
export async function triggerReservationNotification(params: ReservationNotifyParams): Promise<NotifyResult> {
  let result: NotifyResult
  try {
    result = await triggerViaProvider(params)
  } catch (e) {
    // یک خطای اعلان هرگز نباید جریانِ رزرو/لغو را خراب کند.
    result = { success: false, error: e instanceof Error ? e.message : 'خطای نامشخص در ارسال اعلان' }
  }

  if (!result.success) {
    await logEvent({
      level: 'warn',
      category: QUEUE_CATEGORY,
      message: 'notification failed',
      userId: params.subscriberId,
      meta: { event: params.event, transactionId: params.transactionId, error: result.error },
    })
    // lastError برای دیباگِ اعلان/کران نگه داشته می‌شود (fail-safe: شکستِ خودش نادیده گرفته می‌شود).
    try {
      await prisma.reservationQueueEntry.updateMany({
        where: { notificationTransactionId: params.transactionId },
        data: { lastError: result.error ?? 'notification failed' },
      })
    } catch {
      // نادیده — خودِ اعلان fail-safe است
    }
  } else {
    try {
      await prisma.reservationQueueEntry.updateMany({
        where: { notificationTransactionId: params.transactionId },
        data: { lastError: null },
      })
    } catch {
      // نادیده
    }
  }
  return result
}
