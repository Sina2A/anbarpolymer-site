'use server'

import prisma from '@/lib/prisma'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import { getCurrentUser } from '@/lib/currentUser'
import { requireCompanyVerifiedFor, requireVerifiedProducerFor } from '@/lib/kyc'
import { isUserRestricted, startSellerFeeDeadline } from '@/lib/dealDeadlines'
import { logAudit } from '@/lib/logger'
import {
  enterQueue,
  leaveQueue,
  consumeClaimInTx,
  closeRunInTx,
  type Db,
  type ReservationItemType,
} from '@/lib/reservationQueue'

const LISTING_UNAVAILABLE = 'این آگهی دیگر در دسترس نیست یا رزرو شده است.'
const REQUEST_UNAVAILABLE = 'این درخواست دیگر در دسترس نیست یا رزرو شده است.'

/**
 * دروازه‌ی وضعیتِ رزرو (داخل تراکنشِ فراخوان):
 *  - 'free'  : مورد active/open است؛ فراخوان با رزروِ اتمیکِ عادی (active→reserved / open→reserved) ادامه می‌دهد.
 *  - 'claim' : مورد reserved است و این کاربر «نفرِ مطلع‌شده‌ی صفِ رزرو» با claimِ معتبر بوده؛ claim همین‌جا
 *              مصرف شد (notified→accepted) و مورد از قبل reserved است، پس فراخوان نباید دوباره flip کند.
 *  - هر حالتِ دیگر (reserved بدون claimِ معتبر، یا وضعیتِ دیگر) ⇒ throw با unavailableMessage.
 * مصرفِ claim داخل همان تراکنشِ ساختِ Deal است؛ اگر ادامه‌ی تراکنش خطا بدهد claim هم برمی‌گردد.
 */
async function resolveHoldAccess(
  tx: Db,
  itemType: ReservationItemType,
  itemId: string,
  status: string,
  userId: string,
  unavailableMessage: string,
): Promise<'free' | 'claim'> {
  const freeStatus = itemType === 'SELL' ? 'active' : 'open'
  if (status === freeStatus) return 'free'

  if (status === 'reserved') {
    if (await consumeClaimInTx(tx, itemType, itemId, userId)) return 'claim'
    // consume فقط claimِ نگذشته را می‌گیرد؛ اگر ردیفِ notified هنوز هست یعنی مهلتش تمام شده و
    // کران هنوز جاروش نکرده — پیامِ دقیق‌تر از «در دسترس نیست».
    const lapsed = await tx.reservationQueueEntry.findFirst({
      where: { itemType, itemId, userId, status: 'notified' },
      select: { id: true },
    })
    if (lapsed) throw new Error('مهلتِ ۱ ساعته‌ی نوبتِ شما برای این مورد تمام شده است.')
  }
  throw new Error(unavailableMessage)
}

export async function createDealFromListingAction(formData: FormData) {
  const materialListingId = String(formData.get('materialListingId') || '').trim()
  const quantity = String(formData.get('quantity') || '').trim()
  const offerPriceRaw = String(formData.get('offerPriceToman') || '').trim()
  const notes = String(formData.get('notes') || '').trim()

  if (!materialListingId) throw new Error('آگهی انتخاب نشده است.')

  const user = await getCurrentUser()
  await requireCompanyVerifiedFor(user.id, 'U-KYC1-DEAL')

  const restriction = await isUserRestricted(user.id)
  if (restriction.restricted) throw new Error(restriction.reason || 'حساب کاربری شما موقتاً محدود شده است.')

  // گیت سطح ۲ — اگه گریدِ این آگهی فقط برای تولیدکننده‌ی احرازشده قابل خریده.
  // این فقط یک read پیش از رزروه (هم‌راستا با الگوی findUnique fast-path داخل tx)؛
  // رزرو اتمیک داخل tx بدون تغییر می‌مونه.
  const gateInfo = await prisma.materialListing.findUnique({
    where: { id: materialListingId },
    select: { grade: { select: { requiresProducerVerification: true } } },
  })
  if (gateInfo?.grade?.requiresProducerVerification) {
    await requireVerifiedProducerFor(user.id, 'U-KYC2-PRODUCERGRADE')
  }

  const offerPrice = offerPriceRaw ? Number(offerPriceRaw) : null
  const { deal, claimConsumed } = await prisma.$transaction(async (tx) => {
    const listing = await tx.materialListing.findUnique({ where: { id: materialListingId } })
    if (!listing) throw new Error(LISTING_UNAVAILABLE)

    // active ⇒ رزروِ تازه از pool؛ reserved ⇒ فقط نفرِ مطلع‌شده‌ی صفِ رزرو (claimِ معتبر) می‌تواند بگیرد.
    const access = await resolveHoldAccess(tx, 'SELL', materialListingId, listing.validityStatus, user.id, LISTING_UNAVAILABLE)
    if (listing.userId === user.id) throw new Error('خرید از آگهی خودتان امکان‌پذیر نیست.')

    const agreedPrice = offerPrice !== null && Number.isFinite(offerPrice)
      ? offerPrice
      : listing.askingPriceToman ?? null

    // رزرو اتمیک: شرط validityStatus:'active' داخل WHERE. اگر تراکنش همزمانی
    // زودتر آگهی را reserved کرده باشد، count صفر می‌شود و اینDeal ساخته نمی‌شود.
    // (تحت isolation پیش‌فرض Postgres یعنی READ COMMITTED، تنها همین شرطِ داخل
    //  UPDATE است که race را می‌بندد؛ چکِ findUnique بالاتر فقط fast-path است.)
    // مسیرِ claim (access==='claim') آگهی از قبل reserved است و flip نمی‌شود؛ انحصارش را
    // همان مصرفِ شرطیِ claim در resolveHoldAccess تضمین می‌کند.
    if (access === 'free') {
      const reserved = await tx.materialListing.updateMany({
        where: { id: materialListingId, validityStatus: 'active' },
        data: { validityStatus: 'reserved' },
      })
      if (reserved.count === 0) {
        throw new Error(LISTING_UNAVAILABLE)
      }
      // رزروِ تازه از pool = شروعِ یک نسلِ جدید؛ هر ردیفِ زنده‌ی کهنه‌ی نسلِ قبل (نباید وجود داشته باشد) بسته شود.
      await closeRunInTx(tx, 'SELL', materialListingId)
    }

    // مدل ۴نقشی (v2): این مسیر «خریدار روی آگهی فروش» است ⇒ tradeDirection=SELL.
    // فروشنده (صاحب آگهی) requester است و خریدار (کاربر فعلی) acceptor. نقش‌ها همین‌جا
    // snapshot می‌شوند تا تغییر بعدیِ مالکیت آگهی، طرفین این معامله را جابه‌جا نکند.
    // دو ردیف DealPayment مستقل ساخته می‌شود؛ گیتِ عبور به حمل بر اساس همین ردیف‌هاست نه status.
    const created = await tx.deal.create({
      data: {
        buyerId: user.id,
        sellerId: listing.userId,
        requesterId: listing.userId,
        acceptorId: user.id,
        tradeDirection: 'SELL',
        materialListingId,
        quantity: quantity || `${listing.quantityTon} تن`,
        agreedPrice,
        status: 'draft',
        payments: {
          create: [
            { kind: 'BUYER_GOODS', amount: agreedPrice, status: 'PENDING' },
            { kind: 'SELLER_FEE', amount: null, status: 'PENDING' },
          ],
        },
      },
    })
    return { deal: created, claimConsumed: access === 'claim' }
  })

  void notes
  // برای مسیرِ claim هم لازم است: feeDeadlineِ کهنه موقع نگه‌داشتنِ آگهی پاک شده بود و این‌جا مهلتِ تازه می‌گیرد.
  await startSellerFeeDeadline(materialListingId)
  await logAudit('deal', 'پیشنهاد خرید جدید', user.id, { dealId: deal.id, tradeDirection: 'SELL' })
  if (claimConsumed) {
    await logAudit('reservation_queue', 'claim accepted', user.id, { itemType: 'SELL', itemId: materialListingId, dealId: deal.id })
  }
  revalidatePath('/my-deals')
  redirect('/my-deals')
}

/**
 * مسیر قرینه‌ی بازار دوطرفه: فروشنده یک «درخواست خرید» (PurchaseRequest) را می‌پذیرد.
 * tradeDirection=BUY ⇒ خریدار (ثبت‌کننده‌ی درخواست) requester و فروشنده (کاربر فعلی) acceptor.
 * رزرو race-safe روی همان فیلد status موجودِ PurchaseRequest انجام می‌شود (open → reserved):
 * شرط status:'open' داخل WHEREِ updateMany تنها چیزی است که همزمانی را می‌بندد.
 * درخواستِ reserved فقط برای نفرِ مطلع‌شده‌ی صفِ رزرو (claimِ معتبر) باز است (resolveHoldAccess).
 */
export async function acceptPurchaseRequestAction(formData: FormData) {
  const purchaseRequestId = String(formData.get('purchaseRequestId') || '').trim()
  const quantity = String(formData.get('quantity') || '').trim()
  const offerPriceRaw = String(formData.get('offerPriceToman') || '').trim()
  const notes = String(formData.get('notes') || '').trim()

  if (!purchaseRequestId) throw new Error('درخواست خرید انتخاب نشده است.')

  const user = await getCurrentUser()
  await requireCompanyVerifiedFor(user.id, 'U-KYC1-DEAL')

  const restriction = await isUserRestricted(user.id)
  if (restriction.restricted) throw new Error(restriction.reason || 'حساب کاربری شما موقتاً محدود شده است.')

  const offerPrice = offerPriceRaw ? Number(offerPriceRaw) : null
  const { deal, claimConsumed } = await prisma.$transaction(async (tx) => {
    const request = await tx.purchaseRequest.findUnique({ where: { id: purchaseRequestId } })
    if (!request) throw new Error(REQUEST_UNAVAILABLE)

    // open ⇒ رزروِ تازه از pool؛ reserved ⇒ فقط نفرِ مطلع‌شده‌ی صفِ رزرو (claimِ معتبر) می‌تواند بگیرد.
    const access = await resolveHoldAccess(tx, 'BUY', purchaseRequestId, request.status, user.id, REQUEST_UNAVAILABLE)
    if (request.userId === user.id) throw new Error('پذیرش درخواست خودتان امکان‌پذیر نیست.')

    const agreedPrice = offerPrice !== null && Number.isFinite(offerPrice)
      ? offerPrice
      : request.maxPriceToman ?? null

    // رزرو اتمیک روی status موجود: اگر تراکنش همزمانی زودتر آن را reserved کرده باشد،
    // count صفر می‌شود و این Deal ساخته نمی‌شود. (READ COMMITTED؛ شرطِ داخل UPDATE race را می‌بندد.)
    // مسیرِ claim (access==='claim') درخواست از قبل reserved است و flip نمی‌شود.
    if (access === 'free') {
      const reserved = await tx.purchaseRequest.updateMany({
        where: { id: purchaseRequestId, status: 'open' },
        data: { status: 'reserved' },
      })
      if (reserved.count === 0) {
        throw new Error(REQUEST_UNAVAILABLE)
      }
      // رزروِ تازه از pool = شروعِ یک نسلِ جدید؛ هر ردیفِ زنده‌ی کهنه‌ی نسلِ قبل (نباید وجود داشته باشد) بسته شود.
      await closeRunInTx(tx, 'BUY', purchaseRequestId)
    }

    // BUY: buyer=ثبت‌کننده‌ی درخواست (requester)، seller=کاربر فعلی (acceptor)
    const created = await tx.deal.create({
      data: {
        buyerId: request.userId,
        sellerId: user.id,
        requesterId: request.userId,
        acceptorId: user.id,
        tradeDirection: 'BUY',
        purchaseRequestId,
        quantity: quantity || `${request.quantityTon} تن`,
        agreedPrice,
        status: 'draft',
        payments: {
          create: [
            { kind: 'BUYER_GOODS', amount: agreedPrice, status: 'PENDING' },
            { kind: 'SELLER_FEE', amount: null, status: 'PENDING' },
          ],
        },
      },
    })
    return { deal: created, claimConsumed: access === 'claim' }
  })

  void notes
  await logAudit('deal', 'پذیرش درخواست خرید', user.id, { dealId: deal.id, tradeDirection: 'BUY', purchaseRequestId })
  if (claimConsumed) {
    await logAudit('reservation_queue', 'claim accepted', user.id, { itemType: 'BUY', itemId: purchaseRequestId, dealId: deal.id })
  }
  revalidatePath('/my-deals')
  redirect('/my-deals')
}

// ==================== صف رزرو: ورود / خروج ====================

/**
 * خروجیِ اکشن‌های ورود/خروج برای useActionState (خطای قابل‌نمایش inline زیر دکمه).
 * خطاهای انتظارمحور (مثلاً «هم‌اکنون در دسترس است») اینجا برمی‌گردند؛ گیت‌های دسترسی
 * (KYC) throw می‌کنند تا error.tsxِ برندشده همان CTAِ همیشگی را نشان دهد.
 */
export type QueueActionState = { error: string | null }

/** kind: 'listing' → آگهی فروش (SELL)، 'request' → درخواست خرید (BUY). */
function parseQueueTarget(formData: FormData): { itemType: ReservationItemType; itemId: string } {
  const kind = String(formData.get('kind') || '').trim()
  const itemId = String(formData.get('itemId') || '').trim()
  if (!itemId || (kind !== 'listing' && kind !== 'request')) {
    throw new Error('مورد انتخاب‌شده نامعتبر است.')
  }
  return { itemType: kind === 'listing' ? 'SELL' : 'BUY', itemId }
}

/**
 * ورود به صفِ رزرو (دکمه‌ی «رزرو»). همان گیت‌های پذیرش/خرید: لاگین، KYC سطح ۱،
 * نبودنِ محدودیت، و برای آگهیِ گریدِ مخصوصِ تولیدکننده KYC سطح ۲. نبودنِ مالک/طرفِ
 * معامله‌ی جاری و reservedبودنِ مورد را خودِ enterQueue چک می‌کند.
 */
export async function enterQueueAction(_prev: QueueActionState, formData: FormData): Promise<QueueActionState> {
  const { itemType, itemId } = parseQueueTarget(formData)

  const user = await getCurrentUser()
  await requireCompanyVerifiedFor(user.id, 'U-KYC1-DEAL')

  const restriction = await isUserRestricted(user.id)
  if (restriction.restricted) {
    return { error: restriction.reason || 'حساب کاربری شما موقتاً محدود شده است.' }
  }

  if (itemType === 'SELL') {
    const gateInfo = await prisma.materialListing.findUnique({
      where: { id: itemId },
      select: { grade: { select: { requiresProducerVerification: true } } },
    })
    if (gateInfo?.grade?.requiresProducerVerification) {
      await requireVerifiedProducerFor(user.id, 'U-KYC2-PRODUCERGRADE')
    }
  }

  try {
    await enterQueue(itemType, itemId, user.id)
  } catch (err) {
    return { error: err instanceof Error ? err.message : 'ورود به صف انجام نشد.' }
  }

  revalidatePath('/market')
  return { error: null }
}

/**
 * خروج از صفِ رزرو. عمداً فقط لاگین می‌خواهد: خروج بی‌خطر است و کاربرِ محدودشده یا
 * کاربری که KYCاش عوض شده هم باید بتواند از صف بیرون بیاید. اگر خارج‌شونده «نفرِ مطلع‌شده»
 * بوده باشد، leaveQueue خودش نوبت را به نفر بعدی می‌دهد.
 */
export async function leaveQueueAction(_prev: QueueActionState, formData: FormData): Promise<QueueActionState> {
  const { itemType, itemId } = parseQueueTarget(formData)

  const user = await getCurrentUser()

  try {
    await leaveQueue(itemType, itemId, user.id)
  } catch (err) {
    return { error: err instanceof Error ? err.message : 'خروج از صف انجام نشد.' }
  }

  revalidatePath('/market')
  return { error: null }
}
