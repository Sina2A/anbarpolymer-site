import prisma from '@/lib/prisma'
import { getSurfaceHome } from '@/lib/surfaceHome'
import { getCurrentUserOrNull } from '@/lib/currentUser'
import { getQueueSummaries, type QueueSummary } from '@/lib/reservationQueue'
import SupplyTableRow, { SUPPLY_TABLE_COLUMNS } from '@/components/SupplyTableRow'
import DemandTableRow, { DEMAND_TABLE_COLUMNS } from '@/components/DemandTableRow'
import CurrencyTicker from '@/components/CurrencyTicker'
import PublicHeader from '@/components/PublicHeader'
import Footer from '@/components/Footer'
import MarketFilterSheet from '@/components/MarketFilterSheet'
import { colors, spacing, radius, fontSize, breakpoints } from '@/lib/styles/tokens'
import { inputStyle as sharedInputStyle, selectStyle as sharedSelectStyle, emptyStateStyle } from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

const POLYMER_FAMILY_OPTIONS = ['PP', 'HDPE', 'LDPE', 'LLDPE', 'PVC', 'PET', 'PS', 'EPS', 'ABS', 'سایر']

function one(v: string | string[] | undefined): string | undefined {
  if (Array.isArray(v)) return v[0]
  return v
}

/** ردیف‌های رزروشده می‌روند آخرِ لیست؛ بقیه ترتیبِ ورودیشان حفظ می‌شود (stable).
 *  جنریک با تایپِ صریح — هر دو تب (آگهی و درخواست) از همین یکی استفاده می‌کنند. */
function reservedLast<T>(rows: T[], isReserved: (row: T) => boolean): T[] {
  return [...rows].sort((a, b) => Number(isReserved(a)) - Number(isReserved(b)))
}

/** عددِ فارسی — یک‌جا تعریف می‌شود تا فرمت‌ها در صفحه یکی بمانند. */
const fa = (n: number) => n.toLocaleString('fa-IR')

export default async function MarketPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>
}) {
  const sp = await searchParams
  const q = one(sp.q)?.trim() || ''
  const family = one(sp.family)?.trim() || ''
  const category = one(sp.category)?.trim() || ''
  const applicationType = one(sp.applicationType)?.trim() || ''
  const producer = one(sp.producer)?.trim() || ''
  const province = one(sp.province)?.trim() || ''
  // بازار دوطرفه: تب «عرضه» (آگهی فروشنده‌ها) و تب «تقاضا» (درخواست خرید خریدارها)
  const view = one(sp.view)?.trim() === 'demand' ? 'demand' : 'supply'

  // ── Check auth/KYC level ──
  const user = await getCurrentUserOrNull()
  let kycLevel = 0
  if (user) {
    const comp = await prisma.company.findUnique({
      where: { userId: user.id },
      select: { kyc: { select: { level: true } } },
    })
    kycLevel = comp?.kyc?.level ?? 0
  }

  // ── Build where (تب عرضه) ──
  const where: Record<string, unknown> = { validityStatus: { in: ['active', 'reserved'] } }

  if (q) {
    ;(where as any).OR = [
      { grade: { code: { contains: q, mode: 'insensitive' } } },
      { grade: { producer: { contains: q, mode: 'insensitive' } } },
      { grade: { category: { contains: q, mode: 'insensitive' } } },
    ]
  }
  if (family) where.grade = { ...((where.grade as any) || {}), polymerFamily: family }
  if (category) where.grade = { ...((where.grade as any) || {}), category }
  if (applicationType) where.grade = { ...((where.grade as any) || {}), applicationType }
  if (producer) where.grade = { ...((where.grade as any) || {}), producer }
  if (province) where.province = province

  // ── Query ──
  // NOTE: do NOT include `user` here — the full listing is passed to the
  // <ListingDetailModal> client component and would serialize User.passwordHash
  // (and phone/email) into the public page payload. The modal never uses it.
  const listings = await prisma.materialListing.findMany({
    where: where as any,
    include: { grade: true },
    orderBy: { createdAt: 'desc' },
  })
  const supplyRows = reservedLast(listings, (l) => l.validityStatus === 'reserved')

  // ── Filter options ──
  const [allCategories, allApplicationTypes, allProducers, allProvinces] = await Promise.all([
    prisma.grade.findMany({
      where: { isActive: true },
      distinct: ['category'],
      select: { category: true },
      orderBy: { category: 'asc' },
    }),
    prisma.grade.findMany({
      where: { isActive: true, applicationType: { not: null } },
      distinct: ['applicationType'],
      select: { applicationType: true },
      orderBy: { applicationType: 'asc' },
    }),
    prisma.grade.findMany({
      where: { isActive: true },
      distinct: ['producer'],
      select: { producer: true },
      orderBy: { producer: 'asc' },
    }),
    prisma.materialListing.findMany({
      where: { validityStatus: { in: ['active', 'reserved'] } },
      distinct: ['province'],
      select: { province: true },
      orderBy: { province: 'asc' },
    }),
  ])

  const categories = allCategories.map((r) => r.category)
  const applicationTypes = allApplicationTypes.map((r) => r.applicationType).filter((v): v is string => !!v)
  const producers = allProducers.map((r) => r.producer)
  const provinces = allProvinces.map((r) => r.province)

  // ── تب تقاضا: درخواست‌های خرید باز — حالا با همان فیلترهای تب عرضه ──
  // شمارش همیشه اجرا می‌شه (عددِ روی تب)، لیست کامل فقط وقتی تب تقاضا فعاله.
  // «باز» یعنی status=open و منقضی‌نشده — انقضا تنبل حساب می‌شه، مثل
  // /purchase-requests. درخواست با ساخته‌شدن آگهی بسته نمی‌شه، پس چند
  // فروشنده می‌تونن روی یک درخواست رقابت کنن.
  // فیلترها عین تب عرضه‌اند: q روی کد/تولیدکننده/دسته‌ی گرید، بقیه فیلترها روی
  // grade و province روی خودِ درخواست. چون شرط انقضا خودش OR داره، همه‌ی
  // شرط‌ها داخل AND جمع می‌شن تا OR روی هم نوشته نشه — otherwise the expiry
  // OR would be silently overwritten by the search OR.
  // نکته‌ی امنیتی: include: { user } ممنوعه — این صفحه عمومیه و User شامل
  // passwordHash/phone/email می‌شه؛ همون قاعده‌ی کوئری آگهی‌ها.
  const demandAnd: Record<string, unknown>[] = [
    { OR: [{ expiresAt: null }, { expiresAt: { gte: new Date() } }] },
  ]
  if (q) {
    demandAnd.push({
      OR: [
        { grade: { code: { contains: q, mode: 'insensitive' } } },
        { grade: { producer: { contains: q, mode: 'insensitive' } } },
        { grade: { category: { contains: q, mode: 'insensitive' } } },
      ],
    })
  }
  if (family) demandAnd.push({ grade: { polymerFamily: family } })
  if (category) demandAnd.push({ grade: { category } })
  if (applicationType) demandAnd.push({ grade: { applicationType } })
  if (producer) demandAnd.push({ grade: { producer } })
  const openRequestWhere: Record<string, unknown> = { status: { in: ['open', 'reserved'] }, AND: demandAnd }
  if (province) openRequestWhere.province = province
  const demandCount = await prisma.purchaseRequest.count({ where: openRequestWhere as any })
  const demandRequests =
    view === 'demand'
      ? await prisma.purchaseRequest.findMany({
          where: openRequestWhere as any,
          orderBy: { createdAt: 'desc' },
          include: {
            grade: { select: { code: true, producer: true, category: true, applicationType: true } },
            _count: { select: { listings: true } },
          },
        })
      : []
  const demandRows = reservedLast(demandRequests, (r) => r.status === 'reserved')

  // ── خلاصه‌ی صف رزرو (FIFO) برای ردیف‌های رزروشده ──
  // یک کوئری برای همه‌ی ردیف‌ها (بدون N+1)؛ کلید برای هر id برمی‌گردد، پس
  // ردیفی که صف ندارد هم { total: 0 } می‌گیرد. position فقط وقتی کاربر وارد شده
  // و خودش در صف است مقدار دارد؛ مهمان null.
  // فقط ردیف‌های رزروشده کوئری می‌شوند — ردیف آزاد/باز دکمه‌ی صف نشان نمی‌دهد.
  const userId = user?.id ?? null
  const [supplyQueues, demandQueues] = await Promise.all([
    view === 'supply'
      ? getQueueSummaries(
          'SELL',
          supplyRows.filter((l) => l.validityStatus === 'reserved').map((l) => l.id),
          userId,
        )
      : Promise.resolve({} as Record<string, QueueSummary>),
    view === 'demand'
      ? getQueueSummaries(
          'BUY',
          demandRows.filter((r) => r.status === 'reserved').map((r) => r.id),
          userId,
        )
      : Promise.resolve({} as Record<string, QueueSummary>),
  ])
  // ردیفی که صف ندارد هم کلید می‌گیرد (total: 0)، ولی برای اطمینان از تایپ،
  // یک fallback خالی هم اینجا می‌سازیم تا هیچ‌وقت undefined به کامپوننت نرسد.
  const EMPTY_QUEUE: QueueSummary = { total: 0, position: null, label: null, status: null, claimExpiresAt: null }

  // شمارش‌ها: زیرعنوان فقط «واقعا قابل اقدام» را می‌گوید (آزاد/باز)، تب‌ها
  // هرچه در لیست هست (شامل رزروشده) — چون تب باید با تعداد ردیف‌های نمایش‌داده‌شده بخواند.
  // کوئری آگهی‌ها همیشه اجرا می‌شود، پس سمت عرضه از همان ردیف‌ها حساب می‌شود؛
  // سمت تقاضا فقط وقتی تب فعال نباشد یک count می‌خورد (لیست خالی است).
  const listingsCount = supplyRows.length
  const activeListingsCount = supplyRows.filter((l) => l.validityStatus === 'active').length
  const openDemandCount =
    view === 'demand'
      ? demandRows.filter((r) => r.status === 'open').length
      : await prisma.purchaseRequest.count({ where: { ...openRequestWhere, status: 'open' } as any })
  const hasFilters = Boolean(q || family || category || applicationType || producer || province)

  // marketUrl باید قبل از activeFilters تعریف شود — چیپ‌های حذف، لینکِ خودشان را از آن می‌گیرند.
  const marketUrl = (next: Partial<Record<string, string>> = {}) => {
    const params = new URLSearchParams()
    const values = { view, q, family, category, applicationType, producer, province, ...next }
    for (const [key, value] of Object.entries(values)) {
      if (value && (key !== 'view' || value !== 'supply')) params.set(key, value)
    }
    return `/market${params.size ? `?${params}` : ''}`
  }

  // فیلترهای فعال — هرکدام با لینکِ حذفِ خودش (فقط همان یکی را برمی‌دارد، بقیه و تب می‌مانند).
  type ActiveFilter = { key: string; label: string; value: string }
  const activeFilters: ActiveFilter[] = [
    q && { key: 'q', label: 'جستجو', value: q },
    family && { key: 'family', label: 'خانواده', value: family },
    category && { key: 'category', label: 'دسته', value: category },
    applicationType && { key: 'applicationType', label: 'کاربرد', value: applicationType },
    producer && { key: 'producer', label: 'تولیدکننده', value: producer },
    province && { key: 'province', label: 'استان', value: province },
  ].filter(Boolean) as ActiveFilter[]

  // «نتیجه‌ای با این فیلترها نیست» — شمارشِ بدون فیلتر فقط وقتی لازم می‌شود که
  // فیلتر فعال است و لیستِ فعلی خالی. در بقیه‌ی حالت‌ها کوئری اضافه اجرا نمی‌شود.
  const unfilteredCount =
    hasFilters &&
    ((view === 'supply' && listingsCount === 0) || (view === 'demand' && demandCount === 0))
      ? view === 'supply'
        ? await prisma.materialListing.count({ where: { validityStatus: { in: ['active', 'reserved'] } } })
        : await prisma.purchaseRequest.count({
            where: {
              status: { in: ['open', 'reserved'] },
              AND: [{ OR: [{ expiresAt: null }, { expiresAt: { gte: new Date() } }] }],
            } as any,
          })
      : null

  // ── فرم فیلتر مشترک هر دو تب ──
  // GET form submits *replace* the action URL's query string, so the hidden
  // `view` input is what actually keeps the demand tab active after submit —
  // the `?view=demand` in the action alone would be dropped.
  const filterForm = (
    <form method="GET" action="/market" style={filterFormStyle} className="mk-filter-form">
      {view === 'demand' && <input type="hidden" name="view" value="demand" />}
      {family && <input type="hidden" name="family" value={family} />}

      <input
        name="q"
        aria-label="جستجوی بازار"
        defaultValue={q}
        placeholder="جستجو: کد گرید، تولیدکننده، دسته…"
        style={inputStyle}
      />

      {/* Quick chips — لینک‌ها view فعلی رو حفظ می‌کنن تا کلیک، تب رو عوض نکنه */}
      <div style={chipRow} className="mk-chips" aria-label="خانواده‌های پلیمر">
        <a href={marketUrl({ family: '' })} className="mk-chip" aria-current={!family ? 'true' : undefined} style={{ ...chipStyle, background: !family ? colors.orangeBg : colors.neutralBg, color: !family ? colors.orangeText : colors.neutralText }}>همه</a>
        {POLYMER_FAMILY_OPTIONS.map((f) => (
          <a
            key={f}
            href={marketUrl({ family: family === f ? '' : f })}
            className="mk-chip"
            aria-current={family === f ? 'true' : undefined}
            style={{
              ...chipStyle,
              background: family === f ? colors.orangeBg : colors.neutralBg,
              color: family === f ? colors.orangeText : colors.neutralText,
              fontWeight: family === f ? 700 : 400,
            }}
          >
            {f}
          </a>
        ))}
      </div>

      <div className="mk-filter-fields">
      <select name="category" aria-label="دسته" defaultValue={category} style={selectStyle}>
        <option value="">همه‌ی دسته‌ها</option>
        {categories.map((c) => (
          <option key={c} value={c}>
            {c}
          </option>
        ))}
      </select>
      <select name="applicationType" aria-label="کاربرد" defaultValue={applicationType} style={selectStyle}>
        <option value="">همه‌ی کاربردها</option>
        {applicationTypes.map((a) => (
          <option key={a} value={a}>
            {a}
          </option>
        ))}
      </select>
      <select name="producer" aria-label="تولیدکننده" defaultValue={producer} style={selectStyle}>
        <option value="">همه‌ی تولیدکنندگان</option>
        {producers.map((p) => (
          <option key={p} value={p}>
            {p}
          </option>
        ))}
      </select>
      <select name="province" aria-label="استان" defaultValue={province} style={selectStyle}>
        <option value="">همه‌ی استان‌ها</option>
        {provinces.map((pr) => (
          <option key={pr} value={pr}>
            {pr}
          </option>
        ))}
      </select>
      </div>
      <div className="mk-filter-actions">
      <button type="submit" className="btn btn-sm" style={{ whiteSpace: 'nowrap' }}>
        اعمال فیلتر
      </button>
      {(q || family || category || applicationType || producer || province) && (
        <a
          href={marketUrl({ q: '', family: '', category: '', applicationType: '', producer: '', province: '' })}
          className="btn btn-sm btn-outline"
          style={{ whiteSpace: 'nowrap' }}
        >
          پاک کردن
        </a>
      )}
      </div>
    </form>
  )

  // ── فیلترها: دسکتاپ همان فرمِ باز، موبایل bottom-sheet (با JS) ──
  // MarketFilterSheet بدون JS فرم را «همیشه باز» نگه می‌دارد، پس GET بی‌JS کار می‌کند.
  const filterBlock = (
    <MarketFilterSheet activeCount={activeFilters.length}>{filterForm}</MarketFilterSheet>
  )

  // ── نوار فیلترهای فعال: شمارش نتیجه + یک چیپ برای هر فیلتر + «پاک کردن همه» ──
  const resultNoun = view === 'supply' ? 'آگهی' : 'درخواست'
  const resultCount = view === 'supply' ? listingsCount : demandCount
  const activeFilterBar = hasFilters ? (
    <div className="mk-active-bar" style={activeBarStyle}>
      <span style={activeBarCountStyle}>
        {fa(resultCount)} {resultNoun}
      </span>
      <div className="mk-active-chips" style={activeChipsStyle}>
        {activeFilters.map((f) => (
          <a
            key={f.key}
            href={marketUrl({ [f.key]: '' })}
            className="mk-active-chip"
            style={activeChipStyle}
            aria-label={`حذف فیلتر ${f.label}`}
          >
            <span style={activeChipLabelStyle}>{f.label}:</span> {f.value}
            <span aria-hidden="true" style={activeChipXStyle}>✕</span>
          </a>
        ))}
        <a
          href={marketUrl({ q: '', family: '', category: '', applicationType: '', producer: '', province: '' })}
          className="mk-clear-all"
          style={clearAllStyle}
        >
          پاک کردن همه
        </a>
      </div>
    </div>
  ) : null

  /** چهار حالتِ «خالی»: (عرضه|تقاضا) × (با فیلتر | بی‌فیلتر).
   *  با فیلتر → پیشنهادِ دیدنِ همه (با شمارشِ بدون فیلتر) + لینکِ پاک کردن.
   *  بی‌فیلتر → واقعاً چیزی نیست؛ CTA به ثبت آگهی / درخواست خرید. */
  const emptyState = (() => {
    if (view === 'supply') {
      return hasFilters ? (
        <div style={emptyStyle}>
          <div style={emptyTitleStyle}>نتیجه‌ای با این فیلترها پیدا نشد</div>
          <div style={emptyBodyStyle}>
            {unfilteredCount !== null
              ? `${fa(unfilteredCount)} آگهی در بازار هست — فیلترها را کمتر کنید.`
              : 'فیلترها را کمتر کنید یا عبارت دیگری را امتحان کنید.'}
          </div>
          <a
            href={marketUrl({ q: '', family: '', category: '', applicationType: '', producer: '', province: '' })}
            className="btn btn-sm mk-press"
            style={emptyBtnStyle}
          >
            پاک کردن فیلترها
          </a>
        </div>
      ) : (
        <div style={emptyStyle}>
          <div style={emptyTitleStyle}>هنوز آگهی‌ای ثبت نشده</div>
          <div style={emptyBodyStyle}>اولین فروشنده‌ی این بازار باشید.</div>
          <a href={user ? '/new-listing' : '/signup'} className="btn btn-sm mk-press" style={emptyBtnStyle}>
            {user ? 'ثبت آگهی فروش' : 'عضو شوید'}
          </a>
        </div>
      )
    }
    return hasFilters ? (
      <div style={emptyStyle}>
        <div style={emptyTitleStyle}>درخواستی با این فیلترها پیدا نشد</div>
        <div style={emptyBodyStyle}>
          {unfilteredCount !== null
            ? `${fa(unfilteredCount)} درخواست خرید در بازار هست — فیلترها را کمتر کنید.`
            : 'فیلترها را کمتر کنید یا عبارت دیگری را امتحان کنید.'}
        </div>
        <a
          href={marketUrl({ q: '', family: '', category: '', applicationType: '', producer: '', province: '' })}
          className="btn btn-sm mk-press"
          style={emptyBtnStyle}
        >
          پاک کردن فیلترها
        </a>
      </div>
    ) : (
      <div style={emptyStyle}>
        <div style={emptyTitleStyle}>درخواست خریدی ثبت نشده</div>
        <div style={emptyBodyStyle}>اولین خریداری باشید که نیازش را اعلام می‌کند.</div>
        <a href={user ? '/purchase-requests?new=1' : '/signup'} className="btn btn-sm mk-press" style={emptyBtnStyle}>
          {user ? 'ثبت درخواست خرید' : 'عضو شوید'}
        </a>
      </div>
    )
  })()

  return (
    <>
      {/* CSS اختصاصیِ بازار — صفحه‌محلی، تا بسته‌های دیگر globals.css را بازنویسی کنند و این بماند. */}
      <style dangerouslySetInnerHTML={{ __html: MARKET_FILTER_CSS }} />
      <CurrencyTicker />
      <PublicHeader homeHref={getSurfaceHome()} activePage="/market" isLoggedIn={!!user} />

      <section>
        <div className="wrap">
          <div className="eyebrow">خرید و فروش مواد اولیه</div>
          <div className="sec-title">بازار صنعتی پلیمر</div>
          <div className="sec-sub" style={{ marginBottom: spacing.lg }}>
            {view === 'supply' ? (
              <>
                آگهی‌های فروش مواد اولیه پلیمری از تولیدکنندگان و فروشندگان سراسر کشور —{' '}
                <b style={{ color: colors.orange }}>{fa(activeListingsCount)} آگهی آزاد</b>
              </>
            ) : (
              <>
                نیازِ خریدها که خریدارها اعلام کرده‌ن — اگه بار داری، می‌تونی روی همون‌جا آگهی بذاری —{' '}
                <b style={{ color: colors.orange }}>{fa(openDemandCount)} درخواست باز</b>
              </>
            )}
          </div>

          {/* ── تب‌های بازار دوطرفه ──
              لینک‌ها «تمیز»اند (بدون فیلتر) تا زدنِ تب، فیلترهای تب قبل را با خود نیاورد.
              شمارشِ تب = تعداد ردیف‌هایی که در آن تب نمایش داده می‌شوند (شامل رزروشده). */}
          <div style={tabRowStyle} className="mk-tabs">
            <a href="/market" style={view === 'supply' ? tabActiveStyle : tabStyle} aria-current={view === 'supply' ? 'page' : undefined}>
              عرضه‌ی فروشنده‌ها ({fa(listingsCount)})
            </a>
            <a href="/market?view=demand" style={view === 'demand' ? tabActiveStyle : tabStyle} aria-current={view === 'demand' ? 'page' : undefined}>
              تقاضای خریدارها ({fa(demandCount)})
            </a>
          </div>

          {/* ── Guest CTA ── */}
          {!user && (
            <div style={guestBanner}>
              برای مشاهده‌ی جزئیات کامل، قیمت و خرید،{' '}
              <a href="/signup" style={{ color: colors.orange, fontWeight: 700, textDecoration: 'underline' }}>
                عضو شوید ←
              </a>
            </div>
          )}

          {view === 'supply' ? (
            <>
              {filterBlock}
              {activeFilterBar}

              {listingsCount === 0 ? (
                emptyState
              ) : (
                <div className="mk-table-scroll" style={tableScrollStyle}>
                  <div className="mk-table" style={supplyTableStyle}>
                    <div className="mk-thead" style={{ ...headRowStyle, gridTemplateColumns: SUPPLY_TABLE_COLUMNS } as React.CSSProperties}>
                      <div style={headCell}>گرید</div>
                      <div style={headCell}>وضعیت</div>
                      <div style={headCell}>قیمت</div>
                      <div style={headCell}>مقدار</div>
                      <div style={headCell}>محل بار</div>
                      <div style={headCell}>مبدأ</div>
                      <div style={headCell}>MFI</div>
                      <div style={headCell}>کاربرد</div>
                      <div style={headCell}>ثبت</div>
                      <div />
                    </div>
                    {supplyRows.map((listing) => (
                      <SupplyTableRow
                        key={listing.id}
                        listing={listing}
                        kycLevel={kycLevel}
                        isGuest={!user}
                        queue={supplyQueues[listing.id] ?? EMPTY_QUEUE}
                      />
                    ))}
                  </div>
                </div>
              )}
            </>
          ) : (
            <>
              {filterBlock}
              {activeFilterBar}

              {demandCount === 0 ? (
                emptyState
              ) : (
                <div className="mk-table-scroll" style={tableScrollStyle}>
                  <div className="mk-table" style={demandTableStyle}>
                    <div className="mk-thead" style={{ ...headRowStyle, gridTemplateColumns: DEMAND_TABLE_COLUMNS } as React.CSSProperties}>
                      <div style={headCell}>گرید</div>
                      <div style={headCell}>مقدار موردنیاز</div>
                      <div style={headCell}>سقف قیمت</div>
                      <div style={headCell}>استان</div>
                      <div style={headCell}>انقضا</div>
                      <div style={headCell}>وضعیت</div>
                      <div style={headCell}>ثبت</div>
                      <div />
                    </div>
                    {demandRows.map((req) => (
                      <DemandTableRow
                        key={req.id}
                        request={req}
                        isLoggedIn={!!user}
                        kycLevel={kycLevel}
                        queue={demandQueues[req.id] ?? EMPTY_QUEUE}
                      />
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </section>

      <Footer homeHref={getSurfaceHome()} />
    </>
  )
}

// ── Styles ──
const guestBanner: React.CSSProperties = {
  background: colors.warningBg,
  color: colors.warningText,
  borderRadius: radius.md,
  padding: '10px 16px',
  fontSize: fontSize.base,
  fontWeight: 600,
  marginBottom: 20,
  textAlign: 'center',
}
const filterFormStyle: React.CSSProperties = {
  // جهت، چیدمان و «جعبه»ی فرم را CSS می‌سازد (`.mk-filter-form` + media query):
  // دسکتاپ جعبه‌ی خاکستریِ باز، موبایل داخلِ شیتِ سفید (بدون جعبه‌ی جدا).
  // inline نمی‌گذاریم وگرنه روی CSS می‌چربد و شیتِ موبایل خراب می‌شود.
  marginBottom: 20,
}
const inputStyle: React.CSSProperties = {
  ...sharedInputStyle,
}
const chipRow: React.CSSProperties = {
  display: 'flex',
  flexWrap: 'wrap',
  gap: 6,
}
const chipStyle: React.CSSProperties = {
  fontSize: fontSize.xs,
  borderRadius: 20,
  padding: '4px 12px',
  textDecoration: 'none',
  transition: 'background .15s',
  cursor: 'pointer',
}
const selectStyle: React.CSSProperties = {
  ...sharedSelectStyle,
  minWidth: 140,
}
const emptyStyle: React.CSSProperties = {
  ...emptyStateStyle,
  padding: 40,
  border: `1px dashed ${colors.borderStrong}`,
  borderRadius: radius.lg,
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  gap: spacing.sm,
  textAlign: 'center',
}
const emptyTitleStyle: React.CSSProperties = {
  fontSize: fontSize.md,
  fontWeight: 800,
  color: colors.textPrimary,
}
const emptyBodyStyle: React.CSSProperties = {
  fontSize: fontSize.sm,
  color: colors.textSecondary,
}
const emptyBtnStyle: React.CSSProperties = {
  marginTop: spacing.xs,
  textDecoration: 'none',
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
}
// ── نوار فیلترهای فعال ──
const activeBarStyle: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: spacing.md,
  marginBottom: spacing.lg,
  padding: `${spacing.sm}px ${spacing.md}px`,
  background: colors.bgHover,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.md,
}
const activeBarCountStyle: React.CSSProperties = {
  fontSize: fontSize.sm,
  fontWeight: 700,
  color: colors.textPrimary,
  whiteSpace: 'nowrap',
}
// روی موبایل افقی اسکرول می‌شود؛ چیپ‌ها نباید فشرده شوند (flex-shrink:0).
const activeChipsStyle: React.CSSProperties = {
  display: 'flex',
  gap: 6,
  overflowX: 'auto',
  WebkitOverflowScrolling: 'touch',
  flex: 1,
  paddingBottom: 2,
}
const activeChipStyle: React.CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  gap: 5,
  flexShrink: 0,
  fontSize: fontSize.xs,
  fontWeight: 600,
  color: colors.neutralText,
  background: colors.bgCard,
  border: `1px solid ${colors.borderStrong}`,
  borderRadius: 20,
  padding: '3px 10px',
  textDecoration: 'none',
  whiteSpace: 'nowrap',
}
const activeChipLabelStyle: React.CSSProperties = {
  color: colors.textMuted,
  fontWeight: 500,
}
const activeChipXStyle: React.CSSProperties = {
  color: colors.textMuted,
  fontSize: 10,
}
const clearAllStyle: React.CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  flexShrink: 0,
  fontSize: fontSize.xs,
  fontWeight: 700,
  color: colors.orangeText,
  background: colors.orangeBg,
  border: `1px solid ${colors.orange}`,
  borderRadius: 20,
  padding: '3px 10px',
  textDecoration: 'none',
  whiteSpace: 'nowrap',
}
const tabRowStyle: React.CSSProperties = {
  display: 'flex',
  gap: spacing.sm,
  marginBottom: 20,
  borderBottom: `2px solid ${colors.borderSubtle}`,
}
const tabStyle: React.CSSProperties = {
  padding: '10px 18px',
  fontSize: fontSize.base,
  fontWeight: 600,
  color: colors.textMuted,
  textDecoration: 'none',
  borderBottom: '2px solid transparent',
  marginBottom: -2,
  cursor: 'pointer',
}
const tabActiveStyle: React.CSSProperties = {
  ...tabStyle,
  color: colors.navy,
  fontWeight: 800,
  borderBottom: `2px solid ${colors.navy}`,
}
// جدول عرضه: ستون‌هایی با ترکیبی از serif/Sans و حفاظت از wrap کردن
const tableScrollStyle: React.CSSProperties = {
  overflowX: 'auto',
  WebkitOverflowScrolling: 'touch',
  marginBottom: spacing.lg,
}
const supplyTableStyle: React.CSSProperties = {
  minWidth: 760,
}
const demandTableStyle: React.CSSProperties = {
  minWidth: 680,
}
const headRowStyle: React.CSSProperties = {
  display: 'grid',
  gap: 10,
  alignItems: 'center',
  background: colors.navy,
  borderRadius: radius.md,
  padding: '11px 16px',
  marginBottom: 10,
}
const headCell: React.CSSProperties = {
  fontSize: fontSize.xs,
  fontWeight: 700,
  color: '#fff',
  letterSpacing: '0.02em',
  whiteSpace: 'nowrap',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
}

/**
 * CSS صفحه‌ی بازار — عمداً این‌جا (نه globals.css) تا بسته‌های دیگر رویش ننویسند.
 * فقط توکن‌های `@/lib/styles/tokens`؛ هیچ عددِ جادوییِ رنگ/شعاعِ تکراری نه.
 *
 * دو بخش:
 *  1) شیتِ فیلترِ موبایل — بدون JS فرم «همیشه باز» است (position: static) و GET
 *     معمولی submit می‌شود. فقط وقتی JS فعال است (کلاس .mk-filter-enhanced)
 *     تبدیل به bottom-sheet می‌شود؛ پس هیچ‌وقت بدون JS فیلترها پنهان نمی‌مانند.
 *  2) ردیف/کارت — دسکتاپ ردیفِ grid، موبایل کارتِ دوستونی با data-label.
 *
 * قرارداد z-index: هدر ۵۰، ناوبریِ پایین ۴۰، scrim ۴۱، شیت ۴۲.
 */
const MARKET_FILTER_CSS = `
/* ── بازخورد لمسی: فقط :active، بدون تغییر رنگ در hover ── */
.mk-press { transition: transform .12s ease, opacity .12s ease; }
.mk-press:active { transform: scale(.96) !important; opacity: .82 !important; }

/* ── 1) شیتِ فیلتر ── */
/* حالتِ بی‌JS: پنل همان فرمِ داخلِ جریان است، دکمه‌ی باز/بست و scrim بی‌کاربرد. */
.mk-filter-enhanced .mk-filter-toggle { display: none; }
.mk-filter-enhanced .mk-filter-scrim { display: none; }

.mk-filter-form {
  display: flex; flex-direction: column; gap: ${spacing.md}px;
  padding: ${spacing.md}px; background: ${colors.bgHover};
  border: 1px solid ${colors.borderSubtle}; border-radius: ${radius.lg}px;
}
.mk-filter-fields { display: flex; flex-wrap: wrap; gap: ${spacing.sm}px; }
.mk-filter-actions { display: flex; gap: ${spacing.sm}px; align-items: center; }

/* با JS: پنل می‌شود bottom-sheet و دکمه‌ی «فیلترها» ظاهر می‌شود. */
@media (max-width: ${breakpoints.mobile - 1}px) {
  .mk-filter-enhanced .mk-filter-toggle {
    display: flex; align-items: center; justify-content: center; gap: 6px;
    width: 100%; padding: 11px ${spacing.lg}px;
    font-size: ${fontSize.base}px; font-weight: 700;
    color: ${colors.navy}; background: ${colors.bgCard};
    border: 1px solid ${colors.borderStrong}; border-radius: ${radius.md}px;
    cursor: pointer; margin-bottom: ${spacing.md}px;
    font-family: inherit;
  }
  .mk-filter-enhanced .mk-filter-toggle:active { transform: scale(.98); }

  .mk-filter-enhanced .mk-filter-scrim {
    display: block; position: fixed; inset: 0; z-index: 41;
    background: rgba(10, 18, 40, .5); border: 0; padding: 0; cursor: pointer;
    animation: mk-fade .18s ease;
  }

  .mk-filter-enhanced .mk-filter-panel {
    position: fixed; left: 0; right: 0; bottom: 0; z-index: 42;
    max-height: 85vh; overflow-y: auto;
    background: ${colors.bgCard};
    border-radius: 18px 18px 0 0;
    box-shadow: 0 -8px 32px rgba(10, 18, 40, .22);
    padding-bottom: env(safe-area-inset-bottom, 0px);
    transform: translateY(100%);
    transition: transform .24s cubic-bezier(.32, .72, 0, 1);
    display: flex; flex-direction: column;
  }
  .mk-filter-enhanced[data-open='true'] .mk-filter-panel { transform: translateY(0); }

  .mk-filter-heading {
    position: sticky; top: 0; z-index: 1;
    display: flex; align-items: center; justify-content: space-between;
    padding: ${spacing.md}px ${spacing.lg}px ${spacing.sm}px;
    background: ${colors.bgCard};
    border-bottom: 1px solid ${colors.borderSubtle};
  }
  .mk-filter-heading::before {
    content: ''; position: absolute; top: 7px; left: 50%; transform: translateX(-50%);
    width: 36px; height: 4px; border-radius: 2px; background: ${colors.borderStrong};
  }
  .mk-filter-heading strong { font-size: ${fontSize.md}px; font-weight: 800; color: ${colors.textPrimary}; }
  .mk-filter-heading button {
    width: 30px; height: 30px; border-radius: ${radius.sm}px;
    border: 1px solid ${colors.borderSubtle}; background: ${colors.bgPage};
    color: ${colors.textSecondary}; cursor: pointer; font-size: ${fontSize.sm}px;
    display: flex; align-items: center; justify-content: center; font-family: inherit;
  }
  /* بدنه‌ی شیت: فرمِ GET با همان نام‌ها submit می‌شود؛ selectها تک‌ستونی. */
  /* داخلِ شیت، خودِ پنل سطحِ سفید دارد؛ جعبه‌ی خاکستریِ فرم را برمی‌داریم. */
  .mk-filter-enhanced .mk-filter-panel .mk-filter-form {
    padding: ${spacing.lg}px; gap: ${spacing.lg}px;
    background: transparent; border: 0; border-radius: 0; margin-bottom: 0;
  }
  .mk-filter-enhanced .mk-filter-panel .mk-filter-fields { flex-direction: column; }
  .mk-filter-enhanced .mk-filter-panel .mk-filter-fields select { width: 100%; min-width: 0; }
  .mk-filter-enhanced .mk-filter-panel .mk-filter-actions {
    position: sticky; bottom: 0; z-index: 1;
    padding: ${spacing.md}px ${spacing.lg}px calc(${spacing.md}px + env(safe-area-inset-bottom, 0px));
    background: ${colors.bgCard}; border-top: 1px solid ${colors.borderSubtle};
    margin: 0 calc(-1 * ${spacing.lg}px) calc(-1 * ${spacing.lg}px);
  }
  .mk-filter-enhanced .mk-filter-panel .mk-filter-actions > * { flex: 1; justify-content: center; }
}
@keyframes mk-fade { from { opacity: 0 } to { opacity: 1 } }

/* ── 2) ردیف/کارت ── */
/* موبایل: ردیف می‌شود کارتِ دوستونی؛ هدرِ ستون پنهان، هر سلول برچسب می‌گیرد. */
@media (max-width: ${breakpoints.mobile - 1}px) {
  .mk-table-scroll { overflow: visible !important; }
  .mk-table { min-width: 0 !important; }
  .mk-thead { display: none !important; }

  .mk-row {
    grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
    gap: ${spacing.md}px ${spacing.lg}px !important;
    padding: 14px !important;
    cursor: default;
  }
  .mk-cell { min-width: 0; }
  /* هر سلول: برچسب بالای مقدار (data-label) — راست‌چین، Vazirmatn. */
  .mk-cell[data-label]::before {
    content: attr(data-label);
    display: block;
    font-family: Vazirmatn, system-ui, sans-serif;
    font-size: 11px; font-weight: 600; color: ${colors.textMuted};
    direction: rtl; text-align: right; margin-bottom: 3px;
  }
  /* ردیفِ اولِ کارت: گرید + وضعیت، با خطِ جدا زیرشان. */
  .mk-cell-grade, .mk-cell-status { align-self: center; }
  .mk-cell-status { padding-bottom: ${spacing.md}px; border-bottom: 1px solid ${colors.borderSubtle}; }
  .mk-cell-grade { padding-bottom: ${spacing.md}px; border-bottom: 1px solid ${colors.borderSubtle}; }
  /* ردیفِ آخرِ کارت: عملیات — تمام‌عرض، خطِ چینِ بالا، دکمه‌ها بزرگ و لمسی. */
  .mk-cell-actions {
    grid-column: 1 / -1;
    border-top: 1px dashed ${colors.borderStrong};
    padding-top: ${spacing.md}px;
    display: flex !important; align-items: center; gap: 10px !important;
    justify-content: flex-start !important;
  }
  .mk-cell-actions .mk-info-btn { width: 42px !important; height: 42px !important; }
  .mk-cell-actions .mk-info-btn svg { width: 18px; height: 18px; }
  .mk-cell-actions .mk-action-slot { flex: 1; }
  .mk-cell-actions .mk-action-btn {
    width: 100%; height: 42px; padding: 0 ${spacing.md}px !important;
    display: flex; align-items: center; justify-content: center;
    font-size: ${fontSize.base}px !important;
  }
  /* فرمِ صف: دکمه + جایگاهِ زیرش — تمام‌عرض و وسط‌چین. */
  .mk-cell-actions .mk-reserve-form { display: flex; }
  .mk-cell-actions .mk-queue-pos { font-size: 11px; text-align: center; margin-top: 4px; }

  /* قیمتِ مهمان: تار می‌ماند ولی برچسبِ سلول خوانا است. */
  .mk-cell-price { align-items: flex-start; }
}

/* تبلت/دسکتاپ: فرمِ فیلتر افقی می‌شود و شیت بی‌کاربرد است. */
@media (min-width: ${breakpoints.mobile}px) {
  .mk-filter-enhanced .mk-filter-panel { display: contents; }
  .mk-filter-enhanced .mk-filter-heading { display: none; }
  .mk-filter-form {
    flex-direction: row; flex-wrap: wrap; align-items: center;
    gap: ${spacing.sm}px ${spacing.md}px;
    padding: ${spacing.md}px;
    background: ${colors.bgHover};
    border: 1px solid ${colors.borderSubtle};
    border-radius: ${radius.lg}px;
  }
  .mk-filter-form > input[name='q'] { flex: 1 1 240px; min-width: 200px; }
  .mk-chips { flex-basis: 100%; }
  .mk-filter-fields { flex: 1 1 100%; }
  .mk-filter-actions { margin-right: auto; }
}
`
