// src/app/market/loading.tsx
//
// Skeleton صفحه‌ی بازار — آینه‌ی ساختار واقعی صفحه: هدر navy، ناحیه‌ی عنوان،
// ردیف تب‌ها، جعبه‌ی فیلتر، و جدولِ فشرده با هدر navy + ردیف‌های اسکرول‌شونده.
// چیدمان جدول دقیقاً مطابق تب «عرضه»ی market/page.tsx (همان ستون‌ها و استایل‌ها).
// روی موبایل مثل صفحه‌ی واقعی کارتِ دوستونی می‌شود (نه جدولِ افقیِ عریض) — همان
// کلاس‌های .mk-table-scroll/.mk-table/.mk-thead/.mk-row و همان breakpoint.

import SkeletonLine from '@/components/SkeletonLine'
import { colors, spacing, radius, fontSize, breakpoints } from '@/lib/styles/tokens'
import type { CSSProperties } from 'react'

// همان SUPPLY_TABLE_COLUMNS در SupplyTableRow — اینجا inline تا ماژول کلاینت
// وارد گرافِ سرورِ این skeleton نشود.
const SUPPLY_TABLE_COLUMNS =
  'minmax(0,1.4fr) minmax(0,.9fr) minmax(0,1fr) minmax(0,.6fr) minmax(0,.8fr) minmax(0,.6fr) minmax(0,.8fr) minmax(0,.8fr) minmax(0,.8fr) minmax(0,1.3fr)'

const HEAD_LABELS = ['گرید', 'وضعیت', 'قیمت', 'مقدار', 'محل بار', 'مبدأ', 'MFI', 'کاربرد', 'ثبت', '']

// زیرمجموعه‌ی MARKET_FILTER_CSS که فقط روی اسکلت اثر می‌گذارد. اسکلت جای صفحه را
// می‌گیرد (page.tsx منت نمی‌شود)، پس style خودش را دارد؛ data-label ندارد، پس
// قاعده‌ی ::before لازم نیست.
const SKELETON_CSS = `
@media (max-width: ${breakpoints.mobile - 1}px) {
  .mk-table-scroll { overflow: visible !important; }
  .mk-table { min-width: 0 !important; }
  .mk-thead { display: none !important; }
  .mk-row {
    grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
    gap: ${spacing.md}px ${spacing.lg}px !important;
    padding: 14px !important;
  }
}
`

export default function MarketLoading() {
  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: SKELETON_CSS }} />
      {/* جای PublicHeader */}
      <div style={headerPlaceholderStyle} />

      <section>
        <div className="wrap">
          {/* ناحیه‌ی عنوان — eyebrow / sec-title / sec-sub */}
          <div style={{ marginBottom: spacing.lg }}>
            <SkeletonLine width={140} height={14} />
            <div style={{ height: spacing.sm }} />
            <SkeletonLine width={260} height={26} />
            <div style={{ height: spacing.sm }} />
            <SkeletonLine width={380} height={14} />
          </div>

          {/* ردیف تب‌ها */}
          <div style={tabRowStyle}>
            <SkeletonLine width={170} height={20} />
            <SkeletonLine width={170} height={20} />
          </div>

          {/* جعبه‌ی فیلتر */}
          <div style={filterBoxStyle}>
            <SkeletonLine width="100%" height={38} />
            <div style={chipRowStyle}>
              {Array.from({ length: 6 }).map((_, i) => (
                <SkeletonLine key={i} width={54} height={24} />
              ))}
            </div>
            <div style={selectRowStyle}>
              {Array.from({ length: 4 }).map((_, i) => (
                <SkeletonLine key={i} width={150} height={38} />
              ))}
            </div>
          </div>

          {/* جدول: هدر navy + ردیف‌های اسکرول‌شونده (موبایل: کارت) */}
          <div className="mk-table-scroll" style={tableScrollStyle}>
            <div className="mk-table" style={supplyTableStyle}>
              <div className="mk-thead" style={{ ...headRowStyle, gridTemplateColumns: SUPPLY_TABLE_COLUMNS }}>
                {HEAD_LABELS.map((label, i) => (
                  <div key={i} style={headCellStyle}>
                    {label}
                  </div>
                ))}
              </div>
              {Array.from({ length: 8 }).map((_, r) => (
                <div key={r} className="mk-row" style={{ ...rowStyle, gridTemplateColumns: SUPPLY_TABLE_COLUMNS }}>
                  {Array.from({ length: 10 }).map((_, c) => (
                    <SkeletonLine key={c} width={c === 9 ? 70 : '80%'} height={14} />
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

// ── استایل‌ها — آینه‌ی market/page.tsx ──
const headerPlaceholderStyle: CSSProperties = {
  background: colors.navy,
  height: 72,
  width: '100%',
}
const tabRowStyle: CSSProperties = {
  display: 'flex',
  gap: spacing.sm,
  marginBottom: 20,
  borderBottom: `2px solid ${colors.borderSubtle}`,
  paddingBottom: spacing.sm,
}
const filterBoxStyle: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: spacing.md,
  marginBottom: 20,
  padding: spacing.md,
  background: colors.bgHover,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
}
const chipRowStyle: CSSProperties = {
  display: 'flex',
  flexWrap: 'wrap',
  gap: 6,
}
const selectRowStyle: CSSProperties = {
  display: 'flex',
  flexWrap: 'wrap',
  gap: spacing.md,
}
const tableScrollStyle: CSSProperties = {
  overflowX: 'auto',
  WebkitOverflowScrolling: 'touch',
  marginBottom: spacing.lg,
}
const supplyTableStyle: CSSProperties = {
  minWidth: 760,
}
const headRowStyle: CSSProperties = {
  display: 'grid',
  gap: 10,
  alignItems: 'center',
  background: colors.navy,
  borderRadius: radius.md,
  padding: '11px 16px',
  marginBottom: 10,
}
const headCellStyle: CSSProperties = {
  fontSize: fontSize.xs,
  fontWeight: 700,
  color: '#fff',
  letterSpacing: '0.02em',
  whiteSpace: 'nowrap',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
}
const rowStyle: CSSProperties = {
  display: 'grid',
  gap: 10,
  alignItems: 'center',
  background: colors.bgCard,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
  padding: '11px 16px',
  marginBottom: 8,
}
