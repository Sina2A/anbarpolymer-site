'use client'

// زیرنقشه‌ی Leaflet برای LocationPicker — فقط کلاینت.
// این ماژول react-leaflet را به‌صورت static ایمپورت می‌کند (چون useMapEvents یک هوک است
// و نه می‌شود آن را dynamic بارگذاری کرد و نه در کامپوننتی که روی سرور prerender می‌شود
// static ایمپورت کرد؛ Leaflet هنگام import به window دست می‌زند). به همین دلیل کلِ این
// زیردرخت جدا شده و LocationPicker آن را با dynamic(ssr:false) بارگذاری می‌کند.
// از CircleMarker (SVG) استفاده می‌شود تا پین‌ها بدون نیاز به فایلِ آیکنِ مارکر دیده شوند
// (بدونِ باگِ شکستنِ مسیرِ آیکنِ پیش‌فرضِ Leaflet در باندلر).
// leaflet.css به‌صورت سراسری در layout.tsx بارگذاری می‌شود (لازم برای جای‌گیری کاشی‌ها/لایه‌ها).

import { MapContainer, TileLayer, CircleMarker, Tooltip, AttributionControl, useMapEvents } from 'react-leaflet'
import { colors } from '@/lib/styles/tokens'
// کنترلرِ محدوده — minZoomِ پویا (کلِ ایران جا شود) + قفلِ pan روی ایران.
// static ایمپورت امن است چون این ماژول خودش فقط با dynamic(ssr:false) لود می‌شود.
import MapBoundsController from './MapBoundsController'
// لایه‌ی مرزِ نارنجیِ ایران (ADM0) — static به همان دلیل بالا.
import IranBorder from './IranBorder'

export type MapMarker = {
  id: string
  lat: number
  lng: number
  label?: string
  color?: string
}

// مرکز تقریبی ایران برای حالتی که هنوز نقطه‌ای انتخاب نشده.
const IRAN_CENTER: [number, number] = [32.4, 53.6]
const IRAN_ZOOM = 5
const POINT_ZOOM = 11
// رنگِ پین‌ها — آبی فسفریِ پررنگ، هماهنگ با انیمیشنِ .blink-pin در globals.css.
const PIN_COLOR = '#00D4FF'

function round6(n: number): number {
  return Math.round(n * 1e6) / 1e6
}

// هوکِ کلیک — باید داخلِ <MapContainer> رندر شود (فرزندِ نقشه).
function ClickHandler({ onSelect }: { onSelect: (lat: number, lng: number) => void }) {
  useMapEvents({
    click(e) {
      onSelect(round6(e.latlng.lat), round6(e.latlng.lng))
    },
  })
  return null
}

type LocationPickerMapProps = {
  height: number
  /** پین‌های زمینه‌ای (حالت تعاملی) یا پینِ ثابت (حالت فقط‌نمایش). */
  markers: MapMarker[]
  /** پینِ انتخاب‌شده/در‌انتظار (حالت تعاملی). */
  selected: { lat: number; lng: number } | null
  /** اگر داده شود نقشه تعاملی می‌شود: کلیک → (lat, lng). */
  onSelect?: (lat: number, lng: number) => void
  ariaLabel?: string
}

export default function LocationPickerMap({
  height,
  markers,
  selected,
  onSelect,
  ariaLabel,
}: LocationPickerMapProps) {
  const interactive = typeof onSelect === 'function'

  // مرکز اولیه: نقطه‌ی انتخاب‌شده → اولین پین → مرکز ایران.
  const focus = selected ?? (markers.length > 0 ? { lat: markers[0].lat, lng: markers[0].lng } : null)
  const center: [number, number] = focus ? [focus.lat, focus.lng] : IRAN_CENTER
  const zoom = focus ? POINT_ZOOM : IRAN_ZOOM

  return (
    <div style={{ ...wrapStyle, height }} aria-label={ariaLabel}>
      <MapContainer
        center={center}
        zoom={zoom}
        style={{ width: '100%', height: '100%' }}
        attributionControl={false}
        maxBoundsViscosity={1.0}
      >
        {/* minZoomِ پویا + maxBounds روی ایران (قفلِ pan). فرزندِ نقشه چون useMap دارد.
            قفلِ pan جلوی کلیک/انتخاب داخلِ ایران را نمی‌گیرد؛ فقط اجازه نمی‌دهد قاب کاملاً بیرونِ ایران برود. */}
        <MapBoundsController />
        {/* کنترلِ Attribution دستی با prefix=false → حذفِ برند/پرچمِ پیش‌فرضِ Leaflet، بدون حذفِ متنِ منبع (© OpenStreetMap). */}
        <AttributionControl prefix={false} />
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {/* مرزِ نارنجیِ ایران (interactive:false) — کلیکِ انتخابِ نقطه را نمی‌بلعد. */}
        <IranBorder />

        {interactive && onSelect ? <ClickHandler onSelect={onSelect} /> : null}

        {markers.map((m) => (
          <CircleMarker
            key={m.id}
            center={[m.lat, m.lng]}
            radius={6}
            pathOptions={{ className: 'blink-pin', color: '#fff', weight: 1.5, fillColor: m.color ?? PIN_COLOR, fillOpacity: 1 }}
          >
            {m.label ? <Tooltip>{m.label}</Tooltip> : null}
          </CircleMarker>
        ))}

        {selected ? (
          <CircleMarker
            center={[selected.lat, selected.lng]}
            radius={8}
            pathOptions={{ className: 'blink-pin', color: '#fff', weight: 2, fillColor: PIN_COLOR, fillOpacity: 1 }}
          />
        ) : null}
      </MapContainer>
    </div>
  )
}

const wrapStyle: React.CSSProperties = {
  position: 'relative',
  width: '100%',
  borderRadius: 12,
  overflow: 'hidden',
  border: `1px solid ${colors.borderStrong}`,
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
  background: '#f7f8fa',
  boxSizing: 'border-box',
}
