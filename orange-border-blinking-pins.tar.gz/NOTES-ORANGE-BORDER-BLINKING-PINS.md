# مرزِ نارنجیِ ایران + پین‌های چشمک‌زنِ آبی فسفری

## ترتیبِ نصب (مهم)
این بسته **باید بعد از `limit-zoom-out-iran` نصب شود**. آن بسته `MapBoundsController.tsx`
را اضافه کرد و هر سه فایلِ نقشه را ویرایش کرد؛ فایل‌های نقشه در این بسته روی همان نسخه
ساخته شده‌اند (شاملِ `<MapBoundsController />` و `maxBoundsViscosity`). نصبِ این بسته پیش از
`limit-zoom-out-iran`، آن تغییرات را از دست می‌دهد.

## چه چیزی اضافه/عوض شد

### ۱) مرزِ بیرونیِ کشور (ADM0) — رنگِ نارنجیِ برند
کاشی‌های OSM رستری‌اند و رنگِ مرزِ داخلِ خودِ تصویر قابل‌تغییر نیست؛ پس مرزِ کشور را به‌صورت
یک لایه‌ی برداریِ جدا بالای `TileLayer` می‌کشیم:
- داده: `src/data/iran-adm0.json` — **فایلِ جدید** (geoBoundaries IRN ADM0، یک `FeatureCollection`
  با یک `MultiPolygon`، فقط سطحِ کشور، بدونِ مرزِ استان/شهرستان). مستقیم `import` می‌شود
  (`resolveJsonModule` فعال است) و یک‌بار در باندلِ مشترکِ سه نقشه قرار می‌گیرد.
- کامپوننت: `src/components/IranBorder.tsx` — **فایلِ جدید**. `<GeoJSON>` از react-leaflet با
  `style={{ color: colors.orange, weight: 2, opacity: 0.9, fill: false, interactive: false }}`.
  - `fill:false` → داخلِ کشور پر نمی‌شود (پاپ‌آپ/دید مسدود نمی‌شود).
  - `interactive:false` → لایه کلیک را نمی‌بلعد؛ **حیاتی** تا انتخابِ نقطه در LocationPicker سالم بماند.
- الگوی لود: در `LocationPickerMap` به‌صورت `static import` (چون خودِ آن ماژول فقط با
  `dynamic(ssr:false)` لود می‌شود)؛ در `WarehousesMap`/`TransportMap` با `dynamic(ssr:false)`.
  `GeoJSON` یک کامپوننت است (نه هوک) پس هر دو الگو امن‌اند.
- ترتیبِ رندر: بعد از `<TileLayer>` و **قبل از** پین‌ها، تا پین‌ها روی مرز دیده شوند.

### ۲) رنگِ پین‌ها → آبی فسفری `#00D4FF` + چشمکِ ملایم
- `fillColor` همه‌ی پین‌ها روی هر سه نقشه به `#00D4FF` تغییر کرد، **از جمله پینِ انتخاب‌شده در
  LocationPicker که قبلاً نارنجی بود** (`colors.orange` → `#00D4FF`). پین‌های زمینه‌ای اگر
  `m.color` صریح داشته باشند همان را نگه می‌دارند؛ در غیر این صورت `#00D4FF`.
- انیمیشن در `globals.css`: `@keyframes pinBlink` فقط `drop-shadow` را بین
  `rgba(0,212,255,.55)` و `rgba(0,212,255,1)` طیِ `1.6s ease-in-out infinite` نوسان می‌دهد
  (نه‌ خیلی تند/حواس‌پرت‌کن). **`opacity` دست‌نمی‌خورد** تا خواناییِ پین و Popup حفظ شود.
  کلاسِ `.blink-pin` روی مسیرِ SVGِ هر CircleMarker از طریقِ `pathOptions.className` می‌نشیند.
- احترام به دسترس‌پذیری: `@media (prefers-reduced-motion: reduce)` انیمیشن را خاموش می‌کند.

### ۳) TransportMap: `Marker` → `CircleMarker` (گزینه A)
برای اینکه چشمک روی مسیرِ SVG کار کند و با دو نقشه‌ی دیگر یکدست شود، پینِ پیش‌فرضِ
`Marker` (آیکنِ img/div) به `CircleMarker` تبدیل شد: `dynamic` import عوض شد، در JSX
`position` → `center` + `radius={7}` + `pathOptions`، و `<Popup>` همان محتوای قبلی (grade/
مقدار/راننده/پلاک/زمانِ به‌روزرسانی) را به‌صورتِ فرزندِ `CircleMarker` نگه می‌دارد.

### ۴) متنِ Attribution: کوچک و کم‌رنگ (بدونِ حذف)
در `globals.css`:
```
.leaflet-container .leaflet-control-attribution { font-size: 9px; opacity: .55; background: rgba(255,255,255,.5); padding: 0 4px; }
.leaflet-container .leaflet-control-attribution:hover { opacity: 1; }
```
قید رعایت شد: `font-size` کمتر از ۸px نیست، `opacity` کمتر از ۰٫۵ نیست، و لینکِ
© OpenStreetMap قابل‌کلیک می‌ماند (hover آن را کاملاً واضح می‌کند).

## فایل‌های این بسته
- `src/data/iran-adm0.json`            ← **فایلِ جدید** (داده‌ی مرزِ ADM0)
- `src/components/IranBorder.tsx`      ← **فایلِ جدید**
- `src/components/WarehousesMap.tsx`   ← ویرایش‌شده
- `src/components/TransportMap.tsx`    ← ویرایش‌شده (Marker→CircleMarker)
- `src/components/LocationPickerMap.tsx` ← ویرایش‌شده
- `src/app/globals.css`               ← ویرایش‌شده (keyframes + blink-pin + reduced-motion + attribution)

## داده‌ی جعلی
هیچ داده‌ی جعلی/نمونه اضافه نشد. `iran-adm0.json` صرفاً هندسه‌ی مرزِ رسمیِ کشور است.

## راستی‌آزمایی
- `npx tsc --noEmit` → بدونِ خطا (EXIT=0).
- `npx next build`  → `✓ Compiled successfully` (EXIT=0).
- تستِ بصری روی سرورِ واقعی طبقِ توافق (نقشه‌ها پشتِ auth/DB هستند).
