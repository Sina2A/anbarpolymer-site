import { getCurrentUserOrNull } from '@/lib/currentUser'
import CurrencyTicker from '@/components/CurrencyTicker'

export const dynamic = 'force-dynamic'

export default async function ServicesPage() {
  const user = await getCurrentUserOrNull()

  return (
    <>
      <CurrencyTicker />
      <div className="topbar">
        <div className="wrap">
          <span>پشتیبانی فروش شنبه تا چهارشنبه ۸:۳۰ تا ۱۷:۳۰</span>
          <a className="phone" href="tel:+982191234567">
            021-91234567
          </a>
        </div>
      </div>
      <header className="site-header">
        <div className="wrap">
          <a href="/" className="logo">
            <span className="dot"></span> انبار پلیمر
          </a>
          <nav className="main-nav">
            <a href="/">صفحه اصلی</a>
            <a href="/grades">گریدها</a>
            <a href="/rfq">استعلام قیمت</a>
            <a href="/market">بازار صنعتی</a>
            <a href="/reports">گزارش بازار</a>
            <a href="/services" className="active">
              خدمات سازمانی
            </a>
            <a href="/about">درباره ما</a>
            <a href="/contact">تماس با ما</a>
          </nav>
          <div className="header-actions">
            {user ? (
              <a href="/dashboard" className="acct-btn">
                پیشخوان
              </a>
            ) : (
              <a href="/login" className="acct-btn">
                ورود / ثبت‌نام
              </a>
            )}
          </div>
        </div>
      </header>

      <section style={sectionStyle}>
        <div className="wrap">
          <div className="eyebrow">خدمات سازمانی</div>
          <div className="sec-title">خدمات انبار پلیمر برای تولیدکنندگان</div>
          <div className="sec-sub">
            از استعلام قیمت تا تحویل درب کارخانه — مجموعه‌ای کامل از خدمات تأمین مواد اولیه پلیمری برای واحدهای تولیدی.
          </div>
        </div>
      </section>

      <section className="section-line" style={sectionStyle}>
        <div className="wrap">
          <div className="eyebrow">خدمات ما</div>
          <div className="sec-title">چه کارهایی برایت انجام می‌دهیم</div>
          <div className="sec-sub" style={{ marginBottom: 26 }}>
            هر خدمت روی یک بخش واقعی پلتفرم سوار است — مستقیم از همین صفحه شروع کن.
          </div>
          <div className="grid3">
            <div className="feat-card">
              <div className="num">01</div>
              <h3>استعلام قیمت آنلاین</h3>
              <p>
                برای هر گرید از کاتالوگ، درخواست قیمت رسمی ثبت کن و پیش‌فاکتور شفاف با قیمت نهایی و مهلت تایید مشخص بگیر.
              </p>
              <a href="/rfq" className="btn btn-sm btn-outline" style={cardLinkStyle}>
                ثبت استعلام
              </a>
            </div>
            <div className="feat-card">
              <div className="num">02</div>
              <h3>بازار صنعتی دوطرفه</h3>
              <p>
                آگهی‌های عرضه‌ی فروشندگان و درخواست‌های خرید باز، همه در یک بازار شفاف — انتخاب بر اساس قیمت واقعی بازار.
              </p>
              <a href="/market" className="btn btn-sm btn-outline" style={cardLinkStyle}>
                ورود به بازار
              </a>
            </div>
            <div className="feat-card">
              <div className="num">03</div>
              <h3>فروش سازمانی و خرید عمده</h3>
              <p>
                برای خرید حجم بالا، قرارداد مستقیم با قیمت‌گذاری اختصاصی و شرایط پرداخت سازمانی — از طریق تیم فروش.
              </p>
              <a href="/contact" className="btn btn-sm btn-outline" style={cardLinkStyle}>
                گفت‌وگو با تیم فروش
              </a>
            </div>
            <div className="feat-card">
              <div className="num">04</div>
              <h3>ارسال و لجستیک سراسری</h3>
              <p>
                تحویل از شبکه‌ی انبارها به سراسر کشور؛ تخصیص راننده، ثبت بارنامه و رهگیری مرسوله تا لحظه‌ی تحویل.
              </p>
              <a href="/warehouses" className="btn btn-sm btn-outline" style={cardLinkStyle}>
                مشاهده‌ی انبارها
              </a>
            </div>
            <div className="feat-card">
              <div className="num">05</div>
              <h3>کاتالوگ گریدها و دیتاشیت</h3>
              <p>
                مشخصات فنی استاندارد (MFI، دانسیته و…)، دیتاشیت و تصویر واقعی هر گرید از برندهای مختلف — برای مقایسه‌ی دقیق.
              </p>
              <a href="/grades" className="btn btn-sm btn-outline" style={cardLinkStyle}>
                مرور کاتالوگ
              </a>
            </div>
            <div className="feat-card">
              <div className="num">06</div>
              <h3>گزارش بازار و تحلیل قیمت</h3>
              <p>
                شاخص‌های بنچمارک دلاری هر گرید و تحلیل‌های منظم بازار، برای تصمیم‌گیری به‌موقع در زمان‌بندی خرید.
              </p>
              <a href="/reports" className="btn btn-sm btn-outline" style={cardLinkStyle}>
                دیدن گزارش‌ها
              </a>
            </div>
          </div>
        </div>
      </section>

      <section className="section-line" style={sectionStyle}>
        <div className="wrap">
          <div className="eyebrow">روند همکاری</div>
          <div className="sec-title">مسیر یک خرید موفق</div>
          <div className="sec-sub" style={{ marginBottom: 40 }}>
            از ثبت‌نام تا تحویل کالا درب کارخانه — همه‌ی مراحل داخل پلتفرم ثبت و قابل پیگیری است.
          </div>
          <div className="stepper">
            <div className="step on">
              <span className="dot"></span>
              <div className="lab">ثبت‌نام و احراز هویت</div>
            </div>
            <div className="step on">
              <span className="dot"></span>
              <div className="lab">انتخاب گرید و ثبت سفارش</div>
            </div>
            <div className="step on">
              <span className="dot"></span>
              <div className="lab">دریافت پیش‌فاکتور رسمی</div>
            </div>
            <div className="step on">
              <span className="dot"></span>
              <div className="lab">پرداخت و تایید فیش</div>
            </div>
            <div className="step on">
              <span className="dot"></span>
              <div className="lab">ارسال از انبار و تحویل</div>
            </div>
          </div>

          <ul className="check-list" style={{ marginTop: 38 }}>
            <li>پیش‌فاکتور رسمی با مهلت تایید مشخص — بدون قیمت پنهان</li>
            <li>تایید فیش پرداخت توسط تیم مالی، قبل از خروج کالا از انبار</li>
            <li>امتیازدهی دوطرفه‌ی خریدار و فروشنده پس از تحویل، برای شفافیت معاملات بعدی</li>
            <li>احراز هویت اجباری طرفین معامله (KYC) پیش از شروع خرید و فروش</li>
          </ul>
        </div>
      </section>

      <section className="section-line" style={sectionStyle}>
        <div className="wrap">
          <div className="eyebrow">شروع کار</div>
          <div className="sec-title">آماده‌ی شروع هستی؟</div>
          <div className="sec-sub" style={{ marginBottom: 22 }}>
            حساب بساز، احراز هویت را کامل کن و اولین استعلام قیمتت را همین امروز ثبت کن.
          </div>
          <div style={ctaRowStyle}>
            <a href="/rfq" className="btn btn-cyan">
              ثبت استعلام قیمت
            </a>
            <a href={user ? '/verification' : '/login'} className="btn btn-outline">
              {user ? 'تکمیل احراز هویت' : 'ورود / ثبت‌نام'}
            </a>
          </div>
        </div>
      </section>

      <footer className="site-footer">
        <div className="wrap">
          <div className="footer-cols">
            <div>
              <a href="/" className="logo" style={{ marginBottom: 14, display: 'flex' }}>
                <span className="dot"></span> انبار پلیمر
              </a>
              <p style={{ color: 'var(--ink-dim)', fontSize: 13, maxWidth: 280 }}>
                واردکننده و فروشنده مستقیم مواد اولیه پلیمری برای کارخانه‌های تولیدی سراسر کشور.
              </p>
            </div>
            <div>
              <h5>محصولات</h5>
              <ul>
                <li>
                  <a href="/grades">پلی‌پروپیلن</a>
                </li>
                <li>
                  <a href="/grades">پلی‌اتیلن</a>
                </li>
                <li>
                  <a href="/grades">پی‌وی‌سی</a>
                </li>
                <li>
                  <a href="/grades">پلی‌اتیلن ترفتالات</a>
                </li>
              </ul>
            </div>
            <div>
              <h5>خدمات</h5>
              <ul>
                <li>
                  <a href="/rfq">استعلام قیمت آنلاین</a>
                </li>
                <li>
                  <a href="/market">بازار صنعتی</a>
                </li>
                <li>
                  <a href="/services">فروش سازمانی</a>
                </li>
                <li>
                  <a href="/reports">گزارش بازار</a>
                </li>
              </ul>
            </div>
            <div>
              <h5>اطلاعات تماس</h5>
              <ul>
                <li>تهران، خیابان ولیعصر، پلاک ۱۲۴</li>
                <li>انبار یزد — شهرک صنعتی یزد</li>
                <li style={{ direction: 'ltr', textAlign: 'right' }}>021-91234567</li>
              </ul>
            </div>
          </div>
          <div className="footer-bottom">
            <span>انبار پلیمر © ۱۴۰۵ — تمام حقوق محفوظ است</span>
          </div>
        </div>
      </footer>
    </>
  )
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const sectionStyle: React.CSSProperties = { padding: '56px 0' }
const cardLinkStyle: React.CSSProperties = { marginTop: 14 }
const ctaRowStyle: React.CSSProperties = { display: 'flex', gap: 12, flexWrap: 'wrap' }
