import prisma from '@/lib/prisma'
import { getCurrentUserOrNull } from '@/lib/currentUser'
import CurrencyTicker from '@/components/CurrencyTicker'

export const dynamic = 'force-dynamic'

function faDate(d: Date | null | undefined): string {
  if (!d) return '—'
  return new Date(d).toLocaleDateString('fa-IR')
}

// خلاصه‌ی متن مقاله برای کارت‌ها — ۱۶۰ کاراکتر اول، بدون شکستگی خط
function excerptOf(content: string): string {
  const flat = content.trim().replace(/\s+/g, ' ')
  return flat.length > 160 ? flat.slice(0, 160) + '…' : flat
}

export default async function ReportsPage() {
  const user = await getCurrentUserOrNull()
  const now = new Date()

  // ── مقالات منتشرشده — isPublished با تاریخ انتشار گذشته ──
  // نکته‌ی امنیتی: هرگز include: { user } نکن — author فقط با select: { companyName } می‌آید.
  const articles = await prisma.article.findMany({
    where: { isPublished: true, publishedAt: { not: null, lte: now } },
    include: { author: { select: { companyName: true } } },
    orderBy: { publishedAt: 'desc' },
    take: 12,
  })
  const featured = articles[0]
  const sideCards = articles.slice(1, 3)
  const listArticles = articles.slice(3)

  // ── شاخص‌های بنچمارک — آخرین قیمت دلاری ثبت‌شده برای هر گرید ──
  // GlobalBenchmarkPrice رابطه‌ی Prisma به Grade ندارد؛ کد گرید جداگانه خوانده می‌شود.
  const rawBenchmarks = await prisma.globalBenchmarkPrice.findMany({
    orderBy: { effectiveDate: 'desc' },
    take: 80,
  })
  const seenGradeIds = new Set<string>()
  const latestPerGrade: typeof rawBenchmarks = []
  for (const b of rawBenchmarks) {
    if (seenGradeIds.has(b.gradeId)) continue
    seenGradeIds.add(b.gradeId)
    latestPerGrade.push(b)
    if (latestPerGrade.length >= 8) break
  }
  const grades = latestPerGrade.length
    ? await prisma.grade.findMany({
        where: { id: { in: latestPerGrade.map((b) => b.gradeId) } },
        select: { id: true, code: true },
      })
    : []
  const gradeCodeById = new Map(grades.map((g) => [g.id, g.code]))
  const benchmarks: Array<(typeof rawBenchmarks)[number] & { gradeCode: string }> = []
  for (const b of latestPerGrade) {
    const gradeCode = gradeCodeById.get(b.gradeId)
    if (!gradeCode) continue
    benchmarks.push({ ...b, gradeCode })
  }

  return (
    <>
      <CurrencyTicker />
      <div className="topbar">
        <div className="wrap">
          <span>پشتیبانی فروش شنبه تا چهارشنبه ۸:۳۰ تا ۱۷:۳۰</span>
          <a className="phone" href="tel:+982191234567">
            021-91234567
          </a>
        </div>
      </div>
      <header className="site-header">
        <div className="wrap">
          <a href="/" className="logo">
            <span className="dot"></span> انبار پلیمر
          </a>
          <nav className="main-nav">
            <a href="/">صفحه اصلی</a>
            <a href="/grades">گریدها</a>
            <a href="/rfq">استعلام قیمت</a>
            <a href="/market">بازار صنعتی</a>
            <a href="/reports" className="active">
              گزارش بازار
            </a>
            <a href="/services">خدمات سازمانی</a>
            <a href="/about">درباره ما</a>
            <a href="/contact">تماس با ما</a>
          </nav>
          <div className="header-actions">
            {user ? (
              <a href="/dashboard" className="acct-btn">
                پیشخوان
              </a>
            ) : (
              <a href="/login" className="acct-btn">
                ورود / ثبت‌نام
              </a>
            )}
          </div>
        </div>
      </header>

      <section style={sectionStyle}>
        <div className="wrap">
          <div className="eyebrow">گزارش بازار</div>
          <div className="sec-title">گزارش‌ها و تحلیل‌های بازار پلیمر</div>
          <div className="sec-sub">
            تحلیل قیمت‌ها، شاخص‌های بنچمارک جهانی و اخبار بازار مواد اولیه پلیمری — به‌روزرسانی مستمر توسط تیم کارشناسی انبار پلیمر.
          </div>
        </div>
      </section>

      {benchmarks.length > 0 && (
        <section className="section-line" style={sectionStyle}>
          <div className="wrap">
            <div className="eyebrow">شاخص‌های امروز</div>
            <div className="sec-title">آخرین قیمت‌های بنچمارک</div>
            <div className="sec-sub" style={{ marginBottom: 20 }}>
              جدیدترین قیمت دلاری ثبت‌شده برای هر گرید، از منابع مرجع جهانی.
            </div>
            <div className="price-block">
              <h4>قیمت بنچمارک دلاری</h4>
              <div className="hint">صرفاً جهت اطلاع — قیمت معاملاتی نهایی در استعلام قیمت اعلام می‌شود.</div>
              <table>
                <thead>
                  <tr>
                    <th>کد گرید</th>
                    <th>قیمت بنچمارک</th>
                    <th>منبع</th>
                    <th>تاریخ اعتبار</th>
                  </tr>
                </thead>
                <tbody>
                  {benchmarks.map((b) => (
                    <tr key={b.id}>
                      <td>
                        <a href={`/grades/${encodeURIComponent(b.gradeCode)}`} style={gradeCodeStyle}>
                          {b.gradeCode}
                        </a>
                      </td>
                      <td>
                        <span className="num-val" style={priceStyle}>
                          {b.priceUsd.toLocaleString('fa-IR')} دلار
                        </span>
                      </td>
                      <td>{b.sourceLabel ?? '—'}</td>
                      <td>{faDate(b.effectiveDate)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      )}

      <section className="section-line" style={sectionStyle}>
        <div className="wrap">
          <div className="eyebrow">مقالات و اخبار</div>
          <div className="sec-title">جدیدترین گزارش‌ها</div>
          <div className="sec-sub" style={{ marginBottom: 26 }}>
            تحلیل‌ها و اطلاعیه‌های بازار که توسط تیم انبار پلیمر منتشر می‌شوند.
          </div>

          {articles.length === 0 ? (
            <div className="empty-state">هنوز گزارشی منتشر نشده است — به‌زودی گزارش‌ها و تحلیل‌های بازار پلیمر اینجا منتشر می‌شود.</div>
          ) : (
            <>
              {featured && (
                <div className="featured-grid">
                  <a href={`/reports/${featured.id}`} className="featured-main">
                    <span className="cat-badge">گزارش بازار</span>
                    <div>
                      <h3>{featured.title}</h3>
                      <div style={featuredTimeStyle}>
                        {faDate(featured.publishedAt)}
                        {featured.author?.companyName ? ` — ${featured.author.companyName}` : ''}
                      </div>
                    </div>
                  </a>
                  {sideCards.length > 0 && (
                    <div className="featured-side">
                      {sideCards.map((a) => (
                        <a key={a.id} href={`/reports/${a.id}`} className="featured-side-card">
                          <span className="cat-badge">گزارش بازار</span>
                          <div>
                            <h4>{a.title}</h4>
                            <div style={featuredTimeStyle}>{faDate(a.publishedAt)}</div>
                          </div>
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {listArticles.length > 0 && (
                <div className="article-list">
                  {listArticles.map((a) => (
                    <a key={a.id} href={`/reports/${a.id}`} className="article-row">
                      <div className="thumb"></div>
                      <div className="content">
                        <div className="time">
                          {faDate(a.publishedAt)}
                          {a.author?.companyName ? ` — ${a.author.companyName}` : ''}
                        </div>
                        <h4>{a.title}</h4>
                        <p>{excerptOf(a.content)}</p>
                      </div>
                    </a>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </section>

      <footer className="site-footer">
        <div className="wrap">
          <div className="footer-cols">
            <div>
              <a href="/" className="logo" style={{ marginBottom: 14, display: 'flex' }}>
                <span className="dot"></span> انبار پلیمر
              </a>
              <p style={{ color: 'var(--ink-dim)', fontSize: 13, maxWidth: 280 }}>
                واردکننده و فروشنده مستقیم مواد اولیه پلیمری برای کارخانه‌های تولیدی سراسر کشور.
              </p>
            </div>
            <div>
              <h5>محصولات</h5>
              <ul>
                <li>
                  <a href="/grades">پلی‌پروپیلن</a>
                </li>
                <li>
                  <a href="/grades">پلی‌اتیلن</a>
                </li>
                <li>
                  <a href="/grades">پی‌وی‌سی</a>
                </li>
                <li>
                  <a href="/grades">پلی‌اتیلن ترفتالات</a>
                </li>
              </ul>
            </div>
            <div>
              <h5>خدمات</h5>
              <ul>
                <li>
                  <a href="/rfq">استعلام قیمت آنلاین</a>
                </li>
                <li>
                  <a href="/market">بازار صنعتی</a>
                </li>
                <li>
                  <a href="/services">فروش سازمانی</a>
                </li>
                <li>
                  <a href="/reports">گزارش بازار</a>
                </li>
              </ul>
            </div>
            <div>
              <h5>اطلاعات تماس</h5>
              <ul>
                <li>تهران، خیابان ولیعصر، پلاک ۱۲۴</li>
                <li>انبار یزد — شهرک صنعتی یزد</li>
                <li style={{ direction: 'ltr', textAlign: 'right' }}>021-91234567</li>
              </ul>
            </div>
          </div>
          <div className="footer-bottom">
            <span>انبار پلیمر © ۱۴۰۵ — تمام حقوق محفوظ است</span>
          </div>
        </div>
      </footer>
    </>
  )
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const sectionStyle: React.CSSProperties = { padding: '56px 0' }
const gradeCodeStyle: React.CSSProperties = {
  fontFamily: 'var(--mono)',
  fontWeight: 600,
  fontSize: 13,
  color: 'var(--ink)',
}
const priceStyle: React.CSSProperties = {
  fontFamily: 'var(--mono)',
  color: 'var(--cyan)',
  fontWeight: 700,
}
const featuredTimeStyle: React.CSSProperties = {
  fontSize: 11.5,
  color: 'var(--ink-mute)',
  fontFamily: 'var(--mono)',
  marginTop: 8,
}
