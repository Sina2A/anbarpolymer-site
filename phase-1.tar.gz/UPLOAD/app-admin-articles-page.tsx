import prisma from '@/lib/prisma'
import { getAllSectionAccess } from '@/lib/permissions'
import { getCurrentUser } from '@/lib/currentUser'
import AdminNav, { PartialAccessBanner } from '@/components/AdminNav'
import { createArticleAction, togglePublishAction } from './actions'

export const dynamic = 'force-dynamic'

type SearchParams = Promise<Record<string, string | string[] | undefined>>

function one(v: string | string[] | undefined): string | undefined {
  if (Array.isArray(v)) return v[0]
  return v
}

function faDate(d: Date | null | undefined): string {
  if (!d) return '—'
  return new Date(d).toLocaleDateString('fa-IR')
}

const TABS: { key: string; label: string }[] = [
  { key: 'all', label: 'همه' },
  { key: 'published', label: 'منتشرشده' },
  { key: 'scheduled', label: 'زمان‌بندی‌شده' },
  { key: 'draft', label: 'پیش‌نویس' },
]

// وضعیت نمایشی مقاله — ترکیب isPublished و تاریخ انتشار:
//   isPublished=false                       → پیش‌نویس
//   isPublished=true  و تاریخ <= الان        → منتشرشده
//   isPublished=true  و تاریخ > الان         → زمان‌بندی‌شده
function articleStatus(a: { isPublished: boolean; publishedAt: Date | null }): 'published' | 'scheduled' | 'draft' {
  if (!a.isPublished) return 'draft'
  if (a.publishedAt && a.publishedAt.getTime() > Date.now()) return 'scheduled'
  return 'published'
}

const STATUS_META: Record<string, { label: string; style: React.CSSProperties }> = {
  published: { label: 'منتشرشده', style: { fontSize: 10, fontWeight: 700, color: '#065f46', background: '#d1fae5', borderRadius: 6, padding: '2px 8px', whiteSpace: 'nowrap' } },
  scheduled: { label: 'زمان‌بندی‌شده', style: { fontSize: 10, fontWeight: 700, color: '#92400e', background: '#fef3c7', borderRadius: 6, padding: '2px 8px', whiteSpace: 'nowrap' } },
  draft: { label: 'پیش‌نویس', style: { fontSize: 10, fontWeight: 700, color: '#4b5563', background: '#e5e7eb', borderRadius: 6, padding: '2px 8px', whiteSpace: 'nowrap' } },
}

export default async function AdminArticlesPage({ searchParams }: { searchParams: SearchParams }) {
  const sp = await searchParams
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)
  const myLevel = isAdmin ? 'full' : (myAccess?.['articles'] ?? 'none')
  const canEdit = myLevel === 'full' || myLevel === 'edit'

  const activeTab = one(sp.tab) || 'all'
  const now = new Date()

  // شمارش تب‌ها — فقط فیلدهای سبک؛ متن مقاله‌ها لود نمی‌شه
  const all = await prisma.article.findMany({
    select: { id: true, isPublished: true, publishedAt: true },
  })
  const tabCount: Record<string, number> = { all: all.length, published: 0, scheduled: 0, draft: 0 }
  for (const a of all) tabCount[articleStatus(a)]++

  // کوئری نمایش تب فعال — باز بدون فیلد content (متن کامل فقط توی صفحه‌ی خود مقاله)
  const articles = await prisma.article.findMany({
    where:
      activeTab === 'published'
        ? { isPublished: true, OR: [{ publishedAt: null }, { publishedAt: { lte: now } }] }
        : activeTab === 'scheduled'
          ? { isPublished: true, publishedAt: { gt: now } }
          : activeTab === 'draft'
            ? { isPublished: false }
            : {},
    orderBy: [{ publishedAt: 'desc' }, { createdAt: 'desc' }],
    select: {
      id: true,
      title: true,
      isPublished: true,
      publishedAt: true,
      createdAt: true,
      updatedAt: true,
      author: { select: { companyName: true } },
    },
  })

  return (
    <div className="admin-page-wrap" style={{ display: 'flex', gap: 24, padding: '32px 24px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', maxWidth: 1100, margin: '0 auto' }}>
      <AdminNav currentUserName={currentUser.companyName} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="articles" />

      <div style={{ flex: 1, minWidth: 0 }}>
        <PartialAccessBanner level={myLevel} sectionLabel="مقالات و اخبار" />

        <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 8 }}>مقالات و اخبار</h1>
        <p style={{ color: '#6f7680', fontSize: 13.5, marginBottom: 20, lineHeight: 1.9 }}>
          محتوای تحلیلی و خبری انبار پلیمر — نوشتن، ویرایش و انتشار. صفحه‌ی عمومی نمایش مقاله‌ها هنوز ساخته نشده؛ فعلاً این بخش فقط محل آماده‌سازی محتواست.
        </p>

        {/* ── نوشتن مقاله‌ی جدید (باز/بسته‌شونده) ── */}
        {canEdit && (
          <details style={{ ...cardStyle, padding: 0, marginBottom: 20, overflow: 'hidden' }}>
            <summary style={{ padding: '14px 16px', cursor: 'pointer', fontSize: 13.5, fontWeight: 700, color: '#1e357b' }}>
              ➕ نوشتن مقاله‌ی جدید
            </summary>
            <form action={createArticleAction} style={{ padding: '4px 16px 16px', borderTop: '1px solid #eceff3' }}>
              <div style={{ marginBottom: 14, marginTop: 12 }}>
                <div style={labelStyle}>عنوان</div>
                <input name="title" required maxLength={200} placeholder="مثلاً: تحلیل بازار پلی‌اتیلن — شهریور"
                  style={inputStyle} />
              </div>
              <div style={{ marginBottom: 14 }}>
                <div style={labelStyle}>تاریخ انتشار <span style={hintInline}>(اختیاری — خالی باشه موقع انتشار خودکار ثبت می‌شه؛ تاریخ آینده = زمان‌بندی)</span></div>
                <input type="datetime-local" name="publishedAt"
                  style={{ ...inputStyle, direction: 'ltr', textAlign: 'left' }} />
              </div>
              <div style={{ marginBottom: 14 }}>
                <div style={labelStyle}>متن مقاله</div>
                <textarea name="content" rows={10} required maxLength={50000} placeholder="متن کامل مقاله یا خبر…"
                  style={{ ...inputStyle, resize: 'vertical' }} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
                <span style={hintStyle}>مقاله به‌صورت پیش‌نویس ذخیره می‌شه؛ انتشارش جداگانه انجام می‌شه.</span>
                <button type="submit" style={submitBtnStyle}>ذخیره‌ی پیش‌نویس</button>
              </div>
            </form>
          </details>
        )}

        {/* ── تب‌های فیلتر ── */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 18, flexWrap: 'wrap' }}>
          {TABS.map((tab) => {
            const isActive = activeTab === tab.key
            const n = tabCount[tab.key] || 0
            return (
              <a
                key={tab.key}
                href={`/admin-articles?tab=${tab.key}`}
                style={{
                  padding: '7px 16px', borderRadius: 8, fontSize: 12.5, fontWeight: 700,
                  textDecoration: 'none', border: '1px solid',
                  borderColor: isActive ? '#1e357b' : '#d8dde3',
                  background: isActive ? '#1e357b' : '#fff',
                  color: isActive ? '#fff' : '#4f5560',
                }}
              >
                {tab.label} <span style={{ opacity: 0.75, fontFamily: 'monospace' }}>({n})</span>
              </a>
            )
          })}
        </div>

        {/* ── لیست مقاله‌ها ── */}
        {articles.length === 0 ? (
          <div style={emptyStyle}>مقاله‌ای در این دسته نیست.</div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {articles.map((a) => {
              const meta = STATUS_META[articleStatus(a)]
              return (
                <div key={a.id} style={cardStyle}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, marginBottom: 6, flexWrap: 'wrap' }}>
                    <a href={`/admin-articles/${a.id}`} style={{ fontSize: 14, fontWeight: 700, color: '#1e357b', textDecoration: 'none' }}>
                      {a.title}
                    </a>
                    <span style={meta.style}>{meta.label}</span>
                  </div>

                  <div style={{ fontSize: 11.5, color: '#9199a3' }}>
                    نویسنده: <b style={{ color: '#4f5560' }}>{a.author?.companyName ?? '—'}</b>
                    {' | '}ساخته: {faDate(a.createdAt)}
                    {' | '}آخرین ویرایش: {faDate(a.updatedAt)}
                    {a.publishedAt && (
                      <>{' | '}انتشار: {faDate(a.publishedAt)}</>
                    )}
                  </div>

                  {canEdit && (
                    <div style={{ display: 'flex', gap: 8, marginTop: 12, paddingTop: 10, borderTop: '1px solid #eceff3', flexWrap: 'wrap' }}>
                      <form action={togglePublishAction}>
                        <input type="hidden" name="id" value={a.id} />
                        {a.isPublished ? (
                          <button type="submit" style={unpublishBtnStyle}>لغو انتشار</button>
                        ) : (
                          <button type="submit" style={actionBtnStyle}>انتشار</button>
                        )}
                      </form>
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        )}

        {!canEdit && articles.length > 0 && (
          <p style={{ fontSize: 11.5, color: '#9199a3', marginTop: 12 }}>
            برای نوشتن، ویرایش یا انتشار مقاله، دسترسی ویرایش این بخش لازمه.
          </p>
        )}
      </div>
    </div>
  )
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const cardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3', borderRadius: 12, padding: 16,
  background: '#fff', boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const labelStyle: React.CSSProperties = {
  fontSize: 12.5, fontWeight: 700, color: '#4f5560', marginBottom: 5,
}
const hintInline: React.CSSProperties = {
  fontWeight: 400, color: '#9199a3', fontSize: 11,
}
const inputStyle: React.CSSProperties = {
  border: '1px solid #d8dde3', borderRadius: 8,
  padding: '10px 12px', fontSize: 13, fontFamily: 'inherit',
  width: '100%', boxSizing: 'border-box',
}
const hintStyle: React.CSSProperties = {
  fontSize: 11.5, color: '#9199a3',
}
const submitBtnStyle: React.CSSProperties = {
  background: '#1e357b', color: '#fff', border: 'none', borderRadius: 8,
  padding: '10px 28px', fontSize: 13.5, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit',
}
const actionBtnStyle: React.CSSProperties = {
  background: '#f1efe8', color: '#4f5560', border: '1px solid #d8dde3', borderRadius: 8,
  padding: '7px 14px', fontSize: 12, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit',
}
const unpublishBtnStyle: React.CSSProperties = {
  background: 'none', color: '#9b1c1c', border: 'none', borderRadius: 8,
  padding: '7px 10px', fontSize: 12, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit',
}
const emptyStyle: React.CSSProperties = {
  padding: 32, textAlign: 'center', color: '#9199a3',
  border: '1px dashed #d8dde3', borderRadius: 12, fontSize: 13,
}
