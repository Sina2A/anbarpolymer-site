import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

const ADMIN_PATH_PREFIXES = ['/admin-', '/my-tasks']
const ALWAYS_ALLOWED = ['/login', '/logout']

export function middleware(request: NextRequest) {
  const surface = process.env.SURFACE === 'admin' ? 'admin' : 'public'
  const { pathname } = request.nextUrl

  if (ALWAYS_ALLOWED.some((p) => pathname === p || pathname.startsWith(p + '/'))) {
    return NextResponse.next()
  }

  const isAdminPath = ADMIN_PATH_PREFIXES.some((p) => pathname.startsWith(p))

  if (surface === 'admin' && !isAdminPath) {
    return NextResponse.rewrite(new URL('/404', request.url))
  }
  if (surface === 'public' && isAdminPath) {
    return NextResponse.rewrite(new URL('/404', request.url))
  }

  return NextResponse.next()
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|uploads).*)'],
}
