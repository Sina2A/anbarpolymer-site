'use client'

import { useEffect, useState } from 'react'
import { colors } from '@/lib/styles/tokens'
import type { CSSProperties } from 'react'

const NAV_ITEMS = [
  { label: 'صفحه اصلی', href: '/' },
  { label: 'گریدها', href: '/grades' },
  { label: 'استعلام قیمت', href: '/rfq' },
  { label: 'بازار صنعتی', href: '/market' },
  { label: 'گزارش بازار', href: '/reports' },
  { label: 'خدمات سازمانی', href: '/services' },
  { label: 'درباره ما', href: '/about' },
  { label: 'تماس با ما', href: '/contact' },
]

export default function PublicHeader({
  activePage,
  isLoggedIn = false,
}: {
  activePage?: string
  isLoggedIn?: boolean
}) {
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 900) setMenuOpen(false)
    }
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  return (
    <>
      <div style={topbarStyle}>
        <div style={wrapStyle}>
          <span style={{ opacity: 0.85 }}>
            پشتیبانی فروش شنبه تا چهارشنبه ۸:۳۰ تا ۱۷:۳۰
          </span>
          <a href="tel:+982191234567" style={phoneStyle}>
            021-91234567
          </a>
        </div>
      </div>

      <header style={headerStyle}>
        <div style={wrapStyle}>
          <a href="/" style={logoStyle}>
            <span style={logoDotStyle} />
            انبار پلیمر
          </a>

          <nav style={navStyle} data-public-nav="true">
            {NAV_ITEMS.map((item) => (
              <a
                key={item.href}
                href={item.href}
                style={{
                  ...navLinkStyle,
                  color: activePage === item.href ? '#ffffff' : 'rgba(255,255,255,0.78)',
                  fontWeight: activePage === item.href ? 700 : 600,
                }}
              >
                {item.label}
              </a>
            ))}
          </nav>

          <div style={actionsStyle}>
            <a
              href={isLoggedIn ? '/dashboard' : '/login'}
              style={acctBtnStyle}
            >
              {isLoggedIn ? 'پیشخوان' : 'ورود / ثبت‌نام'}
            </a>

            <button
              onClick={() => setMenuOpen(!menuOpen)}
              style={hamburgerBtnStyle}
              data-public-hamburger="true"
              aria-label="منو"
            >
              ☰
            </button>
          </div>
        </div>

        {menuOpen && (
          <div style={mobileMenuStyle}>
            {NAV_ITEMS.map((item) => (
              <a
                key={item.href}
                href={item.href}
                style={{
                  ...mobileLinkStyle,
                  color: activePage === item.href ? '#ffffff' : 'rgba(255,255,255,0.85)',
                  background: activePage === item.href ? 'rgba(255,255,255,0.12)' : 'transparent',
                }}
              >
                {item.label}
              </a>
            ))}
            <a
              href={isLoggedIn ? '/dashboard' : '/login'}
              style={{ ...mobileLinkStyle, fontWeight: 700, borderTop: '1px solid rgba(255,255,255,0.2)' }}
            >
              {isLoggedIn ? 'پیشخوان' : 'ورود / ثبت‌نام'}
            </a>
          </div>
        )}
      </header>
    </>
  )
}

const topbarStyle: CSSProperties = {
  background: colors.navyDark,
  borderBottom: '1px solid rgba(255,255,255,0.15)',
  fontSize: 12.5,
  color: 'rgba(255,255,255,0.85)',
  fontFamily: 'var(--font-label)',
}

const headerStyle: CSSProperties = {
  position: 'sticky',
  top: 0,
  zIndex: 50,
  background: colors.navy,
  borderBottom: `1px solid ${colors.navyDark}`,
  boxShadow: '0 2px 10px rgba(30,53,123,0.25)',
}

// ──────────────────────────────────────────────────────────
// استایل‌ها
// ──────────────────────────────────────────────────────────
const wrapStyle: CSSProperties = {
  maxWidth: 1180,
  margin: '0 auto',
  padding: '0 24px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  height: 72,
  gap: 24,
}

const logoStyle: CSSProperties = {
  fontWeight: 800,
  fontSize: 19,
  letterSpacing: '-0.01em',
  display: 'flex',
  alignItems: 'center',
  gap: 8,
  color: '#ffffff',
  fontFamily: 'var(--font-heading)',
  textDecoration: 'none',
}

const logoDotStyle: CSSProperties = {
  width: 8,
  height: 8,
  borderRadius: '50%',
  background: colors.orange,
  boxShadow: '0 0 0 4px rgba(230,87,22,0.28)',
}

const navStyle: CSSProperties = {
  display: 'flex',
  gap: 26,
  fontSize: 14,
  fontWeight: 600,
  fontFamily: 'var(--font-label)',
}

const navLinkStyle: CSSProperties = {
  color: 'rgba(255,255,255,0.78)',
  textDecoration: 'none',
  transition: 'color 0.15s',
}

const actionsStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 14,
}

const acctBtnStyle: CSSProperties = {
  border: '1px solid rgba(255,255,255,0.55)',
  borderRadius: 8,
  padding: '8px 16px',
  fontSize: 13,
  color: '#ffffff',
  textDecoration: 'none',
}

const phoneStyle: CSSProperties = {
  color: '#ffffff',
  fontWeight: 600,
  fontFamily: 'monospace',
  direction: 'ltr',
  display: 'inline-block',
  textDecoration: 'none',
}

const hamburgerBtnStyle: CSSProperties = {
  display: 'none',
  background: 'transparent',
  border: '1px solid rgba(255,255,255,0.4)',
  borderRadius: 6,
  color: '#ffffff',
  fontSize: 18,
  padding: '4px 10px',
  cursor: 'pointer',
}

const mobileMenuStyle: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  background: colors.navyDark,
  borderTop: '1px solid rgba(255,255,255,0.15)',
  padding: '8px 0',
}

const mobileLinkStyle: CSSProperties = {
  padding: '12px 24px',
  fontSize: 14,
  fontWeight: 600,
  color: 'rgba(255,255,255,0.85)',
  textDecoration: 'none',
}
