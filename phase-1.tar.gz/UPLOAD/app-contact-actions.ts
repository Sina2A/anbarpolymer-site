'use server'

import prisma from '@/lib/prisma'
import { logAudit } from '@/lib/logger'
import { redirect } from 'next/navigation'

// فرم عمومی تماس با ما — بدون هیچ احراز هویتی.
// هر بازدیدکننده‌ی مهمون می‌تونه پیام بذاره؛ فقط سه فیلد ساده.
// جوابی از توی سیستم داده نمی‌شه (نه ایمیل، نه پیامک) — کارشناس فقط می‌خونش.

export async function submitContactAction(formData: FormData) {
  const name = String(formData.get('name') || '').trim()
  const contact = String(formData.get('contact') || '').trim()
  const body = String(formData.get('body') || '').trim()

  if (!name) throw new Error('نامت رو بنویس.')
  if (!contact) throw new Error('یه راه تماس (ایمیل یا شماره) بذار تا بتونیم پیگیری کنیم.')
  if (!body) throw new Error('متن پیام خالیه.')
  if (name.length > 80) throw new Error('نام خیلی بلنده.')
  if (contact.length > 120) throw new Error('راه تماس خیلی بلنده.')
  if (body.length > 2000) throw new Error('متن پیام خیلی بلنده — کوتاه‌ترش کن.')

  await prisma.contactMessage.create({
    data: { name, contact, body },
  })

  // کاربر مهمونه — userId نداریم؛ فقط رد پای لاگ
  await logAudit('contact', `پیام تماس با ما از ${name}`, null, { name, contact })

  redirect('/contact?sent=1')
}
