import prisma from './prisma'
import { getSessionUser } from './auth'
import { redirect } from 'next/navigation'
import { headers } from 'next/headers'

/**
 * قبلاً این تابع یه پل موقت بود (انتخاب کاربر از dropdown چون سیستم ورود
 * نداشتیم). حالا واقعاً از روی کوکی نشست، کاربر لاگین‌شده رو برمی‌گردونه.
 * اگه لاگین نباشه، مستقیم به /login هدایت می‌کنه.
 *
 * گیت نقش برای SURFACE=admin — بخش ۱ِ prompt-role-gate-fix:
 * middleware روی Edge اجراست و به session/DB دسترسی نداره (فقط مسیر رو می‌بنده)،
 * پس همین‌جا که به User کامل (شامل role) دسترسی داریم، اگه روی پورت ادمین
 * باشیم و نقش کاربر buyer باشه، مستقیم به پورت عمومی ریدایرکت می‌کنیم.
 * این گیت روی :3000 بی‌اثره (SURFACE!=='admin')، پس دسترسی buyer به
 * صفحات خودش (dashboard/my-orders/...) مختل نمی‌شه و حلقه‌ی ریدایرکت هم
 * پیش نمیاد. کوکی anbar_session بین پورت‌ها مشترک است (پورت در scope کوکی نیست).
 */
export async function getCurrentUser() {
  const user = await getSessionUser()
  if (!user) {
    redirect('/login')
  }
  if (process.env.SURFACE === 'admin' && user.role !== 'staff' && user.role !== 'admin') {
    const h = await headers()
    const hostname = (h.get('host') || '').split(':')[0] || 'localhost'
    const proto = h.get('x-forwarded-proto') || 'http'
    redirect(`${proto}://${hostname}:3000/dashboard`)
  }
  return user
}

/** نسخه‌ای که ریدایرکت نمی‌کنه — برای جاهایی که فقط می‌خوایم چک کنیم لاگینه یا نه */
export async function getCurrentUserOrNull() {
  return getSessionUser()
}

export async function getAllStaffForPicker() {
  return prisma.user.findMany({
    where: { role: { in: ['staff', 'admin'] }, isActive: true },
    orderBy: { createdAt: 'asc' },
  })
}
