import { getLatestRates, minutesAgo } from '@/lib/exchangeRates'

/**
 * CurrencyTicker — server component, display-only.
 *
 * Shows latest USD/EUR rates from ExchangeRate table above the page header.
 * Has ZERO connection to PriceRecord / pricing engine / benchmark calculations.
 *
 * Usage: place <CurrencyTicker /> at the top of any public page's JSX,
 * above the header/topbar.
 */

const CURRENCY_LABELS: Record<string, string> = {
  USD: 'دلار',
  EUR: 'یورو',
}

export default async function CurrencyTicker() {
  const rates = await getLatestRates(['USD', 'EUR'])

  if (rates.length === 0) {
    return null // no rates scraped yet — render nothing
  }

  return (
    <div style={tickerWrap}>
      <div style={tickerInner}>
        <span style={tickerLabel}>{'💱'} نرخ لحظه‌ای:</span>
        <div style={ratesRow}>
          {rates.map((r) => {
            const mins = minutesAgo(r.scrapedAt)
            const fresh = mins < 30
            return (
              <span key={r.currency} style={rateItem}>
                <span style={currencyName}>{CURRENCY_LABELS[r.currency] ?? r.currency}</span>
                <span style={rateValue}>{r.rateToToman.toLocaleString('fa-IR')}</span>
                <span style={tomanUnit}>تومان</span>
                <span style={fresh ? freshBadge : staleBadge}>
                  {fresh ? `${mins.toLocaleString('fa-IR')} دقیقه پیش` : 'قدیمی'}
                </span>
              </span>
            )
          })}
        </div>
        <span style={sourceHint}>فقط نمایشی</span>
      </div>
    </div>
  )
}

// ── Styles ─────────────────────────────────────────────────────────────
const tickerWrap: React.CSSProperties = {
  background: '#1e357b',
  borderBottom: '1px solid rgba(255,255,255,.12)',
  padding: '6px 24px',
  fontSize: 12,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const tickerInner: React.CSSProperties = {
  maxWidth: 1100,
  margin: '0 auto',
  display: 'flex',
  alignItems: 'center',
  gap: 14,
  flexWrap: 'wrap',
}
const tickerLabel: React.CSSProperties = {
  color: 'rgba(255,255,255,.7)',
  fontWeight: 600,
  fontSize: 11,
  whiteSpace: 'nowrap',
}
const ratesRow: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 18,
  flexWrap: 'wrap',
}
const rateItem: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 5,
}
const currencyName: React.CSSProperties = {
  color: 'rgba(255,255,255,.85)',
  fontWeight: 700,
  fontSize: 11.5,
}
const rateValue: React.CSSProperties = {
  color: '#fff',
  fontWeight: 800,
  fontSize: 13,
  fontFamily: 'monospace',
  direction: 'ltr',
  display: 'inline-block',
}
const tomanUnit: React.CSSProperties = {
  color: 'rgba(255,255,255,.55)',
  fontSize: 10,
}
const freshBadge: React.CSSProperties = {
  fontSize: 9.5,
  fontWeight: 600,
  color: '#146c3a',
  background: '#eaf3de',
  borderRadius: 4,
  padding: '1px 6px',
  marginRight: 2,
  whiteSpace: 'nowrap',
}
const staleBadge: React.CSSProperties = {
  fontSize: 9.5,
  fontWeight: 600,
  color: '#92400e',
  background: '#fef3c7',
  borderRadius: 4,
  padding: '1px 6px',
  marginRight: 2,
  whiteSpace: 'nowrap',
}
const sourceHint: React.CSSProperties = {
  marginRight: 'auto',
  color: 'rgba(255,255,255,.35)',
  fontSize: 9.5,
  fontWeight: 500,
  whiteSpace: 'nowrap',
}
