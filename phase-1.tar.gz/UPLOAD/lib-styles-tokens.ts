// src/lib/styles/tokens.ts
//
// توکن‌های طراحی — الهام از Stripe Dashboard (جدول‌محور، خلوت، رنگ فقط برای معنی)
// رنگ‌های برند (سرمه‌ای/نارنجی) دست‌نخورده می‌مونن، فقط نحوه‌ی استفاده‌شون تغییر می‌کنه:
// قبلاً رنگ برند برای تزئین/پس‌زمینه‌های بزرگ بود، الان فقط برای اکشن اصلی و وضعیت.

export const colors = {
  // برند — دست‌نخورده
  navy: '#1e357b',
  navyDark: '#152a63',
  orange: '#e65716',

  // خنثی — پایه‌ی سبک Stripe (نزدیک به مشکی، نه خاکستری صرف)
  textPrimary: '#1a1f36',
  textSecondary: '#697386',
  textMuted: '#8792a2',

  // پس‌زمینه‌ها
  bgPage: '#f7f8fa',
  bgCard: '#ffffff',
  bgHover: '#f7f8fa',
  bgActiveTint: 'rgba(30, 53, 123, 0.06)', // پس‌زمینه‌ی کم‌رنگ برای آیتم فعال منو

  // خط/حاشیه
  borderSubtle: '#e3e8ee',
  borderStrong: '#d8dde3',

  // وضعیت‌ها — بج‌ها
  successBg: '#e3f9e5',
  successText: '#0e6245',
  warningBg: '#fef8e7',
  warningText: '#92400e',
  dangerBg: '#fde8e8',
  dangerText: '#9b1c1c',
  infoBg: '#e0e7ff',
  infoText: '#3730a3',
  neutralBg: '#f1f2f5',
  neutralText: '#4f5560',
} as const

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
} as const

export const radius = {
  sm: 6,
  md: 8,
  lg: 12,
} as const

export const fontSize = {
  xs: 11,
  sm: 12.5,
  base: 13,
  md: 14,
  lg: 16,
  xl: 20,
  xxl: 22,
} as const
