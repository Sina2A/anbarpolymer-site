import prisma from '@/lib/prisma'
import WarehousesMap from '@/components/WarehousesMap'
import CurrencyTicker from '@/components/CurrencyTicker'
import { getCurrentUserOrNull } from '@/lib/currentUser'

export const dynamic = 'force-dynamic'

export default async function WarehousesPage() {
  const warehouses = await prisma.warehouse.findMany({
    orderBy: [{ city: 'asc' }, { name: 'asc' }],
  })
  const withLocation = warehouses.filter((w) => w.latitude && w.longitude)
  const user = await getCurrentUserOrNull()

  return (
    <>
      <CurrencyTicker />
      <div className="topbar">
        <div className="wrap">
          <span>پشتیبانی فروش شنبه تا چهارشنبه ۸:۳۰ تا ۱۷:۳۰</span>
          <a className="phone" href="tel:+982191234567">
            021-91234567
          </a>
        </div>
      </div>
      <header className="site-header">
        <div className="wrap">
          <a href="/" className="logo">
            <span className="dot"></span> انبار پلیمر
          </a>
          <nav className="main-nav">
            <a href="/">صفحه اصلی</a>
            <a href="/grades">گریدها</a>
            <a href="/rfq">استعلام قیمت</a>
            <a href="/market">بازار صنعتی</a>
            <a href="/reports">گزارش بازار</a>
            <a href="/services">خدمات سازمانی</a>
            <a href="/about">درباره ما</a>
            <a href="/contact">تماس با ما</a>
          </nav>
          <div className="header-actions">
            {user ? (
              <a href="/dashboard" className="acct-btn">
                پیشخوان
              </a>
            ) : (
              <a href="/login" className="acct-btn">
                ورود / ثبت‌نام
              </a>
            )}
          </div>
        </div>
      </header>

      <section style={pageSectionStyle}>
        <div className="wrap">
          <div className="eyebrow">زنجیره‌ی عرضه</div>
          <div className="sec-title">شبکه‌ی انبارهای انبار پلیمر</div>
          <div className="sec-sub" style={{ marginBottom: 28 }}>
            موقعیت انبارهای فعال روی نقشه و فهرست کامل آن‌ها — برای شفافیت زنجیره‌ی عرضه.
          </div>

          {/* نقشه */}
          <section style={sectionStyle}>
            <h2 style={sectionTitle}>موقعیت روی نقشه</h2>
            <WarehousesMap warehouses={withLocation} />
            {withLocation.length > 0 && (
              <p style={hintStyle}>
                📍 {withLocation.length} انبار از {warehouses.length} انبار دارای موقعیت ثبت‌شده هستند.
              </p>
            )}
          </section>

          {/* لیست کارتی همه‌ی انبارها */}
          <section style={sectionStyle}>
            <h2 style={sectionTitle}>فهرست انبارها</h2>
            {warehouses.length === 0 ? (
              <div style={emptyCardStyle}>هیچ انباری ثبت نشده است.</div>
            ) : (
              <div style={gridStyle}>
                {warehouses.map((w) => (
                  <div key={w.id} style={cardStyle}>
                    <div style={cardHead}>
                      <h3 style={cardTitle}>{w.name}</h3>
                      {w.latitude && w.longitude && (
                        <span style={geoBadge}>📍 روی نقشه</span>
                      )}
                    </div>
                    <div style={cardRow}>
                      <span style={cardLabel}>شهر</span>
                      <span style={cardValue}>{w.city}</span>
                    </div>
                    {w.address && (
                      <div style={cardRow}>
                        <span style={cardLabel}>آدرس</span>
                        <span style={cardValue}>{w.address}</span>
                      </div>
                    )}
                    {w.description && (
                      <p style={cardDesc}>{w.description}</p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      </section>

      <footer className="site-footer">
        <div className="wrap">
          <div className="footer-cols">
            <div>
              <a href="/" className="logo" style={{ marginBottom: 14, display: 'flex' }}>
                <span className="dot"></span> انبار پلیمر
              </a>
              <p style={{ color: 'var(--ink-dim)', fontSize: 13, maxWidth: 280 }}>
                واردکننده و فروشنده مستقیم مواد اولیه پلیمری برای کارخانه‌های تولیدی سراسر کشور.
              </p>
            </div>
            <div>
              <h5>محصولات</h5>
              <ul>
                <li>
                  <a href="/grades">پلی‌پروپیلن</a>
                </li>
                <li>
                  <a href="/grades">پلی‌اتیلن</a>
                </li>
                <li>
                  <a href="/grades">پی‌وی‌سی</a>
                </li>
                <li>
                  <a href="/grades">پلی‌اتیلن ترفتالات</a>
                </li>
              </ul>
            </div>
            <div>
              <h5>خدمات</h5>
              <ul>
                <li>
                  <a href="/rfq">استعلام قیمت آنلاین</a>
                </li>
                <li>
                  <a href="/market">بازار صنعتی</a>
                </li>
                <li>
                  <a href="/services">فروش سازمانی</a>
                </li>
                <li>
                  <a href="/reports">گزارش بازار</a>
                </li>
              </ul>
            </div>
            <div>
              <h5>اطلاعات تماس</h5>
              <ul>
                <li>تهران، خیابان ولیعصر، پلاک ۱۲۴</li>
                <li>انبار یزد — شهرک صنعتی یزد</li>
                <li style={{ direction: 'ltr', textAlign: 'right' }}>021-91234567</li>
              </ul>
            </div>
          </div>
          <div className="footer-bottom">
            <span>انبار پلیمر © ۱۴۰۵ — تمام حقوق محفوظ است</span>
          </div>
        </div>
      </footer>
    </>
  )
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const pageSectionStyle: React.CSSProperties = { padding: '48px 0' }
const sectionStyle: React.CSSProperties = {
  marginBottom: 36,
}
const sectionTitle: React.CSSProperties = {
  fontSize: 16,
  fontWeight: 700,
  color: '#1b1e24',
  marginBottom: 14,
}
const hintStyle: React.CSSProperties = {
  fontSize: 12,
  color: '#6f7680',
  marginTop: 10,
}
const emptyCardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 40,
  background: '#fff',
  textAlign: 'center',
  fontSize: 13,
  color: '#6b7280',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const gridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
  gap: 14,
}
const cardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 18,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const cardHead: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  gap: 8,
  marginBottom: 12,
}
const cardTitle: React.CSSProperties = {
  fontSize: 15,
  fontWeight: 700,
  color: '#1e357b',
  margin: 0,
}
const geoBadge: React.CSSProperties = {
  fontSize: 10,
  fontWeight: 700,
  color: '#146c3a',
  background: '#eaf3de',
  borderRadius: 6,
  padding: '3px 8px',
  whiteSpace: 'nowrap',
}
const cardRow: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  gap: 10,
  marginBottom: 6,
  fontSize: 13,
}
const cardLabel: React.CSSProperties = {
  color: '#9199a3',
  fontSize: 12,
}
const cardValue: React.CSSProperties = {
  color: '#1b1e24',
  fontWeight: 600,
  textAlign: 'left',
}
const cardDesc: React.CSSProperties = {
  fontSize: 12,
  color: '#6f7680',
  lineHeight: 1.7,
  marginTop: 10,
  paddingTop: 10,
  borderTop: '1px solid #eceff3',
}
