'use server'

// اکشن‌های CRUD پنل مدیریت انبارها:
//   ۱. createWarehouseAction — افزودن انبار جدید
//   ۲. updateWarehouseAction — ویرایش اطلاعات انبار
//   ۳. upsertStockAction — افزودن/به‌روزرسانی موجودی یک گرید در یک انبار
//   ۴. deleteStockAction — حذف ردیف موجودی
//
// قاعده: فقط Edit/Write، بدون شل. اسم فیلدها از مدل واقعی.

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import { AccessDeniedError } from '@/lib/errorCodes'
import { logAudit } from '@/lib/logger'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'

// ---------------------------------------------------------------- دسترسی

/** چک دسترسی نوشتن روی بخش «warehouses» */
async function requireWarehouseEditAccess() {
  const user = await getCurrentUser()
  if (user.role === 'admin') return user
  const access = await getAllSectionAccess(user.id)
  if (access.warehouses !== 'edit' && access.warehouses !== 'full') {
    throw new AccessDeniedError(
      'A-SECTION-WAREHOUSES',
      'دسترسی ویرایش انبارها رو نداری — از مدیر بخواه بهت بده.'
    )
  }
  return user
}

// ---------------------------------------------------------------- کار با عدد

/** «230,5» یا «230.5» رو عدد کن. خالی → null. */
function toFloatOrNull(s: string | undefined | null): number | null {
  const t = (s ?? '').trim().replace(/٬/g, '').replace(',', '.')
  if (!t) return null
  const n = Number(t)
  return Number.isFinite(n) ? n : null
}

// ================================================================ ایجاد انبار

export async function createWarehouseAction(formData: FormData) {
  const user = await requireWarehouseEditAccess()

  const name = (formData.get('name') as string)?.trim()
  const city = (formData.get('city') as string)?.trim()
  if (!name || !city) {
    throw new Error('نام و شهر انبار الزامی است.')
  }

  const warehouse = await prisma.warehouse.create({
    data: {
      name,
      city,
      address: (formData.get('address') as string)?.trim() || null,
      description: (formData.get('description') as string)?.trim() || null,
      latitude: toFloatOrNull(formData.get('latitude') as string),
      longitude: toFloatOrNull(formData.get('longitude') as string),
    },
  })

  await logAudit('warehouses', `انبار «${name}» ایجاد شد`, user.id, { warehouseId: warehouse.id })
  revalidatePath('/admin-warehouses')
  revalidatePath('/warehouses')
  redirect('/admin-warehouses?created=1')
}

// ================================================================ ویرایش انبار

export async function updateWarehouseAction(formData: FormData) {
  const user = await requireWarehouseEditAccess()

  const id = formData.get('id') as string
  const name = (formData.get('name') as string)?.trim()
  const city = (formData.get('city') as string)?.trim()
  if (!id) throw new Error('شناسه انبار نامعتبر.')
  if (!name || !city) throw new Error('نام و شهر انبار الزامی است.')

  await prisma.warehouse.update({
    where: { id },
    data: {
      name,
      city,
      address: (formData.get('address') as string)?.trim() || null,
      description: (formData.get('description') as string)?.trim() || null,
      latitude: toFloatOrNull(formData.get('latitude') as string),
      longitude: toFloatOrNull(formData.get('longitude') as string),
    },
  })

  await logAudit('warehouses', `انبار «${name}» ویرایش شد`, user.id, { warehouseId: id })
  revalidatePath('/admin-warehouses')
  revalidatePath('/warehouses')
  redirect('/admin-warehouses?updated=1')
}

// ================================================================ موجودی (upsert)

export async function upsertStockAction(formData: FormData) {
  const user = await requireWarehouseEditAccess()

  const gradeId = formData.get('gradeId') as string
  const warehouseId = formData.get('warehouseId') as string
  const quantityTon = toFloatOrNull(formData.get('quantityTon') as string)
  const priceRial = toFloatOrNull(formData.get('priceRial') as string)
  const batch = (formData.get('batch') as string)?.trim() || null

  if (!gradeId || !warehouseId) throw new Error('گرید و انبار الزامی است.')
  if (quantityTon == null || priceRial == null) throw new Error('مقدار و قیمت الزامی هستند.')

  const existing = await prisma.warehouseStock.findFirst({
    where: { gradeId, warehouseId },
  })

  if (existing) {
    await prisma.warehouseStock.update({
      where: { id: existing.id },
      data: { quantityTon, priceRial, batch },
    })
  } else {
    await prisma.warehouseStock.create({
      data: { gradeId, warehouseId, quantityTon, priceRial, batch },
    })
  }

  await logAudit(
    'warehouses',
    existing ? `موجودی گرید ${gradeId} در انبار ${warehouseId} بروزرسانی شد` : `موجودی گرید ${gradeId} در انبار ${warehouseId} ثبت شد`,
    user.id,
    { gradeId, warehouseId, quantityTon, priceRial }
  )
  revalidatePath('/admin-warehouses')
  revalidatePath('/warehouses')
  redirect('/admin-warehouses?stock=1')
}

// ================================================================ حذف موجودی

export async function deleteStockAction(formData: FormData) {
  const user = await requireWarehouseEditAccess()

  const id = formData.get('id') as string
  if (!id) throw new Error('شناسه ردیف نامعتبر.')

  const stock = await prisma.warehouseStock.findUnique({ where: { id } })
  if (stock) {
    await prisma.warehouseStock.delete({ where: { id } })
    await logAudit('warehouses', `ردیف موجودی ${stock.gradeId} در انبار ${stock.warehouseId} حذف شد`, user.id, { stockId: id })
  }

  revalidatePath('/admin-warehouses')
  revalidatePath('/warehouses')
  redirect('/admin-warehouses?deleted=1')
}
