import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { notFound } from 'next/navigation'
import UserNav from '@/components/UserNav'
import DealBankPay from '@/components/DealBankPay'
import { enforceDealDeadlines } from '@/lib/dealDeadlines'

export const dynamic = 'force-dynamic'

/**
 * صفحه‌ی جزئیات معامله برای خریدار — هم‌الگوی proformas/[id]/page.tsx.
 * فقط buyerId مطابق با کاربر جاری دسترسی دارد (وگرنه 404 تا id لو نرود).
 * DealBankPay کامپوننت پرداخت را سوار می‌کند.
 */

const STATUS_TEXT: Record<string, string> = {
  draft: 'پیش‌نویس — در انتظار تایید کارشناس',
  confirmed: 'تایید شد — لطفاً پرداخت را تکمیل کنید',
  seller_fee_paid: 'کارمزد فروشنده پرداخت شد — در انتظار پرداخت شما',
  payment_secured: 'وجه تضمین شد — در انتظار بارگیری',
  loading: 'در حال بارگیری در انبار',
  in_transit: 'در مسیر ارسال',
  delivered: 'تحویل داده شد',
  settled: 'تسویه شد',
}

/** وضعیت‌هایی که خریدار هنوز می‌تواند پرداخت کند */
const PAYABLE_STATUSES = ['confirmed', 'seller_fee_paid']

export default async function MyDealDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const user = await getCurrentUser()

  await enforceDealDeadlines()

  // فقط معامله‌ی خودِ کاربر — 404 به‌جای 403 تا id دیگران لو نرود
  const deal = await prisma.deal.findFirst({
    where: { id, buyerId: user.id },
    include: { materialListing: { include: { grade: true } } },
  })
  if (!deal) notFound()

  const shortId = deal.id.slice(0, 8)
  const gradeCode = (deal.materialListing as unknown as { grade?: { code: string } })?.grade?.code || ''
  const canPay = PAYABLE_STATUSES.includes(deal.status)
  const receiptSent = Boolean(deal.paymentReceiptUrl)

  return (
    <div style={pageStyle}>
      <div style={{ maxWidth: 1100, margin: '0 auto', display: 'flex', gap: 24 }} className="admin-page-wrap">
        <UserNav currentUserName={user.companyName} activeSection="deals" />
        <div style={{ flex: 1, minWidth: 0 }}>

          {/* بازگشت */}
          <a href="/my-deals" style={{ fontSize: 12.5, color: '#9199a3', textDecoration: 'none', display: 'inline-block', marginBottom: 10 }}>
            → بازگشت به لیست معاملات
          </a>

          <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 20 }}>
            معامله #{shortId}
            {gradeCode && <span style={{ fontFamily: 'monospace', fontSize: 16, fontWeight: 400, marginRight: 10, color: '#4f5560' }}>{gradeCode}</span>}
          </h1>

          {/* اطلاعات معامله */}
          <div style={whiteCard}>
            <div style={{ fontSize: 15, fontWeight: 800, marginBottom: 14 }}>جزئیات معامله</div>
            <div style={infoGrid}>
              <InfoRow label="مقدار" value={deal.quantity} mono />
              <InfoRow label="قیمت توافقی" value={deal.agreedPrice || 'ثبت نشده'} mono={!!deal.agreedPrice} />
              {gradeCode && <InfoRow label="گرید" value={gradeCode} mono />}
              <InfoRow label="تاریخ ایجاد" value={new Date(deal.createdAt).toLocaleDateString('fa-IR')} />
            </div>
          </div>

          {/* نوار وضعیت */}
          <div style={statusBar}>
            وضعیت: {STATUS_TEXT[deal.status] || deal.status}
          </div>

          {/* هشدار مهلت پرداخت */}
          {deal.buyerConfirmDeadline && (deal.status === 'confirmed' || deal.status === 'seller_fee_paid') && (
            <div style={deadlineWarn}>
              ⏳ مهلت پرداخت: {new Date(deal.buyerConfirmDeadline).toLocaleString('fa-IR', { dateStyle: 'short', timeStyle: 'short' })}
              &nbsp;— بعد از این زمان معامله خودکار لغو می‌شود
            </div>
          )}

          {/* بخش پرداخت */}
          {(canPay || deal.status === 'payment_secured') && !receiptSent && (
            <div style={{ marginTop: 20 }}>
              <div style={{ fontSize: 14, fontWeight: 800, marginBottom: 14 }}>روش پرداخت</div>
              <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
                {/* کارت پرداخت بانکی / مستقیم */}
                <div style={{ ...payCard, flex: '1 1 300px', border: '1.5px solid #f6621b' }}>
                  <div style={{ fontSize: 15, fontWeight: 800 }}>🏦 پرداخت معامله</div>
                  <div style={{ fontSize: 12, color: '#9199a3', margin: '6px 0 14px' }}>آپلود فیش یا تماس مستقیم</div>
                  <DealBankPay
                    dealId={deal.id}
                    amountLabel={deal.agreedPrice || 'مبلغ توافقی'}
                    purposeLabel={`پرداخت معامله #${shortId}`}
                    paymentInstructionsText={deal.paymentInstructionsText ?? undefined}
                    disabled={!canPay}
                    disabledHint="پرداخت در وضعیت جاری امکان‌پذیر نیست"
                  />
                </div>
                {/* کارت پرداخت آنلاین — به‌زودی */}
                <div style={{ ...payCard, flex: '1 1 300px' }}>
                  <div style={{ fontSize: 15, fontWeight: 800 }}>💳 پرداخت آنلاین</div>
                  <div style={{ fontSize: 12, color: '#9199a3', margin: '6px 0 14px' }}>به‌زودی فعال می‌شود</div>
                  <button type="button" disabled style={disabledBtn}>غیرفعال</button>
                </div>
              </div>
            </div>
          )}

          {/* وضعیت رسید — مدل Deal فیلد paymentReceiptStatus ندارد (فقط Order دارد)،
              پس تنها «ارسال شد» + تضمین وجه از escrowStatus نمایش داده می‌شود */}
          {receiptSent && (
            <div style={{ ...receiptTag, color: '#146c3a', background: '#e8f8ee', marginTop: 18 }}>
              ✓ رسید پرداخت ارسال شد — در انتظار تایید کارشناس مالی
              {deal.paymentReceiptUploadedAt && (
                <span style={{ fontWeight: 400, marginRight: 8, color: '#4f5560' }}>
                  ({new Date(deal.paymentReceiptUploadedAt).toLocaleDateString('fa-IR')})
                </span>
              )}
            </div>
          )}
          {deal.escrowStatus === 'secured_manual' && (
            <div style={{ ...receiptTag, color: '#146c3a', background: '#eaf3de', marginTop: 10 }}>
              ✓ وجه توسط کارشناس مالی تضمین شد
            </div>
          )}

        </div>
      </div>
    </div>
  )
}

function InfoRow({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid #f1efe8', fontSize: 13 }}>
      <span style={{ color: '#6f7680' }}>{label}</span>
      <span style={{ fontWeight: 700, fontFamily: mono ? 'monospace' : 'inherit' }}>{value}</span>
    </div>
  )
}

const pageStyle: React.CSSProperties = {
  minHeight: '100vh', background: '#faf8f4', padding: '32px 20px',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl',
}
const whiteCard: React.CSSProperties = {
  background: '#fff', border: '1px solid #d8dde3', borderRadius: 12,
  padding: 18, marginBottom: 14, boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const infoGrid: React.CSSProperties = { display: 'flex', flexDirection: 'column' }
const statusBar: React.CSSProperties = {
  background: '#fff4ee', borderRadius: 10, padding: '12px 16px',
  fontSize: 13.5, fontWeight: 700, color: '#7a3a10',
}
const deadlineWarn: React.CSSProperties = {
  marginTop: 10, fontSize: 12.5, fontWeight: 700, color: '#7a3a10',
}
const payCard: React.CSSProperties = {
  background: '#fff', border: '1px solid #d8dde3', borderRadius: 12, padding: 18,
}
const disabledBtn: React.CSSProperties = {
  padding: '9px 22px', background: '#e8e4db', color: '#9199a3',
  border: 'none', borderRadius: 8, fontWeight: 700, fontSize: 13, cursor: 'not-allowed',
}
const receiptTag: React.CSSProperties = {
  display: 'inline-block', fontSize: 12.5, fontWeight: 700,
  padding: '8px 16px', borderRadius: 8,
}
