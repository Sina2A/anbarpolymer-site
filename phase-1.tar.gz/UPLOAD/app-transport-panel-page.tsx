import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { addDriver, toggleDriverActive } from './actions'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'
import { colors } from '@/lib/styles/tokens'

export const dynamic = 'force-dynamic'

// وضعیت‌هایی که برای شرکت حمل معنی دارن. قبل از payment_secured معامله هنوز
// قابل برنامه‌ریزیِ حمل نیست، پس عمداً به این پنل نمیاد.
const ACTIVE_STATUSES = ['payment_secured', 'loading', 'in_transit']
const DONE_STATUSES = ['delivered', 'settled']

const CARRIER_STATUS: Record<string, { label: string; bg: string; color: string }> = {
  payment_secured: { label: 'در انتظار بارگیری', bg: colors.warningBg, color: colors.warningText },
  loading: { label: 'در حال بارگیری', bg: colors.infoBg, color: colors.infoText },
  in_transit: { label: 'در مسیر', bg: colors.infoBg, color: colors.infoText },
  delivered: { label: 'تحویل‌شده', bg: colors.successBg, color: colors.successText },
  settled: { label: 'تسویه‌شده', bg: colors.successBg, color: colors.successText },
}

// نام/پلاک راننده‌ی هر محموله از آخرین تاییدیه‌ی بارگیری درمیاد —
// خودِ Deal فیلد driverId نداره، رابطه از سمت DealConfirmation.driverId است.
function loadingInfo(confs: { type: string; driverName: string | null; vehiclePlate: string | null }[]) {
  const c = confs.find((x) => x.type === 'loading') ?? confs[0]
  return { driverName: c?.driverName || null, plate: c?.vehiclePlate || null }
}
const faDateTime = (d: Date) => new Date(d).toLocaleString('fa-IR', { dateStyle: 'short', timeStyle: 'short' })

export default async function TransportPanelPage() {
  const user = await getCurrentUser()

  const company = await prisma.transportCompany.findUnique({
    where: { managerUserId: user.id },
    include: {
      // ۵.۳ — کرایه‌ی حمل (transportCost / transportCostPaid) هم اینجاست؛
      // مبلغ معامله (agreedPrice) و هویت خریدار همچنان برداشته نمی‌شه.
      deals: {
        where: { status: { in: [...ACTIVE_STATUSES, ...DONE_STATUSES] } },
        orderBy: { createdAt: 'desc' },
        take: 60,
        include: {
          materialListing: { include: { grade: true } },
          confirmations: { orderBy: { confirmedAt: 'desc' }, take: 5 },
        },
      },
      drivers: {
        orderBy: { createdAt: 'asc' },
        include: {
          confirmations: {
            orderBy: { confirmedAt: 'desc' },
            take: 10,
            include: { deal: true },
          },
        },
      },
    },
  })

  if (!company) {
    return (
      <div style={pageWrapStyle}>
        <div style={cardStyle}>
          <h1 style={{ fontSize: 18, fontWeight: 800, marginBottom: 8, color: colors.textPrimary }}>
            پنل شرکت حمل‌ونقل — دسترسی ندارید
          </h1>
          <p style={{ fontSize: 13.5, color: colors.textSecondary }}>این حساب به هیچ شرکت حمل‌ونقلی وصل نیست. با پشتیبانی انبار پلیمر تماس بگیرید.</p>
        </div>
      </div>
    )
  }

  // گیت دسترسی پنل (۵.۳) — جدای از خودِ قرارداد حمل. اگه مدیر دسترسی رو
  // قطع کرده باشه، شرکت اصلاً محتوای پنل رو نمی‌بینه؛ عملیاتش هم از سمت
  // اکشن‌ها قفله (getMyTransportCompany هم همین چک رو داره).
  if (!company.logisticsAccessEnabled) {
    return (
      <div style={pageWrapStyle}>
        <div style={cardStyle}>
          <h1 style={{ fontSize: 18, fontWeight: 800, marginBottom: 8, color: colors.textPrimary }}>
            پنل شرکت حملونقل — دسترسی غیرفعال
          </h1>
          <p style={{ fontSize: 13.5, color: colors.textSecondary }}>
            دسترسی پنل حملونقل برای <b style={{ color: colors.textPrimary }}>{company.name}</b> در حال حاضر غیرفعاله. برای فعال‌شدن با پشتیبانی انبار پلیمر تماس بگیرید.
          </p>
        </div>
      </div>
    )
  }

  const activeDeals = company.deals.filter((d) => ACTIVE_STATUSES.includes(d.status))
  const doneDeals = company.deals.filter((d) => DONE_STATUSES.includes(d.status)).slice(0, 20)

  return (
    <div style={pageWrapStyle}>
      <div style={{ maxWidth: 780, margin: '0 auto' }}>
        {/* ── هدر صفحه ── */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
          <h1 style={{ fontSize: 22, fontWeight: 800, color: colors.textPrimary, margin: 0 }}>
            پنل شرکت حمل‌ونقل
          </h1>
          <span style={panelTagStyle}>یوزر لجیستیک</span>
        </div>
        <p style={{ fontSize: 13, color: colors.textMuted, marginBottom: 24 }}>
          <b style={{ color: colors.textSecondary, fontWeight: 700 }}>{company.name}</b>
          {' — '}
          محموله‌های سپرده‌شده، راننده‌ها و تاریخچه‌ی سفرهای تایید‌شده
        </p>

        {/* ── باکس هدف ── */}
        <div style={purposeBoxStyle}>
          <b>هدف این پنل چیه؟</b>
          <p style={{ margin: '6px 0 0', lineHeight: 1.9 }}>
            این پنل مخصوص <b>مدیر شرکت حمل‌ونقل</b>‌ه — بخش داخلی «حمل و نقل» انبار پلیمر جای دیگه‌ایه و به این صفحه ربطی نداره.
            کارش فقط <b>احراز هویت راننده و مسیر طی‌شده</b>‌ست — به‌خاطر حساسیت صنعت مواد اولیه پتروشیمی در ایران.
            انبار پلیمر با رقم دقیق مسافتِ طی‌شده‌ی هیچ راننده‌ای کاری نداره و این داده رو برای ارزیابی عملکرد یا هزینه استفاده نمی‌کنه —
            فقط جهت تایید این‌که سفر واقعاً و توسط همون راننده‌ی ثبت‌شده انجام شده.
          </p>
        </div>

        {/* ── محموله‌های جاری ── */}
        <h3 style={sectionTitleStyle}>محموله‌های جاری ({activeDeals.length})</h3>

        {activeDeals.length === 0 && <div style={emptyBoxStyle}>الان محموله‌ی جاری‌ای به این شرکت سپرده نشده.</div>}

        {activeDeals.map((deal) => {
          const st = CARRIER_STATUS[deal.status]
          const { driverName, plate } = loadingInfo(deal.confirmations)
          const gradeCode = deal.materialListing?.grade?.code
          return (
            <div key={deal.id} style={cardStyle}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, flexWrap: 'wrap', marginBottom: 12 }}>
                <div>
                  <b style={{ fontSize: 13.5, color: colors.textPrimary }}>محموله</b>{' '}
                  <span style={dealIdStyle}>#{deal.id.slice(0, 8)}</span>
                  {gradeCode && <span style={gradeTagStyle}>{gradeCode}</span>}
                </div>
                <span style={{ ...dealBadgeStyle, background: st?.bg ?? colors.neutralBg, color: st?.color ?? colors.neutralText }}>
                  {st?.label ?? deal.status}
                </span>
              </div>

              <div style={metaGridStyle}>
                <div>
                  <span style={metaLabelStyle}>مقدار</span>
                  <span style={metaValueStyle}>{deal.quantity}</span>
                </div>
                <div>
                  <span style={metaLabelStyle}>راننده</span>
                  <span style={metaValueStyle}>{driverName ?? 'ثبت نشده'}</span>
                </div>
                <div>
                  <span style={metaLabelStyle}>پلاک</span>
                  <span style={{ ...metaValueStyle, direction: 'ltr', display: 'inline-block' }}>{plate ?? '—'}</span>
                </div>
                <div>
                  <span style={metaLabelStyle}>آخرین گزارش موقعیت</span>
                  <span style={metaValueStyle}>{deal.locationUpdatedAt ? faDateTime(deal.locationUpdatedAt) : 'گزارشی ثبت نشده'}</span>
                </div>
              </div>

              {/** ۵.۳ — کرایه‌ی حمل: همون واحد پول پیش‌فرض سایت (تومان، my-listings/my-requests) */}
              <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap', marginTop: 10 }}>
                <span style={metaLabelStyle}>کرایه حمل</span>
                <span style={metaValueStyle}>{deal.transportCost != null ? `${deal.transportCost.toLocaleString('fa-IR')} تومان` : '—'}</span>
                {deal.transportCost != null && (
                  <span style={{ ...dealBadgeStyle, background: deal.transportCostPaid ? colors.successBg : colors.warningBg, color: deal.transportCostPaid ? colors.successText : colors.warningText }}>
                    {deal.transportCostPaid ? 'پرداخت شده' : 'پرداخت نشده'}
                  </span>
                )}
              </div>

              {deal.driverSilenceFlaggedAt && (
                <div style={silenceBoxStyle}>
                  از <b>{faDateTime(deal.driverSilenceFlaggedAt)}</b> هیچ گزارشی از راننده‌ی این محموله ثبت نشده — پیگیری کنید.
                </div>
              )}
            </div>
          )
        })}

        {/* ── تاریخچه ── */}
        <h3 style={sectionTitleStyle}>تاریخچه‌ی محموله‌ها ({doneDeals.length})</h3>

        {doneDeals.length === 0 ? (
          <div style={emptyBoxStyle}>هنوز محموله‌ی تکمیل‌شده‌ای ثبت نشده.</div>
        ) : (
          <div style={cardStyle}>
            {doneDeals.map((deal, i) => {
              const st = CARRIER_STATUS[deal.status]
              const { driverName } = loadingInfo(deal.confirmations)
              return (
                <div key={deal.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: 12, padding: '8px 0', gap: 8, flexWrap: 'wrap', color: colors.textSecondary, ...(i > 0 ? { borderTop: `1px solid ${colors.borderSubtle}` } : {}) }}>
                  <span>
                    <span style={dealIdStyle}>#{deal.id.slice(0, 8)}</span>
                    {' — '}
                    {deal.materialListing?.grade?.code ?? 'بدون گرید'}
                    {' — '}
                    {driverName ?? 'راننده ثبت نشده'}
                  </span>
                  <span style={{ ...dealBadgeStyle, background: st?.bg ?? colors.neutralBg, color: st?.color ?? colors.neutralText }}>{st?.label ?? deal.status}</span>
                </div>
              )
            })}
          </div>
        )}

        {/* ── افزودن راننده ── */}
        <h3 style={sectionTitleStyle}>افزودن راننده‌ی جدید</h3>

        <div style={cardStyle}>
          <form action={addDriver} style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 12 }}>
            <input name="fullName" placeholder="نام و نام خانوادگی" required style={inputStyle} />
            <input name="phone" placeholder="شماره موبایل" required style={{ ...inputStyle, direction: 'ltr' }} />
            <input name="nationalId" placeholder="کد ملی (اختیاری)" style={{ ...inputStyle, direction: 'ltr' }} />
            <input name="licenseNumber" placeholder="شماره گواهینامه (اختیاری)" style={{ ...inputStyle, direction: 'ltr' }} />
            <button type="submit" style={btnPrimaryStyle}>افزودن راننده</button>
          </form>
        </div>

        {/* ── لیست راننده‌ها ── */}
        <h3 style={sectionTitleStyle}>راننده‌ها ({company.drivers.length})</h3>

        {company.drivers.length === 0 && <div style={emptyBoxStyle}>هنوز راننده‌ای ثبت نشده.</div>}

        {company.drivers.map((driver) => (
          <div key={driver.id} style={cardStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
              <div>
                <b style={{ fontSize: 14, color: colors.textPrimary }}>{driver.fullName}</b>{' '}
                <span style={{ fontSize: 12, color: colors.textMuted, direction: 'ltr', display: 'inline-block' }}>— {driver.phone}</span>
              </div>
              <form action={toggleDriverActive}>
                <input type="hidden" name="driverId" value={driver.id} />
                <input type="hidden" name="value" value={(!driver.isActive).toString()} />
                <ConfirmSubmitButton
                  message={driver.isActive ? `«${driver.fullName}» غیرفعال بشه؟` : `«${driver.fullName}» دوباره فعال بشه؟`}
                  style={{ ...statusBtnStyle, ...(driver.isActive ? activeStatusStyle : inactiveStatusStyle) }}
                >
                  {driver.isActive ? 'فعال' : 'غیرفعال'}
                </ConfirmSubmitButton>
              </form>
            </div>

            {driver.confirmations.length > 0 && (
              <div style={{ borderTop: `1px dashed ${colors.borderSubtle}`, paddingTop: 10, marginTop: 4 }}>
                <div style={{ fontSize: 11, color: colors.textMuted, marginBottom: 6 }}>آخرین سفرهای تایید‌شده:</div>
                {driver.confirmations.map((c) => (
                  <div key={c.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, padding: '5px 0', color: colors.textSecondary }}>
                    <span>{c.type === 'loading' ? 'بارگیری' : 'تخلیه'} — معامله #{c.dealId.slice(0, 8)}</span>
                    <span style={{ color: colors.textMuted }}>{new Date(c.confirmedAt).toLocaleDateString('fa-IR')}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}

        {/* ── پشتیبانی ── */}
        <div style={{ ...cardStyle, background: colors.infoBg, borderColor: colors.infoText }}>
          <h3 style={{ fontSize: 14, fontWeight: 800, color: colors.infoText, marginBottom: 8 }}>پشتیبانی فنی</h3>
          <p style={{ fontSize: 12.5, color: colors.textSecondary, margin: 0 }}>
            برای هر مشکل فنی در این پنل، با تیم انبار پلیمر تماس بگیرید:{' '}
            <span style={{ direction: 'ltr', display: 'inline-block', fontWeight: 700, color: colors.textPrimary }}>۰۲۱-۹۱۲۳۴۵۶۷</span>
          </p>
        </div>
      </div>
    </div>
  )
}

// ──────────────────────────────────────────────────────────
// استایل‌ها (الهام Stripe Dashboard — تمیز و ساده)
// ──────────────────────────────────────────────────────────
const pageWrapStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: colors.bgPage,
  padding: '32px 20px',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}

const cardStyle: React.CSSProperties = {
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: 12,
  padding: 18,
  marginBottom: 14,
  background: colors.bgCard,
  boxShadow: '0 1px 4px rgba(27,30,36,0.05)',
}

const panelTagStyle: React.CSSProperties = {
  fontSize: 10.5,
  fontWeight: 700,
  color: colors.infoText,
  background: colors.infoBg,
  borderRadius: 5,
  padding: '3px 9px',
  verticalAlign: 'middle',
}

const purposeBoxStyle: React.CSSProperties = {
  background: colors.warningBg,
  color: colors.warningText,
  borderRadius: 10,
  padding: '14px 16px',
  fontSize: 12.5,
  marginBottom: 20,
  lineHeight: 1.9,
}

const inputStyle: React.CSSProperties = {
  border: `1px solid ${colors.borderStrong}`,
  borderRadius: 8,
  padding: '9px 12px',
  fontSize: 13,
  fontFamily: 'inherit',
}

const btnPrimaryStyle: React.CSSProperties = {
  background: colors.navy,
  color: '#fff',
  border: 'none',
  borderRadius: 8,
  padding: '9px 16px',
  fontSize: 13,
  fontWeight: 700,
  cursor: 'pointer',
  gridColumn: 'span 1',
}

const statusBtnStyle: React.CSSProperties = {
  fontSize: 10.5,
  fontWeight: 700,
  borderRadius: 5,
  padding: '4px 12px',
  border: 'none',
  cursor: 'pointer',
}

const activeStatusStyle: React.CSSProperties = {
  background: colors.successBg,
  color: colors.successText,
}

const inactiveStatusStyle: React.CSSProperties = {
  background: colors.dangerBg,
  color: colors.dangerText,
}

const sectionTitleStyle: React.CSSProperties = {
  fontSize: 15,
  fontWeight: 800,
  color: colors.textPrimary,
  margin: '28px 0 14px',
}

const emptyBoxStyle: React.CSSProperties = {
  padding: 28,
  textAlign: 'center',
  color: colors.textMuted,
  border: `1px dashed ${colors.borderStrong}`,
  borderRadius: 12,
  marginBottom: 14,
}

const dealIdStyle: React.CSSProperties = {
  fontFamily: 'monospace',
  fontSize: 12,
  color: colors.textSecondary,
  direction: 'ltr',
  display: 'inline-block',
}

const gradeTagStyle: React.CSSProperties = {
  fontSize: 10.5,
  fontWeight: 700,
  background: colors.neutralBg,
  color: colors.neutralText,
  borderRadius: 4,
  padding: '1px 7px',
  marginRight: 8,
  verticalAlign: 'middle',
}

const dealBadgeStyle: React.CSSProperties = {
  fontSize: 10.5,
  fontWeight: 700,
  borderRadius: 5,
  padding: '3px 10px',
}
const metaGridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))',
  gap: 8,
}

const metaLabelStyle: React.CSSProperties = {
  display: 'block',
  fontSize: 10.5,
  color: colors.textMuted,
  marginBottom: 2,
}

const metaValueStyle: React.CSSProperties = {
  fontSize: 13,
  fontWeight: 600,
  color: colors.textPrimary,
}

const silenceBoxStyle: React.CSSProperties = {
  marginTop: 10,
  background: colors.dangerBg,
  color: colors.dangerText,
  borderRadius: 8,
  padding: '8px 12px',
  fontSize: 12,
  fontWeight: 600,
}

