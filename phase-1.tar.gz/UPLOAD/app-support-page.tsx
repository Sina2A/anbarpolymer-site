import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import UserNav from '@/components/UserNav'
import { createTicketAction } from './actions'

export const dynamic = 'force-dynamic'

export default async function SupportPage() {
  const user = await getCurrentUser()

  const tickets = await prisma.supportTicket.findMany({
    where: { userId: user.id },
    include: { _count: { select: { messages: true } } },
    orderBy: { updatedAt: 'desc' },
  })

  return (
    <div style={{ display: 'flex', gap: 24, padding: '32px 24px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', maxWidth: 1100, margin: '0 auto' }}>
      <UserNav activeSection="support" />

      <div style={{ flex: 1, minWidth: 0 }}>
        <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 8 }}>پشتیبانی</h1>
        <p style={{ color: '#6f7680', fontSize: 13.5, marginBottom: 22, lineHeight: 1.9 }}>
          مشکل یا سوالت رو ثبت کن — کارشناس ما همین‌جا جواب می‌ده و می‌تونی گفتگو رو ادامه بدی.
        </p>

        {/* ── فرم تیکت جدید ── */}
        <div style={cardStyle}>
          <b style={{ fontSize: 14, display: 'block', marginBottom: 14 }}>ثبت تیکت جدید</b>
          <form action={createTicketAction}>
            <div style={{ marginBottom: 12 }}>
              <div style={labelStyle}>موضوع</div>
              <input name="subject" required maxLength={120} placeholder="مثلاً: مشکل در تایید فیش پرداخت"
                style={inputStyle} />
            </div>
            <div style={{ marginBottom: 14 }}>
              <div style={labelStyle}>شرح مشکل</div>
              <textarea name="detail" rows={5} required placeholder="توضیح بده چه اتفاقی افتاده…"
                style={{ ...inputStyle, resize: 'vertical' }} />
            </div>
            <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <button type="submit" style={submitBtnStyle}>ثبت تیکت</button>
            </div>
          </form>
        </div>

        {/* ── لیست تیکت‌های من ── */}
        <h2 style={{ fontSize: 16, fontWeight: 700, margin: '28px 0 14px' }}>تیکت‌های من</h2>
        {tickets.length === 0 ? (
          <div style={{ padding: 32, textAlign: 'center', color: '#9199a3', border: '1px dashed #d8dde3', borderRadius: 12 }}>
            هنوز تیکتی ثبت نکردی.
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {tickets.map((t) => (
              <a key={t.id} href={`/support/${t.id}`} style={{ textDecoration: 'none' }}>
                <div style={{ ...cardStyle, padding: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12 }}>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 14, fontWeight: 700, color: '#1e357b', marginBottom: 4 }}>{t.subject}</div>
                    <div style={{ fontSize: 11.5, color: '#9199a3' }}>
                      {t._count.messages} پیام · آخرین بروزرسانی {new Date(t.updatedAt).toLocaleDateString('fa-IR')}
                    </div>
                  </div>
                  <span style={statusTagStyle(t.status)}>{translateStatus(t.status)}</span>
                </div>
              </a>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

// ── ترجمه و رنگ وضعیت ─────────────────────────────────────────────────
function translateStatus(status: string): string {
  const map: Record<string, string> = { open: 'باز', answered: 'پاسخ‌داده‌شده', closed: 'بسته' }
  return map[status] ?? status
}

function statusTagStyle(status: string): React.CSSProperties {
  let bg = '#f1efe8'
  let color = '#4f5560'
  if (status === 'open') { bg = '#fef3c7'; color = '#92400e' }
  else if (status === 'answered') { bg = '#d1fae5'; color = '#065f46' }
  else if (status === 'closed') { bg = '#e5e7eb'; color = '#4b5563' }
  return { fontSize: 10.5, fontWeight: 700, background: bg, color, borderRadius: 6, padding: '4px 10px', whiteSpace: 'nowrap' }
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const cardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3', borderRadius: 12, padding: 20,
  background: '#fff', boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const inputStyle: React.CSSProperties = {
  border: '1px solid #d8dde3', borderRadius: 8,
  padding: '9px 12px', fontSize: 13, fontFamily: 'inherit', width: '100%',
}
const labelStyle: React.CSSProperties = {
  fontSize: 12, fontWeight: 700, color: '#4f5560', marginBottom: 4,
}
const submitBtnStyle: React.CSSProperties = {
  background: '#1e357b', color: '#fff', border: 'none', borderRadius: 8,
  padding: '9px 18px', fontSize: 12.5, fontWeight: 700, cursor: 'pointer',
  fontFamily: 'inherit',
}
