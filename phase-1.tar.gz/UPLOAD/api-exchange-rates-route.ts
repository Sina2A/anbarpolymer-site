/**
 * POST /api/exchange-rates — ingest endpoint for poller.py
 *
 * ⚠️  NETWORK-EXPOSED ENDPOINT — requires a shared secret token.
 *     Set EXCHANGE_RATE_SECRET in .env on the server.
 *     poller.py sends: Authorization: Bearer <token>
 *
 * Body (JSON):
 *   { currency: "USD", rateToToman: 62850, source?: "telegram_scraper" }
 *   OR array of the above for batch insert.
 *
 * This route writes to ExchangeRate only — it has ZERO connection to
 * PriceRecord / pricing engine / benchmark calculations.
 */

import { NextRequest, NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { logEvent } from '@/lib/logger'

export async function POST(request: NextRequest) {
  // ── Auth check ──
  const secret = process.env.EXCHANGE_RATE_SECRET
  if (!secret) {
    // If the env var is not set, refuse all writes (fail-closed)
    return NextResponse.json(
      { error: 'EXCHANGE_RATE_SECRET is not configured on the server.' },
      { status: 503 },
    )
  }

  const authHeader = request.headers.get('authorization') ?? ''
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : ''

  if (token !== secret) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  // ── Parse body ──
  let body: unknown
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 })
  }

  const items = Array.isArray(body) ? body : [body]

  if (items.length === 0) {
    return NextResponse.json({ error: 'Empty payload' }, { status: 400 })
  }
  if (items.length > 20) {
    return NextResponse.json({ error: 'Max 20 rates per request' }, { status: 400 })
  }

  // ── Validate & insert ──
  const inserted: string[] = []

  for (const item of items) {
    const currency = typeof item?.currency === 'string' ? item.currency.trim().toUpperCase() : ''
    const rateToToman = typeof item?.rateToToman === 'number' ? item.rateToToman : NaN
    const source = typeof item?.source === 'string' ? item.source.trim() : 'telegram_scraper'

    if (!currency || currency.length > 10) {
      return NextResponse.json(
        { error: `Invalid currency: "${item?.currency}"` },
        { status: 400 },
      )
    }
    if (isNaN(rateToToman) || rateToToman <= 0) {
      return NextResponse.json(
        { error: `Invalid rateToToman for ${currency}: ${item?.rateToToman}` },
        { status: 400 },
      )
    }

    await prisma.exchangeRate.create({
      data: { currency, rateToToman, source },
    })

    inserted.push(currency)
  }

  logEvent({
    level: 'info',
    category: 'exchange-rate',
    message: `Ingested rates: ${inserted.join(', ')}`,
  })

  return NextResponse.json({ ok: true, inserted })
}
