import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import UserNav from '@/components/UserNav'
import { enforceDealDeadlines } from '@/lib/dealDeadlines'

export const dynamic = 'force-dynamic'

/**
 * صفحه‌ی لیست «معاملات من» — فقط Dealهایی که همین خریدار (buyerId) طرف‌شونه.
 * هم‌الگوی proformas/page.tsx — کارت لینک‌دار به جزئیات هر معامله.
 */

const STATUS_LABELS: Record<string, string> = {
  draft: 'پیش‌نویس',
  confirmed: 'تایید شد',
  seller_fee_paid: 'کارمزد فروشنده پرداخت شد',
  payment_secured: 'وجه تضمین شد',
  loading: 'در حال بارگیری',
  in_transit: 'در مسیر ارسال',
  delivered: 'تحویل شد',
  settled: 'تسویه شد',
}

export default async function MyDealsPage() {
  const user = await getCurrentUser()

  await enforceDealDeadlines()

  const deals = await prisma.deal.findMany({
    where: { buyerId: user.id },
    include: { materialListing: { include: { grade: true } } },
    orderBy: { createdAt: 'desc' },
  })

  return (
    <div style={pageStyle}>
      <div style={{ maxWidth: 1100, margin: '0 auto', display: 'flex', gap: 24 }} className="admin-page-wrap">
        <UserNav currentUserName={user.companyName} activeSection="deals" />
        <div style={{ flex: 1, minWidth: 0 }}>
          <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>معاملات من</h1>
          <p style={{ fontSize: 13, color: '#9199a3', marginBottom: 24 }}>
            معاملاتی که شما به‌عنوان خریدار طرف‌شون هستید — برای پرداخت یا پیگیری حمل، روی هر کارت بزنید
          </p>

          {deals.length === 0 && (
            <div style={emptyBox}>
              هنوز معامله‌ای به نام شما ثبت نشده — وقتی کارشناس معامله‌ای برایتان ایجاد کند، اینجا نمایش داده می‌شود.
            </div>
          )}

          {deals.map((deal) => {
            const gradeCode = (deal.materialListing as unknown as { grade?: { code: string } })?.grade?.code || ''

            return (
              <a key={deal.id} href={`/my-deals/${deal.id}`} style={cardLink}>
                <div style={cardStyle}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                    <b style={{ fontSize: 14 }}>معامله #{deal.id.slice(0, 8)}</b>
                    <span style={statusTag}>{STATUS_LABELS[deal.status] || deal.status}</span>
                  </div>

                  <div style={{ fontSize: 12.5, color: '#4f5560', marginBottom: 6 }}>
                    {gradeCode && <span style={{ fontFamily: 'monospace' }}>{gradeCode} — </span>}
                    {deal.quantity}
                  </div>

                  {deal.buyerConfirmDeadline && (deal.status === 'confirmed' || deal.status === 'seller_fee_paid') && (
                    <div style={{ fontSize: 11.5, color: '#7a3a10', marginBottom: 6 }}>
                      ⏳ مهلت پرداخت: {new Date(deal.buyerConfirmDeadline).toLocaleString('fa-IR', { dateStyle: 'short', timeStyle: 'short' })} — بعد از این زمان معامله خودکار لغو می‌شود
                    </div>
                  )}

                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: 12.5, fontWeight: 700 }}>
                      {deal.agreedPrice || 'قیمت توافقی ثبت نشده'}
                    </span>
                    <span style={{ fontSize: 11.5, color: '#9199a3' }}>
                      {new Date(deal.createdAt).toLocaleDateString('fa-IR')}
                    </span>
                  </div>
                </div>
              </a>
            )
          })}
        </div>
      </div>
    </div>
  )
}

const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: '#faf8f4',
  padding: '32px 20px',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const emptyBox: React.CSSProperties = {
  padding: 32,
  textAlign: 'center',
  color: '#9199a3',
  border: '1px dashed #d8dde3',
  borderRadius: 12,
  fontSize: 13,
}
const cardLink: React.CSSProperties = {
  display: 'block',
  textDecoration: 'none',
  color: 'inherit',
}
const cardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 18,
  marginBottom: 14,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
  transition: 'border-color .15s',
}
const statusTag: React.CSSProperties = {
  fontSize: 11,
  fontWeight: 700,
  background: '#eef4fd',
  color: '#1e357b',
  borderRadius: 6,
  padding: '4px 12px',
}
