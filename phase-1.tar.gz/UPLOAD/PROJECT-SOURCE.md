# انبار پلیمر — سند وضعیت پروژه

> آخرین به‌روزرسانی: ۱۴۰۵/۰۵/۳۰ (2026-08-21)
> این سند خلاصه‌ی کاملِ کاری است که در این نشست انجام شد — از ابتدای چت تا این لحظه.
> هدفش این است که اگر چت از دست رفت یا نشست جدیدی شروع شد، بدون خواندن تاریخچه بشود ادامه داد.

---

## ۱. مشخصات فنی پروژه

| مورد | مقدار |
|---|---|
| فریم‌ورک | Next.js **16.2.12** (App Router + Turbopack) |
| کتابخانه UI | React **19.2.4** |
| ORM | Prisma **7.9.1** + `@prisma/adapter-pg` + `pg` |
| دیتابیس | PostgreSQL |
| زبان | TypeScript |
| مسیر سرور | `/var/www/anbarpolymer-app` |
| آدرس | `185.164.73.143:3000` |
| pm2 process | `anbarpolymer` |
| ریپو | `github.com/Sina2A/anbarpolymer-site` |
| سیستم‌عامل | Ubuntu 24 (اتصال با MobaXterm) |

**نکات مهم محیط:**
- سرور سابقه‌ی `ETIMEDOUT` روی `npm install` دارد → **از افزودن پکیج npm جدید پرهیز کن** (به همین دلیل ایمپورت با CSV پیاده شد نه xlsx باینری).
- در این پروژه `prisma migrate dev` کلاینت را **خودکار بازتولید نمی‌کند** (به‌خاطر `prisma.config.ts`). بعد از هر تغییر schema حتماً `npx prisma generate` جدا اجرا شود.
- فایل `AGENTS.md` پروژه هشدار می‌دهد که این نسخه‌ی Next.js تغییرات breaking دارد؛ قبل از کدنویسی به `node_modules/next/dist/docs/` مراجعه شود.

---

## ۲. چارچوب شماره ۱ — روال ثابت آپدیت (قانون طلایی)

> این روال توسط کارفرما تعریف شده و بر همه‌ی کارهای آینده حاکم است.

**قانون طلایی:** فایل اصلی پروژه **هرگز ویرایش نمی‌شود**. هر تغییر = یک فایل کاملِ جدید در
`D:\...\claud code web AP\NEW FILES\` با همان ساختار پوشه‌ی مقصد سرور، که از طریق گیت‌هاب روی سرور لود می‌شود.

**تعیین حجم کار، اول از همه:**
- **کار کوچک = ۱ یا ۲ فایل** → موازی و سریع، هر دو در همان نوبت، بدون توقف بین‌شان، بدون منتظر تأیید ماندن.
- **کار بزرگ = ۳ فایل یا بیشتر** → روال «یک فایل، توقف، تأیید». تا گفته نشود «برو قدم بعد»، فایل بعدی شروع نمی‌شود.

**مراحل:**
1. پرامپت خوانده شود. اگر مبهم بود فقط سؤال پرسیده شود، کد زده نشود.
2. خروجی همیشه **فایل کامل نهایی** است (نه diff). محل: `NEW FILES/` با ساختار مقصد.
3. قانون ضدحلقه: هر فایل یک بار خوانده شود. پیام `Wasted call` = محتوا موجود است، دوباره خوانده نشود.
4. مسیر کامل فایل(ها) اعلام شود.
5. دستور نصب MobaXterm/Ubuntu داده شود.
6. کوتاه توضیح داده شود هر دستور چه می‌کند و آیا `prisma migrate` لازم است یا نه.
7. کار بزرگ → توقف و انتظار تأیید. کار کوچک → همه یکجا.

**قرارداد نام‌گذاری ریپو:** همه‌ی فایل‌ها در **ریشه‌ی یک ریپوی واحد** قرار می‌گیرند، پس نام باید یکتا باشد.
قاعده: مسیر پروژه با خط تیره به‌جای اسلش، بدون پیشوند `src/`:

| مسیر واقعی پروژه | نام در ریپو |
|---|---|
| `prisma/schema.prisma` | `prisma-schema.prisma` |
| `src/lib/gradeSpecs.ts` | `lib-gradeSpecs.ts` |
| `src/components/GradeSpecPicker.tsx` | `components-GradeSpecPicker.tsx` |
| `src/components/AdminNav.tsx` | `components-AdminNav.tsx` |
| `src/app/globals.css` | `app-globals.css` |
| `src/app/admin-grades/actions.ts` | `app-admin-grades-actions.ts` |
| `src/app/admin-grades/page.tsx` | `app-admin-grades-page.tsx` |

**پوشه‌ی `UPLOAD/` (الزامی):** هر فایلی که ساخته می‌شود، هم‌زمان با **نام ریپو** در
`NEW FILES/UPLOAD/` هم کپی می‌شود. کارفرما مستقیم از همان‌جا روی گیت‌هاب می‌گذارد،
و تاریخچه‌ی «چه چیزی کِی آپلود شد» هم قابل ردیابی می‌ماند.

**فایل‌های وابسته = یک zip (الزامی):** اگر چند فایل به هم وابسته‌اند (مثلاً CSS کلاس تعریف
می‌کند و TSX از آن استفاده می‌کند)، جدا آپلود نشوند — چون بین دو نصب سایت نصفه‌کاره است.
یک zip با **ساختار واقعی مسیر پروژه** ساخته می‌شود.

### الگوی امن نصب (همیشه از این استفاده شود)

هرگز `wget -O` مستقیم روی فایل اصلی زده نشود. الگوی درست:

```bash
cd /var/www/anbarpolymer-app
wget -O /tmp/<name> <raw-url>     # ۱. دانلود در tmp
wc -l /tmp/<name>                 # ۲. بازرسی: تعداد خط با نسخه‌ی محلی بخواند
grep -c "<نشانه‌ی فایل جدید>" /tmp/<name>
cp /tmp/<name> <مسیر واقعی>       # ۳. تازه کپی
npm run build && pm2 restart anbarpolymer
```

برای zip:
```bash
wget -O /tmp/bundle.zip <raw-url>
rm -rf /tmp/apbundle && mkdir -p /tmp/apbundle
unzip -o /tmp/bundle.zip -d /tmp/apbundle
find /tmp/apbundle -type f         # بازرسی قبل از کپی
cp -r /tmp/apbundle/src/. src/
npm run build && pm2 restart anbarpolymer
```

برای `schema.prisma` بعد از `cp` حتماً `npx prisma validate` سپس `npx prisma migrate dev` سپس `npx prisma generate`.

---

## ۳. صورت‌مسئله — ۷ مورد ناقص پنل گریدها

| # | مورد | وضعیت |
|---|---|---|
| ۱ | فرم ویرایش گرید موجود (`updateGradeAction` بود ولی UI نداشت) | ✅ نصب شد |
| ۲ | جست‌وجو و فیلتر روی جدول گریدها | ✅ نصب شد |
| ۳ | ایمپورت گروهی از فایل (CSV) | ✅ نصب شد |
| ۴ | عکس محصول | ✅ نصب شد |
| ۵ | دیتاشیت فنی (TDS) | ✅ نصب شد |
| ۶ | اتصال به صفحه‌ی عمومی `/grades` + صفحه‌ی جزئیات `/grades/[code]` | ⏳ مانده |
| ۷ | موتور تطبیق و مقایسه‌ی گریدها | ⏳ مانده |

**به‌علاوه‌ی موارد بالا، انجام شد:**
- MFI و چگالی **اجباری** (هم در UI و هم اعتبارسنجی سمت سرور)
- ویجت انتخاب **۷۲ مشخصه‌ی فنی** استاندارد ASTM/ISO در هر دو فرم (جدید و ویرایش)
- افزودن مخفف انگلیسی به هر ۷۲ برچسب فارسی
- واکنش‌گرا کردن پنل روی موبایل
- تبدیل منوی پنل ادمین به دراپ‌داون در موبایل

**عمداً خارج از دامنه (به درخواست کارفرما):**
- ❌ حذف واقعی گرید (فقط غیرفعال‌سازی)
- ❌ قیمت مرجع / benchmark
- ❌ موجودی انبار
- ❌ **هیچ منطق قیمتی** — موتور قیمت‌گذاری عامدانه فریز است

---

## ۴. تصمیم‌های معماری و دلیلشان

**۱. `specsJson` به‌جای ۷۲ ستون یا جدول رابطه‌ای**
پروژه از قبل قرارداد ستون JSON-string دارد (`checklistJson`، `metaJson`). ۷۲ ستون تنک (sparse)
حجم بی‌مورد و migration سنگین می‌سازد؛ جدول رابطه‌ای `GradeSpec` برای داده‌ای که فقط نمایش داده
می‌شود و روی آن JOIN سنگین نمی‌زنیم، پیچیدگی اضافه است.

**۲. اما `mfi` و `density` ستون مستقل ماندند**
این دو (به‌همراه `applicationType`) ورودی **موتور تطبیق** آینده‌اند و باید روی آن‌ها فیلتر و
مرتب‌سازی دیتابیسی انجام شود — که داخل یک رشته‌ی JSON ممکن نیست.
به همین دلیل ویجت مشخصات فنی این دو را **عمداً حذف می‌کند** (`EXCLUDED_KEYS`) تا داده دوتایی و
ناهماهنگ ذخیره نشود.

**۳. فیلتر روی سرور، نه مرورگر**
کارفرما پرسید چرا فیلتر سمت مرورگر نباشد تا بار سرور کم شود. دلیل رد شدن:
فیلتر مرورگری یعنی **همه‌ی گریدها** باید به مرورگر فرستاده شوند — حجم بالا، و مهم‌تر:
گریدهای **غیرفعال** و همه‌ی مشخصات فنی در View Source هر بازدیدکننده‌ای قابل دیدن می‌شد.
فیلتر دیتابیسی هم سبک‌تر است هم امن‌تر.

**۴. CSV به‌جای xlsx**
xlsx باینری نیاز به پکیج npm جدید دارد و سرور سابقه‌ی `ETIMEDOUT` روی `npm install` دارد.
یک پارسر CSV بدون وابستگی نوشته شد که BOM، کوتیشن، کوتیشن escape شده (`""`)،
کامای داخل فیلد و CRLF را مدیریت می‌کند.

**۵. فرم‌های آپلود بیرون از فرم اصلی**
`<form>` تودرتو در HTML **غیرمجاز** است. آپلود عکس و دیتاشیت فرم مستقل دارند.
کارفرما تأیید کرد که این از نظر کاربری هم بهتر است: «دیگه نیاز نیست هی برای ثبت عکس گزینه ذخیره تغییرات را بزنیم».

**۶. `<details>` به‌جای `useState` برای منوی موبایل**
بدون جاوااسکریپت هم کار می‌کند؛ با CSS محض می‌شود روی دسکتاپ همیشه‌باز نگه داشت؛
پشتیبانی کیبورد و screen reader رایگان به‌دست می‌آید.

**۷. CSS واکنش‌گرا در `globals.css`، نه `<style>` تزریقی**
ابتدا به‌اشتباه تصور شد پروژه CSS سراسری ندارد و یک بلوک `<style>` داخل `page.tsx` تزریق شد.
کارفرما اطلاع داد که «ما برای کل سایت css داریم» → همه‌ی قوانین به `src/app/globals.css` منتقل شد.

---

## ۵. فایل‌های ساخته‌شده

مسیر پایه: `D:\documents\Sina Radman Kavir\IMPORT FILES\WEB 2 - AnbarPolymer\claud chat\claud code web AP\NEW FILES\`

| فایل | خط | نام ریپو | وضعیت سرور |
|---|---|---|---|
| `prisma/schema.prisma` | ۷۳۱ | `prisma-schema.prisma` | ✅ نصب + migrate |
| `src/lib/gradeSpecs.ts` | ۲۳۵ | `lib-gradeSpecs.ts` | ✅ نصب |
| `src/components/GradeSpecPicker.tsx` | ۲۷۲ | `components-GradeSpecPicker.tsx` | ✅ نصب |
| `src/app/admin-grades/actions.ts` | ۴۳۰ | `app-admin-grades-actions.ts` | ✅ نصب |
| `src/app/admin-grades/page.tsx` | ۴۶۰ | `app-admin-grades-page.tsx` | ✅ نصب |
| `src/app/globals.css` | ۷۲۶ | `app-globals.css` | ⚠️ نسخه‌ی ۶۹۵خطی نصب شده — نسخه‌ی ۷۲۶خطی (با CSS منو) در zip منتظر نصب |
| `src/components/AdminNav.tsx` | ۱۴۳ | `components-AdminNav.tsx` | ⏳ در zip، منتظر نصب |

**zip آماده:** `UPLOAD/adminnav-mobile.zip` — شامل `src/app/globals.css` + `src/components/AdminNav.tsx`

### ۵.۱ `prisma/schema.prisma`

سه فیلد به مدل `Grade` اضافه شد (بعد از `description`):

```prisma
// --- عکس محصول و دیتاشیت فنی ---
imageUrl     String?  // عکس محصول — برای نمایش توی صفحه‌ی عمومی گریدها
datasheetUrl String?  // دیتاشیت فنی (TDS) به‌صورت PDF

// --- مشخصات فنی انتخابی (از فهرست ۷۲ فیلد استاندارد ASTM/ISO) ---
specsJson    String?
```

Migration اعمال‌شده روی سرور: **`20260820180819_add_grade_media_and_specs`**
هر سه فیلد `String?` (nullable) هستند → هیچ داده‌ی موجودی خراب نشد.

### ۵.۲ `src/lib/gradeSpecs.ts`

کاتالوگ ۷۲ مشخصه‌ی فنی. **عمداً prisma-free** است تا کامپوننت کلاینتی بتواند import کند
(همان قاعده‌ی `sections.ts`).

```ts
export type SpecGroupKey = 'physical' | 'mechanical' | 'thermal' | 'optical' | 'electrical'
export type SpecField = { key: string; label: string; unit: string; standard: string; group: SpecGroupKey }

export const SPEC_GROUPS          // ۵ گروه
export const SPEC_FIELDS          // ۷۲ فیلد: ۱۸ فیزیکی + ۲۰ مکانیکی + ۱۶ گرمایی + ۱۰ نوری + ۸ الکتریکی
export const SPEC_FIELD_COUNT     // = 72
export const SPEC_FIELD_BY_KEY    // Record<string, SpecField>
export const SPEC_INPUT_PREFIX    // = 'spec__'

export function specFieldsByGroup(group)
export function parseSpecs(specsJson)        // هرگز throw نمی‌کند
export function serializeSpecs(values)       // خالی → null
export function readSpecsFromFormData(formData)
export function buildCsvTemplate()
export const CSV_BASE_COLUMNS                // ۱۲ ستون پایه
export const CSV_ALL_COLUMNS                 // پایه + ۷۲ کلید
```

هر برچسب مخفف انگلیسی داخل پرانتز دارد. نمونه:

```ts
{ key: 'density',              label: 'چگالی (Density)',                              unit: 'g/cm³',   standard: 'ASTM D792',  group: 'physical' }
{ key: 'mfi',                  label: 'شاخص جریان مذاب (MFI)',                        unit: 'g/10min', standard: 'ASTM D1238', group: 'physical' }
{ key: 'tensileStrengthYield', label: 'استحکام کششی در نقطه تسلیم (Tensile @ Yield)',  unit: 'MPa',     standard: 'ASTM D638',  group: 'mechanical' }
{ key: 'izodImpactNotched',    label: 'مقاومت ضربه ایزود شیاردار (Izod Notched)',      unit: 'J/m',     standard: 'ASTM D256',  group: 'mechanical' }
{ key: 'hdt182',               label: 'دمای تغییر شکل حرارتی ۱.۸۲ (HDT-A)',            unit: '°C',      standard: 'ASTM D648',  group: 'thermal' }
{ key: 'cti',                  label: 'شاخص ردیابی مقایسه‌ای (CTI)',                   unit: 'V',       standard: 'IEC 60112',  group: 'electrical' }
```

> `key` و `unit` و `standard` هنگام افزودن مخفف‌ها دست‌نخورده ماندند → داده‌ی ذخیره‌شده در
> `specsJson` سالم ماند و ستون‌های CSV تغییر نکردند. منفعت جانبی: جست‌وجوی ویجت روی `label`
> کار می‌کند، پس تایپ «Izod» یا «HDT» هم فیلد را پیدا می‌کند.

### ۵.۳ `src/components/GradeSpecPicker.tsx`

کامپوننت `'use client'`. کاربر فیلد را تیک می‌زند و بلافاصله جای ورود مقدارش ظاهر می‌شود.

```tsx
const EXCLUDED_KEYS = new Set(['mfi', 'density'])   // ستون مستقل دیتابیس‌اند
const PICKABLE_FIELDS = SPEC_FIELDS.filter(f => !EXCLUDED_KEYS.has(f.key))  // ۷۰ فیلد
type Props = { initialValues?: Record<string, string>; defaultOpen?: boolean }
```

- `useState<Set<string>>` برای انتخاب + `useState<Record<string,string>>` برای مقادیر + `query` برای جست‌وجو
- `useMemo` برای فیلتر بر اساس `label` / `key` / `standard`
- برداشتن تیک، مقدار را هم پاک می‌کند تا مقدار قدیمی به سرور نرود
- خروجی: `<input name={SPEC_INPUT_PREFIX + f.key}>` که مستقیم در FormData فرم والد می‌رود — هیچ state ای به سرور پاس داده نمی‌شود

### ۵.۴ `src/app/admin-grades/actions.ts`

```ts
async function requireGradeEditAccess()   // admin یا access.grades ∈ ('edit','full')
function toFloatOrNull(s)                 // جداکننده‌ی اعشار ٬ و , را هم می‌فهمد
const GRADE_UPLOAD_ROOT = path.join(process.cwd(), 'public', 'uploads', 'grades')
const ALLOWED_EXT = { image: ['jpg','jpeg','png','webp','gif'], datasheet: ['pdf'] }
async function saveGradeFile(gradeId, file, kind)   // → /uploads/grades/<kind>/<gradeId>/<ts>-<hex>.<ext>
async function removeStoredFile(url)

export async function createGradeAction(formData)        // MFI + چگالی اجباری سمت سرور
export async function updateGradeAction(formData)        // MFI + چگالی اجباری
export async function toggleGradeActiveAction(formData)
export async function uploadGradeImageAction(formData)
export async function uploadGradeDatasheetAction(formData)
export async function clearGradeMediaAction(formData)    // kind: 'image' | 'datasheet'
function parseCsvText(text): string[][]                  // BOM، کوتیشن، "" ، کامای داخلی، CRLF
export async function importGradesCsvAction(formData)    // ساخت-یا-به‌روزرسانی بر اساس code
```

الگوی آپلود از `src/lib/kyc.ts` گرفته شده (`fs/promises` + `crypto.randomBytes`).
در ایمپورت CSV، **سلول خالی یعنی «دست نزن»** نه «خالی کن».

### ۵.۵ `src/app/admin-grades/page.tsx`

Server Component با `export const dynamic = 'force-dynamic'`.

- `searchParams` به‌صورت `Promise` (الزام Next 16) + هلپر `one()`
- فیلترهای `q` / `status` / `origin` / `category` / `edit` روی دیتابیس با `mode: 'insensitive'`
- `Promise.all([findMany, count])`
- فرم ویرایش در `?edit=<id>` — کارت با حاشیه‌ی آبی، همه‌ی فیلدها پرشده، `<GradeSpecPicker initialValues={parseSpecs(...)} defaultOpen />`
- فرم‌های آپلود **بیرون** از فرم اصلی
- بخش ایمپورت CSV با فهرست `CSV_ALL_COLUMNS`
- کلاس‌های واکنش‌گرا: `admin-page-wrap` / `grade-form-grid` / `grades-filter-form` / `spec-full` / `spec-badge`

### ۵.۶ `src/app/globals.css`

۶۴۹ خط اولیه دست‌نخورده ماند (طراحی‌سیستم موجود: متغیرهای `:root`، `.admin-layout`، `.table-scroll`، `.spec-chip` و...).
دو بلوک به انتها اضافه شد:

```css
/* پیش‌فرض دسکتاپ — عمداً قبل از @media، چون media تخصص اضافه نمی‌کند و ترتیب منبع تعیین‌کننده است */
.spec-full{display:block;}
.spec-badge{display:none;}

@media (max-width:900px){
  /* ... قوانین قبلی پروژه ... */
  .admin-page-wrap{flex-direction:column !important; padding:16px 12px !important; gap:16px !important;}
  .grade-form-grid{grid-template-columns:1fr !important;}
  .grades-filter-form{grid-template-columns:1fr !important;}
  .spec-full{display:none;}
  .spec-badge{display:inline-block;}
}

/* منوی پنل: ستون ثابت روی دسکتاپ، دراپ‌داون روی موبایل */
.admin-nav{width:230px; flex-shrink:0; border:1px solid #d8dde3; border-radius:12px; padding:16px; background:#fff; height:fit-content;}
.admin-nav-toggle{display:none;}
.admin-nav > summary::-webkit-details-marker{display:none;}
.admin-nav > summary{list-style:none;}

@media (max-width:900px){
  .admin-nav{width:100%; padding:0; border-radius:10px; overflow:hidden;}
  .admin-nav-toggle{display:flex; justify-content:space-between; align-items:center; padding:13px 14px; cursor:pointer; font-size:14px; font-weight:700; color:#241d15; background:#fff; user-select:none;}
  .admin-nav[open] .admin-nav-toggle{border-bottom:1px solid #eceff3;}
  .admin-nav[open] .admin-nav-caret{transform:rotate(180deg);}
  .admin-nav-caret{transition:transform .15s; color:#83765f;}
  .admin-nav > div, .admin-nav > nav{padding-left:14px; padding-right:14px;}
  .admin-nav > nav{padding-bottom:12px;}
  .admin-nav > div:first-of-type{padding-top:12px;}
}
```

> **نکته‌ی ظریف CSS:** قوانین پیش‌فرض `.spec-full{display:block}` عمداً **قبل** از بلوک
> `@media` نوشته شده‌اند. در نسخه‌ی اول بعد از آن نوشته شدند و چون media query تخصص
> (specificity) اضافه نمی‌کند، قانون بعدی برنده می‌شد و روی موبایل هم اثر نمی‌کرد.

### ۵.۷ `src/components/AdminNav.tsx`

از `<aside style={{width:230, flexShrink:0, ...}}>` تبدیل شد به `<details className="admin-nav" open>`.

- چون همیشه با `open` رندر می‌شود و روی دسکتاپ `.admin-nav-toggle{display:none}` است،
  **ظاهر دسکتاپ مو‌به‌مو مثل قبل** است.
- زیر ۹۰۰px نوار `☰ <نام بخش فعال> ▾` ظاهر می‌شود.
- `activeLabel` از روی `activeSection` محاسبه می‌شود تا کاربر موبایل بدون بازکردن منو بداند کجاست.
- `asideStyle` حذف شد (ظاهرش رفت به کلاس `.admin-nav`) چون media query در استایل inline کار نمی‌کند.

این تغییر روی **همه‌ی صفحات پنل** اثر می‌گذارد (گریدها، کاربران، سفارش‌ها، KYC و...) چون همه از همین کامپوننت استفاده می‌کنند.

---

## ۶. خطاها و درس‌های آموخته‌شده

### ۶.۱ 🔴 بحرانی — schema اشتباه روی نسخه‌ی سالم نوشت

`wget -O prisma/schema.prisma` یک schema **کهنه‌ی ۱۲۹۰۱ بایتی** از ریپو گرفت و فایل سالم سرور را
بازنویسی کرد. سپس `prisma migrate dev` گزارش ۲۴ قدم معلق داد و متوقف شد:

```
Step 24 Made the column `phone` on table `User` required, but there are 1 existing NULL values.
```

**هیچ چیزی روی دیتابیس نوشته نشد** — Prisma قبلش متوقف شد.
تشخیص از روی حجم: فایل درست **۳۹۲۹۷ بایت / ۷۳۱ خط** است.
`grep -n "phone"` تأیید کرد خط ۱۰۰ پروژه `phone String? @unique` (اختیاری) است → خطا کاملاً از فایل خراب می‌آمد.

**درس (در چارچوب ۱ ثبت شد):** هرگز `wget -O` مستقیم روی فایل زنده. همیشه `/tmp` → بازرسی → `cp`.
همچنین: `wget -O` حتی روی خطای ۴۰۴ هم فایل مقصد را خالی می‌کند.

### ۶.۲ خطای بیلد — `specsJson does not exist in type GradeCreateInput`

```
./src/app/admin-grades/actions.ts:123:7
Type error: Object literal may only specify known properties, and 'specsJson' does not exist...
```

علت: کلاینت تولیدشده‌ی Prisma کهنه بود. در این پروژه `migrate dev` آن را بازتولید نمی‌کند.
راه‌حل: `npx prisma generate && npm run build`. **(در چارچوب ۱ ثبت شد.)**

### ۶.۳ خطای ۴۰۴ روی wget

فایل هنوز روی گیت‌هاب نبود. سپس مشخص شد فایل‌ها در **ریشه‌ی** ریپو قرار می‌گیرند،
پس URL درست `.../main/lib-gradeSpecs.ts` است نه `.../main/src/lib/gradeSpecs.ts`.

### ۶.۴ ترتیب اشتباه قوانین CSS

قوانین پیش‌فرض `.spec-full`/`.spec-badge` ابتدا **بعد** از `@media` نوشته شدند.
چون media query تخصص اضافه نمی‌کند، ترتیب منبع برنده شد و بلوک موبایل بی‌اثر ماند. جابه‌جا شد.

### ۶.۵ بهینه‌سازی‌های خودتصحیح در `actions.ts`

- `producer` و `category` به select اولیه اضافه و `findUnique` تکراری داخل حلقه‌ی CSV حذف شد.
- `requireGradeEditAccess()` از داخل حلقه بیرون کشیده شد → `const user = await requireGradeEditAccess()`.

---

## ۷. بازخوردهای کارفرما که مسیر را عوض کرد

| بازخورد | نتیجه |
|---|---|
| «همشو داخل یک ریپو میزارم. نام‌گذاریها رو بهینه کن» | قرارداد نام‌گذاری با خط تیره |
| «برای بریکینگ ویو موبایل این گزینه رو بزار ولی برای دسکتاپ حتما همه فیلدها نمایش داده بشه» | `.spec-full` دسکتاپ / `.spec-badge` موبایل |
| «اپلود عکس یا دیتاشیت اختیاری هست و محصول بدون این موارد باید بتونه ساخته بشه» | برچسب «(اختیاری)» + فرم مستقل |
| «ما برای کل سایت css داریم» | انتقال از `<style>` تزریقی به `globals.css` |
| «فایل‌هایی که به هم وابسته هستند زیپ بشن» | تحویل به‌صورت zip با ساختار واقعی |
| «فایلی که میخوای تو گیت هاب اپلود کنم رو با همون نام در ریپو توی پوشه لوکال ذخیره کن» | پوشه‌ی `UPLOAD/` |
| «منو رو تبدیل به دراپ دون منو کن» | بازنویسی `AdminNav` با `<details>` |

---

## ۸. قدم بعدی

**۱. نصب zip منتظر:** `UPLOAD/adminnav-mobile.zip` (منوی دراپ‌داون موبایل).

**۲. سپس موارد ۶ و ۷ — کار بزرگ (۳ فایل)، در یک zip:**

| فایل | کار |
|---|---|
| `src/app/grades/page.tsx` | بازنویسی صفحه‌ی عمومی: عکس، MFI/چگالی/کاربرد، فیلتر |
| `src/app/grades/[code]/page.tsx` | صفحه‌ی جزئیات (لینکش الان شکسته است) + نمایش ۷۲ مشخصه + دانلود دیتاشیت |
| `src/lib/gradeMatch.ts` | موتور تطبیق بر پایه‌ی MFI + چگالی + `applicationType` |

> ⚠️ **موتور تطبیق هیچ منطق قیمتی ندارد** — موتور قیمت‌گذاری عامدانه فریز است.

---

## ۹. فهرست پوشه‌ی UPLOAD

```
NEW FILES/UPLOAD/
├── adminnav-mobile.zip              12KB   ⏳ منتظر نصب
├── app-admin-grades-actions.ts      17KB   ✅ نصب شد
├── app-admin-grades-page.tsx        29KB   ✅ نصب شد
├── app-globals.css                  44KB   ⚠️ نسخه‌ی جدید در zip
├── components-AdminNav.tsx         6.7KB   ⏳ در zip
├── components-GradeSpecPicker.tsx  9.4KB   ✅ نصب شد
├── lib-gradeSpecs.ts                17KB   ✅ نصب شد
└── prisma-schema.prisma             38KB   ✅ نصب + migrate
```
