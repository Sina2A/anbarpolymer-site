#!/usr/bin/env python3
"""
poller.py — Exchange-rate scraper for AnbarPolymer ticker.

Reads USD/EUR rates from a Telegram channel (or stub) and POSTs them to
the /api/exchange-rates ingest endpoint.

DISPLAY ONLY — this data feeds the public header ticker.
It has ZERO connection to the product-pricing / benchmark engine.

Usage:
  # Dry-run (logs to console, no HTTP call):
  python3 poller.py

  # Live mode (sends to the site):
  EXCHANGE_RATE_SECRET=your_token SITE_URL=https://example.com python3 poller.py

  # Run via cron every 15 minutes:
  */15 * * * * cd /var/www/anbarpolymer-app && EXCHANGE_RATE_SECRET=xxx SITE_URL=https://example.com python3 scripts/poller.py >> /var/log/poller.log 2>&1

Environment variables:
  EXCHANGE_RATE_SECRET  — shared secret (must match the server .env value)
  SITE_URL              — base URL of the site, e.g. http://localhost:3000
  TELEGRAM_BOT_TOKEN    — (future) Telegram bot token for real channel scraping
  TELEGRAM_CHANNEL_ID   — (future) numeric channel ID to read from

When EXCHANGE_RATE_SECRET is not set, the script runs in stub/dry-run mode:
it generates dummy rates and prints them to stdout without making any HTTP call.
This mirrors the sms.ts "unconnected provider" pattern.
"""

import json
import os
import sys
import urllib.request
import urllib.error
from datetime import datetime

# ── Configuration ──────────────────────────────────────────────────────

SITE_URL = os.environ.get("SITE_URL", "http://localhost:3000").rstrip("/")
SECRET = os.environ.get("EXCHANGE_RATE_SECRET", "")
ENDPOINT = f"{SITE_URL}/api/exchange-rates"

# ── Stub provider (dry-run) ────────────────────────────────────────────

def fetch_rates_stub():
    """
    Stub: returns hardcoded demo rates.
    Replace with fetch_rates_telegram() once the Telegram bot is connected.
    """
    print(f"[STUB — Telegram scraper not connected] {datetime.now().isoformat()}")
    return [
        {"currency": "USD", "rateToToman": 62850, "source": "stub"},
        {"currency": "EUR", "rateToToman": 68200, "source": "stub"},
    ]

# ── Telegram provider (skeleton — not active yet) ─────────────────────

# def fetch_rates_telegram():
#     """
#     Reads the latest message from a Telegram channel that posts
#     USD/EUR rates (e.g. @TetherLand, @DollarSekke, or a custom channel).
#
#     Requires: TELEGRAM_BOT_TOKEN, TELEGRAM_CHANNEL_ID
#
#     Message parsing is channel-specific — uncomment and adapt the regex
#     patterns below once the actual channel format is known.
#     """
#     import re
#     bot_token = os.environ["TELEGRAM_BOT_TOKEN"]
#     channel_id = os.environ["TELEGRAM_CHANNEL_ID"]
#     url = f"https://api.telegram.org/bot{bot_token}/getUpdates?chat_id={channel_id}&limit=5"
#
#     req = urllib.request.Request(url)
#     with urllib.request.urlopen(req, timeout=15) as resp:
#         data = json.loads(resp.read().decode())
#
#     rates = []
#     for update in reversed(data.get("result", [])):
#         text = update.get("message", {}).get("text", "")
#         # Example pattern — adapt to the real channel format:
#         usd_match = re.search(r"دلار[:\s]*([\d,]+)", text)
#         eur_match = re.search(r"یورو[:\s]*([\d,]+)", text)
#         if usd_match:
#             rates.append({
#                 "currency": "USD",
#                 "rateToToman": int(usd_match.group(1).replace(",", "")),
#                 "source": "telegram_scraper",
#             })
#         if eur_match:
#             rates.append({
#                 "currency": "EUR",
#                 "rateToToman": int(eur_match.group(1).replace(",", "")),
#                 "source": "telegram_scraper",
#             })
#         if rates:
#             break
#     return rates

# ── Provider switch ────────────────────────────────────────────────────

def fetch_rates():
    """
    Switch provider here once the Telegram bot is ready.
    Mirrors the sms.ts sendViaProvider() pattern.
    """
    provider = os.environ.get("RATE_PROVIDER", "stub")

    if provider == "telegram":
        raise NotImplementedError(
            "Telegram provider not connected yet. "
            "Set RATE_PROVIDER=stub or leave unset for dry-run."
        )
        # return fetch_rates_telegram()
    else:
        return fetch_rates_stub()

# ── Send to API ────────────────────────────────────────────────────────

def send_to_api(rates):
    """POST rates to the ingest endpoint with Bearer auth."""
    payload = json.dumps(rates).encode("utf-8")

    req = urllib.request.Request(
        ENDPOINT,
        data=payload,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {SECRET}",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            body = json.loads(resp.read().decode())
            print(f"[OK] {resp.status} — {body}")
    except urllib.error.HTTPError as e:
        err_body = e.read().decode() if e.fp else ""
        print(f"[ERROR] HTTP {e.code}: {err_body}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as e:
        print(f"[ERROR] Connection failed: {e.reason}", file=sys.stderr)
        sys.exit(1)

# ── Main ───────────────────────────────────────────────────────────────

def main():
    rates = fetch_rates()
    if not rates:
        print("[WARN] No rates fetched — nothing to send.")
        return

    print(f"Fetched {len(rates)} rate(s): {json.dumps(rates, ensure_ascii=False)}")

    if not SECRET:
        print("[DRY-RUN] EXCHANGE_RATE_SECRET not set — skipping HTTP POST.")
        return

    send_to_api(rates)

if __name__ == "__main__":
    main()
