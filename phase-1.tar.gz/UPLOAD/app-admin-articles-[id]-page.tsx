import prisma from '@/lib/prisma'
import { notFound } from 'next/navigation'
import { getAllSectionAccess } from '@/lib/permissions'
import { getCurrentUser } from '@/lib/currentUser'
import AdminNav, { PartialAccessBanner } from '@/components/AdminNav'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'
import { updateArticleAction, togglePublishAction, deleteArticleAction } from '../actions'

export const dynamic = 'force-dynamic'

type Params = Promise<{ id: string }>

// Date → مقدار قابل استفاده در input datetime-local (YYYY-MM-DDTHH:mm محلی)
function toLocalInput(d: Date | null): string {
  if (!d) return ''
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`
}

function faDate(d: Date | null | undefined): string {
  if (!d) return '—'
  return new Date(d).toLocaleDateString('fa-IR')
}

const STATUS_META: Record<string, { label: string; style: React.CSSProperties }> = {
  published: { label: 'منتشرشده', style: { fontSize: 10, fontWeight: 700, color: '#065f46', background: '#d1fae5', borderRadius: 6, padding: '2px 8px', whiteSpace: 'nowrap' } },
  scheduled: { label: 'زمان‌بندی‌شده', style: { fontSize: 10, fontWeight: 700, color: '#92400e', background: '#fef3c7', borderRadius: 6, padding: '2px 8px', whiteSpace: 'nowrap' } },
  draft: { label: 'پیش‌نویس', style: { fontSize: 10, fontWeight: 700, color: '#4b5563', background: '#e5e7eb', borderRadius: 6, padding: '2px 8px', whiteSpace: 'nowrap' } },
}

export default async function AdminArticlePage({ params }: { params: Params }) {
  const { id } = await params
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)
  const myLevel = isAdmin ? 'full' : (myAccess?.['articles'] ?? 'none')
  const canEdit = myLevel === 'full' || myLevel === 'edit'

  const article = await prisma.article.findUnique({
    where: { id },
    include: { author: { select: { companyName: true } } },
  })
  if (!article) notFound()

  const status = !article.isPublished
    ? 'draft'
    : article.publishedAt && article.publishedAt.getTime() > Date.now()
      ? 'scheduled'
      : 'published'
  const meta = STATUS_META[status]

  return (
    <div className="admin-page-wrap" style={{ display: 'flex', gap: 24, padding: '32px 24px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', maxWidth: 1100, margin: '0 auto' }}>
      <AdminNav currentUserName={currentUser.companyName} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="articles" />

      <div style={{ flex: 1, minWidth: 0 }}>
        <PartialAccessBanner level={myLevel} sectionLabel="مقالات و اخبار" />

        <a href="/admin-articles" style={{ fontSize: 12, fontWeight: 700, color: '#1e357b', textDecoration: 'none', display: 'inline-block', marginBottom: 10 }}>
          ← همه‌ی مقالات
        </a>

        <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap', marginBottom: 8 }}>
          <h1 style={{ fontSize: 20, fontWeight: 800, margin: 0 }}>{article.title}</h1>
          <span style={meta.style}>{meta.label}</span>
        </div>

        <div style={{ ...cardStyle, padding: 14, marginBottom: 18, fontSize: 11.5, color: '#9199a3' }}>
          نویسنده: <b style={{ color: '#4f5560' }}>{article.author?.companyName ?? '—'}</b>
          {' | '}ساخته: {faDate(article.createdAt)}
          {' | '}آخرین ویرایش: {faDate(article.updatedAt)}
          {article.publishedAt && (
            <>{' | '}انتشار: {faDate(article.publishedAt)}</>
          )}
        </div>

        {canEdit ? (
          <>
            <form action={updateArticleAction} style={{ ...cardStyle, marginBottom: 18 }}>
              <input type="hidden" name="id" value={article.id} />
              <div style={{ marginBottom: 14 }}>
                <div style={labelStyle}>عنوان</div>
                <input name="title" required maxLength={200} defaultValue={article.title} style={inputStyle} />
              </div>
              <div style={{ marginBottom: 14 }}>
                <div style={labelStyle}>تاریخ انتشار <span style={hintInline}>(اختیاری — تاریخ آینده = زمان‌بندی انتشار)</span></div>
                <input type="datetime-local" name="publishedAt" defaultValue={toLocalInput(article.publishedAt)}
                  style={{ ...inputStyle, direction: 'ltr', textAlign: 'left' }} />
              </div>
              <div style={{ marginBottom: 14 }}>
                <div style={labelStyle}>متن مقاله</div>
                <textarea name="content" rows={16} required maxLength={50000} defaultValue={article.content}
                  style={{ ...inputStyle, resize: 'vertical' }} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                <button type="submit" style={submitBtnStyle}>ذخیره‌ی تغییرات</button>
              </div>
            </form>

            <div style={{ ...cardStyle, display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
              <form action={togglePublishAction}>
                <input type="hidden" name="id" value={article.id} />
                {article.isPublished ? (
                  <button type="submit" style={unpublishBtnStyle}>لغو انتشار</button>
                ) : (
                  <button type="submit" style={actionBtnStyle}>انتشار</button>
                )}
              </form>
              <form action={deleteArticleAction}>
                <input type="hidden" name="id" value={article.id} />
                <ConfirmSubmitButton
                  message={`مطمئنی می‌خوای مقاله‌ی «${article.title}» برای همیشه حذف بشه؟`}
                  style={deleteBtnStyle}
                >
                  حذف مقاله
                </ConfirmSubmitButton>
              </form>
            </div>
          </>
        ) : (
          <>
            <div style={{ ...cardStyle, whiteSpace: 'pre-wrap', fontSize: 13, lineHeight: 1.9, color: '#1b1e24', marginBottom: 12 }}>
              {article.content}
            </div>
            <p style={{ fontSize: 11.5, color: '#9199a3' }}>
              برای ویرایش یا انتشار این مقاله، دسترسی ویرایش این بخش لازمه.
            </p>
          </>
        )}
      </div>
    </div>
  )
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const cardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3', borderRadius: 12, padding: 20,
  background: '#fff', boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const labelStyle: React.CSSProperties = {
  fontSize: 12.5, fontWeight: 700, color: '#4f5560', marginBottom: 5,
}
const hintInline: React.CSSProperties = {
  fontWeight: 400, color: '#9199a3', fontSize: 11,
}
const inputStyle: React.CSSProperties = {
  border: '1px solid #d8dde3', borderRadius: 8,
  padding: '10px 12px', fontSize: 13, fontFamily: 'inherit',
  width: '100%', boxSizing: 'border-box',
}
const submitBtnStyle: React.CSSProperties = {
  background: '#1e357b', color: '#fff', border: 'none', borderRadius: 8,
  padding: '10px 28px', fontSize: 13.5, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit',
}
const actionBtnStyle: React.CSSProperties = {
  background: '#f1efe8', color: '#4f5560', border: '1px solid #d8dde3', borderRadius: 8,
  padding: '7px 14px', fontSize: 12, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit',
}
const unpublishBtnStyle: React.CSSProperties = {
  background: 'none', color: '#9b1c1c', border: 'none', borderRadius: 8,
  padding: '7px 10px', fontSize: 12, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit',
}
const deleteBtnStyle: React.CSSProperties = {
  background: 'none', color: '#9b1c1c', border: 'none', borderRadius: 8,
  padding: '7px 10px', fontSize: 12, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit',
}
