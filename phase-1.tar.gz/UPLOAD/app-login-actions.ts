'use server'

import prisma from '@/lib/prisma'
import { verifyPassword, createSession } from '@/lib/auth'
import { logAudit, logError } from '@/lib/logger'
import { getPasswordPolicy, isPasswordExpired } from '@/lib/passwordPolicy'
import { headers } from 'next/headers'
import { redirect } from 'next/navigation'

export async function loginAction(prevState: { error: string }, formData: FormData) {
  const identifier = String(formData.get('identifier') || '').trim()
  const password = String(formData.get('password') || '')

  if (!identifier || !password) {
    return { error: 'نام کاربری/شماره تماس و رمز عبور رو وارد کن.' }
  }

  const user = await prisma.user.findFirst({
    where: { OR: [{ username: identifier }, { phone: identifier }] },
  })

  if (!user || !user.isActive) {
    await logError('auth', 'تلاش ورود ناموفق — کاربر پیدا نشد یا غیرفعاله', { identifier })
    return { error: 'نام کاربری یا رمز عبور اشتباهه.' }
  }

  const passwordOk = verifyPassword(password, user.passwordHash)
  if (!passwordOk) {
    await logError('auth', 'تلاش ورود ناموفق — رمز عبور اشتباه', { identifier }, user.id)
    return { error: 'نام کاربری یا رمز عبور اشتباهه.' }
  }

  if (user.role === 'buyer' && user.phone && !user.phoneVerified) {
    await logAudit('auth', 'ورود مسدود شد — شماره هنوز تایید نشده', user.id)
    redirect(`/verify-phone?phone=${encodeURIComponent(user.phone)}`)
  }

  const policy = await getPasswordPolicy()
  if (isPasswordExpired(user.passwordChangedAt, policy)) {
    await logAudit('auth', 'ورود مسدود شد — رمز عبور منقضی شده', user.id)
    if (user.phone) {
      redirect(`/forgot-password?phone=${encodeURIComponent(user.phone)}&reason=expired`)
    }
    return { error: 'رمز عبور شما منقضی شده — برای بازیابی با مدیر سیستم تماس بگیر (چون حساب شما شماره‌موبایل ثبت‌شده نداره).' }
  }

  await createSession(user.id)
  await logAudit('auth', 'ورود موفق', user.id, { role: user.role })

  if (user.role === 'buyer') {
    redirect('/dashboard')
  }

  // پنل ادمین روی پورت جدا (SURFACE=admin) سرو می‌شود — ریدایرکت باید URL مطلق باشد
  const host = (await headers()).get('host')?.split(':')[0] ?? 'localhost'
  const adminPort = process.env.ADMIN_PORT || '3001'
  redirect(`http://${host}:${adminPort}/admin-users`)
}
