import prisma from '@/lib/prisma'
import { getAllSectionAccess } from '@/lib/permissions'
import { getCurrentUser } from '@/lib/currentUser'
import AdminNav, { PartialAccessBanner } from '@/components/AdminNav'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'
import { notFound } from 'next/navigation'
import { replyToTicketAction, updateTicketStatusAction } from '../actions'

export const dynamic = 'force-dynamic'

type Props = { params: Promise<{ id: string }> }

export default async function AdminSupportTicketPage({ params }: Props) {
  const { id } = await params
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)
  const myLevel = isAdmin ? 'full' : (myAccess?.['support'] ?? 'none')
  const canEdit = myLevel === 'full' || myLevel === 'edit'

  const ticket = await prisma.supportTicket.findUnique({
    where: { id },
    include: {
      user: { select: { companyName: true, phone: true, email: true } },
      messages: { orderBy: { createdAt: 'asc' } },
    },
  })
  if (!ticket) notFound()

  // اسم کارشناسی که آخرین بار پاسخ داده — با کوئری جدا، چون answeredById رابطه‌ی نام‌دار نداره
  const answeredBy = ticket.answeredById
    ? await prisma.user.findUnique({ where: { id: ticket.answeredById }, select: { companyName: true, username: true } })
    : null

  return (
    <div className="admin-page-wrap" style={{ display: 'flex', gap: 24, padding: '32px 24px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', maxWidth: 1100, margin: '0 auto' }}>
      <AdminNav currentUserName={currentUser.companyName} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="support" />

      <div style={{ flex: 1, minWidth: 0 }}>
        <PartialAccessBanner level={myLevel} sectionLabel="پشتیبانی و تیکت‌ها" />

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', gap: 12, marginBottom: 18 }}>
          <div>
            <h1 style={{ fontSize: 20, fontWeight: 800, margin: 0, marginBottom: 6 }}>{ticket.subject}</h1>
            <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
              <span style={statusTagStyle(ticket.status)}>{translateStatus(ticket.status)}</span>
              <span style={{ fontSize: 11.5, color: '#9199a3', fontFamily: 'monospace' }}>#{ticket.id.slice(0, 8)}</span>
              <span style={{ fontSize: 11.5, color: '#9199a3' }}>
                ثبت: {new Date(ticket.createdAt).toLocaleDateString('fa-IR')}
              </span>
            </div>
          </div>
          <a href="/admin-support" style={backBtnStyle}>→ بازگشت به لیست</a>
        </div>

        {/* ── اطلاعات کاربر ── */}
        <div style={{ ...cardStyle, marginBottom: 14 }}>
          <b style={{ fontSize: 13.5, display: 'block', marginBottom: 10 }}>ثبت‌کننده</b>
          <div style={{ display: 'flex', gap: 24, flexWrap: 'wrap', fontSize: 12.5, color: '#4f5560' }}>
            <span>شرکت: <b style={{ color: '#1b1e24' }}>{ticket.user.companyName || '—'}</b></span>
            <span>موبایل: <b style={{ direction: 'ltr', fontFamily: 'monospace', color: '#1b1e24' }}>{ticket.user.phone || '—'}</b></span>
            {ticket.user.email && (
              <span>ایمیل: <b style={{ direction: 'ltr', fontFamily: 'monospace', color: '#1b1e24' }}>{ticket.user.email}</b></span>
            )}
            {answeredBy && (
              <span>آخرین پیگیری: <b style={{ color: '#146c3a' }}>{answeredBy.companyName || answeredBy.username}</b></span>
            )}
          </div>
        </div>

        {/* ── تایم‌لاین گفتگو ── */}
        <div style={cardStyle}>
          <b style={{ fontSize: 13.5, display: 'block', marginBottom: 12 }}>گفتگو</b>
          {ticket.messages.length === 0 ? (
            <div style={emptyStyle}>هنوز پیامی ثبت نشده.</div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {ticket.messages.map((m) => {
                const isUser = m.senderType === 'user'
                return (
                  <div
                    key={m.id}
                    style={{
                      alignSelf: isUser ? 'flex-start' : 'flex-end',
                      maxWidth: '85%',
                      background: isUser ? '#fff4ee' : '#eef4fd',
                      border: '1px solid',
                      borderColor: isUser ? '#fbd9c4' : '#d3e2fb',
                      borderRadius: 12,
                      padding: '11px 14px',
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, marginBottom: 5 }}>
                      <span style={{ fontSize: 10.5, fontWeight: 700, color: isUser ? '#b2500b' : '#1e357b' }}>
                        {isUser ? 'کاربر' : 'کارشناس'}
                      </span>
                      <span style={{ fontSize: 10, color: '#9199a3', direction: 'ltr', fontFamily: 'monospace' }}>
                        {new Date(m.createdAt).toLocaleDateString('fa-IR')} {new Date(m.createdAt).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <div style={{ fontSize: 13, lineHeight: 1.8, whiteSpace: 'pre-wrap', color: '#1b1e24' }}>{m.body}</div>
                  </div>
                )
              })}
            </div>
          )}

          {/* ── فرم پاسخ کارشناس ── */}
          {canEdit ? (
            <form action={replyToTicketAction} style={{ marginTop: 18, borderTop: '1px solid #eceff3', paddingTop: 16 }}>
              <input type="hidden" name="ticketId" value={ticket.id} />
              <div style={labelStyle}>پاسخ کارشناس</div>
              <textarea name="body" rows={4} required placeholder="پاسخت رو بنویس — با ارسال، وضعیت تیکت «پاسخ‌داده‌شده» می‌شه"
                style={{ ...inputStyle, resize: 'vertical', marginBottom: 10 }} />
              <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                <button type="submit" style={submitBtnStyle}>ارسال پاسخ</button>
              </div>
            </form>
          ) : (
            <div style={{ marginTop: 18, borderTop: '1px solid #eceff3', paddingTop: 16 }}>
              <div style={noEditNoticeStyle}>برای پاسخ‌دادن، دسترسی ویرایش بخش پشتیبانی لازمه.</div>
            </div>
          )}
        </div>

        {/* ── تغییر وضعیت ── */}
        {canEdit && (
          <div style={{ ...cardStyle, marginTop: 14 }}>
            <b style={{ fontSize: 13.5, display: 'block', marginBottom: 10 }}>تغییر وضعیت</b>
            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
              {ticket.status !== 'open' && (
                <form action={updateTicketStatusAction}>
                  <input type="hidden" name="ticketId" value={ticket.id} />
                  <input type="hidden" name="status" value="open" />
                  <button type="submit" style={statusBtnStyle}>بازگرداندن به «باز»</button>
                </form>
              )}
              {ticket.status !== 'closed' && (
                <form action={updateTicketStatusAction}>
                  <input type="hidden" name="ticketId" value={ticket.id} />
                  <input type="hidden" name="status" value="closed" />
                  <ConfirmSubmitButton
                    message="این تیکت بسته بشه؟ کاربر بعد از این نمی‌تونه پیام جدید بفرسته."
                    style={{ background: 'none', border: 'none', color: '#9b1c1c', fontSize: 12.5, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit', padding: '8px 4px' }}
                  >
                    بستن تیکت
                  </ConfirmSubmitButton>
                </form>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

// ── ترجمه و رنگ وضعیت ─────────────────────────────────────────────────
function translateStatus(status: string): string {
  const map: Record<string, string> = { open: 'باز', answered: 'پاسخ‌داده‌شده', closed: 'بسته' }
  return map[status] ?? status
}

function statusTagStyle(status: string): React.CSSProperties {
  let bg = '#f1efe8'
  let color = '#4f5560'
  if (status === 'open') { bg = '#fef3c7'; color = '#92400e' }
  else if (status === 'answered') { bg = '#d1fae5'; color = '#065f46' }
  else if (status === 'closed') { bg = '#e5e7eb'; color = '#4b5563' }
  return { fontSize: 11, fontWeight: 700, background: bg, color, borderRadius: 6, padding: '4px 10px', whiteSpace: 'nowrap' }
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const cardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3', borderRadius: 12, padding: 18,
  background: '#fff', boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const backBtnStyle: React.CSSProperties = {
  background: 'none', border: '1px solid #d8dde3', borderRadius: 8,
  padding: '7px 14px', fontSize: 12, fontWeight: 600, color: '#4f5560',
  textDecoration: 'none', whiteSpace: 'nowrap',
}
const inputStyle: React.CSSProperties = {
  border: '1px solid #d8dde3', borderRadius: 8,
  padding: '9px 12px', fontSize: 13, fontFamily: 'inherit', width: '100%',
}
const labelStyle: React.CSSProperties = {
  fontSize: 12, fontWeight: 700, color: '#4f5560', marginBottom: 4,
}
const submitBtnStyle: React.CSSProperties = {
  background: '#1e357b', color: '#fff', border: 'none', borderRadius: 8,
  padding: '9px 18px', fontSize: 12.5, fontWeight: 700, cursor: 'pointer',
  fontFamily: 'inherit',
}
const statusBtnStyle: React.CSSProperties = {
  background: '#f1efe8', color: '#4f5560', border: '1px solid #d8dde3', borderRadius: 8,
  padding: '8px 16px', fontSize: 12.5, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit',
}
const emptyStyle: React.CSSProperties = {
  fontSize: 12.5, color: '#9199a3', padding: '20px 0', textAlign: 'center',
}
const noEditNoticeStyle: React.CSSProperties = {
  background: '#f1efe8', color: '#4f5560', borderRadius: 8, padding: '10px 14px',
  fontSize: 12.5, textAlign: 'center',
}
