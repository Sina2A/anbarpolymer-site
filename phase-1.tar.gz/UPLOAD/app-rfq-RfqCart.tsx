'use client'

import { useState, useTransition } from 'react'
import { submitRfq } from './actions'

interface StockItem {
  warehouseId: string
  gradeId: string
  gradeCode: string
  producer: string
  warehouseName: string
  warehouseCity: string
  availableTon: number
  priceRial: number
}

interface CartLine {
  warehouseId: string
  gradeId: string
  gradeCode: string
  warehouseLabel: string
  quantity: number
  priceRial: number
  maxTon: number
}

export default function RfqCart({ items }: { items: StockItem[] }) {
  const [cart, setCart] = useState<CartLine[]>([])
  const [isPending, startTransition] = useTransition()
  const [error, setError] = useState('')

  function addToCart(item: StockItem) {
    setCart((prev) => {
      const existing = prev.find((c) => c.warehouseId === item.warehouseId)
      if (existing) {
        // به‌جای ردیف تکراری، فقط مقدار همون ردیف رو زیاد می‌کنیم
        return prev.map((c) =>
          c.warehouseId === item.warehouseId ? { ...c, quantity: Math.min(c.quantity + 1, c.maxTon) } : c
        )
      }
      return [
        ...prev,
        {
          warehouseId: item.warehouseId,
          gradeId: item.gradeId,
          gradeCode: item.gradeCode,
          warehouseLabel: `${item.warehouseName} — ${item.warehouseCity}`,
          quantity: 1,
          priceRial: item.priceRial,
          maxTon: item.availableTon,
        },
      ]
    })
  }

  function changeQty(warehouseId: string, delta: number) {
    setCart((prev) =>
      prev
        .map((c) => (c.warehouseId === warehouseId ? { ...c, quantity: Math.max(0, Math.min(c.quantity + delta, c.maxTon)) } : c))
        .filter((c) => c.quantity > 0)
    )
  }

  function removeLine(warehouseId: string) {
    setCart((prev) => prev.filter((c) => c.warehouseId !== warehouseId))
  }

  function handleSubmit() {
    setError('')
    if (cart.length === 0) {
      setError('سبد خالیه — اول محصولی اضافه کن.')
      return
    }
    startTransition(async () => {
      try {
        await submitRfq(cart.map((c) => ({ gradeId: c.gradeId, warehouseId: c.warehouseId, quantity: c.quantity })))
      } catch (e) {
        setError(e instanceof Error ? e.message : 'خطایی پیش اومد.')
      }
    })
  }

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        {items.map((item) => (
          <div key={item.warehouseId} style={rowStyle}>
            <div>
              <b style={{ fontFamily: 'monospace' }}>{item.gradeCode}</b>
              <span style={{ fontSize: 11.5, color: '#9199a3', marginRight: 8 }}>{item.producer} — {item.warehouseName}، {item.warehouseCity}</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
              <span style={{ fontSize: 12.5, fontFamily: 'monospace', color: '#4f5560' }}>{item.priceRial.toLocaleString('en-US')} ریال/کیلوگرم</span>
              <button onClick={() => addToCart(item)} style={addBtnStyle}>+ افزودن</button>
            </div>
          </div>
        ))}
      </div>

      <div style={cartBoxStyle}>
        <h3 style={{ fontSize: 14.5, fontWeight: 800, marginBottom: 12 }}>سبد درخواست</h3>
        {cart.length === 0 && <div style={{ fontSize: 12.5, color: '#9199a3' }}>هنوز چیزی اضافه نکردی.</div>}
        {cart.map((line) => (
          <div key={line.warehouseId} style={cartLineStyle}>
            <div>
              <b style={{ fontFamily: 'monospace', fontSize: 13 }}>{line.gradeCode}</b>
              <span style={{ fontSize: 11, color: '#9199a3', marginRight: 8 }}>{line.warehouseLabel}</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <button onClick={() => changeQty(line.warehouseId, -1)} style={qtyBtnStyle}>−</button>
              <span style={{ fontFamily: 'monospace', fontSize: 13, minWidth: 24, textAlign: 'center' }}>{line.quantity}</span>
              <button onClick={() => changeQty(line.warehouseId, 1)} style={qtyBtnStyle}>+</button>
              <button onClick={() => removeLine(line.warehouseId)} style={removeBtnStyle}>✕</button>
            </div>
          </div>
        ))}

        {error && <div style={errorStyle}>{error}</div>}

        <button onClick={handleSubmit} disabled={isPending} style={submitBtnStyle(isPending)}>
          {isPending ? 'در حال ثبت...' : 'ثبت درخواست قیمت'}
        </button>
      </div>
    </div>
  )
}

const rowStyle: React.CSSProperties = { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 14px', background: '#fff', border: '1px solid #eceff3', borderRadius: 10, marginBottom: 8 }
const addBtnStyle: React.CSSProperties = { background: '#eef4fd', color: '#1e357b', border: 'none', borderRadius: 7, padding: '7px 14px', fontSize: 12, fontWeight: 700, cursor: 'pointer' }
const cartBoxStyle: React.CSSProperties = { background: '#fff', border: '1.5px solid #d8dde3', borderRadius: 14, padding: 18 }
const cartLineStyle: React.CSSProperties = { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid #f1efe8' }
const qtyBtnStyle: React.CSSProperties = { width: 26, height: 26, border: '1px solid #d8dde3', borderRadius: 6, background: '#f7f8fa', cursor: 'pointer', fontSize: 14 }
const removeBtnStyle: React.CSSProperties = { color: '#dc2626', border: 'none', background: 'none', cursor: 'pointer', fontSize: 13 }
const errorStyle: React.CSSProperties = { background: '#fee2e2', color: '#a8241a', fontSize: 12, padding: '8px 12px', borderRadius: 7, marginTop: 10 }
function submitBtnStyle(pending: boolean): React.CSSProperties {
  return { width: '100%', marginTop: 14, padding: '13px 0', background: pending ? '#9199a3' : '#f6621b', color: '#fff', border: 'none', borderRadius: 9, fontSize: 14.5, fontWeight: 800, cursor: pending ? 'default' : 'pointer' }
}