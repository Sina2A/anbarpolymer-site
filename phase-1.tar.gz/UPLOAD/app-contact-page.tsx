import CurrencyTicker from '@/components/CurrencyTicker'
import { getCurrentUserOrNull } from '@/lib/currentUser'
import { submitContactAction } from './actions'

export const dynamic = 'force-dynamic'

type SearchParams = Promise<Record<string, string | string[] | undefined>>

function one(v: string | string[] | undefined): string | undefined {
  if (Array.isArray(v)) return v[0]
  return v
}

export default async function ContactPage({ searchParams }: { searchParams: SearchParams }) {
  const sp = await searchParams
  const justSent = one(sp.sent) === '1'
  const user = await getCurrentUserOrNull()

  return (
    <>
      <CurrencyTicker />
      <div className="topbar">
        <div className="wrap">
          <span>پشتیبانی فروش شنبه تا چهارشنبه ۸:۳۰ تا ۱۷:۳۰</span>
          <a className="phone" href="tel:+982191234567">
            021-91234567
          </a>
        </div>
      </div>
      <header className="site-header">
        <div className="wrap">
          <a href="/" className="logo">
            <span className="dot"></span> انبار پلیمر
          </a>
          <nav className="main-nav">
            <a href="/">صفحه اصلی</a>
            <a href="/grades">گریدها</a>
            <a href="/rfq">استعلام قیمت</a>
            <a href="/market">بازار صنعتی</a>
            <a href="/reports">گزارش بازار</a>
            <a href="/services">خدمات سازمانی</a>
            <a href="/about">درباره ما</a>
            <a href="/contact" className="active">
              تماس با ما
            </a>
          </nav>
          <div className="header-actions">
            {user ? (
              <a href="/dashboard" className="acct-btn">
                پیشخوان
              </a>
            ) : (
              <a href="/login" className="acct-btn">
                ورود / ثبت‌نام
              </a>
            )}
          </div>
        </div>
      </header>

      <section style={sectionStyle}>
        <div className="wrap">
          <div className="eyebrow">ارتباط با ما</div>
          <div className="sec-title">تماس با ما</div>
          <div className="sec-sub" style={{ marginBottom: 22 }}>
            سوالی درباره‌ی مواد اولیه، قیمت یا همکاری داری؟ فرم زیر رو پر کن — همکاران ما پیامت رو می‌بینن و از راهی که گذاشتی جواب می‌دن.
          </div>

          {justSent && (
            <div style={successBanner}>
              ✅ پیامت رسید. ممنون! در صورت نیاز از راهی که گذاشتی باهات تماس می‌گیریم.
            </div>
          )}

          <section style={formCardStyle}>
            <form action={submitContactAction}>
              <div style={{ marginBottom: 14 }}>
                <div style={labelStyle}>نام و نام خانوادگی</div>
                <input name="name" required maxLength={80} placeholder="مثلاً: علی رضایی"
                  style={inputStyle} />
              </div>
              <div style={{ marginBottom: 14 }}>
                <div style={labelStyle}>راه تماس <span style={hintInline}>(ایمیل یا شماره موبایل)</span></div>
                <input name="contact" required maxLength={120} placeholder="example@mail.com یا 09121234567"
                  style={{ ...inputStyle, direction: 'ltr', textAlign: 'left' }} />
              </div>
              <div style={{ marginBottom: 16 }}>
                <div style={labelStyle}>متن پیام</div>
                <textarea name="body" rows={6} required maxLength={2000} placeholder="سوال یا پیامت رو اینجا بنویس…"
                  style={{ ...inputStyle, resize: 'vertical' }} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
                <span style={hintStyle}>نیازی به ثبت‌نام نیست — پیامت مستقیم به تیم ما می‌رسه.</span>
                <button type="submit" style={submitBtnStyle}>ارسال پیام</button>
              </div>
            </form>
          </section>
        </div>
      </section>

      <footer className="site-footer">
        <div className="wrap">
          <div className="footer-cols">
            <div>
              <a href="/" className="logo" style={{ marginBottom: 14, display: 'flex' }}>
                <span className="dot"></span> انبار پلیمر
              </a>
              <p style={{ color: 'var(--ink-dim)', fontSize: 13, maxWidth: 280 }}>
                واردکننده و فروشنده مستقیم مواد اولیه پلیمری برای کارخانه‌های تولیدی سراسر کشور.
              </p>
            </div>
            <div>
              <h5>محصولات</h5>
              <ul>
                <li>
                  <a href="/grades">پلی‌پروپیلن</a>
                </li>
                <li>
                  <a href="/grades">پلی‌اتیلن</a>
                </li>
                <li>
                  <a href="/grades">پی‌وی‌سی</a>
                </li>
                <li>
                  <a href="/grades">پلی‌اتیلن ترفتالات</a>
                </li>
              </ul>
            </div>
            <div>
              <h5>خدمات</h5>
              <ul>
                <li>
                  <a href="/rfq">استعلام قیمت آنلاین</a>
                </li>
                <li>
                  <a href="/market">بازار صنعتی</a>
                </li>
                <li>
                  <a href="/services">فروش سازمانی</a>
                </li>
                <li>
                  <a href="/reports">گزارش بازار</a>
                </li>
              </ul>
            </div>
            <div>
              <h5>اطلاعات تماس</h5>
              <ul>
                <li>تهران، خیابان ولیعصر، پلاک ۱۲۴</li>
                <li>انبار یزد — شهرک صنعتی یزد</li>
                <li style={{ direction: 'ltr', textAlign: 'right' }}>021-91234567</li>
              </ul>
            </div>
          </div>
          <div className="footer-bottom">
            <span>انبار پلیمر © ۱۴۰۵ — تمام حقوق محفوظ است</span>
          </div>
        </div>
      </footer>
    </>
  )
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const sectionStyle: React.CSSProperties = { padding: '48px 0' }
const successBanner: React.CSSProperties = {
  background: '#eaf3de',
  color: '#146c3a',
  borderRadius: 10,
  padding: '12px 16px',
  fontSize: 13,
  fontWeight: 600,
  marginBottom: 18,
  border: '1px solid #cfe3bd',
}
const formCardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 24,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
  maxWidth: 640,
}
const labelStyle: React.CSSProperties = {
  fontSize: 12.5,
  fontWeight: 700,
  color: '#4f5560',
  marginBottom: 5,
}
const hintInline: React.CSSProperties = {
  fontWeight: 400,
  color: '#9199a3',
  fontSize: 11,
}
const inputStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 8,
  padding: '10px 12px',
  fontSize: 13,
  fontFamily: 'inherit',
  width: '100%',
  boxSizing: 'border-box',
}
const hintStyle: React.CSSProperties = {
  fontSize: 11.5,
  color: '#9199a3',
}
const submitBtnStyle: React.CSSProperties = {
  background: '#1e357b',
  color: '#fff',
  border: 'none',
  borderRadius: 8,
  padding: '10px 28px',
  fontSize: 13.5,
  fontWeight: 700,
  cursor: 'pointer',
  fontFamily: 'inherit',
}
