import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import UserNav from '@/components/UserNav'
import RfqCart from './RfqCart'

export const dynamic = 'force-dynamic'

export default async function RfqPage() {
  const user = await getCurrentUser()

  // فقط اقلامی که موجودی فعلی‌شون > 0 هست (انبارهایی که واقعاً چیزی دارن)
  const stocks = await prisma.warehouseStock.findMany({
    where: { quantityTon: { gt: 0 } },
    include: { grade: true, warehouse: true },
    orderBy: { createdAt: 'desc' },
  })

  const items = stocks.map((s) => ({
    warehouseId: s.warehouseId,
    gradeId: s.gradeId,
    gradeCode: s.grade.code,
    producer: s.grade.producer,
    warehouseName: s.warehouse.name,
    warehouseCity: s.warehouse.city,
    availableTon: s.quantityTon,
    priceRial: s.priceRial,
  }))

  return (
    <div style={pageStyle}>
      <div style={wrapStyle}>
        <UserNav currentUserName={user.companyName} activeSection="rfq" />

        <div style={{ flex: 1, minWidth: 0 }}>
          <h1 style={titleStyle}>درخواست خرید از انبار (سبد چندمحصولی)</h1>
          <p style={subStyle}>
            موجودی زنده‌ی انبارها رو ببین، اقلام مورد نظرت رو به سبد اضافه کن،
            و در نهایت یک درخواست خرید واحد (Order) با چند ردیف ثبت کن.
          </p>

          {items.length === 0 ? (
            <div style={emptyStyle}>فعلاً هیچ موجودی فعالی توی انبارها ثبت نشده.</div>
          ) : (
            <RfqCart items={items} />
          )}
        </div>
      </div>
    </div>
  )
}

const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: '#faf8f4',
  padding: '32px 24px',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const wrapStyle: React.CSSProperties = {
  maxWidth: 1100,
  margin: '0 auto',
  display: 'flex',
  gap: 24,
}
const titleStyle: React.CSSProperties = {
  fontSize: 22,
  fontWeight: 800,
  marginBottom: 8,
}
const subStyle: React.CSSProperties = {
  color: '#6f7680',
  fontSize: 13.5,
  marginBottom: 22,
  lineHeight: 1.9,
}
const emptyStyle: React.CSSProperties = {
  padding: 32,
  textAlign: 'center',
  color: '#9199a3',
  border: '1px dashed #d8dde3',
  borderRadius: 12,
}