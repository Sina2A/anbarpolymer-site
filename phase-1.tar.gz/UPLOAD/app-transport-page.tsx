import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import UserNav from '@/components/UserNav'
import TransportMap from '@/components/TransportMap'

export const dynamic = 'force-dynamic'

export default async function TransportPage() {
  const user = await getCurrentUser()

  // Deal های in_transit که کاربر خریدار یا فروشنده‌ست
  const activeDeals = await prisma.deal.findMany({
    where: {
      status: 'in_transit',
      OR: [
        { buyerId: user.id },
        { materialListing: { userId: user.id } },
      ],
    },
    include: {
      materialListing: {
        include: { grade: true },
      },
      confirmations: {
        where: { type: 'loading' },
        take: 1,
        orderBy: { confirmedAt: 'desc' },
      },
    },
  })

  const hasActiveDeals = activeDeals.length > 0

  return (
    <div style={pageStyle}>
      <div style={{ maxWidth: 1100, margin: '0 auto', display: 'flex', gap: 24 }} className="admin-page-wrap">
        <UserNav currentUserName={user.companyName} activeSection="transport" />
        <div style={{ flex: 1, minWidth: 0 }}>
          <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>حمل و نقل</h1>
          <p style={{ fontSize: 13, color: '#9199a3', marginBottom: 20 }}>
            ردیابی زنده محموله‌های در حال حمل
          </p>

          {!hasActiveDeals ? (
            <div style={emptyStateStyle}>
              <div style={{ position: 'relative', width: '100%', height: 400, borderRadius: 12, overflow: 'hidden' }}>
                <div style={{ filter: 'blur(8px)', width: '100%', height: '100%', background: '#e5e7eb' }} />
                <div style={overlayTextStyle}>
                  <div style={{ fontSize: 18, fontWeight: 700, color: '#1a1a2e', marginBottom: 8 }}>
                    صفحه‌ی لایو لجستیک
                  </div>
                  <div style={{ fontSize: 14, color: '#4f5560', lineHeight: 1.6 }}>
                    به شما اطلاعات از وضعیت بار و ماشین حمل را ارائه می‌دهد.
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <TransportMap deals={activeDeals} />
          )}
        </div>
      </div>
    </div>
  )
}

const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: '#faf8f4',
  padding: '32px 20px',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const emptyStateStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
  overflow: 'hidden',
}
const overlayTextStyle: React.CSSProperties = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  textAlign: 'center',
  padding: '24px 32px',
  background: 'rgba(255,255,255,0.95)',
  borderRadius: 12,
  boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
}
