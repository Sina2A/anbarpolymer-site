import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import UserNav from '@/components/UserNav'
import { notFound } from 'next/navigation'
import { addUserMessageAction } from '../actions'

export const dynamic = 'force-dynamic'

type Props = { params: Promise<{ id: string }> }

export default async function SupportTicketPage({ params }: Props) {
  const { id } = await params
  const user = await getCurrentUser()

  const ticket = await prisma.supportTicket.findUnique({
    where: { id },
    include: { messages: { orderBy: { createdAt: 'asc' } } },
  })

  // فقط صاحب تیکت اجازه‌ی دیدن داره — در غیر این صورت انگار وجود نداره
  if (!ticket || ticket.userId !== user.id) notFound()

  const isClosed = ticket.status === 'closed'

  return (
    <div style={{ display: 'flex', gap: 24, padding: '32px 24px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', maxWidth: 1100, margin: '0 auto' }}>
      <UserNav activeSection="support" />

      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', gap: 12, marginBottom: 18 }}>
          <div>
            <h1 style={{ fontSize: 20, fontWeight: 800, margin: 0, marginBottom: 6 }}>{ticket.subject}</h1>
            <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
              <span style={statusTagStyle(ticket.status)}>{translateStatus(ticket.status)}</span>
              <span style={{ fontSize: 11.5, color: '#9199a3' }}>
                ثبت: {new Date(ticket.createdAt).toLocaleDateString('fa-IR')}
              </span>
            </div>
          </div>
          <a href="/support" style={backBtnStyle}>→ تیکت‌های من</a>
        </div>

        {/* ── تایم‌لاین گفتگو ── */}
        <div style={cardStyle}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {ticket.messages.map((m) => {
              const isMine = m.senderType === 'user'
              return (
                <div
                  key={m.id}
                  style={{
                    alignSelf: isMine ? 'flex-start' : 'flex-end',
                    maxWidth: '85%',
                    background: isMine ? '#fff4ee' : '#eef4fd',
                    border: '1px solid',
                    borderColor: isMine ? '#fbd9c4' : '#d3e2fb',
                    borderRadius: 12,
                    padding: '11px 14px',
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, marginBottom: 5 }}>
                    <span style={{ fontSize: 10.5, fontWeight: 700, color: isMine ? '#b2500b' : '#1e357b' }}>
                      {isMine ? 'شما' : 'کارشناس پشتیبانی'}
                    </span>
                    <span style={{ fontSize: 10, color: '#9199a3', direction: 'ltr', fontFamily: 'monospace' }}>
                      {new Date(m.createdAt).toLocaleDateString('fa-IR')} {new Date(m.createdAt).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <div style={{ fontSize: 13, lineHeight: 1.8, whiteSpace: 'pre-wrap', color: '#1b1e24' }}>{m.body}</div>
                </div>
              )
            })}
          </div>

          {/* ── فرم پاسخ کاربر ── */}
          {isClosed ? (
            <div style={{ marginTop: 18, borderTop: '1px solid #eceff3', paddingTop: 16 }}>
              <div style={closedNoticeStyle}>این تیکت بسته شده. برای موضوع جدید، یک تیکت تازه ثبت کن.</div>
            </div>
          ) : (
            <form action={addUserMessageAction} style={{ marginTop: 18, borderTop: '1px solid #eceff3', paddingTop: 16 }}>
              <input type="hidden" name="ticketId" value={ticket.id} />
              <div style={labelStyle}>پاسخ شما</div>
              <textarea name="body" rows={4} required placeholder="پیامت رو بنویس…"
                style={{ ...inputStyle, resize: 'vertical', marginBottom: 10 }} />
              <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                <button type="submit" style={submitBtnStyle}>ارسال پیام</button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  )
}

// ── ترجمه و رنگ وضعیت ─────────────────────────────────────────────────
function translateStatus(status: string): string {
  const map: Record<string, string> = { open: 'باز', answered: 'پاسخ‌داده‌شده', closed: 'بسته' }
  return map[status] ?? status
}

function statusTagStyle(status: string): React.CSSProperties {
  let bg = '#f1efe8'
  let color = '#4f5560'
  if (status === 'open') { bg = '#fef3c7'; color = '#92400e' }
  else if (status === 'answered') { bg = '#d1fae5'; color = '#065f46' }
  else if (status === 'closed') { bg = '#e5e7eb'; color = '#4b5563' }
  return { fontSize: 11, fontWeight: 700, background: bg, color, borderRadius: 6, padding: '4px 10px', whiteSpace: 'nowrap' }
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const cardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3', borderRadius: 12, padding: 18,
  background: '#fff', boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const backBtnStyle: React.CSSProperties = {
  background: 'none', border: '1px solid #d8dde3', borderRadius: 8,
  padding: '7px 14px', fontSize: 12, fontWeight: 600, color: '#4f5560',
  textDecoration: 'none', whiteSpace: 'nowrap',
}
const inputStyle: React.CSSProperties = {
  border: '1px solid #d8dde3', borderRadius: 8,
  padding: '9px 12px', fontSize: 13, fontFamily: 'inherit', width: '100%',
}
const labelStyle: React.CSSProperties = {
  fontSize: 12, fontWeight: 700, color: '#4f5560', marginBottom: 4,
}
const submitBtnStyle: React.CSSProperties = {
  background: '#1e357b', color: '#fff', border: 'none', borderRadius: 8,
  padding: '9px 18px', fontSize: 12.5, fontWeight: 700, cursor: 'pointer',
  fontFamily: 'inherit',
}
const closedNoticeStyle: React.CSSProperties = {
  background: '#e5e7eb', color: '#4b5563', borderRadius: 8, padding: '10px 14px',
  fontSize: 12.5, textAlign: 'center',
}
