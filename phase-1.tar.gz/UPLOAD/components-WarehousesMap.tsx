'use client'

import { useEffect, useState } from 'react'
import dynamic from 'next/dynamic'

// Leaflet فقط در کلاینت کار می‌کنه — SSR ندارد
const MapContainer = dynamic(() => import('react-leaflet').then((m) => m.MapContainer), { ssr: false })
const TileLayer = dynamic(() => import('react-leaflet').then((m) => m.TileLayer), { ssr: false })
const Marker = dynamic(() => import('react-leaflet').then((m) => m.Marker), { ssr: false })
const Popup = dynamic(() => import('react-leaflet').then((m) => m.Popup), { ssr: false })

type Warehouse = {
  id: string
  name: string
  city: string
  latitude: number | null
  longitude: number | null
  address: string | null
  description: string | null
}

export default function WarehousesMap({ warehouses }: { warehouses: Warehouse[] }) {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return <div style={loadingStyle}>در حال بارگذاری نقشه...</div>
  }

  // فیلتر انبارهایی که مختصات دارن
  const withLocation = warehouses.filter((w) => w.latitude && w.longitude)

  if (withLocation.length === 0) {
    return (
      <div style={emptyStyle}>
        هیچ انباری با موقعیت جغرافیایی ثبت‌شده وجود ندارد.
      </div>
    )
  }

  // مرکز نقشه — میانگین مختصات
  const centerLat = withLocation.reduce((sum, w) => sum + (w.latitude ?? 0), 0) / withLocation.length
  const centerLng = withLocation.reduce((sum, w) => sum + (w.longitude ?? 0), 0) / withLocation.length

  return (
    <div style={mapWrapStyle}>
      <MapContainer
        center={[centerLat, centerLng]}
        zoom={withLocation.length === 1 ? 11 : 6}
        style={{ height: '100%', width: '100%' }}
        scrollWheelZoom={false}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {withLocation.map((w) => (
          <Marker key={w.id} position={[w.latitude as number, w.longitude as number]}>
            <Popup>
              <div style={{ direction: 'rtl', fontFamily: "'Vazirmatn', Tahoma, sans-serif", minWidth: 160 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: '#1e357b', marginBottom: 4 }}>{w.name}</div>
                <div style={{ fontSize: 12, color: '#4f5560', marginBottom: 2 }}>{w.city}</div>
                {w.address && <div style={{ fontSize: 11, color: '#6f7680' }}>{w.address}</div>}
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  )
}
// ── استایلها ─────────────────────────────────────────────────────────
const mapWrapStyle: React.CSSProperties = {
  height: 420,
  borderRadius: 12,
  overflow: 'hidden',
  border: '1px solid #d8dde3',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const loadingStyle: React.CSSProperties = {
  height: 420,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: 13,
  color: '#6f7680',
  border: '1px solid #d8dde3',
  borderRadius: 12,
  background: '#fff',
}
const emptyStyle: React.CSSProperties = {
  padding: '40px 20px',
  textAlign: 'center',
  fontSize: 13,
  color: '#6b7280',
  border: '1px solid #d8dde3',
  borderRadius: 12,
  background: '#fff',
}

