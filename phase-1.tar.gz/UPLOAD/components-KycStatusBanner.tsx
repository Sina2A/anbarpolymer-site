'use client'

type Props = { level: number }

/**
 * بنر همیشه‌دیده‌ی وضعیت احراز هویت — قبلاً داخل my-orders/page.tsx تعریف شده بود.
 * اینجا منتقل شد تا هم /dashboard و هم /my-orders از یک منبع استفاده کنند.
 * level >= 2 (تولیدکننده‌ی تاییدشده) → null، نیازی به یادآوری نیست.
 */
export default function KycStatusBanner({ level }: Props) {
  if (level >= 2) return null

  const config =
    level === 1
      ? {
          bg: '#eaf3de',
          color: '#27500a',
          icon: '✓',
          text: 'هویت شرکتت تایید شده — اگه می‌خوای توی سایت بار هم بفروشی، احراز تولیدکننده رو تکمیل کن.',
        }
      : {
          bg: '#fef3c7',
          color: '#92400e',
          icon: '⚠',
          text: 'هنوز احراز هویتت رو تکمیل نکردی — بدون این، قیمت دقیق نمی‌بینی و نمی‌تونی استعلام بفرستی.',
        }

  return (
    <a
      href="/verification"
      style={{
        display: 'block',
        background: config.bg,
        color: config.color,
        borderRadius: 10,
        padding: '12px 16px',
        fontSize: 13,
        fontWeight: 600,
        marginBottom: 20,
        textDecoration: 'none',
      }}
    >
      {config.icon} {config.text}{' '}
      <span style={{ textDecoration: 'underline', fontWeight: 800 }}>تکمیل احراز هویت ←</span>
    </a>
  )
}
