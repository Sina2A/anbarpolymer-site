// src/lib/styles/shared.ts
//
// استایل‌های مشترک و قابل‌استفاده‌ی مجدد — همه‌ی صفحات باید از همینا import کنن
// به‌جای تعریف دوباره‌ی cardStyle/tableStyle/... توی هر فایل.
// الهام از Stripe Dashboard: جدول‌محور، خط جداکننده‌ی کم‌رنگ (نه خط دور کامل),
// رنگ فقط برای وضعیت/اکشن.

import { colors, spacing, radius, fontSize } from './tokens'
import type { CSSProperties } from 'react'

// ──────────────────────────────────────────────────────────
// چیدمان صفحه
// ──────────────────────────────────────────────────────────
export const pageStyle: CSSProperties = {
  minHeight: '100vh',
  background: colors.bgPage,
  padding: `${spacing.xxl}px ${spacing.xl}px`,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}

export const pageWrapStyle: CSSProperties = {
  maxWidth: 1200,
  margin: '0 auto',
  display: 'flex',
  gap: spacing.xl,
}

export const contentStyle: CSSProperties = {
  flex: 1,
  minWidth: 0,
}

// ──────────────────────────────────────────────────────────
// عنوان صفحه
// ──────────────────────────────────────────────────────────
export const h1Style: CSSProperties = {
  fontSize: fontSize.xxl,
  fontWeight: 700,
  color: colors.textPrimary,
  margin: 0,
  marginBottom: spacing.xs,
}

export const subTitleStyle: CSSProperties = {
  fontSize: fontSize.base,
  color: colors.textSecondary,
  margin: 0,
  marginBottom: spacing.lg,
}

// ──────────────────────────────────────────────────────────
// کارت
// ──────────────────────────────────────────────────────────
export const cardStyle: CSSProperties = {
  background: colors.bgCard,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
  padding: spacing.xl,
  marginBottom: spacing.lg,
}

export const cardHeaderStyle: CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: spacing.md,
}

export const cardTitleStyle: CSSProperties = {
  fontSize: fontSize.md,
  fontWeight: 700,
  color: colors.textPrimary,
  margin: 0,
}

// ──────────────────────────────────────────────────────────
// جدول — محور اصلی سبک Stripe: بدون خط دور، فقط جداکننده‌ی ردیف
// ──────────────────────────────────────────────────────────
export const tableStyle: CSSProperties = {
  width: '100%',
  borderCollapse: 'collapse',
  fontSize: fontSize.base,
}

export const theadRowStyle: CSSProperties = {
  borderBottom: `1px solid ${colors.borderSubtle}`,
}

export const thStyle: CSSProperties = {
  padding: `${spacing.sm}px ${spacing.md}px`,
  textAlign: 'right',
  fontSize: fontSize.xs,
  fontWeight: 600,
  color: colors.textMuted,
  textTransform: 'none',
}

export const tdStyle: CSSProperties = {
  padding: `${spacing.sm}px ${spacing.md}px`,
  textAlign: 'right',
  color: colors.textPrimary,
  borderBottom: `1px solid ${colors.borderSubtle}`,
}

export const trHoverClass = 'stripe-row-hover' // کلاس CSS برای هاور (توی globals.css اضافه می‌شه)

// ──────────────────────────────────────────────────────────
// بج وضعیت — بیضی کوچیک، نه جعبه‌ی بزرگ
// ──────────────────────────────────────────────────────────
export function badgeStyle(kind: 'success' | 'warning' | 'danger' | 'info' | 'neutral'): CSSProperties {
  const map = {
    success: { bg: colors.successBg, text: colors.successText },
    warning: { bg: colors.warningBg, text: colors.warningText },
    danger: { bg: colors.dangerBg, text: colors.dangerText },
    info: { bg: colors.infoBg, text: colors.infoText },
    neutral: { bg: colors.neutralBg, text: colors.neutralText },
  }
  const c = map[kind]
  return {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 4,
    fontSize: fontSize.xs,
    fontWeight: 600,
    background: c.bg,
    color: c.text,
    borderRadius: 999,
    padding: '3px 10px',
  }
}

// ──────────────────────────────────────────────────────────
// دکمه‌ها
// ──────────────────────────────────────────────────────────
export const btnPrimaryStyle: CSSProperties = {
  background: colors.navy,
  color: '#fff',
  border: 'none',
  borderRadius: radius.sm,
  padding: '8px 16px',
  fontSize: fontSize.sm,
  fontWeight: 600,
  cursor: 'pointer',
  fontFamily: 'inherit',
}

export const btnSecondaryStyle: CSSProperties = {
  background: colors.bgCard,
  color: colors.textPrimary,
  border: `1px solid ${colors.borderStrong}`,
  borderRadius: radius.sm,
  padding: '8px 16px',
  fontSize: fontSize.sm,
  fontWeight: 600,
  cursor: 'pointer',
  fontFamily: 'inherit',
}

export const btnDangerStyle: CSSProperties = {
  ...btnSecondaryStyle,
  color: colors.dangerText,
  borderColor: colors.dangerBg,
}

export const btnSmallStyle: CSSProperties = {
  padding: '5px 12px',
  fontSize: fontSize.xs,
}

// ──────────────────────────────────────────────────────────
// ورودی‌ها
// ──────────────────────────────────────────────────────────
export const inputStyle: CSSProperties = {
  border: `1px solid ${colors.borderStrong}`,
  borderRadius: radius.sm,
  padding: '9px 12px',
  fontSize: fontSize.base,
  fontFamily: 'inherit',
  width: '100%',
  color: colors.textPrimary,
  background: colors.bgCard,
}

export const selectStyle: CSSProperties = { ...inputStyle }

export const labelStyle: CSSProperties = {
  fontSize: fontSize.xs,
  fontWeight: 600,
  color: colors.textSecondary,
  marginBottom: 4,
  display: 'block',
}

// ──────────────────────────────────────────────────────────
// حالت خالی
// ──────────────────────────────────────────────────────────
export const emptyStateStyle: CSSProperties = {
  fontSize: fontSize.sm,
  color: colors.textMuted,
  padding: '32px 0',
  textAlign: 'center',
}

// ──────────────────────────────────────────────────────────
// نوار کناری (سایدبار) — پایه‌ی مشترک AdminNav/UserNav
// ──────────────────────────────────────────────────────────
export const sidebarStyle: CSSProperties = {
  width: 260,
  flexShrink: 0,
  background: colors.bgCard,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
  padding: spacing.md,
  height: 'fit-content',
}

export const sidebarGroupTitleStyle: CSSProperties = {
  fontSize: 11,
  fontWeight: 700,
  color: colors.textMuted,
  textTransform: 'uppercase',
  letterSpacing: '0.03em',
  margin: `${spacing.md}px ${spacing.sm}px ${spacing.xs}px`,
}

export function sidebarItemStyle(active: boolean): CSSProperties {
  return {
    display: 'flex',
    alignItems: 'center',
    gap: spacing.sm,
    padding: '9px 12px',
    borderRadius: radius.sm,
    fontSize: fontSize.sm,
    fontWeight: active ? 600 : 500,
    color: active ? colors.navy : colors.textPrimary,
    background: active ? colors.bgActiveTint : 'transparent',
    textDecoration: 'none',
    cursor: 'pointer',
  }
}

export const sidebarComingSoonBadgeStyle: CSSProperties = {
  fontSize: 10,
  fontWeight: 600,
  color: colors.textMuted,
  background: colors.neutralBg,
  borderRadius: 999,
  padding: '2px 8px',
  marginRight: 'auto',
}

// ──────────────────────────────────────────────────────────
// هدر عمومی (صفحات مهمان — market/grades/warehouses/...)
// ──────────────────────────────────────────────────────────
export const publicHeaderStyle: CSSProperties = {
  background: colors.bgCard,
  borderBottom: `1px solid ${colors.borderSubtle}`,
  padding: '14px 24px',
}

export const publicHeaderInnerStyle: CSSProperties = {
  maxWidth: 1200,
  margin: '0 auto',
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
}

export const publicNavLinkStyle: CSSProperties = {
  fontSize: fontSize.sm,
  fontWeight: 500,
  color: colors.textSecondary,
  textDecoration: 'none',
  padding: '6px 10px',
  borderRadius: radius.sm,
}

export const publicBrandStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: spacing.xs,
  fontSize: fontSize.md,
  fontWeight: 700,
  color: colors.textPrimary,
  textDecoration: 'none',
}
