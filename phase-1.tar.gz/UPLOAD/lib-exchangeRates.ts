/**
 * ExchangeRate read helper — display-only.
 *
 * Returns the latest scraped rate per currency from the ExchangeRate table.
 * This module intentionally has ZERO imports from pricing.ts / PriceRecord —
 * the ticker is a standalone display widget with no connection to the
 * product-pricing / benchmark engine (which is deliberately halted).
 */

import prisma from '@/lib/prisma'

export type LatestRate = {
  currency: string
  rateToToman: number
  source: string
  scrapedAt: Date
}

/**
 * Get the most recent rate for each requested currency.
 * Returns an array sorted by currency code (ascending).
 * If a currency has never been scraped, it is simply absent from the result.
 */
export async function getLatestRates(
  currencies: string[] = ['USD', 'EUR'],
): Promise<LatestRate[]> {
  const results: LatestRate[] = []

  for (const cur of currencies) {
    const row = await prisma.exchangeRate.findFirst({
      where: { currency: cur },
      orderBy: { scrapedAt: 'desc' },
      select: { currency: true, rateToToman: true, source: true, scrapedAt: true },
    })
    if (row) results.push(row)
  }

  return results.sort((a, b) => a.currency.localeCompare(b.currency))
}

/** How many minutes ago a rate was scraped — used by the ticker for freshness badge. */
export function minutesAgo(dt: Date): number {
  return Math.round((Date.now() - dt.getTime()) / 60_000)
}
