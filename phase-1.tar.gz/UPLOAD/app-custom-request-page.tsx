import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import UserNav from '@/components/UserNav'
import { submitCustomRfqAction } from './actions'

export const dynamic = 'force-dynamic'

type SearchParams = Promise<Record<string, string | string[] | undefined>>

function one(v: string | string[] | undefined): string | undefined {
  if (Array.isArray(v)) return v[0]
  return v
}

export default async function CustomRequestPage({ searchParams }: { searchParams: SearchParams }) {
  const user = await getCurrentUser()
  const sp = await searchParams
  const suggestedGrade = one(sp.grade) // از query param ?grade=CODE (دکمه‌ی grades/[code])

  // لیست درخواست‌های قبلی خودِ کاربر
  const myRfqs = await prisma.customRfq.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    take: 20,
  })

  return (
    <div style={pageStyle}>
      <div style={wrapStyle}>
        <UserNav currentUserName={user.companyName} activeSection="custom-request" />

        <div style={{ flex: 1, minWidth: 0 }}>
          <h1 style={titleStyle}>درخواست محصول غیرکاتالوگی (استعلام سفارشی)</h1>
          <p style={subStyle}>
            محصولی که می‌خوای توی کاتالوگ نیست؟ مشخصات فنی دقیقش رو نداری؟ اینجا بنویس —
            کارشناس ما بررسی می‌کنه و قیمت پیشنهادی می‌ده.
          </p>

          {/* ── فرم درخواست جدید ── */}
          <div style={cardStyle}>
            <b style={{ fontSize: 14, display: 'block', marginBottom: 14 }}>ثبت درخواست جدید</b>
            <form action={submitCustomRfqAction}>
              <div style={{ marginBottom: 12 }}>
                <div style={labelStyle}>نوع پلیمر</div>
                <select name="polymerType" required style={inputStyle}>
                  <option value="">انتخاب کنید</option>
                  <option value="PP">پلی‌پروپیلن (PP)</option>
                  <option value="PE">پلی‌اتیلن (PE)</option>
                  <option value="PVC">پی‌وی‌سی (PVC)</option>
                  <option value="PET">پلی‌اتیلن ترفتالات (PET)</option>
                  <option value="PS">پلی‌استایرن (PS)</option>
                  <option value="ABS">ABS</option>
                  <option value="other">سایر</option>
                </select>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
                <div>
                  <div style={labelStyle}>MFI حداقل (اختیاری)</div>
                  <input name="mfiRangeMin" type="number" step="0.1" placeholder="مثلاً ۲" style={inputStyle} />
                </div>
                <div>
                  <div style={labelStyle}>MFI حداکثر (اختیاری)</div>
                  <input name="mfiRangeMax" type="number" step="0.1" placeholder="مثلاً ۸" style={inputStyle} />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
                <div>
                  <div style={labelStyle}>چگالی حداقل (اختیاری)</div>
                  <input name="densityMin" type="number" step="0.001" placeholder="مثلاً ۰.۹۰" style={inputStyle} />
                </div>
                <div>
                  <div style={labelStyle}>چگالی حداکثر (اختیاری)</div>
                  <input name="densityMax" type="number" step="0.001" placeholder="مثلاً ۰.۹۲" style={inputStyle} />
                </div>
              </div>

              <div style={{ marginBottom: 12 }}>
                <div style={labelStyle}>مقدار درخواستی (تن)</div>
                <input name="quantityTon" type="number" step="0.1" min="0.1" required placeholder="مثلاً ۲۵" style={inputStyle} />
              </div>

              <div style={{ marginBottom: 14 }}>
                <div style={labelStyle}>الزامات خاص (اختیاری)</div>
                <textarea
                  name="requirements"
                  rows={4}
                  placeholder="مثلاً: باید FDA approved باشه، رنگ سفید شیری، برای تزریق..."
                  style={{ ...inputStyle, resize: 'vertical' }}
                />
              </div>

              {suggestedGrade && <input type="hidden" name="suggestedGradeCode" value={suggestedGrade} />}

              {suggestedGrade && (
                <div style={infoBannerStyle}>
                  💡 این درخواست از صفحه‌ی گرید <b>{suggestedGrade}</b> شروع شده — کارشناس گریدهای مشابه رو بررسی می‌کنه.
                </div>
              )}

              <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                <button type="submit" style={submitBtnStyle}>ارسال درخواست</button>
              </div>
            </form>
          </div>

          {/* ── لیست درخواست‌های قبلی ── */}
          <h2 style={{ fontSize: 16, fontWeight: 700, margin: '28px 0 14px' }}>درخواست‌های قبلی من</h2>
          {myRfqs.length === 0 ? (
            <div style={emptyStyle}>هنوز درخواستی ثبت نکردی.</div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {myRfqs.map((rfq) => (
                <div key={rfq.id} style={rfqCardStyle}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: 8 }}>
                    <div>
                      <b style={{ fontSize: 13 }}>{rfq.polymerType}</b>
                      {rfq.suggestedGradeCode && (
                        <span style={{ fontSize: 11, color: '#9199a3', marginRight: 8 }}>(پیشنهادی: {rfq.suggestedGradeCode})</span>
                      )}
                    </div>
                    <span style={statusBadge(rfq.status)}>{translateStatus(rfq.status)}</span>
                  </div>

                  <div style={{ fontSize: 12, color: '#6f7680', marginBottom: 6 }}>
                    مقدار: {rfq.quantityTon} تن
                    {rfq.mfiRangeMin != null && rfq.mfiRangeMax != null && <> · MFI: {rfq.mfiRangeMin}–{rfq.mfiRangeMax}</>}
                    {rfq.densityMin != null && rfq.densityMax != null && <> · چگالی: {rfq.densityMin}–{rfq.densityMax}</>}
                  </div>

                  {rfq.requirements && (
                    <div style={{ fontSize: 11.5, color: '#9199a3', marginBottom: 6 }}>
                      {rfq.requirements.slice(0, 120)}{rfq.requirements.length > 120 && '...'}
                    </div>
                  )}

                  {rfq.expertResponse && (
                    <div style={expertResponseStyle}><b>پاسخ کارشناس:</b> {rfq.expertResponse}</div>
                  )}

                  <div style={{ fontSize: 10.5, color: '#9199a3', marginTop: 6 }}>
                    ثبت‌شده: {new Date(rfq.createdAt).toLocaleDateString('fa-IR')}
                    {rfq.answeredAt && <> · پاسخ داده‌شده: {new Date(rfq.answeredAt).toLocaleDateString('fa-IR')}</>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function translateStatus(status: string): string {
  const map: Record<string, string> = { open: 'باز', answered: 'پاسخ‌داده‌شده', closed: 'بسته' }
  return map[status] ?? status
}

function statusBadge(status: string): React.CSSProperties {
  let bg = '#f1efe8', color = '#4f5560'
  if (status === 'open') { bg = '#fef3c7'; color = '#92400e' }
  else if (status === 'answered') { bg = '#d1fae5'; color = '#065f46' }
  else if (status === 'closed') { bg = '#e5e7eb'; color = '#4b5563' }
  return { fontSize: 10, fontWeight: 700, background: bg, color, borderRadius: 6, padding: '4px 10px', whiteSpace: 'nowrap' }
}

const pageStyle: React.CSSProperties = { minHeight: '100vh', background: '#faf8f4', padding: '32px 24px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl' }
const wrapStyle: React.CSSProperties = { maxWidth: 1100, margin: '0 auto', display: 'flex', gap: 24 }
const titleStyle: React.CSSProperties = { fontSize: 22, fontWeight: 800, marginBottom: 8 }
const subStyle: React.CSSProperties = { color: '#6f7680', fontSize: 13.5, marginBottom: 22, lineHeight: 1.9 }
const cardStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 12, padding: 20, background: '#fff', boxShadow: '0 1px 4px rgba(27,30,36,.05)' }
const labelStyle: React.CSSProperties = { fontSize: 12, fontWeight: 700, color: '#4f5560', marginBottom: 4 }
const inputStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 8, padding: '9px 12px', fontSize: 13, fontFamily: 'inherit', width: '100%' }
const submitBtnStyle: React.CSSProperties = { background: '#1e357b', color: '#fff', border: 'none', borderRadius: 8, padding: '9px 18px', fontSize: 12.5, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit' }
const infoBannerStyle: React.CSSProperties = { background: '#eef4fd', color: '#1e357b', borderRadius: 8, padding: '10px 14px', fontSize: 12, marginBottom: 14 }
const emptyStyle: React.CSSProperties = { padding: 32, textAlign: 'center', color: '#9199a3', border: '1px dashed #d8dde3', borderRadius: 12 }
const rfqCardStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 12, padding: 16, background: '#fff', boxShadow: '0 1px 4px rgba(27,30,36,.05)' }
const expertResponseStyle: React.CSSProperties = { background: '#eaf3de', color: '#146c3a', borderRadius: 8, padding: '10px 12px', fontSize: 12, marginTop: 8 }