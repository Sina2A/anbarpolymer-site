import prisma from '@/lib/prisma'
import { getCurrentUserOrNull } from '@/lib/currentUser'
import ListingDetailModal from '@/components/ListingDetailModal'
import CurrencyTicker from '@/components/CurrencyTicker'

export const dynamic = 'force-dynamic'

const POLYMER_FAMILY_OPTIONS = ['PP', 'HDPE', 'LDPE', 'LLDPE', 'PVC', 'PET', 'PS', 'EPS', 'ABS', 'سایر']

function one(v: string | string[] | undefined): string | undefined {
  if (Array.isArray(v)) return v[0]
  return v
}

export default async function MarketPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>
}) {
  const sp = await searchParams
  const q = one(sp.q)?.trim() || ''
  const family = one(sp.family)?.trim() || ''
  const category = one(sp.category)?.trim() || ''
  const applicationType = one(sp.applicationType)?.trim() || ''
  const producer = one(sp.producer)?.trim() || ''
  const province = one(sp.province)?.trim() || ''
  // بازار دوطرفه: تب «عرضه» (آگهی فروشنده‌ها) و تب «تقاضا» (درخواست خرید خریدارها)
  const view = one(sp.view)?.trim() === 'demand' ? 'demand' : 'supply'

  // ── Check auth/KYC level ──
  const user = await getCurrentUserOrNull()
  let kycLevel = 0
  if (user) {
    const comp = await prisma.company.findUnique({
      where: { userId: user.id },
      select: { kyc: { select: { level: true } } },
    })
    kycLevel = comp?.kyc?.level ?? 0
  }

  // ── Build where ──
  const where: Record<string, unknown> = { validityStatus: 'active' }

  if (q) {
    ;(where as any).OR = [
      { grade: { code: { contains: q, mode: 'insensitive' } } },
      { grade: { producer: { contains: q, mode: 'insensitive' } } },
      { grade: { category: { contains: q, mode: 'insensitive' } } },
    ]
  }
  if (family) where.grade = { ...((where.grade as any) || {}), polymerFamily: family }
  if (category) where.grade = { ...((where.grade as any) || {}), category }
  if (applicationType) where.grade = { ...((where.grade as any) || {}), applicationType }
  if (producer) where.grade = { ...((where.grade as any) || {}), producer }
  if (province) where.province = province

  // ── Query ──
  // NOTE: do NOT include `user` here — the full listing is passed to the
  // <ListingDetailModal> client component and would serialize User.passwordHash
  // (and phone/email) into the public page payload. The modal never uses it.
  const listings = await prisma.materialListing.findMany({
    where: where as any,
    include: { grade: true },
    orderBy: { createdAt: 'desc' },
  })

  // ── Filter options ──
  const [allCategories, allApplicationTypes, allProducers, allProvinces] = await Promise.all([
    prisma.grade.findMany({
      where: { isActive: true },
      distinct: ['category'],
      select: { category: true },
      orderBy: { category: 'asc' },
    }),
    prisma.grade.findMany({
      where: { isActive: true, applicationType: { not: null } },
      distinct: ['applicationType'],
      select: { applicationType: true },
      orderBy: { applicationType: 'asc' },
    }),
    prisma.grade.findMany({
      where: { isActive: true },
      distinct: ['producer'],
      select: { producer: true },
      orderBy: { producer: 'asc' },
    }),
    prisma.materialListing.findMany({
      where: { validityStatus: 'active' },
      distinct: ['province'],
      select: { province: true },
      orderBy: { province: 'asc' },
    }),
  ])

  const categories = allCategories.map((r) => r.category)
  const applicationTypes = allApplicationTypes.map((r) => r.applicationType).filter((v): v is string => !!v)
  const producers = allProducers.map((r) => r.producer)
  const provinces = allProvinces.map((r) => r.province)

  // ── تب تقاضا: درخواست‌های خرید باز ──
  // شمارش همیشه اجرا می‌شه (عددِ روی تب)، لیست کامل فقط وقتی تب تقاضا فعاله.
  // «باز» یعنی status=open و منقضی‌نشده — انقضا تنبل حساب می‌شه، مثل
  // /purchase-requests. درخواست با ساخته‌شدن آگهی بسته نمی‌شه، پس چند
  // فروشنده می‌تونن روی یک درخواست رقابت کنن.
  // نکته‌ی امنیتی: include: { user } ممنوعه — این صفحه عمومیه و User شامل
  // passwordHash/phone/email می‌شه؛ همون قاعده‌ی کوئری آگهی‌ها.
  const openRequestWhere = {
    status: 'open',
    OR: [{ expiresAt: null }, { expiresAt: { gte: new Date() } }],
  }
  const demandCount = await prisma.purchaseRequest.count({ where: openRequestWhere })
  const demandRequests =
    view === 'demand'
      ? await prisma.purchaseRequest.findMany({
          where: openRequestWhere,
          orderBy: { createdAt: 'desc' },
          include: {
            grade: { select: { code: true, producer: true, category: true } },
            _count: { select: { listings: true } },
          },
        })
      : []

  return (
    <>
      <CurrencyTicker />
      <style>{`
        .market-table tbody tr:hover {
          background: #f7f8fa;
        }
      `}</style>
      <div className="topbar">
        <div className="wrap">
          <span>پشتیبانی فروش شنبه تا چهارشنبه ۸:۳۰ تا ۱۷:۳۰</span>
          <a className="phone" href="tel:+982191234567">
            021-91234567
          </a>
        </div>
      </div>
      <header className="site-header">
        <div className="wrap">
          <a href="/" className="logo">
            <span className="dot"></span> انبار پلیمر
          </a>
          <nav className="main-nav">
            <a href="/">صفحه اصلی</a>
            <a href="/grades">گریدها</a>
            <a href="/rfq">استعلام قیمت</a>
            <a href="/market" className="active">
              بازار صنعتی
            </a>
            <a href="/reports">گزارش بازار</a>
            <a href="/services">خدمات سازمانی</a>
            <a href="/about">درباره ما</a>
            <a href="/contact">تماس با ما</a>
          </nav>
          <div className="header-actions">
            {user ? (
              <a href="/dashboard" className="acct-btn">
                پیشخوان
              </a>
            ) : (
              <a href="/login" className="acct-btn">
                ورود / ثبت‌نام
              </a>
            )}
          </div>
        </div>
      </header>

      <section>
        <div className="wrap">
          <div className="eyebrow">خرید و فروش مواد اولیه</div>
          <div className="sec-title">بازار صنعتی پلیمر</div>
          <div className="sec-sub" style={{ marginBottom: 16 }}>
            {view === 'supply' ? (
              <>
                آگهی‌های فروش مواد اولیه پلیمری از تولیدکنندگان و فروشندگان سراسر کشور —{' '}
                <b style={{ color: 'var(--cyan)' }}>{listings.length} آگهی فعال</b>
              </>
            ) : (
              <>
                نیازِ خریدها که خریدارها اعلام کرده‌ن — اگه بار داری، می‌تونی روی همون‌جا آگهی بذاری —{' '}
                <b style={{ color: 'var(--cyan)' }}>{demandRequests.length} درخواست باز</b>
              </>
            )}
          </div>

          {/* ── تب‌های بازار دوطرفه ── */}
          <div style={tabRowStyle}>
            <a href="/market" style={view === 'supply' ? tabActiveStyle : tabStyle}>
              عرضه‌ی فروشنده‌ها ({listings.length})
            </a>
            <a href="/market?view=demand" style={view === 'demand' ? tabActiveStyle : tabStyle}>
              تقاضای خریدارها ({demandCount})
            </a>
          </div>

          {/* ── Guest CTA ── */}
          {!user && (
            <div style={guestBanner}>
              برای مشاهده‌ی جزئیات کامل، قیمت و خرید،{' '}
              <a href="/signup" style={{ color: '#e65716', fontWeight: 700, textDecoration: 'underline' }}>
                عضو شوید ←
              </a>
            </div>
          )}

          {view === 'supply' ? (
            <>
              {/* ── Filters ── */}
              <form method="GET" action="/market" style={filterFormStyle}>
                <input
                  name="q"
                  defaultValue={q}
                  placeholder="جستجو: کد گرید، تولیدکننده، دسته…"
                  style={inputStyle}
                />

                {/* Quick chips */}
                <div style={chipRow}>
                  {POLYMER_FAMILY_OPTIONS.map((f) => (
                    <a
                      key={f}
                      href={`/market?family=${encodeURIComponent(f)}`}
                      style={{
                        ...chipStyle,
                        background: family === f ? '#fff4ee' : '#f1efe8',
                        color: family === f ? '#e65716' : '#5a5340',
                        fontWeight: family === f ? 700 : 400,
                      }}
                    >
                      {f}
                    </a>
                  ))}
                </div>

                <select name="category" defaultValue={category} style={selectStyle}>
                  <option value="">همه‌ی دسته‌ها</option>
                  {categories.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
                <select name="applicationType" defaultValue={applicationType} style={selectStyle}>
                  <option value="">همه‌ی کاربردها</option>
                  {applicationTypes.map((a) => (
                    <option key={a} value={a}>
                      {a}
                    </option>
                  ))}
                </select>
                <select name="producer" defaultValue={producer} style={selectStyle}>
                  <option value="">همه‌ی تولیدکنندگان</option>
                  {producers.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
                <select name="province" defaultValue={province} style={selectStyle}>
                  <option value="">همه‌ی استان‌ها</option>
                  {provinces.map((pr) => (
                    <option key={pr} value={pr}>
                      {pr}
                    </option>
                  ))}
                </select>
                <button type="submit" className="btn btn-sm" style={{ whiteSpace: 'nowrap' }}>
                  اعمال فیلتر
                </button>
                {(q || family || category || applicationType || producer || province) && (
                  <a href="/market" className="btn btn-sm btn-outline" style={{ whiteSpace: 'nowrap' }}>
                    پاک کردن
                  </a>
                )}
              </form>

              {/* ── Table ── */}
              {listings.length === 0 ? (
                <div style={emptyStyle}>هیچ آگهی فعالی با این فیلتر یافت نشد.</div>
              ) : (
                <div style={tableWrap}>
                  <table style={tableStyle} className="market-table">
                    <thead>
                      <tr>
                        <th>نام گرید</th>
                        <th>دسته</th>
                        <th>تولیدکننده و کشور</th>
                        <th>فرآیند / کاربرد</th>
                        <th>MFI</th>
                        <th>موقعیت بار</th>
                        <th>حداقل سفارش</th>
                        <th>قیمت (تومان/کیلو)</th>
                        <th>وضعیت</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      {listings.map((listing) => (
                        <ListingDetailModal key={listing.id} listing={listing} kycLevel={kycLevel} isGuest={!user} />
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </>
          ) : (
            <>
              {/* ── تقاضای خریدارها: درخواست‌های باز — سقف قیمت عمومیه ── */}
              {demandRequests.length === 0 ? (
                <div style={emptyStyle}>در حال حاضر هیچ درخواست خرید بازی ثبت نشده.</div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  {demandRequests.map((req) => (
                    <div key={req.id} style={demandCardStyle}>
                      <div style={demandHeadStyle}>
                        <div>
                          <span style={{ fontSize: 15, fontWeight: 800 }}>{req.grade.code}</span>{' '}
                          <span style={{ fontSize: 12, color: '#6f7680' }}>
                            {req.grade.producer} ({req.grade.category})
                          </span>
                        </div>
                        <span style={openTagStyle}>باز</span>
                      </div>

                      <div style={demandGridStyle}>
                        <div>
                          <div style={demandLabelStyle}>مقدار درخواستی</div>
                          <div style={{ fontSize: 13, fontWeight: 700 }}>{req.quantityTon} تن</div>
                        </div>
                        <div>
                          <div style={demandLabelStyle}>سقف قیمت خریدار</div>
                          <div style={{ fontSize: 13, fontWeight: 700, color: '#e65716' }}>
                            {req.maxPriceToman
                              ? `${req.maxPriceToman.toLocaleString('fa-IR')} تومان/کیلو`
                              : 'اعلام نشده'}
                          </div>
                        </div>
                        <div>
                          <div style={demandLabelStyle}>استان تحویل</div>
                          <div style={{ fontSize: 13, fontWeight: 600 }}>{req.province || 'مهم نیست'}</div>
                        </div>
                        <div>
                          <div style={demandLabelStyle}>آگهی‌های ثبت‌شده</div>
                          <div style={{ fontSize: 13, fontWeight: 600 }}>{req._count.listings} آگهی</div>
                        </div>
                      </div>

                      {req.description && (
                        <div style={{ fontSize: 12.5, color: '#4f5560', lineHeight: 1.8, marginBottom: 10 }}>
                          {req.description}
                        </div>
                      )}

                      <div style={demandFootStyle}>
                        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
                          <span>ثبت: {new Date(req.createdAt).toLocaleDateString('fa-IR')}</span>
                          {req.expiresAt && (
                            <>
                              <span>•</span>
                              <span>اعتبار تا: {new Date(req.expiresAt).toLocaleDateString('fa-IR')}</span>
                            </>
                          )}
                          <span>•</span>
                          <span style={{ fontFamily: 'monospace', direction: 'ltr' }}>#{req.id.slice(0, 8)}</span>
                        </div>
                        {user ? (
                          <a href={`/new-listing?request=${req.id}`} style={respondBtnStyle}>
                            ثبت آگهی در پاسخ
                          </a>
                        ) : (
                          <a href="/login" style={respondBtnStyle}>
                            ورود برای پاسخ
                          </a>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </section>

      <footer className="site-footer">
        <div className="wrap">
          <div className="footer-cols">
            <div>
              <a href="/" className="logo" style={{ marginBottom: 14, display: 'flex' }}>
                <span className="dot"></span> انبار پلیمر
              </a>
              <p style={{ color: 'var(--ink-dim)', fontSize: 13, maxWidth: 280 }}>
                واردکننده و فروشنده مستقیم مواد اولیه پلیمری برای کارخانه‌های تولیدی سراسر کشور.
              </p>
            </div>
            <div>
              <h5>محصولات</h5>
              <ul>
                <li>
                  <a href="/grades">پلی‌پروپیلن</a>
                </li>
                <li>
                  <a href="/grades">پلی‌اتیلن</a>
                </li>
                <li>
                  <a href="/grades">پی‌وی‌سی</a>
                </li>
                <li>
                  <a href="/grades">پلی‌اتیلن ترفتالات</a>
                </li>
              </ul>
            </div>
            <div>
              <h5>خدمات</h5>
              <ul>
                <li>
                  <a href="/rfq">استعلام قیمت آنلاین</a>
                </li>
                <li>
                  <a href="/market">بازار صنعتی</a>
                </li>
                <li>
                  <a href="/services">فروش سازمانی</a>
                </li>
                <li>
                  <a href="/reports">گزارش بازار</a>
                </li>
              </ul>
            </div>
            <div>
              <h5>اطلاعات تماس</h5>
              <ul>
                <li>تهران، خیابان ولیعصر، پلاک ۱۲۴</li>
                <li>انبار یزد — شهرک صنعتی یزد</li>
                <li style={{ direction: 'ltr', textAlign: 'right' }}>021-91234567</li>
              </ul>
            </div>
          </div>
          <div className="footer-bottom">
            <span>انبار پلیمر © ۱۴۰۵ — تمام حقوق محفوظ است</span>
          </div>
        </div>
      </footer>
    </>
  )
}

// ── Styles ──
const guestBanner: React.CSSProperties = {
  background: '#fef3c7',
  color: '#92400e',
  borderRadius: 8,
  padding: '10px 16px',
  fontSize: 13,
  fontWeight: 600,
  marginBottom: 20,
  textAlign: 'center',
}
const filterFormStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 12,
  marginBottom: 20,
  padding: 12,
  background: '#f8f9fb',
  border: '1px solid #eceff3',
  borderRadius: 10,
}
const inputStyle: React.CSSProperties = {
  padding: '8px 12px',
  border: '1px solid #d8dde3',
  borderRadius: 8,
  fontSize: 13,
  outline: 'none',
}
const chipRow: React.CSSProperties = {
  display: 'flex',
  flexWrap: 'wrap',
  gap: 6,
}
const chipStyle: React.CSSProperties = {
  fontSize: 11,
  borderRadius: 20,
  padding: '4px 12px',
  textDecoration: 'none',
  transition: 'background .15s',
  cursor: 'pointer',
}
const selectStyle: React.CSSProperties = {
  padding: '8px 10px',
  border: '1px solid #d8dde3',
  borderRadius: 8,
  fontSize: 13,
  background: '#fff',
  minWidth: 140,
}
const emptyStyle: React.CSSProperties = {
  padding: 40,
  textAlign: 'center',
  color: '#9199a3',
  fontSize: 13,
  border: '1px dashed #d8dde3',
  borderRadius: 10,
}
const tableWrap: React.CSSProperties = {
  overflowX: 'auto',
  borderRadius: 12,
  border: '1px solid #d8dde3',
  background: '#fff',
}
const tableStyle: React.CSSProperties = {
  width: '100%',
  borderCollapse: 'collapse',
  fontSize: 12.5,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const tabRowStyle: React.CSSProperties = {
  display: 'flex',
  gap: 8,
  marginBottom: 20,
  borderBottom: '2px solid #eceff3',
}
const tabStyle: React.CSSProperties = {
  padding: '10px 18px',
  fontSize: 13,
  fontWeight: 600,
  color: '#6f7680',
  textDecoration: 'none',
  borderBottom: '2px solid transparent',
  marginBottom: -2,
  cursor: 'pointer',
}
const tabActiveStyle: React.CSSProperties = {
  ...tabStyle,
  color: '#1e357b',
  fontWeight: 800,
  borderBottom: '2px solid #1e357b',
}
const demandCardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 18,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const demandHeadStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: 12,
}
const openTagStyle: React.CSSProperties = {
  fontSize: 10,
  fontWeight: 700,
  background: '#d1fae5',
  color: '#065f46',
  borderRadius: 6,
  padding: '3px 10px',
}
const demandGridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))',
  gap: 14,
  marginBottom: 12,
}
const demandLabelStyle: React.CSSProperties = {
  fontSize: 11,
  color: '#9199a3',
  marginBottom: 3,
}
const demandFootStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  flexWrap: 'wrap',
  gap: 10,
  borderTop: '1px solid #eceff3',
  paddingTop: 12,
  fontSize: 11.5,
  color: '#9199a3',
}
const respondBtnStyle: React.CSSProperties = {
  background: '#1e357b',
  color: '#fff',
  borderRadius: 8,
  padding: '8px 16px',
  fontSize: 12.5,
  fontWeight: 700,
  textDecoration: 'none',
  whiteSpace: 'nowrap',
}
