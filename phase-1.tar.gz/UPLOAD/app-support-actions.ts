'use server'

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { logAudit } from '@/lib/logger'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'

// ==================== ثبت تیکت جدید ====================

export async function createTicketAction(formData: FormData) {
  const user = await getCurrentUser()

  const subject = String(formData.get('subject') || '').trim()
  const detail = String(formData.get('detail') || '').trim()

  if (!subject) throw new Error('موضوع تیکت الزامیه.')
  if (!detail) throw new Error('متن پیام الزامیه.')

  // تیکت + اولین پیام کاربر با هم ساخته می‌شن (پیام اول = همون شرح مشکل)
  const ticket = await prisma.supportTicket.create({
    data: {
      userId: user.id,
      subject,
      detail,
      status: 'open',
      messages: {
        create: {
          body: detail,
          senderType: 'user',
          senderId: user.id,
        },
      },
    },
  })

  await logAudit('support', `تیکت جدید: ${subject}`, user.id, { ticketId: ticket.id })

  revalidatePath('/support')
  redirect(`/support/${ticket.id}`)
}

// ==================== پاسخ کاربر روی تیکت خودش ====================

export async function addUserMessageAction(formData: FormData) {
  const user = await getCurrentUser()

  const ticketId = String(formData.get('ticketId') || '').trim()
  const body = String(formData.get('body') || '').trim()

  if (!ticketId) throw new Error('شناسه‌ی تیکت مشخص نیست.')
  if (!body) throw new Error('متن پیام خالیه.')

  const ticket = await prisma.supportTicket.findUnique({ where: { id: ticketId } })
  if (!ticket) throw new Error('تیکت پیدا نشد.')
  if (ticket.userId !== user.id) throw new Error('فقط صاحب تیکت می‌تونه پیام بده.')
  if (ticket.status === 'closed') throw new Error('این تیکت بسته شده — امکان ارسال پیام نیست.')

  await prisma.supportMessage.create({
    data: {
      ticketId,
      body,
      senderType: 'user',
      senderId: user.id,
    },
  })

  // با پیام جدیدِ کاربر، تیکت دوباره به «باز» برمی‌گرده تا در صف کارشناس بیاد
  await prisma.supportTicket.update({
    where: { id: ticketId },
    data: { status: 'open' },
  })

  await logAudit('support', `پیام جدید کاربر روی تیکت ${ticketId.slice(0, 8)}`, user.id, { ticketId })

  revalidatePath(`/support/${ticketId}`)
  revalidatePath('/support')
}
