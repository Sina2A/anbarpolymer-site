import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import AdminNav from '@/components/AdminNav'
import { getAllSectionAccess } from '@/lib/accessControl'
import { requireCustomRfqAccess } from './accessGate'
import { updateRfqStatusAction, submitExpertResponseAction } from './actions'

export const dynamic = 'force-dynamic'

export default async function AdminCustomRequestPage() {
  const user = await getCurrentUser()
  await requireCustomRfqAccess(user.id, 'view')

  const accessMap = await getAllSectionAccess(user.id)
  const canEdit = accessMap['custom-rfq'] === 'edit' || accessMap['custom-rfq'] === 'full' || user.role === 'admin'

  // لیست همه‌ی درخواست‌های RFQ (باز و پاسخ‌داده‌شده)
  const allRfqs = await prisma.customRfq.findMany({
    orderBy: { createdAt: 'desc' },
    take: 100,
    include: {
      user: { select: { companyName: true, email: true } },
    },
  })

  return (
    <div style={pageStyle}>
      <div style={wrapStyle}>
        <AdminNav
          currentUserName={user.companyName}
          isAdmin={user.role === 'admin'}
          accessMap={accessMap}
          activeSection="custom-rfq"
        />

        <div style={{ flex: 1, minWidth: 0 }}>
          <h1 style={titleStyle}>مدیریت درخواست‌های غیرکاتالوگی (Custom RFQ)</h1>
          <p style={subStyle}>
            درخواست‌هایی که کاربران برای محصولات خارج از کاتالوگ ثبت کردند. پاسخ دستی کارشناس لازمه.
          </p>

          {allRfqs.length === 0 ? (
            <div style={emptyStyle}>هیچ درخواستی ثبت نشده.</div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              {allRfqs.map((rfq) => (
                <div key={rfq.id} style={rfqCardStyle}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: 10 }}>
                    <div>
                      <b style={{ fontSize: 14 }}>{rfq.polymerType}</b>
                      {rfq.suggestedGradeCode && (
                        <span style={{ fontSize: 11, color: '#9199a3', marginRight: 8 }}>
                          (پیشنهاد از گرید: {rfq.suggestedGradeCode})
                        </span>
                      )}
                      <div style={{ fontSize: 12, color: '#6f7680', marginTop: 4 }}>
                        کاربر: <b>{rfq.user.companyName}</b> · {rfq.user.email}
                      </div>
                    </div>
                    <span style={statusBadge(rfq.status)}>{translateStatus(rfq.status)}</span>
                  </div>

                  <div style={{ fontSize: 12, color: '#4f5560', marginBottom: 8 }}>
                    مقدار: <b>{rfq.quantityTon} تن</b>
                    {rfq.mfiRangeMin != null && rfq.mfiRangeMax != null && (
                      <> · MFI: {rfq.mfiRangeMin}–{rfq.mfiRangeMax}</>
                    )}
                    {rfq.densityMin != null && rfq.densityMax != null && (
                      <> · چگالی: {rfq.densityMin}–{rfq.densityMax}</>
                    )}
                  </div>

                  {rfq.requirements && (
                    <div style={{ fontSize: 12, color: '#4f5560', marginBottom: 8, padding: '8px 12px', background: '#f7f8fa', borderRadius: 6 }}>
                      <b style={{ fontSize: 11, color: '#6f7680', display: 'block', marginBottom: 4 }}>الزامات خاص:</b>
                      {rfq.requirements}
                    </div>
                  )}

                  {rfq.expertResponse && (
                    <div style={expertResponseStyle}>
                      <b>پاسخ کارشناس:</b> {rfq.expertResponse}
                    </div>
                  )}

                  <div style={{ fontSize: 11, color: '#9199a3', marginTop: 8 }}>
                    ثبت‌شده: {new Date(rfq.createdAt).toLocaleDateString('fa-IR')}
                    {rfq.answeredAt && (
                      <> · پاسخ داده‌شده: {new Date(rfq.answeredAt).toLocaleDateString('fa-IR')}</>
                    )}
                  </div>

                  {canEdit && rfq.status === 'open' && (
                    <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid #eceff3' }}>
                      <form action={submitExpertResponseAction}>
                        <input type="hidden" name="rfqId" value={rfq.id} />
                        <div style={{ marginBottom: 10 }}>
                          <div style={labelStyle}>پاسخ کارشناس (قیمت پیشنهادی + توضیحات)</div>
                          <textarea
                            name="expertResponse"
                            required
                            rows={3}
                            placeholder="مثلاً: گرید PP-H551T مناسب الزامات شماست. قیمت پیشنهادی: ۱۲۰،۰۰۰ تومان/کیلو (FOB انبار). زمان تحویل ۱۴ روز."
                            style={{ ...inputStyle, resize: 'vertical' }}
                          />
                        </div>
                        <button type="submit" style={submitBtnStyle}>
                          ثبت پاسخ و تغییر وضعیت به «پاسخ‌داده‌شده»
                        </button>
                      </form>
                    </div>
                  )}

                  {canEdit && rfq.status === 'answered' && (
                    <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid #eceff3' }}>
                      <form action={updateRfqStatusAction}>
                        <input type="hidden" name="rfqId" value={rfq.id} />
                        <input type="hidden" name="newStatus" value="closed" />
                        <button type="submit" style={closeBtnStyle}>
                          بستن درخواست (closed)
                        </button>
                      </form>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// ── ترجمه و رنگ وضعیت ──────────────────────────────────────────────────
function translateStatus(status: string): string {
  const map: Record<string, string> = { open: 'باز', answered: 'پاسخ‌داده‌شده', closed: 'بسته' }
  return map[status] ?? status
}

function statusBadge(status: string): React.CSSProperties {
  let bg = '#f1efe8'
  let color = '#4f5560'
  if (status === 'open') {
    bg = '#fef3c7'
    color = '#92400e'
  } else if (status === 'answered') {
    bg = '#d1fae5'
    color = '#065f46'
  } else if (status === 'closed') {
    bg = '#e5e7eb'
    color = '#4b5563'
  }
  return {
    fontSize: 10,
    fontWeight: 700,
    background: bg,
    color,
    borderRadius: 6,
    padding: '4px 10px',
    whiteSpace: 'nowrap',
  }
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: '#faf8f4',
  padding: '32px 24px',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const wrapStyle: React.CSSProperties = {
  maxWidth: 1300,
  margin: '0 auto',
  display: 'flex',
  gap: 24,
}
const titleStyle: React.CSSProperties = {
  fontSize: 20,
  fontWeight: 800,
  marginBottom: 8,
}
const subStyle: React.CSSProperties = {
  color: '#6f7680',
  fontSize: 13,
  marginBottom: 20,
  lineHeight: 1.8,
}
const emptyStyle: React.CSSProperties = {
  padding: 32,
  textAlign: 'center',
  color: '#9199a3',
  border: '1px dashed #d8dde3',
  borderRadius: 12,
}
const rfqCardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 18,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const expertResponseStyle: React.CSSProperties = {
  background: '#eaf3de',
  color: '#146c3a',
  borderRadius: 8,
  padding: '10px 12px',
  fontSize: 12,
  marginTop: 8,
}
const labelStyle: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 700,
  color: '#4f5560',
  marginBottom: 4,
}
const inputStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 8,
  padding: '9px 12px',
  fontSize: 13,
  fontFamily: 'inherit',
  width: '100%',
}
const submitBtnStyle: React.CSSProperties = {
  background: '#1e357b',
  color: '#fff',
  border: 'none',
  borderRadius: 8,
  padding: '9px 16px',
  fontSize: 12.5,
  fontWeight: 700,
  cursor: 'pointer',
  fontFamily: 'inherit',
}
const closeBtnStyle: React.CSSProperties = {
  background: 'transparent',
  color: '#9b1c1c',
  border: '1px solid #d8dde3',
  borderRadius: 8,
  padding: '7px 14px',
  fontSize: 12,
  fontWeight: 700,
  cursor: 'pointer',
  fontFamily: 'inherit',
}