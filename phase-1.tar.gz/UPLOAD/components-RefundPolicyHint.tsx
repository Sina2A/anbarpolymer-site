'use client'

import { useState } from 'react'

interface RefundPolicyHintProps {
  text?: string
  style?: React.CSSProperties
}

export default function RefundPolicyHint({ text, style }: RefundPolicyHintProps) {
  const [open, setOpen] = useState(false)
  const message = text || 'برای درخواست بازگشت وجه، با پشتیبانی انبار پلیمر تماس بگیرید تا پرونده‌ی شما بررسی شود.'

  return (
    <span style={{ position: 'relative', display: 'inline-block', verticalAlign: 'middle', ...style }}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        style={{
          width: 17,
          height: 17,
          borderRadius: '50%',
          background: '#eef4fd',
          border: '1px solid #b6cfed',
          color: '#1e357b',
          fontSize: 11,
          fontWeight: 700,
          cursor: 'pointer',
          lineHeight: '15px',
          textAlign: 'center',
          padding: 0,
        }}
      >
        ؟
      </button>
      {open && (
        <span
          style={{
            position: 'absolute',
            top: '110%',
            right: 0,
            width: 250,
            background: '#fff',
            border: '1px solid #d8dde3',
            borderRadius: 8,
            padding: '10px 12px',
            fontSize: 11.5,
            lineHeight: 1.7,
            color: '#4f5560',
            boxShadow: '0 4px 14px rgba(27,30,36,.12)',
            zIndex: 50,
            whiteSpace: 'normal',
          }}
        >
          <span style={{ display: 'block', fontWeight: 600, color: '#1b1e24', marginBottom: 4 }}>سیاست بازگشت وجه</span>
          {message}
        </span>
      )}
    </span>
  )
}
