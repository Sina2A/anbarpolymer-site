'use client'

import { useEffect, useRef } from 'react'
import { logoutAction } from '@/app/logout/actions'
import {
  sidebarStyle,
  sidebarGroupTitleStyle,
  sidebarItemStyle,
  sidebarComingSoonBadgeStyle,
} from '@/lib/styles/shared'
import { colors } from '@/lib/styles/tokens'
import type { CSSProperties } from 'react'

// ──────────────────────────────────────────────────────────
// گروه‌بندی منوی کاربری
// ──────────────────────────────────────────────────────────
const MENU_GROUPS: { title: string; items: Item[] }[] = [
  {
    title: 'پیشخوان',
    items: [
      { key: 'dashboard', label: 'پیشخوان', href: '/dashboard', isReal: true },
    ],
  },
  {
    title: 'بازرگانی',
    items: [
      { key: 'requests', label: 'درخواست‌های خرید من', href: '/my-requests', isReal: true },
      { key: 'purchase-requests', label: 'اعلام نیاز خرید (بازار)', href: '/purchase-requests', isReal: true },
      { key: 'orders', label: 'سفارش‌های من', href: '/my-orders', isReal: true },
      { key: 'proformas', label: 'پیش‌فاکتورهای من', href: '/proformas', isReal: true },
      { key: 'listings', label: 'شبکه عرضه مواد اولیه من', href: '/my-listings', isReal: true },
      { key: 'deals', label: 'معاملات من', href: '/my-deals', isReal: true },
      { key: 'transport', label: 'حمل و نقل', href: '/transport', isReal: true },
    ],
  },
  {
    title: 'حساب و پشتیبانی',
    items: [
      { key: 'verification', label: 'احراز هویت', href: '/verification', isReal: true },
      { key: 'grades', label: 'گریدها', href: '/grades', isReal: true },
      { key: 'account', label: 'ویرایش حساب کاربری', href: '/account', isReal: true },
      { key: 'custom-request', label: 'درخواست محصول غیرکاتالوگی', href: '/custom-request', isReal: true },
      { key: 'price-alerts', label: 'هشدار قیمت', href: '#', isReal: false },
      { key: 'support', label: 'پشتیبانی', href: '/support', isReal: true },
    ],
  },
]

type Item = {
  key: string
  label: string
  href: string
  isReal: boolean
}

export default function UserNav({
  currentUserName,
  activeSection,
}: {
  currentUserName: string
  activeSection?: string
}) {
  const detailsRef = useRef<HTMLDetailsElement>(null)

  useEffect(() => {
    const handleResize = () => {
      if (detailsRef.current) {
        detailsRef.current.open = window.innerWidth >= 900
      }
    }
    handleResize()
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  const allItems = MENU_GROUPS.flatMap((g) => g.items)
  const activeLabel = allItems.find((i) => i.key === activeSection)?.label ?? 'منوی من'

  return (
    <details className="user-nav" ref={detailsRef}>
      <summary className="user-nav-toggle">
        <span>☰ {activeLabel}</span>
        <span className="user-nav-caret">▾</span>
      </summary>

      <div className="user-nav-body">
        <div style={userBoxStyle}>{currentUserName}</div>
        <nav style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {MENU_GROUPS.map((group) => (
            <div key={group.title}>
              <div style={sidebarGroupTitleStyle}>{group.title}</div>
              {group.items.map((item) => {
                if (!item.isReal) {
                  return (
                    <span
                      key={item.key}
                      style={{
                        ...sidebarItemStyle(false),
                        color: colors.textMuted,
                        cursor: 'default',
                      }}
                      title="هنوز صفحه‌ی این بخش ساخته نشده"
                    >
                      {item.label}
                      <span style={sidebarComingSoonBadgeStyle}>به‌زودی</span>
                    </span>
                  )
                }

                return (
                  <a
                    key={item.key}
                    href={item.href}
                    style={sidebarItemStyle(item.key === activeSection)}
                  >
                    {item.label}
                  </a>
                )
              })}
            </div>
          ))}
        </nav>

        {/* ── خروج از حساب ── */}
        <div style={dividerStyle} />
        <form action={logoutAction}>
          <button
            type="submit"
            style={{
              ...sidebarItemStyle(false),
              color: colors.dangerText,
              cursor: 'pointer',
              width: '100%',
              textAlign: 'right' as const,
              background: 'transparent',
              border: 'none',
              fontFamily: 'inherit',
            }}
          >
            خروج از حساب
          </button>
        </form>
      </div>
    </details>
  )
}

const userBoxStyle: CSSProperties = {
  paddingBottom: 12,
  marginBottom: 10,
  borderBottom: `1px solid ${colors.borderSubtle}`,
  fontSize: 13,
  fontWeight: 700,
  color: colors.textPrimary,
}

const dividerStyle: CSSProperties = {
  height: 1,
  background: colors.borderSubtle,
  margin: '10px 0',
}
