'use client'

// اطلاعات حساب از متغیرهای محیطی NEXT_PUBLIC_ خوانده می‌شن — هیچ اطلاعات
// تماس مستقیم در کد نیست. مقادیر را در .env.local تعریف کن:
//   NEXT_PUBLIC_BANK_NAME=...
//   NEXT_PUBLIC_BANK_ACCOUNT=...
//   NEXT_PUBLIC_BANK_SHEBA=...
//   NEXT_PUBLIC_BANK_OWNER=...
export default function PaymentContactPanel() {
  const bankName = process.env.NEXT_PUBLIC_BANK_NAME
  const account = process.env.NEXT_PUBLIC_BANK_ACCOUNT
  const sheba = process.env.NEXT_PUBLIC_BANK_SHEBA
  const owner = process.env.NEXT_PUBLIC_BANK_OWNER

  if (!bankName && !account && !sheba) {
    return (
      <div style={warnStyle}>
        اطلاعات حساب هنوز تنظیم نشده — با مدیر سیستم تماس بگیرید.
      </div>
    )
  }

  return (
    <div style={panelStyle}>
      <div style={titleStyle}>اطلاعات واریز</div>
      {owner && <Row label="صاحب حساب" value={owner} />}
      {bankName && <Row label="بانک" value={bankName} />}
      {account && <Row label="شماره حساب" value={account} mono />}
      {sheba && <Row label="شبا" value={sheba} mono />}
    </div>
  )
}

function Row({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div style={rowStyle}>
      <span style={labelStyle}>{label}</span>
      <span style={mono ? monoStyle : valueStyle}>{value}</span>
    </div>
  )
}

const panelStyle: React.CSSProperties = {
  background: '#f0f7ff',
  border: '1px solid #c3d9f5',
  borderRadius: 10,
  padding: '14px 16px',
  marginBottom: 16,
}
const titleStyle: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 700,
  color: '#1e357b',
  marginBottom: 10,
}
const rowStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  padding: '5px 0',
  borderBottom: '1px solid #dce9f8',
  fontSize: 13,
}
const labelStyle: React.CSSProperties = { color: '#6b7280', fontSize: 12 }
const valueStyle: React.CSSProperties = { fontWeight: 600, color: '#1a1a2e' }
const monoStyle: React.CSSProperties = {
  fontFamily: 'monospace',
  fontWeight: 700,
  color: '#1a1a2e',
  direction: 'ltr',
}
const warnStyle: React.CSSProperties = {
  background: '#fff8e1',
  border: '1px solid #f0c040',
  borderRadius: 8,
  padding: '10px 14px',
  fontSize: 12,
  color: '#7a5c00',
  marginBottom: 16,
}
