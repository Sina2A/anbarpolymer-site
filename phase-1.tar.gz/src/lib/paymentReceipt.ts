import fs from 'fs/promises'
import path from 'path'
import crypto from 'crypto'
import prisma from '@/lib/prisma'
import { logAudit } from '@/lib/logger'

const UPLOAD_DIR = path.join(process.cwd(), 'public', 'uploads', 'receipts')

// اطمینان از وجود پوشه — اگه نبود خودکار می‌سازه
async function ensureUploadDir() {
  await fs.mkdir(UPLOAD_DIR, { recursive: true })
}

/**
 * ذخیره‌ی فیزیکی فایل رسید و برگرداندن URL نسبی
 * entityType: 'deal' | 'order'
 */
export async function savePaymentReceipt(
  file: File
): Promise<string> {
  await ensureUploadDir()

  const ext = file.name.split('.').pop()?.toLowerCase() ?? 'jpg'
  const allowed = ['jpg', 'jpeg', 'png', 'pdf']
  if (!allowed.includes(ext)) {
    throw new Error('فرمت فایل مجاز نیست — فقط JPG، PNG یا PDF')
  }

  const maxBytes = 5 * 1024 * 1024 // 5 MB
  if (file.size > maxBytes) {
    throw new Error('حجم فایل بیشتر از ۵ مگابایته')
  }

  const randomName = crypto.randomBytes(16).toString('hex')
  const fileName = `${randomName}.${ext}`
  const filePath = path.join(UPLOAD_DIR, fileName)

  const buffer = Buffer.from(await file.arrayBuffer())
  await fs.writeFile(filePath, buffer)

  return `/uploads/receipts/${fileName}`
}

/**
 * ثبت URL رسید روی رکورد Deal یا Order + logAudit
 */
export async function attachPaymentReceipt(
  entityType: 'deal' | 'order',
  entityId: string,
  receiptUrl: string,
  performedByUserId: string
): Promise<void> {
  const now = new Date()

  if (entityType === 'deal') {
    await prisma.deal.update({
      where: { id: entityId },
      data: {
        paymentReceiptUrl: receiptUrl,
        paymentReceiptUploadedAt: now,
      },
    })
  } else {
    await prisma.order.update({
      where: { id: entityId },
      data: {
        paymentReceiptUrl: receiptUrl,
        paymentReceiptUploadedAt: now,
      },
    })
  }

  await logAudit(
    'payment',
    `رسید پرداخت آپلود شد — ${entityType} #${entityId}`,
    performedByUserId,
    { receiptUrl }
  )
}
