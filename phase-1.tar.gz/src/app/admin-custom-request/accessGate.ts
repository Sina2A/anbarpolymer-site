import { getAllSectionAccess } from '@/lib/permissions'
import { AccessDeniedError } from '@/lib/errorCodes'
import type { AccessLevel } from '@/lib/sections'

/**
 * دروازه‌ی دسترسی بخش «درخواست‌های غیرکاتالوگی» — کلید بخش: custom-rfq
 * الگو از admin-support/actions.ts گرفته شده (getAllSectionAccess + مقایسه‌ی سطح).
 */
export async function requireCustomRfqAccess(userId: string, minLevel: AccessLevel = 'view') {
  const access = await getAllSectionAccess(userId)
  const sectionAccess = access['custom-rfq'] ?? 'none'

  const levels: AccessLevel[] = ['none', 'view', 'edit', 'full']
  const userLevelIndex = levels.indexOf(sectionAccess)
  const requiredLevelIndex = levels.indexOf(minLevel)

  if (userLevelIndex < requiredLevelIndex) {
    throw new AccessDeniedError('A-SECTION-CUSTOMRFQ')
  }
}