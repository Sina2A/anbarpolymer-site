import { NextRequest, NextResponse } from 'next/server'
import { getCurrentUserOrNull } from '@/lib/currentUser'
import { savePaymentReceipt, attachPaymentReceipt } from '@/lib/paymentReceipt'

export async function POST(request: NextRequest) {
  const user = await getCurrentUserOrNull()
  if (!user) {
    return NextResponse.json({ error: 'ابتدا وارد شوید' }, { status: 401 })
  }

  let formData: FormData
  try {
    formData = await request.formData()
  } catch {
    return NextResponse.json({ error: 'درخواست نامعتبر است' }, { status: 400 })
  }

  const entityType = formData.get('entityType')
  const entityId = formData.get('entityId')
  const file = formData.get('receipt')

  if (entityType !== 'deal' && entityType !== 'order') {
    return NextResponse.json({ error: 'نوع موجودیت نامعتبر است' }, { status: 400 })
  }
  if (!entityId || typeof entityId !== 'string') {
    return NextResponse.json({ error: 'شناسه‌ی موجودیت الزامی است' }, { status: 400 })
  }
  if (!(file instanceof File)) {
    return NextResponse.json({ error: 'فایل رسید الزامی است' }, { status: 400 })
  }

  let receiptUrl: string
  try {
    receiptUrl = await savePaymentReceipt(file)
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'خطا در ذخیره‌ی فایل'
    return NextResponse.json({ error: msg }, { status: 422 })
  }

  try {
    await attachPaymentReceipt(entityType, entityId, receiptUrl, user.id)
  } catch {
    return NextResponse.json({ error: 'خطا در ثبت اطلاعات' }, { status: 500 })
  }

  return NextResponse.json({ ok: true, receiptUrl })
}
