import { Fragment } from 'react'
import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import type { AccessLevel } from '@/lib/sections'
import AdminNav, { PartialAccessBanner } from '@/components/AdminNav'
import {
  createWarehouseAction,
  upsertStockAction,
  deleteStockAction,
} from './actions'

export const dynamic = 'force-dynamic'

export default async function AdminWarehousesPage({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>
}) {
  const params = await searchParams
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)

  const level: AccessLevel = isAdmin ? 'full' : ((myAccess?.warehouses as AccessLevel) ?? 'none')
  const hasAccess = level !== 'none'
  const canEdit = level === 'edit' || level === 'full'

  const warehouses = hasAccess
    ? await prisma.warehouse.findMany({
        include: {
          stock: {
            include: { grade: { select: { code: true, category: true } } },
            orderBy: { updatedAt: 'desc' },
          },
          _count: { select: { stock: true, orderItems: true } },
        },
        orderBy: { name: 'asc' },
      })
    : []

  const activeGrades = canEdit
    ? await prisma.grade.findMany({
        where: { isActive: true },
        select: { id: true, code: true, category: true },
        orderBy: { code: 'asc' },
      })
    : []

  const editingStockId = typeof params.editing === 'string' ? params.editing : null
  const confirmDeleteId = typeof params.confirmDelete === 'string' ? params.confirmDelete : null

  const feedback =
    typeof params.created === 'string'
      ? 'انبار جدید ثبت شد.'
      : typeof params.updated === 'string'
        ? 'انبار ویرایش شد.'
        : typeof params.stock === 'string'
          ? 'موجودی ذخیره شد.'
          : typeof params.deleted === 'string'
            ? 'ردیف موجودی حذف شد.'
            : null

  return (
    <div
      className="admin-page-wrap"
      style={{
        display: 'flex',
        gap: 24,
        padding: '32px 24px',
        fontFamily: "'Vazirmatn', Tahoma, sans-serif",
        direction: 'rtl',
        maxWidth: 1300,
        margin: '0 auto',
      }}
    >
      <AdminNav
        currentUserName={currentUser.companyName}
        isAdmin={isAdmin}
        accessMap={myAccess || {}}
        activeSection="warehouses"
      />

      <div style={{ flex: 1, minWidth: 0 }}>
        <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>انبارها و موجودی</h1>
        <p style={{ fontSize: 13, color: '#9199a3', marginBottom: 24 }}>
          مدیریت انبارهای انبار پلیمر و موجودی هر گرید در هر انبار
        </p>

        <PartialAccessBanner level={level} sectionLabel="انبارها و موجودی" />

        {!hasAccess && <div style={emptyBoxStyle}>به بخش «انبارها و موجودی» دسترسی نداری.</div>}

        {hasAccess && (
          <>
            {feedback && (
              <div style={feedbackStyle}>{feedback}</div>
            )}

            {canEdit && (
              <details style={{ marginBottom: 20 }}>
                <summary style={addNewBtnStyle}>+ افزودن انبار جدید</summary>
                <form action={createWarehouseAction} style={formCardStyle}>
                  <div style={formGridStyle}>
                    <label style={labelStyle}>
                      نام انبار *
                      <input name="name" required maxLength={120} style={inputStyle} />
                    </label>
                    <label style={labelStyle}>
                      شهر *
                      <input name="city" required maxLength={80} style={inputStyle} />
                    </label>
                    <label style={labelStyle}>
                      آدرس
                      <input name="address" maxLength={250} style={inputStyle} />
                    </label>
                    <label style={labelStyle}>
                      عرض جغرافیایی
                      <input name="latitude" type="number" step="any" style={inputStyle} />
                    </label>
                    <label style={labelStyle}>
                      طول جغرافیایی
                      <input name="longitude" type="number" step="any" style={inputStyle} />
                    </label>
                  </div>
                  <label style={{ ...labelStyle, marginTop: 8, display: 'block' }}>
                    توضیحات
                    <textarea name="description" maxLength={500} rows={2} style={inputStyle} />
                  </label>
                  <div style={{ marginTop: 14 }}>
                    <button type="submit" style={saveBtnStyle}>ذخیره انبار</button>
                  </div>
                </form>
              </details>
            )}

            {warehouses.length === 0 ? (
              <div style={emptyBoxStyle}>هیچ انباری ثبت نشده.</div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
                {warehouses.map((wh) => (
                  <div key={wh.id} style={warehouseCardStyle}>
                    <div style={warehouseHeadStyle}>
                      <div>
                        <h3 style={{ fontSize: 17, fontWeight: 800, margin: 0 }}>{wh.name}</h3>
                        <div style={{ fontSize: 12.5, color: '#6f7680', marginTop: 2 }}>
                          {wh.city}
                          {wh.address && <> — {wh.address}</>}
                        </div>
                      </div>
                      <div style={{ display: 'flex', gap: 12, fontSize: 12, color: '#9199a3' }}>
                        <span>
                          <b style={{ color: '#1b1e24' }}>{wh._count.stock}</b> گرید
                        </span>
                        <span>•</span>
                        <span>
                          <b style={{ color: '#1b1e24' }}>{wh._count.orderItems}</b> سفارش
                        </span>
                      </div>
                    </div>

                    {wh.description && (
                      <div style={{ fontSize: 12.5, color: '#4f5560', marginBottom: 12, lineHeight: 1.7 }}>
                        {wh.description}
                      </div>
                    )}

                    {wh.stock.length === 0 ? (
                      <div style={emptyStockStyle}>هیچ موجودی‌ای در این انبار ثبت نشده.</div>
                    ) : (
                      <div style={tableWrapStyle}>
                        <table style={tableStyle}>
                          <thead>
                            <tr style={{ background: '#f7f8fa' }}>
                              <th style={thStyle}>کد گرید</th>
                              <th style={thStyle}>دسته</th>
                              <th style={thStyle}>مقدار (تن)</th>
                              <th style={thStyle}>قیمت (ریال/کیلو)</th>
                              <th style={thStyle}>بچ</th>
                              <th style={thStyle}>آخرین بروزرسانی</th>
                              {canEdit && <th style={thStyle}>عملیات</th>}
                            </tr>
                          </thead>
                          <tbody>
                            {wh.stock.map((st) => {
                              const isEditing = editingStockId === st.id
                              const isConfirmingDelete = confirmDeleteId === st.id
                              return (
                                <Fragment key={st.id}>
                                <tr style={{ borderTop: '1px solid #eceff3' }}>
                                  <td style={{ ...tdStyle, fontFamily: 'monospace', fontWeight: 700 }}>
                                    {st.grade.code}
                                  </td>
                                  <td style={tdStyle}>{st.grade.category}</td>
                                  <td style={{ ...tdStyle, fontFamily: 'monospace', direction: 'ltr', textAlign: 'right' }}>
                                    {st.quantityTon.toLocaleString('en-US')}
                                  </td>
                                  <td style={{ ...tdStyle, fontFamily: 'monospace', direction: 'ltr', textAlign: 'right' }}>
                                    {st.priceRial.toLocaleString('en-US')}
                                  </td>
                                  <td style={{ ...tdStyle, fontFamily: 'monospace', color: '#6f7680' }}>
                                    {st.batch || '—'}
                                  </td>
                                  <td style={{ ...tdStyle, fontSize: 11.5, color: '#6f7680' }}>
                                    {new Date(st.updatedAt).toLocaleDateString('fa-IR')}
                                  </td>
                                  {canEdit && (
                                    <td style={{ ...tdStyle, whiteSpace: 'nowrap' }}>
                                      <a href={`?editing=${st.id}`} style={actionLinkStyle}>ویرایش</a>
                                      {isConfirmingDelete ? (
                                        <>
                                          <form action={deleteStockAction} style={{ display: 'inline' }}>
                                            <input type="hidden" name="id" value={st.id} />
                                            <button type="submit" style={dangerButtonStyle}>تایید حذف</button>
                                          </form>
                                          <a href="?" style={cancelLinkStyle}>انصراف</a>
                                        </>
                                      ) : (
                                        <a href={`?confirmDelete=${st.id}`} style={dangerLinkStyle}>حذف</a>
                                      )}
                                    </td>
                                  )}
                                </tr>
                                {isEditing && (
                                  <tr style={{ background: '#f7f8fa' }}>
                                    <td colSpan={canEdit ? 7 : 6} style={{ padding: '12px 10px' }}>
                                      <form action={upsertStockAction} style={{ display: 'flex', flexWrap: 'wrap', gap: 12, alignItems: 'flex-end' }}>
                                        <input type="hidden" name="warehouseId" value={wh.id} />
                                        <input type="hidden" name="gradeId" value={st.gradeId} />
                                        <div style={{ fontSize: 12, fontWeight: 700, width: '100%' }}>
                                          ویرایش موجودی: {st.grade.code} ({st.grade.category})
                                        </div>
                                        <label style={labelStyle}>
                                          مقدار (تن)
                                          <input name="quantityTon" type="number" step="0.01" defaultValue={st.quantityTon} required style={inlineInputStyle} />
                                        </label>
                                        <label style={labelStyle}>
                                          قیمت (ریال/کیلو)
                                          <input name="priceRial" type="number" step="1" defaultValue={st.priceRial} required style={inlineInputStyle} />
                                        </label>
                                        <label style={labelStyle}>
                                          بچ
                                          <input name="batch" defaultValue={st.batch || ''} style={inlineInputStyle} />
                                        </label>
                                        <button type="submit" style={saveBtnStyle}>ذخیره</button>
                                        <a href="?" style={cancelLinkStyle}>لغو</a>
                                      </form>
                                    </td>
                                  </tr>
                                )}
                                </Fragment>
                              )
                            })}
                          </tbody>
                        </table>
                      </div>
                    )}

                    {activeGrades.length > 0 && canEdit && (
                      <details style={{ marginTop: 14 }}>
                        <summary style={addStockBtnStyle}>+ افزودن موجودی</summary>
                        <form action={upsertStockAction} style={formCardStyle}>
                          <input type="hidden" name="warehouseId" value={wh.id} />
                          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, alignItems: 'flex-end' }}>
                            <label style={{ ...labelStyle, flex: '1 1 180px' }}>
                              گرید *
                              <select name="gradeId" required style={inputStyle}>
                                <option value="">— انتخاب گرید —</option>
                                {activeGrades.map((g) => (
                                  <option key={g.id} value={g.id}>
                                    {g.code} ({g.category})
                                  </option>
                                ))}
                              </select>
                            </label>
                            <label style={labelStyle}>
                              مقدار (تن) *
                              <input name="quantityTon" type="number" step="0.01" required style={inlineInputStyle} />
                            </label>
                            <label style={labelStyle}>
                              قیمت (ریال/کیلو) *
                              <input name="priceRial" type="number" step="1" required style={inlineInputStyle} />
                            </label>
                            <label style={labelStyle}>
                              بچ
                              <input name="batch" style={inlineInputStyle} />
                            </label>
                            <button type="submit" style={saveBtnStyle}>ذخیره</button>
                          </div>
                        </form>
                      </details>
                    )}
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}

const emptyBoxStyle: React.CSSProperties = {
  padding: 24,
  textAlign: 'center',
  color: '#9199a3',
  border: '1px dashed #d8dde3',
  borderRadius: 12,
  fontSize: 12.5,
  marginBottom: 20,
}
const warehouseCardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 18,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const warehouseHeadStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'flex-start',
  marginBottom: 14,
  flexWrap: 'wrap',
  gap: 12,
}
const emptyStockStyle: React.CSSProperties = {
  padding: 16,
  textAlign: 'center',
  color: '#9199a3',
  fontSize: 12,
  background: '#f7f8fa',
  borderRadius: 8,
}
const tableWrapStyle: React.CSSProperties = {
  overflowX: 'auto',
  border: '1px solid #eceff3',
  borderRadius: 8,
}
const tableStyle: React.CSSProperties = {
  width: '100%',
  borderCollapse: 'collapse',
  fontSize: 12.5,
}
const thStyle: React.CSSProperties = {
  textAlign: 'right',
  fontSize: 11,
  color: '#6f7680',
  padding: '8px 10px',
  fontWeight: 700,
}
const tdStyle: React.CSSProperties = { padding: '9px 10px', fontSize: 12.5 }
const feedbackStyle: React.CSSProperties = {
  padding: '10px 16px',
  background: '#e8f5e9',
  color: '#2e7d32',
  borderRadius: 8,
  fontSize: 13,
  marginBottom: 16,
}
const addNewBtnStyle: React.CSSProperties = {
  padding: '10px 24px',
  background: '#1b1e24',
  color: '#fff',
  borderRadius: 8,
  fontSize: 13,
  fontWeight: 700,
  cursor: 'pointer',
  listStyle: 'none',
}
const addStockBtnStyle: React.CSSProperties = {
  padding: '8px 18px',
  background: '#1a73e8',
  color: '#fff',
  borderRadius: 8,
  fontSize: 12,
  fontWeight: 700,
  cursor: 'pointer',
  listStyle: 'none',
}
const formCardStyle: React.CSSProperties = {
  background: '#f7f8fa',
  border: '1px solid #eceff3',
  borderRadius: 10,
  padding: 16,
  marginTop: 12,
}
const formGridStyle: React.CSSProperties = {
  display: 'flex',
  flexWrap: 'wrap',
  gap: 12,
}
const labelStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 4,
  fontSize: 12,
  fontWeight: 700,
  color: '#4f5560',
  flex: '1 1 180px',
  minWidth: 160,
}
const inputStyle: React.CSSProperties = {
  padding: '8px 10px',
  border: '1px solid #d8dde3',
  borderRadius: 6,
  fontSize: 12.5,
  fontFamily: 'inherit',
  direction: 'rtl',
}
const inlineInputStyle: React.CSSProperties = {
  padding: '6px 10px',
  border: '1px solid #d8dde3',
  borderRadius: 6,
  fontSize: 12,
  fontFamily: 'inherit',
  direction: 'rtl',
  width: 110,
}
const saveBtnStyle: React.CSSProperties = {
  padding: '8px 20px',
  background: '#2e7d32',
  color: '#fff',
  border: 'none',
  borderRadius: 6,
  fontSize: 12,
  fontWeight: 700,
  cursor: 'pointer',
}
const actionLinkStyle: React.CSSProperties = {
  color: '#1a73e8',
  fontSize: 12,
  marginLeft: 10,
}
const dangerLinkStyle: React.CSSProperties = {
  color: '#d32f2f',
  fontSize: 12,
}
const dangerButtonStyle: React.CSSProperties = {
  color: '#d32f2f',
  fontSize: 12,
  fontWeight: 700,
  background: 'none',
  border: 'none',
  cursor: 'pointer',
  padding: 0,
  marginLeft: 10,
}
const cancelLinkStyle: React.CSSProperties = {
  color: '#6f7680',
  fontSize: 11,
  marginLeft: 6,
}
