import prisma from '@/lib/prisma'
import { getAllSectionAccess } from '@/lib/permissions'
import { getCurrentUser } from '@/lib/currentUser'
import AdminNav, { PartialAccessBanner } from '@/components/AdminNav'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'
import { cleanupOldLogsAction } from './actions'

export const dynamic = 'force-dynamic'

const LEVEL_STYLES: Record<string, { bg: string; text: string; label: string }> = {
  error: { bg: '#fde8e8', text: '#9b1c1c', label: '🔴 خطا' },
  warn: { bg: '#fef3c7', text: '#92400e', label: '🟡 هشدار' },
  info: { bg: '#eef4fd', text: '#1e357b', label: 'ℹ️ اطلاع' },
  audit: { bg: '#eaf3de', text: '#27500a', label: '👤 فعالیت کاربر' },
}
const PAGE_SIZE = 50

export default async function AdminLogsPage({
  searchParams,
}: {
  searchParams: Promise<{ level?: string; category?: string; q?: string; page?: string }>
}) {
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)
  const access = isAdmin ? 'full' : myAccess?.logs ?? 'none'

  if (access === 'none') {
    return (
      <div className="admin-page-wrap" style={{ display: 'flex', gap: 24, padding: '32px 24px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', maxWidth: 1100, margin: '0 auto' }}>
        <AdminNav currentUserName={currentUser.companyName} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="logs" />
        <div style={{ flex: 1 }}>دسترسی به این بخش نداری — از مدیر بخواه دسترسیت رو تنظیم کنه.</div>
      </div>
    )
  }

  const sp = await searchParams
  const level = sp.level || ''
  const category = sp.category || ''
  const q = sp.q || ''
  const page = Math.max(1, Number(sp.page) || 1)

  const where: Record<string, unknown> = {}
  if (level) where.level = level
  if (category) where.category = category
  if (q) where.message = { contains: q }

  const [logs, total, categories] = await Promise.all([
    prisma.systemLog.findMany({
      where,
      include: { user: true },
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * PAGE_SIZE,
      take: PAGE_SIZE,
    }),
    prisma.systemLog.count({ where }),
    prisma.systemLog.findMany({ distinct: ['category'], select: { category: true } }),
  ])

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE))

  return (
    <div className="admin-page-wrap" style={{ display: 'flex', gap: 24, padding: '32px 24px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', maxWidth: 1300, margin: '0 auto' }}>
      <AdminNav currentUserName={currentUser.companyName} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="logs" />

      <div style={{ flex: 1, minWidth: 0 }}>
        <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 8 }}>لاگ سیستم و فعالیت کاربر</h1>
        <p style={{ color: '#6f7680', fontSize: 13.5, marginBottom: 20, lineHeight: 1.9 }}>
          خطاهای فنی (برای دیباگ) و فعالیت کاربران (برای ردیابی رفتار)، یکجا. مجموعاً {total} رکورد.
        </p>
        {access !== 'full' && <PartialAccessBanner level={access} sectionLabel="لاگ سیستم و فعالیت" />}

        <form method="GET" style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 20, alignItems: 'center' }}>
          <select name="level" defaultValue={level} style={selectStyle}>
            <option value="">همه‌ی سطح‌ها</option>
            <option value="error">🔴 خطا</option>
            <option value="warn">🟡 هشدار</option>
            <option value="info">ℹ️ اطلاع</option>
            <option value="audit">👤 فعالیت کاربر</option>
          </select>
          <select name="category" defaultValue={category} style={selectStyle}>
            <option value="">همه‌ی دسته‌ها</option>
            {categories.map((c) => (
              <option key={c.category} value={c.category}>{c.category}</option>
            ))}
          </select>
          <input name="q" defaultValue={q} placeholder="جستجو توی متن پیام..." style={{ ...selectStyle, flex: 1, minWidth: 180 }} />
          <button type="submit" style={btnStyle}>فیلتر</button>
          {(level || category || q) && <a href="/admin-logs" style={{ fontSize: 12, color: '#6f7680' }}>پاک‌کردن فیلتر</a>}
        </form>

        <div style={{ border: '1px solid #d8dde3', borderRadius: 12, overflow: 'hidden', marginBottom: 20 }}>
          <table style={{ width: '100%', fontSize: 12.5, borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: '#f7f8fa', color: '#6f7680', textAlign: 'right' }}>
                <th style={thStyle}>زمان</th>
                <th style={thStyle}>سطح</th>
                <th style={thStyle}>دسته</th>
                <th style={thStyle}>پیام</th>
                <th style={thStyle}>کاربر</th>
              </tr>
            </thead>
            <tbody>
              {logs.length === 0 ? (
                <tr><td colSpan={5} style={{ ...tdStyle, textAlign: 'center', color: '#9199a3', padding: 24 }}>چیزی پیدا نشد.</td></tr>
              ) : logs.map((log) => {
                const s = LEVEL_STYLES[log.level] || LEVEL_STYLES.info
                return (
                  <tr key={log.id} style={{ borderTop: '1px solid #eceff3' }}>
                    <td style={{ ...tdStyle, fontFamily: 'monospace', whiteSpace: 'nowrap' }}>{new Date(log.createdAt).toLocaleString('fa-IR')}</td>
                    <td style={tdStyle}><span style={{ background: s.bg, color: s.text, borderRadius: 6, padding: '2px 8px', fontWeight: 700, fontSize: 11 }}>{s.label}</span></td>
                    <td style={{ ...tdStyle, fontFamily: 'monospace' }}>{log.category}</td>
                    <td style={tdStyle}>
                      {log.message}
                      {log.path && <div style={{ fontSize: 10.5, color: '#9199a3' }}>{log.path}</div>}
                      {log.metaJson && (
                        <details style={{ marginTop: 4 }}>
                          <summary style={{ fontSize: 10.5, color: '#1e357b', cursor: 'pointer' }}>جزئیات</summary>
                          <pre style={{ fontSize: 10, background: '#f7f8fa', padding: 8, borderRadius: 6, overflowX: 'auto', direction: 'ltr', textAlign: 'left' }}>{log.metaJson}</pre>
                        </details>
                      )}
                    </td>
                    <td style={tdStyle}>{log.user?.companyName || '—'}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>

        {totalPages > 1 && (
          <div style={{ display: 'flex', gap: 8, marginBottom: 24, fontSize: 12.5 }}>
            {page > 1 && <a href={`?level=${encodeURIComponent(level)}&category=${encodeURIComponent(category)}&q=${encodeURIComponent(q)}&page=${page - 1}`} style={pageLinkStyle}>← قبلی</a>}
            <span style={{ color: '#6f7680' }}>صفحه‌ی {page} از {totalPages}</span>
            {page < totalPages && <a href={`?level=${encodeURIComponent(level)}&category=${encodeURIComponent(category)}&q=${encodeURIComponent(q)}&page=${page + 1}`} style={pageLinkStyle}>بعدی →</a>}
          </div>
        )}

        {isAdmin && (
          <div style={{ border: '1px dashed #d8dde3', borderRadius: 10, padding: 16 }}>
            <div style={{ fontSize: 12.5, fontWeight: 700, marginBottom: 8 }}>پاکسازی</div>
            <p style={{ fontSize: 11.5, color: '#9199a3', marginBottom: 10 }}>
              این جدول هیچ پاکسازی خودکاری نداره — با گذر زمان بزرگ می‌شه. لاگ‌های قدیمی‌تر از ۹۰ روز رو دستی پاک کن.
            </p>
            <form action={cleanupOldLogsAction}>
              <ConfirmSubmitButton message="لاگ‌های قدیمی‌تر از ۹۰ روز حذف بشن؟ این عمل قابل‌بازگشت نیست." style={{ ...btnStyle, background: '#9b1c1c' }}>
                حذف لاگ‌های قدیمی‌تر از ۹۰ روز
              </ConfirmSubmitButton>
            </form>
          </div>
        )}
      </div>
    </div>
  )
}

const selectStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 8, padding: '8px 10px', fontSize: 12.5, fontFamily: 'inherit' }
const btnStyle: React.CSSProperties = { background: '#1e357b', color: '#fff', border: 'none', borderRadius: 8, padding: '8px 18px', fontSize: 12.5, fontWeight: 700, cursor: 'pointer' }
const thStyle: React.CSSProperties = { padding: '10px 12px', fontWeight: 700 }
const tdStyle: React.CSSProperties = { padding: '10px 12px', verticalAlign: 'top' }
const pageLinkStyle: React.CSSProperties = { color: '#1e357b', textDecoration: 'none' }
