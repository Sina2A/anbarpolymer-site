import { getAllSectionAccess } from '@/lib/accessControl'
import { redirect } from 'next/navigation'
import type { AccessLevel } from '@/lib/sections'

export async function requireRfqAccess(userId: string, minLevel: AccessLevel = 'view') {
  const access = await getAllSectionAccess(userId)
  const rfqAccess = access.rfq ?? 'none'

  const levels: AccessLevel[] = ['none', 'view', 'edit', 'full']
  const userLevelIndex = levels.indexOf(rfqAccess)
  const requiredLevelIndex = levels.indexOf(minLevel)

  if (userLevelIndex < requiredLevelIndex) {
    redirect('/admin-orders')
  }
}
