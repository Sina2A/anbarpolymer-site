'use server'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { requireRfqAccess } from './accessGate'

export async function submitExpertResponseAction(formData: FormData) {
  const user = await getCurrentUser()
  await requireRfqAccess(user.id, 'edit')

  const rfqId = formData.get('rfqId') as string
  const expertResponse = formData.get('expertResponse') as string

  if (!rfqId || !expertResponse) {
    throw new Error('شناسه درخواست و پاسخ کارشناس الزامی است')
  }

  await prisma.customRfq.update({
    where: { id: rfqId },
    data: {
      expertResponse,
      answeredById: user.id,
      answeredAt: new Date(),
      status: 'answered',
    },
  })

  revalidatePath('/admin-rfq')
  redirect('/admin-rfq')
}

export async function updateRfqStatusAction(formData: FormData) {
  const user = await getCurrentUser()
  await requireRfqAccess(user.id, 'edit')

  const rfqId = formData.get('rfqId') as string
  const newStatus = formData.get('newStatus') as string

  if (!rfqId || !newStatus) {
    throw new Error('شناسه درخواست و وضعیت جدید الزامی است')
  }

  await prisma.customRfq.update({
    where: { id: rfqId },
    data: { status: newStatus },
  })

  revalidatePath('/admin-rfq')
  redirect('/admin-rfq')
}
