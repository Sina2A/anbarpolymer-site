# گزارش فاز ۱ — گروه ۲۵: بازطراحی کامل (الهام Stripe Dashboard)

**تاریخ:** ۲۰۲۶-۰۹-۰۴
**وضعیت:** ✅ کامل — آماده دیپلوی

---

## خلاصه

فاز ۱ شامل ساخت زیرساخت طراحی (توکن‌ها + استایل مشترک) و مهاجرت پنل حمل‌ونقل به این زیرساخت بود. هیچ تغییری در اسکیما Prisma یا دیتابیس رخ نداده — `prisma migrate` لازم نیست.

---

## فایل‌های تولیدشده

### ۱. توکن‌های طراحی (`lib/styles/tokens.ts`)

| مسیر baseline | مسیر NEW FILES | مسیر UPLOAD |
|---|---|---|
| `anbarpolymer-app/src/lib/styles/tokens.ts` | `NEW FILES/src/lib/styles/tokens.ts` | `NEW FILES/UPLOAD/lib-styles-tokens.ts` |

توکن‌های `colors`، `spacing`، `radius`، `fontSize` به صورت `as const`. رنگ‌های برند (navy/navyDark/orange) دست‌نخورده. فقط نحوه استفاده تغییر کرده.

### ۲. استایل مشترک (`lib/styles/shared.ts`)

| مسیر baseline | مسیر NEW FILES | مسیر UPLOAD |
|---|---|---|
| `anbarpolymer-app/src/lib/styles/shared.ts` | `NEW FILES/src/lib/styles/shared.ts` | `NEW FILES/UPLOAD/lib-styles-shared.ts` |

۲۸۷ خط. صادرات: `pageStyle`، `pageWrapStyle`، `contentStyle`، `h1Style`، `subTitleStyle`، `cardStyle`، `cardHeaderStyle`، `cardTitleStyle`، `tableStyle`، `theadRowStyle`، `thStyle`، `tdStyle`، `trHoverClass`، `badgeStyle(kind)`، `btnPrimaryStyle`، `btnSecondaryStyle`، `btnDangerStyle`، `btnSmallStyle`، `inputStyle`، `selectStyle`، `labelStyle`، `emptyStateStyle`، `sidebarStyle`، `sidebarGroupTitleStyle`، `sidebarItemStyle(active)`، `sidebarComingSoonBadgeStyle`، `publicHeaderStyle`، `publicHeaderInnerStyle`، `publicNavLinkStyle`، `publicBrandStyle`.

### ۳. کامپوننت‌های ناوبری

| کامپوننت | baseline | NEW FILES | UPLOAD |
|---|---|---|---|
| AdminNav | `anbarpolymer-app/src/components/AdminNav.tsx` | `NEW FILES/src/components/AdminNav.tsx` | `NEW FILES/UPLOAD/components-AdminNav.tsx` |
| UserNav | `anbarpolymer-app/src/components/UserNav.tsx` | `NEW FILES/src/components/UserNav.tsx` | `NEW FILES/UPLOAD/components-UserNav.tsx` |
| PublicHeader | `anbarpolymer-app/src/components/PublicHeader.tsx` | `NEW FILES/src/components/PublicHeader.tsx` | `NEW FILES/UPLOAD/components-PublicHeader.tsx` |

### ۴. صفحه پنل حمل‌ونقل (مهاجرت کامل به توکن‌ها)

| مسیر | فایل |
|---|---|
| baseline | `anbarpolymer-app/src/app/transport-panel/page.tsx` |
| NEW FILES | `NEW FILES/src/app/transport-panel/page.tsx` |
| UPLOAD | `NEW FILES/UPLOAD/app-transport-panel-page.tsx` |

۴۲۱ خط. تمام استایل‌های محلی حالا از `colors.*` توکن‌ها استفاده می‌کنند (۵۱ مرجع). هیچ هگز‌کد هاردکد باقی نمانده.

### ۵. CSS سراسری (`globals.css`)

| مسیر | خطوط |
|---|---|
| baseline | ۶۸۷ |
| NEW FILES | ۶۸۷ |
| UPLOAD | ۶۷۵ |

بلاک Phase-1 اضافه شده:
```css
.stripe-row-hover:hover { background-color: #f7f8fa; }

@media (max-width: 899px) {
  nav[data-public-nav="true"] { display: none !important; }
  button[data-public-hamburger="true"] { display: block !important; }
}
```

---

## نیاز به `prisma migrate`؟

**خیر.** فاز ۱ هیچ تغییر اسکیما یا دیتابیس ندارد. فقط فایل‌های کامپوننت و استایل تغییر کرده.

---

## نکات قابل توجه

### ۱. فاصله‌ی ZWNJ در UserNav

baseline از ZWNJ (`‌`) در برچسب‌های فارسی استفاده می‌کنه:
- `درخواست‌های خرید من` (با ZWNJ بین «درخواست» و «های»)
- `سفارش‌های من`
- `پیش‌فاکتورهای من`
- `به‌زودی`

کپی‌های `NEW FILES` و `UPLOAD` الان هم همین ZWNJها رو دارن — هماهنگ با baseline.

### ۲. شکاف CSS در `admin-grades/page.tsx`

صفحه `admin-grades/page.tsx` از کلاس‌های CSS زیر استفاده می‌کنه:
- `.spec-full`
- `.spec-badge`
- `.grade-form-grid`
- `.grades-filter-form`

این کلاس‌ها در baseline `globals.css` تعریف **نشده‌اند**. فقط در کپی قدیمی‌ی UPLOAD وجود داشتن که الان بازنویسی شده. این یک شکاف از قبل موجود در baseline است — فاز ۱ این مشکل رو آشکار می‌کنه ولی حل نمی‌کنه. در فازهای بعدی (وقتی admin-grades بازطراحی میشه) این کلاس‌ها باید یا به globals.css اضافه بشن یا به استایل inline تبدیل بشن.

### ۳. آرشیو tar.gz

بر اساس محدودیت تعیین‌شده، ساخت آرشیو با دستور شل (`tar`) امکان‌پذیر نیست. فایل‌ها در دو دایرکتوری `NEW FILES/src/...` و `NEW FILES/UPLOAD/...` آماده‌ان و می‌تونن به صورت جداگانه از سرور کپی بشن.

---

## مسیرهای دیپلوی

```
// NEW FILES/src/... → /var/www/anbarpolymer-app/src/...
// NEW FILES/UPLOAD/... → /var/www/anbarpolymer-app/src/...
// (با تغییر نام: lib-styles-tokens.ts → lib/styles/tokens.ts و ...)
```

الگوی دیپلوی: GitHub → wget → `npm run build` → pm2 restart.
