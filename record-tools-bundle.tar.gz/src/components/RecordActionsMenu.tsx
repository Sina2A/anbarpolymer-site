'use client'

import { useState, useRef, useEffect } from 'react'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'

type ExtraAction = {
  label: string
  href?: string
  /** اکشن سرورِ bind‌شده به id (مثل action.bind(null, orderId)) — داخل <form action={action}> رندر می‌شه */
  action?: () => void | Promise<void>
  /** اگر ست شده باشه، قبل از submit تاییدیه‌ی مرورگر می‌گیره (ConfirmSubmitButton) */
  confirmMessage?: string
  /** استایل قرمز برای اقدام مخرب/برگشت‌ناپذیر (ابطال، رد) */
  danger?: boolean
}

type Props = {
  editHref?: string
  onDelete?: () => Promise<void>
  deleteConfirmMessage?: string
  extraActions?: ExtraAction[]
}

/**
 * منوی اقدامات رکورد — آیکن آچار با دراپ‌دون کوچیک.
 * طراحی فشرده برای جدول/کارت‌های ادمین.
 */
export default function RecordActionsMenu({ editHref, onDelete, deleteConfirmMessage, extraActions }: Props) {
  const [open, setOpen] = useState(false)
  const menuRef = useRef<HTMLDivElement>(null)

  // بستن دراپ‌دون با کلیک بیرون
  useEffect(() => {
    if (!open) return
    function handleClickOutside(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [open])

  const hasAnyItem = editHref || onDelete || (extraActions && extraActions.length > 0)
  if (!hasAnyItem) return null

  return (
    <div ref={menuRef} style={{ position: 'relative', display: 'inline-block' }}>
      {/* دکمه‌ی آچار */}
      <button
        onClick={() => setOpen(!open)}
        style={triggerStyle}
        title="اقدامات"
        aria-label="اقدامات"
      >
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
          <path d="M11.6 9.4a4.7 4.7 0 0 0 .6-1.8c0-1-.4-2-1.1-2.7L9.4 3.5a.6.6 0 0 0-.9 0L6.6 5.4a3.8 3.8 0 0 0-2.7-1.1c-.7 0-1.3.2-1.8.6L1.1 2.8a.6.6 0 0 0-.8.1L.4 3.8a2.6 2.6 0 0 0-.4 2.7 4.7 4.7 0 0 0 1.8.6 3.8 3.8 0 0 0 3.7 2.8c.7 0 1.3-.2 1.8-.6l2.5 2.5a.6.6 0 0 0 .8-.1l.7-1a2.6 2.6 0 0 0 .4-2.7z" />
          <circle cx="4.8" cy="5.2" r="1.2" />
        </svg>
      </button>

      {/* دراپ‌دون */}
      {open && (
        <div style={dropdownStyle}>
          {editHref && (
            <a href={editHref} style={menuItemStyle} onClick={() => setOpen(false)}>
              ویرایش
            </a>
          )}

          {extraActions && extraActions.map((a, i) => {
            if (a.href) {
              return (
                <a key={i} href={a.href} style={menuItemStyle} onClick={() => setOpen(false)}>
                  {a.label}
                </a>
              )
            }
            if (a.action) {
              // اکشن سرور فقط داخل <form action> واقعاً اجرا می‌شه — همون الگوی onDelete پایین‌تر.
              const itemStyle = a.danger ? { ...menuItemStyle, color: '#9b1c1c', fontWeight: 700 } : menuItemStyle
              return (
                <form key={i} action={a.action} style={{ margin: 0 }}>
                  {a.confirmMessage ? (
                    <ConfirmSubmitButton message={a.confirmMessage} style={itemStyle}>
                      {a.label}
                    </ConfirmSubmitButton>
                  ) : (
                    <button type="submit" style={itemStyle}>
                      {a.label}
                    </button>
                  )}
                </form>
              )
            }
            return null
          })}

          {onDelete && (
            <div style={{ padding: '5px 10px' }}>
              {/* onDelete یه اکشن سروریه (معمولاً deleteX.bind(null, id)). چون ConfirmSubmitButton
                  از نوع type="submit" است، باید داخل <form action> باشه تا واقعاً صدا زده بشه —
                  همون الگویی که بقیه‌ی صفحات ادمین استفاده می‌کنن. */}
              <form action={onDelete}>
                <ConfirmSubmitButton
                  message={deleteConfirmMessage || 'آیا از حذف این مورد اطمینان دارید؟'}
                  style={deleteBtnStyle}
                >
                  حذف
                </ConfirmSubmitButton>
              </form>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

const triggerStyle: React.CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  width: 28,
  height: 28,
  padding: 0,
  borderRadius: 6,
  border: '1px solid #d8dde3',
  background: '#fff',
  color: '#4f5560',
  cursor: 'pointer',
  flexShrink: 0,
}

const dropdownStyle: React.CSSProperties = {
  position: 'absolute',
  top: '100%',
  right: 0,
  marginTop: 4,
  background: '#fff',
  border: '1px solid #d8dde3',
  borderRadius: 8,
  boxShadow: '0 4px 16px rgba(0,0,0,0.10)',
  zIndex: 100,
  minWidth: 120,
  overflow: 'hidden',
}

const menuItemStyle: React.CSSProperties = {
  display: 'block',
  width: '100%',
  padding: '7px 12px',
  fontSize: 12.5,
  color: '#4f5560',
  textDecoration: 'none',
  background: 'none',
  border: 'none',
  textAlign: 'right',
  cursor: 'pointer',
  fontFamily: 'inherit',
}

const deleteBtnStyle: React.CSSProperties = {
  display: 'block',
  width: '100%',
  padding: '7px 12px',
  fontSize: 12.5,
  color: '#9b1c1c',
  background: 'none',
  border: 'none',
  borderRadius: 0,
  textAlign: 'right',
  cursor: 'pointer',
  fontWeight: 700,
  fontFamily: 'inherit',
}
