'use client'

import { useCallback } from 'react'
import { useRouter } from 'next/navigation'
import { Inbox, InboxContent } from '@novu/react'
import type { InboxLocalization } from '@novu/js/ui'
import type { Notification } from '@novu/js'
import { colors, radius } from '@/lib/styles/tokens'

// ──────────────────────────────────────────────────────────
// نگاشت فارسی — همه‌ی کلیدهای InboxLocalization پوشش داده شده
// (لیست از @novu/js/dist/esm/ui/index.mjs، lines 367-425)
// ──────────────────────────────────────────────────────────
const LOCALIZATION: InboxLocalization = {
  locale: 'fa-IR',

  // فیلترها / تب‌ها
  'inbox.filters.dropdownOptions.unread': 'خوانده‌نشده',
  'inbox.filters.dropdownOptions.default': 'همه',
  'inbox.filters.dropdownOptions.archived': 'بایگانی‌شده',
  'inbox.filters.dropdownOptions.snoozed': 'به‌تعویق‌افتاده',
  'inbox.filters.labels.unread': 'خوانده‌نشده',
  'inbox.filters.labels.default': 'همه',
  'inbox.filters.labels.archived': 'بایگانی',
  'inbox.filters.labels.snoozed': 'تعویق',

  // لیست اعلان‌ها
  'notifications.emptyNotice': 'فعلاً پیامی نداری. بعداً سر بزن.',
  'notifications.actions.readAll': 'همه را خوانده‌شده کن',
  'notifications.actions.archiveAll': 'بایگانی همه',
  'notifications.actions.archiveRead': 'بایگانی خوانده‌شده‌ها',
  'notifications.newNotifications': ({ notificationCount }: { notificationCount: number }) =>
    `${notificationCount.toLocaleString('fa-IR')} پیام جدید`,

  // اکشن‌های هر اعلان
  'notification.actions.read.tooltip': 'خوانده‌شده',
  'notification.actions.unread.tooltip': 'خوانده‌نشده کن',
  'notification.actions.archive.tooltip': 'بایگانی',
  'notification.actions.unarchive.tooltip': 'از بایگانی خارج کن',
  'notification.actions.snooze.tooltip': 'تعویق',
  'notification.actions.unsnooze.tooltip': 'لغو تعویق',
  'notification.snoozedUntil': 'تا',

  // ترجیحات (با hideNav مخفی می‌شود؛ بااین‌حال ترجمه کامل است)
  'preferences.title': 'ترجیحات',
  'preferences.emptyNotice': 'ترجیحی برای نمایش وجود ندارد.',
  'preferences.global': 'عمومی',
  'preferences.schedule.title': 'زمان‌بندی',
  'preferences.schedule.description': 'زمان دریافت اعلان‌ها',
  'preferences.schedule.headerInfo': 'اعلان‌ها فقط در این بازه ارسال می‌شوند.',
  'preferences.schedule.info': 'خارج از این بازه اعلان‌ها به تعویق می‌افتند.',
  'preferences.schedule.days': 'روزها',
  'preferences.schedule.from': 'از',
  'preferences.schedule.to': 'تا',
  'preferences.schedule.copyTimesTo': 'کپی زمان به همه‌ی روزها',
  'preferences.schedule.sunday': 'یکشنبه',
  'preferences.schedule.monday': 'دوشنبه',
  'preferences.schedule.tuesday': 'سه‌شنبه',
  'preferences.schedule.wednesday': 'چهارشنبه',
  'preferences.schedule.thursday': 'پنج‌شنبه',
  'preferences.schedule.friday': 'جمعه',
  'preferences.schedule.saturday': 'شنبه',
  'preferences.schedule.dayScheduleCopy.title': 'کپی زمان‌بندی',
  'preferences.schedule.dayScheduleCopy.selectAll': 'انتخاب همه',
  'preferences.schedule.dayScheduleCopy.apply': 'اعمال',
  'preferences.workflow.disabled.notice': 'این دسته غیرفعال است.',
  'preferences.workflow.disabled.tooltip': 'توسط مدیر غیرفعال شده',
  'preferences.group.info': 'تنظیمات این گروه',

  // تعویق (snooze)
  'snooze.datePicker.timePickerLabel': 'زمان',
  'snooze.datePicker.apply': 'تأیید',
  'snooze.datePicker.cancel': 'انصراف',
  'snooze.datePicker.pastDateTooltip': 'تاریخ گذشته مجاز نیست.',
  'snooze.datePicker.noDateSelectedTooltip': 'تاریخی انتخاب نشده.',
  'snooze.datePicker.exceedingLimitTooltip': ({ days }: { days: number }) =>
    `حداکثر ${days.toLocaleString('fa-IR')} روز مجاز است.`,
  'snooze.options.anHourFromNow': 'یک ساعت دیگر',
  'snooze.options.customTime': 'زمان دلخواه',
  'snooze.options.inOneDay': 'یک روز دیگر',
  'snooze.options.inOneWeek': 'یک هفته دیگر',
}

const APPEARANCE = {
  variables: {
    colorPrimary: colors.navy,
    colorForeground: colors.textPrimary,
    colorBackground: colors.bgCard,
    colorCounter: colors.orange,
    colorCounterForeground: '#ffffff',
    fontSize: '14px',
    borderRadius: '8px',
  },
  elements: {
    root: {
      direction: 'rtl' as const,
      fontFamily: "'Vazirmatn', Tahoma, sans-serif",
    },
  },
} as const

type Props = {
  applicationIdentifier: string
  subscriberId: string
  subscriberHash: string
  backendUrl: string
  socketUrl: string
}

export default function NovuInbox(p: Props) {
  const router = useRouter()

  const routerPush = useCallback((path: string) => router.push(path), [router])

  const onNotificationClick = useCallback(
    (n: Notification) => {
      // @novu/js خودش بعد از این callback روی redirect.url ناوبری می‌کند
      // (Inbox → handleNotificationClick → navigate(redirect.url, target)).
      // پس وقتی redirect.url موجود است، اینجا ناوبری تکراری نکن.
      const redirectUrl = (n as unknown as { redirect?: { url?: string } }).redirect?.url
      if (typeof redirectUrl === 'string' && redirectUrl.length > 0) return
      const u = (n as unknown as { data?: Record<string, unknown> }).data?.url
      if (typeof u === 'string' && /^\/(?!\/)/.test(u)) router.push(u)
    },
    [router],
  )

  return (
    <div
      style={{
        height: '70vh',
        minHeight: 420,
        overflow: 'hidden',
        background: colors.bgCard,
        border: `1px solid ${colors.borderSubtle}`,
        borderRadius: radius.lg,
      }}
    >
      <Inbox
        applicationIdentifier={p.applicationIdentifier}
        subscriber={p.subscriberId}
        subscriberHash={p.subscriberHash}
        backendUrl={p.backendUrl}
        socketUrl={p.socketUrl}
        localization={LOCALIZATION}
        appearance={APPEARANCE}
        routerPush={routerPush}
      >
        <InboxContent hideNav onNotificationClick={onNotificationClick} />
      </Inbox>
    </div>
  )
}
