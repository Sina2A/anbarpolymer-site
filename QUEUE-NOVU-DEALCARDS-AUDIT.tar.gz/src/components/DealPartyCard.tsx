import type { CSSProperties, ReactNode } from 'react'
import { colors } from '@/lib/styles/tokens'

type PartyRole = 'buyer' | 'seller'

type DealPartyCardProps = {
  role: PartyRole
  secondaryLabel?: string | null
  companyName: string | null | undefined
  economicCode: string | null | undefined
  address: string | null | undefined
  verified: boolean
  children?: ReactNode
}

// Six theme values (bg, accent, title, line, role-badge bg/text) plus the role texts.
// Structure, sizes, fonts and min-height are shared, so the two cards can only differ here.
// `line` is exposed to children as the --party-line custom property for their box borders.
const PARTY_THEMES: Record<PartyRole, {
  bg: string; accent: string; title: string; line: string; badgeBg: string; badgeText: string
  icon: string; heading: string; label: string
}> = {
  buyer: { bg: '#f0f6ff', accent: '#1e357b', title: '#1e357b', line: '#dbeafe', badgeBg: colors.infoBg, badgeText: colors.infoText, icon: '🏢', heading: 'اطلاعات خریدار', label: 'خریدار' },
  seller: { bg: '#fff7ed', accent: '#ea580c', title: '#9a3412', line: '#fed7aa', badgeBg: '#ffedd5', badgeText: '#9a3412', icon: '🏭', heading: 'اطلاعات فروشنده', label: 'فروشنده' },
}

const REQUESTER_LABEL = 'درخواست‌دهنده'

function chipStyle(bg: string, color: string, extra?: CSSProperties): CSSProperties {
  return { display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 10, fontWeight: 600, background: bg, color, borderRadius: 999, padding: '2px 8px', ...extra }
}

// Presentation only: callers resolve identity, KYC and address fallbacks on the
// server and supply their own payment/action content. Never pass a raw user here.
export default function DealPartyCard({ role, secondaryLabel, companyName, economicCode, address, verified, children }: DealPartyCardProps) {
  const theme = PARTY_THEMES[role]
  const secondary = secondaryLabel === REQUESTER_LABEL
    ? { bg: colors.purpleBg, text: colors.purpleText }
    : { bg: colors.successBg, text: colors.successText }

  return (
    <div dir="rtl" style={{ ...({ '--party-line': theme.line } as CSSProperties), background: theme.bg, borderTop: `4px solid ${theme.accent}`, borderRadius: 12, padding: 14, minHeight: 420, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
      <div style={{ fontSize: 13, fontWeight: 800, color: theme.title }}>
        {`${theme.icon} ${theme.heading}`}{' '}
        <span style={chipStyle(theme.badgeBg, theme.badgeText)}>{theme.label}</span>
        {secondaryLabel && <span style={chipStyle(secondary.bg, secondary.text, { marginRight: 4 })}>{secondaryLabel}</span>}
      </div>
      <DealPartyFieldRow label="نام شرکت" value={companyName} />
      <DealPartyFieldRow label="کد اقتصادی" value={economicCode} fallback="— — کد اقتصادی ثبت نشده" />
      <DealPartyFieldRow label="آدرس" value={address} fallback="آدرس ثبت نشده" />
      <DealPartyFieldRow label="وضعیت احراز هویت" value={verified ? 'تایید‌شده ✓' : 'تایید نشده'} />
      {children}
    </div>
  )
}

export function DealPartyFieldRow({ label, value, fallback, small }: { label: string; value: string | null | undefined; fallback?: string; small?: boolean }) {
  const display = value && String(value).trim() ? String(value) : (fallback ?? '—')
  const isEmpty = !value || !String(value).trim()
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, fontSize: small ? 11 : 11.5, lineHeight: 1.8 }}>
      <span style={{ color: '#6f7680', flexShrink: 0 }}>{label}:</span>
      <span style={{ fontWeight: 600, color: isEmpty ? '#9199a3' : '#111827', textAlign: 'left', wordBreak: 'break-word' }}>{display}</span>
    </div>
  )
}
