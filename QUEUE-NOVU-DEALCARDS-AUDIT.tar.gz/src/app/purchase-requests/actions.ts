'use server'

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { requireCompanyVerifiedFor, requireVerifiedProducerFor } from '@/lib/kyc'
import { logAudit } from '@/lib/logger'
import { closeRunInTx } from '@/lib/reservationQueue'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import { PurchaseRequestSchema } from '@/schemas/purchaseRequest'

// ==================== ثبت درخواست خرید ====================

export async function createPurchaseRequestAction(formData: FormData) {
  const user = await getCurrentUser()

  // دروازه‌ی احراز هویت — سطح ۱ (هویت شرکت) کافیه برای خرید
  await requireCompanyVerifiedFor(user.id, 'U-KYC1-PURCHASEREQ')

  const gradeId = String(formData.get('gradeId') || '').trim()
  const quantityTon = parseFloat(String(formData.get('quantityTon') || ''))
  const maxPriceRaw = String(formData.get('maxPriceToman') || '').trim()
  const maxPriceToman = maxPriceRaw ? parseFloat(maxPriceRaw) : null
  const province = String(formData.get('province') || '').trim() || null
  const description = String(formData.get('description') || '').trim() || null
  const expiresInDays = parseInt(String(formData.get('expiresInDays') || '14'), 10)

  // Zod validation
  const result = PurchaseRequestSchema.safeParse({
    gradeId,
    quantityTon,
    maxPriceToman,
    deliveryLocation: province,
    notes: description,
  })
  if (!result.success) {
    const firstError = Object.values(result.error.flatten().fieldErrors)[0]?.[0] ||
                       result.error.flatten().formErrors[0] ||
                       'ورودی معتبر نیست'
    throw new Error(firstError)
  }

  // بررسی وجود گرید
  const grade = await prisma.grade.findUnique({ where: { id: gradeId }, select: { id: true, code: true, requiresProducerVerification: true } })
  if (!grade) throw new Error('گرید انتخاب‌شده وجود نداره.')

  // گیت سطح ۲ — بعضی گریدها فقط برای تولیدکننده‌ی احرازشده قابل خریدن
  if (grade.requiresProducerVerification) {
    await requireVerifiedProducerFor(user.id, 'U-KYC2-PRODUCERGRADE')
  }

  // محاسبه‌ی تاریخ انقضا
  const validDays = expiresInDays > 0 && expiresInDays <= 90 ? expiresInDays : 14
  const expiresAt = new Date(Date.now() + validDays * 24 * 60 * 60 * 1000)

  await prisma.purchaseRequest.create({
    data: {
      userId: user.id,
      gradeId: grade.id,
      quantityTon,
      maxPriceToman,
      province,
      description,
      status: 'open',
      expiresAt,
    },
  })

  await logAudit('purchase-request', `درخواست خرید ${grade.code} — ${quantityTon} تن`, user.id, {
    gradeId: grade.id,
    quantityTon,
    maxPriceToman,
    province,
    expiresInDays: validDays,
  })

  revalidatePath('/purchase-requests')
  revalidatePath('/market')
  redirect('/purchase-requests')
}

// ==================== بستن درخواست توسط خریدار ====================

export async function closePurchaseRequestAction(formData: FormData) {
  const user = await getCurrentUser()

  const requestId = String(formData.get('requestId') || '').trim()
  if (!requestId) throw new Error('شناسه‌ی درخواست مشخص نیست.')

  const pr = await prisma.purchaseRequest.findUnique({ where: { id: requestId } })
  if (!pr) throw new Error('درخواست پیدا نشد.')
  if (pr.userId !== user.id) throw new Error('فقط خودِ خریدار می‌تونه درخواستش رو ببنده.')
  if (pr.status !== 'open') throw new Error('این درخواست قبلاً بسته شده.')

  // بستن شرطی روی status:'open' (نه update بی‌قید) تا اگر هم‌زمان کسی درخواست را پذیرفت (reserved)
  // و معامله ساخت، این بستن آن را زیر پای معامله نبندد. صفِ رزرو هم (دفاعی) در همان تراکنش بسته می‌شود.
  await prisma.$transaction(async (tx) => {
    const closed = await tx.purchaseRequest.updateMany({
      where: { id: requestId, status: 'open' },
      data: { status: 'closed' },
    })
    if (closed.count === 0) throw new Error('این درخواست قبلاً بسته شده.')
    await closeRunInTx(tx, 'BUY', requestId)
  })

  await logAudit('purchase-request', `درخواست خرید ${requestId.slice(0, 8)} بسته شد`, user.id)

  revalidatePath('/purchase-requests')
  revalidatePath('/market')
}
