import { createHmac } from 'node:crypto'
import { getSurfaceHome } from '@/lib/surfaceHome'
import { getCurrentUser } from '@/lib/currentUser'
import UserNav from '@/components/UserNav'
import PanelHeader from '@/components/PanelHeader'
import Footer from '@/components/Footer'
import NovuInbox from '@/components/NovuInbox'
import { colors, spacing, fontSize } from '@/lib/styles/tokens'
import { cardStyle as sharedCardStyle, emptyStateStyle } from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

export default async function InboxPage() {
  const user = await getCurrentUser()

  const appId = (process.env.NOVU_APP_IDENTIFIER ?? '').trim()
  const backendUrl = (process.env.NOVU_BACKEND_URL ?? '').trim()
  const socketUrl = (process.env.NOVU_SOCKET_URL ?? '').trim()
  const secret = (process.env.NOVU_SECRET_KEY ?? '').trim()

  const ready = Boolean(appId && backendUrl && socketUrl && secret)
  const subscriberHash = ready
    ? createHmac('sha256', secret).update(user.id).digest('hex')
    : ''

  return (
    <>
      <PanelHeader homeHref={getSurfaceHome()} currentUserName={user.companyName} />
      <div
        className="admin-page-wrap"
        style={{
          display: 'flex',
          gap: spacing.xl,
          padding: `${spacing.xxl}px ${spacing.xl}px`,
          fontFamily: "'Vazirmatn', Tahoma, sans-serif",
          direction: 'rtl',
          width: '100%',
          background: colors.bgCard,
          minHeight: '100vh',
        }}
      >
        <UserNav currentUserName={user.companyName} activeSection="inbox" />

        <div style={{ flex: 1, minWidth: 0 }}>
          <h1
            style={{
              fontSize: fontSize.xxl,
              fontWeight: 800,
              marginBottom: spacing.sm,
              color: colors.textPrimary,
            }}
          >
            صندوق پیام‌ها
          </h1>
          <p style={{ color: colors.textSecondary, fontSize: fontSize.md, marginBottom: 22, lineHeight: 1.9 }}>
            اعلان‌های نوبت رزرو و به‌روزرسانی معامله‌ها همین‌جا نمایش داده می‌شود.
          </p>

          {!ready ? (
            <div style={emptyStateStyle}>
              صندوق پیام هنوز راه‌اندازی نشده است. مدیر سیستم باید کلیدهای Novu را در متغیرهای محیطی تنظیم کند.
            </div>
          ) : (
            <NovuInbox
              applicationIdentifier={appId}
              subscriberId={user.id}
              subscriberHash={subscriberHash}
              backendUrl={backendUrl}
              socketUrl={socketUrl}
            />
          )}
        </div>
      </div>
      <Footer homeHref={getSurfaceHome()} />
    </>
  )
}
