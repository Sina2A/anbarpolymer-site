'use server'

// اکشن‌های پنل مدیریت آگهی‌های عرضه مواد اولیه:
//   updateListingStatusAction — تغییر وضعیت validityStatus یک آگهی
//
// وضعیت‌های مجاز:
//   active → reserved (توقف)  |  reserved → active (فعالسازی مجدد)
//   needs_reverification → active (تایید انتشار مجدد پس از لغو توسط ثبت‌کننده)
//   هر وضعیتی → cancelled (حذف به دلیل تخلف)
//
// صفِ رزرو: ورود به active هرگز مستقیم نیست و از releaseItemInTx می‌گذرد. اگر کسی در صفِ رزروِ
// این آگهی منتظر باشد آگهی 'reserved' می‌ماند و نفر اول مطلع می‌شود؛ فقط بدون صف active می‌شود.
// تا وقتی مهلتِ یک claimِ زنده باقی است فعال‌سازی ممکن نیست (خطا). cancel صفِ رزرو را هم می‌بندد.

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import { AccessDeniedError } from '@/lib/errorCodes'
import { logAudit } from '@/lib/logger'
import {
  releaseItemInTx,
  closeRunInTx,
  notifyPromoted,
  type PromoteResult,
} from '@/lib/reservationQueue'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'

/** چک دسترسی نوشتن روی بخش «material-listings» */
async function requireListingEditAccess() {
  const user = await getCurrentUser()
  if (user.role === 'admin') return user
  const access = await getAllSectionAccess(user.id)
  if (access['material-listings'] !== 'edit' && access['material-listings'] !== 'full') {
    throw new AccessDeniedError(
      'A-SECTION-MATERIAL-LISTINGS',
      'دسترسی مدیریت آگهی‌ها رو نداری — از مدیر بخواه بهت بده.'
    )
  }
  return user
}

// ================================================================ تغییر وضعیت

const VALID_TRANSITIONS: Record<string, string> = {
  active: 'reserved',
  reserved: 'active',
  // پس از لغو معامله توسط ثبت‌کننده، آگهی به needs_reverification می‌رود؛ کارشناس با
  // همان دکمه‌ی toggle آن را دوباره منتشر (active) می‌کند.
  needs_reverification: 'active',
}

export async function updateListingStatusAction(formData: FormData) {
  const user = await requireListingEditAccess()

  const id = formData.get('id') as string
  const action = formData.get('action') as string

  if (!id || !action) throw new Error('شناسه آگهی و نوع عملیات الزامی است.')

  const listing = await prisma.materialListing.findUnique({ where: { id } })
  if (!listing) throw new Error('آگهی یافت نشد.')

  let newStatus: string | null = null

  if (action === 'toggle') {
    const target = VALID_TRANSITIONS[listing.validityStatus]
    if (!target) {
      throw new Error(
        `وضعیت فعلی «${listing.validityStatus}» قابل تغییر نیست.`
      )
    }
    newStatus = target
  } else if (action === 'cancel') {
    newStatus = 'cancelled'
  } else {
    throw new Error('عملیات نامعتبر.')
  }

  const from = listing.validityStatus
  const toStatus: string = newStatus
  let finalStatus: string = toStatus
  let actionLabel: string
  let promote: PromoteResult | null = null
  let queueClosed = 0

  if (action === 'cancel') {
    // حذف به دلیل تخلف: آگهی برای همیشه از بازار می‌رود ⇒ صفِ رزروش هم در همان تراکنش بسته می‌شود.
    queueClosed = await prisma.$transaction(async (tx) => {
      await tx.materialListing.update({
        where: { id },
        data: { validityStatus: 'cancelled', reviewedById: user.id, reviewedAt: new Date() },
      })
      return (await closeRunInTx(tx, 'SELL', id)).closed
    })
    actionLabel = `به «cancelled» تغییر یافت (حذف به دلیل تخلف)`
  } else if (toStatus === 'active') {
    // reserved → active و needs_reverification → active از مسیرِ صفِ رزرو: وضعیت را خودِ
    // releaseItemInTx شرطی تغییر می‌دهد (نفر اولِ صف مطلع می‌شود یا آگهی به بازار برمی‌گردد)،
    // و مُهرِ بازبینی فقط وقتی ثبت می‌شود که واقعاً چیزی تغییر کرده باشد.
    const released = await prisma.$transaction(async (tx) => {
      const res = await releaseItemInTx(tx, 'SELL', id, from)
      if (!res.promoted && !res.returnedToPool) return null
      await tx.materialListing.update({
        where: { id },
        data: { reviewedById: user.id, reviewedAt: new Date() },
      })
      return res
    })
    if (!released) {
      // یا claimِ زنده‌ای برای نفرِ صف باقی است، یا وضعیتِ آگهی هم‌زمان عوض شده.
      throw new Error(
        'تغییر وضعیت ممکن نشد: آگهی هم‌اکنون برای نفرِ صفِ رزرو نگه‌داشته شده یا وضعیتش هم‌زمان عوض شده است. صفحه را تازه کنید.'
      )
    }
    promote = released
    if (released.promoted) {
      finalStatus = 'reserved'
      actionLabel =
        from === 'reserved'
          ? `آزاد شد و به نفر بعدیِ صفِ رزرو رسید (وضعیت «reserved» می‌ماند)`
          : `از «${from}» به «reserved» تغییر یافت (نفر اولِ صفِ رزرو مطلع شد)`
    } else {
      finalStatus = 'active'
      actionLabel = `از «${from}» به «active» تغییر یافت`
    }
  } else {
    // active → reserved (توقفِ دستی)
    await prisma.materialListing.update({
      where: { id },
      data: { validityStatus: toStatus, reviewedById: user.id, reviewedAt: new Date() },
    })
    actionLabel = `از «${from}» به «${toStatus}» تغییر یافت`
  }

  // اعلانِ صف بعد از commit و قبل از redirect (redirect با throw کار می‌کند).
  if (promote) await notifyPromoted('SELL', id, promote)

  await logAudit(
    'material-listings',
    `آگهی ${listing.gradeId} (${listing.id}): ${actionLabel}`,
    user.id,
    {
      listingId: id,
      from,
      to: finalStatus,
      ...(queueClosed > 0 ? { queueEntriesClosed: queueClosed } : {}),
      ...(promote?.promoted ? { queuePromotedUserId: promote.promoted.userId } : {}),
    }
  )
  revalidatePath('/admin-material-listings')
  redirect('/admin-material-listings?updated=1')
}
