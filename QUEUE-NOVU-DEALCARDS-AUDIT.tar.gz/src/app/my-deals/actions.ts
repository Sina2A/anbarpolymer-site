'use server'

import prisma from '@/lib/prisma'
import { revalidatePath } from 'next/cache'
import { getCurrentUser } from '@/lib/currentUser'
import { startBuyerPaymentDeadline } from '@/lib/dealDeadlines'
import { savePaymentReceipt } from '@/lib/paymentReceipt'
import { submitDiscrepancyReport } from '@/lib/disputes'
import { logAudit } from '@/lib/logger'
import { isDealSeller } from '@/lib/dealRoles'
import { dealItemRef, releaseItemInTx, notifyPromoted } from '@/lib/reservationQueue'

/**
 * کنش‌های سمت سرور پنل «معاملات من».
 * دو طرف معامله از روی خود رکورد Deal تشخیص داده می‌شن:
 *   خریدار  = deal.buyerId
 *   فروشنده = deal.sellerId (snapshot v2) با فالبک به deal.materialListing.userId (معامله‌های legacy)
 * همه‌ی چک‌های دسترسی همین‌جا و مستقل از UI انجام می‌شن.
 */

/** وضعیت‌هایی که معامله (قبل از بارگیری) قابل لغو دستی‌ست */
const CANCELABLE_STATUSES = ['draft', 'awaiting_approval', 'confirmed', 'seller_fee_paid']

/**
 * فروشنده، پیشنهادِ پیش‌نویس یک خریدار رو می‌پذیره. بعد از پذیرش، مهلت
 * پرداخت خریدار شروع می‌شه؛ اگه قیمت توافقی نیاز به تایید کارشناس داشته
 * باشه، startBuyerPaymentDeadline خودش وضعیت رو روی awaiting_approval می‌ذاره.
 */
export async function acceptDealOfferAction(dealId: string) {
  const user = await getCurrentUser()

  const deal = await prisma.deal.findUnique({
    where: { id: dealId },
    include: { materialListing: true },
  })
  if (!deal) throw new Error('معامله پیدا نشد.')
  if (deal.status !== 'draft') throw new Error('این پیشنهاد دیگر در وضعیت پذیرش نیست.')
  if (!isDealSeller(deal, user.id)) throw new Error('فقط فروشنده می‌تونه پیشنهاد رو بپذیره.')

  // در هر دو حالت (قیمت‌دار / بدون قیمت) همین تابع وضعیت و مهلت رو می‌چینه
  await startBuyerPaymentDeadline(dealId, false)

  await logAudit('deal', 'قبول پیشنهاد', user.id, { dealId, action: 'offer_accepted' })
  revalidatePath('/my-deals')
}

/**
 * فروشنده، پیشنهادِ پیش‌نویس رو رد می‌کنه: معامله لغو می‌شه و مورد رزروشده (آگهی یا
 * درخواست خرید) از مسیر صفِ رزرو آزاد می‌شه — اگه کسی تو صف باشه نفر بعدی مطلع می‌شه و
 * فقط وقتی صفی نباشه مورد به بازار برمی‌گرده. لغو و آزادسازی در یک تراکنش‌اند و گاردِ
 * وضعیت (draft) داخل خودِ UPDATE است تا دو رد هم‌زمان دو بار آزادسازی نکنند.
 */
export async function rejectDealOfferAction(dealId: string) {
  const user = await getCurrentUser()

  const deal = await prisma.deal.findUnique({
    where: { id: dealId },
    include: { materialListing: true },
  })
  if (!deal) throw new Error('معامله پیدا نشد.')
  if (deal.status !== 'draft') throw new Error('این پیشنهاد دیگر در وضعیت پذیرش نیست.')
  if (!isDealSeller(deal, user.id)) throw new Error('فقط فروشنده می‌تونه پیشنهاد رو رد کنه.')

  const ref = dealItemRef(deal)
  const outcome = await prisma.$transaction(async (tx) => {
    const cancelled = await tx.deal.updateMany({
      where: { id: dealId, status: 'draft' },
      data: { status: 'cancelled' },
    })
    if (cancelled.count === 0) return null
    return { promote: ref ? await releaseItemInTx(tx, ref.itemType, ref.itemId) : null }
  })
  if (!outcome) throw new Error('این پیشنهاد دیگر در وضعیت پذیرش نیست.')

  await logAudit('deal', 'رد پیشنهاد', user.id, { dealId, action: 'offer_rejected' })
  revalidatePath('/my-deals')
  if (ref && outcome.promote) await notifyPromoted(ref.itemType, ref.itemId, outcome.promote)
}

/**
 * هر طرف رسید پرداخت خودش رو آپلود می‌کنه — بسته به kind:
 *   BUYER_GOODS  → خریدار (deal.buyerId)، بهای بار
 *   SELLER_FEE   → فروشنده (deal.sellerId)، کارمزد معامله
 * گیت روی خودِ ردیف DealPayment است (نه status معامله): فقط وقتی هنوز
 * رسیدی روی اون ردیف ثبت نشده. رسید روی همون ردیف نوشته می‌شه، نه فیلد
 * قدیمی Deal.paymentReceiptUrl. تایید نهایی با ادمین است (approvePaymentAction).
 */
export async function uploadDealPaymentReceiptAction(formData: FormData) {
  const dealId = String(formData.get('dealId') || '')
  const kind = String(formData.get('kind') || '')
  const file = formData.get('receiptFile') as File | null

  const user = await getCurrentUser()
  if (!dealId || !file || file.size === 0) return
  if (kind !== 'BUYER_GOODS' && kind !== 'SELLER_FEE') throw new Error('نوع پرداخت نامعتبر است.')

  const deal = await prisma.deal.findUnique({ where: { id: dealId } })
  if (!deal) throw new Error('معامله پیدا نشد.')

  // نقش مجاز بر اساس kind تعیین می‌شه؛ طرفِ دیگه (یا کاربر ثالث) نمی‌تونه رسید طرف مقابل رو ثبت کنه.
  const payerId = kind === 'BUYER_GOODS' ? deal.buyerId : deal.sellerId
  if (!payerId || user.id !== payerId) {
    throw new Error(
      kind === 'BUYER_GOODS'
        ? 'فقط خریدار می‌تونه رسید پرداخت بها رو ثبت کنه.'
        : 'فقط فروشنده می‌تونه رسید کارمزد رو ثبت کنه.',
    )
  }

  const payment = await prisma.dealPayment.findUnique({
    where: { dealId_kind: { dealId, kind } },
  })
  if (!payment) throw new Error('ردیف پرداخت این معامله پیدا نشد.')
  if (payment.receiptUrl) throw new Error('رسید این پرداخت قبلاً ثبت شده.')

  const url = await savePaymentReceipt(file)

  // نوشتن race-safe/idempotent روی همون ردیف: فقط اگه هنوز رسیدی نداشته باشه.
  const res = await prisma.dealPayment.updateMany({
    where: { dealId, kind, receiptUrl: null },
    data: { receiptUrl: url, submittedAt: new Date(), status: 'SUBMITTED' },
  })
  if (res.count === 0) throw new Error('در وضعیت جاری امکان ثبت رسید پرداخت وجود ندارد.')

  await logAudit('deal', 'ثبت رسید پرداخت', user.id, {
    dealId,
    action: 'payment_receipt_uploaded',
    kind,
  })
  revalidatePath(`/my-deals/${dealId}`)
}

/**
 * خریدار، گزارش مغایرت کیفی رو توی پنجره‌ی مهلت اعلام می‌کنه. موارد انتخابی
 * از formData.getAll('items') گرفته می‌شن؛ submitDiscrepancyReport خودش حساس/جزئی
 * بودن رو تشخیص می‌ده و در صورت لزوم تایمر واریز رو فریز و Dispute باز می‌کنه.
 */
export async function reportDiscrepancyAction(formData: FormData) {
  const dealId = String(formData.get('dealId') || '')
  const note = String(formData.get('note') || '').trim()
  const selectedItems = formData.getAll('items').map((v) => String(v)).filter(Boolean)

  const user = await getCurrentUser()
  if (!dealId || selectedItems.length === 0) return

  const deal = await prisma.deal.findUnique({ where: { id: dealId } })
  if (!deal) throw new Error('معامله پیدا نشد.')
  if (user.id !== deal.buyerId) throw new Error('فقط خریدار می‌تونه مغایرت گزارش کنه.')

  await submitDiscrepancyReport({ dealId, raisedById: user.id, selectedItems, note })

  await logAudit('deal', 'ثبت گزارش مغایرت', user.id, { dealId, action: 'discrepancy_reported', count: selectedItems.length })
  revalidatePath(`/my-deals/${dealId}`)
}

/**
 * لغو دستی معامله — هر دو طرف (درخواست‌دهنده یا پذیرنده)، فقط تا پیش از مرحله‌ی
 * بارگیری (draft/awaiting_approval/confirmed/seller_fee_paid). لغو داوطلبانه است و
 * جریمه‌ای ندارد. سرنوشتِ مبدأ (آگهی فروش / درخواست خرید) بسته به اینکه چه کسی لغو
 * می‌کند فرق دارد:
 *   • لغو توسط درخواست‌دهنده → وضعیت میانی که نیاز به تایید دستی ادمین دارد و تا آن
 *     زمان از بازار پنهان می‌ماند: SELL ⇒ آگهی 'needs_reverification' ؛
 *     BUY ⇒ درخواست 'needs_review'.
 *   • لغو توسط پذیرنده → بازگشت به بازار از مسیر صفِ رزرو (releaseItemInTx): اگر کسی در
 *     صف منتظر باشد نفر اول مطلع می‌شود و مورد (SELL ⇒ آگهی / BUY ⇒ درخواست) همچنان
 *     'reserved' می‌ماند؛ فقط وقتی صفی نباشد آگهی 'active' / درخواست 'open' می‌شود.
 *   • لغو توسط درخواست‌دهنده، صف را «متوقف» می‌کند (مورد پنهان است و کسی مطلع نمی‌شود)؛
 *     وقتی ادمین دوباره تاییدش کرد، همان‌جا نفر اولِ صف نوبت می‌گیرد.
 * نقش‌ها با فالبک مدل ۴نقشی v2 استخراج می‌شن تا رکوردهای legacy (فقط buyerId/sellerId)
 * هم درست کار کنن.
 */
export async function cancelDealAction(formData: FormData) {
  const dealId = String(formData.get('dealId') || '')
  const reason = String(formData.get('reason') || '').trim()

  const user = await getCurrentUser()
  if (!dealId) return

  const deal = await prisma.deal.findUnique({
    where: { id: dealId },
    include: { materialListing: true, purchaseRequest: true },
  })
  if (!deal) throw new Error('معامله پیدا نشد.')

  const dir = deal.tradeDirection || 'SELL'
  const requesterId = deal.requesterId ?? (dir === 'SELL' ? deal.sellerId : deal.buyerId)
  const acceptorId = deal.acceptorId ?? (dir === 'SELL' ? deal.buyerId : deal.sellerId)

  const userIsRequester = requesterId != null && user.id === requesterId
  const userIsAcceptor = acceptorId != null && user.id === acceptorId
  if (!userIsRequester && !userIsAcceptor) throw new Error('شما طرف این معامله نیستید.')
  if (!CANCELABLE_STATUSES.includes(deal.status)) throw new Error('این معامله در وضعیت جاری قابل لغو نیست.')

  const ref = dealItemRef(deal)
  const promote = await prisma.$transaction(async (tx) => {
    // لغو race-safe: فقط اگر معامله هنوز در وضعیت قابل‌لغو باشد وضعیتش را cancelled می‌کنیم
    const cancelled = await tx.deal.updateMany({
      where: { id: dealId, status: { in: CANCELABLE_STATUSES } },
      data: { status: 'cancelled' },
    })
    if (cancelled.count === 0) throw new Error('این معامله در وضعیت جاری قابل لغو نیست.')
    if (!ref) return null

    // بازگردانی مبدأ بسته به اینکه چه کسی لغو کرده
    if (userIsRequester) {
      // وضعیت میانیِ پنهان (نیازمند تاییدِ دستیِ ادمین) — صفِ رزرو در همین حالت متوقف می‌ماند
      if (ref.itemType === 'SELL') {
        await tx.materialListing.update({ where: { id: ref.itemId }, data: { validityStatus: 'needs_reverification' } })
      } else {
        await tx.purchaseRequest.update({ where: { id: ref.itemId }, data: { status: 'needs_review' } })
      }
      return null
    }
    // پذیرنده: آزادسازیِ queue-aware (نفر بعدیِ صف، یا برگشت به بازار) — اتمیک با لغو
    return releaseItemInTx(tx, ref.itemType, ref.itemId)
  })

  await logAudit('deal', 'لغو معامله', user.id, {
    dealId,
    action: 'deal_cancelled',
    reason: reason || null,
    by: userIsRequester ? 'requester' : 'acceptor',
  })
  revalidatePath('/my-deals')
  revalidatePath(`/my-deals/${dealId}`)
  if (ref && promote) await notifyPromoted(ref.itemType, ref.itemId, promote)
}
