-- Reservation queue + seller-side payment instructions.
-- Both additions are backward-safe (new nullable column + brand-new table).

-- 1) Seller-side payment instructions on Deal (nullable -> existing rows keep NULL;
--    UI falls back to the buyer-side paymentInstructionsText when this is empty).
ALTER TABLE "Deal" ADD COLUMN "sellerPaymentInstructionsText" TEXT;

-- 2) Reservation queue table.
--    itemType 'SELL' -> MaterialListing, 'BUY' -> PurchaseRequest (light polymorphic
--    link, no FK because it targets two tables). enteredAt is the authoritative FIFO
--    timestamp (the item models lack updatedAt). queueRunId isolates queue generations.
CREATE TABLE "ReservationQueueEntry" (
    "id" TEXT NOT NULL,
    "itemType" TEXT NOT NULL,
    "itemId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "enteredAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "status" TEXT NOT NULL DEFAULT 'waiting',
    "queueRunId" TEXT NOT NULL,
    "notifiedAt" TIMESTAMP(3),
    "claimExpiresAt" TIMESTAMP(3),
    "acceptedAt" TIMESTAMP(3),
    "declinedAt" TIMESTAMP(3),
    "expiredAt" TIMESTAMP(3),
    "notificationTransactionId" TEXT,
    "lastError" TEXT,

    CONSTRAINT "ReservationQueueEntry_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "ReservationQueueEntry_notificationTransactionId_key" ON "ReservationQueueEntry"("notificationTransactionId");
CREATE INDEX "ReservationQueueEntry_itemType_itemId_queueRunId_status_idx" ON "ReservationQueueEntry"("itemType", "itemId", "queueRunId", "status");
CREATE INDEX "ReservationQueueEntry_itemType_itemId_status_enteredAt_idx" ON "ReservationQueueEntry"("itemType", "itemId", "status", "enteredAt");
CREATE INDEX "ReservationQueueEntry_status_claimExpiresAt_idx" ON "ReservationQueueEntry"("status", "claimExpiresAt");
CREATE INDEX "ReservationQueueEntry_userId_status_idx" ON "ReservationQueueEntry"("userId", "status");

-- AddForeignKey
ALTER TABLE "ReservationQueueEntry" ADD CONSTRAINT "ReservationQueueEntry_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
