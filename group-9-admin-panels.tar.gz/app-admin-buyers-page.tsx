import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import type { AccessLevel } from '@/lib/sections'
import AdminNav, { PartialAccessBanner } from '@/components/AdminNav'

export const dynamic = 'force-dynamic'

export default async function AdminBuyersPage() {
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)

  const level: AccessLevel = isAdmin ? 'full' : ((myAccess?.buyers as AccessLevel) ?? 'none')
  const hasAccess = level !== 'none'

  const buyers = hasAccess
    ? await prisma.user.findMany({
        where: { role: 'buyer', isActive: true },
        include: {
          company: {
            select: {
              nationalId: true,
              registrationNumber: true,
              kyc: { select: { level: true, verifiedAt: true } },
            },
          },
          _count: {
            select: {
              orders: true,
              purchaseRequests: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      })
    : []

  return (
    <div
      className="admin-page-wrap"
      style={{
        display: 'flex',
        gap: 24,
        padding: '32px 24px',
        fontFamily: "'Vazirmatn', Tahoma, sans-serif",
        direction: 'rtl',
        maxWidth: 1300,
        margin: '0 auto',
      }}
    >
      <AdminNav
        currentUserName={currentUser.companyName}
        isAdmin={isAdmin}
        accessMap={myAccess || {}}
        activeSection="buyers"
      />

      <div style={{ flex: 1, minWidth: 0 }}>
        <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>مدیریت خریداران</h1>
        <p style={{ fontSize: 13, color: '#9199a3', marginBottom: 24 }}>
          نمای مدیریتی کاربران با نقش خریدار — {buyers.length} خریدار فعال
        </p>

        <PartialAccessBanner level={level} sectionLabel="خریداران" />

        {!hasAccess && <div style={emptyBoxStyle}>به بخش «خریداران» دسترسی نداری.</div>}

        {hasAccess && (
          <>
            {buyers.length === 0 ? (
              <div style={emptyBoxStyle}>هیچ خریدار فعالی ثبت نشده.</div>
            ) : (
              <div style={cardStyle}>
                <div style={tableWrapStyle}>
                  <table style={tableStyle}>
                    <thead>
                      <tr style={{ background: '#f7f8fa' }}>
                        <th style={thStyle}>نام شرکت</th>
                        <th style={thStyle}>شناسه ملی</th>
                        <th style={thStyle}>شماره ثبت</th>
                        <th style={thStyle}>وضعیت KYC</th>
                        <th style={thStyle}>تاریخ تایید</th>
                        <th style={thStyle}>سفارش‌ها</th>
                        <th style={thStyle}>درخواست‌های خرید</th>
                        <th style={thStyle}>تاریخ عضویت</th>
                      </tr>
                    </thead>
                    <tbody>
                      {buyers.map((buyer) => {
                        const kycLevel = buyer.company?.kyc?.level ?? 0
                        const kycVerifiedAt = buyer.company?.kyc?.verifiedAt

                        const kycBadge =
                          kycLevel === 0 ? (
                            <span style={kycBadgeStyle('#f3f4f6', '#6b7280')}>احراز نشده</span>
                          ) : kycLevel === 1 ? (
                            <span style={kycBadgeStyle('#fef3c7', '#92400e')}>سطح ۱</span>
                          ) : (
                            <span style={kycBadgeStyle('#d1fae5', '#065f46')}>سطح ۲</span>
                          )

                        return (
                          <tr key={buyer.id} style={{ borderTop: '1px solid #eceff3' }}>
                            <td style={{ ...tdStyle, fontWeight: 700 }}>{buyer.companyName}</td>
                            <td style={{ ...tdStyle, fontFamily: 'monospace', direction: 'ltr', textAlign: 'right' }}>
                              {buyer.company?.nationalId || '—'}
                            </td>
                            <td style={{ ...tdStyle, fontFamily: 'monospace', direction: 'ltr', textAlign: 'right' }}>
                              {buyer.company?.registrationNumber || '—'}
                            </td>
                            <td style={tdStyle}>{kycBadge}</td>
                            <td style={{ ...tdStyle, fontSize: 11.5, color: '#6f7680' }}>
                              {kycVerifiedAt ? new Date(kycVerifiedAt).toLocaleDateString('fa-IR') : '—'}
                            </td>
                            <td style={{ ...tdStyle, fontFamily: 'monospace', textAlign: 'center' }}>
                              {buyer._count.orders}
                            </td>
                            <td style={{ ...tdStyle, fontFamily: 'monospace', textAlign: 'center' }}>
                              {buyer._count.purchaseRequests}
                            </td>
                            <td style={{ ...tdStyle, fontSize: 11.5, color: '#6f7680' }}>
                              {new Date(buyer.createdAt).toLocaleDateString('fa-IR')}
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}

const kycBadgeStyle = (bg: string, fg: string): React.CSSProperties => ({
  fontSize: 10.5,
  fontWeight: 700,
  background: bg,
  color: fg,
  borderRadius: 6,
  padding: '3px 10px',
  display: 'inline-block',
})

const emptyBoxStyle: React.CSSProperties = {
  padding: 24,
  textAlign: 'center',
  color: '#9199a3',
  border: '1px dashed #d8dde3',
  borderRadius: 12,
  fontSize: 12.5,
  marginBottom: 20,
}
const cardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 14,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
  marginBottom: 8,
}
const tableWrapStyle: React.CSSProperties = {
  overflowX: 'auto',
}
const tableStyle: React.CSSProperties = {
  width: '100%',
  borderCollapse: 'collapse',
  fontSize: 12.5,
}
const thStyle: React.CSSProperties = {
  textAlign: 'right',
  fontSize: 11,
  color: '#6f7680',
  padding: '8px 10px',
  fontWeight: 700,
}
const tdStyle: React.CSSProperties = { padding: '9px 10px', fontSize: 12.5 }
