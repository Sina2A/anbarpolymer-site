import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import type { AccessLevel } from '@/lib/sections'
import AdminNav, { PartialAccessBanner } from '@/components/AdminNav'

export const dynamic = 'force-dynamic'

export default async function AdminWarehousesPage() {
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)

  const level: AccessLevel = isAdmin ? 'full' : ((myAccess?.warehouses as AccessLevel) ?? 'none')
  const hasAccess = level !== 'none'

  const warehouses = hasAccess
    ? await prisma.warehouse.findMany({
        include: {
          stock: {
            include: { grade: { select: { code: true, category: true } } },
            orderBy: { updatedAt: 'desc' },
          },
          _count: { select: { stock: true, orderItems: true } },
        },
        orderBy: { name: 'asc' },
      })
    : []

  return (
    <div
      className="admin-page-wrap"
      style={{
        display: 'flex',
        gap: 24,
        padding: '32px 24px',
        fontFamily: "'Vazirmatn', Tahoma, sans-serif",
        direction: 'rtl',
        maxWidth: 1300,
        margin: '0 auto',
      }}
    >
      <AdminNav
        currentUserName={currentUser.companyName}
        isAdmin={isAdmin}
        accessMap={myAccess || {}}
        activeSection="warehouses"
      />

      <div style={{ flex: 1, minWidth: 0 }}>
        <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>انبارها و موجودی</h1>
        <p style={{ fontSize: 13, color: '#9199a3', marginBottom: 24 }}>
          مدیریت انبارهای انبار پلیمر و موجودی هر گرید در هر انبار
        </p>

        <PartialAccessBanner level={level} sectionLabel="انبارها و موجودی" />

        {!hasAccess && <div style={emptyBoxStyle}>به بخش «انبارها و موجودی» دسترسی نداری.</div>}

        {hasAccess && (
          <>
            {warehouses.length === 0 ? (
              <div style={emptyBoxStyle}>هیچ انباری ثبت نشده.</div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
                {warehouses.map((wh) => (
                  <div key={wh.id} style={warehouseCardStyle}>
                    <div style={warehouseHeadStyle}>
                      <div>
                        <h3 style={{ fontSize: 17, fontWeight: 800, margin: 0 }}>{wh.name}</h3>
                        <div style={{ fontSize: 12.5, color: '#6f7680', marginTop: 2 }}>
                          {wh.city}
                          {wh.address && <> — {wh.address}</>}
                        </div>
                      </div>
                      <div style={{ display: 'flex', gap: 12, fontSize: 12, color: '#9199a3' }}>
                        <span>
                          <b style={{ color: '#1b1e24' }}>{wh._count.stock}</b> گرید
                        </span>
                        <span>•</span>
                        <span>
                          <b style={{ color: '#1b1e24' }}>{wh._count.orderItems}</b> سفارش
                        </span>
                      </div>
                    </div>

                    {wh.description && (
                      <div style={{ fontSize: 12.5, color: '#4f5560', marginBottom: 12, lineHeight: 1.7 }}>
                        {wh.description}
                      </div>
                    )}

                    {wh.stock.length === 0 ? (
                      <div style={emptyStockStyle}>هیچ موجودی‌ای در این انبار ثبت نشده.</div>
                    ) : (
                      <div style={tableWrapStyle}>
                        <table style={tableStyle}>
                          <thead>
                            <tr style={{ background: '#f7f8fa' }}>
                              <th style={thStyle}>کد گرید</th>
                              <th style={thStyle}>دسته</th>
                              <th style={thStyle}>مقدار (تن)</th>
                              <th style={thStyle}>قیمت (ریال/کیلو)</th>
                              <th style={thStyle}>بچ</th>
                              <th style={thStyle}>آخرین بروزرسانی</th>
                            </tr>
                          </thead>
                          <tbody>
                            {wh.stock.map((st) => (
                              <tr key={st.id} style={{ borderTop: '1px solid #eceff3' }}>
                                <td style={{ ...tdStyle, fontFamily: 'monospace', fontWeight: 700 }}>
                                  {st.grade.code}
                                </td>
                                <td style={tdStyle}>{st.grade.category}</td>
                                <td style={{ ...tdStyle, fontFamily: 'monospace', direction: 'ltr', textAlign: 'right' }}>
                                  {st.quantityTon.toLocaleString('en-US')}
                                </td>
                                <td style={{ ...tdStyle, fontFamily: 'monospace', direction: 'ltr', textAlign: 'right' }}>
                                  {st.priceRial.toLocaleString('en-US')}
                                </td>
                                <td style={{ ...tdStyle, fontFamily: 'monospace', color: '#6f7680' }}>
                                  {st.batch || '—'}
                                </td>
                                <td style={{ ...tdStyle, fontSize: 11.5, color: '#6f7680' }}>
                                  {new Date(st.updatedAt).toLocaleDateString('fa-IR')}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}

const emptyBoxStyle: React.CSSProperties = {
  padding: 24,
  textAlign: 'center',
  color: '#9199a3',
  border: '1px dashed #d8dde3',
  borderRadius: 12,
  fontSize: 12.5,
  marginBottom: 20,
}
const warehouseCardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 18,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const warehouseHeadStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'flex-start',
  marginBottom: 14,
  flexWrap: 'wrap',
  gap: 12,
}
const emptyStockStyle: React.CSSProperties = {
  padding: 16,
  textAlign: 'center',
  color: '#9199a3',
  fontSize: 12,
  background: '#f7f8fa',
  borderRadius: 8,
}
const tableWrapStyle: React.CSSProperties = {
  overflowX: 'auto',
  border: '1px solid #eceff3',
  borderRadius: 8,
}
const tableStyle: React.CSSProperties = {
  width: '100%',
  borderCollapse: 'collapse',
  fontSize: 12.5,
}
const thStyle: React.CSSProperties = {
  textAlign: 'right',
  fontSize: 11,
  color: '#6f7680',
  padding: '8px 10px',
  fontWeight: 700,
}
const tdStyle: React.CSSProperties = { padding: '9px 10px', fontSize: 12.5 }
