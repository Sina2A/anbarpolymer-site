export type CreateTransportCompanyState = {
  status: 'idle' | 'error' | 'success'
  message: string
}
