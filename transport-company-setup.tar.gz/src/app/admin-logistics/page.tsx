import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import AdminNav, { PartialAccessBanner } from '@/components/AdminNav'
import { regenerateDriverLinkAction, assignTransportCompanyAction } from './actions'
import CreateTransportCompanyForm from './CreateTransportCompanyForm'
import { colors, radius, fontSize, shadow } from '@/lib/styles/tokens'
import {
  pageStyle as sharedPageStyle,
  pageWrapStyle as sharedPageWrapStyle,
  contentStyle as sharedContentStyle,
  cardStyle as sharedCardStyle,
  tableStyle as sharedTableStyle,
  thStyle as sharedThStyle,
  tdStyle as sharedTdStyle,
  emptyStateStyle as sharedEmptyStateStyle,
} from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

export default async function AdminLogisticsPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>
}) {
  const sp = await searchParams
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)
  const level = isAdmin ? 'full' : myAccess?.logistics ?? 'none'
  const hasAccess = level !== 'none'
  const canEdit = level === 'edit' || level === 'full'

  const feedback =
    typeof sp.regenerated === 'string'
      ? 'لینک راننده دوباره ساخته شد.'
      : typeof sp.assigned === 'string'
        ? 'شرکت حمل‌ونقل به‌روزرسانی شد.'
        : null

  // مبنای انتخاب: هر Deal ای که حداقل یک تاییدیه (بارگیری/تخلیه) یا لینک راننده داره —
  // یعنی وارد مرحله‌ی عملیاتی حمل‌ونقل شده، فارغ از اینکه دقیق کدوم enum status باشه
  // (چون مقادیر کامل enum status روی Deal برای من قطعی/تاییدشده نبود، این معیار امن‌تره).
  const deals = hasAccess
    ? await prisma.deal.findMany({
        where: {
          OR: [{ confirmations: { some: {} } }, { driverLinks: { some: {} } }],
        },
        include: {
          buyer: { select: { companyName: true } },
          materialListing: { include: { grade: { select: { code: true } } } },
          confirmations: { orderBy: { confirmedAt: 'desc' }, take: 1 },
          driverLinks: { orderBy: { createdAt: 'desc' }, take: 1 },
          transportCompany: { select: { name: true } },
        },
        orderBy: { id: 'desc' },
        take: 100,
      })
    : []

  const transportCompanies = hasAccess && (level === 'edit' || level === 'full')
    ? await prisma.transportCompany.findMany({ where: { isActive: true }, select: { id: true, name: true } })
    : []

  return (
    <div style={sharedPageStyle}>
      <div style={{ ...sharedPageWrapStyle, maxWidth: 1200, margin: '0 auto' }} className="admin-page-wrap">
        <AdminNav currentUserName={currentUser.companyName} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="logistics" />
        <div style={sharedContentStyle}>
          <h1 style={{ fontSize: fontSize.xxl, fontWeight: 800, color: colors.textPrimary, margin: '0 0 4px' }}>حمل و نقل — هماهنگی داخلی</h1>
          <p style={{ fontSize: fontSize.base, color: colors.textMuted, margin: '0 0 20px' }}>
            نمای نظارتی داخلی روی همه‌ی معاملاتی که وارد مرحله‌ی حمل‌ونقل شدن — جدا از پنل شرکت حمل‌ونقل (`/transport-panel`) و ردیابی خریدار/فروشنده (`/transport`).
          </p>

          <PartialAccessBanner level={level} sectionLabel="حمل و نقل — هماهنگی داخلی" />

          {feedback && (
            <div style={{ background: colors.successBg, color: colors.successText, borderRadius: radius.md, padding: '10px 14px', fontSize: fontSize.base, marginBottom: 14 }}>
              {feedback}
            </div>
          )}

          {!hasAccess && <div style={sharedEmptyStateStyle}>به این بخش دسترسی نداری.</div>}

          {canEdit && (
            <div style={{ ...sharedCardStyle, boxShadow: shadow.card, marginBottom: 20 }}>
              <div style={{ marginBottom: 14 }}>
                <b style={{ fontSize: fontSize.md }}>ساخت شرکت حمل‌ونقل و حساب مدیر</b>
                <p style={{ fontSize: fontSize.sm, color: colors.textMuted, margin: '4px 0 0' }}>
                  شرکت حمل‌ونقل جدید به‌همراه حساب کاربری مدیرش در یک عملیات ساخته می‌شود. دسترسی پنل شرکت به‌صورت پیش‌فرض غیرفعاله و بعداً از «مدیریت کاربران» فعال می‌شه.
                </p>
              </div>
              <CreateTransportCompanyForm />
            </div>
          )}

          {hasAccess && (
            <div style={{ ...sharedCardStyle, boxShadow: shadow.card }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                <b style={{ fontSize: fontSize.md }}>معاملات در جریان حمل‌ونقل</b>
                <span style={countBadgeStyle}>{deals.length}</span>
              </div>

              {deals.length === 0 ? (
                <div style={sharedEmptyStateStyle}>فعلاً هیچ معامله‌ای وارد مرحله‌ی حمل‌ونقل نشده.</div>
              ) : (
                <div style={{ overflowX: 'auto' }}>
                  <table style={sharedTableStyle}>
                    <thead>
                      <tr style={{ background: colors.bgPage }}>
                        <th style={sharedThStyle}>شناسه معامله</th>
                        <th style={sharedThStyle}>گرید</th>
                        <th style={sharedThStyle}>خریدار</th>
                        <th style={sharedThStyle}>آخرین تاییدیه</th>
                        <th style={sharedThStyle}>شرکت حمل‌ونقل</th>
                        <th style={sharedThStyle}>وضعیت لینک راننده</th>
                        {canEdit && <th style={sharedThStyle}>عملیات</th>}
                      </tr>
                    </thead>
                    <tbody>
                      {deals.map((deal) => {
                        const lastConfirmation = deal.confirmations[0]
                        const lastLink = deal.driverLinks[0]
                        const linkStatus = !lastLink
                          ? 'بدون لینک'
                          : lastLink.usedAt
                            ? 'استفاده‌شده'
                            : new Date(lastLink.expiresAt) < new Date()
                              ? 'منقضی'
                              : 'فعال'
                        const linkStatusColor =
                          linkStatus === 'فعال'
                            ? colors.darkGreenText
                            : linkStatus === 'استفاده‌شده'
                              ? colors.infoText
                              : colors.textMuted

                        return (
                          <tr key={deal.id}>
                            <td style={{ ...sharedTdStyle, fontFamily: 'monospace', fontSize: fontSize.xs }}>{deal.id.slice(0, 8)}</td>
                            <td style={sharedTdStyle}>{deal.materialListing?.grade?.code ?? '—'}</td>
                            <td style={sharedTdStyle}>{deal.buyer?.companyName ?? '—'}</td>
                            <td style={{ ...sharedTdStyle, fontSize: 12 }}>
                              {lastConfirmation
                                ? `${translateConfirmationType(lastConfirmation.type)} — ${lastConfirmation.driverName ?? 'بدون نام راننده'}`
                                : 'هنوز تاییدیه‌ای ثبت نشده'}
                            </td>
                            <td style={{ ...sharedTdStyle, fontSize: 12 }}>
                              {canEdit ? (
                                <form action={assignTransportCompanyAction} style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                                  <input type="hidden" name="dealId" value={deal.id} />
                                  <select
                                    name="transportCompanyId"
                                    defaultValue={deal.transportCompanyId ?? ''}
                                    style={{ fontSize: 11.5, padding: '4px 6px', borderRadius: radius.sm, border: `1px solid ${colors.borderStrong}`, fontFamily: 'inherit' }}
                                  >
                                    <option value="">— بدون شرکت —</option>
                                    {transportCompanies.map((tc) => (
                                      <option key={tc.id} value={tc.id}>
                                        {tc.name}
                                      </option>
                                    ))}
                                  </select>
                                  <button type="submit" style={smallBtnStyle}>
                                    ثبت
                                  </button>
                                </form>
                              ) : (
                                deal.transportCompany?.name ?? '—'
                              )}
                            </td>
                            <td style={{ ...sharedTdStyle, color: linkStatusColor, fontWeight: 700 }}>{linkStatus}</td>
                            {canEdit && (
                              <td style={sharedTdStyle}>
                                <form action={regenerateDriverLinkAction}>
                                  <input type="hidden" name="dealId" value={deal.id} />
                                  <button type="submit" style={smallBtnStyle}>
                                    ساخت دوباره‌ی لینک راننده
                                  </button>
                                </form>
                              </td>
                            )}
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function translateConfirmationType(type: string): string {
  const map: Record<string, string> = {
    loading: 'بارگیری',
    unloading: 'تخلیه',
    driver_confirm: 'تایید راننده',
    buyer_confirm: 'تایید خریدار',
  }
  return map[type] ?? type
}

const countBadgeStyle: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 700,
  background: colors.orange,
  color: '#fff',
  borderRadius: radius.md,
  padding: '2px 10px',
}
const smallBtnStyle: React.CSSProperties = {
  background: colors.navy,
  color: '#fff',
  border: 'none',
  borderRadius: radius.sm,
  padding: '6px 12px',
  fontSize: 11.5,
  fontWeight: 700,
  cursor: 'pointer',
  fontFamily: 'inherit',
}
