'use client'

import { useActionState, useEffect, useRef } from 'react'
import type { CSSProperties } from 'react'
import { createTransportCompanyAction } from './actions'
import type { CreateTransportCompanyState } from './types'
import { colors, fontSize, radius, spacing } from '@/lib/styles/tokens'

const initialState: CreateTransportCompanyState = {
  status: 'idle',
  message: '',
}

export default function CreateTransportCompanyForm() {
  const [state, formAction, isPending] = useActionState(createTransportCompanyAction, initialState)
  const formRef = useRef<HTMLFormElement>(null)

  useEffect(() => {
    if (state.status === 'success') formRef.current?.reset()
  }, [state.status])

  return (
    <form ref={formRef} action={formAction}>
      <div style={formGridStyle}>
        <label style={fieldStyle}>
          <span style={labelStyle}>نام شرکت</span>
          <input name="companyName" required maxLength={120} autoComplete="organization" style={inputStyle} />
        </label>

        <label style={fieldStyle}>
          <span style={labelStyle}>تلفن تماس</span>
          <input
            name="contactPhone"
            required
            inputMode="tel"
            pattern="09[0-9]{9}"
            placeholder="09123456789"
            autoComplete="tel"
            dir="ltr"
            style={inputStyle}
          />
        </label>

        <label style={fieldStyle}>
          <span style={labelStyle}>نام‌کاربری/شماره‌تلفن مدیر</span>
          <input
            name="managerIdentifier"
            required
            minLength={3}
            maxLength={64}
            autoComplete="username"
            dir="ltr"
            style={inputStyle}
          />
        </label>

        <label style={fieldStyle}>
          <span style={labelStyle}>پسورد اولیه</span>
          <input
            name="initialPassword"
            type="password"
            required
            autoComplete="new-password"
            dir="ltr"
            style={inputStyle}
          />
        </label>
      </div>

      <p style={hintStyle}>پسورد باید مطابق سیاست فعلی رمز عبور سامانه باشد؛ خطای دقیق سیاست هنگام ثبت نمایش داده می‌شود.</p>

      {state.message && (
        <div
          role={state.status === 'error' ? 'alert' : 'status'}
          aria-live="polite"
          style={state.status === 'error' ? errorStyle : successStyle}
        >
          {state.message}
        </div>
      )}

      <button type="submit" disabled={isPending} style={{ ...submitStyle, opacity: isPending ? 0.65 : 1 }}>
        {isPending ? 'در حال ساخت…' : 'ساخت شرکت و حساب مدیر'}
      </button>
    </form>
  )
}

const formGridStyle: CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
  gap: spacing.md,
}

const fieldStyle: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: spacing.xs,
}

const labelStyle: CSSProperties = {
  color: colors.textSecondary,
  fontSize: fontSize.sm,
  fontWeight: 700,
}

const inputStyle: CSSProperties = {
  width: '100%',
  boxSizing: 'border-box',
  border: `1px solid ${colors.borderStrong}`,
  borderRadius: radius.sm,
  padding: '9px 10px',
  background: colors.bgCard,
  color: colors.textPrimary,
  fontFamily: 'inherit',
  fontSize: fontSize.base,
}

const hintStyle: CSSProperties = {
  margin: `${spacing.sm}px 0 ${spacing.md}px`,
  color: colors.textMuted,
  fontSize: fontSize.xs,
}

const messageStyle: CSSProperties = {
  borderRadius: radius.md,
  padding: '9px 12px',
  marginBottom: spacing.md,
  fontSize: fontSize.base,
}

const errorStyle: CSSProperties = {
  ...messageStyle,
  background: colors.dangerBg,
  color: colors.dangerText,
}

const successStyle: CSSProperties = {
  ...messageStyle,
  background: colors.successBg,
  color: colors.successText,
}

const submitStyle: CSSProperties = {
  border: 'none',
  borderRadius: radius.sm,
  padding: '9px 16px',
  background: colors.navy,
  color: '#fff',
  cursor: 'pointer',
  fontFamily: 'inherit',
  fontSize: fontSize.base,
  fontWeight: 700,
}
