import prisma from './prisma'

const RESTRICTION_HOURS = 24
const SELLER_FEE_DEADLINE_HOURS = 24
const BUYER_PAYMENT_DEADLINE_HOURS = 24

/**
 * این تابع رو باید هر جا صفحه‌ی مرتبط لود می‌شه صدا زد (بازار صنعتی، پنل کاربری، پنل ادمین).
 * چون هنوز job scheduler/cron جدا نداریم، به‌جاش هر بار که یکی از این صفحات باز می‌شه،
 * این تابع خودش چک می‌کنه آیا مهلتی گذشته یا نه — یه الگوی ساده و رایج برای MVP،
 * بدون نیاز به زیرساخت جداگانه.
 */
export async function enforceDealDeadlines() {
  await enforceSellerFeeDeadlines()
  await enforceBuyerPaymentDeadlines()
}

/**
 * فروشنده کارمزد رو سر وقت نداده → آگهی دوباره آزاد می‌شه (چراغ سبز)،
 * فروشنده ۲۴ ساعت محدود می‌شه.
 */
async function enforceSellerFeeDeadlines() {
  const now = new Date()
  const overdue = await prisma.materialListing.findMany({
    where: {
      feeStatus: 'unpaid',
      feeDeadline: { lt: now },
      validityStatus: 'reserved',
    },
  })

  for (const listing of overdue) {
    await prisma.materialListing.update({
      where: { id: listing.id },
      data: { validityStatus: 'active', feeDeadline: null },
    })

    await prisma.user.update({
      where: { id: listing.userId },
      data: {
        restrictedUntil: new Date(now.getTime() + RESTRICTION_HOURS * 60 * 60 * 1000),
        restrictionReason: 'کارمزد فروش را ظرف مهلت مقرر پرداخت نکرد',
      },
    })

    // هر Deal مرتبط با این آگهی که هنوز باز بود، لغو می‌شه
    await prisma.deal.updateMany({
      where: { materialListingId: listing.id, status: { in: ['draft', 'confirmed'] } },
      data: { status: 'cancelled' },
    })
  }

  return overdue.length
}

/**
 * خریدار بعد از تایید، پرداخت کامل رو تکمیل نکرده → همون اتفاق برای خریدار می‌افته.
 */
async function enforceBuyerPaymentDeadlines() {
  const now = new Date()
  const overdue = await prisma.deal.findMany({
    where: {
      status: 'confirmed',
      escrowStatus: 'pending',
      buyerConfirmDeadline: { lt: now },
    },
    include: { materialListing: true },
  })

  for (const deal of overdue) {
    await prisma.deal.update({
      where: { id: deal.id },
      data: { status: 'cancelled' },
    })

    if (deal.materialListingId) {
      await prisma.materialListing.update({
        where: { id: deal.materialListingId },
        data: { validityStatus: 'active' },
      })
    }

    await prisma.user.update({
      where: { id: deal.buyerId },
      data: {
        restrictedUntil: new Date(now.getTime() + RESTRICTION_HOURS * 60 * 60 * 1000),
        restrictionReason: 'رزرو را تایید کرد ولی پرداخت را ظرف مهلت مقرر تکمیل نکرد',
      },
    })
  }

  return overdue.length
}

/** برای چک‌کردن قبل از اجازه دادن به ثبت آگهی/رزرو جدید */
export async function isUserRestricted(userId: string) {
  const user = await prisma.user.findUnique({ where: { id: userId } })
  if (!user?.restrictedUntil) return { restricted: false as const }
  if (user.restrictedUntil < new Date()) return { restricted: false as const }
  return { restricted: true as const, until: user.restrictedUntil, reason: user.restrictionReason }
}

/** موقع تایید ادمین روی یه رزرو، این رو صدا بزن تا مهلت کارمزد فروشنده شروع بشه */
export async function startSellerFeeDeadline(materialListingId: string) {
  const deadline = new Date(Date.now() + SELLER_FEE_DEADLINE_HOURS * 60 * 60 * 1000)
  await prisma.materialListing.update({
    where: { id: materialListingId },
    data: { validityStatus: 'reserved', feeDeadline: deadline },
  })
  return deadline
}

/** موقع تایید کارمزد فروشنده، این رو صدا بزن تا مهلت پرداخت کامل خریدار شروع بشه */
export async function startBuyerPaymentDeadline(dealId: string) {
  const deadline = new Date(Date.now() + BUYER_PAYMENT_DEADLINE_HOURS * 60 * 60 * 1000)
  await prisma.deal.update({
    where: { id: dealId },
    data: { status: 'confirmed', buyerConfirmDeadline: deadline },
  })
  return deadline
}
