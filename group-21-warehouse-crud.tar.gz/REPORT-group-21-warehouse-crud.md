# گروه ۲۱ — CRUD انبارها و موجودی (پنل مدیریت)

تاریخ: ۱۴۰۵ / 2026-09-03
مرجع: `prompt-admin-warehouses-crud.md`

## فایل‌های تولید/تغییر یافته

| # | فایل | نوع |
|---|------|------|
| ۱ | `src/app/admin-warehouses/actions.ts` | جدید |
| ۲ | `src/app/admin-warehouses/page.tsx` | بازنویسی |
| ۳ | `src/lib/sections.ts` | تغییر مقدار (warehouses isReal: false → true) |

## جزئیات

### actions.ts — ۴ اکشن سروری
- **`requireWarehouseEditAccess()`** — گارد دسترسی (الگوی `admin-grades/actions.ts`):
  - `user.role === 'admin'` → همیشه مجاز
  - `access.warehouses === 'edit' | 'full'` → مجاز
  - در غیر این صورت → `AccessDeniedError('A-SECTION-WAREHOUSES')`
- **`createWarehouseAction`** — نام + شهر اجباری؛ آدرس/توضیحات/عرض/طول اختیarı — ورودی با `toFloatOrNull`
- **`updateWarehouseAction`** — ویرایش اطلاعات انبار (فیلدهای مشابه create)
- **`upsertStockAction`** — gradeId + warehouseId + quantityTon + priceRial اجباری، batch اختیاری؛ `findFirst({gradeId, warehouseId})` → اگر وجود داشت update، نه create (بدون touch به dealLightStatus)
- **`deleteStockAction`** — حذف ردیف موجودی با ID
- هر چهار اکشن: `revalidatePath('/admin-warehouses')` + `revalidatePath('/warehouses')` + `logAudit` با `user.id`

### page.tsx — صفحه CRUD کامل
- **Queries جدید**: `grade.findMany({ where: isActive })` فقط وقتی `canEdit` — لیست د_dropdown افزودن موجودی
- **افزودن انبار**: `<details>` با Summary «+ افزودن انبار جدید» → فرم name/city/address/lat/long/desc → `createWarehouseAction`
- **جدول موجودی + دکمه‌ها**:
  - ویرایش → لینک `?editing=stockId` → ردیف ویرایش inline در جدول (همون grade انتخاب شده، قیمت/مقدار/بچ قابل تغییر → `upsertStockAction`)
  - حذف → لینک `?confirmDelete=stockId` → نمایش «تایید حذف» + «انصراف» → `deleteStockAction` (دو مرحله‌ای)
- **افزودن موجودی**: `<details>` per warehouse → dropdown گریدهای فعال + قیمت/مقدار/بچ → `upsertStockAction`
- **بازخورد**: نوار سبز با query params (`created`, `updated`, `stock`, `deleted`)
- **سطح دسترسی**: `level === 'none'` → فقط مشاهده بدون دکمه؛ `view` → مشاهده + جدول؛ `edit`/`full` → همه دکمه‌ها

### sections.ts — تغییر `isReal`
- مقدار `warehouses` از `false` به `true` تغییر کرد تا لینک در AdminNav فعال باشد (قبلاً «به‌زودی» نشان می‌داد)
- نسخه `NEW FILES/src/lib/sections.ts` از قبل `true` بود — فقط نسخه‌ی `anbarpolymer-app` عقب‌تر بود

## امنیت

- ✅ همه‌ی اکشن‌ها پشت `requireWarehouseEditAccess` هستن — بدون دسترسی، throw
- ✅ `upsertStockAction` فقط فیلدهای quantityTon/priceRial/batch را آپدیت می‌کنه — `dealLightStatus` دست‌نخورده باقی می‌ماند
- ✅ `gradeId` در فرم افزودن موجودی از `grade.findMany({ isActive: true })` پر می‌شه — فقط گریدهای فعال
- ✅ حذف دو مرحله‌ای: ابتدا `?confirmDelete=...`، سپس تایید
- ✅ هیچ شلی برای عملیات فایل وجود ندارد

## نصب روی سرور

```bash
cd /var/www/anbarpolymer-app
tar -xzf /tmp/group-21-warehouse-crud.tar.gz
npm run build
pm2 restart anbarpolymer
```

- ❌ `prisma migrate` **نیاز نیست** — همه فیلدها از قبل در schema وجود دارن
- ❌ `prisma generate` **نیاز نیست**
- ❌ پکیج جدید **نیاز نیست**
- ✅ فقط build + restart

## بررسی پس از نصب

1. `/admin-warehouses` → صفحه با AdminNav و بخش «انبارها و موجودی» فعال
2. کلیک «+ افزودن انبار جدید» → فرم باز شود → ثبت → بازگشت با پیام سبز
3. در هر انبار → «+ افزودن موجودی» → dropdown گریدها → ثبت → بازگشت با پیام
4. در هر ردیف موجودی → «ویرایش» → ردیف edit inline ظاهر شود → تغییر + ذخیره
5. در هر ردیف موجودی → «حذف» → «تایید حذف» ظاهر شود → تایید → ردیف حذف شود
6. کاربر با دسترسی `view` → فقط جدول بدون دکمه
7. کاربر بدون دسترسی → پیام «دسترسی نداری»
