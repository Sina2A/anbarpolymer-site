import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import AdminNav, { PartialAccessBanner } from '@/components/AdminNav'
import { regenerateDriverLinkAction } from './actions'

export const dynamic = 'force-dynamic'

export default async function AdminLogisticsPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>
}) {
  const sp = await searchParams
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)
  const level = isAdmin ? 'full' : myAccess?.logistics ?? 'none'
  const hasAccess = level !== 'none'
  const canEdit = level === 'edit' || level === 'full'

  const feedback = typeof sp.regenerated === 'string' ? 'لینک راننده دوباره ساخته شد.' : null

  // مبنای انتخاب: هر Deal ای که حداقل یک تاییدیه (بارگیری/تخلیه) یا لینک راننده داره —
  // یعنی وارد مرحله‌ی عملیاتی حمل‌ونقل شده، فارغ از اینکه دقیق کدوم enum status باشه
  // (چون مقادیر کامل enum status روی Deal برای من قطعی/تاییدشده نبود، این معیار امن‌تره).
  const deals = hasAccess
    ? await prisma.deal.findMany({
        where: {
          OR: [{ confirmations: { some: {} } }, { driverLinks: { some: {} } }],
        },
        include: {
          buyer: { select: { companyName: true } },
          materialListing: { include: { grade: { select: { code: true } } } },
          confirmations: { orderBy: { confirmedAt: 'desc' }, take: 1 },
          driverLinks: { orderBy: { createdAt: 'desc' }, take: 1 },
        },
        orderBy: { id: 'desc' },
        take: 100,
      })
    : []

  return (
    <div style={pageStyle}>
      <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', gap: 24 }} className="admin-page-wrap">
        <AdminNav currentUserName={currentUser.companyName} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="logistics" />
        <div style={{ flex: 1, minWidth: 0 }}>
          <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>حمل و نقل — هماهنگی داخلی</h1>
          <p style={{ fontSize: 13, color: '#9199a3', marginBottom: 20 }}>
            نمای نظارتی داخلی روی همه‌ی معاملاتی که وارد مرحله‌ی حمل‌ونقل شدن — جدا از پنل شرکت حمل‌ونقل (`/transport-panel`) و ردیابی خریدار/فروشنده (`/transport`).
          </p>

          <PartialAccessBanner level={level} sectionLabel="حمل و نقل — هماهنگی داخلی" />

          {feedback && (
            <div style={{ background: '#eaf3de', color: '#27500a', borderRadius: 8, padding: '10px 14px', fontSize: 13, marginBottom: 14 }}>
              {feedback}
            </div>
          )}

          {!hasAccess && <div style={emptyBoxStyle}>به این بخش دسترسی نداری.</div>}

          {hasAccess && (
            <div style={cardStyle}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                <b style={{ fontSize: 14 }}>معاملات در جریان حمل‌ونقل</b>
                <span style={countBadgeStyle}>{deals.length}</span>
              </div>

              {deals.length === 0 ? (
                <div style={emptyBoxStyle}>فعلاً هیچ معامله‌ای وارد مرحله‌ی حمل‌ونقل نشده.</div>
              ) : (
                <div style={{ overflowX: 'auto' }}>
                  <table style={tableStyle}>
                    <thead>
                      <tr style={{ background: '#f7f8fa' }}>
                        <th style={thStyle}>شناسه معامله</th>
                        <th style={thStyle}>گرید</th>
                        <th style={thStyle}>خریدار</th>
                        <th style={thStyle}>آخرین تاییدیه</th>
                        <th style={thStyle}>وضعیت لینک راننده</th>
                        {canEdit && <th style={thStyle}>عملیات</th>}
                      </tr>
                    </thead>
                    <tbody>
                      {deals.map((deal) => {
                        const lastConfirmation = deal.confirmations[0]
                        const lastLink = deal.driverLinks[0]
                        const linkStatus = !lastLink
                          ? 'بدون لینک'
                          : lastLink.usedAt
                            ? 'استفاده‌شده'
                            : new Date(lastLink.expiresAt) < new Date()
                              ? 'منقضی'
                              : 'فعال'
                        const linkStatusColor =
                          linkStatus === 'فعال' ? '#065f46' : linkStatus === 'استفاده‌شده' ? '#3730a3' : '#9199a3'

                        return (
                          <tr key={deal.id} style={{ borderTop: '1px solid #eceff3' }}>
                            <td style={{ ...tdStyle, fontFamily: 'monospace', fontSize: 11 }}>{deal.id.slice(0, 8)}</td>
                            <td style={tdStyle}>{deal.materialListing?.grade?.code ?? '—'}</td>
                            <td style={tdStyle}>{deal.buyer?.companyName ?? '—'}</td>
                            <td style={{ ...tdStyle, fontSize: 12 }}>
                              {lastConfirmation
                                ? `${translateConfirmationType(lastConfirmation.type)} — ${lastConfirmation.driverName ?? 'بدون نام راننده'}`
                                : 'هنوز تاییدیه‌ای ثبت نشده'}
                            </td>
                            <td style={{ ...tdStyle, color: linkStatusColor, fontWeight: 700 }}>{linkStatus}</td>
                            {canEdit && (
                              <td style={tdStyle}>
                                <form action={regenerateDriverLinkAction}>
                                  <input type="hidden" name="dealId" value={deal.id} />
                                  <button type="submit" style={smallBtnStyle}>
                                    ساخت دوباره‌ی لینک راننده
                                  </button>
                                </form>
                              </td>
                            )}
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function translateConfirmationType(type: string): string {
  const map: Record<string, string> = {
    loading: 'بارگیری',
    unloading: 'تخلیه',
    driver_confirm: 'تایید راننده',
    buyer_confirm: 'تایید خریدار',
  }
  return map[type] ?? type
}

const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: '#faf8f4',
  padding: '32px 20px',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const cardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 18,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const emptyBoxStyle: React.CSSProperties = {
  fontSize: 12.5,
  color: '#9199a3',
  padding: '20px 0',
  textAlign: 'center',
}
const countBadgeStyle: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 700,
  background: '#e65716',
  color: '#fff',
  borderRadius: 8,
  padding: '2px 10px',
}
const tableStyle: React.CSSProperties = { width: '100%', borderCollapse: 'collapse', fontSize: 13 }
const thStyle: React.CSSProperties = { padding: '10px 12px', textAlign: 'right', fontSize: 12, color: '#6f7680', fontWeight: 700 }
const tdStyle: React.CSSProperties = { padding: '10px 12px', textAlign: 'right' }
const smallBtnStyle: React.CSSProperties = {
  background: '#1e357b',
  color: '#fff',
  border: 'none',
  borderRadius: 6,
  padding: '6px 12px',
  fontSize: 11.5,
  fontWeight: 700,
  cursor: 'pointer',
  fontFamily: 'inherit',
}
