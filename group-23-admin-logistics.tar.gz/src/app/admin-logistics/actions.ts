'use server'

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import { AccessDeniedError } from '@/lib/errorCodes'
import { logAudit } from '@/lib/logger'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import crypto from 'crypto'

async function requireLogisticsEditAccess() {
  const user = await getCurrentUser()
  if (user.role === 'admin') return user
  const access = await getAllSectionAccess(user.id)
  if (access.logistics !== 'edit' && access.logistics !== 'full') {
    throw new AccessDeniedError(
      'A-SECTION-LOGISTICS',
      'دسترسی مدیریت حمل‌ونقل داخلی رو نداری — از مدیر بخواه بهت بده.'
    )
  }
  return user
}

/**
 * لینک راننده‌ی جدید برای یه Deal می‌سازه — برای وقتی که لینک قبلی منقضی/گم
 * شده. مهلت اعتبار پیش‌فرض: ۴۸ ساعت (هم‌الگوی سایر لینک‌های موقت پروژه).
 */
export async function regenerateDriverLinkAction(formData: FormData) {
  const user = await requireLogisticsEditAccess()
  const dealId = String(formData.get('dealId') || '').trim()
  if (!dealId) throw new Error('شناسه‌ی معامله مشخص نیست.')

  const deal = await prisma.deal.findUnique({ where: { id: dealId } })
  if (!deal) throw new Error('معامله پیدا نشد.')

  // شماره‌ی تماس راننده: از آخرین DealConfirmation (اگه ثبت شده) یا آخرین
  // DriverAccessLink قبلی می‌گیریم — این فیلد اجباریه، پس نمی‌تونیم خالی بذاریم
  const lastConfirmation = await prisma.dealConfirmation.findFirst({
    where: { dealId, driverPhone: { not: null } },
    orderBy: { confirmedAt: 'desc' },
  })
  const lastLink = await prisma.driverAccessLink.findFirst({
    where: { dealId },
    orderBy: { createdAt: 'desc' },
  })
  const phone = lastConfirmation?.driverPhone ?? lastLink?.phone
  if (!phone) {
    throw new Error('شماره‌ی تماس راننده برای این معامله موجود نیست — اول باید یه تاییدیه یا لینک قبلی داشته باشه.')
  }

  const token = crypto.randomBytes(24).toString('hex')
  const expiresAt = new Date(Date.now() + 48 * 60 * 60 * 1000)

  await prisma.driverAccessLink.create({
    data: { dealId, token, phone, expiresAt },
  })

  await logAudit('logistics', `لینک راننده برای معامله‌ی ${dealId.slice(0, 8)} دوباره ساخته شد`, user.id, { dealId })

  revalidatePath('/admin-logistics')
  redirect('/admin-logistics?regenerated=1')
}
