// src/components/StatCard.tsx
//
// کارت آماری فشرده — برای بخش Stats پیشخوان

import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import type { CSSProperties } from 'react'

type Props = {
  value: number
  label: string
  breakdown?: string
  cta?: { text: string; href: string }
  color?: 'navy' | 'orange'
}

export default function StatCard({ value, label, breakdown, cta, color = 'navy' }: Props) {
  const valueColor = color === 'orange' ? colors.orange : colors.navy

  return (
    <div style={cardStyle}>
      <div style={{ ...valueStyle, color: valueColor }}>{value}</div>
      <div style={labelStyle}>{label}</div>
      {breakdown && <div style={breakdownStyle}>{breakdown}</div>}
      {cta && (
        <a href={cta.href} style={ctaStyle}>
          {cta.text} →
        </a>
      )}
    </div>
  )
}

const cardStyle: CSSProperties = {
  background: colors.bgCard,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
  padding: '16px 14px',
}

const valueStyle: CSSProperties = {
  fontSize: 18,
  fontWeight: 800,
  marginBottom: 4,
}

const labelStyle: CSSProperties = {
  fontSize: fontSize.sm,
  color: colors.textSecondary,
  marginBottom: 6,
}

const breakdownStyle: CSSProperties = {
  fontSize: fontSize.xs,
  color: colors.textMuted,
  marginTop: 6,
}

const ctaStyle: CSSProperties = {
  fontSize: fontSize.xs,
  color: colors.navy,
  fontWeight: 600,
  textDecoration: 'none',
  display: 'inline-block',
  marginTop: 8,
}
