// src/components/RecentItemsList.tsx
//
// لیست آیتم‌های اخیر — برای بخش فعالیت اخیر (سه ستون)

import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { badgeStyle } from '@/lib/styles/shared'
import type { CSSProperties } from 'react'

type RecentItem = {
  id: string
  description: string
  status: string
  date: Date
}

type Props = {
  title: string
  items: RecentItem[]
  emptyText: string
  linkToAll: string
  statusTranslator: (status: string) => string
  statusKind: (status: string) => 'success' | 'warning' | 'danger' | 'neutral'
}

export default function RecentItemsList({
  title,
  items,
  emptyText,
  linkToAll,
  statusTranslator,
  statusKind,
}: Props) {
  return (
    <div style={cardStyle}>
      <div style={headerStyle}>
        <b style={{ fontSize: fontSize.md }}>{title}</b>
      </div>

      {items.length === 0 ? (
        <div style={emptyStyle}>{emptyText}</div>
      ) : (
        <div style={listStyle}>
          {items.map((item) => (
            <div key={item.id} style={itemStyle}>
              <div style={itemTopStyle}>
                <div style={descStyle}>{item.description}</div>
                <span style={badgeStyle(statusKind(item.status))}>
                  {statusTranslator(item.status)}
                </span>
              </div>
              <div style={dateStyle}>
                {new Date(item.date).toLocaleDateString('fa-IR')}
              </div>
            </div>
          ))}
        </div>
      )}

      <a href={linkToAll} style={footerLinkStyle}>
        مشاهده همه →
      </a>
    </div>
  )
}

const cardStyle: CSSProperties = {
  background: colors.bgCard,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
  padding: '16px 14px',
}

const headerStyle: CSSProperties = {
  marginBottom: spacing.md,
}

const listStyle: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 10,
}

const itemStyle: CSSProperties = {
  borderBottom: `1px solid ${colors.borderSubtle}`,
  paddingBottom: 10,
}

const itemTopStyle: CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'flex-start',
  gap: 8,
  marginBottom: 4,
}

const descStyle: CSSProperties = {
  fontSize: fontSize.sm,
  color: colors.textPrimary,
  flex: 1,
  lineHeight: 1.5,
}

const dateStyle: CSSProperties = {
  fontSize: fontSize.xs,
  color: colors.textMuted,
}

const emptyStyle: CSSProperties = {
  fontSize: fontSize.sm,
  color: colors.textMuted,
  padding: '16px 0',
  textAlign: 'center',
}

const footerLinkStyle: CSSProperties = {
  display: 'block',
  fontSize: fontSize.xs,
  color: colors.navy,
  fontWeight: 600,
  textDecoration: 'none',
  marginTop: spacing.md,
  textAlign: 'center',
}
