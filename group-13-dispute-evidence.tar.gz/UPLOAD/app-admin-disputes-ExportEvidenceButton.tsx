'use client'

import { useState } from 'react'
import { exportDisputeEvidenceAction } from './actions'

export default function ExportEvidenceButton({ dealId, compact }: { dealId: string; compact?: boolean }) {
  const [loading, setLoading] = useState(false)

  async function handleExport() {
    setLoading(true)
    try {
      const result = await exportDisputeEvidenceAction(dealId)
      if (result.success && result.html) {
        // باز کردن HTML در پنجره جدید — کاربر می‌تونه Print to PDF کنه
        const win = window.open('', '_blank')
        if (win) {
          win.document.write(result.html)
          win.document.close()
        } else {
          alert('پنجره جدید باز نشد — لطفاً popup blocker رو غیرفعال کنید.')
        }
      }
    } catch (err) {
      console.error(err)
      alert('خطا در تولید مستندات')
    } finally {
      setLoading(false)
    }
  }

  if (compact) {
    return (
      <button
        onClick={handleExport}
        disabled={loading}
        style={compactBtnStyle}
        title="خروجی مستندات برای ارجاع قضایی"
      >
        {loading ? '...' : '📄'}
      </button>
    )
  }

  return (
    <button onClick={handleExport} disabled={loading} style={btnStyle}>
      {loading ? 'در حال تولید...' : '📄 خروجی مستندات'}
    </button>
  )
}

const btnStyle: React.CSSProperties = {
  background: '#fff',
  color: '#1e357b',
  border: '1px solid #1e357b',
  borderRadius: 8,
  padding: '9px 18px',
  fontSize: 12.5,
  fontWeight: 700,
  cursor: 'pointer',
}
const compactBtnStyle: React.CSSProperties = {
  background: '#fff',
  color: '#1e357b',
  border: '1px solid #d8dde3',
  borderRadius: 6,
  padding: '4px 10px',
  fontSize: 14,
  cursor: 'pointer',
}
