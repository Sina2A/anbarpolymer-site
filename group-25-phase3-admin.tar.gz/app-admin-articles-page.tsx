import prisma from '@/lib/prisma'
import { getAllSectionAccess } from '@/lib/permissions'
import { getCurrentUser } from '@/lib/currentUser'
import AdminNav, { PartialAccessBanner } from '@/components/AdminNav'
import { createArticleAction, togglePublishAction } from './actions'
import { pageStyle, pageWrapStyle, contentStyle, h1Style, subTitleStyle, cardStyle, badgeStyle, btnPrimaryStyle, btnSecondaryStyle, btnDangerStyle, inputStyle, labelStyle, emptyStateStyle } from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

type SearchParams = Promise<Record<string, string | string[] | undefined>>

function one(v: string | string[] | undefined): string | undefined {
  if (Array.isArray(v)) return v[0]
  return v
}

function faDate(d: Date | null | undefined): string {
  if (!d) return '—'
  return new Date(d).toLocaleDateString('fa-IR')
}

const TABS: { key: string; label: string }[] = [
  { key: 'all', label: 'همه' },
  { key: 'published', label: 'منتشرشده' },
  { key: 'scheduled', label: 'زمان‌بندی‌شده' },
  { key: 'draft', label: 'پیش‌نویس' },
]

// وضعیت نمایشی مقاله — ترکیب isPublished و تاریخ انتشار:
//   isPublished=false                       → پیش‌نویس
//   isPublished=true  و تاریخ <= الان        → منتشرشده
//   isPublished=true  و تاریخ > الان         → زمان‌بندی‌شده
function articleStatus(a: { isPublished: boolean; publishedAt: Date | null }): 'published' | 'scheduled' | 'draft' {
  if (!a.isPublished) return 'draft'
  if (a.publishedAt && a.publishedAt.getTime() > Date.now()) return 'scheduled'
  return 'published'
}

const STATUS_META: Record<string, { label: string; kind: 'success' | 'warning' | 'neutral' }> = {
  published: { label: 'منتشرشده', kind: 'success' },
  scheduled: { label: 'زمان‌بندی‌شده', kind: 'warning' },
  draft: { label: 'پیش‌نویس', kind: 'neutral' },
}

export default async function AdminArticlesPage({ searchParams }: { searchParams: SearchParams }) {
  const sp = await searchParams
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)
  const myLevel = isAdmin ? 'full' : (myAccess?.['articles'] ?? 'none')
  const canEdit = myLevel === 'full' || myLevel === 'edit'

  const activeTab = one(sp.tab) || 'all'
  const now = new Date()

  // شمارش تب‌ها — فقط فیلدهای سبک؛ متن مقاله‌ها لود نمی‌شه
  const all = await prisma.article.findMany({
    select: { id: true, isPublished: true, publishedAt: true },
  })
  const tabCount: Record<string, number> = { all: all.length, published: 0, scheduled: 0, draft: 0 }
  for (const a of all) tabCount[articleStatus(a)]++

  // کوئری نمایش تب فعال — باز بدون فیلد content (متن کامل فقط توی صفحه‌ی خود مقاله)
  const articles = await prisma.article.findMany({
    where:
      activeTab === 'published'
        ? { isPublished: true, OR: [{ publishedAt: null }, { publishedAt: { lte: now } }] }
        : activeTab === 'scheduled'
          ? { isPublished: true, publishedAt: { gt: now } }
          : activeTab === 'draft'
            ? { isPublished: false }
            : {},
    orderBy: [{ publishedAt: 'desc' }, { createdAt: 'desc' }],
    select: {
      id: true,
      title: true,
      isPublished: true,
      publishedAt: true,
      createdAt: true,
      updatedAt: true,
      author: { select: { companyName: true } },
    },
  })

  return (
    <div style={pageStyle}>
      <div style={pageWrapStyle}>
      <AdminNav currentUserName={currentUser.companyName} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="articles" />

      <div style={contentStyle}>
        <PartialAccessBanner level={myLevel} sectionLabel="مقالات و اخبار" />

        <h1 style={h1Style}>مقالات و اخبار</h1>
        <p style={subTitleStyle}>
          محتوای تحلیلی و خبری انبار پلیمر — نوشتن، ویرایش و انتشار. صفحه‌ی عمومی نمایش مقاله‌ها هنوز ساخته نشده؛ فعلاً این بخش فقط محل آماده‌سازی محتواست.
        </p>

        {/* ── نوشتن مقاله‌ی جدید (باز/بسته‌شونده) ── */}
        {canEdit && (
          <details style={{ ...cardStyle, padding: 0, marginBottom: 20, overflow: 'hidden' }}>
            <summary style={{ padding: '14px 16px', cursor: 'pointer', fontSize: 13.5, fontWeight: 700, color: '#1e357b' }}>
              ➕ نوشتن مقاله‌ی جدید
            </summary>
            <form action={createArticleAction} style={{ padding: '4px 16px 16px', borderTop: '1px solid #eceff3' }}>
              <div style={{ marginBottom: 14, marginTop: 12 }}>
                <div style={labelStyle}>عنوان</div>
                <input name="title" required maxLength={200} placeholder="مثلاً: تحلیل بازار پلی‌اتیلن — شهریور"
                  style={inputStyle} />
              </div>
              <div style={{ marginBottom: 14 }}>
                <div style={labelStyle}>تاریخ انتشار <span style={hintInline}>(اختیاری — خالی باشه موقع انتشار خودکار ثبت می‌شه؛ تاریخ آینده = زمان‌بندی)</span></div>
                <input type="datetime-local" name="publishedAt"
                  style={{ ...inputStyle, direction: 'ltr', textAlign: 'left' }} />
              </div>
              <div style={{ marginBottom: 14 }}>
                <div style={labelStyle}>متن مقاله</div>
                <textarea name="content" rows={10} required maxLength={50000} placeholder="متن کامل مقاله یا خبر…"
                  style={{ ...inputStyle, resize: 'vertical' }} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
                <span style={hintStyle}>مقاله به‌صورت پیش‌نویس ذخیره می‌شه؛ انتشارش جداگانه انجام می‌شه.</span>
                <button type="submit" style={btnPrimaryStyle}>ذخیره‌ی پیش‌نویس</button>
              </div>
            </form>
          </details>
        )}

        {/* ── تب‌های فیلتر ── */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 18, flexWrap: 'wrap' }}>
          {TABS.map((tab) => {
            const isActive = activeTab === tab.key
            const n = tabCount[tab.key] || 0
            return (
              <a
                key={tab.key}
                href={`/admin-articles?tab=${tab.key}`}
                style={{
                  padding: '7px 16px', borderRadius: 8, fontSize: 12.5, fontWeight: 700,
                  textDecoration: 'none', border: '1px solid',
                  borderColor: isActive ? '#1e357b' : '#d8dde3',
                  background: isActive ? '#1e357b' : '#fff',
                  color: isActive ? '#fff' : '#4f5560',
                }}
              >
                {tab.label} <span style={{ opacity: 0.75, fontFamily: 'monospace' }}>({n})</span>
              </a>
            )
          })}
        </div>

        {/* ── لیست مقاله‌ها ── */}
        {articles.length === 0 ? (
          <div style={emptyStateStyle}>مقاله‌ای در این دسته نیست.</div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {articles.map((a) => {
              const meta = STATUS_META[articleStatus(a)]
              return (
                <div key={a.id} style={cardStyle}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, marginBottom: 6, flexWrap: 'wrap' }}>
                    <a href={`/admin-articles/${a.id}`} style={{ fontSize: 14, fontWeight: 700, color: '#1e357b', textDecoration: 'none' }}>
                      {a.title}
                    </a>
                    <span style={badgeStyle(meta.kind)}>{meta.label}</span>
                  </div>

                  <div style={{ fontSize: 11.5, color: '#9199a3' }}>
                    نویسنده: <b style={{ color: '#4f5560' }}>{a.author?.companyName ?? '—'}</b>
                    {' | '}ساخته: {faDate(a.createdAt)}
                    {' | '}آخرین ویرایش: {faDate(a.updatedAt)}
                    {a.publishedAt && (
                      <>{' | '}انتشار: {faDate(a.publishedAt)}</>
                    )}
                  </div>

                  {canEdit && (
                    <div style={{ display: 'flex', gap: 8, marginTop: 12, paddingTop: 10, borderTop: '1px solid #eceff3', flexWrap: 'wrap' }}>
                      <form action={togglePublishAction}>
                        <input type="hidden" name="id" value={a.id} />
                        {a.isPublished ? (
                          <button type="submit" style={btnDangerStyle}>لغو انتشار</button>
                        ) : (
                          <button type="submit" style={btnSecondaryStyle}>انتشار</button>
                        )}
                      </form>
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        )}

        {!canEdit && articles.length > 0 && (
          <p style={{ fontSize: 11.5, color: '#9199a3', marginTop: 12 }}>
            برای نوشتن، ویرایش یا انتشار مقاله، دسترسی ویرایش این بخش لازمه.
          </p>
        )}
      </div>
      </div>
    </div>
  )
}

// ── استایل‌های محلی (معادل shared ندارند) ──────────────────────────────
const hintInline: React.CSSProperties = {
  fontWeight: 400, color: '#9199a3', fontSize: 11,
}
const hintStyle: React.CSSProperties = {
  fontSize: 11.5, color: '#9199a3',
}
