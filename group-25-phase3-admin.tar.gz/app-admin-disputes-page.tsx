import prisma from '@/lib/prisma'
import { getAllSectionAccess } from '@/lib/permissions'
import { getCurrentUser } from '@/lib/currentUser'
import AdminNav from '@/components/AdminNav'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'
import { resolveDisputeAction } from './actions'
import {
  pageStyle,
  pageWrapStyle,
  contentStyle,
  h1Style,
  subTitleStyle,
  cardStyle,
  badgeStyle,
  btnPrimaryStyle,
  emptyStateStyle,
} from '@/lib/styles/shared.ts'

export const dynamic = 'force-dynamic'

export default async function AdminDisputesPage() {
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)

  const disputes = await prisma.dispute.findMany({
    include: { deal: { include: { buyer: true } }, raisedBy: true },
    orderBy: { createdAt: 'desc' },
  })

  const openDisputes = disputes.filter((d) => d.status === 'open')
  const closedDisputes = disputes.filter((d) => d.status !== 'open')

  return (
    <div style={pageStyle}>
      <div style={pageWrapStyle}>
        <AdminNav currentUserName={currentUser.companyName} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="disputes" />

        <div style={contentStyle}>
          <h1 style={h1Style}>رسیدگی به اختلاف</h1>
          <p style={subTitleStyle}>
            هر بار خریدار تحویل بار رو «با مغایرت» یا «رد» تایید کنه، یه مورد اینجا خودکار باز می‌شه.
          </p>

          <h2 style={sectionHeadStyle}>باز — نیاز به رسیدگی <span style={countBadge}>{openDisputes.length}</span></h2>
          {openDisputes.length === 0 && <div style={emptyStateStyle}>هیچ اختلاف بازی نیست.</div>}
          {openDisputes.map((d) => (
            <form key={d.id} action={resolveDisputeAction} style={cardStyle}>
              <input type="hidden" name="disputeId" value={d.id} />
              <input type="hidden" name="status" value="resolved" />
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
                <b style={{ fontSize: 14 }}>معامله #{d.dealId.slice(0, 8)}</b>
                <span style={{ fontSize: 11, color: '#9199a3' }}>{new Date(d.createdAt).toLocaleDateString('fa-IR')}</span>
              </div>
              <div style={{ fontSize: 12.5, color: '#4f5560', marginBottom: 4 }}>خریدار: {d.deal.buyer.companyName}</div>
              <div style={{ fontSize: 13, fontWeight: 600, color: '#a8241a', marginBottom: 14 }}>دلیل: {d.reason}</div>

              <textarea name="resolution" placeholder="توضیح نتیجه‌ی رسیدگی (الزامی)" rows={3} style={textareaStyle} required />

              <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
                <ConfirmSubmitButton message="این اختلاف حل‌شده ثبت بشه؟" style={btnPrimaryStyle}>
                  ثبت به‌عنوان حل‌شده
                </ConfirmSubmitButton>
              </div>
            </form>
          ))}

          <h2 style={{ ...sectionHeadStyle, marginTop: 32 }}>تاریخچه</h2>
          {closedDisputes.length === 0 && <div style={emptyStateStyle}>هنوز موردی بسته نشده.</div>}
          {closedDisputes.map((d) => (
            <div key={d.id} style={cardStyle}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <b style={{ fontSize: 13 }}>#{d.dealId.slice(0, 8)}</b>
                <span style={statusTag}>{d.status === 'resolved' ? 'حل شد' : 'رد شد'}</span>
              </div>
              {d.resolution && <div style={{ fontSize: 12, color: '#4f5560', marginTop: 6 }}>{d.resolution}</div>}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

const sectionHeadStyle: React.CSSProperties = { fontSize: 15, fontWeight: 800, display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }
const countBadge: React.CSSProperties = { background: '#fee2e2', color: '#a8241a', fontSize: 11, fontWeight: 800, borderRadius: 20, padding: '2px 10px' }
const textareaStyle: React.CSSProperties = { width: '100%', border: '1px solid #d8dde3', borderRadius: 8, padding: '10px 12px', fontSize: 12.5, fontFamily: 'inherit', resize: 'vertical' }
const statusTag: React.CSSProperties = { ...badgeStyle('neutral') }
