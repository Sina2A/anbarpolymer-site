import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import AdminNav from '@/components/AdminNav'
import { getAllSectionAccess } from '@/lib/accessControl'
import { requireCustomRfqAccess } from './accessGate'
import { updateRfqStatusAction, submitExpertResponseAction } from './actions'
import { pageStyle, pageWrapStyle, contentStyle, h1Style, subTitleStyle, cardStyle, tableStyle, theadRowStyle, thStyle, tdStyle, badgeStyle, btnPrimaryStyle, btnSecondaryStyle, btnDangerStyle, inputStyle, selectStyle, labelStyle, emptyStateStyle } from '@/lib/styles/shared.ts'

export const dynamic = 'force-dynamic'

export default async function AdminCustomRequestPage() {
  const user = await getCurrentUser()
  await requireCustomRfqAccess(user.id, 'view')

  const accessMap = await getAllSectionAccess(user.id)
  const canEdit = accessMap['custom-rfq'] === 'edit' || accessMap['custom-rfq'] === 'full' || user.role === 'admin'

  // لیست همه‌ی درخواست‌های RFQ (باز و پاسخ‌داده‌شده)
  const allRfqs = await prisma.customRfq.findMany({
    orderBy: { createdAt: 'desc' },
    take: 100,
    include: {
      user: { select: { companyName: true, email: true } },
    },
  })

  return (
    <div style={pageStyle}>
      <div style={pageWrapStyle}>
        <AdminNav
          currentUserName={user.companyName}
          isAdmin={user.role === 'admin'}
          accessMap={accessMap}
          activeSection="custom-rfq"
        />

        <div style={{ flex: 1, minWidth: 0 }}>
          <h1 style={h1Style}>مدیریت درخواست‌های غیرکاتالوگی (Custom RFQ)</h1>
          <p style={subTitleStyle}>
            درخواست‌هایی که کاربران برای محصولات خارج از کاتالوگ ثبت کردند. پاسخ دستی کارشناس لازمه.
          </p>

          {allRfqs.length === 0 ? (
            <div style={emptyStateStyle}>هیچ درخواستی ثبت نشده.</div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              {allRfqs.map((rfq) => (
                <div key={rfq.id} style={cardStyle}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: 10 }}>
                    <div>
                      <b style={{ fontSize: 14 }}>{rfq.polymerType}</b>
                      {rfq.suggestedGradeCode && (
                        <span style={{ fontSize: 11, color: '#9199a3', marginRight: 8 }}>
                          (پیشنهاد از گرید: {rfq.suggestedGradeCode})
                        </span>
                      )}
                      <div style={{ fontSize: 12, color: '#6f7680', marginTop: 4 }}>
                        کاربر: <b>{rfq.user.companyName}</b> · {rfq.user.email}
                      </div>
                    </div>
                    <span style={badgeStyle(rfq.status === 'open' ? 'warning' : rfq.status === 'answered' ? 'success' : 'neutral')}>{translateStatus(rfq.status)}</span>
                  </div>

                  <div style={{ fontSize: 12, color: '#4f5560', marginBottom: 8 }}>
                    مقدار: <b>{rfq.quantityTon} تن</b>
                    {rfq.mfiRangeMin != null && rfq.mfiRangeMax != null && (
                      <> · MFI: {rfq.mfiRangeMin}–{rfq.mfiRangeMax}</>
                    )}
                    {rfq.densityMin != null && rfq.densityMax != null && (
                      <> · چگالی: {rfq.densityMin}–{rfq.densityMax}</>
                    )}
                  </div>

                  {rfq.requirements && (
                    <div style={{ fontSize: 12, color: '#4f5560', marginBottom: 8, padding: '8px 12px', background: '#f7f8fa', borderRadius: 6 }}>
                      <b style={{ fontSize: 11, color: '#6f7680', display: 'block', marginBottom: 4 }}>الزامات خاص:</b>
                      {rfq.requirements}
                    </div>
                  )}

                  {rfq.expertResponse && (
                    <div style={{ background: '#eaf3de', color: '#146c3a', borderRadius: 8, padding: '10px 12px', fontSize: 12, marginTop: 8 }}>
                      <b>پاسخ کارشناس:</b> {rfq.expertResponse}
                    </div>
                  )}

                  <div style={{ fontSize: 11, color: '#9199a3', marginTop: 8 }}>
                    ثبت‌شده: {new Date(rfq.createdAt).toLocaleDateString('fa-IR')}
                    {rfq.answeredAt && (
                      <> · پاسخ داده‌شده: {new Date(rfq.answeredAt).toLocaleDateString('fa-IR')}</>
                    )}
                  </div>

                  {canEdit && rfq.status === 'open' && (
                    <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid #eceff3' }}>
                      <form action={submitExpertResponseAction}>
                        <input type="hidden" name="rfqId" value={rfq.id} />
                        <div style={{ marginBottom: 10 }}>
                          <div style={labelStyle}>پاسخ کارشناس (قیمت پیشنهادی + توضیحات)</div>
                          <textarea
                            name="expertResponse"
                            required
                            rows={3}
                            placeholder="مثلاً: گرید PP-H551T مناسب الزامات شماست. قیمت پیشنهادی: ۱۲۰،۰۰۰ تومان/کیلو (FOB انبار). زمان تحویل ۱۴ روز."
                            style={{ ...inputStyle, resize: 'vertical' }}
                          />
                        </div>
                        <button type="submit" style={btnPrimaryStyle}>
                          ثبت پاسخ و تغییر وضعیت به «پاسخ‌داده‌شده»
                        </button>
                      </form>
                    </div>
                  )}

                  {canEdit && rfq.status === 'answered' && (
                    <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid #eceff3' }}>
                      <form action={updateRfqStatusAction}>
                        <input type="hidden" name="rfqId" value={rfq.id} />
                        <input type="hidden" name="newStatus" value="closed" />
                        <button type="submit" style={btnSecondaryStyle}>
                          بستن درخواست (closed)
                        </button>
                      </form>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// ── ترجمه و رنگ وضعیت ──────────────────────────────────────────────────
function translateStatus(status: string): string {
  const map: Record<string, string> = { open: 'باز', answered: 'پاسخ‌داده‌شده', closed: 'بسته' }
  return map[status] ?? status
}
