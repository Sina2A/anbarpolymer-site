import prisma from '@/lib/prisma'
import { notFound } from 'next/navigation'
import { getAllSectionAccess } from '@/lib/permissions'
import { getCurrentUser } from '@/lib/currentUser'
import AdminNav, { PartialAccessBanner } from '@/components/AdminNav'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'
import { updateArticleAction, togglePublishAction, deleteArticleAction } from '../actions'
import {
  pageStyle, pageWrapStyle, contentStyle,
  h1Style, cardStyle,
  badgeStyle,
  btnPrimaryStyle, btnSecondaryStyle, btnDangerStyle, btnSmallStyle,
  inputStyle, labelStyle,
} from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

type Params = Promise<{ id: string }>

// Date → مقدار قابل استفاده در input datetime-local (YYYY-MM-DDTHH:mm محلی)
function toLocalInput(d: Date | null): string {
  if (!d) return ''
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`
}

function faDate(d: Date | null | undefined): string {
  if (!d) return '—'
  return new Date(d).toLocaleDateString('fa-IR')
}

const STATUS_META: Record<string, { label: string; kind: 'success' | 'warning' | 'neutral' }> = {
  published: { label: 'منتشرشده', kind: 'success' },
  scheduled: { label: 'زمان‌بندی‌شده', kind: 'warning' },
  draft: { label: 'پیش‌نویس', kind: 'neutral' },
}

export default async function AdminArticlePage({ params }: { params: Params }) {
  const { id } = await params
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)
  const myLevel = isAdmin ? 'full' : (myAccess?.['articles'] ?? 'none')
  const canEdit = myLevel === 'full' || myLevel === 'edit'

  const article = await prisma.article.findUnique({
    where: { id },
    include: { author: { select: { companyName: true } } },
  })
  if (!article) notFound()

  const status = !article.isPublished
    ? 'draft'
    : article.publishedAt && article.publishedAt.getTime() > Date.now()
      ? 'scheduled'
      : 'published'
  const meta = STATUS_META[status]

  return (
    <div style={pageStyle}>
      <div style={pageWrapStyle}>
        <AdminNav currentUserName={currentUser.companyName} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="articles" />

        <div style={contentStyle}>
          <PartialAccessBanner level={myLevel} sectionLabel="مقالات و اخبار" />

          <a href="/admin-articles" style={{ fontSize: 12, fontWeight: 700, color: '#1e357b', textDecoration: 'none', display: 'inline-block', marginBottom: 10 }}>
            ← همه‌ی مقالات
          </a>

          <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap', marginBottom: 8 }}>
            <h1 style={h1Style}>{article.title}</h1>
            <span style={badgeStyle(meta.kind)}>{meta.label}</span>
          </div>

          <div style={{ ...cardStyle, padding: 14, marginBottom: 18, fontSize: 11.5, color: '#9199a3' }}>
            نویسنده: <b style={{ color: '#4f5560' }}>{article.author?.companyName ?? '—'}</b>
            {' | '}ساخته: {faDate(article.createdAt)}
            {' | '}آخرین ویرایش: {faDate(article.updatedAt)}
            {article.publishedAt && (
              <>{' | '}انتشار: {faDate(article.publishedAt)}</>
            )}
          </div>

          {canEdit ? (
            <>
              <form action={updateArticleAction} style={{ ...cardStyle, marginBottom: 18 }}>
                <input type="hidden" name="id" value={article.id} />
                <div style={{ marginBottom: 14 }}>
                  <div style={labelStyle}>عنوان</div>
                  <input name="title" required maxLength={200} defaultValue={article.title} style={inputStyle} />
                </div>
                <div style={{ marginBottom: 14 }}>
                  <div style={labelStyle}>تاریخ انتشار <span style={hintInline}>(اختیاری — تاریخ آینده = زمان‌بندی انتشار)</span></div>
                  <input type="datetime-local" name="publishedAt" defaultValue={toLocalInput(article.publishedAt)}
                    style={{ ...inputStyle, direction: 'ltr', textAlign: 'left' }} />
                </div>
                <div style={{ marginBottom: 14 }}>
                  <div style={labelStyle}>متن مقاله</div>
                  <textarea name="content" rows={16} required maxLength={50000} defaultValue={article.content}
                    style={{ ...inputStyle, resize: 'vertical' }} />
                </div>
                <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                  <button type="submit" style={{ ...btnPrimaryStyle, padding: '10px 28px' }}>ذخیره‌ی تغییرات</button>
                </div>
              </form>

              <div style={{ ...cardStyle, display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
                <form action={togglePublishAction}>
                  <input type="hidden" name="id" value={article.id} />
                  {article.isPublished ? (
                    <button type="submit" style={{ ...btnDangerStyle, padding: '7px 10px', color: '#9b1c1c', border: 'none' }}>لغو انتشار</button>
                  ) : (
                    <button type="submit" style={{ ...btnSecondaryStyle, padding: '7px 14px' }}>انتشار</button>
                  )}
                </form>
                <form action={deleteArticleAction}>
                  <input type="hidden" name="id" value={article.id} />
                  <ConfirmSubmitButton
                    message={`مطمئنی می‌خوای مقاله‌ی «${article.title}» برای همیشه حذف بشه؟`}
                    style={{ ...btnDangerStyle, padding: '7px 10px', color: '#9b1c1c', border: 'none' }}
                  >
                    حذف مقاله
                  </ConfirmSubmitButton>
                </form>
              </div>
            </>
          ) : (
            <>
              <div style={{ ...cardStyle, whiteSpace: 'pre-wrap', fontSize: 13, lineHeight: 1.9, color: '#1b1e24', marginBottom: 12 }}>
                {article.content}
              </div>
              <p style={{ fontSize: 11.5, color: '#9199a3' }}>
                برای ویرایش یا انتشار این مقاله، دسترسی ویرایش این بخش لازمه.
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

// ── استایل‌های محلی (فقط مواردی که معادل shared ندارند) ─────────────────
const hintInline: React.CSSProperties = {
  fontWeight: 400, color: '#9199a3', fontSize: 11,
}
