import prisma from '@/lib/prisma'
import { getAllSectionAccess } from '@/lib/permissions'
import { getCurrentUser } from '@/lib/currentUser'
import AdminNav from '@/components/AdminNav'
import { Suspense } from 'react'
import type React from 'react'
import { pageStyle, pageWrapStyle, contentStyle, h1Style, subTitleStyle, cardStyle, tableStyle, theadRowStyle, thStyle, tdStyle, badgeStyle, btnPrimaryStyle, btnSecondaryStyle, btnDangerStyle, inputStyle, selectStyle, labelStyle, emptyStateStyle } from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

export default async function AdminPricingPage({ searchParams }: { searchParams: Promise<{ tab?: string }> }) {
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)

  const sp = await searchParams
  const activeTab = sp.tab || 'formula'

  return (
    <div style={pageStyle}>
      <div style={pageWrapStyle}>
        <AdminNav currentUserName={currentUser.companyName} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="pricing" />

        <div style={contentStyle}>
          <h1 style={h1Style}>📊 بنچمارک قیمت</h1>
          <p style={subTitleStyle}>
            موتور قیمت‌گذاری و بنچمارک — ۷ تب ساختاریافته برای مدیریت فرمول‌ها، ضرایب، سطوح حاشیه، قوانین تایید، و انتشار قیمت مرجع.
          </p>

          {/* ناوبری تب‌های داخلی */}
          <div style={{ display: 'flex', gap: 8, marginBottom: 24, borderBottom: '2px solid #eceff3', paddingBottom: 0 }}>
            <TabLink href="/admin-pricing?tab=formula" label="۱. فرمول پایه & Reference" active={activeTab === 'formula'} />
            <TabLink href="/admin-pricing?tab=waterfall" label="۲. آبشار قیمت" active={activeTab === 'waterfall'} />
            <TabLink href="/admin-pricing?tab=payment" label="۳. ضرایب تسویه" active={activeTab === 'payment'} />
            <TabLink href="/admin-pricing?tab=volume" label="۴. ضرایب حجم و انبارداری" active={activeTab === 'volume'} />
            <TabLink href="/admin-pricing?tab=margins" label="۵. سطوح Floor/Target/Stretch" active={activeTab === 'margins'} />
            <TabLink href="/admin-pricing?tab=approval" label="۶. قوانین تایید مدیر فروش" active={activeTab === 'approval'} />
            <TabLink href="/admin-pricing?tab=publish" label="۷. مدیریت لیست‌های بنچینو & انتشار" active={activeTab === 'publish'} />
          </div>

          <Suspense fallback={<div style={{ padding: 40, textAlign: 'center', color: '#9199a3' }}>در حال بارگذاری...</div>}>
            {activeTab === 'formula' && <Tab1Formula />}
            {activeTab === 'waterfall' && <Tab2Waterfall />}
            {activeTab === 'payment' && <Tab3Payment />}
            {activeTab === 'volume' && <Tab4Volume />}
            {activeTab === 'margins' && <Tab5Margins />}
            {activeTab === 'approval' && <Tab6Approval />}
            {activeTab === 'publish' && <Tab7Publish searchParams={sp} />}
          </Suspense>
        </div>
      </div>
    </div>
  )
}

function TabLink({ href, label, active }: { href: string; label: string; active: boolean }) {
  return (
    <a
      href={href}
      style={{
        fontSize: 12.5,
        fontWeight: active ? 700 : 500,
        color: active ? '#1e357b' : '#6f7680',
        padding: '10px 16px',
        textDecoration: 'none',
        borderBottom: active ? '3px solid #1e357b' : '3px solid transparent',
        transition: 'all 0.2s',
      }}
    >
      {label}
    </a>
  )
}

// ==================== تب ۱: فرمول پایه & Reference ====================
async function Tab1Formula() {
  const formulas = await prisma.priceFormulaRule.findMany({ orderBy: { createdAt: 'desc' } })
  const grades = await prisma.grade.findMany({ where: { isActive: true }, orderBy: { code: 'asc' } })

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <h2 style={{ fontSize: 16, fontWeight: 800 }}>فرمول پایه قیمت‌گذاری</h2>
        <a href="/admin-pricing/formula/new" style={btnPrimaryStyle}>+ افزودن فرمول</a>
      </div>

      {formulas.length === 0 && <EmptyState message="هنوز هیچ فرمولی تعریف نشده — با دکمه‌ی «افزودن» شروع کنید." />}

      {formulas.length > 0 && (
        <table style={tableStyle}>
          <thead>
            <tr style={theadRowStyle}>
              <th style={thStyle}>گرید</th>
              <th style={thStyle}>فرمول</th>
              <th style={thStyle}>نوع منبع</th>
              <th style={thStyle}>مقدار</th>
              <th style={thStyle}>وضعیت</th>
              <th style={thStyle}>عملیات</th>
            </tr>
          </thead>
          <tbody>
            {formulas.map((f) => {
              const grade = f.gradeId ? grades.find((g) => g.id === f.gradeId) : null
              return (
                <tr key={f.id} style={tbodyRowStyle}>
                  <td style={tdStyle}>{grade ? grade.code : 'عمومی (همه‌ی گریدها)'}</td>
                  <td style={{ ...tdStyle, fontFamily: 'monospace', fontSize: 11.5, direction: 'ltr', textAlign: 'left' }}>{f.formulaText}</td>
                  <td style={tdStyle}>{f.sourceType === 'manual' ? 'دستی' : 'API'}</td>
                  <td style={{ ...tdStyle, fontFamily: 'monospace' }}>{f.sourceType === 'manual' ? (f.manualValue || '—') : (f.apiSnapshotValue || '—')}</td>
                  <td style={tdStyle}>
                    <StatusBadge active={f.isActive} />
                  </td>
                  <td style={tdStyle}>
                    <a href={`/admin-pricing/formula/${f.id}`} style={btnEditStyle}>ویرایش</a>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      )}
    </div>
  )
}

// ==================== تب ۲: آبشار قیمت ====================
async function Tab2Waterfall() {
  const rules = await prisma.waterfallRule.findMany({ orderBy: { priority: 'asc' } })

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <h2 style={{ fontSize: 16, fontWeight: 800 }}>آبشار قیمت (ردیف‌های شرطی)</h2>
        <a href="/admin-pricing/waterfall/new" style={btnPrimaryStyle}>+ افزودن ردیف</a>
      </div>

      {rules.length === 0 && <EmptyState message="هیچ قانون آبشاری تعریف نشده." />}

      {rules.length > 0 && (
        <table style={tableStyle}>
          <thead>
            <tr style={theadRowStyle}>
              <th style={thStyle}>اولویت</th>
              <th style={thStyle}>نوع شرط</th>
              <th style={thStyle}>مقدار شرط</th>
              <th style={thStyle}>نوع تنظیم</th>
              <th style={thStyle}>مقدار تنظیم</th>
              <th style={thStyle}>وضعیت</th>
              <th style={thStyle}>عملیات</th>
            </tr>
          </thead>
          <tbody>
            {rules.map((r) => (
              <tr key={r.id} style={tbodyRowStyle}>
                <td style={tdStyle}>{r.priority}</td>
                <td style={tdStyle}>{conditionTypeLabel(r.conditionType)}</td>
                <td style={tdStyle}>{r.conditionValue}</td>
                <td style={tdStyle}>{r.adjustmentType === 'percentage' ? 'درصد' : 'مبلغ ثابت'}</td>
                <td style={{ ...tdStyle, fontFamily: 'monospace' }}>{r.adjustmentValue}</td>
                <td style={tdStyle}><StatusBadge active={r.isActive} /></td>
                <td style={tdStyle}>
                  <a href={`/admin-pricing/waterfall/${r.id}`} style={btnEditStyle}>ویرایش</a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  )
}

// ==================== تب ۳: ضرایب تسویه ====================
async function Tab3Payment() {
  const terms = await prisma.paymentTermRule.findMany({ orderBy: { termDays: 'asc' } })

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <h2 style={{ fontSize: 16, fontWeight: 800 }}>ضرایب شرایط تسویه</h2>
        <a href="/admin-pricing/payment/new" style={btnPrimaryStyle}>+ افزودن شرایط</a>
      </div>

      {terms.length === 0 && <EmptyState message="هیچ شرایط پرداختی تعریف نشده." />}

      {terms.length > 0 && (
        <table style={tableStyle}>
          <thead>
            <tr style={theadRowStyle}>
              <th style={thStyle}>مدت پرداخت (روز)</th>
              <th style={thStyle}>ضریب تنظیم (%)</th>
              <th style={thStyle}>وضعیت</th>
              <th style={thStyle}>عملیات</th>
            </tr>
          </thead>
          <tbody>
            {terms.map((t) => (
              <tr key={t.id} style={tbodyRowStyle}>
                <td style={{ ...tdStyle, fontFamily: 'monospace' }}>{t.termDays} روز</td>
                <td style={{ ...tdStyle, fontFamily: 'monospace', color: t.adjustmentPercent >= 0 ? '#146c3a' : '#9b1c1c' }}>
                  {t.adjustmentPercent > 0 ? '+' : ''}{t.adjustmentPercent}%
                </td>
                <td style={tdStyle}><StatusBadge active={t.isActive} /></td>
                <td style={tdStyle}>
                  <a href={`/admin-pricing/payment/${t.id}`} style={btnEditStyle}>ویرایش</a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  )
}

// ==================== تب ۴: ضرایب حجم و انبارداری ====================
async function Tab4Volume() {
  const tiers = await prisma.volumeTierRule.findMany({ orderBy: { minTonnage: 'asc' } })

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <h2 style={{ fontSize: 16, fontWeight: 800 }}>ضرایب حجم و انبارداری</h2>
        <a href="/admin-pricing/volume/new" style={btnPrimaryStyle}>+ افزودن پله</a>
      </div>

      {tiers.length === 0 && <EmptyState message="هیچ پله‌ی حجمی تعریف نشده." />}

      {tiers.length > 0 && (
        <table style={tableStyle}>
          <thead>
            <tr style={theadRowStyle}>
              <th style={thStyle}>حداقل تناژ</th>
              <th style={thStyle}>ضریب تنظیم (%)</th>
              <th style={thStyle}>نوع انبار</th>
              <th style={thStyle}>وضعیت</th>
              <th style={thStyle}>عملیات</th>
            </tr>
          </thead>
          <tbody>
            {tiers.map((t) => (
              <tr key={t.id} style={tbodyRowStyle}>
                <td style={{ ...tdStyle, fontFamily: 'monospace' }}>{t.minTonnage} تن</td>
                <td style={{ ...tdStyle, fontFamily: 'monospace', color: t.adjustmentPercent >= 0 ? '#146c3a' : '#9b1c1c' }}>
                  {t.adjustmentPercent > 0 ? '+' : ''}{t.adjustmentPercent}%
                </td>
                <td style={tdStyle}>{t.storageType || 'سراسری'}</td>
                <td style={tdStyle}><StatusBadge active={t.isActive} /></td>
                <td style={tdStyle}>
                  <a href={`/admin-pricing/volume/${t.id}`} style={btnEditStyle}>ویرایش</a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  )
}

// ==================== تب ۵: سطوح Floor/Target/Stretch ====================
async function Tab5Margins() {
  const margins = await prisma.marginGuidance.findMany({ include: { grade: true }, orderBy: { createdAt: 'desc' } })
  const gradesWithoutMargin = await prisma.grade.findMany({
    where: { isActive: true, marginGuidance: null },
    orderBy: { code: 'asc' },
  })

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <h2 style={{ fontSize: 16, fontWeight: 800 }}>سطوح حاشیه‌ی هدف (Floor / Target / Stretch)</h2>
        <a href="/admin-pricing/margins/new" style={btnPrimaryStyle}>+ افزودن سطوح</a>
      </div>

      {gradesWithoutMargin.length > 0 && (
        <div style={{ background: '#fef3c7', border: '1px solid #f59e0b', borderRadius: 8, padding: '10px 14px', marginBottom: 16, fontSize: 12.5 }}>
          <b>{gradesWithoutMargin.length} گرید</b> هنوز سطوح حاشیه ندارند.
        </div>
      )}

      {margins.length === 0 && <EmptyState message="هیچ سطح حاشیه‌ای تعریف نشده." />}

      {margins.length > 0 && (
        <table style={tableStyle}>
          <thead>
            <tr style={theadRowStyle}>
              <th style={thStyle}>گرید</th>
              <th style={thStyle}>Floor (%)</th>
              <th style={thStyle}>Target (%)</th>
              <th style={thStyle}>Stretch (%)</th>
              <th style={thStyle}>وضعیت</th>
              <th style={thStyle}>عملیات</th>
            </tr>
          </thead>
          <tbody>
            {margins.map((m) => (
              <tr key={m.id} style={tbodyRowStyle}>
                <td style={tdStyle}>{m.grade.code}</td>
                <td style={{ ...tdStyle, fontFamily: 'monospace' }}>{m.floorPercent}%</td>
                <td style={{ ...tdStyle, fontFamily: 'monospace' }}>{m.targetPercent}%</td>
                <td style={{ ...tdStyle, fontFamily: 'monospace' }}>{m.stretchPercent}%</td>
                <td style={tdStyle}><StatusBadge active={m.isActive} /></td>
                <td style={tdStyle}>
                  <a href={`/admin-pricing/margins/${m.id}`} style={btnEditStyle}>ویرایش</a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  )
}

// ==================== تب ۶: قوانین تایید مدیر فروش ====================
async function Tab6Approval() {
  const rules = await prisma.approvalRule.findMany({ orderBy: { createdAt: 'desc' } })

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <h2 style={{ fontSize: 16, fontWeight: 800 }}>قوانین تایید مدیر فروش</h2>
        <a href="/admin-pricing/approval/new" style={btnPrimaryStyle}>+ افزودن قانون</a>
      </div>

      <div style={{ background: '#eef4fd', border: '1px solid #1e357b', borderRadius: 8, padding: '12px 16px', marginBottom: 16, fontSize: 12.5, lineHeight: 1.6 }}>
        <b>یادآوری:</b> موتور تایید هیچ عدد هاردکد شده‌ای نداره — همه‌چیز از همین جدول خونده می‌شه. threshold بالاتر → سطح تایید بالاتر.
      </div>

      {rules.length === 0 && <EmptyState message="هیچ قانون تاییدی تعریف نشده — همه‌چیز خودکار خواهد بود." />}

      {rules.length > 0 && (
        <table style={tableStyle}>
          <thead>
            <tr style={theadRowStyle}>
              <th style={thStyle}>موجودیت</th>
              <th style={thStyle}>نوع شرط</th>
              <th style={thStyle}>حد آستانه</th>
              <th style={thStyle}>سطح موردنیاز</th>
              <th style={thStyle}>وضعیت</th>
              <th style={thStyle}>عملیات</th>
            </tr>
          </thead>
          <tbody>
            {rules.map((r) => (
              <tr key={r.id} style={tbodyRowStyle}>
                <td style={tdStyle}>{entityTypeLabel(r.entityType)}</td>
                <td style={tdStyle}>{r.conditionType === 'amount' ? 'مبلغ' : 'درصد انحراف'}</td>
                <td style={{ ...tdStyle, fontFamily: 'monospace' }}>
                  {r.conditionType === 'amount' ? `${(r.thresholdValue / 1_000_000).toLocaleString('fa-IR')} میلیون تومان` : `${r.thresholdValue}%`}
                </td>
                <td style={tdStyle}>{approvalLevelLabel(r.requiredLevel)}</td>
                <td style={tdStyle}><StatusBadge active={r.isActive} /></td>
                <td style={tdStyle}>
                  <a href={`/admin-pricing/approval/${r.id}`} style={btnEditStyle}>ویرایش</a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  )
}

// ==================== تب ۷: مدیریت لیست‌های بنچینو & انتشار ====================
async function Tab7Publish({ searchParams }: { searchParams: { tab?: string; subtab?: string } }) {
  const subtab = searchParams.subtab || 'benchino'

  return (
    <div>
      <div style={{ display: 'flex', gap: 12, marginBottom: 20, borderBottom: '1px solid #eceff3', paddingBottom: 12 }}>
        <SubtabLink href="/admin-pricing?tab=publish&subtab=benchino" label="۷.۱ لیست بنچینو" active={subtab === 'benchino'} />
        <SubtabLink href="/admin-pricing?tab=publish&subtab=live" label="۷.۲ قیمت‌های لایو داخلی" active={subtab === 'live'} />
        <SubtabLink href="/admin-pricing?tab=publish&subtab=release" label="۷.۳ انتشار بنچمارک" active={subtab === 'release'} />
      </div>

      {subtab === 'benchino' && <Tab7_1Benchino />}
      {subtab === 'live' && <Tab7_2Live />}
      {subtab === 'release' && <Tab7_3Release />}
    </div>
  )
}

function SubtabLink({ href, label, active }: { href: string; label: string; active: boolean }) {
  return (
    <a
      href={href}
      style={{
        fontSize: 12,
        fontWeight: active ? 700 : 500,
        color: active ? '#f6621b' : '#6f7680',
        padding: '6px 12px',
        textDecoration: 'none',
        borderRadius: 6,
        background: active ? '#fef3e8' : 'transparent',
      }}
    >
      {label}
    </a>
  )
}

// ۷.۱ لیست بنچینو — قیمت مرجع جهانی
async function Tab7_1Benchino() {
  const prices = await prisma.globalBenchmarkPrice.findMany({
    include: { grade: true } as any,
    orderBy: { effectiveDate: 'desc' },
    take: 100,
  })

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <h3 style={{ fontSize: 15, fontWeight: 700 }}>قیمت مرجع جهانی گریدها (دلار/تن)</h3>
        <a href="/admin-pricing/benchino/new" style={btnPrimaryStyle}>+ افزودن قیمت</a>
      </div>

      {prices.length === 0 && <EmptyState message="هیچ قیمت مرجع جهانی ثبت نشده." />}

      {prices.length > 0 && (
        <table style={tableStyle}>
          <thead>
            <tr style={theadRowStyle}>
              <th style={thStyle}>گرید</th>
              <th style={thStyle}>قیمت (USD/ton)</th>
              <th style={thStyle}>منبع</th>
              <th style={thStyle}>تاریخ اعمال</th>
              <th style={thStyle}>عملیات</th>
            </tr>
          </thead>
          <tbody>
            {prices.map((p: any) => (
              <tr key={p.id} style={tbodyRowStyle}>
                <td style={tdStyle}>{p.grade?.code || '—'}</td>
                <td style={{ ...tdStyle, fontFamily: 'monospace', direction: 'ltr', textAlign: 'right' }}>${p.priceUsd.toLocaleString('en-US')}</td>
                <td style={tdStyle}>{p.sourceLabel || '—'}</td>
                <td style={{ ...tdStyle, fontSize: 11, color: '#6f7680' }}>
                  {new Date(p.effectiveDate).toLocaleDateString('fa-IR', { dateStyle: 'short' })}
                </td>
                <td style={tdStyle}>
                  <a href={`/admin-pricing/benchino/${p.id}`} style={btnEditStyle}>ویرایش</a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  )
}

// ۷.۲ قیمت‌های لایو داخلی — از WarehouseStock + dealLightStatus
async function Tab7_2Live() {
  const stocks = await prisma.warehouseStock.findMany({
    include: { grade: true, warehouse: true } as any,
    orderBy: { updatedAt: 'desc' },
    take: 50,
  })

  return (
    <div>
      <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 16 }}>قیمت‌های لایو موجودی انبار</h3>

      {stocks.length === 0 && <EmptyState message="هیچ موجودی فعالی یافت نشد." />}

      {stocks.length > 0 && (
        <table style={tableStyle}>
          <thead>
            <tr style={theadRowStyle}>
              <th style={thStyle}>گرید</th>
              <th style={thStyle}>انبار</th>
              <th style={thStyle}>موجودی (تن)</th>
              <th style={thStyle}>قیمت (ریال/کیلو)</th>
              <th style={thStyle}>وضعیت</th>
              <th style={thStyle}>آخرین بروزرسانی</th>
            </tr>
          </thead>
          <tbody>
            {stocks.map((s: any) => {
              const lightColor = s.dealLightStatus === 'available' ? '#22c55e' : s.dealLightStatus === 'negotiating' ? '#f59e0b' : '#ef4444'
              const lightLabel = s.dealLightStatus === 'available' ? 'آزاد' : s.dealLightStatus === 'negotiating' ? 'در حال معامله' : 'به تازگی معامله شد'
              return (
                <tr key={s.id} style={tbodyRowStyle}>
                  <td style={tdStyle}>{s.grade?.code || '—'}</td>
                  <td style={tdStyle}>{s.warehouse?.name || '—'}</td>
                  <td style={{ ...tdStyle, fontFamily: 'monospace' }}>{s.quantityTon.toFixed(2)}</td>
                  <td style={{ ...tdStyle, fontFamily: 'monospace', direction: 'ltr', textAlign: 'right' }}>
                    {s.priceRial.toLocaleString('fa-IR')}
                  </td>
                  <td style={tdStyle}>
                    <span style={{ fontSize: 10, fontWeight: 700, color: lightColor, background: `${lightColor}15`, borderRadius: 4, padding: '2px 8px' }}>
                      {lightLabel}
                    </span>
                  </td>
                  <td style={{ ...tdStyle, fontSize: 11, color: '#6f7680' }}>
                    {new Date(s.updatedAt).toLocaleDateString('fa-IR', { dateStyle: 'short', timeStyle: 'short' })}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      )}
    </div>
  )
}

// ۷.۳ انتشار بنچمارک — نمایش سوابق + فرم انتشار جدید
async function Tab7_3Release() {
  const records = await prisma.benchmarkPublishRecord.findMany({
    orderBy: { createdAt: 'desc' },
    take: 20,
  })

  return (
    <div>
      <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 16 }}>انتشار بنچمارک امروز</h3>

      <div style={cardStyle}>
        <form action="/admin-pricing/release" method="POST">
          <div style={{ marginBottom: 14 }}>
            <label style={labelStyle}>حالت انتشار</label>
            <select name="mode" style={selectStyle} required>
              <option value="global">کلی (یک درصد برای همه)</option>
              <option value="detailed">جزئی (ردیف‌به‌ردیف)</option>
            </select>
          </div>

          <div style={{ marginBottom: 14 }}>
            <label style={labelStyle}>
              درصد تنظیم کلی (اگه حالت کلی) <span style={{ fontWeight: 400, color: '#6f7680' }}>— مثلاً +5 یا -3</span>
            </label>
            <input type="number" step="0.1" name="globalAdjustPercent" placeholder="0" style={inputStyle} />
          </div>

          <button type="submit" style={{ ...btnPrimaryStyle, width: '100%', textAlign: 'center' }}>
            📤 انتشار بنچمارک امروز
          </button>
        </form>
      </div>

      <h4 style={{ fontSize: 14, fontWeight: 700, marginBottom: 12 }}>سوابق انتشار</h4>

      {records.length === 0 && <EmptyState message="هنوز هیچ بنچمارکی منتشر نشده." />}

      {records.length > 0 && (
        <table style={tableStyle}>
          <thead>
            <tr style={theadRowStyle}>
              <th style={thStyle}>تاریخ</th>
              <th style={thStyle}>حالت</th>
              <th style={thStyle}>تنظیم کلی</th>
              <th style={thStyle}>وضعیت</th>
              <th style={thStyle}>سطح تایید</th>
              <th style={thStyle}>عملیات</th>
            </tr>
          </thead>
          <tbody>
            {records.map((r) => (
              <tr key={r.id} style={tbodyRowStyle}>
                <td style={{ ...tdStyle, fontSize: 11 }}>
                  {new Date(r.createdAt).toLocaleDateString('fa-IR', { dateStyle: 'short', timeStyle: 'short' })}
                </td>
                <td style={tdStyle}>{r.mode === 'global' ? 'کلی' : 'جزئی'}</td>
                <td style={{ ...tdStyle, fontFamily: 'monospace' }}>
                  {r.globalAdjustPercent !== null ? `${r.globalAdjustPercent > 0 ? '+' : ''}${r.globalAdjustPercent}%` : '—'}
                </td>
                <td style={tdStyle}>{publishStatusLabel(r.status)}</td>
                <td style={tdStyle}>{r.approvalLevel ? approvalLevelLabel(r.approvalLevel) : '—'}</td>
                <td style={tdStyle}>
                  <a href={`/admin-pricing/release/${r.id}`} style={btnEditStyle}>جزئیات</a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  )
}

// ==================== کامپوننت‌های مشترک ====================
function EmptyState({ message }: { message: string }) {
  return (
    <div style={emptyStateStyle}>
      {message}
    </div>
  )
}

function StatusBadge({ active }: { active: boolean }) {
  return (
    <span style={badgeStyle(active ? 'success' : 'danger')}>
      {active ? 'فعال' : 'غیرفعال'}
    </span>
  )
}

function conditionTypeLabel(type: string) {
  return type === 'price_range' ? 'محدوده قیمت' : type === 'grade_category' ? 'دسته گرید' : 'گرید خاص'
}

function entityTypeLabel(type: string) {
  return type === 'Order' ? 'سفارش' : type === 'Deal' ? 'معامله' : 'انتشار بنچمارک'
}

function approvalLevelLabel(level: string) {
  return level === 'auto' ? 'خودکار' : level === 'supervisor' ? 'سرپرست' : level === 'manager' ? 'مدیر' : 'ادمین'
}

function publishStatusLabel(status: string) {
  return status === 'pending' ? 'در انتظار تایید' : status === 'approved' ? 'تایید شده' : status === 'published' ? 'منتشرشده' : 'رد شده'
}

// ==================== استایل‌ها ====================
const tbodyRowStyle: React.CSSProperties = {
  borderTop: '1px solid #eceff3',
}

const btnEditStyle: React.CSSProperties = {
  ...btnSecondaryStyle,
  ...btnSmallStyle,
  textDecoration: 'none',
  display: 'inline-block',
}
