import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import AdminNav from '@/components/AdminNav'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'
import {
  updateCompanyIdentityAction,
  updateProducerFieldsAction,
  updateApiFieldsAction,
  overrideLevelAction,
} from './actions'

export const dynamic = 'force-dynamic'

const LEGAL_TYPES = [
  { value: 'factory', label: 'کارخانه / واحد تولیدی' },
  { value: 'production_unit', label: 'واحد تولیدی کوچک' },
  { value: 'trading_company', label: 'شرکت بازرگانی' },
  { value: 'cooperative', label: 'تعاونی' },
  { value: 'official_agent', label: 'نماینده‌ی رسمی' },
  { value: 'importer', label: 'واردکننده' },
  { value: 'exporter', label: 'صادرکننده' },
]
const BADGE_OPTIONS = ['none', 'verified_company', 'verified_producer', 'trusted_supplier', 'trusted_buyer']

export default async function AdminKycDetailPage({ params }: { params: Promise<{ companyId: string }> }) {
  const { companyId } = await params
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'

  if (!isAdmin) {
    return (
      <div style={{ display: 'flex', gap: 24, padding: '32px 24px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', maxWidth: 1100, margin: '0 auto' }}>
        <AdminNav currentUserName={currentUser.companyName} isAdmin={isAdmin} accessMap={{}} activeSection="kyc" />
        <div style={{ flex: 1 }}>این بخش فقط برای نقش «مدیر» در دسترسه.</div>
      </div>
    )
  }

  const company = await prisma.company.findUnique({
    where: { id: companyId },
    include: { kyc: true, user: true },
  })

  if (!company) {
    return <div style={{ padding: 32, fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl' }}>پرونده‌ای با این شناسه پیدا نشد.</div>
  }

  const kyc = company.kyc

  return (
    <div style={{ display: 'flex', gap: 24, padding: '32px 24px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', maxWidth: 1100, margin: '0 auto' }}>
      <AdminNav currentUserName={currentUser.companyName} isAdmin={isAdmin} accessMap={{}} activeSection="kyc" />

      <div style={{ flex: 1, minWidth: 0 }}>
        <a href="/admin-kyc" style={{ fontSize: 12, color: '#1e357b', marginBottom: 12, display: 'inline-block' }}>← بازگشت به فهرست</a>
        <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>{company.companyName}</h1>
        <p style={{ color: '#6f7680', fontSize: 12.5, marginBottom: 20, fontFamily: 'monospace', direction: 'ltr', textAlign: 'right' }}>{company.user.phone}</p>

        {/* ================= نتیجه‌ی نهایی — سطح و بج ================= */}
        <div style={cardStyle}>
          <h3 style={{ fontSize: 15, marginBottom: 6 }}>🏁 نتیجه‌ی نهایی</h3>
          <p style={{ fontSize: 11.5, color: '#9199a3', marginBottom: 14, lineHeight: 1.8 }}>
            این بخش سطح و بج رو مستقیم عوض می‌کنه — برای اصلاح دستی موارد خاص (نه روند عادی تایید/رد که توی «مدیریت کاربران» انجام می‌شه).
          </p>
          <form action={overrideLevelAction} style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <input type="hidden" name="companyId" value={company.id} />
            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
              <select name="level" defaultValue={kyc?.level ?? 0} style={inputStyle}>
                <option value={0}>سطح ۰ — کاربر ساده</option>
                <option value={1}>سطح ۱ — شرکت تایید‌شده</option>
                <option value={2}>سطح ۲ — تولیدکننده‌ی تایید‌شده</option>
                <option value={3}>سطح ۳ — چند معامله‌ی موفق</option>
              </select>
              <select name="badge" defaultValue={kyc?.badge ?? 'none'} style={inputStyle}>
                {BADGE_OPTIONS.map((b) => <option key={b} value={b}>{b}</option>)}
              </select>
            </div>
            <textarea name="reviewNote" placeholder="یادداشت بررسی (چرا این تغییر؟)" defaultValue={kyc?.reviewNote ?? ''} rows={2} style={{ ...inputStyle, fontFamily: 'inherit', resize: 'vertical' }} />
            {kyc?.reviewedAt && (
              <div style={{ fontSize: 11, color: '#9199a3' }}>آخرین بررسی: {new Date(kyc.reviewedAt).toLocaleString('fa-IR')}</div>
            )}
            <ConfirmSubmitButton message="سطح و بج این پرونده مستقیم تغییر می‌کنه. مطمئنی؟" style={{ ...btnStyle, alignSelf: 'flex-start' }}>
              اعمال تغییر مستقیم
            </ConfirmSubmitButton>
          </form>
        </div>

        {/* ================= هویت شرکت — دستی ================= */}
        <div style={cardStyle}>
          <h3 style={{ fontSize: 15, marginBottom: 6 }}>🏢 هویت شرکت <span style={sourceTag}>ورودی کاربر</span></h3>
          <p style={{ fontSize: 11.5, color: '#9199a3', marginBottom: 14 }}>همون فیلدهایی که خودِ کاربر توی /verification پر می‌کنه — این‌جا مدیر می‌تونه اصلاحشون کنه.</p>
          <form action={updateCompanyIdentityAction} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <input type="hidden" name="companyId" value={company.id} />
            <input name="companyName" defaultValue={company.companyName} placeholder="نام شرکت" style={inputStyle} />
            <select name="legalType" defaultValue={company.legalType} style={inputStyle}>
              {LEGAL_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
            </select>
            <input name="nationalId" defaultValue={company.nationalId ?? ''} placeholder="شناسه‌ی ملی" style={inputStyle} />
            <input name="registrationNumber" defaultValue={company.registrationNumber ?? ''} placeholder="شماره‌ی ثبت" style={inputStyle} />
            <input name="economicCode" defaultValue={company.economicCode ?? ''} placeholder="کد اقتصادی" style={inputStyle} />
            <input name="taxNumber" defaultValue={company.taxNumber ?? ''} placeholder="شماره‌ی مالیاتی" style={inputStyle} />
            <input name="province" defaultValue={company.province ?? ''} placeholder="استان" style={inputStyle} />
            <input name="city" defaultValue={company.city ?? ''} placeholder="شهر" style={inputStyle} />
            <input name="postalCode" defaultValue={company.postalCode ?? ''} placeholder="کدپستی" style={inputStyle} />
            <input name="companyPhone" defaultValue={company.companyPhone ?? ''} placeholder="تلفن ثابت شرکت" style={inputStyle} />
            <input name="website" defaultValue={company.website ?? ''} placeholder="وب‌سایت (اختیاری)" style={inputStyle} />
            <input name="address" defaultValue={company.address ?? ''} placeholder="آدرس دقیق" style={inputStyle} />
            <ConfirmSubmitButton message="اطلاعات هویتی این شرکت تغییر می‌کنه. مطمئنی؟" style={{ ...btnStyle, gridColumn: '1 / -1' }}>
              ذخیره‌ی هویت شرکت
            </ConfirmSubmitButton>
          </form>
        </div>

        {/* ================= احراز تولیدکننده — دستی + سند ================= */}
        <div style={cardStyle}>
          <h3 style={{ fontSize: 15, marginBottom: 6 }}>🏭 احراز تولیدکننده <span style={sourceTag}>ورودی کاربر + سند</span></h3>
          <p style={{ fontSize: 11.5, color: '#9199a3', marginBottom: 14 }}>
            شماره‌ی پروانه رو با <a href="https://behinyab.ir" target="_blank" style={{ color: '#1e357b' }}>behinyab.ir</a> تطبیق بده.
          </p>
          {kyc?.productionLicenseFileUrl && (
            <div style={{ marginBottom: 12 }}>
              <a href={kyc.productionLicenseFileUrl} target="_blank" style={{ color: '#1e357b', fontSize: 12.5, fontWeight: 700 }}>مشاهده‌ی تصویر پروانه ↗</a>
            </div>
          )}
          <form action={updateProducerFieldsAction} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <input type="hidden" name="companyId" value={company.id} />
            <input name="productionLicenseNumber" defaultValue={kyc?.productionLicenseNumber ?? ''} placeholder="شماره‌ی پروانه‌ی بهره‌برداری" style={inputStyle} />
            <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12.5 }}>
              <input type="checkbox" name="productionLicenseIsSetup" defaultChecked={kyc?.productionLicenseIsSetup ?? false} />
              جواز تاسیس (نه پروانه‌ی نهایی)
            </label>
            <input name="factoryActivityType" defaultValue={kyc?.factoryActivityType ?? ''} placeholder="نوع فعالیت تولیدی" style={inputStyle} />
            <input name="factoryAddress" defaultValue={kyc?.factoryAddress ?? ''} placeholder="آدرس کارخانه" style={inputStyle} />
            <textarea name="factoryProducts" defaultValue={kyc?.factoryProducts ?? ''} placeholder="محصولات تولیدی" rows={2} style={{ ...inputStyle, gridColumn: '1 / -1', fontFamily: 'inherit', resize: 'vertical' }} />
            <ConfirmSubmitButton message="اطلاعات کارخانه تغییر می‌کنه. مطمئنی؟" style={{ ...btnStyle, gridColumn: '1 / -1' }}>
              ذخیره‌ی اطلاعات تولیدکننده
            </ConfirmSubmitButton>
          </form>
        </div>

        {/* ================= داده‌های استعلام API — لینکا/دستی ================= */}
        <div style={cardStyle}>
          <h3 style={{ fontSize: 15, marginBottom: 6 }}>🔌 داده‌های استعلام <span style={sourceTag}>API (وقتی وصل بشه) یا دستی</span></h3>
          <p style={{ fontSize: 11.5, color: '#9199a3', marginBottom: 14, lineHeight: 1.8 }}>
            این فیلدها قراره بعداً خودکار از لینکا/api.ir پر بشن. تا اون‌موقع، اگه دستی (مثلاً با تماس تلفنی یا استعلام روی rrk.ir) چیزی رو تایید کردی، همین‌جا ثبتش کن.
          </p>
          <form action={updateApiFieldsAction} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <input type="hidden" name="companyId" value={company.id} />
            <select name="verificationSource" defaultValue={kyc?.verificationSource ?? 'manual'} style={inputStyle}>
              <option value="manual">دستی</option>
              <option value="api">API</option>
            </select>
            <input name="apiIntegrationUsed" defaultValue={kyc?.apiIntegrationUsed ?? ''} placeholder="کدوم API (مثلاً linka)" style={inputStyle} />
            <select name="companyManagerMatch" defaultValue={kyc?.companyManagerMatch === true ? 'true' : kyc?.companyManagerMatch === false ? 'false' : ''} style={inputStyle}>
              <option value="">تطابق شخص↔شرکت: نامشخص</option>
              <option value="true">تطابق دارد</option>
              <option value="false">تطابق ندارد</option>
            </select>
            <div />
            <input name="linkaCompanyName" defaultValue={kyc?.linkaCompanyName ?? ''} placeholder="نام شرکت طبق استعلام" style={inputStyle} />
            <input name="linkaManagerName" defaultValue={kyc?.linkaManagerName ?? ''} placeholder="نام مدیرعامل طبق استعلام" style={inputStyle} />
            <input name="linkaCompanyStatus" defaultValue={kyc?.linkaCompanyStatus ?? ''} placeholder="وضعیت ثبتی (فعال/منحل/...)" style={{ ...inputStyle, gridColumn: '1 / -1' }} />
            {kyc?.linkaCheckedAt && (
              <div style={{ fontSize: 11, color: '#9199a3', gridColumn: '1 / -1' }}>آخرین استعلام موفق: {new Date(kyc.linkaCheckedAt).toLocaleString('fa-IR')}</div>
            )}
            <ConfirmSubmitButton message="داده‌های استعلام تغییر می‌کنه. مطمئنی؟" style={{ ...btnStyle, gridColumn: '1 / -1' }}>
              ذخیره‌ی داده‌های استعلام
            </ConfirmSubmitButton>
          </form>
        </div>
      </div>
    </div>
  )
}

const cardStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 12, padding: 20, marginBottom: 20, background: '#fff', boxShadow: '0 1px 4px rgba(27,30,36,.05)' }
const inputStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 8, padding: '9px 12px', fontSize: 13, fontFamily: 'inherit' }
const btnStyle: React.CSSProperties = { background: '#1e357b', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 18px', fontSize: 13, fontWeight: 700, cursor: 'pointer' }
const sourceTag: React.CSSProperties = { fontSize: 10, fontWeight: 700, background: '#eef4fd', color: '#1e357b', borderRadius: 20, padding: '2px 10px', marginRight: 8 }
