import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import UserNav from '@/components/UserNav'
import PanelHeader from '@/components/PanelHeader'
import PanelFooter from '@/components/PanelFooter'
import { enforceProformaDeadlines } from '@/lib/dealDeadlines'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { cardStyle as sharedCardStyle, badgeStyle, emptyStateStyle, orderStatusBadgeStyle, getOrderStatusLabel } from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

/**
 * صفحه‌ی لیست «پیش‌فاکتورهای من» — فقط سفارش‌هایی که کارشناس قیمت‌گذاری کرده
 * (status: priced) یا مشتری تایید کرده و در مرحله‌ی قرارداد (buyer_confirmed / contracted).
 *
 * وضعیت‌های واقعی از workflow.ts:
 *   priced → buyer_confirmed → contracted
 */

const STATUS_LABELS: Record<string, string> = {
  priced: 'در انتظار تایید شما',
  buyer_confirmed: 'تایید شد — در حال عقد قرارداد',
  contracted: getOrderStatusLabel('contracted'),
}

export default async function ProformasPage() {
  const user = await getCurrentUser()

  // مثل بقیه‌ی مهلت‌ها (بدون cron): موقع لود این صفحه، سفارش‌هایی که مهلت
  // تاییدشون گذشته خودکار باطل و موجودیشون به انبار برمی‌گرده.
  await enforceProformaDeadlines()

  const orders = await prisma.order.findMany({
    where: {
      userId: user.id,
      status: { in: ['priced', 'buyer_confirmed', 'contracted'] },
    },
    include: { items: { include: { grade: true } } },
    orderBy: { createdAt: 'desc' },
  })

  return (
    <>
    <PanelHeader currentUserName={user.companyName} />
    <div style={pageStyle}>
      <div style={{ width: '100%', display: 'flex', gap: 24 }} className="admin-page-wrap">
        <UserNav currentUserName={user.companyName} activeSection="proformas" />
        <div style={{ flex: 1, minWidth: 0 }}>
          <h1 style={{ fontSize: fontSize.xxl, fontWeight: 800, marginBottom: spacing.xs, color: colors.textPrimary }}>پیش‌فاکتورهای من</h1>
          <p style={{ fontSize: fontSize.base, color: colors.textMuted, marginBottom: spacing.xl }}>
            سفارش‌هایی که قیمت‌گذاری شدن و منتظر تایید یا در مرحله‌ی قرارداد هستن
          </p>

          {orders.length === 0 && (
            <div style={emptyBox}>
              هیچ پیش‌فاکتور فعالی ندارید — وقتی کارشناس فروش قیمت سفارش شما را ثبت کنه، اینجا نمایش داده می‌شه.
            </div>
          )}

          {orders.map((order) => {
            const gradeSummary = order.items.map((i) => i.grade.code).join(' + ')
            const totalRial = order.items.reduce(
              (sum, it) => sum + (it.finalPrice ?? it.price) * it.quantity,
              0
            )

            return (
              <a key={order.id} href={`/proformas/${order.id}`} style={cardLink}>
                <div style={cardStyle}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.md }}>
                    <b style={{ fontSize: fontSize.md }}>سفارش #{order.id.slice(0, 8)}</b>
                    <span style={orderStatusBadgeStyle(order.status)}>{STATUS_LABELS[order.status] || order.status}</span>
                  </div>

                  <div style={{ fontSize: fontSize.sm, color: colors.neutralText, marginBottom: 6 }}>
                    <span style={{ fontFamily: 'monospace' }}>{gradeSummary}</span>
                  </div>

                  {order.status === 'priced' && order.proformaDeadline && (
                    <div style={{ fontSize: fontSize.sm, color: colors.warningText, marginBottom: 6 }}>
                      ⏳ مهلت تایید: {new Date(order.proformaDeadline).toLocaleString('fa-IR', { dateStyle: 'short', timeStyle: 'short' })} — بعد از این زمان سفارش خودکار باطل می‌شود
                    </div>
                  )}

                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: fontSize.sm, fontWeight: 700 }}>
                      {totalRial.toLocaleString('en-US')} ریال
                    </span>
                    <span style={{ fontSize: fontSize.xs, color: colors.textMuted }}>
                      {new Date(order.createdAt).toLocaleDateString('fa-IR')}
                    </span>
                  </div>
                </div>
              </a>
            )
          })}
        </div>
      </div>
    </div>
    <PanelFooter />
  </>
)
}

const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: colors.bgPage,
  padding: `${spacing.xxl}px ${spacing.xl}px`,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const emptyBox: React.CSSProperties = {
  ...emptyStateStyle,
  padding: 32,
}
const cardLink: React.CSSProperties = {
  display: 'block',
  textDecoration: 'none',
  color: 'inherit',
}
const cardStyle: React.CSSProperties = {
  ...sharedCardStyle,
  padding: 18,
  marginBottom: 14,
  transition: 'border-color .15s',
}
