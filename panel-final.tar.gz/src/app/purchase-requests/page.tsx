import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import UserNav from '@/components/UserNav'
import PanelHeader from '@/components/PanelHeader'
import PanelFooter from '@/components/PanelFooter'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'
import { createPurchaseRequestAction, closePurchaseRequestAction } from './actions'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { cardStyle as sharedCardStyle, badgeStyle, btnPrimaryStyle, inputStyle as sharedInputStyle, selectStyle as sharedSelectStyle, labelStyle as sharedLabelStyle, emptyStateStyle } from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

type SearchParams = Promise<Record<string, string | string[] | undefined>>

function one(v: string | string[] | undefined): string | undefined {
  if (Array.isArray(v)) return v[0]
  return v
}

export default async function PurchaseRequestsPage({
  searchParams,
}: {
  searchParams: SearchParams
}) {
  const sp = await searchParams
  const user = await getCurrentUser()
  const showForm = one(sp.new) === '1'

  // درخواست‌های خرید کاربر
  const myRequests = await prisma.purchaseRequest.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    include: {
      grade: true,
      _count: { select: { listings: true } },
    },
  })

  // گریدهای فعال — برای dropdown فرم
  const grades = showForm
    ? await prisma.grade.findMany({
        where: { isActive: true },
        orderBy: { code: 'asc' },
        select: { id: true, code: true, producer: true, category: true },
      })
    : []

  return (
    <>
    <PanelHeader currentUserName={user.companyName} />
    <div style={pageStyle}>
      <div style={{ width: '100%', display: 'flex', gap: 24 }} className="admin-page-wrap">
        <UserNav currentUserName={user.companyName} activeSection="purchase-requests" />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <div>
              <h1 style={{ fontSize: fontSize.xxl, fontWeight: 800, margin: 0, marginBottom: spacing.xs, color: colors.textPrimary }}>درخواست‌های خرید</h1>
              <p style={{ fontSize: fontSize.base, color: colors.textMuted, margin: 0 }}>
                اعلام نیاز خرید مواد اولیه — فروشنده‌ها می‌بینن و آگهی می‌سازن
              </p>
            </div>
            {!showForm && (
              <a href="/purchase-requests?new=1" style={newBtnStyle}>
                + ثبت درخواست جدید
              </a>
            )}
          </div>

          {/* ── فرم ثبت درخواست جدید ── */}
          {showForm && (
            <div style={cardStyle}>
              <h3 style={{ fontSize: fontSize.lg, fontWeight: 700, margin: 0, marginBottom: spacing.lg }}>
                ثبت درخواست خرید جدید
              </h3>
              <form action={createPurchaseRequestAction}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
                  <div>
                    <div style={labelStyle}>گرید مورد نظر *</div>
                    <select name="gradeId" required style={selectStyle}>
                      <option value="">انتخاب گرید…</option>
                      {grades.map((g) => (
                        <option key={g.id} value={g.id}>
                          {g.code} — {g.producer} ({g.category})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <div style={labelStyle}>مقدار درخواستی (تن) *</div>
                    <input name="quantityTon" type="number" step="0.1" min="0.1" required
                      placeholder="مثلاً ۲۵" style={inputStyle} />
                  </div>
                  <div>
                    <div style={labelStyle}>سقف قیمت (تومان/کیلو)</div>
                    <input name="maxPriceToman" type="number" step="1" min="1"
                      placeholder="اختیاری — خالی = بدون سقف" style={inputStyle} />
                  </div>
                  <div>
                    <div style={labelStyle}>استان ترجیحی محل بار</div>
                    <input name="province" placeholder="اختیاری" style={inputStyle} />
                  </div>
                  <div>
                    <div style={labelStyle}>مدت اعتبار (روز)</div>
                    <select name="expiresInDays" defaultValue="14" style={selectStyle}>
                      <option value="7">۷ روز</option>
                      <option value="14">۱۴ روز</option>
                      <option value="30">۳۰ روز</option>
                      <option value="60">۶۰ روز</option>
                      <option value="90">۹۰ روز</option>
                    </select>
                  </div>
                  <div style={{ gridColumn: '1 / -1' }}>
                    <div style={labelStyle}>توضیحات</div>
                    <textarea name="description" rows={3}
                      placeholder="شرایط خاص، کیفیت مدنظر، حجم بسته‌بندی و غیره"
                      style={{ ...inputStyle, resize: 'vertical' }} />
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
                  <a href="/purchase-requests" style={{ ...submitBtnStyle, background: colors.neutralBg, color: colors.neutralText, textDecoration: 'none', fontSize: fontSize.sm, padding: '9px 18px', fontWeight: 600 }}>
                    انصراف
                  </a>
                  <button type="submit" style={submitBtnStyle}>ثبت درخواست</button>
                </div>
              </form>
            </div>
          )}

          {/* ── لیست درخواست‌ها ── */}
          <div style={cardStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.md }}>
              <b style={{ fontSize: fontSize.md }}>درخواست‌های من</b>
              <span style={{ fontSize: fontSize.sm, fontWeight: 700, background: colors.orange, color: '#fff', borderRadius: radius.md, padding: '2px 10px' }}>
                {myRequests.length}
              </span>
            </div>

            {myRequests.length === 0 ? (
              <div style={emptyStyle}>هنوز درخواست خریدی ثبت نکردی.</div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {myRequests.map((req) => {
                  const isExpired = req.status === 'open' && req.expiresAt && new Date(req.expiresAt) < new Date()
                  const displayStatus = isExpired ? 'expired' : req.status
                  return (
                    <div key={req.id} style={reqCardStyle}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: spacing.sm }}>
                        <div>
                          <span style={{ fontSize: fontSize.md, fontWeight: 700 }}>
                            {req.grade.code}
                          </span>
                          <span style={{ fontSize: fontSize.xs, color: colors.textMuted, fontFamily: 'monospace', marginRight: spacing.sm }}>
                            #{req.id.slice(0, 8)}
                          </span>
                          <span style={{ ...statusTagStyle(displayStatus), marginRight: spacing.sm }}>
                            {translateStatus(displayStatus)}
                          </span>
                        </div>
                        <span style={{ fontSize: fontSize.xs, color: colors.textMuted }}>
                          {new Date(req.createdAt).toLocaleDateString('fa-IR')}
                        </span>
                      </div>

                      <div style={{ display: 'flex', gap: spacing.xl, fontSize: fontSize.sm, color: colors.neutralText, marginBottom: 6, flexWrap: 'wrap' }}>
                        <span>مقدار: <b>{req.quantityTon} تن</b></span>
                        {req.maxPriceToman && (
                          <span>سقف قیمت: <b style={{ color: colors.orange }}>{req.maxPriceToman.toLocaleString('fa-IR')} تومان/کیلو</b></span>
                        )}
                        {req.province && <span>استان: <b>{req.province}</b></span>}
                      </div>

                      {req.description && (
                        <div style={{ fontSize: fontSize.sm, color: colors.textSecondary, marginBottom: 6, fontStyle: 'italic' }}>
                          {req.description}
                        </div>
                      )}

                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 6 }}>
                        <span style={{ fontSize: fontSize.xs, color: colors.textMuted }}>
                          {req._count.listings > 0
                            ? `${req._count.listings} آگهی در پاسخ`
                            : 'هنوز آگهی‌ای ثبت نشده'}
                          {req.expiresAt && (
                            <> | انقضا: {new Date(req.expiresAt).toLocaleDateString('fa-IR')}</>
                          )}
                        </span>
                        {displayStatus === 'open' && (
                          <form action={closePurchaseRequestAction}>
                            <input type="hidden" name="requestId" value={req.id} />
                            <ConfirmSubmitButton
                              message="آیا مطمئنی که می‌خوای این درخواست رو ببندی؟"
                              style={{ background: 'none', border: 'none', color: colors.dangerText, fontSize: fontSize.xs, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit' }}
                            >
                              بستن درخواست
                            </ConfirmSubmitButton>
                          </form>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
    <PanelFooter />
  </>
)
}

// ── ترجمه و رنگ ─────────────────────────────────────────────────────
function translateStatus(status: string): string {
  const map: Record<string, string> = { open: 'باز', closed: 'بسته شده', expired: 'منقضی' }
  return map[status] ?? status
}

function statusTagStyle(status: string): React.CSSProperties {
  let kind: 'success' | 'info' | 'neutral' = 'neutral'
  if (status === 'open') kind = 'success'
  else if (status === 'closed') kind = 'info'
  else if (status === 'expired') kind = 'neutral'
  return badgeStyle(kind)
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: colors.bgPage,
  padding: `${spacing.xxl}px ${spacing.xl}px`,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const newBtnStyle: React.CSSProperties = {
  ...btnPrimaryStyle,
  display: 'inline-block',
  fontWeight: 700,
  textDecoration: 'none',
  whiteSpace: 'nowrap',
}
const cardStyle: React.CSSProperties = {
  ...sharedCardStyle,
  padding: 18,
  marginBottom: 14,
}
const inputStyle: React.CSSProperties = {
  ...sharedInputStyle,
}
const selectStyle: React.CSSProperties = {
  ...sharedSelectStyle,
}
const labelStyle: React.CSSProperties = {
  ...sharedLabelStyle,
}
const submitBtnStyle: React.CSSProperties = {
  ...btnPrimaryStyle,
  padding: '11px 28px',
  fontSize: fontSize.md,
  fontWeight: 800,
}
const emptyStyle: React.CSSProperties = {
  ...emptyStateStyle,
  padding: '20px 0',
}
const reqCardStyle: React.CSSProperties = {
  padding: '14px 16px',
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
  background: colors.bgPage,
}
