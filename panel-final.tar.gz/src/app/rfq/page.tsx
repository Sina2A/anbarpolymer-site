import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import UserNav from '@/components/UserNav'
import PanelHeader from '@/components/PanelHeader'
import PanelFooter from '@/components/PanelFooter'
import RfqCart from './RfqCart'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { emptyStateStyle } from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

export default async function RfqPage() {
  const user = await getCurrentUser()

  // فقط اقلامی که موجودی فعلی‌شون > 0 هست (انبارهایی که واقعاً چیزی دارن)
  const stocks = await prisma.warehouseStock.findMany({
    where: { quantityTon: { gt: 0 } },
    include: { grade: true, warehouse: true },
    orderBy: { updatedAt: 'desc' },
  })

  const items = stocks.map((s) => ({
    warehouseId: s.id,
    gradeId: s.gradeId,
    gradeCode: s.grade.code,
    producer: s.grade.producer,
    warehouseName: s.warehouse.name,
    warehouseCity: s.warehouse.city,
    availableTon: s.quantityTon,
    priceRial: s.priceRial,
  }))

  return (
    <>
      <PanelHeader currentUserName={user.companyName} />
      <div style={pageStyle}>
        <div style={wrapStyle}>
          <UserNav currentUserName={user.companyName} activeSection="rfq" />

          <div style={{ flex: 1, minWidth: 0 }}>
            <h1 style={titleStyle}>درخواست خرید از انبار (سبد چندمحصولی)</h1>
            <p style={subStyle}>
              موجودی زنده‌ی انبارها رو ببین، اقلام مورد نظرت رو به سبد اضافه کن،
              و در نهایت یک درخواست خرید واحد (Order) با چند ردیف ثبت کن.
            </p>

            {items.length === 0 ? (
              <div style={emptyStyle}>فعلاً هیچ موجودی فعالی توی انبارها ثبت نشده.</div>
            ) : (
              <RfqCart items={items} />
            )}
          </div>
        </div>
      </div>
      <PanelFooter />
    </>
  )
}

const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: colors.bgPage,
  padding: `${spacing.xxl}px ${spacing.xl}px`,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const wrapStyle: React.CSSProperties = {
  width: '100%',
  display: 'flex',
  gap: spacing.xl,
}
const titleStyle: React.CSSProperties = {
  fontSize: fontSize.xxl,
  fontWeight: 800,
  marginBottom: spacing.sm,
  color: colors.textPrimary,
}
const subStyle: React.CSSProperties = {
  color: colors.textSecondary,
  fontSize: fontSize.md,
  marginBottom: 22,
  lineHeight: 1.9,
}
const emptyStyle: React.CSSProperties = {
  ...emptyStateStyle,
  padding: 32,
}
