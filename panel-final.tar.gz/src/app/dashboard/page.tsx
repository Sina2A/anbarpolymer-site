import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getUserKycLevel } from '@/lib/kyc'
import KycStatusBanner from '@/components/KycStatusBanner'
import UserNav from '@/components/UserNav'
import PanelHeader from '@/components/PanelHeader'
import PanelFooter from '@/components/PanelFooter'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { cardStyle as sharedCardStyle, tableStyle as sharedTableStyle, theadRowStyle, thStyle as sharedThStyle, tdStyle as sharedTdStyle, badgeStyle, emptyStateStyle } from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

export default async function DashboardPage() {
  const user = await getCurrentUser()
  const kycLevel = await getUserKycLevel(user.id)

  // کارت خلاصه سفارش‌ها — تعداد Order با status مختلف
  const orderStats = await prisma.order.groupBy({
    by: ['status'],
    where: { userId: user.id },
    _count: true,
  })
  const orderStatusMap = Object.fromEntries(orderStats.map((s) => [s.status, s._count]))
  const totalOrders = orderStats.reduce((sum, s) => sum + s._count, 0)

  // کارت خلاصه حمل‌ونقل — تعداد Deal با status='in_transit' که کاربر خریدار یا فروشنده‌ست
  const inTransitCount = await prisma.deal.count({
    where: {
      status: 'in_transit',
      OR: [
        { buyerId: user.id },
        { materialListing: { userId: user.id } }, // کاربر فروشنده‌ست
      ],
    },
  })

  // جدول «درخواست‌های اخیر» — ترکیب Order + MaterialListing + Deal
  const recentOrders = await prisma.order.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    take: 5,
    include: { items: { include: { grade: true } } },
  })

  const recentListings = await prisma.materialListing.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    take: 5,
    include: { grade: true },
  })

  const recentDeals = await prisma.deal.findMany({
    where: {
      OR: [
        { buyerId: user.id },
        { materialListing: { userId: user.id } },
      ],
    },
    orderBy: { createdAt: 'desc' },
    take: 5,
    include: { materialListing: { include: { grade: true } } },
  })

  // ترکیب و مرتب‌سازی بر اساس تاریخ
  type RecentItem = {
    id: string
    type: 'order' | 'listing' | 'deal'
    description: string
    status: string
    date: Date
  }

  const allRecent: RecentItem[] = [
    ...recentOrders.map((o) => ({
      id: o.id,
      type: 'order' as const,
      description: `${o.items.length} قلم — ${o.items.map((i) => i.grade.code).join('، ')}`,
      status: o.status,
      date: o.createdAt,
    })),
    ...recentListings.map((l) => ({
      id: l.id,
      type: 'listing' as const,
      description: `${l.grade.code} — ${l.quantityTon} تن`,
      status: l.validityStatus,
      date: l.createdAt,
    })),
    ...recentDeals.map((d) => ({
      id: d.id,
      type: 'deal' as const,
      description: `${d.materialListing?.grade.code ?? 'معامله'} — ${d.quantity}`,
      status: d.status,
      date: d.createdAt,
    })),
  ]
    .sort((a, b) => b.date.getTime() - a.date.getTime())
    .slice(0, 10)

  return (
    <>
      <PanelHeader currentUserName={user.companyName} />
      <div style={pageStyle}>
        <div style={{ width: '100%', display: 'flex', gap: 24 }} className="admin-page-wrap">
          <UserNav currentUserName={user.companyName} activeSection="dashboard" />
          <div style={{ flex: 1, minWidth: 0 }}>
            <a href="/market" style={{ fontSize: fontSize.sm, color: colors.navy, textDecoration: 'none' }}>← بازگشت به سایت</a>
            <h1 style={{ fontSize: fontSize.xxl, fontWeight: 800, marginBottom: spacing.xs, marginTop: spacing.sm, color: colors.textPrimary }}>پیشخوان</h1>
            <p style={{ fontSize: fontSize.base, color: colors.textMuted, marginBottom: spacing.xl }}>
              خلاصه‌ی وضعیت خرید و فروش شما در انبار پلیمر
            </p>

            <KycStatusBanner level={kycLevel} />

            {/* دو کارت خلاصه — در یک ردیف */}
            <div style={{ display: 'flex', gap: 14, marginBottom: 14, flexWrap: 'wrap' }}>
              {/* کارت خلاصه سفارش‌ها */}
              <div style={{ ...cardStyle, flex: '1 1 300px' }}>
                <div style={{ fontSize: fontSize.md, fontWeight: 700, marginBottom: spacing.md, color: colors.textPrimary }}>
                  📦 سفارش‌ها
                </div>
                <div style={{ fontSize: 24, fontWeight: 800, color: colors.orange, marginBottom: spacing.sm }}>
                  {totalOrders}
                </div>
                <div style={{ fontSize: fontSize.xs, color: colors.textSecondary, display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                  {Object.entries(orderStatusMap).map(([status, count]) => (
                    <span key={status} style={{ background: colors.neutralBg, padding: '2px 8px', borderRadius: radius.sm }}>
                      {translateOrderStatus(status)}: {count}
                    </span>
                  ))}
                </div>
              </div>

              {/* کارت خلاصه حمل‌ونقل */}
              <div style={{ ...cardStyle, flex: '1 1 300px' }}>
                <div style={{ fontSize: fontSize.md, fontWeight: 700, marginBottom: spacing.md, color: colors.textPrimary }}>
                  🚚 حمل‌ونقل فعال
                </div>
                <div style={{ fontSize: 24, fontWeight: 800, color: colors.navy, marginBottom: spacing.sm }}>
                  {inTransitCount}
                </div>
                <div style={{ fontSize: fontSize.xs, color: colors.textSecondary }}>
                  محموله در حال حمل
                </div>
              </div>
            </div>

            {/* جدول درخواست‌های اخیر */}
            <div style={cardStyle}>
              <div style={cardHeaderStyle}>
                <b style={{ fontSize: fontSize.md }}>درخواست‌های اخیر</b>
              </div>

              {allRecent.length === 0 ? (
                <div style={emptyStyle}>هنوز فعالیتی ثبت نشده.</div>
              ) : (
                <div style={{ overflowX: 'auto' }}>
                  <table style={tableStyle}>
                    <thead>
                      <tr style={headerRowStyle}>
                        <th style={thStyle}>نوع</th>
                        <th style={thStyle}>شناسه</th>
                        <th style={thStyle}>توضیحات</th>
                        <th style={thStyle}>وضعیت</th>
                        <th style={thStyle}>تاریخ</th>
                      </tr>
                    </thead>
                    <tbody>
                      {allRecent.map((item) => (
                        <tr key={`${item.type}-${item.id}`} style={rowStyle}>
                          <td style={tdStyle}>
                            <span style={typeTag(item.type)}>{translateType(item.type)}</span>
                          </td>
                          <td style={tdStyle}>
                            <span style={{ fontFamily: 'monospace', fontSize: fontSize.xs }}>
                              {item.id.slice(0, 8)}
                            </span>
                          </td>
                          <td style={tdStyle}>{item.description}</td>
                          <td style={tdStyle}>
                            <span style={statusTag(item.status)}>{translateStatus(item.type, item.status)}</span>
                          </td>
                          <td style={tdStyle}>
                            <span style={{ fontSize: fontSize.xs, color: colors.textMuted }}>
                              {new Date(item.date).toLocaleDateString('fa-IR')}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <PanelFooter />
    </>
  )
}

// ── تابع‌های ترجمه ──────────────────────────────────────────────────────────
function translateType(type: 'order' | 'listing' | 'deal'): string {
  switch (type) {
    case 'order':
      return 'سفارش'
    case 'listing':
      return 'آگهی'
    case 'deal':
      return 'معامله'
  }
}

function translateOrderStatus(status: string): string {
  const map: Record<string, string> = {
    pending: 'در انتظار',
    priced: 'قیمت‌گذاری‌شده',
    awaiting_approval: 'در انتظار تایید مدیر',
    confirmed: 'تایید‌شده',
    completed: 'تکمیل‌شده',
    cancelled: 'لغو شده',
    rejected: 'لغو شده',
  }
  return map[status] ?? status
}

function translateStatus(type: 'order' | 'listing' | 'deal', status: string): string {
  if (type === 'order') return translateOrderStatus(status)

  if (type === 'listing') {
    const map: Record<string, string> = {
      active: 'فعال',
      reserved: 'رزرو',
      needs_reverification: 'نیازمند بررسی',
      completed: 'انجام‌شده',
      cancelled: 'لغو‌شده',
    }
    return map[status] ?? status
  }

  // Deal
  const map: Record<string, string> = {
    draft: 'پیش‌نویس',
    confirmed: 'تایید‌شده',
    seller_fee_paid: 'کارمزد پرداخت‌شده',
    payment_secured: 'پرداخت تامین‌شده',
    loading: 'در حال بارگیری',
    in_transit: 'در حال حمل',
    delivered: 'تحویل‌شده',
    settled: 'تسویه‌شده',
  }
  return map[status] ?? status
}

// ── تگ‌های رنگی ───────────────────────────────────────────────────────────
function typeTag(type: 'order' | 'listing' | 'deal'): React.CSSProperties {
  const kindMap = { order: 'info', listing: 'warning', deal: 'success' } as const
  return badgeStyle(kindMap[type])
}

function statusTag(status: string): React.CSSProperties {
  // رنگ‌بندی بر اساس وضعیت
  let kind: 'success' | 'warning' | 'danger' | 'neutral' = 'neutral'

  if (['confirmed', 'active', 'paid', 'completed', 'settled', 'delivered'].includes(status)) {
    kind = 'success'
  } else if (['in_transit', 'loading', 'priced', 'reserved', 'seller_fee_paid'].includes(status)) {
    kind = 'warning'
  } else if (['cancelled', 'needs_reverification'].includes(status)) {
    kind = 'danger'
  }

  return badgeStyle(kind)
}

// ── استایل‌ها ─────────────────────────────────────────────────────────────
const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: colors.bgPage,
  padding: `${spacing.xxl}px ${spacing.xl}px`,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const cardStyle: React.CSSProperties = {
  ...sharedCardStyle,
  padding: 18,
  marginBottom: 0,
}
const cardHeaderStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: spacing.md,
}
const emptyStyle: React.CSSProperties = { ...emptyStateStyle, padding: '12px 0' }
const tableStyle: React.CSSProperties = { ...sharedTableStyle }
const headerRowStyle: React.CSSProperties = { ...theadRowStyle }
const thStyle: React.CSSProperties = { ...sharedThStyle }
const rowStyle: React.CSSProperties = {
  borderBottom: `1px solid ${colors.borderSubtle}`,
}
const tdStyle: React.CSSProperties = {
  ...sharedTdStyle,
  verticalAlign: 'middle',
  borderBottom: 'none',
}
