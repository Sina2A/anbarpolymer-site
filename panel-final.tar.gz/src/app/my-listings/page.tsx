import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import UserNav from '@/components/UserNav'
import PanelHeader from '@/components/PanelHeader'
import PanelFooter from '@/components/PanelFooter'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { cardStyle as sharedCardStyle, badgeStyle, btnPrimaryStyle } from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

export default async function MyListingsPage() {
  const user = await getCurrentUser()

  // تمام MaterialListing های کاربر
  const myListings = await prisma.materialListing.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    include: {
      grade: true,
    },
  })

  return (
    <>
      <PanelHeader currentUserName={user.companyName} />
      <div style={pageStyle}>
      <div style={{ width: '100%', display: 'flex', gap: 24 }} className="admin-page-wrap">
        <UserNav currentUserName={user.companyName} activeSection="listings" />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12, flexWrap: 'wrap' }}>
            <div>
              <h1 style={{ fontSize: fontSize.xxl, fontWeight: 800, marginBottom: spacing.xs, color: colors.textPrimary }}>شبکه عرضه مواد اولیه من</h1>
              <p style={{ fontSize: fontSize.base, color: colors.textMuted, marginBottom: spacing.xl }}>
                آگهی‌های فروش ثبت‌شده توسط شما
              </p>
            </div>
            <a href="/new-listing" style={ctaBtnStyle}>+ ثبت آگهی عرضه</a>
          </div>

          {myListings.length === 0 ? (
            <div style={emptyCardStyle}>
              <div style={{ fontSize: 40, marginBottom: spacing.md }}>📦</div>
              <div style={{ fontSize: fontSize.lg, fontWeight: 700, color: colors.textPrimary, marginBottom: spacing.sm }}>
                هنوز آگهی فروشی ثبت نکردی
              </div>
              <div style={{ fontSize: fontSize.base, color: colors.textSecondary, marginBottom: spacing.lg }}>
                برای عرضه مواد اولیه خود، آگهی فروش ثبت کن تا خریداران ببینند.
              </div>
              <a href="/new-listing" style={ctaBtnStyle}>ثبت آگهی عرضه</a>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {myListings.map((listing) => (
                <div key={listing.id} style={listingCardStyle}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: spacing.sm }}>
                    <div>
                      <h3 style={{ fontSize: fontSize.lg, fontWeight: 700, margin: 0, marginBottom: spacing.xs }}>
                        {listing.grade.code}
                      </h3>
                      <div style={{ fontSize: fontSize.xs, color: colors.textMuted, fontFamily: 'monospace' }}>
                        #{listing.id.slice(0, 8)}
                      </div>
                    </div>
                    <span style={validityStatusTag(listing.validityStatus)}>
                      {translateValidityStatus(listing.validityStatus)}
                    </span>
                  </div>

                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: spacing.md, marginBottom: spacing.sm }}>
                    <div>
                      <div style={{ fontSize: fontSize.xs, color: colors.textSecondary, marginBottom: 2 }}>مقدار</div>
                      <div style={{ fontSize: fontSize.base, fontWeight: 700 }}>{listing.quantityTon} تن</div>
                    </div>
                    <div>
                      <div style={{ fontSize: fontSize.xs, color: colors.textSecondary, marginBottom: 2 }}>قیمت درخواستی</div>
                      <div style={{ fontSize: fontSize.base, fontWeight: 700, color: colors.orange }}>
                        {listing.askingPriceToman.toLocaleString('fa-IR')} تومان/کیلو
                      </div>
                    </div>
                    <div>
                      <div style={{ fontSize: fontSize.xs, color: colors.textSecondary, marginBottom: 2 }}>محل</div>
                      <div style={{ fontSize: fontSize.base, fontWeight: 600 }}>{listing.city}, {listing.province}</div>
                    </div>
                  </div>

                  <div style={{ display: 'flex', gap: spacing.lg, marginBottom: spacing.sm, fontSize: fontSize.sm, color: colors.neutralText }}>
                    <div>
                      <span style={{ color: colors.textMuted }}>بسته‌بندی:</span> {listing.packagingType} ({listing.packagingQuality})
                    </div>
                    <div>
                      <span style={{ color: colors.textMuted }}>کیفیت مواد:</span> {listing.materialQuality}
                    </div>
                  </div>

                  <div style={{ display: 'flex', gap: spacing.sm, alignItems: 'center', fontSize: fontSize.xs, color: colors.textMuted }}>
                    <span>ثبت‌شده: {new Date(listing.createdAt).toLocaleDateString('fa-IR')}</span>
                    {listing.feeStatus !== 'unpaid' && (
                      <>
                        <span>•</span>
                        <span style={feeStatusTag(listing.feeStatus)}>
                          کارمزد: {translateFeeStatus(listing.feeStatus)}
                        </span>
                      </>
                    )}
                    {listing.feeDeadline && new Date(listing.feeDeadline) > new Date() && (
                      <>
                        <span>•</span>
                        <span style={{ color: colors.dangerText, fontWeight: 700 }}>
                          مهلت: {new Date(listing.feeDeadline).toLocaleDateString('fa-IR')}
                        </span>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
      <PanelFooter />
    </>
  )
}

// ── ترجمه ───────────────────────────────────────────────────────────────
function translateValidityStatus(status: string): string {
  const map: Record<string, string> = {
    active: 'فعال',
    reserved: 'رزرو',
    needs_reverification: 'نیازمند بررسی',
    completed: 'انجام‌شده',
    cancelled: 'لغو‌شده',
  }
  return map[status] ?? status
}

function translateFeeStatus(status: string): string {
  const map: Record<string, string> = {
    unpaid: 'پرداخت نشده',
    pending_review: 'در حال بررسی',
    paid: 'پرداخت‌شده',
  }
  return map[status] ?? status
}

// ── تگ‌های رنگی ───────────────────────────────────────────────────────────
function validityStatusTag(status: string): React.CSSProperties {
  let kind: 'success' | 'warning' | 'danger' | 'info' | 'neutral' = 'neutral'

  if (status === 'active') kind = 'success'
  else if (status === 'reserved') kind = 'warning'
  else if (status === 'needs_reverification') kind = 'danger'
  else if (status === 'completed') kind = 'info'
  else if (status === 'cancelled') kind = 'neutral'

  return badgeStyle(kind)
}

function feeStatusTag(status: string): React.CSSProperties {
  let color: string = colors.textSecondary
  if (status === 'paid') color = colors.successText
  if (status === 'pending_review') color = colors.warningText
  return { color, fontWeight: 700 }
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: colors.bgPage,
  padding: `${spacing.xxl}px ${spacing.xl}px`,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const emptyCardStyle: React.CSSProperties = {
  ...sharedCardStyle,
  padding: 40,
  marginBottom: 0,
  textAlign: 'center',
}
const ctaBtnStyle: React.CSSProperties = {
  ...btnPrimaryStyle,
  display: 'inline-block',
  fontWeight: 700,
  textDecoration: 'none',
  whiteSpace: 'nowrap',
}
const listingCardStyle: React.CSSProperties = {
  ...sharedCardStyle,
  padding: 18,
  marginBottom: 0,
}
