'use client'

import { useEffect, useState } from 'react'
import { logoutAction } from '@/app/logout/actions'
import { colors } from '@/lib/styles/tokens'
import type { CSSProperties } from 'react'

export default function PanelHeader({
  currentUserName,
}: {
  currentUserName: string
}) {
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 900) setMenuOpen(false)
    }
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  return (
    <header style={headerStyle} data-panel-header="true">
      <div style={wrapStyle}>
        <a href="/" style={logoStyle}>
          <span style={logoDotStyle} />
          انبار پلیمر
        </a>

        <div style={actionsStyle}>
          <span style={userNameStyle} className="panel-user-desktop">
            {currentUserName}
          </span>

          <form action={logoutAction} className="panel-logout-desktop">
            <button type="submit" style={logoutBtnStyle}>
              خروج از حساب
            </button>
          </form>

          <button
            onClick={() => setMenuOpen(!menuOpen)}
            style={hamburgerBtnStyle}
            data-panel-hamburger="true"
            aria-label="منو"
          >
            ☰
          </button>
        </div>
      </div>

      {menuOpen && (
        <div style={mobileMenuStyle}>
          <div style={mobileUserStyle}>{currentUserName}</div>
          <form action={logoutAction}>
            <button type="submit" style={mobileLogoutStyle}>
              خروج از حساب
            </button>
          </form>
        </div>
      )}
    </header>
  )
}

// ──────────────────────────────────────────────────────────
// استایل‌ها — الگوی PublicHeader با ساده‌سازی
// ──────────────────────────────────────────────────────────
const headerStyle: CSSProperties = {
  position: 'sticky',
  top: 0,
  zIndex: 50,
  background: colors.navy,
  borderBottom: `1px solid ${colors.navyDark}`,
  boxShadow: '0 2px 10px rgba(30,53,123,0.25)',
}

const wrapStyle: CSSProperties = {
  maxWidth: 1180,
  margin: '0 auto',
  padding: '0 24px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  height: 56,
  gap: 24,
}

const logoStyle: CSSProperties = {
  fontWeight: 800,
  fontSize: 19,
  letterSpacing: '-0.01em',
  display: 'flex',
  alignItems: 'center',
  gap: 8,
  color: '#ffffff',
  fontFamily: 'var(--font-heading)',
  textDecoration: 'none',
}

const logoDotStyle: CSSProperties = {
  width: 8,
  height: 8,
  borderRadius: '50%',
  background: colors.orange,
  boxShadow: '0 0 0 4px rgba(230,87,22,0.28)',
}

const actionsStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 14,
}

const userNameStyle: CSSProperties = {
  color: 'rgba(255,255,255,0.85)',
  fontSize: 13,
  fontWeight: 600,
  fontFamily: 'var(--font-label)',
}

const logoutBtnStyle: CSSProperties = {
  border: '1px solid rgba(255,255,255,0.4)',
  borderRadius: 8,
  padding: '6px 14px',
  fontSize: 12.5,
  color: '#ffffff',
  background: 'transparent',
  cursor: 'pointer',
  fontFamily: 'inherit',
  fontWeight: 600,
}

const hamburgerBtnStyle: CSSProperties = {
  display: 'none',
  background: 'transparent',
  border: '1px solid rgba(255,255,255,0.4)',
  borderRadius: 6,
  color: '#ffffff',
  fontSize: 18,
  padding: '4px 10px',
  cursor: 'pointer',
}

const mobileMenuStyle: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  background: colors.navyDark,
  borderTop: '1px solid rgba(255,255,255,0.15)',
  padding: '12px 24px',
  gap: 8,
}

const mobileUserStyle: CSSProperties = {
  color: 'rgba(255,255,255,0.85)',
  fontSize: 13,
  fontWeight: 700,
  paddingBottom: 8,
  borderBottom: '1px solid rgba(255,255,255,0.15)',
}

const mobileLogoutStyle: CSSProperties = {
  color: '#ff9b9b',
  fontSize: 13,
  fontWeight: 600,
  background: 'transparent',
  border: 'none',
  cursor: 'pointer',
  fontFamily: 'inherit',
  textAlign: 'right' as const,
  padding: '6px 0',
  width: '100%',
}
