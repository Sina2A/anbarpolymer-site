// src/components/VerificationStepper.tsx
//
// نشانگر افقی مراحل (Horizontal Stepper) برای صفحه‌ی احراز هویت.
// سه حالت اصلی: تکمیل‌شده (سبز + ✓)، فعال (سرمه‌ای برجسته)، غیرفعال (خاکستری).
// حالت «در انتظار بررسی» هم به‌صورت کهربایی نمایش داده می‌شه.

import { Fragment } from 'react'
import { colors, fontSize } from '@/lib/styles/tokens'

export type StepState = 'completed' | 'active' | 'pending' | 'locked'

export interface StepperStep {
  label: string
  state: StepState
}

export default function VerificationStepper({ steps }: { steps: StepperStep[] }) {
  return (
    <div style={stepperRowStyle}>
      {steps.map((step, i) => (
        <Fragment key={step.label}>
          {/* خط اتصال بین دایره‌ها */}
          {i > 0 && (
            <div
              style={{
                ...connectorStyle,
                background: steps[i - 1].state === 'completed' ? colors.successText : colors.borderSubtle,
              }}
            />
          )}
          {/* دایره + برچسب */}
          <div style={stepColStyle}>
            <div style={circleStyle(step.state)}>
              {step.state === 'completed' ? '✓' : step.state === 'pending' ? '⏳' : i + 1}
            </div>
            <div style={labelStyle(step.state)}>{step.label}</div>
          </div>
        </Fragment>
      ))}
    </div>
  )
}

// ── استایل‌ها ──

const stepperRowStyle: React.CSSProperties = {
  display: 'flex',
  alignItems: 'flex-start',
  justifyContent: 'center',
}

const stepColStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
}

// خط اتصال — وسط دایره‌ی ۴۰px (40/2 - 1 = 19)
const connectorStyle: React.CSSProperties = {
  flex: 1,
  height: 2,
  borderRadius: 1,
  marginTop: 19,
  minWidth: 28,
}

const circleBase: React.CSSProperties = {
  width: 40,
  height: 40,
  borderRadius: 20,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: fontSize.md,
  fontWeight: 800,
  lineHeight: 1,
}

function circleStyle(state: StepState): React.CSSProperties {
  switch (state) {
    case 'completed':
      return { ...circleBase, background: colors.successText, color: '#fff' }
    case 'active':
      return {
        ...circleBase,
        background: colors.navy,
        color: '#fff',
        boxShadow: '0 0 0 4px rgba(30, 53, 123, 0.14)',
      }
    case 'pending':
      return {
        ...circleBase,
        background: colors.warningBg,
        color: colors.warningText,
        border: `2px solid ${colors.warningText}`,
      }
    case 'locked':
      return {
        ...circleBase,
        background: colors.neutralBg,
        color: colors.textSecondary,
        border: `1px solid ${colors.borderSubtle}`,
      }
  }
}

function labelStyle(state: StepState): React.CSSProperties {
  const base: React.CSSProperties = {
    fontSize: fontSize.sm,
    fontWeight: 700,
    marginTop: 8,
    whiteSpace: 'nowrap',
  }
  switch (state) {
    case 'completed':
      return { ...base, color: colors.successText }
    case 'active':
      return { ...base, color: colors.navy }
    case 'pending':
      return { ...base, color: colors.warningText }
    case 'locked':
      return { ...base, color: colors.textMuted, fontWeight: 500 }
  }
}
