import { colors, spacing, fontSize } from '@/lib/styles/tokens'
import type { CSSProperties } from 'react'

// فوتر ساده‌ی پنل‌ها — نسخه‌ی خلاصه‌شده‌ی فوتر صفحات عمومی (مثل /market).
// فقط کپی‌رایت و چند لینک اصلی؛ ناوبری کامل توی سایدبار پنل هست.
export default function PanelFooter() {
  return (
    <footer style={footerStyle}>
      <div style={footerInner}>
        <span>© {new Date().getFullYear()} انبار پلیمر — تمامی حقوق محفوظ است.</span>
        <span style={footerLinks}>
          <a href="/" style={footerLink}>خانه</a>
          <span style={dot}>•</span>
          <a href="/market" style={footerLink}>بازار</a>
          <span style={dot}>•</span>
          <a href="/support" style={footerLink}>پشتیبانی</a>
        </span>
      </div>
    </footer>
  )
}

const footerStyle: CSSProperties = {
  background: colors.bgCard,
  borderTop: `1px solid ${colors.borderSubtle}`,
  padding: `${spacing.lg}px ${spacing.xl}px`,
  marginTop: 40,
}

const footerInner: CSSProperties = {
  maxWidth: 1100,
  margin: '0 auto',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  gap: spacing.md,
  flexWrap: 'wrap',
  fontSize: fontSize.xs,
  color: colors.textMuted,
}

const footerLinks: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: spacing.sm,
}

const footerLink: CSSProperties = {
  color: colors.neutralText,
  textDecoration: 'none',
  fontWeight: 600,
}

const dot: CSSProperties = {
  color: colors.borderSubtle,
}