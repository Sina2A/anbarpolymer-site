// ==================== ممیزی ساختاری فرم‌ها با Playwright ====================
//
// این اسکریپت مثل کاربر واقعی، توی مرورگر headless لاگین می‌کنه، فرم‌ها رو پر و
// ثبت می‌کنه، و مستقیم با Prisma چک می‌کنه رکورد واقعاً ساخته شده یا نه.
//
// نصب لازم (روی سرور):
//   npm install -D playwright
//   npx playwright install chromium --with-deps
//
// اجرا (با متغیرهای محیطی):
//   AUDIT_USERNAME=testbuyer AUDIT_PASSWORD=test123 node scripts/audit-forms.mjs

import { chromium } from 'playwright'
import { PrismaClient } from '@prisma/client'
import { PrismaPg } from '@prisma/adapter-pg'

const adapter = new PrismaPg({ connectionString: process.env.DATABASE_URL })
const prisma = new PrismaClient({ adapter })
const BASE = 'http://localhost:3000'

/**
 * لاگین با فیلدهای واقعی فرم: identifier (نام کاربری یا شماره) + password
 *
 * نکته‌ی مهم: click() و waitForURL() باید با Promise.all هم‌زمان اجرا بشن،
 * نه یکی بعد از اون یکی — وگرنه یه race condition پیش میاد (click قبل از
 * شروع navigation resolve می‌شه، بعد waitForURL یه وضعیت میانی/ناپایدار رو
 * می‌بینه) که باعث ناپایداری (flaky) توی تشخیص لاگین موفق می‌شه.
 */
async function loginAs(page, username, password) {
  await page.goto(`${BASE}/login`)
  await page.fill('input[name="identifier"]', username)
  await page.fill('input[name="password"]', password)

  await Promise.all([
    page.waitForURL((url) => !url.pathname.includes('/login'), { timeout: 10000 }),
    page.click('button[type="submit"]'),
  ])

  await page.waitForTimeout(500)

  // تشخیص — دقیق ببینیم بلافاصله بعد از لاگین کجا فرود اومدیم
  const landedUrl = page.url()
  const cookies = await page.context().cookies()
  const cookieNames = cookies.map((c) => c.name).join(', ')
  console.log(`   [تشخیص لاگین] فرود روی: ${landedUrl}`)
  console.log(`   [تشخیص لاگین] کوکی‌های موجود: ${cookieNames || '(هیچی)'}`)
}

/**
 * تست یه فرم: شمارش قبل/بعد از Prisma model، برگشت نتیجه
 */
async function testForm({
  browser,
  name,
  path,
  fillFn,
  prismaModel,
  requiresLogin = true,
}) {
  const page = await browser.newPage()

  if (requiresLogin) {
    await loginAs(page, process.env.AUDIT_USERNAME, process.env.AUDIT_PASSWORD)
  }

  const before = await prismaModel.count()
  await page.goto(`${BASE}${path}`)
  // منتظر بمون تا React کامل هیدریت بشه — وگرنه کلیک زودهنگام (سریع‌تر از
  // یه کاربر واقعی) باعث ارسال خام HTML (نه از طریق React) می‌شه، که سرور
  // به‌عنوان Server Action نامعتبر ردش می‌کنه («Server Reference ID» خطا)
  await page.waitForLoadState('networkidle')
  await fillFn(page)
  await page.waitForTimeout(3000) // زمان برای ذخیره و ریدایرکت
  const after = await prismaModel.count()

  // اگه رکورد ساخته نشد، برای تشخیص علت، آدرس فعلی + متن قابل‌مشاهده‌ی صفحه رو ضبط کن
  let diagnostic = null
  if (after <= before) {
    const currentUrl = page.url()
    const bodyText = await page.locator('body').innerText().catch(() => '(خوندن متن صفحه شکست خورد)')
    diagnostic = {
      currentUrl,
      // فقط ۵۰۰ کاراکتر اول، برای اینکه گزارش طولانی نشه
      bodyPreview: bodyText.slice(0, 500),
    }
  }

  await page.close()

  return { name, before, after, pass: after > before, diagnostic }
}

async function fillNewListingForm(page) {
  await page.selectOption('select[name="gradeId"]', { index: 1 })
  await page.fill('input[name="quantityTon"]', '10')
  await page.fill('input[name="province"]', 'تهران')
  await page.fill('input[name="city"]', 'تهران')
  await page.fill('input[name="packagingType"]', 'کیسه ۲۵ کیلویی')
  await page.fill('input[name="packagingQuality"]', 'نو')
  await page.fill('input[name="materialQuality"]', 'virgin')
  await page.fill('input[name="askingPriceToman"]', '95000')
  await page.fill('input[name="weighbridgeNetWeightKg"]', '10000')
  const pngBuffer = Buffer.from(
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=',
    'base64'
  )
  await page.setInputFiles('input[name="weighbridgeTicket"]', {
    name: 'ticket.png',
    mimeType: 'image/png',
    buffer: pngBuffer,
  })
  await page.click('button[type="submit"]')
}

async function main() {
  console.log('=== شروع ممیزی ساختاری فرم‌ها ===\n')

  if (!process.env.AUDIT_USERNAME || !process.env.AUDIT_PASSWORD) {
    console.error('❌ متغیرهای محیطی AUDIT_USERNAME و AUDIT_PASSWORD باید تنظیم بشن.')
    process.exit(1)
  }

  const browser = await chromium.launch({
    executablePath: '/usr/bin/chromium-browser',
    args: ['--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage'],
  })
  const results = []

  // ────────────────────────────────────────────────────────────────────────
  // تست ۱: درخواست خرید (PurchaseRequest)
  // ────────────────────────────────────────────────────────────────────────
  try {
    results.push(
      await testForm({
        browser,
        name: 'purchase-requests',
        path: '/purchase-requests?new=1',
        prismaModel: prisma.purchaseRequest,
        fillFn: async (page) => {
          // انتخاب اولین گرید موجود (option با index=1 چون index=0 پیش‌فرض خالی)
          const options = await page.locator('select[name="gradeId"] option').count()
          if (options < 2) throw new Error('هیچ گریدی برای انتخاب وجود نداره')
          await page.selectOption('select[name="gradeId"]', { index: 1 })

          await page.fill('input[name="quantityTon"]', '25')
          // فیلدهای اختیاری (maxPriceToman, province, description) خالی می‌مونن
          await page.selectOption('select[name="expiresInDays"]', '14')
          await page.click('button[type="submit"]')
        },
      })
    )
  } catch (err) {
    results.push({
      name: 'purchase-requests',
      before: 0,
      after: 0,
      pass: false,
      error: err.message,
    })
  }

  // ────────────────────────────────────────────────────────────────────────
  // تست ۲: تیکت پشتیبانی (SupportTicket)
  // ────────────────────────────────────────────────────────────────────────
  try {
    results.push(
      await testForm({
        browser,
        name: 'support-ticket',
        path: '/support',
        prismaModel: prisma.supportTicket,
        fillFn: async (page) => {
          await page.fill('input[name="subject"]', 'تست ممیزی — تیکت آزمایشی')
          await page.fill(
            'textarea[name="detail"]',
            'این یک پیام آزمایشی برای ممیزی ساختاری سیستم است. رکورد باید در پایگاه داده ساخته بشه.'
          )
          await page.click('button[type="submit"]')
        },
      })
    )
  } catch (err) {
    results.push({
      name: 'support-ticket',
      before: 0,
      after: 0,
      pass: false,
      error: err.message,
    })
  }

  // ────────────────────────────────────────────────────────────────────────
  // تست ۳: تماس با ما (ContactMessage) — بدون نیاز به لاگین
  // ────────────────────────────────────────────────────────────────────────
  try {
    results.push(
      await testForm({
        browser,
        name: 'contact',
        path: '/contact',
        prismaModel: prisma.contactMessage,
        requiresLogin: false, // این فرم عمومیه
        fillFn: async (page) => {
          await page.fill('input[name="name"]', 'ممیزی خودکار')
          await page.fill('input[name="contact"]', 'audit@test.local')
          await page.fill(
            'textarea[name="body"]',
            'پیام آزمایشی برای ممیزی فرم تماس با ما. این رکورد توسط اسکریپت Playwright ساخته شده.'
          )
          await page.click('button[type="submit"]')
        },
      })
    )
  } catch (err) {
    results.push({
      name: 'contact',
      before: 0,
      after: 0,
      pass: false,
      error: err.message,
    })
  }

  // ────────────────────────────────────────────────────────────────────────
  // تست ۴: شبکه عرضه مواد اولیه (MaterialListing) — نیاز به KYC سطح ۲
  // ────────────────────────────────────────────────────────────────────────
  try {
    const listingPage = await browser.newPage()
    await loginAs(listingPage, process.env.AUDIT_USERNAME, process.env.AUDIT_PASSWORD)

    const listingsBefore = await prisma.materialListing.count()
    await listingPage.goto(`${BASE}/new-listing`)

    // چک می‌کنیم آیا به صفحه‌ی احراز هویت ریدایرکت شدیم (یعنی KYC نداره)
    const currentUrl = listingPage.url()
    if (currentUrl.includes('/verification')) {
      results.push({
        name: 'my-listings',
        before: listingsBefore,
        after: listingsBefore,
        pass: null,
        skipped:
          'کاربر تست فاقد KYC سطح ۲ (احراز تولیدکننده) — به /verification ریدایرکت شد',
      })
    } else {
      await listingPage.waitForLoadState('networkidle')
      await fillNewListingForm(listingPage)
      await listingPage.waitForTimeout(3000)
      const listingsAfter = await prisma.materialListing.count()
      let diagnostic = null
      if (listingsAfter <= listingsBefore) {
        const bodyText = await listingPage
          .locator('body')
          .innerText()
          .catch(() => '(خوندن متن صفحه شکست خورد)')
        diagnostic = { currentUrl: listingPage.url(), bodyPreview: bodyText.slice(0, 500) }
      }
      results.push({
        name: 'my-listings',
        before: listingsBefore,
        after: listingsAfter,
        pass: listingsAfter > listingsBefore,
        diagnostic,
      })
    }
    await listingPage.close()
  } catch (err) {
    results.push({
      name: 'my-listings',
      before: 0,
      after: 0,
      pass: false,
      error: err.message,
    })
  }

  // ────────────────────────────────────────────────────────────────────────
  // گزارش نهایی
  // ────────────────────────────────────────────────────────────────────────
  console.log('\n=== نتیجه‌ی ممیزی ساختاری ===')
  console.log(`زمان اجرا: ${new Date().toLocaleString('fa-IR')}`)
  console.log(`پایگاه: ${BASE}\n`)

  for (const r of results) {
    if (r.error) {
      console.log(`❌ ${r.name} — خطا: ${r.error}`)
    } else if (r.skipped) {
      console.log(`⊘  ${r.name} — رد شد: ${r.skipped}`)
    } else {
      const icon = r.pass ? '✅' : '❌'
      console.log(`${icon} ${r.name} — قبل: ${r.before}, بعد: ${r.after}`)
      if (r.diagnostic) {
        console.log(`   آدرس فعلی: ${r.diagnostic.currentUrl}`)
        console.log(`   متن صفحه (۵۰۰ کاراکتر اول):`)
        console.log(`   ${r.diagnostic.bodyPreview.replace(/\n+/g, ' | ')}`)
      }
    }
  }

  const passCount = results.filter((r) => r.pass === true).length
  const failCount = results.filter((r) => r.pass === false).length
  const skipCount = results.filter((r) => r.skipped).length
  const errorCount = results.filter((r) => r.error).length

  console.log(
    `\nخلاصه: ${passCount} موفق، ${failCount + errorCount} ناموفق، ${skipCount} رد شده\n`
  )

  await browser.close()
  await prisma.$disconnect()

  // خروج با کد مناسب برای CI
  if (failCount > 0 || errorCount > 0) process.exit(1)
}

main().catch((err) => {
  console.error('خطای غیرمنتظره:', err)
  process.exit(1)
})
