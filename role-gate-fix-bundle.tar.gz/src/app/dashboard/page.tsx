import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getUserKycLevel } from '@/lib/kyc'
import KycStatusBanner from '@/components/KycStatusBanner'
import UserNav from '@/components/UserNav'

export const dynamic = 'force-dynamic'

export default async function DashboardPage() {
  const user = await getCurrentUser()
  const kycLevel = await getUserKycLevel(user.id)

  // کارت خلاصه سفارش‌ها — تعداد Order با status مختلف
  const orderStats = await prisma.order.groupBy({
    by: ['status'],
    where: { userId: user.id },
    _count: true,
  })
  const orderStatusMap = Object.fromEntries(orderStats.map((s) => [s.status, s._count]))
  const totalOrders = orderStats.reduce((sum, s) => sum + s._count, 0)

  // کارت خلاصه حمل‌ونقل — تعداد Deal با status='in_transit' که کاربر خریدار یا فروشنده‌ست
  const inTransitCount = await prisma.deal.count({
    where: {
      status: 'in_transit',
      OR: [
        { buyerId: user.id },
        { materialListing: { userId: user.id } }, // کاربر فروشنده‌ست
      ],
    },
  })

  // جدول «درخواست‌های اخیر» — ترکیب Order + MaterialListing + Deal
  const recentOrders = await prisma.order.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    take: 5,
    include: { items: { include: { grade: true } } },
  })

  const recentListings = await prisma.materialListing.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    take: 5,
    include: { grade: true },
  })

  const recentDeals = await prisma.deal.findMany({
    where: {
      OR: [
        { buyerId: user.id },
        { materialListing: { userId: user.id } },
      ],
    },
    orderBy: { createdAt: 'desc' },
    take: 5,
    include: { materialListing: { include: { grade: true } } },
  })

  // ترکیب و مرتب‌سازی بر اساس تاریخ
  type RecentItem = {
    id: string
    type: 'order' | 'listing' | 'deal'
    description: string
    status: string
    date: Date
  }

  const allRecent: RecentItem[] = [
    ...recentOrders.map((o) => ({
      id: o.id,
      type: 'order' as const,
      description: `${o.items.length} قلم — ${o.items.map((i) => i.grade.productName).join('، ')}`,
      status: o.status,
      date: o.createdAt,
    })),
    ...recentListings.map((l) => ({
      id: l.id,
      type: 'listing' as const,
      description: `${l.grade.productName} — ${l.quantityTon} تن`,
      status: l.validityStatus,
      date: l.createdAt,
    })),
    ...recentDeals.map((d) => ({
      id: d.id,
      type: 'deal' as const,
      description: `${d.materialListing?.grade.productName ?? 'معامله'} — ${d.quantity}`,
      status: d.status,
      date: d.createdAt,
    })),
  ]
    .sort((a, b) => b.date.getTime() - a.date.getTime())
    .slice(0, 10)

  return (
    <div style={pageStyle}>
      <div style={{ maxWidth: 1100, margin: '0 auto', display: 'flex', gap: 24 }} className="admin-page-wrap">
        <UserNav currentUserName={user.companyName} activeSection="dashboard" />
        <div style={{ flex: 1, minWidth: 0 }}>
          <a href="/market" style={{ fontSize: 12, color: '#1e357b', textDecoration: 'none' }}>← بازگشت به سایت</a>
          <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4, marginTop: 8 }}>پیشخوان</h1>
          <p style={{ fontSize: 13, color: '#9199a3', marginBottom: 20 }}>
            خلاصه‌ی وضعیت خرید و فروش شما در انبار پلیمر
          </p>

          <KycStatusBanner level={kycLevel} />

          {/* دو کارت خلاصه — در یک ردیف */}
          <div style={{ display: 'flex', gap: 14, marginBottom: 14, flexWrap: 'wrap' }}>
            {/* کارت خلاصه سفارش‌ها */}
            <div style={{ ...cardStyle, flex: '1 1 300px' }}>
              <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 12, color: '#1a1a2e' }}>
                📦 سفارش‌ها
              </div>
              <div style={{ fontSize: 24, fontWeight: 800, color: '#e65716', marginBottom: 8 }}>
                {totalOrders}
              </div>
              <div style={{ fontSize: 11, color: '#6b7280', display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {Object.entries(orderStatusMap).map(([status, count]) => (
                  <span key={status} style={{ background: '#f1efe8', padding: '2px 8px', borderRadius: 6 }}>
                    {translateOrderStatus(status)}: {count}
                  </span>
                ))}
              </div>
            </div>

            {/* کارت خلاصه حمل‌ونقل */}
            <div style={{ ...cardStyle, flex: '1 1 300px' }}>
              <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 12, color: '#1a1a2e' }}>
                🚚 حمل‌ونقل فعال
              </div>
              <div style={{ fontSize: 24, fontWeight: 800, color: '#0ea5e9', marginBottom: 8 }}>
                {inTransitCount}
              </div>
              <div style={{ fontSize: 11, color: '#6b7280' }}>
                محموله در حال حمل
              </div>
            </div>
          </div>

          {/* جدول درخواست‌های اخیر */}
          <div style={cardStyle}>
            <div style={cardHeaderStyle}>
              <b style={{ fontSize: 14 }}>درخواست‌های اخیر</b>
            </div>

            {allRecent.length === 0 ? (
              <div style={emptyStyle}>هنوز فعالیتی ثبت نشده.</div>
            ) : (
              <div style={{ overflowX: 'auto' }}>
                <table style={tableStyle}>
                  <thead>
                    <tr style={headerRowStyle}>
                      <th style={thStyle}>نوع</th>
                      <th style={thStyle}>شناسه</th>
                      <th style={thStyle}>توضیحات</th>
                      <th style={thStyle}>وضعیت</th>
                      <th style={thStyle}>تاریخ</th>
                    </tr>
                  </thead>
                  <tbody>
                    {allRecent.map((item) => (
                      <tr key={`${item.type}-${item.id}`} style={rowStyle}>
                        <td style={tdStyle}>
                          <span style={typeTag(item.type)}>{translateType(item.type)}</span>
                        </td>
                        <td style={tdStyle}>
                          <span style={{ fontFamily: 'monospace', fontSize: 11 }}>
                            {item.id.slice(0, 8)}
                          </span>
                        </td>
                        <td style={tdStyle}>{item.description}</td>
                        <td style={tdStyle}>
                          <span style={statusTag(item.status)}>{translateStatus(item.type, item.status)}</span>
                        </td>
                        <td style={tdStyle}>
                          <span style={{ fontSize: 11, color: '#9199a3' }}>
                            {new Date(item.date).toLocaleDateString('fa-IR')}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

// ── تابع‌های ترجمه ──────────────────────────────────────────────────────────
function translateType(type: 'order' | 'listing' | 'deal'): string {
  switch (type) {
    case 'order':
      return 'سفارش'
    case 'listing':
      return 'آگهی'
    case 'deal':
      return 'معامله'
  }
}

function translateOrderStatus(status: string): string {
  const map: Record<string, string> = {
    pending: 'در انتظار',
    priced: 'قیمت‌گذاری‌شده',
    confirmed: 'تایید‌شده',
    completed: 'تکمیل‌شده',
    cancelled: 'لغو‌شده',
  }
  return map[status] ?? status
}

function translateStatus(type: 'order' | 'listing' | 'deal', status: string): string {
  if (type === 'order') return translateOrderStatus(status)

  if (type === 'listing') {
    const map: Record<string, string> = {
      active: 'فعال',
      reserved: 'رزرو',
      needs_reverification: 'نیازمند بررسی',
      completed: 'انجام‌شده',
      cancelled: 'لغو‌شده',
    }
    return map[status] ?? status
  }

  // Deal
  const map: Record<string, string> = {
    draft: 'پیش‌نویس',
    confirmed: 'تایید‌شده',
    seller_fee_paid: 'کارمزد پرداخت‌شده',
    payment_secured: 'پرداخت تامین‌شده',
    loading: 'در حال بارگیری',
    in_transit: 'در حال حمل',
    delivered: 'تحویل‌شده',
    settled: 'تسویه‌شده',
  }
  return map[status] ?? status
}

// ── تگ‌های رنگی ───────────────────────────────────────────────────────────
function typeTag(type: 'order' | 'listing' | 'deal'): React.CSSProperties {
  const colors = {
    order: { bg: '#eef4fd', color: '#1e357b' },
    listing: { bg: '#fef3c7', color: '#92400e' },
    deal: { bg: '#d1fae5', color: '#065f46' },
  }
  const c = colors[type]
  return {
    fontSize: 10,
    fontWeight: 700,
    background: c.bg,
    color: c.color,
    borderRadius: 6,
    padding: '3px 8px',
    display: 'inline-block',
  }
}

function statusTag(status: string): React.CSSProperties {
  // رنگ‌بندی بر اساس وضعیت
  let bg = '#f1efe8'
  let color = '#4f5560'

  if (['confirmed', 'active', 'paid', 'completed', 'settled', 'delivered'].includes(status)) {
    bg = '#d1fae5'
    color = '#065f46'
  } else if (['in_transit', 'loading', 'priced', 'reserved', 'seller_fee_paid'].includes(status)) {
    bg = '#fef3c7'
    color = '#92400e'
  } else if (['cancelled', 'needs_reverification'].includes(status)) {
    bg = '#fee2e2'
    color = '#991b1b'
  }

  return {
    fontSize: 10,
    fontWeight: 700,
    background: bg,
    color: color,
    borderRadius: 6,
    padding: '3px 8px',
    display: 'inline-block',
  }
}

// ── استایل‌ها ─────────────────────────────────────────────────────────────
const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: '#faf8f4',
  padding: '32px 20px',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const cardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 18,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const cardHeaderStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: 12,
}
const emptyStyle: React.CSSProperties = { fontSize: 12.5, color: '#9199a3', padding: '12px 0' }
const tableStyle: React.CSSProperties = {
  width: '100%',
  borderCollapse: 'collapse',
  fontSize: 12.5,
}
const headerRowStyle: React.CSSProperties = {
  background: '#faf8f4',
  borderBottom: '2px solid #e8e4db',
}
const thStyle: React.CSSProperties = {
  padding: '10px 12px',
  textAlign: 'right',
  fontWeight: 700,
  fontSize: 12,
  color: '#4f5560',
}
const rowStyle: React.CSSProperties = {
  borderBottom: '1px solid #f1efe8',
}
const tdStyle: React.CSSProperties = {
  padding: '12px',
  verticalAlign: 'middle',
}
