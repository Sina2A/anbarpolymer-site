import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { enforceDealDeadlines } from '@/lib/dealDeadlines'
import { SEVERE_DISCREPANCY_ITEMS, MINOR_DISCREPANCY_ITEMS } from '@/lib/disputes'
import { submitDiscrepancy } from './actions'

export const dynamic = 'force-dynamic'

export default async function DealConfirmPage({ params }: { params: Promise<{ dealId: string }> }) {
  const { dealId } = await params
  const user = await getCurrentUser()

  // اگه مهلتی (این معامله یا هر معامله‌ی دیگه‌ای) گذشته باشه، همینجا خودکار
  // به‌روزرسانی می‌شه — قبل از رندر بقیه‌ی صفحه، تا وضعیت همیشه تازه باشه.
  await enforceDealDeadlines()

  const deal = await prisma.deal.findUnique({
    where: { id: dealId },
    include: { confirmations: { orderBy: { confirmedAt: 'asc' } } },
  })

  if (!deal || deal.buyerId !== user.id) {
    return <div style={pageStyle}>این معامله پیدا نشد یا مال شما نیست.</div>
  }

  const buyerConfirmRecord = deal.confirmations.find((c) => c.type === 'buyer_confirm')
  const unloadingDone = deal.confirmations.some((c) => c.type === 'unloading')

  if (!unloadingDone) {
    if (deal.driverSilenceFlaggedAt) {
      return (
        <div style={pageStyle}>
          <div style={cardStyle}>
            <h1 style={{ fontSize: 17, fontWeight: 800, marginBottom: 8, color: '#9b1c1c' }}>منتظر تایید کارشناس از صحت بار</h1>
            <p style={{ fontSize: 13, color: '#4f5560', lineHeight: 1.9 }}>
              از لحظه‌ی بارگیری این محموله مدتی گذشته بدون این‌که رویداد جدیدی ثبت بشه. این لزوماً به‌معنی مشکل نیست
              (ممکنه توقف کوتاه یا تاخیر عادی باشه)، ولی برای اطمینان، کارشناس ما در حال بررسیه. به‌محض تایید یا مشخص‌شدن
              وضعیت، همینجا به‌روزرسانی می‌شه.
            </p>
          </div>
        </div>
      )
    }
    return (
      <div style={pageStyle}>
        <div style={cardStyle}>
          <h1 style={{ fontSize: 17, fontWeight: 800 }}>هنوز تخلیه ثبت نشده</h1>
          <p style={{ fontSize: 13, color: '#6f7680' }}>وقتی راننده تخلیه رو ثبت کنه، بار به‌صورت پیش‌فرض تحویل‌شده در نظر گرفته می‌شه و اینجا فقط می‌تونی در صورت وجود مشکل، مغایرت ثبت کنی.</p>
        </div>
      </div>
    )
  }

  if (buyerConfirmRecord) {
    return <AlreadyReportedView record={buyerConfirmRecord} />
  }

  return (
    <div style={pageStyle}>
      <div style={cardStyle}>
        <h1 style={{ fontSize: 18, fontWeight: 800, marginBottom: 6 }}>وضعیت تحویل بار</h1>
        <p style={{ fontSize: 13, color: '#6f7680', marginBottom: 14 }}>معامله #{deal.id.slice(0, 8)} — مقدار {deal.quantity}</p>

        <div style={{ background: '#eaf3de', color: '#27500a', borderRadius: 8, padding: '10px 14px', fontSize: 12.5, fontWeight: 600, marginBottom: 14, lineHeight: 1.9 }}>
          ✓ بار طبق سیستم تحویل‌شده و بدون مغایرت در نظر گرفته می‌شه. نیازی به تایید فعال نیست — فقط اگه واقعاً مشکلی توی بار دیدی، پایین همین صفحه گزارش کن.
        </div>

        <DiscrepancyDeadlineBanner deadline={deal.discrepancyReportDeadline} />

        <details style={{ marginTop: 18 }}>
          <summary style={{ cursor: 'pointer', fontSize: 13.5, fontWeight: 700, color: '#9b1c1c' }}>⚠ گزارش مغایرت در بار</summary>

          <form action={submitDiscrepancy} style={{ display: 'flex', flexDirection: 'column', gap: 14, marginTop: 14 }}>
            <input type="hidden" name="dealId" value={deal.id} />

            <div>
              <div style={{ fontSize: 12.5, fontWeight: 700, color: '#791f1f', marginBottom: 8 }}>موارد حساس — معامله متوقف و بررسی می‌شه</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {SEVERE_DISCREPANCY_ITEMS.map((item) => (
                  <label key={item} style={severeOptionStyle}>
                    <input type="checkbox" name="items" value={item} />
                    <span>{item}</span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <div style={{ fontSize: 12.5, fontWeight: 700, color: '#633806', marginBottom: 8 }}>موارد جزئی — فقط برای سابقه ثبت می‌شه</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {MINOR_DISCREPANCY_ITEMS.map((item) => (
                  <label key={item} style={minorOptionStyle}>
                    <input type="checkbox" name="items" value={item} />
                    <span>{item}</span>
                  </label>
                ))}
              </div>
            </div>

            <textarea name="note" placeholder="توضیح بیشتر (اختیاری)" rows={3} style={textareaStyle} />

            <button type="submit" style={submitBtnStyle}>ثبت گزارش مغایرت</button>
          </form>
        </details>
      </div>
    </div>
  )
}

function AlreadyReportedView({ record }: { record: { finalVerdict: string | null; discrepancyItemsJson: string | null } }) {
  const isAuto = record.finalVerdict === 'auto_no_discrepancy'
  const isSevere = record.finalVerdict === 'discrepancy_severe'
  const items: string[] = record.discrepancyItemsJson ? JSON.parse(record.discrepancyItemsJson) : []

  return (
    <div style={pageStyle}>
      <div style={cardStyle}>
        {isAuto && (
          <>
            <h1 style={{ fontSize: 17, fontWeight: 800, marginBottom: 8 }}>بار بدون مغایرت تایید شده</h1>
            <p style={{ fontSize: 13, color: '#4f5560', lineHeight: 1.9 }}>
              چون ظرف مهلت مقرر گزارشی ثبت نشد، بار طبق سیستم بدون مغایرت در نظر گرفته شد و در روند عادی واریز قرار گرفت.
            </p>
          </>
        )}
        {isSevere && (
          <>
            <h1 style={{ fontSize: 17, fontWeight: 800, marginBottom: 8, color: '#9b1c1c' }}>گزارش مغایرت حساس ثبت شد</h1>
            <p style={{ fontSize: 13, color: '#4f5560', lineHeight: 1.9, marginBottom: 10 }}>
              واریز وجه متوقف شد و این معامله برای رسیدگی به کارشناسان ارجاع داده شد. به‌زودی با شما تماس گرفته می‌شه.
            </p>
            <ul style={{ fontSize: 12.5, color: '#791f1f', paddingRight: 18 }}>
              {items.map((i) => <li key={i}>{i}</li>)}
            </ul>
          </>
        )}
        {!isAuto && !isSevere && (
          <>
            <h1 style={{ fontSize: 17, fontWeight: 800, marginBottom: 8 }}>گزارش مغایرت جزئی ثبت شد</h1>
            <p style={{ fontSize: 13, color: '#4f5560', lineHeight: 1.9 }}>این موارد برای سابقه ثبت شدن و روند واریز وجه ادامه پیدا می‌کنه.</p>
          </>
        )}
      </div>
    </div>
  )
}

/** بنر پلکانی برای مهلت ۴ساعته‌ی گزارش مغایرت. */
function DiscrepancyDeadlineBanner({ deadline }: { deadline: Date | null }) {
  if (!deadline) return null

  const msRemaining = new Date(deadline).getTime() - Date.now()
  const hoursRemaining = msRemaining / (60 * 60 * 1000)
  const deadlineLabel = new Date(deadline).toLocaleString('fa-IR')

  let style: React.CSSProperties = { background: '#eef4fd', color: '#1e357b' }
  let icon = 'ℹ️'
  if (hoursRemaining <= 1) {
    style = { background: '#fde8e8', color: '#9b1c1c' }
    icon = '🔴'
  } else if (hoursRemaining <= 2) {
    style = { background: '#fef3c7', color: '#92400e' }
    icon = '⏱'
  }

  return (
    <div style={{ ...style, borderRadius: 8, padding: '10px 14px', fontSize: 12.5, fontWeight: 600, lineHeight: 1.9 }}>
      {icon} تا <b>{deadlineLabel}</b> (ساعت کاری) فرصت داری مغایرت رو گزارش کنی. بعد از این مهلت، گزارش مغایرت دیگه از این صفحه ممکن نیست.
    </div>
  )
}

const pageStyle: React.CSSProperties = { minHeight: '100vh', background: '#faf8f4', padding: '32px 20px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl' }
const cardStyle: React.CSSProperties = { maxWidth: 480, margin: '0 auto', background: '#fff', border: '1px solid #d8dde3', borderRadius: 14, padding: '24px 20px' }
const severeOptionStyle: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 10, fontSize: 13, padding: '10px 14px', border: '1px solid #f0997b', background: '#faece7', borderRadius: 9, cursor: 'pointer' }
const minorOptionStyle: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 10, fontSize: 13, padding: '10px 14px', border: '1px solid #eceff3', borderRadius: 9, cursor: 'pointer' }
const textareaStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 9, padding: '10px 12px', fontSize: 13, fontFamily: 'inherit', resize: 'vertical' }
const submitBtnStyle: React.CSSProperties = { background: '#9b1c1c', color: '#fff', border: 'none', borderRadius: 9, padding: '13px 0', fontSize: 14.5, fontWeight: 800, cursor: 'pointer' }
