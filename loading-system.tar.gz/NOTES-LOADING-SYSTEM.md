# NOTES-LOADING-SYSTEM.md

## خلاصه‌ی سیستم لودینگ جامع

این سیستم دو مکانیزم لودینگ را پوشش می‌دهد:

### بخش A: Skeleton UI (لودینگ جابه‌جایی صفحه)

**هدف**: نمایش طرح‌واره‌ی خاکستری (Skeleton) به‌جای صفحه خالی موقع لود Server Component.

**پیاده‌سازی**:
- از قابلیت داخلی Next.js (`loading.tsx` در هر مسیر) استفاده شد
- 8 فایل `loading.tsx` ایجاد شد:
  - `/dashboard/loading.tsx` — گرید دوستونی (6 کارت + 3 کارت) + 3 ستون پایین
  - `/my-orders/loading.tsx` — جدول 5×5
  - `/my-listings/loading.tsx` — جدول 5×5
  - `/my-deals/loading.tsx` — جدول 5×5
  - `/verification/loading.tsx` — Stepper افقی + کارت فرم
  - `/market/loading.tsx` — فیلترها + گرید 6 کارتی
  - `/grades/loading.tsx` — گرید 12 کارتی
  - `/grades/[code]/loading.tsx` — عنوان + مشخصات + نمودار

**کامپوننت‌های پایه**:
- `SkeletonLine.tsx` — خط shimmer با عرض/ارتفاع قابل تنظیم
- `SkeletonCard.tsx` — کارت با چند خط shimmer (عرض‌های 100%, 80%, 60%)
- `SkeletonTable.tsx` — جدول با thead ثابت + tbody قابل تنظیم

**طراحی**:
- به‌جای بازسازی کامل `PanelHeader`/`UserNav` به‌شکل Skeleton، فقط یک `<div>` ساده با رنگ و ارتفاع مشابه (72px) استفاده شد
- انیمیشن shimmer با CSS خالص (`@keyframes shimmer` در `globals.css`)
- رنگ‌ها: gradient از `#e3e8ee` به `#f0f2f5`

**مزایا**:
- منطبق با چیدمان واقعی صفحه → پیش‌بینی‌پذیر
- حس سرعت بیشتر نسبت به اسپینر
- بدون کتابخونه‌ی خارجی

---

### بخش B: Overlay Loading (لودینگ عملیات داخل صفحه)

**هدف**: نمایش overlay برندشده برای عملیات Server Action (ثبت سفارش، پرداخت، آپلود فایل).

**پیاده‌سازی**:

#### 1. Context سراسری (`LoadingContext.tsx`)
```tsx
- State: showOverlay (boolean)
- Ref: timerRef (NodeJS.Timeout | null) — مدیریت تایمر با useRef
- Ref: loadingCountRef (number) — reference counter برای عملیات هم‌زمان
- Methods: showLoading(), hideLoading()
- useEffect cleanup: clearTimeout(timerRef.current)
```

**الگوریتم Reference Counter**:
```
showLoading():
  loadingCountRef.current += 1
  if (count === 1) → setTimeout 300ms

hideLoading():
  loadingCountRef.current -= 1
  if (count === 0) → clearTimeout + setShowOverlay(false)
```

**مثال سناریو**:
- عملیات A شروع → counter: 0→1 → تایمر شروع
- عملیات B شروع (قبل از 300ms) → counter: 1→2 → تایمر ادامه
- عملیات A تمام → counter: 2→1 → overlay باقی می‌مونه
- عملیات B تمام → counter: 1→0 → overlay بسته می‌شه

#### 2. LoadingOverlay (`LoadingOverlay.tsx`)
```tsx
- Overlay: rgba(255, 255, 255, 0.85) + backdrop-filter: blur(8px)
- دایره‌ی نارنجی: colors.orange با boxShadow
- انیمیشن pulse: scale(1 → 1.15 → 1) در 1.2 ثانیه
- متن: "در حال پردازش..." با colors.navy
```

#### 3. معماری Client/Server
```tsx
src/app/layout.tsx (Server Component — دست‌نخورده):
  return (
    <html>
      <body>
        <ClientProviders>{children}</ClientProviders>
      </body>
    </html>
  )

src/app/ClientProviders.tsx ('use client'):
  return <LoadingProvider>{children}</LoadingProvider>
```

**چرا این معماری؟**
- `layout.tsx` ریشه Server Component باقی می‌مونه
- فقط `ClientProviders.tsx` client-side هست
- جلوگیری از تبدیل کل ساختار به 'use client'

#### 4. استفاده در فرم‌ها
```tsx
'use client'
import { useLoading } from '@/contexts/LoadingContext'

const { showLoading, hideLoading } = useLoading()

async function handleSubmit(formData: FormData) {
  showLoading()
  try {
    await submitAction(formData)
  } finally {
    hideLoading() // حتماً در finally
  }
}
```

**ویژگی‌های کلیدی**:
- **تاخیر 300ms**: overlay فقط برای عملیات >300ms نشون داده می‌شه (جلوگیری از flicker)
- **Reference Counter**: مدیریت درست عملیات هم‌زمان (نه boolean ساده)
- **useRef + cleanup**: جلوگیری از memory leak موقع unmount
- **Blur ملایم**: حفظ context پس‌زمینه (حیاتی برای B2B)

---

## فایل‌های ایجاد‌شده / ویرایش‌شده

### فایل‌های جدید (16):
```
src/components/SkeletonLine.tsx
src/components/SkeletonCard.tsx
src/components/SkeletonTable.tsx
src/components/LoadingOverlay.tsx
src/contexts/LoadingContext.tsx
src/app/ClientProviders.tsx
src/app/dashboard/loading.tsx
src/app/my-orders/loading.tsx
src/app/my-listings/loading.tsx
src/app/my-deals/loading.tsx
src/app/verification/loading.tsx
src/app/market/loading.tsx
src/app/grades/loading.tsx
src/app/grades/[code]/loading.tsx
```

### فایل‌های ویرایش‌شده (2):
```
src/app/layout.tsx — اضافه کردن ClientProviders wrapper
src/app/globals.css — اضافه کردن @keyframes shimmer + pulse
```

---

## نکات پیاده‌سازی

### ✅ الزامات رعایت‌شده:

1. **Timer با useRef**: `timerRef` با `clearTimeout` واقعی در `hideLoading()` و `useEffect cleanup`
2. **Reference Counter**: `loadingCountRef` به‌جای boolean ساده — فقط وقتی counter=0 overlay بسته می‌شه
3. **useEffect cleanup**: تایمر موقع unmount پاک می‌شه
4. **div ساده جایگزین هدر**: به‌جای بازسازی کامل PanelHeader/UserNav، فقط یک div با `background: colors.navy, height: 72`
5. **پلن تایید‌شده**: همه‌ی 5 الزام اصلاح‌شده در پیاده‌سازی رعایت شد

### انیمیشن‌ها:
- **Shimmer**: gradient جابه‌جا می‌شه (200% background-size) در 1.5 ثانیه
- **Pulse**: دایره‌ی نارنجی scale می‌شه در 1.2 ثانیه
- هر دو با CSS خالص — بدون کتابخونه

### رنگ‌بندی:
- **Skeleton**: `#e3e8ee` → `#f0f2f5` (خاکستری روشن)
- **Overlay**: دایره نارنجی (`#e65716`) + متن navy (`#1e357b`)

---

## تست‌های پیشنهادی

### Skeleton:
1. ناوبری `/dashboard` → `/market` → Skeleton market نشون داده بشه
2. Refresh صفحه → Skeleton ظاهر بشه تا Server Component لود بشه
3. عرض‌های مختلف → Skeleton responsive باشه

### Overlay:
1. عملیات سریع (<300ms) → overlay نشون داده نشه
2. عملیات آهسته (>300ms) → overlay + دایره pulse
3. دو عملیات هم‌زمان → counter: 0→1→2→1→0، overlay فقط یک‌بار
4. عملیات با خطا → finally cleanup
5. Unmount کامپوننت موقع لودینگ → timer پاک بشه (no memory leak)

---

## استفاده

### برای Skeleton:
هیچ کاری لازم نیست — Next.js خودکار `loading.tsx` رو نشون می‌ده موقع لود صفحه.

### برای Overlay:
```tsx
'use client'
import { useLoading } from '@/contexts/LoadingContext'

export default function MyForm() {
  const { showLoading, hideLoading } = useLoading()

  async function handleAction(formData: FormData) {
    showLoading()
    try {
      await myServerAction(formData)
      // موفقیت
    } catch (error) {
      // خطا
    } finally {
      hideLoading() // حتماً در finally
    }
  }

  return <form action={handleAction}>...</form>
}
```

---

## خلاصه تصمیمات معماری

| جنبه | راه‌حل |
|---|---|
| **Skeleton** | `loading.tsx` با div ساده جایگزین هدر |
| **Overlay** | Context + Hook + تاخیر 300ms با `useRef` |
| **Timer** | `useRef` + `clearTimeout` واقعی + `useEffect cleanup` |
| **عملیات هم‌زمان** | Reference counter (نه boolean) |
| **هدر Skeleton** | div ساده 72px بدون نمونه‌سازی کامپوننت واقعی |
| **انیمیشن** | دایره‌ی نارنجی pulse + shimmer gradient |
| **Server Component** | `ClientProviders.tsx` جدا — `layout.tsx` Server |
| **CSS** | خالص (`globals.css`) — بدون کتابخونه |

---

**تاریخ**: 2026-09-10  
**وضعیت**: کامل — آماده‌ی استفاده
