// src/contexts/LoadingContext.tsx
//
// Context سراسری برای مدیریت overlay لودینگ با reference counter

'use client'

import { createContext, useContext, useState, useRef, useEffect, type ReactNode } from 'react'
import LoadingOverlay from '@/components/LoadingOverlay'

type LoadingContextType = {
  showLoading: () => void
  hideLoading: () => void
}

const LoadingContext = createContext<LoadingContextType | null>(null)

export function LoadingProvider({ children }: { children: ReactNode }) {
  const [showOverlay, setShowOverlay] = useState(false)
  const timerRef = useRef<NodeJS.Timeout | null>(null)
  const loadingCountRef = useRef(0)

  const showLoading = () => {
    loadingCountRef.current += 1

    // فقط اگه اولین درخواست بود (0→1) تایمر جدید بساز
    if (loadingCountRef.current === 1) {
      timerRef.current = setTimeout(() => {
        setShowOverlay(true)
      }, 300)
    }
  }

  const hideLoading = () => {
    loadingCountRef.current = Math.max(0, loadingCountRef.current - 1)

    // فقط وقتی همه‌ی درخواست‌ها تموم شدن (counter=0) overlay رو ببند
    if (loadingCountRef.current === 0) {
      if (timerRef.current) {
        clearTimeout(timerRef.current)
        timerRef.current = null
      }
      setShowOverlay(false)
    }
  }

  // cleanup موقع unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current)
      }
    }
  }, [])

  return (
    <LoadingContext.Provider value={{ showLoading, hideLoading }}>
      {children}
      {showOverlay && <LoadingOverlay />}
    </LoadingContext.Provider>
  )
}

export function useLoading() {
  const context = useContext(LoadingContext)
  if (!context) {
    throw new Error('useLoading must be used within LoadingProvider')
  }
  return context
}
