// src/app/my-deals/loading.tsx
//
// Skeleton برای صفحه معامله‌های من

import SkeletonTable from '@/components/SkeletonTable'
import { colors, spacing } from '@/lib/styles/tokens'
import type { CSSProperties } from 'react'

export default function MyDealsLoading() {
  const headerPlaceholderStyle: CSSProperties = {
    background: colors.navy,
    height: 72,
    width: '100%',
  }

  const pageStyle: CSSProperties = {
    minHeight: '100vh',
    background: colors.bgPage,
    padding: `${spacing.xxl}px ${spacing.xl}px`,
    fontFamily: "'Vazirmatn', Tahoma, sans-serif",
    direction: 'rtl',
  }

  const pageWrapStyle: CSSProperties = {
    width: '100%',
    display: 'flex',
    gap: spacing.xl,
  }

  const navPlaceholderStyle: CSSProperties = {
    width: 200,
    background: colors.bgCard,
    borderRadius: 12,
    height: 'fit-content',
    minHeight: 300,
  }

  const containerStyle: CSSProperties = {
    flex: 1,
    minWidth: 0,
  }

  return (
    <>
      <div style={headerPlaceholderStyle} />
      <div style={pageStyle}>
        <div style={pageWrapStyle}>
          <div style={navPlaceholderStyle} />
          <div style={containerStyle}>
            <SkeletonTable rows={5} columns={5} />
          </div>
        </div>
      </div>
    </>
  )
}
