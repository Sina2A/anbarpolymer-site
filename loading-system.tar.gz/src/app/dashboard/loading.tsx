// src/app/dashboard/loading.tsx
//
// Skeleton برای صفحه داشبورد

import SkeletonCard from '@/components/SkeletonCard'
import { colors, spacing } from '@/lib/styles/tokens'
import type { CSSProperties } from 'react'

export default function DashboardLoading() {
  const headerPlaceholderStyle: CSSProperties = {
    background: colors.navy,
    height: 72,
    width: '100%',
  }

  const pageStyle: CSSProperties = {
    minHeight: '100vh',
    background: colors.bgPage,
    padding: `${spacing.xxl}px ${spacing.xl}px`,
    fontFamily: "'Vazirmatn', Tahoma, sans-serif",
    direction: 'rtl',
  }

  const pageWrapStyle: CSSProperties = {
    width: '100%',
    display: 'flex',
    gap: spacing.xl,
  }

  const navPlaceholderStyle: CSSProperties = {
    width: 200,
    background: colors.bgCard,
    borderRadius: 12,
    height: 'fit-content',
    minHeight: 300,
  }

  const containerStyle: CSSProperties = {
    flex: 1,
    minWidth: 0,
  }

  const topGridStyle: CSSProperties = {
    display: 'grid',
    gridTemplateColumns: '2fr 1fr',
    gap: 16,
    marginBottom: 20,
  }

  const quickActionsGridStyle: CSSProperties = {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))',
    gap: 12,
  }

  const statsColStyle: CSSProperties = {
    display: 'flex',
    flexDirection: 'column',
    gap: 10,
  }

  const recentGridStyle: CSSProperties = {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
    gap: 14,
  }

  return (
    <>
      <div style={headerPlaceholderStyle} />
      <div style={pageStyle}>
        <div style={pageWrapStyle}>
          <div style={navPlaceholderStyle} />
          <div style={containerStyle}>
            <div style={topGridStyle}>
              <div style={quickActionsGridStyle}>
                {Array.from({ length: 6 }).map((_, i) => (
                  <SkeletonCard key={i} height={100} lines={2} />
                ))}
              </div>
              <div style={statsColStyle}>
                {Array.from({ length: 3 }).map((_, i) => (
                  <SkeletonCard key={i} height={80} lines={2} />
                ))}
              </div>
            </div>
            <div style={recentGridStyle}>
              {Array.from({ length: 3 }).map((_, i) => (
                <SkeletonCard key={i} height={200} lines={5} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
