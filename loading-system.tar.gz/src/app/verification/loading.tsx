// src/app/verification/loading.tsx
//
// Skeleton برای صفحه احراز هویت

import SkeletonCard from '@/components/SkeletonCard'
import SkeletonLine from '@/components/SkeletonLine'
import { colors, spacing } from '@/lib/styles/tokens'
import type { CSSProperties } from 'react'

export default function VerificationLoading() {
  const headerPlaceholderStyle: CSSProperties = {
    background: colors.navy,
    height: 72,
    width: '100%',
  }

  const pageStyle: CSSProperties = {
    minHeight: '100vh',
    background: colors.bgPage,
    padding: `${spacing.xxl}px ${spacing.xl}px`,
    fontFamily: "'Vazirmatn', Tahoma, sans-serif",
    direction: 'rtl',
  }

  const pageWrapStyle: CSSProperties = {
    width: '100%',
    display: 'flex',
    gap: spacing.xl,
  }

  const navPlaceholderStyle: CSSProperties = {
    width: 200,
    background: colors.bgCard,
    borderRadius: 12,
    height: 'fit-content',
    minHeight: 300,
  }

  const containerStyle: CSSProperties = {
    flex: 1,
    minWidth: 0,
  }

  const stepperStyle: CSSProperties = {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 40,
    marginBottom: spacing.xl,
    padding: `${spacing.lg}px 0`,
  }

  return (
    <>
      <div style={headerPlaceholderStyle} />
      <div style={pageStyle}>
        <div style={pageWrapStyle}>
          <div style={navPlaceholderStyle} />
          <div style={containerStyle}>
            {/* Stepper افقی */}
            <div style={stepperStyle}>
              <SkeletonLine width={80} height={20} />
              <SkeletonLine width={120} height={4} />
              <SkeletonLine width={80} height={20} />
              <SkeletonLine width={120} height={4} />
              <SkeletonLine width={80} height={20} />
            </div>
            {/* کارت فرم */}
            <SkeletonCard height={400} lines={8} />
          </div>
        </div>
      </div>
    </>
  )
}
