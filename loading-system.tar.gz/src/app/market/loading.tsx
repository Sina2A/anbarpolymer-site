// src/app/market/loading.tsx
//
// Skeleton برای صفحه بازار صنعتی

import SkeletonCard from '@/components/SkeletonCard'
import SkeletonLine from '@/components/SkeletonLine'
import { colors, spacing } from '@/lib/styles/tokens'
import type { CSSProperties } from 'react'

export default function MarketLoading() {
  const headerPlaceholderStyle: CSSProperties = {
    background: colors.navy,
    height: 72,
    width: '100%',
  }

  const pageStyle: CSSProperties = {
    minHeight: '100vh',
    background: colors.bgPage,
    padding: `${spacing.xxl}px ${spacing.xl}px`,
    fontFamily: "'Vazirmatn', Tahoma, sans-serif",
    direction: 'rtl',
  }

  const containerStyle: CSSProperties = {
    maxWidth: 1180,
    margin: '0 auto',
  }

  const filtersStyle: CSSProperties = {
    display: 'flex',
    gap: spacing.md,
    marginBottom: spacing.xl,
    flexWrap: 'wrap',
  }

  const gridStyle: CSSProperties = {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
    gap: spacing.md,
  }

  return (
    <>
      <div style={headerPlaceholderStyle} />
      <div style={pageStyle}>
        <div style={containerStyle}>
          {/* فیلترها */}
          <div style={filtersStyle}>
            <SkeletonLine width={150} height={36} />
            <SkeletonLine width={150} height={36} />
            <SkeletonLine width={150} height={36} />
            <SkeletonLine width={150} height={36} />
          </div>
          {/* گرید کارت‌ها */}
          <div style={gridStyle}>
            {Array.from({ length: 6 }).map((_, i) => (
              <SkeletonCard key={i} height={180} lines={4} />
            ))}
          </div>
        </div>
      </div>
    </>
  )
}
