import './globals.css'
import ClientProviders from './ClientProviders'

export const metadata = {
  title: 'انبار پلیمر',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="fa" dir="rtl">
      <body>
        <ClientProviders>
          {children}
        </ClientProviders>
      </body>
    </html>
  )
}
