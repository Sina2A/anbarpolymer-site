// src/app/grades/loading.tsx
//
// Skeleton برای صفحه لیست گریدها

import SkeletonCard from '@/components/SkeletonCard'
import { colors, spacing } from '@/lib/styles/tokens'
import type { CSSProperties } from 'react'

export default function GradesLoading() {
  const headerPlaceholderStyle: CSSProperties = {
    background: colors.navy,
    height: 72,
    width: '100%',
  }

  const pageStyle: CSSProperties = {
    minHeight: '100vh',
    background: colors.bgPage,
    padding: `${spacing.xxl}px ${spacing.xl}px`,
    fontFamily: "'Vazirmatn', Tahoma, sans-serif",
    direction: 'rtl',
  }

  const containerStyle: CSSProperties = {
    maxWidth: 1180,
    margin: '0 auto',
  }

  const gridStyle: CSSProperties = {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
    gap: spacing.md,
  }

  return (
    <>
      <div style={headerPlaceholderStyle} />
      <div style={pageStyle}>
        <div style={containerStyle}>
          <div style={gridStyle}>
            {Array.from({ length: 12 }).map((_, i) => (
              <SkeletonCard key={i} height={140} lines={3} />
            ))}
          </div>
        </div>
      </div>
    </>
  )
}
