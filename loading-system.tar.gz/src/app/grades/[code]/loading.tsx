// src/app/grades/[code]/loading.tsx
//
// Skeleton برای صفحه جزئیات گرید

import SkeletonCard from '@/components/SkeletonCard'
import SkeletonLine from '@/components/SkeletonLine'
import { colors, spacing } from '@/lib/styles/tokens'
import type { CSSProperties } from 'react'

export default function GradeDetailLoading() {
  const headerPlaceholderStyle: CSSProperties = {
    background: colors.navy,
    height: 72,
    width: '100%',
  }

  const pageStyle: CSSProperties = {
    minHeight: '100vh',
    background: colors.bgPage,
    padding: `${spacing.xxl}px ${spacing.xl}px`,
    fontFamily: "'Vazirmatn', Tahoma, sans-serif",
    direction: 'rtl',
  }

  const containerStyle: CSSProperties = {
    maxWidth: 1180,
    margin: '0 auto',
  }

  const topSectionStyle: CSSProperties = {
    marginBottom: spacing.xl,
  }

  const gridStyle: CSSProperties = {
    display: 'grid',
    gridTemplateColumns: '2fr 1fr',
    gap: spacing.lg,
  }

  return (
    <>
      <div style={headerPlaceholderStyle} />
      <div style={pageStyle}>
        <div style={containerStyle}>
          {/* عنوان و توضیحات */}
          <div style={topSectionStyle}>
            <SkeletonLine width="40%" height={32} />
            <div style={{ marginTop: spacing.sm }}>
              <SkeletonLine width="80%" />
              <SkeletonLine width="70%" />
            </div>
          </div>
          {/* مشخصات + قیمت */}
          <div style={gridStyle}>
            <SkeletonCard height={300} lines={6} />
            <SkeletonCard height={300} lines={4} />
          </div>
          {/* نمودار */}
          <div style={{ marginTop: spacing.lg }}>
            <SkeletonCard height={250} lines={2} />
          </div>
        </div>
      </div>
    </>
  )
}
