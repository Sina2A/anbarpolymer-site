// src/app/ClientProviders.tsx
//
// Client Component wrapper برای Context‌ها — layout.tsx Server باقی می‌مونه

'use client'

import { LoadingProvider } from '@/contexts/LoadingContext'
import type { ReactNode } from 'react'

export default function ClientProviders({ children }: { children: ReactNode }) {
  return (
    <LoadingProvider>
      {children}
    </LoadingProvider>
  )
}
