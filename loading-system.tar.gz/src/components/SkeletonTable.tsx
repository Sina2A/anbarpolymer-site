// src/components/SkeletonTable.tsx
//
// جدول skeleton برای صفحات لیست (my-orders, my-listings, my-deals)

import SkeletonLine from './SkeletonLine'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import type { CSSProperties } from 'react'

type Props = {
  rows?: number
  columns?: number
}

export default function SkeletonTable({ rows = 5, columns = 5 }: Props) {
  const tableStyle: CSSProperties = {
    width: '100%',
    borderCollapse: 'collapse',
    background: colors.bgCard,
    borderRadius: radius.lg,
    overflow: 'hidden',
  }

  const thStyle: CSSProperties = {
    padding: spacing.sm,
    textAlign: 'right',
    borderBottom: `2px solid ${colors.borderSubtle}`,
    background: colors.bgPage,
  }

  const tdStyle: CSSProperties = {
    padding: spacing.sm,
    borderBottom: `1px solid ${colors.borderSubtle}`,
  }

  return (
    <table style={tableStyle}>
      <thead>
        <tr>
          {Array.from({ length: columns }).map((_, i) => (
            <th key={i} style={thStyle}>
              <SkeletonLine width="80%" height={12} />
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {Array.from({ length: rows }).map((_, rowIndex) => (
          <tr key={rowIndex}>
            {Array.from({ length: columns }).map((_, colIndex) => (
              <td key={colIndex} style={tdStyle}>
                <SkeletonLine width="70%" />
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  )
}
