// src/components/SkeletonLine.tsx
//
// خط shimmer پایه — کامپوننت اصلی برای skeleton

import type { CSSProperties } from 'react'

type Props = {
  width?: string | number
  height?: number
}

export default function SkeletonLine({ width = '100%', height = 14 }: Props) {
  const style: CSSProperties = {
    width,
    height,
  }

  return <div className="shimmer-line" style={style} />
}
