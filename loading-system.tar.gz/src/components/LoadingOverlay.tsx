// src/components/LoadingOverlay.tsx
//
// Overlay برندشده با دایره‌ی نارنجی pulse

'use client'

import { colors, fontSize } from '@/lib/styles/tokens'
import type { CSSProperties } from 'react'

export default function LoadingOverlay() {
  const overlayStyle: CSSProperties = {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    background: 'rgba(255, 255, 255, 0.85)',
    backdropFilter: 'blur(8px)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 9999,
  }

  const boxStyle: CSSProperties = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: 16,
  }

  const circleStyle: CSSProperties = {
    width: 48,
    height: 48,
    borderRadius: '50%',
    background: colors.orange,
    boxShadow: '0 0 0 4px rgba(230, 87, 22, 0.28)',
  }

  const labelStyle: CSSProperties = {
    fontSize: fontSize.sm,
    color: colors.navy,
    fontWeight: 600,
    fontFamily: 'var(--font-label)',
  }

  return (
    <div style={overlayStyle}>
      <div style={boxStyle}>
        <div style={circleStyle} className="pulse-animation" />
        <div style={labelStyle}>در حال پردازش...</div>
      </div>
    </div>
  )
}
