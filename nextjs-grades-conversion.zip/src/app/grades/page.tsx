import prisma from '@/lib/prisma'

export const dynamic = 'force-dynamic'

export default async function GradesPage() {
  const grades = await prisma.grade.findMany({
    orderBy: { code: 'asc' },
  })

  return (
    <>
      <div className="topbar">
        <div className="wrap">
          <span>پشتیبانی فروش شنبه تا چهارشنبه ۸:۳۰ تا ۱۷:۳۰</span>
          <a className="phone" href="tel:+982191234567">021-91234567</a>
        </div>
      </div>
      <header className="site-header">
        <div className="wrap">
          <a href="/" className="logo"><span className="dot"></span> انبار پلیمر</a>
          <nav className="main-nav">
            <a href="/">صفحه اصلی</a>
            <a href="/grades" className="active">گریدها</a>
            <a href="/rfq">استعلام قیمت</a>
            <a href="/reports">گزارش بازار</a>
            <a href="/services">خدمات سازمانی</a>
            <a href="/about">درباره ما</a>
            <a href="/contact">تماس با ما</a>
          </nav>
          <div className="header-actions">
            <input className="search-box" placeholder="جستجوی گرید یا کد محصول…" />
            <a href="/login" className="acct-btn">ورود / ثبت‌نام</a>
          </div>
        </div>
      </header>

      <section>
        <div className="wrap">
          <div className="eyebrow">دیتاشیت و مقایسه گریدها</div>
          <div className="sec-title">مشخصات فنی گریدهای پلیمری</div>
          <div className="sec-sub" style={{ marginBottom: 24 }}>
            این صفحه فقط برای مقایسه‌ی فنی گریدهاست؛ برای قیمت و موجودی به صفحه‌ی استعلام قیمت مراجعه کنید. —{' '}
            <b style={{ color: 'var(--cyan)' }}>{grades.length} گرید از دیتابیس</b>
          </div>

          <table className="g-table">
            <thead>
              <tr>
                <th>نوع ماده</th>
                <th>گرید</th>
                <th>تولیدکننده</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {grades.map((g) => (
                <tr key={g.id}>
                  <td>{g.category}</td>
                  <td className="grade-code">{g.code}</td>
                  <td>{g.producer}</td>
                  <td><a href={`/grades/${g.code}`} className="btn btn-sm btn-outline">دیتاشیت</a></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <footer className="site-footer">
        <div className="wrap">
          <div className="footer-cols">
            <div>
              <a href="/" className="logo" style={{ marginBottom: 14, display: 'flex' }}><span className="dot"></span> انبار پلیمر</a>
              <p style={{ color: 'var(--ink-dim)', fontSize: 13, maxWidth: 280 }}>واردکننده و فروشنده مستقیم مواد اولیه پلیمری برای کارخانه‌های تولیدی سراسر کشور.</p>
            </div>
            <div>
              <h5>محصولات</h5>
              <ul>
                <li><a href="/grades">پلی‌پروپیلن</a></li>
                <li><a href="/grades">پلی‌اتیلن</a></li>
                <li><a href="/grades">پی‌وی‌سی</a></li>
                <li><a href="/grades">پلی‌اتیلن ترفتالات</a></li>
              </ul>
            </div>
            <div>
              <h5>خدمات</h5>
              <ul>
                <li><a href="/rfq">استعلام قیمت آنلاین</a></li>
                <li><a href="/services">فروش سازمانی</a></li>
                <li><a href="/services">ارسال و لجستیک</a></li>
                <li><a href="/reports">گزارش بازار</a></li>
              </ul>
            </div>
            <div>
              <h5>اطلاعات تماس</h5>
              <ul>
                <li>تهران، خیابان ولیعصر، پلاک ۱۲۴</li>
                <li>انبار یزد — شهرک صنعتی یزد</li>
                <li style={{ direction: 'ltr', textAlign: 'right' }}>021-91234567</li>
              </ul>
            </div>
          </div>
          <div className="footer-bottom">
            <span>انبار پلیمر © ۱۴۰۵ — تمام حقوق محفوظ است</span>
          </div>
        </div>
      </footer>
    </>
  )
}
