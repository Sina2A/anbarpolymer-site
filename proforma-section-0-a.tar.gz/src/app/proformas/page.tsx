import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'

export const dynamic = 'force-dynamic'

/**
 * صفحه‌ی لیست «پیش‌فاکتورهای من» — فقط سفارش‌هایی که کارشناس قیمت‌گذاری کرده
 * (status: priced) یا مشتری تایید کرده و در مرحله‌ی قرارداده (buyer_confirmed / contracted).
 *
 * وضعیت‌های واقعی از workflow.ts:
 *   priced → buyer_confirmed → contracted
 */

const STATUS_LABELS: Record<string, string> = {
  priced: 'در انتظار تایید شما',
  buyer_confirmed: 'تایید شد — در حال عقد قرارداد',
  contracted: 'قرارداد بسته شد',
}

export default async function ProformasPage() {
  const user = await getCurrentUser()

  const orders = await prisma.order.findMany({
    where: {
      userId: user.id,
      status: { in: ['priced', 'buyer_confirmed', 'contracted'] },
    },
    include: { items: { include: { grade: true } } },
    orderBy: { createdAt: 'desc' },
  })

  return (
    <div style={pageStyle}>
      <div style={{ maxWidth: 820, margin: '0 auto' }}>
        <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>پیش‌فاکتورهای من</h1>
        <p style={{ fontSize: 13, color: '#9199a3', marginBottom: 24 }}>
          سفارش‌هایی که قیمت‌گذاری شدن و منتظر تایید یا در مرحله‌ی قرارداد هستن
        </p>

        {orders.length === 0 && (
          <div style={emptyBox}>
            هیچ پیش‌فاکتور فعالی ندارید — وقتی کارشناس فروش قیمت سفارش شما را ثبت کنه، اینجا نمایش داده می‌شه.
          </div>
        )}

        {orders.map((order) => {
          const gradeSummary = order.items.map((i) => i.grade.code).join(' + ')
          const totalRial = order.items.reduce(
            (sum, it) => sum + (it.finalPrice ?? it.price) * it.quantity,
            0
          )

          return (
            <a key={order.id} href={`/proformas/${order.id}`} style={cardLink}>
              <div style={cardStyle}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                  <b style={{ fontSize: 14 }}>سفارش #{order.id.slice(0, 8)}</b>
                  <span style={statusTag}>{STATUS_LABELS[order.status] || order.status}</span>
                </div>

                <div style={{ fontSize: 12.5, color: '#4f5560', marginBottom: 6 }}>
                  <span style={{ fontFamily: 'monospace' }}>{gradeSummary}</span>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: 12.5, fontWeight: 700 }}>
                    {totalRial.toLocaleString('en-US')} ریال
                  </span>
                  <span style={{ fontSize: 11.5, color: '#9199a3' }}>
                    {new Date(order.createdAt).toLocaleDateString('fa-IR')}
                  </span>
                </div>
              </div>
            </a>
          )
        })}
      </div>
    </div>
  )
}

const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: '#faf8f4',
  padding: '32px 20px',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const emptyBox: React.CSSProperties = {
  padding: 32,
  textAlign: 'center',
  color: '#9199a3',
  border: '1px dashed #d8dde3',
  borderRadius: 12,
  fontSize: 13,
}
const cardLink: React.CSSProperties = {
  display: 'block',
  textDecoration: 'none',
  color: 'inherit',
}
const cardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 18,
  marginBottom: 14,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
  transition: 'border-color .15s',
}
const statusTag: React.CSSProperties = {
  fontSize: 11,
  fontWeight: 700,
  background: '#eef4fd',
  color: '#1e357b',
  borderRadius: 6,
  padding: '4px 12px',
}
