# Plan: بازطراحی کارت معامله `/admin-deals` — آکوردئون درون‌خط دو ستونی (آبی/نارنجی)

## Context
- وضعیت فعلی `/admin-deals` (۵۱۳ خط): کارت سادهٔ فشرده با هدر `#{id.slice(0,8)} — buyer — quantity` و `badgeStatus`، پرچم قرمز `driverSilenceFlaggedAt/fundReleaseFrozen/fundReleaseDue`، بلوک وجه + `RefundPolicyHint`، تایم‌لاین `confirmations` (type/ checklistJson/ verdict/ lat/lng/ photoUrl)، بلوک مهلت‌ها (buyerConfirm/discrepancy/fundRelease) + تاریخچه `DeadlineAdjustment` + فرم `adjustDeadlineAction` (فقط admin)، سپس `<details style={payInstrBox}>` «دستور پرداخت» (متن آزاد) و دکمه‌های دستی وجه (`confirmFundsReleased` فقط وقتی `escrowStatus==='secured_manual'`). دو صف بالای صفحه: «در انتظار تایید» (`status==='awaiting_approval'` → `approveDealAction`) و «بررسی پرداخت‌ها» (`status==='confirmed'` × `DealPayment.status in PENDING/SUBMITTED` → `approvePaymentAction`/`rejectPaymentAction`).
- هدف (تصویر `ChatGPT Image ... 01_35_10 AM.png`): هدر غنی با تصویر + کد + برند + خط‌زمانی ۴ مرحله‌ای، و آکوردئون بازشونده با دو ستون: آبی=خریدار، نارنجی=فروشنده — ستون نارنجی عمداً بلندتر (نسبت تصویر ~ ۱:۱.۲، با `flex`/`min-height` پیاده می‌شود).
- تصمیم‌های قفل‌شدهٔ سینا (۴ بند): ارتفاع کارت بسته دست‌نخورده؛ آکوردئون درون‌خط با `<details>/<summary>` روی کل کارت (همان الگوی `payInstrBox`، فقط summary = هدر فعلی) بدون مودال/ناوبری و بدون پرش؛ دو ستون آبی/نارنجی داخل `details`؛ ستون نارنجی بلندتر طبق نسبت تصویر.
- قوانین ثابت: بدون دادهٔ جعلی/نمونه، گیت `logisticsAccessEnabled` دست‌نخورده (این صفحه جدا از حمل‌ونقل است)، بدون تغییر `actions.ts`/مدل‌های موجود مگر پیشنهاد migration، بدون اجرا/build/migration، منطق دکمه‌ها دست‌نخورده — فقط جابه‌جایی چیدمان.

## Field Honesty Matrix — ۱۲ فیلد دیزاین هدف

| # | فیلد دیزاین | منبع واقعی (Read) | وضعیت | رفتار صادقانه در پلن |
|---|-------------|-------------------|-------|----------------------|
| 1 | **تصویر محصول** | `Grade.imageUrl String?` (خط ۳۱ schema) — nullable، بدون fallback | ⚠️ | اگر `grade.imageUrl` موجود بود نمایش؛ اگر null → آیکون placeholder خاکستری + متن «تصویر ثبت نشده»؛ هرگز عکس نمونه/جعلی تزریق نمی‌شود. `Grade` از `Deal.materialListing.grade` یا `Deal.purchaseRequest.grade` می‌آید (هر دو روی `gradeId`). |
| 2 | **نام محصول + برند** (`PP 552R` + `Jam`) | `Grade.code String @unique` + `Grade.producer String` (خط ۱۶-۱۸) | ✅ | `code` + `producer` — هر دو NOT NULL، همیشه قابل نمایش. فرمت: عنوان اصلی `code`، زیرعنوان `producer` + `Grade.category` (پلی‌پروپیلن) اختیاری. |
| 3 | **کد معامله** (`DEAL-2026-00127`) | `Deal.id String @id @default(cuid())` — فقط cuid داخلی؛ هیچ فیلد `dealNumber` وجود ندارد | ⚠️ | همان short-id فعلی `deal.id.slice(0,8)` کفایت می‌کند (تصمیم ۴ قبلی: بدون migration). داخل کارت به شکل `#AP-xxxxxxxx` یا `#<8>` نمایش؛ فرمت `DEAL-YYYY-NNNNN` به‌عنوان migration پیشنهادی جدا (اختیاری) ذکر می‌شود، نه اجرا. |
| 4 | **خط‌زمانی وضعیت معامله** (ثبت→درحال‌انجام→تسویه→تکمیل) — ۴ دایرهٔ تصویر | `Deal.status String` (خط ۳۲۹) — مقادیر واقعی: `draft`/`awaiting_approval`/`confirmed`/`seller_fee_paid`/`payment_secured`/`loading`/`in_transit`/`delivered`/`settled` + `void`/`cancelled`/`transport_pending` | ✅ | نگاشت ۴ مرحله‌ای: ① ثبت معامله = `draft|awaiting_approval|confirmed` ؛ ② در حال انجام = `seller_fee_paid|payment_secured|transport_pending|loading|in_transit` ؛ ③ تسویه = `delivered` (+ `escrowStatus==='secured_manual'` اگر هنوز آزاد نشده) ؛ ④ تکمیل = `settled` (+ `escrowStatus==='released_manual'`). `void/cancelled` → استایل خطا + ۴ نقطه خاکستری با برچسب «باطل شد». |
| 5 | **کد اقتصادی خریدار/فروشنده** | `Company.economicCode String?` (خط ۲۲۴) روی `User.company` — nullable؛ `Kyc` جدا | ⚠️ | `buyer.company?.economicCode` و `seller.company?.economicCode` (seller = `Deal.sellerId` یا `Deal.seller` relation؛ fallback اگر `sellerId==null` → مالک `materialListing.user`). اگر null → «—» + زیرمتن ۱۰px «کد اقتصادی ثبت نشده» (همان لحن «نامشخص» قبلی). |
| 6 | **آدرس خریدار/فروشنده** | `Company.address String?` + `Company.province/city/postalCode String?` (خط ۲۲۹-۲۳۲)؛ `Kyc.factoryAddress String?` (خط ۲۸۱) برای تولیدکننده | ⚠️ | ترکیب `province` + `city` + `address`؛ برای فروشنده اگر `Kyc.factoryAddress` پر بود اولویت با آن. هیچکدام نیست → «آدرس ثبت نشده» (نه آدرس جعلی اصفهان/بندرعباس تصویر). |
| 7 | **«وضعیت احراز هویت»** (تایید‌شده) | `Kyc.level Int` + `Kyc.badge String` (خط ۲۶۶-۲۶۷): `none|verified_company|verified_producer|trusted_supplier|trusted_buyer` + `Kyc.verificationSource` + `Company.kyc` relation | ✅ | `badge!=='none' && level>=1` → «تایید‌شده» با تیک سبز؛ وگرنه «تایید نشده» خاکستری. منبع از `buyer.company.kyc` و `seller.company.kyc`. |
| 8 | **خط‌زمانی پرداخت هر طرف** (در انتظار→ثبت‌شد→تاییدشد→تسویه) | `DealPayment` با `kind='BUYER_GOODS'|'SELLER_FEE'` (خط ۴۰۵)، `status PENDING|SUBMITTED|APPROVED|REJECTED` + `receiptUrl/submittedAt/reviewedAt` (خط ۴۰۷-۴۱۱)، + `Deal.escrowStatus pending|secured_manual|released_manual` برای گام نهایی تسویه | ✅ | هر ستون timeline خودش را از ردیف مربوطه می‌گیرد: خریدار←`BUYER_GOODS`، فروشنده←`SELLER_FEE`. نگاشت: `PENDING`→در انتظار پرداخت/دریافت، `SUBMITTED` (یا `receiptUrl` موجود)→پرداخت ثبت شد، `APPROVED`→تایید پرداخت، `escrowStatus==='released_manual'` یا `Deal.status==='settled'`→تسویه/وجه قابل تسویه. اگر ردیف `DealPayment` اصلاً وجود نداشت → «—» (نه درصد جعلی). |
| 9 | **«اطلاعات پرداخت» (شماره‌حساب + نام بانک، جدا)** | `Deal.paymentInstructionsText String?` (خط ۳۵۹) — **یک فیلد آزاد واحد**، همین. هیچ `PaymentInstruction` جدا یا فیلد `bankName/accountNumber` در schema نیست (جستجوی grep تایید) | ❌ | نمی‌شود شماره‌حساب/بانک را جدا نمایش داد. همان متن آزاد عیناً در بلوک «اطلاعات پرداخت» هر دو ستون رندر می‌شود (`white-space: pre-wrap`) با دکمهٔ «کپی متن» کلی (نه کپی شماره‌حساب جدا). اگر `null` → «خالی — کارشناس هنوز دستوری ثبت نکرده» (همان `payInstrEmptyTag`). فرم ویرایش `updateDealPaymentInstructionsAction` دست‌نخورده می‌ماند و داخل ستون خریدار (آبی) جاسازی می‌شود. |
| 10 | **«اطلاعات تخلیه بار»** (مسئول تخلیه، آدرس، شماره تماس) | `DealConfirmation.type==='unloading'` دارد `receiverName/receiverRole` (خط ۶۴۱-۶۴۲) + `latitude/longitude` — ولی **آدرس ساختاریافته/شماره تماس تخلیه ندارد**. `PurchaseRequest` فقط `province String?` دارد (خط ۹۰۵)، بدون شهر/آدرس/تلفن. `Company.companyPhone String?` برای تلفن شرکت | ❌/⚠️ | مسئول: اگر `unloading` confirmation موجود → `receiverName (receiverRole)`؛ وگرنه `buyer.companyName`. آدرس: `buyer.company` (province/city/address) یا `PurchaseRequest.province` به‌عنوان fallback؛ شماره تماس: `buyer.phone` یا `buyer.company.companyPhone`. هرکدام null → «—» / «ثبت نشده»؛ هرگز شمارهٔ نمونهٔ `۰۹۱۳۱۴...` تصویر پر نمی‌شود. |
| 11 | **«اطلاعات بارگیری»** (مسئول بارگیری، آدرس، شماره تماس) | `MaterialListing.province+city` (خط ۸۵۹-۸۶۰) + `MaterialListing.user` (فروشنده) + `Kyc.factoryAddress` + `DealConfirmation.type==='loading'` (`driverName/driverPhone/vehiclePlate`) — ولی بدون فیلد «مسئول بارگیری/تلفن بارگیری» ساختاریافتهٔ جدا | ⚠️ | مسئول بارگیری: اگر `loading` confirmation دارد → `driverName` یا `seller.companyName`؛ وگرنه `materialListing.user.companyName` یا `Deal.seller.companyName`. آدرس: `materialListing.province/city` + `seller Kyc.factoryAddress ?? seller Company.address` (اولویت کارخانه). تماس: `seller.phone` یا `driver.phone` یا `Company.companyPhone`. کمبود → «—». |
| 12 | **دکمهٔ «اقدام بعدی» هر طرف** | actions موجود: `approveDealAction` (awaiting→confirmed)، `approvePaymentAction`/`rejectPaymentAction` (روی `DealPayment`، بدون ترتیب، اتمیک + `transport_pending` اگر هر دو APPROVED)، `updateDealPaymentInstructionsAction` (متن آزاد)، `confirmFundsReleased` (فقط `escrowStatus==='secured_manual'`، idempotent)، `adjustDeadlineAction` | ✅ | هر دکمه به action واقعی وصل می‌شود، نه دکوری: ستون آبی (خریدار) → فرم دستور پرداخت + اگر صف بررسی پرداخت شامل `BUYER_GOODS` بود → دکمه‌های تایید/رد همان پرداخت؛ ستون نارنجی (فروشنده) → اگر `SELLER_FEE` در صف بود → تایید/رد آن؛ بلوک وجه نهایی (تسویه) اگر `secured_manual` → `confirmFundsReleased`. اگر هیچ action مجاز نبود → متن «اقدامی باقی نمانده» (نه دکمهٔ نارنجی جعلی «اعلام آمادگی بارگیری» با فرم خیالی). |

**قاعدهٔ کل:** هر ❌ یا کمبود ⚠️ → یا حذف بلوک مربوطه یا placeholder صادقانهٔ «— / ثبت نشده / خالی» — هرگز مقدار نمونهٔ `DEAL-...`/`۱۴۰۰۱۲۳...`/`۰۹۱۲...` تصویر کپی نمی‌شود.

## Accordion Mechanism — پیشنهادی (ارتفاع بسته دست‌نخورده)

- **ساختار DOM:** هر کارتِ فعلیِ `deals.map` که الآن `<div style={cardStyle}>` است، به `<details style={cardStyle}>` تبدیل می‌شود؛ محتوای «بسته» عیناً داخل `<summary>` می‌رود (همان سطر `#{id} — buyer — quantity + badge + پرچم‌ها`). `summary` استایل پیش‌فرض مثلث را با `listStyle:none` و `::-webkit-details-marker: none` مخفی می‌کند و `cursor:pointer` می‌گیرد؛ هاور → `background:#fafbfc`. همین الگوی `payInstrBox` فعلی است، فقط در سطح کل کارت.
- **ارتفاع بسته:** چون `summary` دقیقاً همان JSX قبلی است و `details` با `cardStyle` موجود رندر می‌شود، ارتفاع بسته دقیقاً ثابت می‌ماند؛ هیچ padding/margin اضافه در حالت بسته اضافه نمی‌شود.
- **محتوای بازشونده:** زیر `summary`، یک `div` دو ستونی با `display:grid; gridTemplateColumns: 1fr 1fr; gap:16px` (در موبایل `1fr` با media query) قرار می‌گیرد. ستون راست = آبی (خریدار، `background:#f0f6ff`، `borderTop: 4px solid #1e357b`)، ستون چپ = نارنجی (فروشنده، `background:#fff7ed`، `borderTop: 4px solid #ea580c`). طبق بند ۴ قفل‌شده، ستون نارنجی بلندتر است: با `alignItems: stretch` + `minHeight` وزن‌دار: آبی `minHeight: 420px`، نارنجی `minHeight: 520px` (نسبت ~۱:۱.۲۴ مطابق تصویر — narنجی حدود ۲۰-۲۵٪ بلندتر؛ داخل ستون‌ها `flex:1` و `justifyContent: space-between` تا بلوک‌ها کش بیاید). ستون کوتاه‌تر اگر محتوایش کم بود، فضای خالیِ صادقانه می‌ماند (نه پر کردن جعلی).
- **هدرهای ستون:** هر ستون هدر رنگی با آیکون (آبی: 🏢 خریدار، نارنجی: 🏭 فروشنده) + زیرش بلوک «کد اقتصادی / آدرس / احراز هویت / وضعیت پرداخت (timeline عمودی ۴ قدم) / اطلاعات پرداخت / تخلیه یا بارگیری / اقدام بعدی». ترتیب بلوک‌ها عین تصویر است.
- **بدون پرش/ناوبری:** `<details>` بومی است — باز شدن صفحه را به پایین هل می‌دهد (natural flow)، بدون `router.push`، بدون `useState` جدا، بدون scroll-into-view اجباری. (اختیاری: `details[open] { scroll-margin-top: 16px }` برای جلوگیری از پرش ناگهانی.)
- **بلوک‌های انتقالی:** تایم‌لاین `confirmations` فعلی و بلوک مهلت‌ها (`buyerConfirmDeadline/discrepancy/fundRelease` + `DeadlineAdjustment` + فرم `adjustDeadlineAction`) داخل ستون مربوطه جاسازی می‌شود (تایم‌لاین بارگیری→ ستون نارنجی، تخلیه/buyer_confirm→ ستون آبی، مهلت‌ها→ هر دو ستون یا فوتر مشترک زیر grid — پیشنهاد: فوتر مشترک کم‌رنگ زیر grid تا تکرار نشود). `payInstrBox` جزیره‌ای حذف و محتوایش داخل دو بلوک «اطلاعات پرداخت» ادغام می‌شود.

## Data Fetching & Mapping

- **گسترش `findMany`:** فعلی `include: { buyer:true, confirmations:{orderBy:{confirmedAt:asc}}, payments:true }` → به:
  ```
  buyer: { include: { company: { include: { kyc: true } } } },
  seller: { include: { company: { include: { kyc: true } } } }, // via Deal.sellerId
  materialListing: { include: { grade: true, user: { include: { company: { include: { kyc:true } } } } } },
  purchaseRequest: { include: { grade: true } },
  confirmations, payments, deadlineAdjustments (already fetched separately), transportCompany?, driver?
  ```
  یک کوئری می‌ماند (بدون N+1)؛ seller از `Deal.seller` (یا fallback `materialListing.user`) حل می‌شود.
- **Grade resolution:** `grade = materialListing?.grade ?? purchaseRequest?.grade` — هر دو روی `gradeId` مشترک‌اند؛ `code/producer/imageUrl/category` از آن.
- **Company/KYC:** `buyerCompany = deal.buyer.company`, `sellerCompany = deal.seller?.company ?? deal.materialListing?.user.company`؛ `buyerKyc = buyerCompany?.kyc`, `sellerKyc = sellerCompany?.kyc`.
- **Payments:** `buyerPayment = payments.find(p=>p.kind==='BUYER_GOODS')`, `sellerPayment = payments.find(p=>p.kind==='SELLER_FEE')`.
- **Loading/Unloading:** `loadingConf = confirmations.find(c=>c.type==='loading')`, `unloadingConf = confirmations.find(c=>c.type==='unloading')`.

## Action Wiring — جابه‌جایی بدون تغییر منطق

- `approveDealAction(dealId)` — اگر `status==='awaiting_approval'` بود، دکمهٔ آبی داخل ستون خریدار (زیر «اقدام بعدی خریدار»)؛ وگرنه مخفی. فرم `action={approveDealAction.bind(null, deal.id)}` دست‌نخورده.
- `approvePaymentAction` / `rejectPaymentAction` — هرکدام فقط روی ردیف `kind` مربوطه و فقط وقتی `status in PENDING/SUBMITTED` (همان فیلتر `reviewablePayments`) — دکمه‌ها داخل ستون مربوطه (BUYER→آبی، SELLER→نارنجی) منتقل می‌شوند؛ inputهای `dealId/kind/reason/penaltyHours` عیناً می‌مانند.
- `updateDealPaymentInstructionsAction` — فرم textarea داخل بلوک «اطلاعات پرداخت» ستون آبی (خریدار)؛ شارژ مجدد `revalidatePath('/admin-deals')` حفظ.
- `confirmFundsReleased` — فقط وقتی `escrowStatus==='secured_manual'` (گارد `updateMany` داخل action)، دکمهٔ «تایید پرداخت به فروشنده» در فوتر مشترک یا ستون فروشنده؛ وگرنه «✓ تسویه شد» یا مخفی.
- `adjustDeadlineAction` + نمایش `DeadlineAdjustment` — بلوک مهلت‌ها فوتر مشترک زیر grid (فقط admin می‌بیند، مثل قبل).

## Files & Scope

- **تغییر اصلی:** `src/app/admin-deals/page.tsx` — کارت به `<details>/<summary>` + grid دو ستونی + نگاشت فیلدهای بالا + کپی‌باکس برای `paymentInstructionsText`؛ هدر غنی بالای کارت (تصویر + کد + قیمت توافقی + timeline ۴ مرحله) داخل summary/بالای details.
- **بدون تغییر:** `src/app/admin-deals/actions.ts` (هیچ action جدید/تغییر logic)، `prisma/schema.prisma` (در این فاز هیچ migration — پیشنهاد `dealNumber String? @unique` برای فرمت `DEAL-YYYY-NNNNN` فقط در بخش «پیشنهاد آتی» ذکر می‌شود)، `src/lib/styles/*` reuse (`cardStyle/pageStyle/badgeStyle/btn*`).
- **استایل:** `colors.navy #1e357b` برای آبی، `colors.orange #ea580c` برای نارنجی (از `tokens.ts`)؛ `spacing/radius/fontSize` مشترک.

## Proposals (فقط پیشنهاد، بدون اجرا)

- **Migration پیشنهادی (اختیاری، بعداً):** `Deal.dealNumber String? @unique` با فرمت `DEAL-YYYY-NNNNN` (sequence سالانه) یا view روی `fiscalYear+seq` مثل `Invoice.number`؛ فعلاً short-id کافی است — فقط برای تایید جدا پیشنهاد می‌شود.
- **Grade.imageUrl filling:** اگر بخواهیم تصویر واقعاً پر شود، یک seed/admin-upload برای `Grade.imageUrl` پیشنهاد می‌شود (نه mock در کد).

## Verification

- `rg paymentInstructionsText` → فقط `Deal.paymentInstructionsText` واحد؛ هیچ split.
- `rg Grade.*imageUrl` / `Company.*economicCode` / `Company.*address` / `Kyc.*badge` → nullable بودن تایید.
- رندر دستی: کارت بسته ارتفاعش با قبل برابر بماند؛ بازشو → دو ستون آبی/نارنجی، نارنجی بلندتر؛ کمبود داده → «—/ثبت نشده» (نه عدد جعلی تصویر).
- کلیک اکشن‌ها: تایید معامله/پرداخت/دستور پرداخت/آزادسازی → `revalidatePath` و تغییر status/escrow طبق قبل.
- بدون `next build` / `prisma migrate` در این فاز — فقط plan.

