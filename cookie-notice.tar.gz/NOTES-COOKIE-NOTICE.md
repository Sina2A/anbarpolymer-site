# بنر اطلاع‌رسانی کوکی — NOTES

## تصمیم
سایت فقط یک کوکی دارد: `SESSION_COOKIE = 'anbar_session'` در `src/lib/auth.ts` — ضروری برای نشست ورود، بدون آن لاگین کار نمی‌کند. هیچ اسکریپت ردیابی/آمار/تبلیغاتی (Analytics و مشابه) وجود ندارد. بنابراین بنر صادقانه است: بدون «قبول/رد» قلابی، فقط یک دکمه‌ی «متوجه شدم».

## فایل‌های تغییریافته
- **جدید:** `src/components/CookieNotice.tsx` (`'use client'`) — الگوی `OfflineBanner.tsx` (استایل inline از `src/lib/styles/tokens.ts`، بدون CSS جدید).
- **ویرایش:** `src/app/layout.tsx` — یک import و یک JSX (`<CookieNotice />` کنار `<OfflineBanner />`، قبل از `<ClientProviders>`). چون `layout.tsx` بین هر ۴ سطح (عمومی/کاربر/ادمین/حمل‌ونقل) مشترک است، خودکار همه‌جا اعمال می‌شود.

## رفتار
- متن: «این سایت فقط از یک کوکی ضروری برای نگه‌داشتن نشست ورود شما استفاده می‌کند — هیچ ردیابی یا تبلیغاتی نداریم.» + دکمه‌ی «متوجه شدم».
- فقط یک‌بار: بعد از کلیک `localStorage.setItem('ap-cookie-notice-seen','1')`؛ رندر بعدی `null`. کلید: `ap-cookie-notice-seen`.
- هیدریشن: `useState<boolean | null>(null)` — سرور `null` → چیزی رندر نمی‌کند؛ کلاینت بعد از mount از `localStorage` می‌خواند. عدم دسترسی به `localStorage` → بنر برای همان سشن مخفی می‌ماند.
- دسترسی‌پذیری: `role="region"` + `aria-label="اطلاع‌رسانی کوکی"` (نه `status` — تغییر وضعیت شبکه نیست).
- بدون تغییر `src/lib/auth.ts` یا خود کوکی.

## جایگاه و تداخل دو بنر
- `OfflineBanner`: `position: fixed; top: 0; z-index: 9999`
- `CookieNotice`: `position: fixed; bottom: 0; z-index: 9998` — پایین صفحه، با `borderTop` و `boxShadow` مات. حتی اگر هر دو هم‌زمان نمایش داده شوند هم‌پوشانی ندارند. چیدمان داخلی `flex` با `flexWrap: wrap`.

## تأیید
- `npx tsc --noEmit` — صفر خطا روی فایل‌های تغییریافته.
- `npx next build` — EXIT 0 (وابستگی‌های اعلان‌نشده‌ی پیشین `lucide-react`/`@tanstack/react-table@8`/`echarts`/`echarts-for-react` با `--no-save --no-package-lock` نصب شدند؛ `package.json`/`package-lock.json` دست‌نخورده).
