// src/components/CookieNotice.tsx
//
// بنر اطلاع‌رسانی کوکی — ساده و صادقانه (بدون انتخاب قلابی).
// سایت فقط یک کوکی ضروری دارد (SESSION_COOKIE در src/lib/auth.ts).
// هیچ اسکریپت ردیابی/تبلیغاتی نیست، پس بنر فقط یک دکمه دارد: «متوجه شدم».

'use client'

import { useEffect, useState } from 'react'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'

const STORAGE_KEY = 'ap-cookie-notice-seen'

export default function CookieNotice() {
  const [seen, setSeen] = useState<boolean | null>(null)

  useEffect(() => {
    try {
      setSeen(localStorage.getItem(STORAGE_KEY) === '1')
    } catch {
      setSeen(true)
    }
  }, [])

  if (seen !== false) return null

  function dismiss() {
    try {
      localStorage.setItem(STORAGE_KEY, '1')
    } catch {
      // storage unavailable — just hide for this session
    }
    setSeen(true)
  }

  return (
    <div
      role="region"
      aria-label="اطلاع‌رسانی کوکی"
      style={{
        position: 'fixed',
        bottom: 0,
        insetInline: 0,
        zIndex: 9998,
        background: colors.bgCard,
        borderTop: `1px solid ${colors.borderSubtle}`,
        boxShadow: '0 -1px 8px rgba(27,30,36,0.08)',
        padding: '12px 16px',
        direction: 'rtl',
      }}
    >
      <div
        style={{
          maxWidth: 960,
          margin: '0 auto',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: spacing.md,
          flexWrap: 'wrap',
        }}
      >
        <p
          style={{
            margin: 0,
            color: colors.textSecondary,
            fontFamily: "'Vazirmatn', Tahoma, sans-serif",
            fontSize: fontSize.base,
            lineHeight: 1.7,
            flex: '1 1 280px',
          }}
        >
          این سایت فقط از یک کوکی ضروری برای نگه‌داشتن نشست ورود شما استفاده
          می‌کند — هیچ ردیابی یا تبلیغاتی نداریم.
        </p>
        <button
          type="button"
          onClick={dismiss}
          style={{
            flexShrink: 0,
            background: colors.navy,
            color: '#fff',
            border: `1px solid ${colors.navy}`,
            borderRadius: radius.md,
            padding: '8px 20px',
            fontFamily: "'Vazirmatn', Tahoma, sans-serif",
            fontSize: fontSize.base,
            fontWeight: 700,
            cursor: 'pointer',
            lineHeight: 1.5,
            whiteSpace: 'nowrap',
          }}
        >
          متوجه شدم
        </button>
      </div>
    </div>
  )
}
