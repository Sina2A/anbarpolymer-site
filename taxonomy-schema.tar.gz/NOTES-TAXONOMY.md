# Taxonomy + GradeAttribute — NOTES

**Migration:** `prisma/migrations/20260823200000_add_category_tree_and_grade_attributes/migration.sql`
- Creates `categories`, `grade_attributes`, `_GradeToGradeAttribute` + adds `grades.categoryId` (nullable, FK SET NULL).
- **Status:** created, NOT applied. Do not run `prisma migrate dev/deploy` until explicitly approved.
- `npx prisma validate` OK, `npx prisma generate` OK, `tsc --noEmit` — zero new errors (pre-existing lucide/echarts only).

**Schema:** `prisma/schema.prisma`
- `Category` tree L1-4: level Int, kind String, `@@unique([level, slug])`, parentId Restrict, `@@map("categories")`.
- `Grade.categoryId` nullable + `categoryNode` relation (legacy `Grade.category String` kept untouched — 37 display sites unaffected).
- `GradeAttribute`: value/kind (`application`|`process`), implicit m2m `grades`, `@@unique([value, kind])`, `@@map("grade_attributes")`. No seeded values — filled later via datasheet import. Coexists with legacy `Grade.applicationType String?`.
- `MaterialListing`/`PurchaseRequest` unaffected (join via gradeId only).

**Post-migration change (homepage):** once categories are seeded, switch homepage stat from
`prisma.grade.findMany({ distinct: ['category'] })` to `prisma.category.count({ where: { level: 3, isActive: true } })`.

**Blocker:** Real L1/L2/L4 names still needed from Sina — no fake data seeded.
