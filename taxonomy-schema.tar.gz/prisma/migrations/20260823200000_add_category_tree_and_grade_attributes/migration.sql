-- CreateTable categories
CREATE TABLE "categories" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "level" INTEGER NOT NULL,
    "kind" TEXT NOT NULL,
    "parentId" TEXT,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "description" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable grade_attributes
CREATE TABLE "grade_attributes" (
    "id" TEXT NOT NULL,
    "value" TEXT NOT NULL,
    "kind" TEXT NOT NULL,
    CONSTRAINT "grade_attributes_pkey" PRIMARY KEY ("id")
);

-- CreateTable _GradeToGradeAttribute (Prisma implicit m2m)
CREATE TABLE "_GradeToGradeAttribute" (
    "A" TEXT NOT NULL,
    "B" TEXT NOT NULL,
    CONSTRAINT "_GradeToGradeAttribute_AB_pkey" PRIMARY KEY ("A","B")
);

-- AlterTable grades: add categoryId
ALTER TABLE "grades" ADD COLUMN "categoryId" TEXT;

-- Constraints & Indexes
CREATE UNIQUE INDEX "categories_level_slug_key" ON "categories"("level", "slug");
CREATE UNIQUE INDEX "grade_attributes_value_kind_key" ON "grade_attributes"("value", "kind");
CREATE INDEX "categories_parentId_idx" ON "categories"("parentId");
CREATE INDEX "categories_level_isActive_sortOrder_idx" ON "categories"("level", "isActive", "sortOrder");
CREATE INDEX "grade_attributes_kind_idx" ON "grade_attributes"("kind");
CREATE INDEX "grades_categoryId_idx" ON "grades"("categoryId");
CREATE INDEX "_GradeToGradeAttribute_B_index" ON "_GradeToGradeAttribute"("B");
ALTER TABLE "categories" ADD CONSTRAINT "categories_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES "categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "grades" ADD CONSTRAINT "grades_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "categories"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "_GradeToGradeAttribute" ADD CONSTRAINT "_GradeToGradeAttribute_A_fkey" FOREIGN KEY ("A") REFERENCES "grades"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "_GradeToGradeAttribute" ADD CONSTRAINT "_GradeToGradeAttribute_B_fkey" FOREIGN KEY ("B") REFERENCES "grade_attributes"("id") ON DELETE CASCADE ON UPDATE CASCADE;
