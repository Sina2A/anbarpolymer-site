// src/components/ArticleEditor.tsx
//
// ادیتور متن غنی TipTap برای مقالات — Headless با toolbar سفارشی

'use client'

import { useEditor, EditorContent } from '@tiptap/react'
import StarterKit from '@tiptap/starter-kit'
import Link from '@tiptap/extension-link'
import Image from '@tiptap/extension-image'
import { useEffect, useState } from 'react'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import type { CSSProperties } from 'react'

type Props = {
  initialContent?: string
  name?: string
  maxLength?: number
}

export default function ArticleEditor({
  initialContent = '',
  name = 'content',
  maxLength = 50000
}: Props) {
  const [htmlContent, setHtmlContent] = useState(initialContent)

  const editor = useEditor({
    extensions: [
      StarterKit,
      Link.configure({
        openOnClick: false,
        HTMLAttributes: {
          rel: 'noopener noreferrer',
          target: '_blank',
        },
      }),
      Image.configure({
        HTMLAttributes: {
          style: 'max-width: 100%; height: auto; border-radius: 8px; margin: 20px 0;',
        },
      }),
    ],
    content: initialContent,
    onUpdate: ({ editor }) => {
      const html = editor.getHTML()
      setHtmlContent(html)
    },
  })

  // Sync initial content when editor is ready
  useEffect(() => {
    if (editor && initialContent && editor.getHTML() !== initialContent) {
      editor.commands.setContent(initialContent)
    }
  }, [editor, initialContent])

  if (!editor) {
    return <div style={loadingStyle}>در حال بارگذاری ادیتور...</div>
  }

  const addLink = () => {
    const url = prompt('آدرس لینک:')
    if (url) {
      editor.chain().focus().setLink({ href: url }).run()
    }
  }

  const addImage = () => {
    const url = prompt('آدرس تصویر (URL):')
    if (url) {
      editor.chain().focus().setImage({ src: url }).run()
    }
  }

  const charCount = editor.getText().length

  return (
    <div style={containerStyle}>
      {/* Toolbar */}
      <div style={toolbarStyle}>
        <button
          type="button"
          className="editor-toolbar-btn"
          onClick={() => editor.chain().focus().toggleBold().run()}
          style={editor.isActive('bold') ? activeButtonStyle : buttonStyle}
          title="بولد (Ctrl+B)"
        >
          <b>B</b>
        </button>

        <button
          type="button"
          className="editor-toolbar-btn"
          onClick={() => editor.chain().focus().toggleItalic().run()}
          style={editor.isActive('italic') ? activeButtonStyle : buttonStyle}
          title="ایتالیک (Ctrl+I)"
        >
          <i>I</i>
        </button>

        <div style={separatorStyle} />

        <button
          type="button"
          className="editor-toolbar-btn"
          onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
          style={editor.isActive('heading', { level: 2 }) ? activeButtonStyle : buttonStyle}
          title="هدینگ 2"
        >
          H2
        </button>

        <button
          type="button"
          className="editor-toolbar-btn"
          onClick={() => editor.chain().focus().toggleHeading({ level: 3 }).run()}
          style={editor.isActive('heading', { level: 3 }) ? activeButtonStyle : buttonStyle}
          title="هدینگ 3"
        >
          H3
        </button>

        <div style={separatorStyle} />

        <button
          type="button"
          className="editor-toolbar-btn"
          onClick={() => editor.chain().focus().toggleBulletList().run()}
          style={editor.isActive('bulletList') ? activeButtonStyle : buttonStyle}
          title="لیست نقطه‌ای"
        >
          •
        </button>

        <button
          type="button"
          className="editor-toolbar-btn"
          onClick={() => editor.chain().focus().toggleOrderedList().run()}
          style={editor.isActive('orderedList') ? activeButtonStyle : buttonStyle}
          title="لیست شماره‌دار"
        >
          1.
        </button>

        <div style={separatorStyle} />

        <button
          type="button"
          className="editor-toolbar-btn"
          onClick={addLink}
          style={editor.isActive('link') ? activeButtonStyle : buttonStyle}
          title="لینک"
        >
          🔗
        </button>

        <button
          type="button"
          className="editor-toolbar-btn"
          onClick={addImage}
          style={buttonStyle}
          title="تصویر"
        >
          🖼️
        </button>

        <button
          type="button"
          className="editor-toolbar-btn"
          onClick={() => editor.chain().focus().setHorizontalRule().run()}
          style={buttonStyle}
          title="خط افقی"
        >
          ―
        </button>

        <div style={separatorStyle} />

        <button
          type="button"
          className="editor-toolbar-btn"
          onClick={() => editor.chain().focus().undo().run()}
          disabled={!editor.can().undo()}
          style={buttonStyle}
          title="Undo (Ctrl+Z)"
        >
          ↶
        </button>

        <button
          type="button"
          className="editor-toolbar-btn"
          onClick={() => editor.chain().focus().redo().run()}
          disabled={!editor.can().redo()}
          style={buttonStyle}
          title="Redo (Ctrl+Shift+Z)"
        >
          ↷
        </button>

        <div style={{ flex: 1 }} />

        <span style={charCountStyle}>
          {charCount} / {maxLength.toLocaleString('fa-IR')}
        </span>
      </div>

      {/* Editor */}
      <EditorContent editor={editor} style={editorStyle} />

      {/* Hidden input for form submission */}
      <input type="hidden" name={name} value={htmlContent} required />
    </div>
  )
}

// ── استایل‌ها ─────────────────────────────────────────────────────────────

const containerStyle: CSSProperties = {
  width: '100%',
}

const toolbarStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 4,
  background: colors.bgCard,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.md,
  padding: spacing.sm,
  marginBottom: 2,
  flexWrap: 'wrap',
}

const buttonStyle: CSSProperties = {
  background: 'transparent',
  border: 'none',
  color: colors.textSecondary,
  fontSize: fontSize.md,
  padding: '6px 10px',
  borderRadius: radius.sm,
  cursor: 'pointer',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  fontWeight: 600,
  transition: 'background 0.15s',
}

const activeButtonStyle: CSSProperties = {
  ...buttonStyle,
  background: colors.navy,
  color: '#fff',
}

const separatorStyle: CSSProperties = {
  width: 1,
  height: 20,
  background: colors.borderSubtle,
  margin: '0 4px',
}

const charCountStyle: CSSProperties = {
  fontSize: fontSize.xs,
  color: colors.textMuted,
  fontFamily: 'monospace',
  direction: 'ltr',
}

const editorStyle: CSSProperties = {
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.md,
  minHeight: 300,
  padding: spacing.lg,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  fontSize: fontSize.base,
  lineHeight: 1.8,
  background: colors.bgCard,
}

const loadingStyle: CSSProperties = {
  padding: spacing.xl,
  textAlign: 'center',
  color: colors.textMuted,
  fontSize: fontSize.sm,
}
