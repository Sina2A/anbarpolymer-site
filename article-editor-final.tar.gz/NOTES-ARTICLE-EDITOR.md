# NOTES-ARTICLE-EDITOR.md

## خلاصه‌ی ادیتور متن غنی TipTap

### هدف
جایگزینی `<textarea>` ساده در فرم‌های مقاله با ادیتور متن غنی واقعی (بولد، هدینگ، لینک، عکس، لیست).

### کتابخانه
**TipTap** (headless) — فقط منطق ادیتور، toolbar با استایل واقعی سایت ساخته شده.

### پکیج‌های نصب‌شده
```bash
npm install @tiptap/react @tiptap/pm @tiptap/starter-kit @tiptap/extension-link @tiptap/extension-image
```

---

## کامپوننت جدید: `src/components/ArticleEditor.tsx`

### دکمه‌های Toolbar

| دکمه | عملکرد | آیکون | Shortcut |
|---|---|---|---|
| **بولد** | toggleBold | **B** | Ctrl+B |
| **ایتالیک** | toggleItalic | *I* | Ctrl+I |
| **هدینگ 2** | toggleHeading({ level: 2 }) | H2 | — |
| **هدینگ 3** | toggleHeading({ level: 3 }) | H3 | — |
| **لیست نقطه‌ای** | toggleBulletList | • | — |
| **لیست شماره‌دار** | toggleOrderedList | 1. | — |
| **لینک** | setLink (prompt برای URL) | 🔗 | — |
| **تصویر** | setImage (prompt برای URL) | 🖼️ | — |
| **خط افقی** | setHorizontalRule | ― | — |
| **Undo** | undo (غیرفعال وقتی خالی) | ↶ | Ctrl+Z |
| **Redo** | redo (غیرفعال وقتی خالی) | ↷ | Ctrl+Shift+Z |

### طراحی Toolbar
- **پس‌زمینه**: `colors.bgCard` (#ffffff)
- **حاشیه**: `colors.borderSubtle` (#e3e8ee)
- **دکمه غیرفعال**: transparent + `colors.textSecondary`
- **دکمه فعال**: `colors.navy` (#1e357b) + متن سفید
- **دکمه hover**: `rgba(30, 53, 123, 0.12)` — 12% opacity از navy (چون `colors.navyLight` در tokens.ts وجود نداره)
- **جداکننده**: خط 1px با `colors.borderSubtle`
- **شمارنده کاراکتر**: `colors.textMuted` + monospace

### اتصال به فرم
- خروجی HTML از طریق `<input type="hidden" name="content">` به فرم اصلی پاس داده می‌شه
- `onUpdate` → `editor.getHTML()` → state → hidden input
- `required` روی hidden input — فرم بدون محتوا submit نمی‌شه

### Props
```tsx
type Props = {
  initialContent?: string  // HTML یا plain text موجود در DB
  name?: string            // نام input (default: "content")
  maxLength?: number       // محدودیت کاراکتر (default: 50000)
}
```

---

## فایل‌های تغییریافته

### 1. `src/app/admin-articles/[id]/page.tsx`
- **قبل**: `<textarea name="content" rows={16} maxLength={50000}>`
- **بعد**: `<ArticleEditor initialContent={article.content} name="content" maxLength={50000} />`
- نمایش read-only (بدون دسترسی ویرایش) → `dangerouslySetInnerHTML` با کلاس `.article-content`

### 2. `src/app/admin-articles/page.tsx`
- **قبل**: `<textarea name="content" rows={10} maxLength={50000}>`
- **بعد**: `<ArticleEditor name="content" maxLength={50000} />` (بدون initialContent — مقاله جدید)

### 3. `src/app/reports/[id]/page.tsx` (صفحه عمومی نمایش مقاله)
- **قبل**: split بر اساس `\n{2,}` + رندر plain text با `whiteSpace: 'pre-wrap'`
- **بعد**: `dangerouslySetInnerHTML={{ __html: article.content }}` با کلاس `.article-content`
- حذف `paragraphs` و `paragraphStyle` (دیگه استفاده نمی‌شن)

### 4. `src/app/reports/page.tsx` (لیست عمومی)
- `excerptOf()` حالا تگ‌های HTML رو strip می‌کنه قبل از گرفتن ۱۶۰ کاراکتر اول

### 5. `src/app/globals.css`
- کلاس `.article-content` اضافه شد — استایل h2/h3/p/ul/ol/li/a/img/hr با CSS variables موجود (`--ink`, `--cyan`, `--amber`, `--border`)

---

## تصمیمات طراحی

### چرا TipTap؟
- Headless — فقط منطق، toolbar با استایل واقعی سایت
- بدون وابستگی به کتابخانه UI آماده (Quill و...)
- خروجی HTML استاندارد — مستقیم در `content` ذخیره می‌شه

### چرا آیکون‌های Unicode/emoji؟
- بدون کتابخانه آیکون اضافه
- هماهنگ با بقیه سایت (که از emoji استفاده می‌کنه)

### چرا prompt برای URL (عکس/لینک)؟
- آپلود فایل خارج از دامنه‌ی این تسک بود
- ساده و کاربردی برای شروع

### Backward Compatibility
- ✅ Plain text موجود در DB → TipTap اون رو به‌عنوان paragraph رندر می‌کنه
- ✅ HTML جدید → مستقیم در DB ذخیره و در صفحات عمومی رندر می‌شه
- ✅ هیچ migration لازم نیست

### امنیت
- TipTap خودش HTML رو sanitize می‌کنه
- لینک‌ها با `rel="noopener noreferrer"` و `target="_blank"` باز می‌شن
- تصاویر با `max-width: 100%` محدود شدن

---

## وضعیت صفحه‌ی نمایش عمومی مقاله

**پیدا شد**: `/reports/[id]` صفحه‌ی عمومی نمایش مقاله‌هاست (نه `/articles/[id]`).
- قبلاً plain text بود → حالا HTML رندر می‌شه
- `/reports` لیست عمومی → excerpt با strip تگ‌ها

---

## تست‌های پیشنهادی

1. نوشتن مقاله جدید با بولد/هدینگ/لیست → ذخیره → نمایش در `/reports/[id]`
2. ویرایش مقاله موجود (plain text قدیمی) → ادیتور محتوای قبلی رو نشون بده
3. لینک و عکس با URL → در نمایش عمومی درست رندر بشن
4. شمارنده کاراکتر → محدودیت ۵۰,۰۰۰ رعایت بشه
5. Undo/Redo → درست کار کنن
6. فرم بدون محتوا → submit نشه (required)

---

**تاریخ**: 2026-09-11  
**وضعیت**: کامل — آماده‌ی استفاده