# رفع ریشه‌ای — چیدمان موبایل (۴ صفحه) + Overflow جدول

## نتیجه‌ی بررسی فرضیه‌ها (به ترتیب)

| # | فرضیه | نتیجه |
|---|---|---|
| ۱ | `globals.css` روی سرور قدیمی است | **رد.** قوانین موبایل در CSS هستند و Chromium آن‌ها را parse می‌کند (پایین را ببینید). حتی اگر CSS کاملاً درست سرو شود، این باگ رخ می‌دهد، چون مشکل در CSS نیست. |
| ۲ | براکت ناقص/اضافه در `globals.css` | **رد.** کل فایل با parser خودِ Chromium (`CSSStyleSheet.replaceSync`) خوانده شد: ۷۴۰ قانون سطح‌بالا، آخرین قانون فایل هم سالم parse شد. `.contact-grid` و `.wh-layout` داخل `(max-width: 899px)` حاضرند. تراز براکت‌ها: ۰، هیچ‌جا منفی نمی‌شود. |
| ۳ | breakpoint ناهماهنگ (۸۹۹ در برابر ۹۰۰) | **رد.** تست در عرض ۳۹۰px انجام شد که خیلی زیر هر دو عدد است، و باز هم همان علامت دیده شد. |
| ۴ | تغییر سراسری امروز (`overflow-x:clip`) روی `/about` اثر گذاشته | **رد.** این گارد فقط محتوای بیرون‌زده را می‌بُرد و در Overflow جدول نقش داشت (پایین را ببینید). علت `/about` چیز دیگری است. |

## علت ریشه‌ای ۱: `pageWrapStyle` برای `/contact`، `/warehouses` و `/warehouses/[id]`

`src/lib/styles/shared.ts`:
```ts
export const pageWrapStyle = { maxWidth: 1200, margin: '0 auto', display: 'flex', gap: spacing.xl }
```
این استایل برای چیدمان «سایدبار + محتوا» ساخته شده و `display:flex` ردیفی دارد. `mainStyle` این سه صفحه با `...pageWrapStyle` شروع می‌شود، پس **هیرو و بدنه دو آیتمِ فلکسِ کنار هم** می‌شوند. این در همه‌ی عرض‌ها رخ می‌دهد و ربطی به media query ندارد. به همین دلیل تک‌ستون‌کردن `.contact-grid` و `.wh-layout` هیچ اثری نداشت: خودِ گرید درست تک‌ستون می‌شد، اما کنار هیرو و در یک ستونِ ۱۴۰ پیکسلی.
این مشکل از زمان بازطراحی این صفحه‌ها وجود داشته و تغییرهای امروز آن را ایجاد نکرده‌اند.

**رفع:** در `mainStyle` این سه صفحه `display:'block'` و `width:'100%'` اضافه شد. خودِ `shared.ts` تغییر نکرد، چون صفحه‌های ادمین (`admin-warehouses`، `admin-kyc`، `verification`) به همان حالت فلکسی نیاز دارند.

## علت ریشه‌ای ۲: `/about` با گریدهای inline

در `about/page.tsx` چهار گرید ستون‌هایشان را inline تعریف کرده‌اند: `problemGridStyle` با `1fr 1.15fr` (کارت سرمه‌ای کنار کارت روشن)، `valuesGridStyle` با `repeat(4,1fr)`، `processTrackStyle` با `repeat(6,1fr)` و `principlesGridStyle` با `repeat(3,1fr)`.
استایل inline به media query جواب نمی‌دهد، پس این صفحه **هیچ‌وقت** در موبایل تک‌ستون نمی‌شد. هیچ تغییر امروزی این را ایجاد نکرده؛ یک مشکل قدیمی است که تازه دیده شد.

**رفع:** `gridTemplateColumns` از استایل inline حذف شد و به کلاس‌های `.about-problem-grid`، `.about-values-grid`، `.about-process-track` و `.about-principles-grid` در `globals.css` منتقل شد. ستون‌ها در دسکتاپ مثل قبل هستند و زیر ۸۹۹px و ۴۸۰px کم می‌شوند.

## علت ریشه‌ای ۳: Overflow جدول در `/warehouses/[id]`

ظرف `overflowX:'auto'` از قبل وجود داشت، اما کار نمی‌کرد:
- `main` فرزندِ فلکسِ ستونیِ `pageStyle` است، و `margin:'0 auto'` (از `pageWrapStyle`) کشیدگی‌اش را خاموش می‌کند. در نتیجه عرض main به‌جای عرض صفحه، به اندازه‌ی محتوا (جدول) می‌رسید: عرض ۵۴۲px با `left` برابر ‎-152px روی صفحه‌ی ۳۹۰px.
- ظرف جدول هم به همان اندازه پهن می‌شد، پس اسکرولی لازم نبود (`scrollWidth == clientWidth`).
- `html,body{overflow-x:clip}` هم بخش بیرون‌زده را بدون اسکرول می‌بُرد. ستون «خانواده پلیمری» به همین دلیل بریده می‌شد.

**رفع:** `width:'100%'` روی main گذاشته شد، و ظرف جدول کلاس `.table-scroll` و `maxWidth:'100%'` گرفت.

## تأیید (با رندر واقعی، نه grep)

خودِ `page.tsx`ها با React SSR (`renderToStaticMarkup`) رندر شدند، همراه با `globals.css` و `tokens`/`shared` واقعی. Prisma و هدر و فوتر stub شدند. بعد نتیجه در Chromium با عرض ۳۹۰px اندازه‌گیری شد:

| صفحه | قبل | بعد |
|---|---|---|
| `/contact` | هیرو و گرید کنار هم؛ فرم ۹۰px عرض | زیر هم؛ فرم ۲۹۲px؛ دکمه‌ی «راه‌های تماس» دیده می‌شود |
| `/warehouses` | هیرو ۲۰۰px کنار بدنه‌ی ۱۱۸px | زیر هم، هر دو ۳۴۲px |
| `/about` | ستون‌های گرید مسئله/راه‌حل: `150px 172px` (کنار هم) | `342px` (زیر هم) |
| `/warehouses/[id]` | عرض main ۵۴۲px، ظرف جدول اسکرول ندارد | عرض main ۳۹۰px، ظرف ۳۴۲px و اسکرول‌پذیر |

## فایل‌های این بسته
- `src/app/contact/page.tsx`: ✏️ `mainStyle`
- `src/app/warehouses/page.tsx`: ✏️ `mainStyle`
- `src/app/warehouses/[id]/page.tsx`: ✏️ `mainStyle` و ظرف جدول
- `src/app/about/page.tsx`: ✏️ `className` روی ۴ گرید و حذف `gridTemplateColumns` inline
- `src/app/globals.css`: ✏️ بلوک `/about` در انتهای فایل. این نسخه روی بسته‌ی `fix-map404-contactdisclosure` بنا شده است.

## نصب
```bash
tar -xzf fix-mobile-layout-root.tar.gz
grep -n "display: 'block'" src/app/contact/page.tsx src/app/warehouses/page.tsx "src/app/warehouses/[id]/page.tsx"   # سه خروجی
grep -c "about-problem-grid" src/app/globals.css src/app/about/page.tsx                                             # هر دو ≥۱
npm run build
# ری‌استارت هر سه سطح
```
