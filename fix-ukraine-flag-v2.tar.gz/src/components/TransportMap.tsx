'use client'

import { useEffect, useState } from 'react'
import dynamic from 'next/dynamic'
import { colors, radius, fontSize, shadow } from '@/lib/styles/tokens'

// Leaflet فقط در کلاینت کار می‌کنه — SSR ندارد
const MapContainer = dynamic(() => import('react-leaflet').then((m) => m.MapContainer), { ssr: false })
const TileLayer = dynamic(() => import('react-leaflet').then((m) => m.TileLayer), { ssr: false })
const Marker = dynamic(() => import('react-leaflet').then((m) => m.Marker), { ssr: false })
const Popup = dynamic(() => import('react-leaflet').then((m) => m.Popup), { ssr: false })
// کنترلِ Attribution دستی با prefix=false → حذفِ برند/پرچمِ پیش‌فرضِ Leaflet، بدون حذفِ متنِ منبع (© OpenStreetMap).
const AttributionControl = dynamic(() => import('react-leaflet').then((m) => m.AttributionControl), { ssr: false })

type Deal = {
  id: string
  quantity: string
  currentLatitude: number | null
  currentLongitude: number | null
  locationUpdatedAt: Date | null
  materialListing: {
    grade: {
      code: string
    }
  } | null
  confirmations: Array<{
    driverName: string | null
    vehiclePlate: string | null
  }>
}

export default function TransportMap({ deals }: { deals: Deal[] }) {
  const [mounted, setMounted] = useState(false)
  const [mapOpen, setMapOpen] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return <div style={loadingStyle}>در حال بارگذاری نقشه...</div>
  }

  // فیلتر Deal هایی که موقعیت دارن
  const dealsWithLocation = deals.filter((d) => d.currentLatitude && d.currentLongitude)

  if (dealsWithLocation.length === 0) {
    return (
      <div style={cardStyle}>
        <div style={{ fontSize: fontSize.md, color: colors.textMuted, textAlign: 'center', padding: 20 }}>
          هیچ محموله‌ای با موقعیت فعال وجود ندارد.
          <div style={{ fontSize: 12, marginTop: 8 }}>
            (موقعیت زمانی ثبت می‌شود که راننده صفحه‌ی تایید بارگیری را باز داشته باشد)
          </div>
        </div>
      </div>
    )
  }

  // مرکز نقشه — میانگین موقعیت‌ها
  const centerLat = dealsWithLocation.reduce((sum, d) => sum + (d.currentLatitude ?? 0), 0) / dealsWithLocation.length
  const centerLng = dealsWithLocation.reduce((sum, d) => sum + (d.currentLongitude ?? 0), 0) / dealsWithLocation.length

  return (
    <div>
      {/* کارت‌های اصلی معاملات — محور اصلی صفحه */}
      <div style={{ marginBottom: 14 }}>
        <div style={{ fontSize: fontSize.md, fontWeight: 700, marginBottom: 12 }}>محموله‌های فعال</div>
        {dealsWithLocation.map((deal) => (
          <div key={deal.id} style={dealCardStyle}>
            <div style={{ fontSize: 15, fontWeight: 700, marginBottom: 8, color: colors.navy }}>
              {deal.materialListing?.grade.code ?? 'محموله'}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 10, marginBottom: 8 }}>
              <div>
                <div style={{ fontSize: fontSize.xs, color: '#6b7280', marginBottom: 2 }}>مقدار</div>
                <div style={{ fontSize: fontSize.base, fontWeight: 700 }}>{deal.quantity}</div>
              </div>
              {deal.confirmations[0]?.driverName && (
                <div>
                  <div style={{ fontSize: fontSize.xs, color: '#6b7280', marginBottom: 2 }}>راننده</div>
                  <div style={{ fontSize: fontSize.base, fontWeight: 600 }}>{deal.confirmations[0].driverName}</div>
                </div>
              )}
              {deal.confirmations[0]?.vehiclePlate && (
                <div>
                  <div style={{ fontSize: fontSize.xs, color: '#6b7280', marginBottom: 2 }}>پلاک خودرو</div>
                  <div style={{ fontSize: fontSize.base, fontWeight: 600, fontFamily: 'monospace' }}>
                    {deal.confirmations[0].vehiclePlate}
                  </div>
                </div>
              )}
            </div>
            {deal.locationUpdatedAt && (
              <div style={{ fontSize: fontSize.xs, color: colors.textMuted, marginTop: 6 }}>
                آخرین به‌روزرسانی موقعیت: {new Date(deal.locationUpdatedAt).toLocaleString('fa-IR')}
              </div>
            )}
            <div style={{ marginTop: 10, paddingTop: 10, borderTop: '1px solid #f1efe8' }}>
              <span style={statusBadge}>در مسیر</span>
            </div>
          </div>
        ))}
      </div>

      {/* نقشه — ویجت جمع‌شونده زیر کارت‌ها */}
      <details style={detailsStyle} open={mapOpen} onToggle={(e) => setMapOpen((e.target as HTMLDetailsElement).open)}>
        <summary style={summaryStyle}>
          🗺️ نمایش نقشه موقعیت زنده
          <span style={{ fontSize: fontSize.xs, color: colors.textMuted, fontWeight: 400, marginRight: 8 }}>
            (کلیک برای {mapOpen ? 'بستن' : 'باز کردن'})
          </span>
        </summary>
        <div style={mapWrapperStyle}>
          <MapContainer
            center={[centerLat, centerLng]}
            zoom={dealsWithLocation.length === 1 ? 13 : 10}
            style={{ width: '100%', height: '100%' }}
            attributionControl={false}
          >
            <AttributionControl prefix={false} />
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            {dealsWithLocation.map((deal) => (
              <Marker key={deal.id} position={[deal.currentLatitude!, deal.currentLongitude!]}>
                <Popup>
                  <div style={{ fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', fontSize: 12 }}>
                    <div style={{ fontWeight: 700, marginBottom: 4 }}>
                      {deal.materialListing?.grade.code ?? 'محموله'}
                    </div>
                    <div style={{ fontSize: fontSize.xs, color: '#6b7280' }}>
                      مقدار: {deal.quantity}
                    </div>
                    {deal.confirmations[0]?.driverName && (
                      <div style={{ fontSize: fontSize.xs, color: '#6b7280', marginTop: 4 }}>
                        راننده: {deal.confirmations[0].driverName}
                      </div>
                    )}
                    {deal.confirmations[0]?.vehiclePlate && (
                      <div style={{ fontSize: fontSize.xs, color: '#6b7280' }}>
                        پلاک: {deal.confirmations[0].vehiclePlate}
                      </div>
                    )}
                    {deal.locationUpdatedAt && (
                      <div style={{ fontSize: 10, color: colors.textMuted, marginTop: 6, fontStyle: 'italic' }}>
                        آخرین به‌روزرسانی: {new Date(deal.locationUpdatedAt).toLocaleString('fa-IR')}
                      </div>
                    )}
                  </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>
          <div style={{ fontSize: fontSize.xs, color: colors.textMuted, marginTop: 10, padding: '8px 10px', background: '#fef3c7', borderRadius: radius.sm }}>
            ⓘ موقعیت فقط زمانی به‌روز می‌شود که مرورگر راننده باز و صفحه فعال باشد (تب پس‌زمینه یا قفل گوشی، ارسال را متوقف می‌کند).
          </div>
        </div>
      </details>
    </div>
  )
}

const dealCardStyle: React.CSSProperties = {
  border: `1px solid ${colors.borderStrong}`,
  borderRadius: radius.lg,
  padding: 18,
  marginBottom: 12,
  background: colors.bgCard,
  boxShadow: shadow.card,
}
const statusBadge: React.CSSProperties = {
  fontSize: 10,
  fontWeight: 700,
  background: '#fef3c7',
  color: colors.warningText,
  borderRadius: radius.sm,
  padding: '4px 10px',
  display: 'inline-block',
}
const detailsStyle: React.CSSProperties = {
  border: `1px solid ${colors.borderStrong}`,
  borderRadius: radius.lg,
  background: colors.bgCard,
  boxShadow: shadow.card,
  overflow: 'hidden',
}
const summaryStyle: React.CSSProperties = {
  padding: '14px 18px',
  fontSize: fontSize.base,
  fontWeight: 700,
  color: colors.navy,
  cursor: 'pointer',
  userSelect: 'none',
  background: '#fbf9f5',
  borderBottom: '1px solid #e8e4db',
}
const mapWrapperStyle: React.CSSProperties = {
  padding: 14,
  minHeight: 450,
}
const loadingStyle: React.CSSProperties = {
  padding: 40,
  textAlign: 'center',
  fontSize: fontSize.base,
  color: colors.textMuted,
  border: `1px solid ${colors.borderStrong}`,
  borderRadius: radius.lg,
  background: colors.bgCard,
}
const cardStyle: React.CSSProperties = {
  border: `1px solid ${colors.borderStrong}`,
  borderRadius: radius.lg,
  background: colors.bgCard,
  boxShadow: shadow.card,
}
