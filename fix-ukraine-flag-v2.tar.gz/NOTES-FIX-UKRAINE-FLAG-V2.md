# NOTES — رفع قطعیِ پرچمِ اوکراین (خاموش‌کردنِ prefix از منبع، نه فقط CSS)

## چرا رفعِ قبلی (CSS) کافی نبود
تحویلِ قبلی فقط یک قانونِ CSS داشت: `.leaflet-attribution-flag{display:none !important}`.
اما این کلاس روی یک `<svg>`ِ **inline** است که Leaflet آن را داخلِ رشته‌ی `prefix` تولید می‌کند:

```js
// node_modules/leaflet/dist/leaflet-src.js — options پیش‌فرضِ Control.Attribution
prefix: '<a href="https://leafletjs.com" ...>'
        + (Browser.inlineSvg ? ukrainianFlag + ' ' : '')   // ← SVGِ پرچم اینجاست
        + 'Leaflet</a>'
```
پرچم بخشی از **prefixِ پیش‌فرضِ کنترلِ Attribution** است (برندِ «Leaflet»)، نه لایه‌ی کاشی.
تکیه‌ی صرف به CSS شکننده است؛ راهِ قطعی، خاموش‌کردنِ خودِ prefix از منبع است.

## یافته‌ی فنی (از سورسِ نصب‌شده)
- `react-leaflet@5.0.0` → `AttributionControl` را export می‌کند
  (`node_modules/react-leaflet/lib/AttributionControl.js` مستقیماً `new Control.Attribution(props)`).
- امضای props: `Control.AttributionOptions` — شاملِ `prefix: String | false`.
- سورسِ Leaflet: `// @option prefix: String|false = 'Leaflet'` → دادنِ `false` کلِ برند/پرچم را حذف می‌کند.
- **متنِ منبع (© OpenStreetMap) از `attribution`ِ خودِ `TileLayer` می‌آید و جدا از prefix است**،
  پس با `prefix={false}` دست‌نخورده باقی می‌ماند (الزامِ قانونی رعایت می‌شود).

## راه‌حل (گزینه‌ی الفِ مستند — قطعی)
روی هر سه `<MapContainer>`:
1. `attributionControl={false}` → خاموش‌کردنِ کنترلِ پیش‌فرض (که prefixِ برنددارِ Leaflet را می‌آورد).
2. افزودنِ `<AttributionControl prefix={false} />` → کنترلِ دستی که **فقط** متنِ `attribution`ِ لایه‌ها
   (© OpenStreetMap) را نشان می‌دهد، بدون هیچ برند/پرچمِ Leaflet.

چرا این‌بار قطعی است: پرچم دیگر اصلاً در DOM **تولید نمی‌شود** (نه اینکه با CSS پنهان شود).
مستقل از `Browser.inlineSvg`، کش، یا نحوه‌ی پردازشِ CSS در build.

## تغییرات
### `src/components/WarehousesMap.tsx`
- افزودنِ `AttributionControl` به import‌های dynamic (ssr:false).
- `attributionControl={false}` روی `MapContainer` + `<AttributionControl prefix={false} />`.

### `src/components/LocationPickerMap.tsx`
- افزودنِ `AttributionControl` به importِ static موجودِ `react-leaflet`.
- `attributionControl={false}` روی `MapContainer` + `<AttributionControl prefix={false} />`.

### `src/components/TransportMap.tsx`
- افزودنِ `AttributionControl` به import‌های dynamic (ssr:false).
- `attributionControl={false}` روی `MapContainer` + `<AttributionControl prefix={false} />`.

### `src/app/globals.css` — بدون تغییر (لایه‌ی ایمنی)
قانونِ `.leaflet-attribution-flag{display:none !important}` عمداً نگه داشته شد (بی‌ضرر،
دفاعِ لایه‌ای). چون هیچ فایلِ CSS تغییر نکرد، در این بسته گنجانده نشده — از تحویلِ قبلی باقی است.

## راستی‌آزمایی (اجراشده)
- `npx tsc --noEmit` → **EXIT 0**
- `npx next build` → **EXIT 0**
- تاییدِ منبع: `prefix: '...'+(Browser.inlineSvg?ukrainianFlag+' ':'')+'Leaflet</a>'` در leaflet-src.js —
  با `prefix={false}` این کلاً تولید نمی‌شود.
- متنِ © OpenStreetMap از `TileLayer.attribution` می‌آید و حفظ می‌شود.

---

## محتوای این بسته
```
NOTES-FIX-UKRAINE-FLAG-V2.md          (همین فایل)
src/components/WarehousesMap.tsx       (attributionControl=false + AttributionControl prefix=false)
src/components/LocationPickerMap.tsx   (همان)
src/components/TransportMap.tsx        (همان)
```

## نحوه‌ی اعمال روی مخزن
```bash
tar -xzf fix-ukraine-flag-v2.tar.gz
npx tsc --noEmit
npx next build
```
> پیش‌نیاز: بسته‌های revert-to-leaflet و fix-blank-leaflet-map قبلاً اعمال شده باشند.
> قانونِ CSSِ ایمنیِ `.leaflet-attribution-flag` از تحویلِ قبلی در globals.css باقی می‌ماند.
