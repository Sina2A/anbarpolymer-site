/**
 * اسکریپت ساخت حساب مدیر — یه‌بار اجرا می‌شه.
 * چون نیازی به TypeScript/build نداره، مستقیم با node قابل‌اجراست:
 *
 *   node scripts/seed-admin.js
 *
 * رمز عبور دقیقاً با همون الگوریتمی هش می‌شه که src/lib/auth.ts استفاده می‌کنه
 * (Node.js scrypt، بدون هیچ پکیج بیرونی) — تا با فرم ورود واقعی سازگار باشه.
 */
const crypto = require('crypto')
const { PrismaClient } = require('@prisma/client')
const { PrismaPg } = require('@prisma/adapter-pg')

const USERNAME = 'SinaAbouei'
const PASSWORD = '404696417SKj'
const COMPANY_NAME = 'سینا ابویی'

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex')
  const derivedKey = crypto.scryptSync(password, salt, 64)
  return `${salt}:${derivedKey.toString('hex')}`
}

async function main() {
  const adapter = new PrismaPg({ connectionString: process.env.DATABASE_URL })
  const prisma = new PrismaClient({ adapter })

  const existing = await prisma.user.findUnique({ where: { username: USERNAME } })
  if (existing) {
    console.log(`کاربر «${USERNAME}» از قبل وجود داره — چیزی تغییر نکرد.`)
    console.log('اگه می‌خوای رمزش رو عوض کنی، این رکورد رو از دیتابیس پاک کن و دوباره این اسکریپت رو بزن.')
    await prisma.$disconnect()
    return
  }

  const existingAdmin = await prisma.user.findFirst({ where: { role: 'admin', isActive: true } })
  if (existingAdmin) {
    console.log(`⚠️ یه مدیر فعال دیگه («${existingAdmin.companyName}») از قبل هست.`)
    console.log('طبق قانون تک‌مدیر، این حساب رو با نقش «کارشناس» می‌سازیم، نه «مدیر».')
  }

  const user = await prisma.user.create({
    data: {
      username: USERNAME,
      companyName: COMPANY_NAME,
      passwordHash: hashPassword(PASSWORD),
      role: existingAdmin ? 'staff' : 'admin',
      isActive: true,
    },
  })

  console.log('✓ حساب ساخته شد:')
  console.log('  نام کاربری:', user.username)
  console.log('  نقش:', user.role === 'admin' ? 'مدیر' : 'کارشناس')
  console.log('')
  console.log('حالا می‌تونی از /login وارد بشی.')

  await prisma.$disconnect()
}

main().catch((e) => {
  console.error('خطا در ساخت حساب:', e)
  process.exit(1)
})
