'use server'

import prisma from '@/lib/prisma'
import { verifyPassword, createSession } from '@/lib/auth'
import { redirect } from 'next/navigation'

export async function loginAction(prevState: { error: string | null }, formData: FormData) {
  const identifier = String(formData.get('identifier') || '').trim()
  const password = String(formData.get('password') || '')

  if (!identifier || !password) {
    return { error: 'نام کاربری/شماره تماس و رمز عبور رو وارد کن.' }
  }

  // کاربر می‌تونه با username (کارشناس/مدیر) یا phone (خریدار) وارد بشه
  const user = await prisma.user.findFirst({
    where: { OR: [{ username: identifier }, { phone: identifier }] },
  })

  if (!user || !user.isActive) {
    return { error: 'نام کاربری یا رمز عبور اشتباهه.' }
  }

  const passwordOk = verifyPassword(password, user.passwordHash)
  if (!passwordOk) {
    return { error: 'نام کاربری یا رمز عبور اشتباهه.' }
  }

  await createSession(user.id)
  redirect(user.role === 'buyer' ? '/dashboard' : '/admin-users')
}
