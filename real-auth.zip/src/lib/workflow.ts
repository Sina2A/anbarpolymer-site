// نقشه‌ی دقیق مراحل مجاز برای هر نوع رکورد.
// هدف: فیلد «مرحله بعد» هیچ‌وقت گمراه‌کننده نباشه — اگه چند مسیر ممکنه،
// به‌جای حدس زدن، پیام خنثی «منتظر وضعیت جاری» نشون داده می‌شه.

export type RecordType = 'Order' | 'MaterialListing' | 'SupportTicket'

export const AWAITING_CURRENT = 'AWAITING_CURRENT'

interface StageDef {
  key: string
  label: string // برچسب فارسی قابل‌نمایش برای کارشناس (فعل حال، مثل "در حال ...")
  possibleNext: string[] // کلید مراحل بعدی ممکن؛ اگه بیش از یکی بود، فیلد بعد مبهم می‌مونه
  responsibleSection: string | null // کدوم بخش پنل مسئول اقدام روی این مرحله‌ست؛ null یعنی مرحله‌ی پایانی، کاری لازم نیست
}

const ORDER_STAGES: StageDef[] = [
  { key: 'pending', label: 'در حال ثبت اولیه توسط مشتری', possibleNext: ['priced'], responsibleSection: 'orders' },
  { key: 'priced', label: 'در حال تعیین قیمت توسط کارشناس فروش', possibleNext: ['buyer_confirmed', 'pending'], responsibleSection: 'orders' },
  { key: 'buyer_confirmed', label: 'در حال تایید قیمت توسط مشتری', possibleNext: ['contracted'], responsibleSection: null },
  { key: 'contracted', label: 'در حال عقد قرارداد', possibleNext: ['paid'], responsibleSection: 'orders' },
  { key: 'paid', label: 'در حال بررسی و تایید پرداخت توسط کارشناس مالی', possibleNext: ['loading'], responsibleSection: 'payments' },
  { key: 'loading', label: 'در حال بارگیری در انبار', possibleNext: ['in_transit'], responsibleSection: 'warehouses' },
  { key: 'in_transit', label: 'در مسیر ارسال', possibleNext: ['delivered'], responsibleSection: 'logistics' },
  { key: 'delivered', label: 'تحویل داده شده — سفارش بسته شد', possibleNext: [], responsibleSection: null },
]

const MATERIAL_LISTING_STAGES: StageDef[] = [
  { key: 'submitted', label: 'ثبت شد — در انتظار بررسی توسط پشتیبانی', possibleNext: ['approved', 'needs_correction'], responsibleSection: 'material-listings' },
  { key: 'needs_correction', label: 'نیاز به اصلاح اطلاعات توسط ثبت‌کننده', possibleNext: ['submitted'], responsibleSection: null },
  { key: 'approved', label: 'تایید شد — در سایت قابل مشاهده است', possibleNext: ['under_review_by_buyer'], responsibleSection: null },
  { key: 'under_review_by_buyer', label: 'در حال بررسی توسط یک خریدار', possibleNext: ['accepted_by_buyer', 'approved'], responsibleSection: 'material-listings' },
  { key: 'accepted_by_buyer', label: 'پذیرفته شد توسط خریدار — منتظر پرداخت کارمزد', possibleNext: ['fee_paid'], responsibleSection: null },
  { key: 'fee_paid', label: 'کارمزد پرداخت شد — در حال هماهنگی انتقال بار', possibleNext: ['completed'], responsibleSection: 'material-listings' },
  { key: 'completed', label: 'تکمیل شد — بار تحویل داده شد', possibleNext: [], responsibleSection: null },
]

const SUPPORT_TICKET_STAGES: StageDef[] = [
  { key: 'open', label: 'در حال بررسی اولیه توسط پشتیبانی', possibleNext: ['in_progress'], responsibleSection: 'support' },
  { key: 'in_progress', label: 'در حال پیگیری توسط کارشناس پشتیبانی', possibleNext: ['resolved'], responsibleSection: 'support' },
  { key: 'resolved', label: 'پاسخ داده شد — منتظر تایید نهایی مشتری', possibleNext: ['closed', 'in_progress'], responsibleSection: null },
  { key: 'closed', label: 'بسته شد', possibleNext: [], responsibleSection: null },
]

const WORKFLOWS: Record<RecordType, StageDef[]> = {
  Order: ORDER_STAGES,
  MaterialListing: MATERIAL_LISTING_STAGES,
  SupportTicket: SUPPORT_TICKET_STAGES,
}

function findStage(recordType: RecordType, key: string): StageDef | undefined {
  return WORKFLOWS[recordType].find((s) => s.key === key)
}

function findPrevStage(recordType: RecordType, currentKey: string): StageDef | undefined {
  return WORKFLOWS[recordType].find((s) => s.possibleNext.includes(currentKey))
}

/**
 * برای یک رکورد در یک مرحله‌ی مشخص، برچسب مرحله‌ی قبلی/حال/بعدی رو برمی‌گردونه.
 * اگه از این مرحله بیش از یک مسیر ممکن باشه، nextLabel خنثی («منتظر وضعیت جاری») می‌شه
 * — نه یه حدسِ گمراه‌کننده.
 */
export function describeTransition(recordType: RecordType, currentKey: string) {
  const current = findStage(recordType, currentKey)
  if (!current) {
    return { prevLabel: null, currentLabel: 'وضعیت نامشخص', nextLabel: null }
  }

  const prev = findPrevStage(recordType, currentKey)

  let nextLabel: string | null
  if (current.possibleNext.length === 0) {
    nextLabel = null // مرحله‌ی پایانی، مرحله‌ی بعدی وجود نداره
  } else if (current.possibleNext.length === 1) {
    const next = findStage(recordType, current.possibleNext[0])
    nextLabel = next ? next.label : null
  } else {
    nextLabel = 'منتظر وضعیت جاری' // چند مسیر ممکنه؛ گمراه‌کننده نشون ندیم
  }

  return {
    prevLabel: prev ? prev.label : null,
    currentLabel: current.label,
    nextLabel,
    responsibleSection: current.responsibleSection,
  }
}

export function getStages(recordType: RecordType): StageDef[] {
  return WORKFLOWS[recordType]
}

export function getStageDef(recordType: RecordType, key: string): StageDef | undefined {
  return findStage(recordType, key)
}

export function isTerminalStage(recordType: RecordType, key: string): boolean {
  const stage = findStage(recordType, key)
  return !stage || stage.possibleNext.length === 0
}
