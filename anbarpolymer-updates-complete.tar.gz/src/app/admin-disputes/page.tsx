import prisma from '@/lib/prisma'
import { getAllSectionAccess } from '@/lib/permissions'
import { getCurrentUser } from '@/lib/currentUser'
import AdminNav from '@/components/AdminNav'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'
import { resolveDisputeAction } from './actions'

export const dynamic = 'force-dynamic'

export default async function AdminDisputesPage() {
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)

  const disputes = await prisma.dispute.findMany({
    include: { deal: { include: { buyer: true } }, raisedBy: true },
    orderBy: { createdAt: 'desc' },
  })

  const openDisputes = disputes.filter((d) => d.status === 'open')
  const closedDisputes = disputes.filter((d) => d.status !== 'open')

  return (
    <div className="admin-page-wrap" style={{ display: 'flex', gap: 24, padding: '32px 24px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', maxWidth: 1100, margin: '0 auto' }}>
      <AdminNav currentUserName={currentUser.companyName} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="disputes" />

      <div style={{ flex: 1, minWidth: 0 }}>
        <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>رسیدگی به اختلاف</h1>
        <p style={{ fontSize: 13, color: '#6f7680', marginBottom: 24 }}>
          هر بار خریدار تحویل بار رو «با مغایرت» یا «رد» تایید کنه، یه مورد اینجا خودکار باز می‌شه.
        </p>

        <h2 style={sectionHeadStyle}>باز — نیاز به رسیدگی <span style={countBadge}>{openDisputes.length}</span></h2>
        {openDisputes.length === 0 && <div style={emptyBoxStyle}>هیچ اختلاف بازی نیست.</div>}
        {openDisputes.map((d) => (
          <form key={d.id} action={resolveDisputeAction} style={disputeCardStyle}>
            <input type="hidden" name="disputeId" value={d.id} />
            <input type="hidden" name="status" value="resolved" />
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
              <b style={{ fontSize: 14 }}>معامله #{d.dealId.slice(0, 8)}</b>
              <span style={{ fontSize: 11, color: '#9199a3' }}>{new Date(d.createdAt).toLocaleDateString('fa-IR')}</span>
            </div>
            <div style={{ fontSize: 12.5, color: '#4f5560', marginBottom: 4 }}>خریدار: {d.deal.buyer.companyName}</div>
            <div style={{ fontSize: 13, fontWeight: 600, color: '#a8241a', marginBottom: 14 }}>دلیل: {d.reason}</div>

            <textarea name="resolution" placeholder="توضیح نتیجه‌ی رسیدگی (الزامی)" rows={3} style={textareaStyle} required />

            <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
              <ConfirmSubmitButton message="این اختلاف حل‌شده ثبت بشه؟" style={resolveBtnStyle}>
                ثبت به‌عنوان حل‌شده
              </ConfirmSubmitButton>
            </div>
          </form>
        ))}

        <h2 style={{ ...sectionHeadStyle, marginTop: 32 }}>تاریخچه</h2>
        {closedDisputes.length === 0 && <div style={emptyBoxStyle}>هنوز موردی بسته نشده.</div>}
        {closedDisputes.map((d) => (
          <div key={d.id} style={historyCardStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <b style={{ fontSize: 13 }}>#{d.dealId.slice(0, 8)}</b>
              <span style={statusTag}>{d.status === 'resolved' ? 'حل شد' : 'رد شد'}</span>
            </div>
            {d.resolution && <div style={{ fontSize: 12, color: '#4f5560', marginTop: 6 }}>{d.resolution}</div>}
          </div>
        ))}
      </div>
    </div>
  )
}

const sectionHeadStyle: React.CSSProperties = { fontSize: 15, fontWeight: 800, display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }
const countBadge: React.CSSProperties = { background: '#fee2e2', color: '#a8241a', fontSize: 11, fontWeight: 800, borderRadius: 20, padding: '2px 10px' }
const emptyBoxStyle: React.CSSProperties = { padding: 24, textAlign: 'center', color: '#9199a3', border: '1px dashed #d8dde3', borderRadius: 12, fontSize: 12.5, marginBottom: 20 }
const disputeCardStyle: React.CSSProperties = { border: '1.5px solid #dc2626', borderRadius: 12, padding: 18, marginBottom: 12, background: '#fff' }
const historyCardStyle: React.CSSProperties = { border: '1px solid #eceff3', borderRadius: 10, padding: '12px 16px', marginBottom: 8, background: '#fff' }
const textareaStyle: React.CSSProperties = { width: '100%', border: '1px solid #d8dde3', borderRadius: 8, padding: '10px 12px', fontSize: 12.5, fontFamily: 'inherit', resize: 'vertical' }
const resolveBtnStyle: React.CSSProperties = { background: '#1e357b', color: '#fff', border: 'none', borderRadius: 8, padding: '9px 18px', fontSize: 12.5, fontWeight: 700, cursor: 'pointer' }
const statusTag: React.CSSProperties = { fontSize: 10.5, fontWeight: 700, background: '#f1efe8', color: '#5f5e5a', borderRadius: 5, padding: '3px 10px' }
