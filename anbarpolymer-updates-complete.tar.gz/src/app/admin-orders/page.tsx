import prisma from '@/lib/prisma'
import { getAllSectionAccess } from '@/lib/permissions'
import { getCurrentUser } from '@/lib/currentUser'
import { isPriceStillValid } from '@/lib/pricing'
import AdminNav from '@/components/AdminNav'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'
import { setOrderPricing, rejectOrder } from './actions'

export const dynamic = 'force-dynamic'

const STATUS_LABELS: Record<string, string> = {
  pending: 'در انتظار قیمت‌گذاری',
  priced: 'قیمت ثبت شد — منتظر تایید مشتری',
  buyer_confirmed: 'تایید شد توسط مشتری',
  contracted: 'در حال عقد قرارداد',
  paid: 'پرداخت تایید شد',
  loading: 'در حال بارگیری',
  in_transit: 'در مسیر ارسال',
  delivered: 'تحویل داده شد',
  rejected: 'رد شد',
}

export default async function AdminOrdersPage() {
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)

  const orders = await prisma.order.findMany({
    include: { user: true, items: { include: { grade: true, warehouse: true } } },
    orderBy: { createdAt: 'desc' },
  })

  const pendingOrders = orders.filter((o) => o.status === 'pending')
  const otherOrders = orders.filter((o) => o.status !== 'pending')

  return (
    <div className="admin-page-wrap" style={{ display: 'flex', gap: 24, padding: '32px 24px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', maxWidth: 1100, margin: '0 auto' }}>
      <AdminNav currentUserName={currentUser.companyName} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="orders" />

      <div style={{ flex: 1, minWidth: 0 }}>
        <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>سفارش‌ها</h1>
        <p style={{ fontSize: 13, color: '#6f7680', marginBottom: 28 }}>سفارش‌های در انتظار قیمت‌گذاری بالای صفحه‌ن — بقیه پایین، به‌عنوان تاریخچه.</p>

        {/* ================= بخش ۱: نیاز به اقدام فوری ================= */}
        <h2 style={sectionHeadStyle}>
          🔴 نیاز به قیمت‌گذاری
          <span style={countBadge}>{pendingOrders.length}</span>
        </h2>

        {pendingOrders.length === 0 && (
          <div style={emptyBoxStyle}>هیچ سفارش در انتظاری نیست.</div>
        )}

        {pendingOrders.map((order) => (
          <form key={order.id} action={setOrderPricing} style={pendingCardStyle}>
            <input type="hidden" name="orderId" value={order.id} />
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
              <div>
                <b style={{ fontSize: 14.5 }}>سفارش #{order.id.slice(0, 8)}</b>
                <span style={{ fontSize: 12, color: '#6f7680', marginRight: 10 }}>{order.user.companyName}</span>
              </div>
              <span style={{ fontSize: 11, color: '#9199a3' }}>{new Date(order.createdAt).toLocaleString('fa-IR')}</span>
            </div>

            <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: 14 }}>
              <thead>
                <tr style={{ borderBottom: '1.5px solid #eceff3' }}>
                  <th style={thStyle}>گرید</th>
                  <th style={thStyle}>انبار</th>
                  <th style={thStyle}>مقدار</th>
                  <th style={thStyle}>قیمت مرجع</th>
                  <th style={thStyle}>وضعیت اعتبار</th>
                  <th style={thStyle}>قیمت نهایی</th>
                </tr>
              </thead>
              <tbody>
                {order.items.map((item) => {
                  const valid = isPriceStillValid(item.priceValidUntil)
                  return (
                    <tr key={item.id} style={{ borderBottom: '1px solid #f1efe8' }}>
                      <td style={tdStyle}><b style={{ fontFamily: 'monospace' }}>{item.grade.code}</b></td>
                      <td style={tdStyle}>{item.warehouse?.name}</td>
                      <td style={tdStyle}>{item.quantity} تن</td>
                      <td style={{ ...tdStyle, fontFamily: 'monospace' }}>{item.price.toLocaleString('en-US')}</td>
                      <td style={tdStyle}>
                        <span style={valid ? validTag : expiredTag}>{valid ? 'معتبر' : 'منقضی — بررسی کن'}</span>
                      </td>
                      <td style={tdStyle}>
                        <input
                          name={`finalPrice-${item.id}`}
                          type="number"
                          defaultValue={item.price}
                          style={priceInputStyle}
                        />
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>

            <div style={{ display: 'flex', gap: 10 }}>
              <ConfirmSubmitButton
                message="قیمت‌های ثبت‌شده برای مشتری ارسال بشه؟"
                style={{ background: '#1e357b', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 18px', fontSize: 13, fontWeight: 700, cursor: 'pointer' }}
              >
                ثبت قیمت‌ها و ارسال به مشتری
              </ConfirmSubmitButton>
            </div>
          </form>
        ))}

        {/* دکمه‌ی رد سفارش جدا، چون moment فرم دیگه‌ایه */}
        {pendingOrders.map((order) => (
          <form key={`reject-${order.id}`} action={rejectOrder} style={{ marginTop: -10, marginBottom: 20 }}>
            <input type="hidden" name="orderId" value={order.id} />
            <ConfirmSubmitButton
              message={`⚠️ سفارش #${order.id.slice(0, 8)} رد بشه؟ موجودی قفل‌شده به انبار برمی‌گرده.`}
              style={{ background: 'transparent', color: '#dc2626', border: '1px solid #dc2626', borderRadius: 8, padding: '8px 16px', fontSize: 12, fontWeight: 700, cursor: 'pointer' }}
            >
              رد این سفارش
            </ConfirmSubmitButton>
          </form>
        ))}

        {/* ================= بخش ۲: تاریخچه ================= */}
        <h2 style={{ ...sectionHeadStyle, marginTop: 36 }}>تاریخچه‌ی سفارش‌ها</h2>
        {otherOrders.length === 0 && <div style={emptyBoxStyle}>هنوز سفارشی به این مرحله نرسیده.</div>}
        {otherOrders.map((order) => (
          <div key={order.id} style={historyCardStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <b style={{ fontSize: 13.5 }}>#{order.id.slice(0, 8)}</b>
                <span style={{ fontSize: 11.5, color: '#6f7680', marginRight: 8 }}>{order.user.companyName}</span>
              </div>
              <span style={statusTag}>{STATUS_LABELS[order.status] || order.status}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

const sectionHeadStyle: React.CSSProperties = { fontSize: 15, fontWeight: 800, display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }
const countBadge: React.CSSProperties = { background: '#fee2e2', color: '#a8241a', fontSize: 11, fontWeight: 800, borderRadius: 20, padding: '2px 10px' }
const emptyBoxStyle: React.CSSProperties = { padding: 24, textAlign: 'center', color: '#9199a3', border: '1px dashed #d8dde3', borderRadius: 12, fontSize: 12.5, marginBottom: 20 }
const pendingCardStyle: React.CSSProperties = { border: '1.5px solid #f6621b', borderRadius: 12, padding: 18, marginBottom: 10, background: '#fff', boxShadow: '0 1px 4px rgba(27,30,36,.05)' }
const historyCardStyle: React.CSSProperties = { border: '1px solid #eceff3', borderRadius: 10, padding: '12px 16px', marginBottom: 8, background: '#fff' }
const thStyle: React.CSSProperties = { textAlign: 'right', fontSize: 11, color: '#6f7680', padding: '6px 8px', fontWeight: 700 }
const tdStyle: React.CSSProperties = { padding: '8px', fontSize: 12.5 }
const validTag: React.CSSProperties = { fontSize: 10.5, fontWeight: 700, background: '#dcfce7', color: '#146c3a', borderRadius: 5, padding: '3px 9px' }
const expiredTag: React.CSSProperties = { fontSize: 10.5, fontWeight: 700, background: '#fee2e2', color: '#a8241a', borderRadius: 5, padding: '3px 9px' }
const statusTag: React.CSSProperties = { fontSize: 11, fontWeight: 700, background: '#eef4fd', color: '#1e357b', borderRadius: 6, padding: '4px 12px' }
const priceInputStyle: React.CSSProperties = { width: 110, border: '1px solid #d8dde3', borderRadius: 6, padding: '6px 8px', fontSize: 12, fontFamily: 'monospace' }
