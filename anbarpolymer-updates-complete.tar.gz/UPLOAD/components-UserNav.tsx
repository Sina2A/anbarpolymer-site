'use client'

export default function UserNav({
  currentUserName,
  activeSection,
}: {
  currentUserName: string
  activeSection?: string
}) {
  const items = [
    { key: 'dashboard', label: 'داشبورد', href: '/dashboard' },
    { key: 'orders', label: 'سفارش‌های من', href: '/my-orders' },
    { key: 'verification', label: 'احراز هویت', href: '/verification' },
    { key: 'grades', label: 'گریدها', href: '/grades' },
    { key: 'rfq', label: 'استعلام قیمت', href: '/rfq' },
  ]
  const activeLabel = items.find((i) => i.key === activeSection)?.label ?? 'منوی من'

  return (
    <details className="user-nav" open>
      <summary className="user-nav-toggle">
        <span>☰ {activeLabel}</span>
        <span className="user-nav-caret">▾</span>
      </summary>
      <div
        style={{
          paddingBottom: 12,
          marginBottom: 10,
          borderBottom: '1px solid #eceff3',
          fontSize: 13,
          fontWeight: 700,
        }}
      >
        {currentUserName}
      </div>
      <nav style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {items.map((item) => (
          <a
            key={item.key}
            href={item.href}
            style={{
              display: 'block',
              padding: '9px 8px',
              borderRadius: 6,
              fontSize: 13,
              textDecoration: 'none',
              color: item.key === activeSection ? '#e65716' : '#4f5560',
              background: item.key === activeSection ? '#fff4ee' : 'transparent',
              fontWeight: item.key === activeSection ? 700 : 400,
            }}
          >
            {item.label}
          </a>
        ))}
      </nav>
    </details>
  )
}
