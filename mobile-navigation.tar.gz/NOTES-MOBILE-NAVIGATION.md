# یادداشت تحویل — ناوبری موبایل (۵ ساختار جدا + الحاقیه‌ی بصری)

## خلاصه
پیاده‌سازی ناوبری موبایل با ۵ ساختار جدا بر اساس نقش کاربری، با زبان بصری واحد (سرمه‌ای `#16285F` + نارنجی `#E65716`) و طبق الحاقیه‌ی بصری تأییدشده (شناور pill، تب فعال با پس‌زمینه‌ی گرد). دسکتاپ (سایدبار ثابت) دست‌نخورده ماند. همه‌چیز فقط زیر `899px` فعال است.

## ساختارها

### ۱) مهمان (Guest) — `PublicHeader`
- **نوار پایین ۴ تب ثابت:** خانه `/`، بازار صنعتی `/market`، گزارش بازار `/reports`، تماس با ما `/contact`
- **بیشتر (☰ در هدر → Bottom Sheet):** گریدها `/grades`، استعلام قیمت `/rfq`، انبارها `/warehouses`، خدمات سازمانی `/services`، درباره ما `/about`، ورود/ثبت‌نام `/login`

### ۲) کاربر لاگین‌شده (buyer/seller) — `PanelHeader`
- **نوار پایین ۵ تب:** پیشخوان `/dashboard`، بازار من `/purchase-requests`، سفارش‌ها `/my-orders`، معاملات و حمل `/my-deals`، حساب من `/account`
- **بیشتر (☰ در هدر → Bottom Sheet):** احراز هویت `/verification`، پیش‌فاکتورها `/proformas`، شبکه عرضه‌ی من `/my-listings`، ثبت آگهی `/new-listing`، استعلام قیمت `/rfq`، درخواست غیرکاتالوگی `/custom-request`، هشدار قیمت `/price-alerts`، پشتیبانی `/support`، خروج از حساب (via `logoutAction`)
- لینک ثانویه‌ی حمل‌ونقل `/transport` داخل شیت بیشتر است.

### ۳) ادمین — بدون نوار پایین
- هدر تیره‌ی ثابت + دکمه‌ی ☰ سمت راست (`data-admin-hamburger`)
- کلیک → Drawer از راست با همان ۷ گروه موجود `AdminNav` (همان منطق `accessOf`/`isReal`/`partialTag`) — محتوای فعلی فقط در Drawer
- سایدبار دسکتاپ با `admin-sidebar-desktop` زیر `899px` مخفی می‌شود.

### ۴) پنل حمل‌ونقل — Segmented Control بالا (نه Bottom Nav)
- شرکت حمل‌ونقل: ۲ تب بالای صفحه `فعلی /transport-panel/current` و `تاریخچه /transport-panel/history` (تشخیص فعال با `pathname.startsWith`)
- راننده (`driver/[token]`, `driver/t/[token]`): بدون هیچ منویی — صفحات تک‌کاره، دست‌نخورده
- Drawer موجود `TransportPanelShell` حفظ شد؛ Segmented فقط میان‌بر است.

### ۵) راننده — بدون منو (عمداً)

## فایل‌های جدید

- `src/lib/mobileNavItems.ts` — منبع واحد: `GUEST_BOTTOM_TABS`، `GUEST_SHEET_ITEMS`، `USER_BOTTOM_TABS`، `USER_SHEET_ITEMS` + تابع `isActivePath(pathname, href)` (حالت `/` دقیق، بقیه `===` یا `startsWith(href+'/')`)؛ آیکون‌ها از `lucide-react` (بدون ایموجی)
- `src/components/mobile/GuestBottomNav.tsx` — `'use client'`, `usePathname`, `homeHref` prop (از `getSurfaceHome()` والد Server)
- `src/components/mobile/UserBottomNav.tsx` — مشابه، ۵ تب، `isActivePath`
- `src/components/mobile/MoreSheet.tsx` — Bottom Sheet مشترک (`open`/`onClose`/`title`/`items`)؛ `isLogout` → `<form action={logoutAction}>`؛ قفل اسکرول + Escape
- `src/components/mobile/AdminMobileDrawer.tsx` — Drawer هفت‌دسته‌ای با همان منطق دسترسی `AdminNav`؛ `open`/`onClose`، `panelRef` + Escape + قفل اسکرول
- `src/components/mobile/TransportSegmentedTabs.tsx` — `'use client'`, `usePathname`, دو تب

## فایل‌های تغییریافته

- `src/lib/styles/tokens.ts` — افزوده: `export const breakpoints = { mobile: 900 }` (تنها منبع عددی؛ CSS با `899px` و JS با `900`)
- `src/components/PublicHeader.tsx` — `moreOpen` state، حذف `mobileMenuStyle` قدیمی، افزودن `MoreSheet` + `Guest/UserBottomNav` شرطی، هامبورگر `☰` با `data-public-hamburger`
- `src/components/PanelHeader.tsx` — افزودن `MoreSheet` + `UserBottomNav`، هامبورگر `data-panel-hamburger`
- `src/components/AdminNav.tsx` — `admin-sidebar-desktop` روی `<aside>`، تریگر `data-admin-hamburger` + `AdminMobileDrawer`، اصلاح `useState/useEffect` و `accessOf`
- `src/components/UserNav.tsx` — `user-sidebar-desktop` روی `<div>`
- `src/app/globals.css` — الحاقیه‌ی دقیق (wrap `fixed` + `env(safe-area-inset-bottom)`، nav `#16285F` radius `22`، item radius `16`، active `#E65716`) + قواعد ریسپانسیو `@media (max-width: 899px)` + فیکس چیدمان MoreSheet: `nav.mobile-sheet-list {display:flex; flex-direction:column; align-items:stretch; width:100%}` و `a.mobile-sheet-item / form.mobile-sheet-form / button.mobile-sheet-item-logout {width:100%; align-self:stretch; display:flex}` تا هر آیتم ردیف تمام‌عرض جدا باشد (رفع بهم‌چسبیدگی پاراگرافی)
- `src/app/transport-panel/layout.tsx` — رندر `TransportSegmentedTabs` بالای `children`

## قوانین رعایت‌شده

- بدون ایموجی — فقط `lucide-react` SVG
- دسکتاپ دست‌نخورده (سایدبار ثابت فقط با `display:none` زیر breakpoint مخفی)
- `homeHref` via prop-drilling از والد Server (`getSurfaceHome()`) — هیچ `process.env.SURFACE` در `'use client'`
- `breakpoints.mobile = 900` تنها منبع؛ CSS با `899px`
- آیکون تب‌ها `16px`، `strokeWidth` فعال `2.3` / غیرفعال `1.8`، برچسب `10px/600`

## راستی‌آزمایی

- `npx tsc --noEmit` → `EXIT 0`
- `grep -rn "process.env.SURFACE" src/components/mobile/` → فقط کامنت توضیحی (بدون استفاده‌ی واقعی)
- `grep -rn "getSurfaceHome" src/components/PublicHeader.tsx src/components/PanelHeader.tsx` → فقط via prop

## پیوست — مقایسه‌ی لینک‌های منوی همبرگری قدیمی با شیت‌های جدید

> هدف این جدول این است که صریحاً نشان دهد هیچ لینکی در بازطراحی موبایل حذف نشده — فقط بازچینی شده است. ستون «قبل» از روی کدِ قبل از این تسک (منوی همبرگریِ قدیمی `PublicHeader`/`PanelHeader` و محتوای `UserNav`/`AdminNav`) استخراج شده است.

### ۱) مهمان — `PublicHeader` (پورتال عمومی)

| لینک قدیمی (همبرگری قبل) | مسیر | وضعیت جدید |
|---|---|---|
| صفحه اصلی | `/` | نوار پایین (تب خانه) |
| بازار صنعتی | `/market` | نوار پایین |
| گزارش بازار | `/reports` | نوار پایین |
| تماس با ما | `/contact` | نوار پایین |
| گریدها | `/grades` | شیت «بیشتر» (`GUEST_SHEET_ITEMS`) |
| استعلام قیمت | `/rfq` | شیت «بیشتر» |
| انبارها | `/warehouses` | شیت «بیشتر» |
| خدمات سازمانی | `/services` | شیت «بیشتر» |
| درباره ما | `/about` | شیت «بیشتر» |
| ورود / ثبت‌نام | `/login` | شیت «بیشتر» |

نتیجه: ۱۰ لینک قدیمی → ۴ تب پایین + ۶ آیتم شیت. هیچ حذفی نیست؛ فقط ۴ لینک پرکاربرد به نوار پایین منتقل شدند.

### ۲) کاربر لاگین‌شده — `PanelHeader` + `UserNav`

| لینک قدیمی (`UserNav` / هدر قدیمی) | مسیر | وضعیت جدید |
|---|---|---|
| پیشخوان | `/dashboard` | نوار پایین |
| بازار من | `/purchase-requests` | نوار پایین |
| سفارش‌ها | `/my-orders` | نوار پایین |
| معاملات و حمل | `/my-deals` | نوار پایین (لینک ثانویه‌ی `/transport` → شیت) |
| حساب من | `/account` | نوار پایین |
| احراز هویت | `/verification` | شیت «بیشتر» (`USER_SHEET_ITEMS`) |
| پیش‌فاکتورهای من | `/proformas` | شیت «بیشتر» |
| شبکه عرضه‌ی من | `/my-listings` | شیت «بیشتر» |
| ثبت آگهی جدید | `/new-listing` | شیت «بیشتر» |
| استعلام قیمت | `/rfq` | شیت «بیشتر» |
| درخواست غیرکاتالوگی | `/custom-request` | شیت «بیشتر» |
| هشدار قیمت | `/price-alerts` | شیت «بیشتر» |
| حمل و نقل | `/transport` | شیت «بیشتر» (لینک ثانویه‌ی پرامپت) |
| پشتیبانی | `/support` | شیت «بیشتر» |
| خروج از حساب | `logoutAction` | شیت «بیشتر» (`isLogout: true`) |

نتیجه: همه‌ی آیتم‌های `UserNav` (۳ گروه) + اکشن خروج حفظ شدند؛ ۵ تای اصلی به نوار پایین، ۱۰ تای بقیه به شیت.

### ۳) ادمین — `AdminNav`

بدون شیت/نوار پایین. همان ۷ گروهِ `MENU_GROUPS` با همان منطق `accessOf`/`isReal`/`partialTag` عیناً به `AdminMobileDrawer` منتقل شد — هیچ کلید بخشی (`SECTION_KEYS`) حذف یا اضافه نشده است.

### ۴) حمل‌ونقل

- شرکت: `TransportPanelShell` (Drawer موجود) دست‌نخورده؛ `TransportSegmentedTabs` فقط ۲ تب میان‌بر (`/transport-panel/current`, `/transport-panel/history`) اضافه می‌کند.
- راننده (`driver/[token]`, `driver/t/[token]`): بدون منو — عمداً بدون تغییر.

**جمع‌بندی:** مقایسه‌ی ردیف‌به‌ردیف بالا نشان می‌دهد تمام لینک‌های همبرگری قدیمی عیناً در `GUEST_SHEET_ITEMS` / `USER_SHEET_ITEMS` / `AdminMobileDrawer` / `TransportSegmentedTabs` بازتاب یافته‌اند. هیچ مسیری حذف نشده است.
