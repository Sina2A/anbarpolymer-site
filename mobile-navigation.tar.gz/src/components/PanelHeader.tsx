'use client'

import { useEffect, useState } from 'react'
import { logoutAction } from '@/app/logout/actions'
import { colors } from '@/lib/styles/tokens'
import { Home } from 'lucide-react'
import UserBottomNav from '@/components/mobile/UserBottomNav'
import MoreSheet from '@/components/mobile/MoreSheet'
import { USER_SHEET_ITEMS } from '@/lib/mobileNavItems'
import type { CSSProperties } from 'react'
import { BrandCoin } from '@/components/BrandMark'

export default function PanelHeader({
  currentUserName,
  homeHref = '/',
}: {
  currentUserName: string
  homeHref?: string
}) {
  const [moreOpen, setMoreOpen] = useState(false)

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 900) setMoreOpen(false)
    }
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  return (
    <>
      <header style={headerStyle} data-panel-header="true">
      <div style={wrapStyle}>
        <a href={homeHref} style={logoStyle}>
          <BrandCoin />
          انبار پلیمر
        </a>

        <div style={actionsStyle}>
          <a href="/market" style={backToSiteStyle} className="panel-backtosite-desktop">
            <Home size={14} />
            بازگشت به سایت
          </a>

          <span style={userNameStyle} className="panel-user-desktop">
            {currentUserName}
          </span>

          <form action={logoutAction} className="panel-logout-desktop">
            <button type="submit" style={logoutBtnStyle}>
              خروج از حساب
            </button>
          </form>

          <button
            onClick={() => setMoreOpen(true)}
            style={hamburgerBtnStyle}
            data-panel-hamburger="true"
            aria-label="منو"
          >
            ☰
          </button>
        </div>
      </div>
    </header>
      <MoreSheet open={moreOpen} onClose={() => setMoreOpen(false)} title="بیشتر" items={USER_SHEET_ITEMS} />
      <UserBottomNav homeHref={homeHref} />
    </>
  )
}

// ──────────────────────────────────────────────────────────
// استایل‌ها — الگوی PublicHeader با ساده‌سازی
// ──────────────────────────────────────────────────────────
const headerStyle: CSSProperties = {
  position: 'sticky',
  top: 0,
  zIndex: 50,
  background: colors.navy,
  borderBottom: `1px solid ${colors.navyDark}`,
  boxShadow: '0 2px 10px rgba(30,53,123,0.25)',
}

const wrapStyle: CSSProperties = {
  maxWidth: 1180,
  margin: '0 auto',
  padding: '0 24px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  height: 56,
  gap: 24,
}

const logoStyle: CSSProperties = {
  fontWeight: 800,
  fontSize: 19,
  letterSpacing: '-0.01em',
  display: 'flex',
  alignItems: 'center',
  gap: 8,
  color: '#ffffff',
  fontFamily: 'var(--font-heading)',
  textDecoration: 'none',
}

const actionsStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 14,
}

const userNameStyle: CSSProperties = {
  color: 'rgba(255,255,255,0.85)',
  fontSize: 13,
  fontWeight: 600,
  fontFamily: 'var(--font-label)',
}

const logoutBtnStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  height: 30,
  border: '1px solid rgba(255,255,255,0.4)',
  borderRadius: 8,
  padding: '0 14px',
  fontSize: 12.5,
  color: '#ffffff',
  background: 'transparent',
  cursor: 'pointer',
  fontFamily: 'inherit',
  fontWeight: 600,
  boxSizing: 'border-box',
}

const hamburgerBtnStyle: CSSProperties = {
  display: 'none',
  background: 'transparent',
  border: '1px solid rgba(255,255,255,0.4)',
  borderRadius: 6,
  color: '#ffffff',
  fontSize: 18,
  padding: '4px 10px',
  cursor: 'pointer',
}

const mobileUserStyle: CSSProperties = {
  color: 'rgba(255,255,255,0.85)',
  fontSize: 13,
  fontWeight: 700,
  paddingBottom: 8,
  borderBottom: '1px solid rgba(255,255,255,0.15)',
}

const mobileLogoutStyle: CSSProperties = {
  color: '#ff9b9b',
  fontSize: 13,
  fontWeight: 600,
  background: 'transparent',
  border: 'none',
  cursor: 'pointer',
  fontFamily: 'inherit',
  textAlign: 'right' as const,
  padding: '6px 0',
  width: '100%',
}

const backToSiteStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 6,
  height: 30,
  border: '1px solid rgba(255,255,255,0.4)',
  borderRadius: 8,
  padding: '0 14px',
  fontSize: 12.5,
  color: '#ffffff',
  background: 'transparent',
  cursor: 'pointer',
  fontFamily: 'inherit',
  fontWeight: 600,
  textDecoration: 'none',
  boxSizing: 'border-box',
}

const mobileBackToSiteStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 6,
  color: 'rgba(255,255,255,0.85)',
  fontSize: 13,
  fontWeight: 600,
  textDecoration: 'none',
  paddingBottom: 8,
  borderBottom: '1px solid rgba(255,255,255,0.15)',
}
