'use client'

// src/components/mobile/TransportSegmentedTabs.tsx
//
// Segmented Control بالای پنل شرکت حمل‌ونقل — فقط ۲ تب (فعلی/تاریخچه).
// Drawer موجود (TransportPanelShell) حفظ می‌شود؛ این فقط میان‌بر است،
// نه جایگزین. روی راننده‌های بی-سطح (driver/[token] و driver/t/[token])
// اصلاً رندر نمی‌شود — آن صفحات تک‌کاره و بدون منو هستند.
//
// مانند بقیه‌ی ناوبری موبایل، فقط زیر breakpoint موبایل نمایان است؛
 // دسکتاپ بی‌تغییر. طبق قانون سطح‌ها، هیچ process.env.SURFACE ای اینجا نیست.

import { usePathname } from 'next/navigation'

const TABS: { label: string; href: string }[] = [
  { label: 'فعلی', href: '/transport-panel/current' },
  { label: 'تاریخچه', href: '/transport-panel/history' },
]

export default function TransportSegmentedTabs() {
  const pathname = usePathname()
  const path = pathname ?? ''
  const activeHref = path.startsWith('/transport-panel/history')
    ? '/transport-panel/history'
    : '/transport-panel/current'

  return (
    <nav
      className="transport-segmented-tabs"
      aria-label="ناوبری محموله‌ها"
      dir="rtl"
    >
      {TABS.map((tab) => {
        const active = tab.href === activeHref
        return (
          <a
            key={tab.label}
            href={tab.href}
            className={`transport-segmented-tab${active ? ' is-active' : ''}`}
            aria-current={active ? 'page' : undefined}
          >
            {tab.label}
          </a>
        )
      })}
    </nav>
  )
}
