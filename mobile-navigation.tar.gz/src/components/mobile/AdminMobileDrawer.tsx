'use client'

// src/components/mobile/AdminMobileDrawer.tsx
//
// نسخه‌ی Drawer از AdminNav — همان ۷ دسته‌ی موجود، با همون منطق دسترسی
// (full/edit/view/none و isReal/isReal=false). سایدبار دسکتاپ دست‌نخورده
// می‌ماند (با کلاس admin-sidebar-desktop زیر 899px مخفی می‌شود)؛ Drawer
// فقط زیر همان breakpoint از طریق هدر باز می‌شود.
//
// این کامپوننت خودش تریگر ☰ را ندارد — تریگر در هدر ادمین/کنار AdminNav است
// و state آن به این Drawer پاس داده می‌شود. طبق قانون سطح‌ها، homeHref از
// والد Server به‌صورت prop می‌رسد.

import { useEffect, useRef } from 'react'
import { X } from 'lucide-react'
import { logoutAction } from '@/app/logout/actions'
import { SECTION_KEYS, type AccessLevel } from '@/lib/sections'
import { SidebarBrand } from '@/components/BrandMark'
import {
  sidebarGroupTitleStyle,
  sidebarItemStyle,
  sidebarComingSoonBadgeStyle,
} from '@/lib/styles/shared'
import { colors } from '@/lib/styles/tokens'
import type { CSSProperties } from 'react'

type Group = { title: string; keys: string[] }

export default function AdminMobileDrawer({
  groups,
  accessOf,
  activeSection,
  isAdmin,
  currentUserName,
  currentUsername,
  homeHref = '/',
  open,
  onClose,
}: {
  groups: Group[]
  accessOf: (key: string) => AccessLevel
  activeSection?: string
  isAdmin: boolean
  currentUserName: string
  currentUsername?: string | null
  homeHref?: string
  open: boolean
  onClose: () => void
}) {
  const panelRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!open) return
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [open, onClose])

  useEffect(() => {
    if (!open) return
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      document.body.style.overflow = prev
    }
  }, [open])

  // فوکوس داخل Drawer وقتی باز می‌شود — دسترس‌پذیری
  useEffect(() => {
    if (!open) return
    panelRef.current?.focus()
  }, [open])

  if (!open) return null

  return (
    <>
      <button
        type="button"
        className="admin-mobile-drawer-scrim open"
        aria-label="بستن منوی ادمین"
        onClick={onClose}
      />
      <div
        ref={panelRef}
        className="admin-mobile-drawer open"
        role="dialog"
        aria-modal="true"
        aria-label="منوی ادمین"
        tabIndex={-1}
      >
        <div className="admin-mobile-drawer-head">
          <SidebarBrand homeHref={homeHref} />
          <button
            type="button"
            className="admin-mobile-drawer-close"
            aria-label="بستن"
            onClick={onClose}
          >
            <X size={19} strokeWidth={2.2} />
          </button>
        </div>

        <div style={userBoxStyle}>
          <div style={{ fontSize: 13, fontWeight: 700, color: colors.textPrimary }}>
            {currentUserName}
          </div>
          {currentUsername && (
            <div
              style={{
                fontSize: 11.5,
                fontWeight: 700,
                fontFamily: 'monospace',
                direction: 'ltr' as const,
                textAlign: 'right' as const,
                color: colors.textMuted,
              }}
            >
              @{currentUsername}
            </div>
          )}
          <div style={{ fontSize: 11, color: colors.textMuted }}>
            {isAdmin ? 'مدیر' : 'کارشناس'}
          </div>
        </div>

        <nav style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {groups.map((group) => (
            <div key={group.title} style={groupContainerStyle}>
              <div style={sidebarGroupTitleStyle}>{group.title}</div>
              {group.keys.map((key) => {
                if (key === 'tasks') {
                  const active = activeSection === 'tasks'
                  return (
                    <a
                      key={key}
                      href="/my-tasks"
                      style={sidebarItemStyle(active)}
                      onClick={onClose}
                    >
                      کارهای منتظر من
                    </a>
                  )
                }
                const sec = SECTION_KEYS.find((s) => s.key === key)
                if (!sec) return null
                const level = accessOf(key)
                const active = key === activeSection

                if (!sec.isReal) {
                  return (
                    <span
                      key={key}
                      style={{
                        ...sidebarItemStyle(false),
                        color: colors.textMuted,
                        cursor: 'default',
                      }}
                      title="هنوز صفحه‌ی این بخش ساخته نشده"
                    >
                      {sec.label}
                      <span style={sidebarComingSoonBadgeStyle}>به‌زودی</span>
                    </span>
                  )
                }

                if (level === 'none') {
                  return (
                    <span
                      key={key}
                      style={{
                        ...sidebarItemStyle(false),
                        color: colors.dangerText,
                        cursor: 'not-allowed',
                        opacity: 0.65,
                      }}
                      title="دسترسی نداری"
                    >
                      {sec.label}
                    </span>
                  )
                }

                return (
                  <a
                    key={key}
                    href={sec.href}
                    style={sidebarItemStyle(active)}
                    onClick={onClose}
                  >
                    {sec.label}
                    {level !== 'full' && (
                      <span style={partialTag}>{level === 'view' ? 'فقط مشاهده' : 'فقط ویرایش'}</span>
                    )}
                  </a>
                )
              })}
            </div>
          ))}
        </nav>

        {isAdmin && (
          <>
            <div style={dividerStyle} />
            <a
              href="#"
              style={{ ...sidebarItemStyle(false), color: '#f59e0b', fontWeight: 700 }}
              onClick={(e) => {
                e.preventDefault()
                window.open(`http://${window.location.hostname}:4000`, '_blank')
              }}
            >
              پنل دیپلوی (مدیریت سرور) ↗
            </a>
          </>
        )}

        <div style={dividerStyle} />
        <form action={logoutAction}>
          <button
            type="submit"
            style={{
              ...sidebarItemStyle(false),
              color: colors.dangerText,
              cursor: 'pointer',
              width: '100%',
              textAlign: 'right' as const,
              background: 'transparent',
              border: 'none',
              fontFamily: 'inherit',
            }}
          >
            خروج از حساب
          </button>
        </form>
      </div>
    </>
  )
}

const partialTag: CSSProperties = {
  fontSize: 9.5,
  fontFamily: 'monospace',
  background: colors.warningBg,
  color: colors.warningText,
  borderRadius: 4,
  padding: '1px 6px',
}

const dividerStyle: CSSProperties = {
  height: 1,
  background: colors.borderSubtle,
  margin: '10px 0',
}

const groupContainerStyle: CSSProperties = {
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: 8,
  padding: '8px 6px',
  background: colors.bgPage,
}

const userBoxStyle: CSSProperties = {
  padding: '12px 0 14px',
  marginBottom: 8,
  borderBottom: `1px solid ${colors.borderSubtle}`,
  display: 'flex',
  flexDirection: 'column' as const,
  gap: 2,
}
