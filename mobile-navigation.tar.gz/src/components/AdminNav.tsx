'use client'

import { SECTION_KEYS, AccessLevel } from '@/lib/sections'
import { logoutAction } from '@/app/logout/actions'
import {
  sidebarStyle,
  sidebarGroupTitleStyle,
  sidebarItemStyle,
  sidebarComingSoonBadgeStyle,
} from '@/lib/styles/shared'
import { colors } from '@/lib/styles/tokens'
import AdminMobileDrawer from '@/components/mobile/AdminMobileDrawer'
import { useState, useEffect } from 'react'
import type { CSSProperties } from 'react'
import { SidebarBrand } from '@/components/BrandMark'


// ──────────────────────────────────────────────────────────
// گروه‌بندی هفت‌دسته‌ای منوی ادمین — بازنگری‌شده با جداسازی بصری
// payments و custom-rfq به گروه‌های مستقل؛ logs به گروه ۱؛ pricing به گروه ۴
// ──────────────────────────────────────────────────────────
const MENU_GROUPS: { title: string; keys: string[] }[] = [
  { title: 'پیشخوان و تنظیمات', keys: ['tasks', 'logs'] },
  { title: 'سفارشات و معاملات', keys: ['orders', 'deals', 'logistics', 'disputes'] },
  { title: 'پرداخت و مالی', keys: ['payments'] },
  { title: 'کاتالوگ و بازار', keys: ['grades', 'warehouses', 'material-listings', 'pricing'] },
  { title: 'کاربران و دسترسی', keys: ['users', 'kyc', 'buyers'] },
  { title: 'فروش خاص', keys: ['custom-rfq'] },
  { title: 'محتوا و ارتباطات', keys: ['articles', 'support', 'contact'] },
]

/**
 * ناوبری پنل ادمین که بر اساس دسترسی کاربر رنگ می‌گیره:
 * - دسترسی کامل یا مدیر → لینک عادی
 * - دسترسی جزئی (فقط مشاهده یا فقط ویرایش) → لینک عادی، ولی خودِ صفحه باید بنر هشدار نشون بده
 * - بدون دسترسی → قرمز و غیرقابل‌کلیک (span، نه a — تا حتی href هم توی DOM نباشه)
 */
export default function AdminNav({
  currentUserName,
  currentUsername,
  isAdmin,
  accessMap,
  activeSection,
  homeHref = '/',
}: {
  currentUserName: string
  currentUsername?: string | null
  isAdmin: boolean
  accessMap: Record<string, AccessLevel>
  activeSection?: string
  homeHref?: string
}) {
  const [mobileOpen, setMobileOpen] = useState(false)
  useEffect(() => { const h=()=>{ if(window.innerWidth>=900) setMobileOpen(false)}; window.addEventListener('resize',h); return()=>window.removeEventListener('resize',h)},[])

  // ساخت نقشه‌ی دسترسی سریع
  const accessOf = (key: string): AccessLevel =>
    isAdmin ? 'full' : accessMap[key] ?? 'none'

  return (
    <>
      <aside style={sidebarStyle} className="admin-sidebar-desktop">
      <SidebarBrand homeHref={homeHref} />
      {/* اطلاعات کاربر */}
      <div style={userBoxStyle}>
        <div style={{ fontSize: 13, fontWeight: 700, color: colors.textPrimary }}>
          {currentUserName}
        </div>
        {currentUsername && (
          <div style={{ fontSize: 11.5, fontWeight: 700, fontFamily: 'monospace', direction: 'ltr', textAlign: 'right', color: colors.textMuted }}>
            @{currentUsername}
          </div>
        )}
        <div style={{ fontSize: 11, color: colors.textMuted }}>
          {isAdmin ? 'مدیر' : 'کارشناس'}
        </div>
      </div>

      {/* منوی گروه‌بندی‌شده با جداسازی بصری */}
      <nav style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {MENU_GROUPS.map((group) => (
          <div key={group.title} style={groupContainerStyle}>
            <div style={sidebarGroupTitleStyle}>{group.title}</div>
            {group.keys.map((key) => {
              // «کارهای منتظر من» بخش قابل‌گرنت‌شدن نیست
              if (key === 'tasks') {
                return (
                  <a
                    key={key}
                    href="/my-tasks"
                    style={sidebarItemStyle(activeSection === 'tasks')}
                  >
                    کارهای منتظر من
                  </a>
                )
              }

              const sec = SECTION_KEYS.find((s) => s.key === key)
              if (!sec) return null
              const level = accessOf(key)
              const active = key === activeSection

              if (!sec.isReal) {
                return (
                  <span
                    key={key}
                    style={{
                      ...sidebarItemStyle(false),
                      color: colors.textMuted,
                      cursor: 'default',
                    }}
                    title="هنوز صفحه‌ی این بخش ساخته نشده"
                  >
                    {sec.label}
                    <span style={sidebarComingSoonBadgeStyle}>به‌زودی</span>
                  </span>
                )
              }

              if (level === 'none') {
                return (
                  <span
                    key={key}
                    style={{
                      ...sidebarItemStyle(false),
                      color: colors.dangerText,
                      cursor: 'not-allowed',
                      opacity: 0.65,
                    }}
                    title="دسترسی نداری"
                  >
                    {sec.label}
                  </span>
                )
              }

              return (
                <a key={key} href={sec.href} style={sidebarItemStyle(active)}>
                  {sec.label}
                  {level !== 'full' && (
                    <span style={partialTag}>
                      {level === 'view' ? 'فقط مشاهده' : 'فقط ویرایش'}
                    </span>
                  )}
                </a>
              )
            })}
          </div>
        ))}
      </nav>

      {isAdmin && (
        <>
          <div style={dividerStyle} />
          <a
            href="#"
            style={{
              ...sidebarItemStyle(false),
              color: '#f59e0b',
              fontWeight: 700,
            }}
            onClick={(e) => {
              e.preventDefault()
              window.open(
                'http://' + window.location.hostname + ':4000',
                '_blank'
              )
            }}
          >
            پنل دیپلوی (مدیریت سرور) ↗
          </a>
        </>
      )}

      {/* ── خروج از حساب ── */}
      <div style={dividerStyle} />
      <form action={logoutAction}>
        <button
          type="submit"
          style={{
            ...sidebarItemStyle(false),
            color: colors.dangerText,
            cursor: 'pointer',
            width: '100%',
            textAlign: 'right' as const,
            background: 'transparent',
            border: 'none',
            fontFamily: 'inherit',
          }}
        >
          خروج از حساب
        </button>
      </form>
    </aside>
      <button onClick={() => setMobileOpen(true)} data-admin-hamburger="true" aria-label="منو" className="admin-mobile-hamburger">☰</button>
      <AdminMobileDrawer groups={MENU_GROUPS} accessOf={accessOf} activeSection={activeSection} isAdmin={isAdmin} currentUserName={currentUserName} currentUsername={currentUsername} homeHref={homeHref} open={mobileOpen} onClose={() => setMobileOpen(false)} />
    </>
  )
}

/**
 * برای بالای صفحه‌ی هر بخشی که کاربر فقط دسترسی جزئی (نه کامل) بهش داره.
 */
export function PartialAccessBanner({
  level,
  sectionLabel,
}: {
  level: AccessLevel
  sectionLabel: string
}) {
  if (level !== 'view' && level !== 'edit') return null
  const text =
    level === 'view'
      ? `شما فقط به «${sectionLabel}» دسترسی مشاهده دارید — نمی‌توانید تغییری اعمال کنید.`
      : `شما فقط دسترسی ویرایش «${sectionLabel}» را دارید.`
  return (
    <div
      style={{
        background: colors.warningBg,
        color: colors.warningText,
        borderRadius: 8,
        padding: '10px 16px',
        fontSize: 13,
        fontWeight: 500,
        marginBottom: 20,
      }}
    >
      {text}
    </div>
  )
}

// ──────────────────────────────────────────────────────────
// استایل‌های محلی (فقط چیزهایی که توی shared.ts نیست)
// ──────────────────────────────────────────────────────────
const userBoxStyle: CSSProperties = {
  paddingBottom: 12,
  marginBottom: 10,
  borderBottom: `1px solid ${colors.borderSubtle}`,
}

const partialTag: CSSProperties = {
  fontSize: 9.5,
  fontFamily: 'monospace',
  background: colors.warningBg,
  color: colors.warningText,
  borderRadius: 4,
  padding: '1px 6px',
}

const dividerStyle: CSSProperties = {
  height: 1,
  background: colors.borderSubtle,
  margin: '10px 0',
}

const groupContainerStyle: CSSProperties = {
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: 8,
  padding: '8px 6px',
  background: colors.bgPage,
}
