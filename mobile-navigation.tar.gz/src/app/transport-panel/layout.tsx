import type { ReactNode } from 'react'
import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import TransportPanelShell from '@/components/TransportPanelShell'
import TransportPanelFooter from '@/components/TransportPanelFooter'
import TransportSegmentedTabs from '@/components/mobile/TransportSegmentedTabs'
import { getSurfaceHome } from '@/lib/surfaceHome'

export default async function TransportPanelLayout({ children }: { children: ReactNode }) {
  const user = await getCurrentUser()
  const company = await prisma.transportCompany.findUnique({
    where: { managerUserId: user.id },
    select: { name: true },
  })

  return (
    <TransportPanelShell companyName={company?.name ?? 'شرکت حمل‌ونقل'} homeHref={getSurfaceHome()}>
      <TransportSegmentedTabs />
      {children}
      <TransportPanelFooter homeHref={getSurfaceHome()} />
    </TransportPanelShell>
  )
}
