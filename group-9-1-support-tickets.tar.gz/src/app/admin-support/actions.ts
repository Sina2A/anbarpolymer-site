'use server'

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import { logAudit } from '@/lib/logger'
import { revalidatePath } from 'next/cache'

// گیت دسترسی — فقط مدیر یا کارشناسِ دارای دسترسی بخش «support» مجازه.
// مدیر روی همه‌چیز دسترسی داره (مثل الگوی صفحات admin-* موجود).
async function requireSupportAccess() {
  const user = await getCurrentUser()
  const isAdmin = user.role === 'admin'
  if (!isAdmin) {
    const access = await getAllSectionAccess(user.id)
    const level = access['support'] ?? 'none'
    if (level === 'none') throw new Error('شما به بخش پشتیبانی دسترسی ندارید.')
  }
  return { user, isAdmin }
}

// ==================== پاسخ کارشناس روی تیکت ====================

export async function replyToTicketAction(formData: FormData) {
  const { user } = await requireSupportAccess()

  const ticketId = String(formData.get('ticketId') || '').trim()
  const body = String(formData.get('body') || '').trim()

  if (!ticketId) throw new Error('شناسه‌ی تیکت مشخص نیست.')
  if (!body) throw new Error('متن پاسخ خالیه.')

  const ticket = await prisma.supportTicket.findUnique({ where: { id: ticketId } })
  if (!ticket) throw new Error('تیکت پیدا نشد.')

  await prisma.supportMessage.create({
    data: {
      ticketId,
      body,
      senderType: 'staff',
      senderId: user.id,
    },
  })

  // با پاسخ کارشناس، تیکت به «پاسخ‌داده‌شده» می‌ره
  await prisma.supportTicket.update({
    where: { id: ticketId },
    data: { status: 'answered', answeredById: user.id, answeredAt: new Date() },
  })

  await logAudit('support', `پاسخ کارشناس به تیکت ${ticketId.slice(0, 8)}`, user.id, { ticketId })

  revalidatePath(`/admin-support/${ticketId}`)
  revalidatePath('/admin-support')
}

// ==================== تغییر وضعیت تیکت (باز/پاسخ‌داده‌شده/بسته) ====================

export async function updateTicketStatusAction(formData: FormData) {
  const { user } = await requireSupportAccess()

  const ticketId = String(formData.get('ticketId') || '').trim()
  const status = String(formData.get('status')) as 'open' | 'answered' | 'closed'

  if (!ticketId) throw new Error('شناسه‌ی تیکت مشخص نیست.')
  if (!['open', 'answered', 'closed'].includes(status)) throw new Error('وضعیت نامعتبر.')

  const ticket = await prisma.supportTicket.findUnique({ where: { id: ticketId } })
  if (!ticket) throw new Error('تیکت پیدا نشد.')

  const data: { status: string; answeredById?: string; answeredAt?: Date; closedAt?: Date | null } = { status }
  if (status === 'answered') {
    data.answeredById = user.id
    data.answeredAt = new Date()
  } else if (status === 'closed') {
    data.closedAt = new Date()
    // اگه قبل از پاسخ بسته شد، answeredAt رو خالی نذار ولی بسته‌شدن رو ثبت کن
    if (!ticket.answeredAt) {
      data.answeredById = user.id
      data.answeredAt = new Date()
    }
  } else if (status === 'open') {
    data.closedAt = null
  }

  await prisma.supportTicket.update({ where: { id: ticketId }, data })

  await logAudit('support', `تغییر وضعیت تیکت ${ticketId.slice(0, 8)} → ${status}`, user.id, { ticketId, status })

  revalidatePath(`/admin-support/${ticketId}`)
  revalidatePath('/admin-support')
}
