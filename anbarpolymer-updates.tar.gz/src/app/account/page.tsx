import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { redirect } from 'next/navigation'
import UserNav from '@/components/UserNav'
import AccountForm from '@/components/AccountForm'

export const dynamic = 'force-dynamic'

export default async function AccountPage() {
  const user = await getCurrentUser()

  // بارگذاری اطلاعات Company (اگه داره)
  const company = await prisma.company.findUnique({
    where: { userId: user.id },
  })

  return (
    <div style={pageStyle}>
      <div style={{ maxWidth: 1100, margin: '0 auto', display: 'flex', gap: 24 }} className="admin-page-wrap">
        <UserNav currentUserName={user.companyName} activeSection="account" />
        <div style={{ flex: 1, minWidth: 0 }}>
          <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>ویرایش حساب کاربری</h1>
          <p style={{ fontSize: 13, color: '#9199a3', marginBottom: 20 }}>
            مشخصات حساب و شرکت خود را مدیریت کنید
          </p>

          {/* اطلاعات غیرقابل‌ویرایش */}
          <div style={cardStyle}>
            <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 12 }}>اطلاعات ثابت حساب</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <div style={infoRowStyle}>
                <span style={labelStyle}>شماره موبایل (احراز هویت)</span>
                <span style={valueStyle}>{user.phone}</span>
              </div>
              <div style={infoRowStyle}>
                <span style={labelStyle}>نام کاربری</span>
                <span style={valueStyle}>{user.username}</span>
              </div>
              <div style={infoRowStyle}>
                <span style={labelStyle}>نقش</span>
                <span style={roleTag}>{user.role === 'buyer' ? 'خریدار' : user.role === 'admin' ? 'مدیر' : 'کارشناس'}</span>
              </div>
              <div style={{ fontSize: 11, color: '#9199a3', marginTop: 6, fontStyle: 'italic' }}>
                ⓘ شماره موبایل پایه‌ی احراز هویت است و قابل تغییر مستقیم نیست. برای تغییر با پشتیبانی تماس بگیرید.
              </div>
            </div>
          </div>

          {/* فرم ویرایش */}
          <AccountForm
            userId={user.id}
            currentCompanyName={user.companyName}
            company={company}
          />
        </div>
      </div>
    </div>
  )
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: '#faf8f4',
  padding: '32px 20px',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const cardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 18,
  marginBottom: 14,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const infoRowStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  padding: '10px 12px',
  background: '#faf8f4',
  borderRadius: 8,
}
const labelStyle: React.CSSProperties = {
  fontSize: 12.5,
  color: '#6b7280',
  fontWeight: 600,
}
const valueStyle: React.CSSProperties = {
  fontSize: 13,
  color: '#1a1a2e',
  fontWeight: 700,
  fontFamily: 'monospace',
}
const roleTag: React.CSSProperties = {
  fontSize: 11,
  fontWeight: 700,
  background: '#e0e7ff',
  color: '#3730a3',
  borderRadius: 6,
  padding: '3px 10px',
}
