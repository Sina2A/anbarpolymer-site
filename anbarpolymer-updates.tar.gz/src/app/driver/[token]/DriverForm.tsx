'use client'

import { useState, useEffect } from 'react'
import { submitDealConfirmation } from './actions'

const LOADING_CHECKLIST = [
  { key: 'packagingIntact', label: 'بسته‌بندی سالم بود' },
  { key: 'quantityMatches', label: 'تعداد کیسه‌ها/جامبوبگ‌ها مطابق سفارش بود' },
  { key: 'palletsIntact', label: 'پالت‌ها سالم بودند' },
  { key: 'productMatchesOrder', label: 'محصول مطابق سفارش تحویل گرفته شد' },
  { key: 'discrepancyObserved', label: 'مغایرت مشاهده شد' },
]

const UNLOADING_CHECKLIST = [
  { key: 'quantityMatches', label: 'تعداد تحویل‌شده مطابق سفارش است' },
  { key: 'packagingIntact', label: 'بسته‌بندی سالم است' },
  { key: 'noTransitDamage', label: 'آسیب حمل مشاهده نشد' },
  { key: 'productReceived', label: 'محصول دریافت شد' },
  { key: 'discrepancyExists', label: 'مغایرت وجود دارد' },
]

export default function DriverForm({ token, type }: { token: string; type: 'loading' | 'unloading' }) {
  const [gpsStatus, setGpsStatus] = useState<'locating' | 'ok' | 'denied'>('locating')
  const [coords, setCoords] = useState<{ lat: number; lng: number; accuracy: number } | null>(null)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    if (!navigator.geolocation) {
      setGpsStatus('denied')
      return
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude, accuracy: pos.coords.accuracy })
        setGpsStatus('ok')
      },
      () => setGpsStatus('denied'),
      { enableHighAccuracy: true, timeout: 10000 }
    )

    // ردیابی دوره‌ای موقعیت بعد از تایید بارگیری — فقط اگه type='unloading' نباشه
    // (یعنی وقتی راننده هنوز در مسیره، نه اینکه رسیده و داره تخلیه می‌کنه)
    if (type === 'loading') {
      const interval = setInterval(() => {
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            // ارسال موقعیت به سرور هر ۲ دقیقه
            fetch('/api/driver-location', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                token,
                latitude: pos.coords.latitude,
                longitude: pos.coords.longitude,
              }),
            }).catch(() => {
              // خطا در ارسال — بی‌صدا نادیده گرفته می‌شه
            })
          },
          () => {}, // خطای GPS — بی‌صدا نادیده گرفته می‌شه
          { enableHighAccuracy: false, timeout: 30000 }
        )
      }, 120000) // هر ۲ دقیقه = 120000ms

      return () => clearInterval(interval)
    }
  }, [token, type])

  const checklist = type === 'loading' ? LOADING_CHECKLIST : UNLOADING_CHECKLIST

  return (
    <form
      action={submitDealConfirmation}
      onSubmit={() => setSubmitting(true)}
      style={{ display: 'flex', flexDirection: 'column', gap: 16 }}
    >
      <input type="hidden" name="token" value={token} />
      <input type="hidden" name="type" value={type} />
      {coords && (
        <>
          <input type="hidden" name="latitude" value={coords.lat} />
          <input type="hidden" name="longitude" value={coords.lng} />
          <input type="hidden" name="gpsAccuracy" value={coords.accuracy} />
        </>
      )}

      <div style={gpsBoxStyle(gpsStatus)}>
        {gpsStatus === 'locating' && 'در حال گرفتن موقعیت مکانی...'}
        {gpsStatus === 'ok' && '✓ موقعیت مکانی ثبت شد'}
        {gpsStatus === 'denied' && '⚠ موقعیت مکانی در دسترس نیست — فرم بدون GPS هم ثبت می‌شه'}
      </div>

      <fieldset style={fieldsetStyle}>
        <legend style={legendStyle}>اطلاعات راننده و خودرو</legend>
        <div style={fieldStyle}>
          <label style={labelStyle}>نام و نام خانوادگی راننده</label>
          <input name="driverName" required style={inputStyle} />
        </div>
        <div style={fieldStyle}>
          <label style={labelStyle}>شماره موبایل راننده</label>
          <input name="driverPhone" required style={{ ...inputStyle, direction: 'ltr' }} />
        </div>
        <div style={fieldStyle}>
          <label style={labelStyle}>پلاک خودرو</label>
          <input name="vehiclePlate" required style={inputStyle} />
        </div>
        <div style={fieldStyle}>
          <label style={labelStyle}>نوع خودرو</label>
          <select name="vehicleType" required style={inputStyle}>
            <option value="">انتخاب کنید</option>
            <option value="truck">کامیون</option>
            <option value="trailer">تریلی</option>
            <option value="khavar">خاور</option>
            <option value="pickup">وانت</option>
          </select>
        </div>
      </fieldset>

      {type === 'unloading' && (
        <fieldset style={fieldsetStyle}>
          <legend style={legendStyle}>اطلاعات تحویل‌گیرنده</legend>
          <div style={fieldStyle}>
            <label style={labelStyle}>نام تحویل‌گیرنده</label>
            <input name="receiverName" required style={inputStyle} />
          </div>
          <div style={fieldStyle}>
            <label style={labelStyle}>سمت تحویل‌گیرنده</label>
            <select name="receiverRole" required style={inputStyle}>
              <option value="">انتخاب کنید</option>
              <option value="purchasing_manager">مدیر خرید</option>
              <option value="warehouse_keeper">انباردار</option>
              <option value="qc_officer">مسئول کنترل کیفیت</option>
              <option value="other">سایر</option>
            </select>
          </div>
        </fieldset>
      )}

      <fieldset style={fieldsetStyle}>
        <legend style={legendStyle}>وضعیت بار</legend>
        {checklist.map((item) => (
          <label key={item.key} style={checkboxRowStyle}>
            <input type="checkbox" name="checklist" value={item.key} style={{ width: 18, height: 18 }} />
            <span>{item.label}</span>
          </label>
        ))}
      </fieldset>

      <fieldset style={fieldsetStyle}>
        <legend style={legendStyle}>عکس</legend>
        <div style={{ fontSize: 11.5, color: '#9199a3', marginBottom: 8 }}>فقط یک تصویر کلی از بار کافیه.</div>
        <input type="file" name="photo" accept="image/*" capture="environment" required style={inputStyle} />
      </fieldset>

      <button type="submit" disabled={submitting} style={submitBtnStyle(submitting)}>
        {submitting ? 'در حال ثبت...' : type === 'loading' ? 'تایید بارگیری' : 'تایید تخلیه'}
      </button>
    </form>
  )
}

function gpsBoxStyle(status: string): React.CSSProperties {
  return {
    fontSize: 12.5, padding: '10px 14px', borderRadius: 8, textAlign: 'center', fontWeight: 600,
    background: status === 'ok' ? '#dcfce7' : status === 'denied' ? '#fef3c7' : '#eef4fd',
    color: status === 'ok' ? '#146c3a' : status === 'denied' ? '#92400e' : '#1e357b',
  }
}

const fieldsetStyle: React.CSSProperties = { border: '1px solid #e5e7eb', borderRadius: 10, padding: '14px 14px 6px', margin: 0 }
const legendStyle: React.CSSProperties = { fontSize: 12.5, fontWeight: 800, color: '#1e357b', padding: '0 6px' }
const fieldStyle: React.CSSProperties = { marginBottom: 12 }
const labelStyle: React.CSSProperties = { display: 'block', fontSize: 12, color: '#4f5560', marginBottom: 5, fontWeight: 600 }
const inputStyle: React.CSSProperties = { width: '100%', padding: '10px 12px', border: '1px solid #d8dde3', borderRadius: 8, fontSize: 14, fontFamily: 'inherit' }
const checkboxRowStyle: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, padding: '8px 0', borderBottom: '1px solid #f1efe8' }
function submitBtnStyle(submitting: boolean): React.CSSProperties {
  return {
    width: '100%', padding: '14px 0', background: submitting ? '#9199a3' : '#f6621b', color: '#fff',
    border: 'none', borderRadius: 10, fontSize: 15, fontWeight: 800, cursor: submitting ? 'default' : 'pointer',
  }
}
