import { NextRequest, NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { validateDriverToken } from '@/lib/driverAccess'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { token, latitude, longitude } = body

    if (!token || !latitude || !longitude) {
      return NextResponse.json({ error: 'فیلدهای الزامی ناقص است' }, { status: 400 })
    }

    // اعتبارسنجی توکن راننده
    const { valid, link } = await validateDriverToken(token)
    if (!valid || !link) {
      return NextResponse.json({ error: 'توکن نامعتبر است' }, { status: 401 })
    }

    const deal = link.deal

    // فقط اگه Deal در مرحله in_transit باشه، موقعیت رو آپدیت می‌کنیم
    if (deal.status !== 'in_transit') {
      return NextResponse.json({ error: 'معامله در مرحله‌ی حمل نیست' }, { status: 400 })
    }

    // آپدیت موقعیت
    await prisma.deal.update({
      where: { id: deal.id },
      data: {
        currentLatitude: latitude,
        currentLongitude: longitude,
        locationUpdatedAt: new Date(),
      },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Driver location update error:', error)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
