import { NextRequest, NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'

export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser()
    const body = await req.json()

    const {
      companyName,
      legalType,
      brandName,
      nationalId,
      registrationNumber,
      economicCode,
      taxNumber,
      foundedYear,
      province,
      city,
      address,
      postalCode,
      companyPhone,
      website,
    } = body

    // اعتبارسنجی companyName
    if (!companyName || companyName.trim().length < 2) {
      return NextResponse.json({ error: 'نام شرکت باید حداقل ۲ کاراکتر باشد' }, { status: 400 })
    }

    // آپدیت User.companyName
    await prisma.user.update({
      where: { id: user.id },
      data: { companyName: companyName.trim() },
    })

    // بررسی وجود رکورد Company
    const existingCompany = await prisma.company.findUnique({
      where: { userId: user.id },
    })

    if (existingCompany) {
      // آپدیت Company
      await prisma.company.update({
        where: { userId: user.id },
        data: {
          legalType: legalType || existingCompany.legalType,
          companyName: companyName.trim(),
          brandName: brandName?.trim() || null,
          nationalId: nationalId?.trim() || null,
          registrationNumber: registrationNumber?.trim() || null,
          economicCode: economicCode?.trim() || null,
          taxNumber: taxNumber?.trim() || null,
          foundedYear: foundedYear || null,
          province: province?.trim() || null,
          city: city?.trim() || null,
          address: address?.trim() || null,
          postalCode: postalCode?.trim() || null,
          companyPhone: companyPhone?.trim() || null,
          website: website?.trim() || null,
        },
      })
    } else if (legalType) {
      // ساخت رکورد جدید Company (فقط اگه legalType پر باشه)
      await prisma.company.create({
        data: {
          userId: user.id,
          legalType,
          companyName: companyName.trim(),
          brandName: brandName?.trim() || null,
          nationalId: nationalId?.trim() || null,
          registrationNumber: registrationNumber?.trim() || null,
          economicCode: economicCode?.trim() || null,
          taxNumber: taxNumber?.trim() || null,
          foundedYear: foundedYear || null,
          province: province?.trim() || null,
          city: city?.trim() || null,
          address: address?.trim() || null,
          postalCode: postalCode?.trim() || null,
          companyPhone: companyPhone?.trim() || null,
          website: website?.trim() || null,
        },
      })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Account update error:', error)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
