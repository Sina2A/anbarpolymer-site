'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'

type Company = {
  id: string
  legalType: string
  companyName: string
  brandName: string | null
  nationalId: string | null
  registrationNumber: string | null
  economicCode: string | null
  taxNumber: string | null
  foundedYear: number | null
  country: string
  province: string | null
  city: string | null
  address: string | null
  postalCode: string | null
  companyPhone: string | null
  website: string | null
} | null

type Props = {
  userId: string
  currentCompanyName: string
  company: Company
}

export default function AccountForm({ userId, currentCompanyName, company }: Props) {
  const router = useRouter()
  const [companyName, setCompanyName] = useState(currentCompanyName)
  const [formData, setFormData] = useState({
    legalType: company?.legalType ?? '',
    brandName: company?.brandName ?? '',
    nationalId: company?.nationalId ?? '',
    registrationNumber: company?.registrationNumber ?? '',
    economicCode: company?.economicCode ?? '',
    taxNumber: company?.taxNumber ?? '',
    foundedYear: company?.foundedYear?.toString() ?? '',
    province: company?.province ?? '',
    city: company?.city ?? '',
    address: company?.address ?? '',
    postalCode: company?.postalCode ?? '',
    companyPhone: company?.companyPhone ?? '',
    website: company?.website ?? '',
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)

  function handleChange(field: string, value: string) {
    setFormData((prev) => ({ ...prev, [field]: value }))
    setError('')
    setSuccess(false)
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')
    setSuccess(false)

    try {
      const res = await fetch('/api/account', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          companyName,
          ...formData,
          foundedYear: formData.foundedYear ? parseInt(formData.foundedYear) : null,
        }),
      })

      const json = await res.json()
      if (!res.ok) {
        setError(json.error ?? 'خطا در ذخیره — دوباره امتحان کن')
        return
      }

      setSuccess(true)
      router.refresh()
    } catch {
      setError('خطای شبکه — اتصال رو بررسی کن')
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} style={formStyle}>
      <div style={cardStyle}>
        <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 12 }}>اطلاعات پایه</div>

        <div style={fieldStyle}>
          <label style={labelStyle}>نام شرکت/سازمان *</label>
          <input
            type="text"
            value={companyName}
            onChange={(e) => setCompanyName(e.target.value)}
            required
            style={inputStyle}
            placeholder="نام شرکت خود را وارد کنید"
          />
        </div>

        {company && (
          <>
            <div style={fieldStyle}>
              <label style={labelStyle}>نوع فعالیت</label>
              <select
                value={formData.legalType}
                onChange={(e) => handleChange('legalType', e.target.value)}
                style={inputStyle}
              >
                <option value="">انتخاب کنید</option>
                <option value="factory">کارخانه</option>
                <option value="production_unit">واحد تولیدی</option>
                <option value="trading_company">شرکت بازرگانی</option>
                <option value="cooperative">تعاونی</option>
                <option value="official_agent">نمایندگی رسمی</option>
                <option value="importer">واردکننده</option>
                <option value="exporter">صادرکننده</option>
              </select>
            </div>

            <div style={fieldStyle}>
              <label style={labelStyle}>نام تجاری/برند</label>
              <input
                type="text"
                value={formData.brandName}
                onChange={(e) => handleChange('brandName', e.target.value)}
                style={inputStyle}
                placeholder="اختیاری"
              />
            </div>
          </>
        )}
      </div>

      {company && (
        <>
          <div style={cardStyle}>
            <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 12 }}>مشخصات ثبتی</div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 12 }}>
              <div style={fieldStyle}>
                <label style={labelStyle}>شناسه ملی</label>
                <input
                  type="text"
                  value={formData.nationalId}
                  onChange={(e) => handleChange('nationalId', e.target.value)}
                  style={inputStyle}
                  placeholder="11 رقم"
                />
              </div>

              <div style={fieldStyle}>
                <label style={labelStyle}>شماره ثبت</label>
                <input
                  type="text"
                  value={formData.registrationNumber}
                  onChange={(e) => handleChange('registrationNumber', e.target.value)}
                  style={inputStyle}
                />
              </div>

              <div style={fieldStyle}>
                <label style={labelStyle}>کد اقتصادی</label>
                <input
                  type="text"
                  value={formData.economicCode}
                  onChange={(e) => handleChange('economicCode', e.target.value)}
                  style={inputStyle}
                  placeholder="14 رقم"
                />
              </div>

              <div style={fieldStyle}>
                <label style={labelStyle}>شماره مالیاتی</label>
                <input
                  type="text"
                  value={formData.taxNumber}
                  onChange={(e) => handleChange('taxNumber', e.target.value)}
                  style={inputStyle}
                />
              </div>

              <div style={fieldStyle}>
                <label style={labelStyle}>سال تاسیس</label>
                <input
                  type="number"
                  value={formData.foundedYear}
                  onChange={(e) => handleChange('foundedYear', e.target.value)}
                  style={inputStyle}
                  placeholder="1400"
                  min="1300"
                  max="1410"
                />
              </div>
            </div>
          </div>

          <div style={cardStyle}>
            <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 12 }}>آدرس و تماس</div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 12, marginBottom: 12 }}>
              <div style={fieldStyle}>
                <label style={labelStyle}>استان</label>
                <input
                  type="text"
                  value={formData.province}
                  onChange={(e) => handleChange('province', e.target.value)}
                  style={inputStyle}
                  placeholder="تهران"
                />
              </div>

              <div style={fieldStyle}>
                <label style={labelStyle}>شهر</label>
                <input
                  type="text"
                  value={formData.city}
                  onChange={(e) => handleChange('city', e.target.value)}
                  style={inputStyle}
                  placeholder="تهران"
                />
              </div>

              <div style={fieldStyle}>
                <label style={labelStyle}>کد پستی</label>
                <input
                  type="text"
                  value={formData.postalCode}
                  onChange={(e) => handleChange('postalCode', e.target.value)}
                  style={inputStyle}
                  placeholder="10 رقم"
                  maxLength={10}
                />
              </div>
            </div>

            <div style={fieldStyle}>
              <label style={labelStyle}>آدرس کامل</label>
              <textarea
                value={formData.address}
                onChange={(e) => handleChange('address', e.target.value)}
                style={{ ...inputStyle, minHeight: 80, resize: 'vertical' }}
                placeholder="آدرس دقیق شرکت"
              />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 12 }}>
              <div style={fieldStyle}>
                <label style={labelStyle}>تلفن شرکت</label>
                <input
                  type="tel"
                  value={formData.companyPhone}
                  onChange={(e) => handleChange('companyPhone', e.target.value)}
                  style={inputStyle}
                  placeholder="021-12345678"
                />
              </div>

              <div style={fieldStyle}>
                <label style={labelStyle}>وب‌سایت</label>
                <input
                  type="url"
                  value={formData.website}
                  onChange={(e) => handleChange('website', e.target.value)}
                  style={inputStyle}
                  placeholder="https://example.com"
                  dir="ltr"
                />
              </div>
            </div>
          </div>
        </>
      )}

      {error && <div style={errorStyle}>{error}</div>}
      {success && <div style={successStyle}>✓ تغییرات با موفقیت ذخیره شد</div>}

      <button type="submit" disabled={loading} style={{ ...submitBtn, opacity: loading ? 0.7 : 1 }}>
        {loading ? 'در حال ذخیره…' : 'ذخیره تغییرات'}
      </button>
    </form>
  )
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const formStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 14,
}
const cardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 18,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const fieldStyle: React.CSSProperties = {
  marginBottom: 12,
}
const labelStyle: React.CSSProperties = {
  display: 'block',
  fontSize: 12.5,
  fontWeight: 600,
  color: '#4f5560',
  marginBottom: 6,
}
const inputStyle: React.CSSProperties = {
  width: '100%',
  padding: '10px 12px',
  border: '1px solid #d8dde3',
  borderRadius: 8,
  fontSize: 13,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  background: '#fff',
}
const errorStyle: React.CSSProperties = {
  padding: '12px 16px',
  background: '#fee2e2',
  color: '#991b1b',
  borderRadius: 8,
  fontSize: 13,
  fontWeight: 600,
}
const successStyle: React.CSSProperties = {
  padding: '12px 16px',
  background: '#d1fae5',
  color: '#065f46',
  borderRadius: 8,
  fontSize: 13,
  fontWeight: 600,
}
const submitBtn: React.CSSProperties = {
  padding: '12px 24px',
  background: '#e65716',
  color: '#fff',
  border: 'none',
  borderRadius: 8,
  fontSize: 14,
  fontWeight: 700,
  cursor: 'pointer',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  alignSelf: 'flex-start',
}
