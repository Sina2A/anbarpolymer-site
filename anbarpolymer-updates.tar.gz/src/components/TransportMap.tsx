'use client'

import { useEffect, useState } from 'react'
import dynamic from 'next/dynamic'

// Leaflet فقط در کلاینت کار می‌کنه — SSR ندارد
const MapContainer = dynamic(() => import('react-leaflet').then((m) => m.MapContainer), { ssr: false })
const TileLayer = dynamic(() => import('react-leaflet').then((m) => m.TileLayer), { ssr: false })
const Marker = dynamic(() => import('react-leaflet').then((m) => m.Marker), { ssr: false })
const Popup = dynamic(() => import('react-leaflet').then((m) => m.Popup), { ssr: false })

type Deal = {
  id: string
  quantity: string
  currentLatitude: number | null
  currentLongitude: number | null
  locationUpdatedAt: Date | null
  materialListing: {
    grade: {
      productName: string
    }
  } | null
  driverLinks: Array<{
    driverName: string | null
    vehiclePlate: string | null
  }>
}

export default function TransportMap({ deals }: { deals: Deal[] }) {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return <div style={loadingStyle}>در حال بارگذاری نقشه...</div>
  }

  // فیلتر Deal هایی که موقعیت دارن
  const dealsWithLocation = deals.filter((d) => d.currentLatitude && d.currentLongitude)

  if (dealsWithLocation.length === 0) {
    return (
      <div style={cardStyle}>
        <div style={{ fontSize: 14, color: '#9199a3', textAlign: 'center', padding: 20 }}>
          هیچ محموله‌ای با موقعیت فعال وجود ندارد.
          <div style={{ fontSize: 12, marginTop: 8 }}>
            (موقعیت زمانی ثبت می‌شود که راننده صفحه‌ی تایید بارگیری را باز داشته باشد)
          </div>
        </div>
      </div>
    )
  }

  // مرکز نقشه — میانگین موقعیت‌ها
  const centerLat = dealsWithLocation.reduce((sum, d) => sum + (d.currentLatitude ?? 0), 0) / dealsWithLocation.length
  const centerLng = dealsWithLocation.reduce((sum, d) => sum + (d.currentLongitude ?? 0), 0) / dealsWithLocation.length

  return (
    <div style={containerStyle}>
      <div style={mapStyle}>
        <MapContainer
          center={[centerLat, centerLng]}
          zoom={dealsWithLocation.length === 1 ? 13 : 10}
          style={{ width: '100%', height: '100%' }}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          {dealsWithLocation.map((deal) => (
            <Marker key={deal.id} position={[deal.currentLatitude!, deal.currentLongitude!]}>
              <Popup>
                <div style={{ fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', fontSize: 12 }}>
                  <div style={{ fontWeight: 700, marginBottom: 4 }}>
                    {deal.materialListing?.grade.productName ?? 'محموله'}
                  </div>
                  <div style={{ fontSize: 11, color: '#6b7280' }}>
                    مقدار: {deal.quantity}
                  </div>
                  {deal.driverLinks[0]?.driverName && (
                    <div style={{ fontSize: 11, color: '#6b7280', marginTop: 4 }}>
                      راننده: {deal.driverLinks[0].driverName}
                    </div>
                  )}
                  {deal.driverLinks[0]?.vehiclePlate && (
                    <div style={{ fontSize: 11, color: '#6b7280' }}>
                      پلاک: {deal.driverLinks[0].vehiclePlate}
                    </div>
                  )}
                  {deal.locationUpdatedAt && (
                    <div style={{ fontSize: 10, color: '#9199a3', marginTop: 6, fontStyle: 'italic' }}>
                      آخرین به‌روزرسانی: {new Date(deal.locationUpdatedAt).toLocaleString('fa-IR')}
                    </div>
                  )}
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>
      </div>

      {/* پنل اطلاعات کناری */}
      <div style={sidebarStyle}>
        <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 12 }}>محموله‌های فعال</div>
        {dealsWithLocation.map((deal) => (
          <div key={deal.id} style={dealCardStyle}>
            <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 6 }}>
              {deal.materialListing?.grade.productName ?? 'محموله'}
            </div>
            <div style={{ fontSize: 11, color: '#6b7280', marginBottom: 4 }}>
              مقدار: {deal.quantity}
            </div>
            {deal.driverLinks[0] && (
              <>
                {deal.driverLinks[0].driverName && (
                  <div style={{ fontSize: 11, color: '#4f5560' }}>
                    راننده: {deal.driverLinks[0].driverName}
                  </div>
                )}
                {deal.driverLinks[0].vehiclePlate && (
                  <div style={{ fontSize: 11, color: '#4f5560' }}>
                    پلاک: {deal.driverLinks[0].vehiclePlate}
                  </div>
                )}
              </>
            )}
            {deal.locationUpdatedAt && (
              <div style={{ fontSize: 10, color: '#9199a3', marginTop: 6, fontStyle: 'italic' }}>
                {new Date(deal.locationUpdatedAt).toLocaleString('fa-IR')}
              </div>
            )}
          </div>
        ))}
        <div style={{ fontSize: 11, color: '#9199a3', marginTop: 12, padding: '8px 10px', background: '#fef3c7', borderRadius: 6 }}>
          ⓘ موقعیت فقط زمانی به‌روز می‌شود که مرورگر راننده باز و صفحه فعال باشد (تب پس‌زمینه یا قفل گوشی، ارسال را متوقف می‌کند).
        </div>
      </div>
    </div>
  )
}

const containerStyle: React.CSSProperties = {
  display: 'flex',
  gap: 14,
  border: '1px solid #d8dde3',
  borderRadius: 12,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
  overflow: 'hidden',
  minHeight: 500,
}
const mapStyle: React.CSSProperties = {
  flex: 1,
  minHeight: 500,
  position: 'relative',
}
const sidebarStyle: React.CSSProperties = {
  width: 280,
  padding: 16,
  background: '#faf8f4',
  overflowY: 'auto',
  borderLeft: '1px solid #e8e4db',
}
const dealCardStyle: React.CSSProperties = {
  padding: 12,
  background: '#fff',
  border: '1px solid #e8e4db',
  borderRadius: 8,
  marginBottom: 10,
}
const loadingStyle: React.CSSProperties = {
  padding: 40,
  textAlign: 'center',
  fontSize: 13,
  color: '#9199a3',
  border: '1px solid #d8dde3',
  borderRadius: 12,
  background: '#fff',
}
const cardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
