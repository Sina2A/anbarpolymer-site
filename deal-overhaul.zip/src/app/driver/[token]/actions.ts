'use server'

import prisma from '@/lib/prisma'
import { validateDriverToken, markDriverLinkUsed } from '@/lib/driverAccess'
import { startPostUnloadingClocks } from '@/lib/dealDeadlines'
import fs from 'fs/promises'
import path from 'path'
import crypto from 'crypto'
import { redirect } from 'next/navigation'

const UPLOAD_ROOT = path.join(process.cwd(), 'public', 'uploads', 'deals')

/**
 * ذخیره‌ی عکس روی دیسک محلی سرور (نه فضای ابری) — چون هنوز فاز Storage
 * واقعی نساختیم. برای همین حجم فعلی کاملاً کافیه؛ وقتی حجم بار زیاد شد،
 * این تابع باید با یه سرویس ابری جایگزین بشه (فقط همین یه تابع، بقیه‌ی
 * کد دست‌نخورده می‌مونه چون همه‌جا فقط از photoUrl استفاده می‌کنن).
 */
async function savePhotoToLocalDisk(dealId: string, file: File): Promise<string> {
  const dealDir = path.join(UPLOAD_ROOT, dealId)
  await fs.mkdir(dealDir, { recursive: true })

  const ext = (file.name.split('.').pop() || 'jpg').toLowerCase().replace(/[^a-z0-9]/g, '') || 'jpg'
  const fileName = `${Date.now()}-${crypto.randomBytes(4).toString('hex')}.${ext}`
  const filePath = path.join(dealDir, fileName)

  const buffer = Buffer.from(await file.arrayBuffer())
  await fs.writeFile(filePath, buffer)

  return `/uploads/deals/${dealId}/${fileName}`
}

export async function submitDealConfirmation(formData: FormData) {
  const token = String(formData.get('token') || '')
  const type = String(formData.get('type') || '') // loading | unloading

  const { valid, link } = await validateDriverToken(token)
  if (!valid || !link) {
    throw new Error('لینک نامعتبر یا منقضی‌شده — فرم ثبت نشد.')
  }

  const dealId = link.dealId

  // دروازه‌ی بارگیری: تا وقتی حسابداری پرداخت خریدار رو تایید نکرده،
  // بارگیری اصلاً نباید شروع بشه — طبق تصمیم صریح سینا.
  if (type === 'loading') {
    const deal = await prisma.deal.findUnique({ where: { id: dealId } })
    if (deal?.escrowStatus !== 'secured_manual') {
      throw new Error('پرداخت خریدار هنوز توسط حسابداری تایید نشده — بارگیری قابل ثبت نیست.')
    }
  }

  const driverName = String(formData.get('driverName') || '').trim()
  const driverPhone = String(formData.get('driverPhone') || '').trim()
  const vehiclePlate = String(formData.get('vehiclePlate') || '').trim()
  const vehicleType = String(formData.get('vehicleType') || '')
  const receiverName = String(formData.get('receiverName') || '').trim()
  const receiverRole = String(formData.get('receiverRole') || '')

  const latitude = formData.get('latitude') ? parseFloat(String(formData.get('latitude'))) : null
  const longitude = formData.get('longitude') ? parseFloat(String(formData.get('longitude'))) : null
  const gpsAccuracy = formData.get('gpsAccuracy') ? parseFloat(String(formData.get('gpsAccuracy'))) : null

  // چک‌لیست: هر آیتمی که توی فرم تیک خورده، از formData میاد (checkbox های هم‌نام)
  const checklistItems = formData.getAll('checklist') as string[]
  const checklistJson = JSON.stringify(checklistItems.reduce((acc, key) => ({ ...acc, [key]: true }), {}))

  let photoUrl: string | null = null
  const photoFile = formData.get('photo') as File | null
  if (photoFile && photoFile.size > 0) {
    photoUrl = await savePhotoToLocalDisk(dealId, photoFile)
  }

  const confirmedAt = new Date()

  await prisma.dealConfirmation.create({
    data: {
      dealId,
      type,
      confirmedAt,
      driverName: driverName || null,
      driverPhone: driverPhone || null,
      vehiclePlate: vehiclePlate || null,
      vehicleType: vehicleType || null,
      receiverName: receiverName || null,
      receiverRole: receiverRole || null,
      checklistJson,
      photoUrl,
      latitude,
      longitude,
      gpsAccuracy,
    },
  })

  // با تایید تخلیه، دو تایمر مستقل (گزارش مغایرت ۴ساعته + واریز وجه ۸ساعته)
  // شروع می‌شه — بار پیش‌فرض «بدون مغایرت» فرض می‌شه، نیازی به تایید فعال
  // خریدار نیست، فقط امکان گزارش مشکل در همون بازه.
  if (type === 'unloading') {
    await startPostUnloadingClocks(dealId, confirmedAt)
  }

  // آپدیت وضعیت کلی معامله متناسب با نوع رویداد.
  // توجه: تایم‌لاین خودِ Deal همین رکوردهای DealConfirmation هستن (هرکدوم با
  // زمان دقیق) — نیازی به دوباره‌نویسی توی StatusEvent نیست، چون آن سیستم
  // برای Order/MaterialListing/SupportTicket طراحی شده، نه Deal.
  // توجه: وضعیت «delivered» رو startPostUnloadingClocks خودش ست می‌کنه.
  if (type === 'loading') {
    await prisma.deal.update({ where: { id: dealId }, data: { status: 'in_transit' } })
  }

  await markDriverLinkUsed(token)

  redirect(`/driver/${token}/done`)
}
