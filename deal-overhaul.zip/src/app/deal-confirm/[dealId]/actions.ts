'use server'

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { submitDiscrepancyReport, SEVERE_DISCREPANCY_ITEMS, MINOR_DISCREPANCY_ITEMS } from '@/lib/disputes'
import { redirect } from 'next/navigation'

export async function submitDiscrepancy(formData: FormData) {
  const user = await getCurrentUser()
  const dealId = String(formData.get('dealId'))
  const note = String(formData.get('note') || '').trim()
  const selectedItems = formData.getAll('items') as string[]

  const deal = await prisma.deal.findUnique({ where: { id: dealId } })
  if (!deal) throw new Error('معامله پیدا نشد.')
  if (deal.buyerId !== user.id) throw new Error('این معامله مال شما نیست.')
  if (selectedItems.length === 0) throw new Error('حداقل یک مورد مغایرت رو انتخاب کن.')

  const validItems = [...SEVERE_DISCREPANCY_ITEMS, ...MINOR_DISCREPANCY_ITEMS]
  const filtered = selectedItems.filter((i) => validItems.includes(i))

  await submitDiscrepancyReport({ dealId, raisedById: user.id, selectedItems: filtered, note })

  redirect('/my-orders')
}
