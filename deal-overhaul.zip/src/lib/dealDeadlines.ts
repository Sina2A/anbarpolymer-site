import prisma from './prisma'
import { calculateBusinessHoursDeadline } from './businessHours'

const RESTRICTION_HOURS = 24
const SELLER_FEE_DEADLINE_HOURS = 24 // ساعت‌کاری
const BUYER_PAYMENT_DEADLINE_HOURS = 72 // ساعت‌کاری
const DISCREPANCY_REPORT_HOURS = 4 // ساعت‌کاری، از لحظه‌ی تخلیه
const FUND_RELEASE_HOURS = 8 // ساعت‌کاری، از لحظه‌ی تخلیه
const DRIVER_SILENCE_DAYS = 5 // تقویمی، نه ساعت‌کاری — چون حمل جاده‌ای توی تعطیلات هم ادامه داره

/**
 * این تابع رو باید هر جا صفحه‌ی مرتبط لود می‌شه صدا زد (بازار صنعتی، پنل کاربری، پنل ادمین).
 * چون هنوز job scheduler/cron جدا نداریم، به‌جاش هر بار که یکی از این صفحات باز می‌شه،
 * این تابع خودش چک می‌کنه آیا مهلتی گذشته یا نه — یه الگوی ساده و رایج برای MVP،
 * بدون نیاز به زیرساخت جداگانه.
 */
export async function enforceDealDeadlines() {
  const sellerExpired = await enforceSellerFeeDeadlines()
  const buyerExpired = await enforceBuyerPaymentDeadlines()
  const discrepancyWindowClosed = await enforceDiscrepancyWindowClose()
  const driverSilenceFlagged = await enforceDriverSilenceEscalation()
  return {
    cancelledCount: sellerExpired + buyerExpired,
    qualityAutoAcceptedCount: discrepancyWindowClosed,
    driverSilenceFlaggedCount: driverSilenceFlagged,
  }
}

/**
 * فروشنده کارمزد رو سر وقت (۲۴ساعت‌کاری) نداده → آگهی به‌جای بازگشت فوری به
 * بازار، می‌ره تو حالت «نیازمند بررسی مجدد» (needs_reverification) — چون
 * ممکنه موجودی فروشنده واقعاً عوض شده باشه و بازگردوندنِ کورکورانه‌ش به بازار
 * یه رزرو شکست‌خورده‌ی دیگه بسازه. کارشناس باید دستی تایید کنه قبل از این‌که
 * دوباره قابل‌رزرو بشه.
 */
async function enforceSellerFeeDeadlines() {
  const now = new Date()
  const overdue = await prisma.materialListing.findMany({
    where: {
      feeStatus: 'unpaid',
      feeDeadline: { lt: now },
      validityStatus: 'reserved',
    },
  })

  for (const listing of overdue) {
    await prisma.materialListing.update({
      where: { id: listing.id },
      data: { validityStatus: 'needs_reverification', feeDeadline: null },
    })

    await prisma.user.update({
      where: { id: listing.userId },
      data: {
        restrictedUntil: new Date(now.getTime() + RESTRICTION_HOURS * 60 * 60 * 1000),
        restrictionReason: 'کارمزد فروش را ظرف مهلت مقرر پرداخت نکرد',
      },
    })

    // هر Deal مرتبط با این آگهی که هنوز باز بود، لغو می‌شه
    await prisma.deal.updateMany({
      where: { materialListingId: listing.id, status: { in: ['draft', 'confirmed'] } },
      data: { status: 'cancelled' },
    })
  }

  return overdue.length
}

/**
 * خریدار بعد از تایید، پرداخت کامل رو تکمیل نکرده (ظرف ۷۲ساعت‌کاری) → همون
 * اتفاق برای خریدار می‌افته: رزرو کنسل، آگهی آزاد می‌شه.
 */
async function enforceBuyerPaymentDeadlines() {
  const now = new Date()
  const overdue = await prisma.deal.findMany({
    where: {
      status: 'confirmed',
      escrowStatus: 'pending',
      buyerConfirmDeadline: { lt: now },
    },
    include: { materialListing: true },
  })

  for (const deal of overdue) {
    await prisma.deal.update({
      where: { id: deal.id },
      data: { status: 'cancelled' },
    })

    if (deal.materialListingId) {
      await prisma.materialListing.update({
        where: { id: deal.materialListingId },
        data: { validityStatus: 'active' },
      })
    }

    await prisma.user.update({
      where: { id: deal.buyerId },
      data: {
        restrictedUntil: new Date(now.getTime() + RESTRICTION_HOURS * 60 * 60 * 1000),
        restrictionReason: 'رزرو را تایید کرد ولی پرداخت را ظرف مهلت مقرر تکمیل نکرد',
      },
    })
  }

  return overdue.length
}

/**
 * وقتی راننده «تایید تخلیه» رو ثبت می‌کنه، این رو صدا بزن. از همین لحظه دو
 * تایمر مستقل شروع می‌شه — بار به‌صورت پیش‌فرض «تحویل‌شده و بدون مغایرت»
 * فرض می‌شه (دیگه نیاز به تایید فعال خریدار نیست، فقط امکان گزارش مشکل).
 */
export async function startPostUnloadingClocks(dealId: string, unloadingConfirmedAt: Date) {
  const [discrepancyDeadline, releaseDeadline] = await Promise.all([
    calculateBusinessHoursDeadline(unloadingConfirmedAt, DISCREPANCY_REPORT_HOURS),
    calculateBusinessHoursDeadline(unloadingConfirmedAt, FUND_RELEASE_HOURS),
  ])
  await prisma.deal.update({
    where: { id: dealId },
    data: {
      status: 'delivered',
      discrepancyReportDeadline: discrepancyDeadline,
      fundReleaseDeadline: releaseDeadline,
    },
  })
  return { discrepancyDeadline, releaseDeadline }
}

/**
 * پایان مهلت ۴ساعته‌ی گزارش مغایرت: اگه خریدار هیچ مغایرتی (نه جزئی، نه حساس)
 * ثبت نکرده باشه، سیستم خودش auto_no_discrepancy رو ثبت می‌کنه — صرفاً برای
 * شفافیت تاریخچه، نه چون خریدار کاری کرده. مهلت ۸ساعته‌ی واریز جدا محاسبه
 * شده و اینجا دست‌کاری نمی‌شه؛ فقط اگه بین این دو لحظه مغایرتِ «حساس» ثبت
 * بشه، fundReleaseFrozen توسط submitDiscrepancyReport ست می‌شه.
 */
async function enforceDiscrepancyWindowClose() {
  const now = new Date()
  const overdue = await prisma.deal.findMany({
    where: {
      discrepancyReportDeadline: { lt: now },
      status: 'delivered',
      qualityAutoAccepted: false,
    },
    include: { confirmations: true },
  })

  let count = 0
  for (const deal of overdue) {
    const alreadyReported = deal.confirmations.some((c) => c.type === 'buyer_confirm')
    if (alreadyReported) {
      await prisma.deal.update({ where: { id: deal.id }, data: { qualityAutoAccepted: true } })
      continue
    }

    await prisma.dealConfirmation.create({
      data: {
        dealId: deal.id,
        type: 'buyer_confirm',
        finalVerdict: 'auto_no_discrepancy',
        checklistJson: '{}',
      },
    })
    await prisma.deal.update({
      where: { id: deal.id },
      data: { qualityAutoAccepted: true },
    })
    count++
  }
  return count
}

/**
 * اگه راننده بعد از «تایید بارگیری» تا ۵ روز تقویمی هیچ رویداد دیگه‌ای
 * (تخلیه یا هرچی) ثبت نکنه، این پرچم می‌خوره — علامت قرمز فسفری توی
 * admin-logistics و نوتیف به خریدار/فروشنده که «منتظر تایید کارشناسه».
 * تقویمی حساب می‌شه (نه ساعت‌کاری) چون حمل جاده‌ای توی تعطیلات هم جریان داره.
 */
async function enforceDriverSilenceEscalation() {
  const now = new Date()
  const cutoff = new Date(now.getTime() - DRIVER_SILENCE_DAYS * 24 * 60 * 60 * 1000)

  const inTransitDeals = await prisma.deal.findMany({
    where: { status: 'in_transit', driverSilenceFlaggedAt: null },
    include: { confirmations: { orderBy: { confirmedAt: 'desc' } } },
  })

  let count = 0
  for (const deal of inTransitDeals) {
    const lastEvent = deal.confirmations[0]
    if (lastEvent && lastEvent.confirmedAt < cutoff) {
      await prisma.deal.update({
        where: { id: deal.id },
        data: { driverSilenceFlaggedAt: now },
      })
      count++
    }
  }
  return count
}

/** برای چک‌کردن قبل از اجازه دادن به ثبت آگهی/رزرو جدید */
export async function isUserRestricted(userId: string) {
  const user = await prisma.user.findUnique({ where: { id: userId } })
  if (!user?.restrictedUntil) return { restricted: false as const }
  if (user.restrictedUntil < new Date()) return { restricted: false as const }
  return { restricted: true as const, until: user.restrictedUntil, reason: user.restrictionReason }
}

/** موقع تایید ادمین روی یه رزرو، این رو صدا بزن تا مهلت کارمزد فروشنده (۲۴ساعت‌کاری) شروع بشه */
export async function startSellerFeeDeadline(materialListingId: string) {
  const deadline = await calculateBusinessHoursDeadline(new Date(), SELLER_FEE_DEADLINE_HOURS)
  await prisma.materialListing.update({
    where: { id: materialListingId },
    data: { validityStatus: 'reserved', feeDeadline: deadline },
  })
  return deadline
}

/** موقع تایید کارمزد فروشنده، این رو صدا بزن تا مهلت پرداخت کامل خریدار (۷۲ساعت‌کاری) شروع بشه */
export async function startBuyerPaymentDeadline(dealId: string) {
  const deadline = await calculateBusinessHoursDeadline(new Date(), BUYER_PAYMENT_DEADLINE_HOURS)
  await prisma.deal.update({
    where: { id: dealId },
    data: { status: 'confirmed', buyerConfirmDeadline: deadline },
  })
  return deadline
}
