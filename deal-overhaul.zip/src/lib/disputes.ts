import prisma from './prisma'

/**
 * موارد مغایرت — طبقه‌بندی‌شده به دو سطح، طبق تصمیم صریح سینا:
 *   حساس: باید معامله متوقف و بررسی بشه (کسری وزن زیاد، بسته‌بندی خراب و...)
 *   جزئی: فقط ثبت می‌شه برای سابقه، ولی جلوی واریز خودکار رو نمی‌گیره
 * این لیست‌ها هم توی فرم خریدار و هم موقع تفسیر گزارش استفاده می‌شن.
 */
export const SEVERE_DISCREPANCY_ITEMS = [
  'کسری وزن بیش از ۵۰ کیلوگرم',
  'عدم بسته‌بندی کامل یا صحیح',
  'گرید یا نوع محصول با سفارش مطابقت ندارد',
  'شواهد آشکار تقلب یا جعل مدارک',
]

export const MINOR_DISCREPANCY_ITEMS = [
  'کسری وزن کمتر از ۱ کیلوگرم',
  'باز شدن شیرینک بسته‌بندی',
  'شکستگی جزئی پالت',
  'خیس‌شدگی سطحی ناشی از باران',
]

/**
 * خریدار توی پنجره‌ی ۴ساعته یه مغایرت گزارش کرده. اگه حتی یکی از موارد
 * انتخاب‌شده «حساس» باشه، کل گزارش حساس تلقی می‌شه: تایمر واریز فریز می‌شه
 * و یه Dispute واقعی باز می‌شه. اگه فقط موارد جزئی باشن، صرفاً ثبت می‌شه —
 * نه فریز، نه Dispute — چون این‌جور مشکلات جلوی جریان معامله رو نمی‌گیرن.
 */
export async function submitDiscrepancyReport(params: {
  dealId: string
  raisedById: string
  selectedItems: string[]
  note: string
}) {
  const { dealId, raisedById, selectedItems, note } = params
  const isSevere = selectedItems.some((item) => SEVERE_DISCREPANCY_ITEMS.includes(item))
  const severity = isSevere ? 'severe' : 'minor'

  await prisma.dealConfirmation.create({
    data: {
      dealId,
      type: 'buyer_confirm',
      finalVerdict: isSevere ? 'discrepancy_severe' : 'discrepancy_minor',
      discrepancySeverity: severity,
      discrepancyItemsJson: JSON.stringify(selectedItems),
      discrepancyNote: note || null,
      checklistJson: '{}',
    },
  })

  await prisma.deal.update({
    where: { id: dealId },
    data: {
      qualityAutoAccepted: true, // یعنی پنجره‌ی گزارش بسته شد (چه با خبر چه بی‌خبر)
      fundReleaseFrozen: isSevere,
    },
  })

  if (isSevere) {
    await prisma.dispute.create({
      data: {
        dealId,
        raisedById,
        reason: `مغایرت حساس گزارش‌شده توسط خریدار: ${selectedItems.join('، ')}${note ? ' — ' + note : ''}`,
        status: 'open',
      },
    })
  }

  return { severity }
}

/**
 * وقتی تاییدیه‌ی نهایی خریدار «مغایرت دارد» یا «رد» باشه، این تابع خودکار
 * یه Dispute باز می‌کنه — قبلاً فقط یه چک‌باکس بود که «بعدش چی می‌شه»
 * نداشت؛ الان یه رکورد واقعی می‌سازه که ادمین می‌تونه پیگیریش کنه.
 *
 * @deprecated این تابع مربوط به مدل قدیمی «تایید فعال خریدار» بود. با
 * جایگزینی با submitDiscrepancyReport، دیگه توی مسیر اصلی صدا زده نمی‌شه،
 * ولی برای سازگاری با هر کد قدیمی‌تر نگه داشته شده.
 */
export async function raiseDisputeIfNeeded(params: {
  dealId: string
  raisedById: string
  finalVerdict: string | null
}) {
  if (params.finalVerdict !== 'accept_with_discrepancy' && params.finalVerdict !== 'reject') {
    return null
  }

  const reason =
    params.finalVerdict === 'reject'
      ? 'خریدار تحویل بار را رد کرد'
      : 'خریدار بار را با مغایرت تایید کرد'

  return prisma.dispute.create({
    data: {
      dealId: params.dealId,
      raisedById: params.raisedById,
      reason,
      status: 'open',
    },
  })
}

export async function resolveDispute(params: {
  disputeId: string
  resolvedById: string
  resolution: string
  status: 'resolved' | 'rejected'
}) {
  return prisma.dispute.update({
    where: { id: params.disputeId },
    data: {
      status: params.status,
      resolution: params.resolution,
      resolvedById: params.resolvedById,
      resolvedAt: new Date(),
    },
  })
}
