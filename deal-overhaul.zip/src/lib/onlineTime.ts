/**
 * دریافت ساعت دقیق از یه سرویس بیرونی — برای اطمینان از این‌که محاسبه‌ی
 * مهلت‌ها به ساعت خودِ سرور (که ممکنه اشتباه تنظیم شده باشه، یا UTC باشه نه
 * Asia/Tehran) وابسته نباشه.
 *
 * طراحی عمداً بسیار محافظه‌کارانه‌ست: تایم‌اوت کوتاه (۳ ثانیه)، try/catch کامل،
 * و در هر خطایی (شبکه قطع، سرویس در دسترس نیست، پاسخ نامعتبر) بی‌صدا به ساعت
 * محلی سرور برمی‌گرده. **هیچ‌وقت نباید جلوی هیچ فرآیندی رو بگیره یا خطا پرت
 * کنه** — این تابع فقط یه «بهترین تلاش» برای دقت بیشتره، نه یه وابستگی حیاتی.
 */
export async function getReliableNow(): Promise<Date> {
  try {
    const controller = new AbortController()
    const timeout = setTimeout(() => controller.abort(), 3000)

    const res = await fetch('https://worldtimeapi.org/api/timezone/Asia/Tehran', {
      signal: controller.signal,
      cache: 'no-store',
    })
    clearTimeout(timeout)

    if (!res.ok) return new Date()

    const data = await res.json()
    const iso = data?.datetime
    if (!iso) return new Date()

    const parsed = new Date(iso)
    if (Number.isNaN(parsed.getTime())) return new Date()

    return parsed
  } catch {
    // هر نوع خطا (تایم‌اوت، قطعی شبکه، سرویس خارجی مشکل داره) → بی‌صدا fallback
    return new Date()
  }
}

/**
 * چقدر ساعت سرور با ساعت آنلاین فرق داره (به میلی‌ثانیه) — فقط برای مانیتورینگ/
 * هشدار به مدیر، نه برای مصرف مستقیم توی محاسبات (چون خودش هم می‌تونه fallback
 * بخوره و گمراه‌کننده بشه).
 */
export async function getServerClockDriftMs(): Promise<number | null> {
  try {
    const before = Date.now()
    const online = await getReliableNow()
    const after = Date.now()
    // اگه fetch واقعاً انجام نشده باشه (fallback به new Date() خورده)، تشخیص
    // قابل‌اعتمادی نداریم — null برمی‌گردونیم به‌جای عدد گمراه‌کننده
    const roundTrip = after - before
    if (roundTrip > 2900) return null // احتمالاً fallback خورده (نزدیک تایم‌اوت)
    return online.getTime() - Math.round((before + after) / 2)
  } catch {
    return null
  }
}
