import prisma from './prisma'

/**
 * موتور محاسبه‌ی مهلت بر اساس «ساعت کاری» — نه روز تقویمی، نه ساعت تقویمی خام.
 *
 * اولویت‌بندی (طبق تصمیم صریح سینا):
 *   ۱. جدول Holiday — یه روز خاص با تاریخ مشخص، همیشه حرف آخر رو می‌زنه.
 *      اگه یه روز اونجا ثبت شده باشه (چه جمعه چه نه)، کل اون روز غیرکاریه.
 *   ۲. اگه روز توی Holiday نبود، جدول WeeklyBusinessHour (الگوی تکرارشونده‌ی
 *      هرهفته) تعیین می‌کنه اون روز از هفته اصلاً بازه یا نه، و از ساعت چند
 *      تا ساعت چند.
 *
 * محاسبه‌ی «N ساعت کاری از X» یعنی: از لحظه‌ی X شروع کن، فقط بازه‌های باز
 * (طبق قانون بالا) رو بشمار، و هروقت N ساعت واقعی سپری شد، همون لحظه مهلته.
 */

function pad2(n: number) {
  return String(n).padStart(2, '0')
}
function dateKey(d: Date): string {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`
}
function parseHM(hm: string): { h: number; m: number } {
  const [h, m] = hm.split(':').map((x) => parseInt(x, 10))
  return { h: h || 0, m: m || 0 }
}

type DaySchedule = { isOpen: boolean; openTime: string; closeTime: string }

async function loadCalendars() {
  const [holidays, weekly] = await Promise.all([
    prisma.holiday.findMany(),
    prisma.weeklyBusinessHour.findMany(),
  ])
  const holidaySet = new Set(holidays.map((h) => dateKey(h.date)))
  const weeklyMap = new Map<number, DaySchedule>()
  for (const w of weekly) {
    weeklyMap.set(w.dayOfWeek, { isOpen: w.isOpen, openTime: w.openTime, closeTime: w.closeTime })
  }
  return { holidaySet, weeklyMap }
}

/** برای یه روز مشخص، بازه‌ی بازبودنش رو برمی‌گردونه (یا null اگه کلاً تعطیله). */
function getDaySchedule(
  day: Date,
  holidaySet: Set<string>,
  weeklyMap: Map<number, DaySchedule>
): { start: Date; end: Date } | null {
  if (holidaySet.has(dateKey(day))) return null // اولویت با Holiday

  const w = weeklyMap.get(day.getDay())
  // اگه هنوز هیچ تنظیمی برای این روز هفته ثبت نشده، پیش‌فرض امن: باز، ۸ تا ۱۷
  const schedule = w ?? { isOpen: true, openTime: '08:00', closeTime: '17:00' }
  if (!schedule.isOpen) return null

  const { h: oh, m: om } = parseHM(schedule.openTime)
  const { h: ch, m: cm } = parseHM(schedule.closeTime)
  const start = new Date(day)
  start.setHours(oh, om, 0, 0)
  const end = new Date(day)
  end.setHours(ch, cm, 0, 0)
  if (end <= start) return null // تنظیم نامعتبر — رفتار امن: بسته حساب کن
  return { start, end }
}

/**
 * از لحظه‌ی `start`، `hours` ساعتِ کاری واقعی جلو می‌ره و لحظه‌ی دقیق مهلت رو
 * برمی‌گردونه. اگه `start` خودش بیرون از ساعت کاری باشه (مثلاً نصف‌شب یا روز
 * تعطیل)، اول به نزدیک‌ترین لحظه‌ی باز بعدی می‌پره.
 */
export async function calculateBusinessHoursDeadline(start: Date, hours: number): Promise<Date> {
  const { holidaySet, weeklyMap } = await loadCalendars()

  let remainingMs = hours * 60 * 60 * 1000
  let cursor = new Date(start)
  let cursorDay = new Date(cursor)
  cursorDay.setHours(0, 0, 0, 0)

  // محافظ ضد حلقه‌ی بی‌نهایت (مثلاً اگه همه‌ی روزها اشتباهاً بسته تنظیم شده باشن)
  let safety = 0
  const SAFETY_LIMIT = 400 // بیشتر از یه سال روزانه، کافیه

  while (remainingMs > 0) {
    safety += 1
    if (safety > SAFETY_LIMIT) {
      throw new Error('محاسبه‌ی مهلت ساعت‌کاری بیش از حد طول کشید — احتمالاً تنظیمات WeeklyBusinessHour همه‌ی روزها رو بسته کرده.')
    }

    const sched = getDaySchedule(cursorDay, holidaySet, weeklyMap)
    if (sched) {
      const windowStart = cursor > sched.start ? cursor : sched.start
      if (windowStart < sched.end) {
        const availableMs = sched.end.getTime() - windowStart.getTime()
        if (availableMs >= remainingMs) {
          cursor = new Date(windowStart.getTime() + remainingMs)
          remainingMs = 0
          break
        } else {
          remainingMs -= availableMs
        }
      }
    }

    // برو روز بعد، از اول روز
    cursorDay = new Date(cursorDay.getTime() + 24 * 60 * 60 * 1000)
    cursor = new Date(cursorDay)
  }

  return cursor
}

/** آیا همین الان توی بازه‌ی ساعت کاریه؟ (برای تصمیم‌های آنی، نه محاسبه‌ی مهلت) */
export async function isWithinBusinessHours(at: Date = new Date()): Promise<boolean> {
  const { holidaySet, weeklyMap } = await loadCalendars()
  const day = new Date(at)
  day.setHours(0, 0, 0, 0)
  const sched = getDaySchedule(day, holidaySet, weeklyMap)
  if (!sched) return false
  return at >= sched.start && at < sched.end
}

// ==================== مدیریت ساعات کاری هفتگی (فقط مدیر) ====================

const DAY_LABELS_FA = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه']

export async function listWeeklyBusinessHours() {
  const rows = await prisma.weeklyBusinessHour.findMany({ orderBy: { dayOfWeek: 'asc' } })
  const byDay = new Map(rows.map((r) => [r.dayOfWeek, r]))
  // اگه هنوز چیزی برای یه روز ثبت نشده، یه پیش‌فرض نمایشی (بدون ذخیره) برمی‌گردونیم
  return Array.from({ length: 7 }, (_, dayOfWeek) => {
    const existing = byDay.get(dayOfWeek)
    return {
      dayOfWeek,
      label: DAY_LABELS_FA[dayOfWeek],
      isOpen: existing?.isOpen ?? dayOfWeek !== 5, // پیش‌فرض نمایشی: جمعه‌ها بسته
      openTime: existing?.openTime ?? '08:00',
      closeTime: existing?.closeTime ?? '17:00',
    }
  })
}

export async function upsertWeeklyBusinessHour(dayOfWeek: number, isOpen: boolean, openTime: string, closeTime: string) {
  await prisma.weeklyBusinessHour.upsert({
    where: { dayOfWeek },
    update: { isOpen, openTime, closeTime },
    create: { dayOfWeek, isOpen, openTime, closeTime },
  })
}
