'use client'

// کنترلر انتخاب موقعیت روی نقشه‌ی Leaflet + OpenStreetMap.
// دو حالت:
//  • تعاملی (پیش‌فرض): کلیک روی نقشه → طول/عرض را در همان input‌های عددیِ فرم می‌ریزد
//    (نام فیلدها عیناً حفظ می‌شود، پس Server Action موجود بدون تغییر کار می‌کند).
//    ورود دستیِ عدد هم هم‌زمان ممکن است (مکملِ نقشه، نه جایگزینِ اجباری).
//  • فقط‌نمایش (readOnly): یک پینِ ثابت روی موقعیتِ ثبت‌شده، بدون input و بدون کلیک.
// نقشه (Leaflet) فقط در کلاینت اجرا می‌شود؛ با dynamic(ssr:false) بارگذاری می‌شود.

import { useState } from 'react'
import dynamic from 'next/dynamic'
import type { MapMarker } from './LocationPickerMap'
import { colors, radius, fontSize } from '@/lib/styles/tokens'

// Leaflet فقط در کلاینت کار می‌کند (به window دست می‌زند) — با ssr:false بارگذاری می‌شود.
const LocationPickerMap = dynamic(() => import('./LocationPickerMap'), {
  ssr: false,
  loading: () => <div style={mapLoadingStyle}>در حال بارگذاری نقشه…</div>,
})

type LocationPickerProps = {
  /** نام input عرض جغرافیایی (مثلاً "latitude") — عیناً همان فیلدی که Server Action می‌خواند. */
  latName: string
  /** نام input طول جغرافیایی (مثلاً "longitude"). */
  lngName: string
  initialLat?: number | null
  initialLng?: number | null
  /** فقط‌نمایش: پینِ ثابت، بدون کلیک/input. */
  readOnly?: boolean
  height?: number
  /** برچسب پینِ فقط‌نمایش. */
  markerLabel?: string
  /** پین‌های زمینه‌ای اضافی (مثلاً سایر انبارها) در حالت تعاملی. */
  contextMarkers?: MapMarker[]
  /**
   * کال‌بکِ اختیاری برای فرم‌هایی که به‌جای FormData، state خودشان را می‌فرستند
   * (مثلاً AccountForm که با fetch/JSON کار می‌کند). با هر تغییرِ موقعیت صدا زده می‌شود.
   * فرم‌های مبتنی بر Server Action نیازی به این ندارند؛ همان input‌های نام‌دار کافی‌اند.
   */
  onChange?: (lat: number | null, lng: number | null) => void
}

function toNum(v: string): number | null {
  if (v.trim() === '') return null
  const n = Number(v)
  return Number.isFinite(n) ? n : null
}

export default function LocationPicker({
  latName,
  lngName,
  initialLat = null,
  initialLng = null,
  readOnly = false,
  height = 340,
  markerLabel,
  contextMarkers = [],
  onChange,
}: LocationPickerProps) {
  const [lat, setLat] = useState<number | null>(initialLat)
  const [lng, setLng] = useState<number | null>(initialLng)

  const hasPoint = lat != null && lng != null

  // تغییرِ هم‌زمانِ هر دو مقدار + اطلاع به فرم‌های JSON‌محور (اگر onChange داده شده باشد).
  function apply(nextLat: number | null, nextLng: number | null) {
    setLat(nextLat)
    setLng(nextLng)
    onChange?.(nextLat, nextLng)
  }

  // ── حالت فقط‌نمایش ─────────────────────────────────────────────
  if (readOnly) {
    const markers: MapMarker[] = hasPoint
      ? [{ id: 'loc', lat: lat as number, lng: lng as number, label: markerLabel }]
      : []
    return (
      <div>
        <LocationPickerMap
          height={height}
          markers={markers}
          selected={null}
          ariaLabel={markerLabel ?? 'موقعیت ثبت‌شده روی نقشه'}
        />
        {!hasPoint && <div style={emptyNoteStyle}>موقعیتی روی نقشه ثبت نشده است.</div>}
      </div>
    )
  }

  // ── حالت تعاملی ───────────────────────────────────────────────
  return (
    <div>
      <LocationPickerMap
        height={height}
        onSelect={(la, ln) => apply(la, ln)}
        selected={hasPoint ? { lat: lat as number, lng: lng as number } : null}
        markers={contextMarkers}
        ariaLabel="برای انتخاب موقعیت روی نقشه کلیک کنید"
      />

      <div style={hintRowStyle}>
        <span style={hintTextStyle}>
          روی نقشه کلیک کن تا موقعیت انتخاب شود، یا مقادیر را دستی وارد کن.
        </span>
        {hasPoint && (
          <button
            type="button"
            onClick={() => apply(null, null)}
            style={clearBtnStyle}
          >
            پاک‌کردن موقعیت
          </button>
        )}
      </div>

      <div style={coordRowStyle}>
        <label style={coordFieldStyle}>
          <span style={coordLabelStyle}>عرض جغرافیایی (Latitude)</span>
          <input
            name={latName}
            type="number"
            step="any"
            inputMode="decimal"
            value={lat ?? ''}
            onChange={(e) => apply(toNum(e.target.value), lng)}
            placeholder="مثلاً 35.6892"
            style={coordInputStyle}
          />
        </label>
        <label style={coordFieldStyle}>
          <span style={coordLabelStyle}>طول جغرافیایی (Longitude)</span>
          <input
            name={lngName}
            type="number"
            step="any"
            inputMode="decimal"
            value={lng ?? ''}
            onChange={(e) => apply(lat, toNum(e.target.value))}
            placeholder="مثلاً 51.3890"
            style={coordInputStyle}
          />
        </label>
      </div>
    </div>
  )
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const mapLoadingStyle: React.CSSProperties = {
  height: 340,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: 13,
  color: colors.textMuted,
  border: `1px solid ${colors.borderStrong}`,
  borderRadius: 12,
  background: '#fff',
}
const emptyNoteStyle: React.CSSProperties = {
  marginTop: 8,
  fontSize: fontSize.xs,
  color: colors.textMuted,
}
const hintRowStyle: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  gap: 12,
  marginTop: 8,
  flexWrap: 'wrap',
}
const hintTextStyle: React.CSSProperties = {
  fontSize: fontSize.xs,
  color: colors.textMuted,
}
const clearBtnStyle: React.CSSProperties = {
  background: 'transparent',
  border: `1px solid ${colors.borderStrong}`,
  borderRadius: radius.sm,
  padding: '4px 12px',
  fontSize: fontSize.xs,
  fontWeight: 600,
  color: colors.textSecondary,
  cursor: 'pointer',
  fontFamily: 'inherit',
}
const coordRowStyle: React.CSSProperties = {
  display: 'flex',
  gap: 12,
  marginTop: 10,
  flexWrap: 'wrap',
}
const coordFieldStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 4,
  flex: '1 1 160px',
  minWidth: 0,
}
const coordLabelStyle: React.CSSProperties = {
  fontSize: fontSize.xs,
  fontWeight: 700,
  color: colors.textSecondary,
}
const coordInputStyle: React.CSSProperties = {
  width: '100%',
  boxSizing: 'border-box',
  border: `1px solid ${colors.borderStrong}`,
  borderRadius: radius.sm,
  padding: '8px 10px',
  fontSize: fontSize.base,
  fontFamily: 'inherit',
  direction: 'ltr',
  textAlign: 'left',
}
