'use client'

// زیرنقشه‌ی Leaflet برای LocationPicker — فقط کلاینت.
// این ماژول react-leaflet را به‌صورت static ایمپورت می‌کند (چون useMapEvents یک هوک است
// و نه می‌شود آن را dynamic بارگذاری کرد و نه در کامپوننتی که روی سرور prerender می‌شود
// static ایمپورت کرد؛ Leaflet هنگام import به window دست می‌زند). به همین دلیل کلِ این
// زیردرخت جدا شده و LocationPicker آن را با dynamic(ssr:false) بارگذاری می‌کند.
// از CircleMarker (SVG) استفاده می‌شود تا پین‌ها بدون نیاز به آیکن یا leaflet.css دیده شوند
// (دقیقاً مثل انتخابِ TransportMap: بدون leaflet.css).

import { MapContainer, TileLayer, CircleMarker, Tooltip, useMapEvents } from 'react-leaflet'
import { colors } from '@/lib/styles/tokens'

export type MapMarker = {
  id: string
  lat: number
  lng: number
  label?: string
  color?: string
}

// مرکز تقریبی ایران برای حالتی که هنوز نقطه‌ای انتخاب نشده.
const IRAN_CENTER: [number, number] = [32.4, 53.6]
const IRAN_ZOOM = 5
const POINT_ZOOM = 11

function round6(n: number): number {
  return Math.round(n * 1e6) / 1e6
}

// هوکِ کلیک — باید داخلِ <MapContainer> رندر شود (فرزندِ نقشه).
function ClickHandler({ onSelect }: { onSelect: (lat: number, lng: number) => void }) {
  useMapEvents({
    click(e) {
      onSelect(round6(e.latlng.lat), round6(e.latlng.lng))
    },
  })
  return null
}

type LocationPickerMapProps = {
  height: number
  /** پین‌های زمینه‌ای (حالت تعاملی) یا پینِ ثابت (حالت فقط‌نمایش). */
  markers: MapMarker[]
  /** پینِ انتخاب‌شده/در‌انتظار (حالت تعاملی). */
  selected: { lat: number; lng: number } | null
  /** اگر داده شود نقشه تعاملی می‌شود: کلیک → (lat, lng). */
  onSelect?: (lat: number, lng: number) => void
  ariaLabel?: string
}

export default function LocationPickerMap({
  height,
  markers,
  selected,
  onSelect,
  ariaLabel,
}: LocationPickerMapProps) {
  const interactive = typeof onSelect === 'function'

  // مرکز اولیه: نقطه‌ی انتخاب‌شده → اولین پین → مرکز ایران.
  const focus = selected ?? (markers.length > 0 ? { lat: markers[0].lat, lng: markers[0].lng } : null)
  const center: [number, number] = focus ? [focus.lat, focus.lng] : IRAN_CENTER
  const zoom = focus ? POINT_ZOOM : IRAN_ZOOM

  return (
    <div style={{ ...wrapStyle, height }} aria-label={ariaLabel}>
      <MapContainer center={center} zoom={zoom} style={{ width: '100%', height: '100%' }}>
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        {interactive && onSelect ? <ClickHandler onSelect={onSelect} /> : null}

        {markers.map((m) => (
          <CircleMarker
            key={m.id}
            center={[m.lat, m.lng]}
            radius={6}
            pathOptions={{ color: '#fff', weight: 1.5, fillColor: m.color ?? colors.navy, fillOpacity: 1 }}
          >
            {m.label ? <Tooltip>{m.label}</Tooltip> : null}
          </CircleMarker>
        ))}

        {selected ? (
          <CircleMarker
            center={[selected.lat, selected.lng]}
            radius={8}
            pathOptions={{ color: '#fff', weight: 2, fillColor: colors.orange, fillOpacity: 1 }}
          />
        ) : null}
      </MapContainer>
    </div>
  )
}

const wrapStyle: React.CSSProperties = {
  position: 'relative',
  width: '100%',
  borderRadius: 12,
  overflow: 'hidden',
  border: `1px solid ${colors.borderStrong}`,
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
  background: '#f7f8fa',
  boxSizing: 'border-box',
}
