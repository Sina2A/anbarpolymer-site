# NOTES — بازگشت نقشه‌ها از GeoJSON سفارشی به Leaflet + OpenStreetMap

## چرا این تغییر
نقشه‌ی سفارشی (GeoJSON + react-simple-maps + `IranMap.tsx`) فقط مرزهای اداری را نشان می‌داد:
بدون نام شهر، بدون جاده. Leaflet + OpenStreetMap این‌ها را رایگان و قانونی می‌دهد
(نام شهر/جاده، ظاهرِ نزدیک به Google Maps) و زومِ native دارد. کامپوننتِ `TransportMap.tsx`
از ابتدا روی همین Leaflet بود و هرگز تغییر نکرد؛ همان الگو اینجا مرجع قرار گرفت.

قاعده‌های ثابتِ رعایت‌شده: **بدون داده‌ی جعلی**، حفظِ منطق مهمان/دسترسی (`readOnly`)،
حفظِ امضای propها (هیچ مصرف‌کننده‌ای تغییر نکرد).

---

## فایل‌های تغییریافته

### ۱) `src/components/WarehousesMap.tsx` — بازنویسی به Leaflet
- دقیقاً الگوی `TransportMap.tsx`: `dynamic(() => import('react-leaflet').then(m => m.X), { ssr:false })`
  برای `MapContainer`/`TileLayer`/`CircleMarker`/`Popup` + گیتِ `mounted` (`useEffect`).
- کاشی OSM: `https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png` با attributionِ OpenStreetMap.
- مرکز = میانگینِ مختصاتِ انبارهای دارای موقعیت؛ zoom: تک‌انبار → ۱۱، چند‌انبار → ۵
  (fallback مرکز ایران `[32.4, 53.6]` اگر میانگین معتبر نبود).
- هر انبار → یک **`CircleMarker`** (SVG، بدون نیاز به آیکن/فایل تصویر) با رنگِ `colors.navy`
  و `Popup` شاملِ نام/شهر/آدرس.
- **امضای prop عیناً حفظ شد:** `{ warehouses, height = 420 }`. حالتِ خالی (بدون موقعیت) حفظ شد.
- زوم = native خودِ Leaflet (بدون دکمه‌ی دستی).

### ۲) `src/components/LocationPicker.tsx` — بازنویسی به Leaflet
- **امضای propها کلمه‌به‌کلمه حفظ شد:**
  `latName, lngName, initialLat, initialLng, readOnly, height, markerLabel, contextMarkers, onChange`.
  پس هر ۴ مصرف‌کننده‌ی FormData (`admin-warehouses`, `admin-kyc`, `verification`) و مصرف‌کننده‌ی
  JSON (`AccountForm` با `onChange`) بدون هیچ تغییری کار می‌کنند.
- منطقِ `apply()` / `onChange` / دو `<input type="number" name={latName|lngName}>` **عیناً حفظ**
  (سازگاری کاملِ FormData Server Action + فرم JSON).
- حالت `readOnly`: پینِ ثابت روی نقطه، بدون کلیک/بدون input؛ پیام «موقعیتی ثبت نشده» حفظ شد.
- حالت تعاملی: پینِ نارنجیِ انتخاب + پین‌های `contextMarkers` + هینت + دکمه‌ی «پاک‌کردن موقعیت» حفظ شد.
- **کلِ منطقِ `projection.invert()` / `getScreenCTM()` / `DOMPoint` حذف شد** و جای آن
  رویدادِ کلیکِ خودِ Leaflet نشست (طول/عرضِ واقعی مستقیم).
- تایپِ مارکر که قبلاً از `IranMap` می‌آمد، حالا `MapMarker` است که از `LocationPickerMap` وارد می‌شود
  (هیچ مصرف‌کننده‌ای این تایپ را مستقیماً import نمی‌کند — بررسی شد).

### ۳) `src/components/LocationPickerMap.tsx` — فایل جدید (زیرنقشه‌ی Leaflet)
- **چرا فایل جدا؟** انتخابِ نقطه به هوکِ `useMapEvents` نیاز دارد. یک هوک نه می‌تواند
  `dynamic` بارگذاری شود و نه در کامپوننتی که روی سرور prerender می‌شود به‌صورت static ایمپورت شود
  (Leaflet هنگام import به `window` دست می‌زند). پس کلِ زیردرختِ نقشه در این ماژول جدا شد و
  `LocationPicker` آن را با `dynamic(() => import('./LocationPickerMap'), { ssr:false })` بارگذاری می‌کند.
  این همان تحققِ درستِ «`ClickHandler` داخلِ `MapContainer`» است که در پلن تایید شد.
- `ClickHandler` (فرزندِ `<MapContainer>`) با `useMapEvents({ click })` → `onSelect(lat, lng)`.
- پین‌ها با **`CircleMarker`** (SVG) — بدون وابستگی به آیکن یا `leaflet.css` همیشه دیده می‌شوند.
- مرکز/زوم: نقطه‌ی انتخاب‌شده → روی نقطه (zoom ۱۱)؛ بدون نقطه → مرکز ایران `[32.4, 53.6]` (zoom ۵).

---

## فایل‌های حذف‌شده (چون tar نمی‌تواند حذف را حمل کند، دستی هم اعمال کنید)

```bash
rm -f src/components/IranMap.tsx
rm -f public/geoBoundaries-IRN-ADM3.geojson
```

- **`src/components/IranMap.tsx`** (۱۰٬۲۱۸ بایت) — تنها مصرف‌کننده‌هایش `WarehousesMap` و
  `LocationPicker` بودند که هر دو بازنویسی شدند. با grep تأیید شد که هیچ importِ دیگری نمانده.
- **`public/geoBoundaries-IRN-ADM3.geojson`** (۱۸٬۰۱۶٬۳۳۶ بایت ≈ ۱۸ مگابایت) — دیگر fetch نمی‌شود.
  → **کاهشِ ۱۸ مگابایتی از `public/`**. کاشی‌های OSM بر حسب نیاز و کش‌شونده‌ی مرورگر بارگذاری می‌شوند
  (بسیار سبک‌تر روی موبایل نسبت به دانلودِ یک‌جای ۱۸ مگابایت).
- `src/types/topojson-client.d.ts` در تسکِ قبلی حذف شده بود — اقدامی لازم نیست.

---

## وابستگی‌ها — حذف + گزارشِ ریسک

`react-simple-maps`, `d3-geo`, `topojson-client` (+ تایپ‌های `@types/d3-geo`,
`@types/topojson-specification`) فقط در `IranMap.tsx` استفاده می‌شدند. با حذفِ آن، بی‌مصرف شدند.

دستورِ اجراشده (فقط **حذف** — هیچ وابستگیِ جدیدی اضافه نشد):
```bash
npm uninstall react-simple-maps d3-geo topojson-client @types/d3-geo @types/topojson-specification
```
نتیجه: `removed 13 packages` (۵ مستقیم + ۸ ترنزیتیوِ یتیم‌شده).

### ⚠️ نکته‌ی حیاتی — چرا `@types/geojson` نگه داشته شد
importِ مستقیمِ ما (`import type … from 'geojson'` در `IranMap`) حذف شد، اما
**`@types/leaflet` در `package.json` خودش `"@types/geojson": "*"` را به‌عنوان dependency صریح دارد**
(تأیید شد: `node_modules/@types/leaflet/package.json`). طبق قاعده‌ی `NOTES-PIN-UNDECLARED-DEPS.md`
هر پکیجِ موردنیاز باید صریحاً و با pin در `package.json` بماند وگرنه `npm install` بعدی آن را
prune می‌کند و همان چرخه‌ی «خوابیدنِ سایت» برمی‌گردد. پس `@types/geojson` روی `7946.0.16` **pin ماند**.

این دقیقاً همان تنشی بود که در تسکِ قبلی `topojson-client` را عمداً نگه داشته بود (چون آن‌موقع
`react-simple-maps` بهش نیاز داشت)؛ حالا که `react-simple-maps` رفته، `topojson-client` هم امن برای حذف شد.

بدون تغییر: `leaflet ^1.9.4`, `react-leaflet ^5.0.0`, `@types/leaflet ^1.9.22` (از قبل اعلام‌شده،
مصرف‌شده توسط `TransportMap` و حالا سه کامپوننتِ نقشه).

---

## تصمیمِ leaflet.css — گزینه‌ی الف (بدون CSS)
طبق تایید، **هیچ `leaflet.css` اضافه نشد** — دقیقاً مثل `TransportMap` که بدون آن کار می‌کند.
به همین دلیل عمداً از `CircleMarker` (SVG) به‌جای `Marker`ِ پیش‌فرض استفاده شد تا پین‌ها بدون
وابستگی به آیکن/CSS همیشه درست دیده شوند.

---

## راستی‌آزمایی (اجراشده)
- `npx tsc --noEmit` → **EXIT 0**
- `npx next build` → **EXIT 0** (مسیرهای `/warehouses` و همه‌ی صفحاتِ دارای `LocationPicker` کامپایل شدند)
- `npm ls --depth=0` → **extraneous = 0** (اینوریانتِ کلیدیِ پروژه — سایت پایدار)
- grep تأیید: در کلِ `src` هیچ ردی از `react-simple-maps` / `d3-geo` / `topojson` / `from 'geojson'` /
  `IranMap` / `geoBoundaries` نمانده.
- ۹ نمونه‌ی مصرف‌کننده دست‌نخورده: `WarehousesMap` ×۲ (warehouses)، `LocationPicker` ×۷
  (admin-warehouses ×۲، admin-kyc ×۲، verification ×۲، AccountForm ×۱).

---

## محتوای این بسته
```
NOTES-REVERT-TO-LEAFLET.md          (همین فایل)
src/components/WarehousesMap.tsx     (بازنویسی)
src/components/LocationPicker.tsx    (بازنویسی)
src/components/LocationPickerMap.tsx (فایل جدید)
package.json                         (۵ وابستگی حذف شد؛ @types/geojson نگه داشته شد)
package-lock.json                    (قفلِ همگام با حذف‌ها)
```

## نحوه‌ی اعمال روی مخزن
```bash
# ۱) استخراجِ فایل‌ها (مسیرها repo-rooted و flat هستند)
tar -xzf revert-to-leaflet.tar.gz

# ۲) اعمالِ دو حذف که tar حملشان نمی‌کند
rm -f src/components/IranMap.tsx
rm -f public/geoBoundaries-IRN-ADM3.geojson

# ۳) همگام‌سازیِ node_modules با package-lock جدید
npm ci

# ۴) راستی‌آزمایی
npx tsc --noEmit
npx next build
npm ls --depth=0   # باید هیچ extraneous نداشته باشد
```
