# Homepage Redesign — NOTES

**Changed:** `src/app/page.tsx` (async Server Component, `force-dynamic`, `getCurrentUserOrNull`+`PublicHeader`/`Footer` preserved) + `src/app/globals.css` (appended `home-*` classes — no existing rules modified). `src/lib/styles/tokens.ts` untouched.

**Palette A (local `home` const in page.tsx):** navy #1E357B, navyDark #16285F, orange #E65716, orangeDark #c94a10, orangeSoft #FFF1EA, bgPage #F7F8FA, bgCard #fff, borderSubtle #E4E7EC, textPrimary #172033, textSecondary #475467, textMuted #667085.

**Sections:** Hero (CSS pattern+glow, live `gradeCount`/`baseCount` via Prisma — no hardcoded 11/3), Features (1 lead + 3 small, real inline SVGs), Gallery (3 hatched placeholders "بعداً جایگزین می‌شود"), How (5 steps matching real Deal flow), Logistics (3 intro cards only — fake AP-1048 tracking panel removed), Trust (3 cards), CTA → `/signup` or `/dashboard` if logged in.

**Live stats:** `Promise.all([grade.count(isActive), grade.findMany distinct category])`. After taxonomy is seeded, replace second query with `prisma.category.count({ where: { level: 3, isActive: true } })`.

**Responsive:** @1024 (2-col), @640 (stacked).

**Verify:** `tsc --noEmit` — `page.tsx` zero errors.
