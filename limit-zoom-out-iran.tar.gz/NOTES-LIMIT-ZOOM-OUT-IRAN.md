# NOTES — محدودسازیِ زوم‌اوت و pan به محدوده‌ی ایران

## هدف
۱. زوم‌اوت نباید از حدی فراتر رود که کلِ عرضِ شرقی–غربیِ ایران در قاب جا می‌شود.
۲. کاربر نباید بتواند نقشه را با drag/pan کاملاً بیرونِ ایران ببرد (قفلِ سخت، نه کِشسان).

هر دو به‌صورت **پویا** (نه عددِ ثابت) و روی هر سه نقشه: `WarehousesMap`, `LocationPickerMap`, `TransportMap`.

## راه‌حل
یک کنترلرِ مشترکِ client-only که فرزندِ `<MapContainer>` است و با هوکِ `useMap` به instanceِ نقشه دسترسی دارد.

- **minZoomِ پویا:** `map.getBoundsZoom(IRAN_BOUNDS)` زومی را می‌دهد که کلِ محدوده‌ی ایران در قابِ فعلی جا شود؛ همان را `setMinZoom` می‌کنیم ⇒ کفِ زوم‌اوت. چون از اندازه‌ی واقعیِ کانتینر حساب می‌شود، روی موبایل/دسکتاپ و پس از چرخش فرق می‌کند (هارد‌کد نیست).
- **قفلِ pan:** `map.setMaxBounds(IRAN_BOUNDS)` + پراپِ `maxBoundsViscosity={1.0}` روی `MapContainer`. ویسکوزیتی ۱٫۰ یعنی قفلِ کاملاً سفت (نه الاستیک). Leaflet این مقدار را زنده از `map.options` می‌خواند، پس پاس‌دادن به‌صورت prop کافی است.
- **واکنش به resize/چرخش:** یک `ResizeObserver` روی `map.getContainer()`. با هر تغییرِ اندازه `invalidateSize()` سپس بازمحاسبه‌ی minZoom/maxBounds. رویدادِ `resize`ِ خودِ Leaflet هم به‌عنوان شبکه‌ی ایمنی حفظ شده.
- **گاردِ اندازه‌ی صفر:** در `TransportMap` نقشه داخلِ `<details>`ِ بسته mount می‌شود (کانتینر 0×0). تا وقتی `getSize()` صفر است بازمحاسبه انجام نمی‌شود؛ به‌محضِ باز شدنِ details و مرئی‌شدن، `ResizeObserver` فایر می‌شود و مقادیر درست ست می‌شوند.
- **LocationPicker:** قفلِ pan جلوی کلیک/انتخابِ نقطه داخلِ ایران را نمی‌گیرد (کلیک از طریقِ `useMapEvents` مستقل از maxBounds کار می‌کند)؛ فقط اجازه نمی‌دهد قاب کاملاً از ایران خارج شود.

## محدوده‌ی ایران (یک منبعِ واحد)
از bboxِ داده‌ی رسمیِ ADM0 (geoBoundaries) — طول `44.0149↔63.3196`، عرض `25.0594↔39.7715`.
قالبِ Leaflet `[[south, west], [north, east]]`:
```
IRAN_BOUNDS = [[25.0594, 44.0149], [39.7715, 63.3196]]
```
در `MapBoundsController.tsx` تعریف و export شده تا هر سه نقشه از همان یک ثابت استفاده کنند.

## فایل‌ها
### جدید
- `src/components/MapBoundsController.tsx` — کنترلرِ محدوده (منطقِ minZoom/maxBounds/ResizeObserver + ثابتِ `IRAN_BOUNDS`).

### تغییریافته
- `src/components/WarehousesMap.tsx` — import کنترلر با `dynamic(ssr:false)`؛ افزودنِ `maxBoundsViscosity={1.0}` و `<MapBoundsController />`.
- `src/components/TransportMap.tsx` — همان (الگوی pattern A، نقشه داخلِ `<details>`).
- `src/components/LocationPickerMap.tsx` — import کنترلر به‌صورت static (این ماژول خودش فقط با `dynamic(ssr:false)` لود می‌شود)؛ افزودنِ `maxBoundsViscosity={1.0}` و `<MapBoundsController />`.

### حذف
هیچ. (این تحویل چیزی حذف نمی‌کند.)

## چرا کنترلرِ جدا؟
`useMap` مثلِ `useMapEvents` یک هوک است: نه می‌شود dynamic بارگذاری‌اش کرد، نه در کامپوننتی که روی سرور prerender می‌شود static ایمپورت کرد (Leaflet هنگامِ import به `window` دست می‌زند). پس منطقِ وابسته به instanceِ نقشه باید در یک ماژولِ client-only و به‌عنوانِ فرزندِ `<MapContainer>` باشد.

## صحت‌سنجی
- `npx tsc --noEmit` → بدون خطا.
- `npx next build` → `✓ Compiled successfully`، EXIT=0، بدونِ error/warn.

تستِ بصری روی سرورِ واقعی (صفحات پشتِ auth/DB هستند) طبقِ توافق به‌عهده‌ی سیناست.
