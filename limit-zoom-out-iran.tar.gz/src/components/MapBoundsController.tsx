'use client'

// کنترلرِ محدوده‌ی نقشه — فرزندِ <MapContainer>.
// دو کار انجام می‌دهد:
//   (۱) minZoom را پویا حساب می‌کند تا کلِ عرضِ ایران در کانتینرِ فعلی جا شود
//       (با getBoundsZoom، نه عددِ ثابت — پس با موبایل/دسکتاپ و resize/چرخش سازگار است).
//   (۲) maxBounds را روی محدوده‌ی ایران ست می‌کند تا کاربر نتواند نقشه را بیرونِ ایران بکشد
//       (به‌همراهِ maxBoundsViscosity={1.0} که روی خودِ MapContainer پاس داده می‌شود).
// چون useMap یک هوک است (مثلِ useMapEvents)، این ماژول client-only است:
// LocationPickerMap آن را static ایمپورت می‌کند (خودش فقط با dynamic ssr:false لود می‌شود)،
// و WarehousesMap/TransportMap با dynamic(ssr:false) بارگذاری‌اش می‌کنند.

import { useEffect } from 'react'
import { useMap } from 'react-leaflet'

// محدوده‌ی جغرافیاییِ ایران — از bboxِ داده‌ی رسمیِ ADM0 (geoBoundaries):
// طول ۴۴٫۰۱↔۶۳٫۳۲ ، عرض ۲۵٫۰۶↔۳۹٫۷۷ . قالبِ Leaflet: [[south, west], [north, east]].
export const IRAN_BOUNDS: [[number, number], [number, number]] = [
  [25.0594, 44.0149],
  [39.7715, 63.3196],
]

export default function MapBoundsController() {
  const map = useMap()

  useEffect(() => {
    const apply = () => {
      // اگر کانتینر هنوز اندازه‌ای ندارد (مثلاً داخلِ <details>ِ بسته در TransportMap)،
      // getBoundsZoom عددِ بی‌معنا می‌دهد؛ صبر کن تا مرئی/دارای‌اندازه شود.
      const size = map.getSize()
      if (size.x === 0 || size.y === 0) return

      // زومی که در آن کلِ محدوده‌ی ایران در قابِ فعلی جا می‌شود → کفِ زوم‌اوت.
      const z = map.getBoundsZoom(IRAN_BOUNDS)
      map.setMinZoom(z)
      map.setMaxBounds(IRAN_BOUNDS)
      if (map.getZoom() < z) map.setZoom(z)
    }

    // ResizeObserver روی کانتینرِ نقشه: هم وقتی از حالت مخفی (details بسته) مرئی می‌شود فایر می‌شود،
    // هم با resize/چرخشِ صفحه. رویدادِ 'resize'ِ خودِ Leaflet فقط به window بسته است و بازشدنِ
    // <details> را نمی‌گیرد؛ برای همین ابتدا invalidateSize تا Leaflet اندازه‌ی جدید را بشناسد،
    // بعد minZoom/maxBounds را دوباره حساب می‌کنیم.
    const container = map.getContainer()
    let ro: ResizeObserver | null = null
    if (typeof ResizeObserver !== 'undefined') {
      ro = new ResizeObserver(() => {
        map.invalidateSize()
        apply()
      })
      ro.observe(container)
    }

    apply()
    // شبکه‌ی ایمنی برای مرورگرهای بدونِ ResizeObserver.
    map.on('resize', apply)
    return () => {
      if (ro) ro.disconnect()
      map.off('resize', apply)
    }
  }, [map])

  return null
}
