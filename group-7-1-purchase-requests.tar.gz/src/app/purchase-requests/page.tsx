import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import UserNav from '@/components/UserNav'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'
import { createPurchaseRequestAction, closePurchaseRequestAction } from './actions'

export const dynamic = 'force-dynamic'

type SearchParams = Promise<Record<string, string | string[] | undefined>>

function one(v: string | string[] | undefined): string | undefined {
  if (Array.isArray(v)) return v[0]
  return v
}

export default async function PurchaseRequestsPage({
  searchParams,
}: {
  searchParams: SearchParams
}) {
  const sp = await searchParams
  const user = await getCurrentUser()
  const showForm = one(sp.new) === '1'

  // درخواست‌های خرید کاربر
  const myRequests = await prisma.purchaseRequest.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    include: {
      grade: true,
      _count: { select: { listings: true } },
    },
  })

  // گریدهای فعال — برای dropdown فرم
  const grades = showForm
    ? await prisma.grade.findMany({
        where: { isActive: true },
        orderBy: { code: 'asc' },
        select: { id: true, code: true, producer: true, category: true },
      })
    : []

  return (
    <div style={pageStyle}>
      <div style={{ maxWidth: 1100, margin: '0 auto', display: 'flex', gap: 24 }} className="admin-page-wrap">
        <UserNav currentUserName={user.companyName} activeSection="purchase-requests" />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <div>
              <h1 style={{ fontSize: 22, fontWeight: 800, margin: 0, marginBottom: 4 }}>درخواست‌های خرید</h1>
              <p style={{ fontSize: 13, color: '#9199a3', margin: 0 }}>
                اعلام نیاز خرید مواد اولیه — فروشنده‌ها می‌بینن و آگهی می‌سازن
              </p>
            </div>
            {!showForm && (
              <a href="/purchase-requests?new=1" style={newBtnStyle}>
                + ثبت درخواست جدید
              </a>
            )}
          </div>

          {/* ── فرم ثبت درخواست جدید ── */}
          {showForm && (
            <div style={cardStyle}>
              <h3 style={{ fontSize: 15, fontWeight: 700, margin: 0, marginBottom: 14 }}>
                ثبت درخواست خرید جدید
              </h3>
              <form action={createPurchaseRequestAction}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
                  <div>
                    <div style={labelStyle}>گرید مورد نظر *</div>
                    <select name="gradeId" required style={selectStyle}>
                      <option value="">انتخاب گرید…</option>
                      {grades.map((g) => (
                        <option key={g.id} value={g.id}>
                          {g.code} — {g.producer} ({g.category})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <div style={labelStyle}>مقدار درخواستی (تن) *</div>
                    <input name="quantityTon" type="number" step="0.1" min="0.1" required
                      placeholder="مثلاً ۲۵" style={inputStyle} />
                  </div>
                  <div>
                    <div style={labelStyle}>سقف قیمت (تومان/کیلو)</div>
                    <input name="maxPriceToman" type="number" step="1" min="1"
                      placeholder="اختیاری — خالی = بدون سقف" style={inputStyle} />
                  </div>
                  <div>
                    <div style={labelStyle}>استان ترجیحی محل بار</div>
                    <input name="province" placeholder="اختیاری" style={inputStyle} />
                  </div>
                  <div>
                    <div style={labelStyle}>مدت اعتبار (روز)</div>
                    <select name="expiresInDays" defaultValue="14" style={selectStyle}>
                      <option value="7">۷ روز</option>
                      <option value="14">۱۴ روز</option>
                      <option value="30">۳۰ روز</option>
                      <option value="60">۶۰ روز</option>
                      <option value="90">۹۰ روز</option>
                    </select>
                  </div>
                  <div style={{ gridColumn: '1 / -1' }}>
                    <div style={labelStyle}>توضیحات</div>
                    <textarea name="description" rows={3}
                      placeholder="شرایط خاص، کیفیت مدنظر، حجم بسته‌بندی و غیره"
                      style={{ ...inputStyle, resize: 'vertical' }} />
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
                  <a href="/purchase-requests" style={{ ...submitBtnStyle, background: '#f1efe8', color: '#4f5560', textDecoration: 'none', fontSize: 12.5, padding: '9px 18px', fontWeight: 600 }}>
                    انصراف
                  </a>
                  <button type="submit" style={submitBtnStyle}>ثبت درخواست</button>
                </div>
              </form>
            </div>
          )}

          {/* ── لیست درخواست‌ها ── */}
          <div style={cardStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <b style={{ fontSize: 14 }}>درخواست‌های من</b>
              <span style={{ fontSize: 12, fontWeight: 700, background: '#e65716', color: '#fff', borderRadius: 8, padding: '2px 10px' }}>
                {myRequests.length}
              </span>
            </div>

            {myRequests.length === 0 ? (
              <div style={emptyStyle}>هنوز درخواست خریدی ثبت نکردی.</div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {myRequests.map((req) => {
                  const isExpired = req.status === 'open' && req.expiresAt && new Date(req.expiresAt) < new Date()
                  const displayStatus = isExpired ? 'expired' : req.status
                  return (
                    <div key={req.id} style={reqCardStyle}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: 8 }}>
                        <div>
                          <span style={{ fontSize: 14, fontWeight: 700 }}>
                            {req.grade.code}
                          </span>
                          <span style={{ fontSize: 11, color: '#9199a3', fontFamily: 'monospace', marginRight: 8 }}>
                            #{req.id.slice(0, 8)}
                          </span>
                          <span style={{ ...statusTagStyle(displayStatus), marginRight: 8 }}>
                            {translateStatus(displayStatus)}
                          </span>
                        </div>
                        <span style={{ fontSize: 11, color: '#9199a3' }}>
                          {new Date(req.createdAt).toLocaleDateString('fa-IR')}
                        </span>
                      </div>

                      <div style={{ display: 'flex', gap: 20, fontSize: 12.5, color: '#4f5560', marginBottom: 6, flexWrap: 'wrap' }}>
                        <span>مقدار: <b>{req.quantityTon} تن</b></span>
                        {req.maxPriceToman && (
                          <span>سقف قیمت: <b style={{ color: '#e65716' }}>{req.maxPriceToman.toLocaleString('fa-IR')} تومان/کیلو</b></span>
                        )}
                        {req.province && <span>استان: <b>{req.province}</b></span>}
                      </div>

                      {req.description && (
                        <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 6, fontStyle: 'italic' }}>
                          {req.description}
                        </div>
                      )}

                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 6 }}>
                        <span style={{ fontSize: 11, color: '#9199a3' }}>
                          {req._count.listings > 0
                            ? `${req._count.listings} آگهی در پاسخ`
                            : 'هنوز آگهی‌ای ثبت نشده'}
                          {req.expiresAt && (
                            <> | انقضا: {new Date(req.expiresAt).toLocaleDateString('fa-IR')}</>
                          )}
                        </span>
                        {displayStatus === 'open' && (
                          <form action={closePurchaseRequestAction}>
                            <input type="hidden" name="requestId" value={req.id} />
                            <ConfirmSubmitButton
                              message="آیا مطمئنی که می‌خوای این درخواست رو ببندی؟"
                              style={{ background: 'none', border: 'none', color: '#9b1c1c', fontSize: 11, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit' }}
                            >
                              بستن درخواست
                            </ConfirmSubmitButton>
                          </form>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  )
}

// ── ترجمه و رنگ ─────────────────────────────────────────────────────
function translateStatus(status: string): string {
  const map: Record<string, string> = { open: 'باز', closed: 'بسته شده', expired: 'منقضی' }
  return map[status] ?? status
}

function statusTagStyle(status: string): React.CSSProperties {
  let bg = '#f1efe8'
  let color = '#4f5560'
  if (status === 'open') { bg = '#d1fae5'; color = '#065f46' }
  else if (status === 'closed') { bg = '#e0e7ff'; color = '#3730a3' }
  else if (status === 'expired') { bg = '#f3f4f6'; color = '#6b7280' }
  return {
    fontSize: 10, fontWeight: 700, background: bg, color,
    borderRadius: 6, padding: '4px 10px', display: 'inline-block',
  }
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: '#faf8f4',
  padding: '32px 20px',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const newBtnStyle: React.CSSProperties = {
  background: '#1e357b', color: '#fff', border: 'none', borderRadius: 8,
  padding: '9px 18px', fontSize: 12.5, fontWeight: 700,
  textDecoration: 'none', cursor: 'pointer', whiteSpace: 'nowrap',
}
const cardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3', borderRadius: 12, padding: 18,
  marginBottom: 14, background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const inputStyle: React.CSSProperties = {
  border: '1px solid #d8dde3', borderRadius: 8,
  padding: '9px 12px', fontSize: 13, fontFamily: 'inherit', width: '100%',
}
const selectStyle: React.CSSProperties = {
  border: '1px solid #d8dde3', borderRadius: 8,
  padding: '9px 12px', fontSize: 13, fontFamily: 'inherit',
  background: '#fff', width: '100%',
}
const labelStyle: React.CSSProperties = {
  fontSize: 12, fontWeight: 700, color: '#4f5560', marginBottom: 4,
}
const submitBtnStyle: React.CSSProperties = {
  background: '#1e357b', color: '#fff', border: 'none', borderRadius: 8,
  padding: '11px 28px', fontSize: 14, fontWeight: 800, cursor: 'pointer',
  fontFamily: 'inherit',
}
const emptyStyle: React.CSSProperties = {
  fontSize: 12.5, color: '#9199a3', padding: '20px 0', textAlign: 'center',
}
const reqCardStyle: React.CSSProperties = {
  padding: '14px 16px', border: '1px solid #e8e4db', borderRadius: 10,
  background: '#faf8f4',
}
