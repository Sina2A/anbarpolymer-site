import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { getCurrentUserOrNull } from '@/lib/currentUser'
import { getUserKycLevel } from '@/lib/kyc'
import { isUserRestricted } from '@/lib/dealDeadlines'
import { logAudit } from '@/lib/logger'
import fs from 'fs/promises'
import path from 'path'
import crypto from 'crypto'

/**
 * ثبت آگهی عرضه (MaterialListing) — تنها جای نوشتنِ این جدول در کل سایت.
 *
 * چرا Route Handler و نه Server Action؟ چون weighbridgeTicketUrl اجباریه و
 * عکس قبض باسکول راحت از سقف یک‌مگابایتی بدنه‌ی Server Action می‌زنه بالا
 * (next.config.ts خالیه، پس سقف همون پیش‌فرضه). دقیقاً همون دلیلی که
 * api/grade-documents/route.ts رو داریم.
 *
 * خطاها throw نمی‌شن — با کد کوتاه توی query برمی‌گردن به /new-listing تا
 * فروشنده پیام فارسی رو روی همون فرم ببینه، نه صفحه‌ی خطای Next.
 */

const UPLOAD_ROOT = path.join(process.cwd(), 'public', 'uploads', 'weighbridge')

/** سقف حجم عکس قبض — بالاتر از این، دیسک سرور بی‌دلیل پر می‌شه */
const MAX_FILE_SIZE = 20 * 1024 * 1024

const ALLOWED_EXT: Record<string, string> = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
}

/**
 * برگشت به فرم ثبت آگهی. دو نکته که نباید عوض بشن:
 *   ۱. کد ۳۰۳ (نه ۳۰۷): مرورگر باید POST رو به GET تبدیل کنه، وگرنه دوباره
 *      همون بدنه رو می‌فرسته و آگهی تکراری ساخته می‌شه.
 *   ۲. Location نسبی: پشت nginx، آدرس مطلقِ ساخته‌شده از request.url به
 *      localhost اشاره می‌کنه.
 */
function backToForm(errorCode: string, purchaseRequestId?: string) {
  const query = new URLSearchParams()
  query.set('error', errorCode)
  if (purchaseRequestId) query.set('request', purchaseRequestId)
  return new NextResponse(null, {
    status: 303,
    headers: { Location: `/new-listing?${query.toString()}` },
  })
}

export async function POST(request: Request) {
  // getCurrentUser اینجا به‌کار نمیاد: ریدایرکتش ۳۰۷ه و متد POST رو نگه می‌داره،
  // پس /login با ۴۰۵ جواب می‌ده. نسخه‌ی بی‌ریدایرکت + ۳۰۳ دستی درستشه.
  const user = await getCurrentUserOrNull()
  if (!user) return new NextResponse(null, { status: 303, headers: { Location: '/login' } })

  const formData = await request.formData()

  const purchaseRequestId = String(formData.get('purchaseRequestId') || '').trim() || null
  const gradeId = String(formData.get('gradeId') || '').trim()
  const quantityTon = parseFloat(String(formData.get('quantityTon') || ''))
  const province = String(formData.get('province') || '').trim()
  const city = String(formData.get('city') || '').trim()
  const packagingType = String(formData.get('packagingType') || '').trim()
  const packagingQuality = String(formData.get('packagingQuality') || '').trim()
  const materialQuality = String(formData.get('materialQuality') || '').trim()
  const askingPriceToman = parseFloat(String(formData.get('askingPriceToman') || ''))
  const netWeightKg = parseFloat(String(formData.get('weighbridgeNetWeightKg') || ''))
  const weighbridgeDateRaw = String(formData.get('weighbridgeDate') || '').trim()
  const weighbridgePlate = String(formData.get('weighbridgePlate') || '').trim() || null
  const file = formData.get('weighbridgeTicket')

  const back = (code: string) => backToForm(code, purchaseRequestId ?? undefined)

  // ── دروازه‌ی احراز هویت: فروش سطح ۲ لازم داره (پروانه بهره‌برداری) ──
  // اینجا requireVerifiedProducer صدا زده نمی‌شه چون throw می‌کنه و کاربر
  // صفحه‌ی خطای Next رو می‌بینه؛ نسخه‌ی بی‌throw + ریدایرکت درستشه.
  const kycLevel = await getUserKycLevel(user.id)
  if (kycLevel < 2) return back('kyc')

  // فروشنده‌ای که مهلت‌هاش رو سوزونده، تا پایان محدودیت آگهی جدید نمی‌ده
  const restriction = await isUserRestricted(user.id)
  if (restriction.restricted) return back('restricted')

  // ── اعتبارسنجی ──
  if (!gradeId) return back('no-grade')
  if (!quantityTon || quantityTon <= 0) return back('bad-quantity')
  if (!province || !city) return back('no-location')
  if (!packagingType || !packagingQuality || !materialQuality) return back('no-specs')
  if (!askingPriceToman || askingPriceToman <= 0) return back('bad-price')
  if (!netWeightKg || netWeightKg <= 0) return back('bad-weight')
  if (!weighbridgeDateRaw) return back('no-ticket-date')

  // اسکیما می‌گه «تاریخ قبض باید همون روز ثبت باشه» — پس فقط امروز قبوله.
  const weighbridgeDate = new Date(weighbridgeDateRaw)
  if (isNaN(weighbridgeDate.getTime())) return back('bad-ticket-date')
  const today = new Date()
  const sameDay =
    weighbridgeDate.getFullYear() === today.getFullYear() &&
    weighbridgeDate.getMonth() === today.getMonth() &&
    weighbridgeDate.getDate() === today.getDate()
  if (!sameDay) return back('ticket-not-today')

  // عکس قبض باسکول اجباریه — بدون این، آگهی ثبت نمی‌شه
  if (!(file instanceof File) || file.size === 0) return back('no-ticket')
  if (file.size > MAX_FILE_SIZE) return back('too-big')
  // هم content-type و هم پسوند چک می‌شن — بعضی مرورگرها type رو خالی می‌فرستن.
  const nameExt = file.name.toLowerCase().split('.').pop() || ''
  const ext = ALLOWED_EXT[file.type] ?? (['jpg', 'jpeg', 'png', 'webp'].includes(nameExt) ? (nameExt === 'jpeg' ? 'jpg' : nameExt) : null)
  if (!ext) return back('not-image')

  const grade = await prisma.grade.findUnique({
    where: { id: gradeId },
    select: { id: true, code: true, isActive: true },
  })
  if (!grade || !grade.isActive) return back('no-grade')

  // اگه آگهی در پاسخ به یه درخواست خریده، درخواست باید واقعاً باز باشه.
  // توجه: درخواست بعد از ساخت آگهی بسته نمی‌شه — چند فروشنده می‌تونن رقابت کنن.
  if (purchaseRequestId) {
    const pr = await prisma.purchaseRequest.findUnique({
      where: { id: purchaseRequestId },
      select: { id: true, status: true, expiresAt: true },
    })
    if (!pr) return backToForm('no-request')
    if (pr.status !== 'open') return backToForm('request-closed')
    if (pr.expiresAt && pr.expiresAt < new Date()) return backToForm('request-expired')
  }

  // همون الگوی lib/kyc.ts — ذخیره روی دیسک محلی زیر public تا مستقیم سرو بشه.
  // اسم فایل هرگز از نام آپلودی ساخته نمی‌شه (جلوگیری از path traversal و تکرار).
  const userDir = path.join(UPLOAD_ROOT, user.id)
  await fs.mkdir(userDir, { recursive: true })
  const fileName = `ticket-${Date.now()}-${crypto.randomBytes(4).toString('hex')}.${ext}`
  const buffer = Buffer.from(await file.arrayBuffer())
  await fs.writeFile(path.join(userDir, fileName), buffer)

  const listing = await prisma.materialListing.create({
    data: {
      userId: user.id,
      gradeId: grade.id,
      quantityTon,
      province,
      city,
      packagingType,
      packagingQuality,
      materialQuality,
      askingPriceToman,
      weighbridgeTicketUrl: `/uploads/weighbridge/${user.id}/${fileName}`,
      weighbridgeNetWeightKg: netWeightKg,
      weighbridgeDate,
      weighbridgePlate,
      purchaseRequestId,
      // validityStatus و bureaucracyStage و feeStatus از default اسکیما میان
      // (active / submitted / unpaid) — دستی ست نمی‌شن.
    },
  })

  await logAudit(
    'material-listing',
    `آگهی عرضه ${grade.code} — ${quantityTon} تن${purchaseRequestId ? ' (در پاسخ به درخواست خرید)' : ''}`,
    user.id,
    { listingId: listing.id, gradeId: grade.id, quantityTon, askingPriceToman, province, city, purchaseRequestId }
  )

  // هیچ revalidatePath لازم نیست: /my-listings و /market و /purchase-requests
  // همه force-dynamic هستن، پس در هر درخواست تازه رندر می‌شن.
  return new NextResponse(null, { status: 303, headers: { Location: '/my-listings' } })
}
