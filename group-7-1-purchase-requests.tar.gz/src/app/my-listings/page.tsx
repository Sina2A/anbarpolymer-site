import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import UserNav from '@/components/UserNav'

export const dynamic = 'force-dynamic'

export default async function MyListingsPage() {
  const user = await getCurrentUser()

  // تمام MaterialListing های کاربر
  const myListings = await prisma.materialListing.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    include: {
      grade: true,
    },
  })

  return (
    <div style={pageStyle}>
      <div style={{ maxWidth: 1100, margin: '0 auto', display: 'flex', gap: 24 }} className="admin-page-wrap">
        <UserNav currentUserName={user.companyName} activeSection="listings" />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12, flexWrap: 'wrap' }}>
            <div>
              <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>شبکه عرضه مواد اولیه من</h1>
              <p style={{ fontSize: 13, color: '#9199a3', marginBottom: 20 }}>
                آگهی‌های فروش ثبت‌شده توسط شما
              </p>
            </div>
            <a href="/new-listing" style={ctaBtnStyle}>+ ثبت آگهی عرضه</a>
          </div>

          {myListings.length === 0 ? (
            <div style={emptyCardStyle}>
              <div style={{ fontSize: 40, marginBottom: 12 }}>📦</div>
              <div style={{ fontSize: 15, fontWeight: 700, color: '#1a1a2e', marginBottom: 8 }}>
                هنوز آگهی فروشی ثبت نکردی
              </div>
              <div style={{ fontSize: 13, color: '#6b7280', marginBottom: 16 }}>
                برای عرضه مواد اولیه خود، آگهی فروش ثبت کن تا خریداران ببینند.
              </div>
              <a href="/new-listing" style={ctaBtnStyle}>ثبت آگهی عرضه</a>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {myListings.map((listing) => (
                <div key={listing.id} style={listingCardStyle}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: 10 }}>
                    <div>
                      <h3 style={{ fontSize: 15, fontWeight: 700, margin: 0, marginBottom: 4 }}>
                        {listing.grade.code}
                      </h3>
                      <div style={{ fontSize: 11, color: '#9199a3', fontFamily: 'monospace' }}>
                        #{listing.id.slice(0, 8)}
                      </div>
                    </div>
                    <span style={validityStatusTag(listing.validityStatus)}>
                      {translateValidityStatus(listing.validityStatus)}
                    </span>
                  </div>

                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 12, marginBottom: 10 }}>
                    <div>
                      <div style={{ fontSize: 11, color: '#6b7280', marginBottom: 2 }}>مقدار</div>
                      <div style={{ fontSize: 13, fontWeight: 700 }}>{listing.quantityTon} تن</div>
                    </div>
                    <div>
                      <div style={{ fontSize: 11, color: '#6b7280', marginBottom: 2 }}>قیمت درخواستی</div>
                      <div style={{ fontSize: 13, fontWeight: 700, color: '#e65716' }}>
                        {listing.askingPriceToman.toLocaleString('fa-IR')} تومان/کیلو
                      </div>
                    </div>
                    <div>
                      <div style={{ fontSize: 11, color: '#6b7280', marginBottom: 2 }}>محل</div>
                      <div style={{ fontSize: 13, fontWeight: 600 }}>{listing.city}, {listing.province}</div>
                    </div>
                  </div>

                  <div style={{ display: 'flex', gap: 16, marginBottom: 10, fontSize: 12, color: '#4f5560' }}>
                    <div>
                      <span style={{ color: '#9199a3' }}>بسته‌بندی:</span> {listing.packagingType} ({listing.packagingQuality})
                    </div>
                    <div>
                      <span style={{ color: '#9199a3' }}>کیفیت مواد:</span> {listing.materialQuality}
                    </div>
                  </div>

                  <div style={{ display: 'flex', gap: 8, alignItems: 'center', fontSize: 11, color: '#9199a3' }}>
                    <span>ثبت‌شده: {new Date(listing.createdAt).toLocaleDateString('fa-IR')}</span>
                    {listing.feeStatus !== 'unpaid' && (
                      <>
                        <span>•</span>
                        <span style={feeStatusTag(listing.feeStatus)}>
                          کارمزد: {translateFeeStatus(listing.feeStatus)}
                        </span>
                      </>
                    )}
                    {listing.feeDeadline && new Date(listing.feeDeadline) > new Date() && (
                      <>
                        <span>•</span>
                        <span style={{ color: '#dc2626', fontWeight: 700 }}>
                          مهلت: {new Date(listing.feeDeadline).toLocaleDateString('fa-IR')}
                        </span>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// ── ترجمه ───────────────────────────────────────────────────────────────
function translateValidityStatus(status: string): string {
  const map: Record<string, string> = {
    active: 'فعال',
    reserved: 'رزرو',
    needs_reverification: 'نیازمند بررسی',
    completed: 'انجام‌شده',
    cancelled: 'لغو‌شده',
  }
  return map[status] ?? status
}

function translateFeeStatus(status: string): string {
  const map: Record<string, string> = {
    unpaid: 'پرداخت نشده',
    pending_review: 'در حال بررسی',
    paid: 'پرداخت‌شده',
  }
  return map[status] ?? status
}

// ── تگ‌های رنگی ───────────────────────────────────────────────────────────
function validityStatusTag(status: string): React.CSSProperties {
  let bg = '#f1efe8'
  let color = '#4f5560'

  if (status === 'active') {
    bg = '#d1fae5'
    color = '#065f46'
  } else if (status === 'reserved') {
    bg = '#fef3c7'
    color = '#92400e'
  } else if (status === 'needs_reverification') {
    bg = '#fee2e2'
    color = '#991b1b'
  } else if (status === 'completed') {
    bg = '#e0e7ff'
    color = '#3730a3'
  } else if (status === 'cancelled') {
    bg = '#f3f4f6'
    color = '#6b7280'
  }

  return {
    fontSize: 10,
    fontWeight: 700,
    background: bg,
    color: color,
    borderRadius: 6,
    padding: '4px 10px',
    display: 'inline-block',
  }
}

function feeStatusTag(status: string): React.CSSProperties {
  let color = '#6b7280'
  if (status === 'paid') color = '#065f46'
  if (status === 'pending_review') color = '#92400e'
  return { color, fontWeight: 700 }
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: '#faf8f4',
  padding: '32px 20px',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const emptyCardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 40,
  background: '#fff',
  textAlign: 'center',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const ctaBtnStyle: React.CSSProperties = {
  display: 'inline-block',
  background: '#1e357b',
  color: '#fff',
  borderRadius: 8,
  padding: '9px 18px',
  fontSize: 12.5,
  fontWeight: 700,
  textDecoration: 'none',
  cursor: 'pointer',
  whiteSpace: 'nowrap',
}
const listingCardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 18,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
