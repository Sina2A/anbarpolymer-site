import crypto from 'crypto'
import { cookies } from 'next/headers'
import prisma from './prisma'

const SESSION_COOKIE = 'anbar_session'
const SESSION_DAYS = 7

/**
 * کوکی نشست فقط وقتی «secure» باشه که واقعاً پشت HTTPS باشیم. قبلاً این بر اساس
 * NODE_ENV === 'production' تنظیم می‌شد، ولی این اشتباهه: production بودن به
 * معنی HTTPS بودن نیست. الان که سایت مستقیم روی http://94.184.36.118:3000
 * (بدون SSL) در دسترسه، اون تنظیم قبلی باعث می‌شد مرورگر اصلاً کوکی رو ذخیره
 * نکنه — یعنی لاگین توی دیتابیس ثبت می‌شد ولی مرورگر هیچ نشونه‌ای نداشت، پس
 * هر ناوبری دوباره کاربر رو به /login پرت می‌کرد.
 *
 * الان این با یه متغیر محیطی صریح کنترل می‌شه — پیش‌فرض false (یعنی HTTP خام،
 * وضعیت فعلی سرور). وقتی بعداً یه دامنه‌ی واقعی با گواهی SSL جلوی پورت ۳۰۰۰
 * (یا پشت Nginx) گذاشتی، توی فایل .env سرور این خط رو اضافه کن:
 *   COOKIE_SECURE=true
 * و pm2 restart anbarpolymer بزن — از اون لحظه کوکی‌ها فقط روی HTTPS کار می‌کنن.
 */
const COOKIE_SECURE = process.env.COOKIE_SECURE === 'true'

/**
 * هش کردن رمز عبور با scrypt — بخشی از خودِ Node.js است، نیازی به هیچ
 * پکیج بیرونی (مثل bcrypt که کامپایل native می‌خواد) نیست. با توجه به
 * تاریخچه‌ی این سرور با خطاهای build، این انتخاب عمدیه.
 */
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex')
  const derivedKey = crypto.scryptSync(password, salt, 64)
  return `${salt}:${derivedKey.toString('hex')}`
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const [salt, key] = storedHash.split(':')
  if (!salt || !key) return false
  const derivedKey = crypto.scryptSync(password, salt, 64)
  const keyBuffer = Buffer.from(key, 'hex')
  if (keyBuffer.length !== derivedKey.length) return false
  return crypto.timingSafeEqual(keyBuffer, derivedKey)
}

/**
 * بعد از ورود موفق، یه نشست جدید توی دیتابیس می‌سازه و توکنش رو توی یه
 * کوکی httpOnly می‌ذاره — یعنی جاوااسکریپت سمت مرورگر اصلاً نمی‌تونه
 * بهش دسترسی داشته باشه (محافظت در برابر XSS).
 */
export async function createSession(userId: string) {
  const token = crypto.randomBytes(32).toString('hex')
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000)

  await prisma.session.create({ data: { userId, token, expiresAt } })

  const cookieStore = await cookies()
  cookieStore.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: COOKIE_SECURE,
    sameSite: 'lax',
    expires: expiresAt,
    path: '/',
  })

  await prisma.user.update({ where: { id: userId }, data: { lastLoginAt: new Date() } })
}

/** کاربر واقعیِ لاگین‌شده رو از روی کوکی نشست برمی‌گردونه — یا null اگه لاگین نیست. */
export async function getSessionUser() {
  const cookieStore = await cookies()
  const token = cookieStore.get(SESSION_COOKIE)?.value
  if (!token) return null

  const session = await prisma.session.findUnique({ where: { token }, include: { user: true } })
  if (!session) return null
  if (session.expiresAt < new Date()) {
    await prisma.session.delete({ where: { token } }).catch(() => {})
    return null
  }
  if (!session.user.isActive) return null

  return session.user
}

export async function destroySession() {
  const cookieStore = await cookies()
  const token = cookieStore.get(SESSION_COOKIE)?.value
  if (token) {
    await prisma.session.delete({ where: { token } }).catch(() => {})
  }
  cookieStore.delete(SESSION_COOKIE)
}
