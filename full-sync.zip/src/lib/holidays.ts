import prisma from './prisma'

// ==================== تبدیل تاریخ شمسی به میلادی ====================
// الگوریتم استاندارد و عمومی (بدون هیچ وابستگی بیرونی) — چون فایل CSV
// تعطیلات رسمی ایران معمولاً با تاریخ شمسی میاد (مثلاً «۱۴۰۵/۰۱/۰۱»)، ولی
// دیتابیس ما تاریخ رو به‌صورت میلادی ذخیره می‌کنه.

const JALAALI_BREAKS = [
  -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210,
  1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178,
]

function jdiv(a: number, b: number) { return ~~(a / b) }
function jmod(a: number, b: number) { return a - ~~(a / b) * b }

function jalCal(jy: number) {
  const bl = JALAALI_BREAKS.length
  const gy = jy + 621
  let leapJ = -14
  let jp = JALAALI_BREAKS[0]
  if (jy < jp || jy >= JALAALI_BREAKS[bl - 1]) {
    throw new Error('سال شمسی خارج از بازه‌ی پشتیبانی‌شده: ' + jy)
  }
  let jump = 0
  for (let i = 1; i < bl; i += 1) {
    const jm = JALAALI_BREAKS[i]
    jump = jm - jp
    if (jy < jm) break
    leapJ = leapJ + jdiv(jump, 33) * 8 + jdiv(jmod(jump, 33), 4)
    jp = jm
  }
  let n = jy - jp
  leapJ = leapJ + jdiv(n, 33) * 8 + jdiv(jmod(n, 33) + 3, 4)
  if (jmod(jump, 33) === 4 && jump - n === 4) leapJ += 1
  const leapG = jdiv(gy, 4) - jdiv((jdiv(gy, 100) + 1) * 3, 4) - 150
  const march = 20 + leapJ - leapG
  if (jump - n < 6) n = n - jump + jdiv(jump, 33) * 33
  return { march }
}

function g2d(gy: number, gm: number, gd: number) {
  let d = jdiv((gy + jdiv(gm - 8, 6) + 100100) * 1461, 4)
    + jdiv(153 * jmod(gm + 9, 12) + 2, 5)
    + gd - 34840408
  d = d - jdiv(jdiv(gy + 100100 + jdiv(gm - 8, 6), 100) * 3, 4) + 752
  return d
}

function d2g(jdn: number): [number, number, number] {
  let j = 4 * jdn + 139361631
  j = j + jdiv(jdiv(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908
  const i = jdiv(jmod(j, 1461), 4) * 5 + 308
  const gd = jdiv(jmod(i, 153), 5) + 1
  const gm = jmod(jdiv(i, 153), 12) + 1
  const gy = jdiv(j, 1461) - 100100 + jdiv(8 - gm, 6)
  return [gy, gm, gd]
}

function j2d(jy: number, jm: number, jd: number) {
  const r = jalCal(jy)
  return g2d(jy + 621, 3, r.march) + (jm - 1) * 31 - jdiv(jm, 7) * (jm - 7) + jd - 1
}

/** تاریخ شمسی (سال، ماه، روز) رو به تاریخ میلادی [سال، ماه، روز] تبدیل می‌کنه. */
export function jalaaliToGregorian(jy: number, jm: number, jd: number): [number, number, number] {
  return d2g(j2d(jy, jm, jd))
}

// ==================== وارد کردن گروهی از CSV ====================

/**
 * فرمت CSV: هر خط `تاریخ,عنوان` (عنوان اختیاری). تاریخ می‌تونه شمسی
 * («۱۴۰۵/۰۱/۰۱» یا «1405-01-01») یا میلادی («2026-03-21») باشه — خودکار بر
 * اساس بزرگی سال تشخیص داده می‌شه (زیر ۱۵۰۰ یعنی شمسی). خط اول اگه خودش
 * تاریخ معتبر نباشه، به‌عنوان هدر نادیده گرفته می‌شه.
 */
export function parseHolidayCsv(csvText: string): { valid: { date: Date; title: string }[]; skippedLines: number } {
  const lines = csvText.split(/\r?\n/).map((l) => l.trim()).filter(Boolean)
  const valid: { date: Date; title: string }[] = []
  let skippedLines = 0

  for (const line of lines) {
    const parts = line.split(',')
    const rawDate = (parts[0] || '').trim().replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    const title = (parts[1] || '').trim()

    const m = rawDate.match(/^(\d{3,4})[\/\-](\d{1,2})[\/\-](\d{1,2})$/)
    if (!m) {
      skippedLines += 1
      continue
    }
    const y = parseInt(m[1], 10)
    const mo = parseInt(m[2], 10)
    const d = parseInt(m[3], 10)

    try {
      let date: Date
      if (y < 1500) {
        const [gy, gm, gd] = jalaaliToGregorian(y, mo, d)
        date = new Date(gy, gm - 1, gd)
      } else {
        date = new Date(y, mo - 1, d)
      }
      if (Number.isNaN(date.getTime())) {
        skippedLines += 1
        continue
      }
      date.setHours(0, 0, 0, 0)
      valid.push({ date, title })
    } catch {
      skippedLines += 1
    }
  }

  return { valid, skippedLines }
}

export async function importHolidaysFromCsv(csvText: string) {
  const { valid, skippedLines } = parseHolidayCsv(csvText)

  for (const h of valid) {
    await prisma.holiday.upsert({
      where: { date: h.date },
      update: { title: h.title || null },
      create: { date: h.date, title: h.title || null },
    })
  }

  return { addedCount: valid.length, skippedLines }
}

/**
 * منطق این فایل: «۷۲ ساعت غیر از تعطیلات رسمی و عمومی» یعنی هر روز تقویمی
 * (نه بازه‌ی ساعتی دقیق) که جمعه یا توی جدول Holiday ثبت شده باشه، ۲۴ ساعت
 * کامل به مهلت اضافه می‌شه — انگار اون روز اصلاً نبوده.
 *
 * این یه ساده‌سازی عمدیه (نه محاسبه‌ی ساعت‌به‌ساعت کاری)، چون قانون کسب‌وکاری
 * که تعریف شده («۷۲ ساعت از بارگیری، غیر از روزهای تعطیل») درباره‌ی روز کامل
 * صحبت می‌کنه نه ساعت اداری. اگه بعداً قرار شد این متن دقیق قراردادی بشه،
 * وکیل باید عبارت رو تایید کنه؛ الگوریتم اینجا هرچی که تصمیم نهایی باشه راحت
 * قابل تنظیمه.
 */

const FRIDAY = 5 // JS: getDay() === 5 یعنی جمعه

function toDateKey(d: Date): string {
  return d.toISOString().slice(0, 10) // YYYY-MM-DD
}

function startOfDay(d: Date): Date {
  const copy = new Date(d)
  copy.setHours(0, 0, 0, 0)
  return copy
}

async function getHolidayDateKeys(): Promise<Set<string>> {
  const holidays = await prisma.holiday.findMany()
  return new Set(holidays.map((h) => toDateKey(h.date)))
}

function isNonWorkingDay(day: Date, holidayKeys: Set<string>): boolean {
  return day.getDay() === FRIDAY || holidayKeys.has(toDateKey(day))
}

/**
 * از `start`، `hours` ساعت جلو می‌ره؛ برای هر روز تقویمی که بین شروع و مهلت
 * جمعه یا تعطیل رسمی باشه، ۲۴ ساعت به مهلت اضافه می‌شه. چون اضافه‌کردن ممکنه
 * روزهای تعطیل جدیدی رو وارد بازه کنه، تا زمانی که دیگه چیزی تغییر نکنه تکرار
 * می‌شه (زنجیره‌ی چند تعطیلی پشت‌سرهم رو هم درست پوشش می‌ده).
 */
export async function calculateHolidayAdjustedDeadline(start: Date, hours: number): Promise<Date> {
  const holidayKeys = await getHolidayDateKeys()
  let deadline = new Date(start.getTime() + hours * 60 * 60 * 1000)

  let changed = true
  while (changed) {
    changed = false
    let cursor = startOfDay(start)
    const lastDay = startOfDay(deadline)

    while (cursor.getTime() <= lastDay.getTime()) {
      if (isNonWorkingDay(cursor, holidayKeys)) {
        deadline = new Date(deadline.getTime() + 24 * 60 * 60 * 1000)
        changed = true
      }
      cursor = new Date(cursor.getTime() + 24 * 60 * 60 * 1000)
    }
  }

  return deadline
}

// ==================== مدیریت تعطیلات (پنل ادمین) ====================

export async function listHolidays() {
  return prisma.holiday.findMany({ orderBy: { date: 'asc' } })
}

export async function addHoliday(dateStr: string, title: string) {
  const date = startOfDay(new Date(dateStr))
  return prisma.holiday.upsert({
    where: { date },
    update: { title: title || null },
    create: { date, title: title || null },
  })
}

export async function removeHoliday(id: string) {
  await prisma.holiday.delete({ where: { id } })
}
