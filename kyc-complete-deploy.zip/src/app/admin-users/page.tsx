import prisma from '@/lib/prisma'
import { SECTION_KEYS, getAllSectionAccess } from '@/lib/permissions'
import { getCurrentUser } from '@/lib/currentUser'
import { listWeeklyBusinessHours } from '@/lib/businessHours'
import { getPasswordPolicy } from '@/lib/passwordPolicy'
import { createStaffUser, setPermission, toggleUserActive, changeUserRole, updateUserInfo, upsertWeeklyHourAction, reviewKycLevel1Action, reviewProducerLicenseAction, updatePasswordPolicyAction } from './actions'
import AdminNav, { PartialAccessBanner } from '@/components/AdminNav'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'

export const dynamic = 'force-dynamic'

export default async function AdminUsersPage() {
  // getCurrentUser دیگه از session واقعی می‌خونه — اگه لاگین نباشه، خودش به /login می‌فرسته
  const currentUser = await getCurrentUser()

  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)

  return (
    <div style={{ display: 'flex', gap: 24, padding: '32px 24px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', maxWidth: 1100, margin: '0 auto' }}>
      <AdminNav currentUserName={currentUser.companyName} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="users" />

      <div style={{ flex: 1, minWidth: 0 }}>
        {isAdmin ? (
          <AdminFullView currentUser={currentUser} />
        ) : (
          <>
            {(myAccess?.kyc === 'view' || myAccess?.kyc === 'edit' || myAccess?.kyc === 'full') && (
              <KycReviewSection currentUser={currentUser} />
            )}
            <SelfProfileView user={currentUser} />
          </>
        )}

      </div>
    </div>
  )
}

async function KycReviewSection({ currentUser }: { currentUser: { id: string } }) {
  const pendingCompanyKyc = await prisma.company.findMany({
    where: { kyc: { level: 0, documentsSubmittedAt: { not: null } } },
    include: { kyc: true, user: true },
  })
  const pendingProducerKyc = await prisma.company.findMany({
    where: { kyc: { level: 1, producerDocumentsSubmittedAt: { not: null } } },
    include: { kyc: true, user: true },
  })

  if (pendingCompanyKyc.length === 0 && pendingProducerKyc.length === 0) return null

  return (
    <div style={cardStyle}>
      <h3 style={{ fontSize: 15, marginBottom: 6 }}>🪪 احراز هویت در انتظار بررسی</h3>
      <p style={{ fontSize: 11.5, color: '#9199a3', marginBottom: 16, lineHeight: 1.9 }}>
        هویت شرکت (گام ۱): شناسه‌ی ملی رو با{' '}
        <a href="https://rrk.ir" target="_blank" style={{ color: '#1e357b' }}>rrk.ir</a> (روزنامه‌ی رسمی کشور، رایگان) تطبیق بده.
        <br />
        احراز تولیدکننده (گام ۲): شماره‌ی پروانه رو با شناسه‌ی ملی روی{' '}
        <a href="https://behinyab.ir" target="_blank" style={{ color: '#1e357b' }}>behinyab.ir</a> تطبیق بده (این سامانه API عمومی نداره).
      </p>

      {pendingCompanyKyc.map((c) => (
        <div key={c.id} style={{ border: '1px solid #eceff3', borderRadius: 10, padding: 14, marginBottom: 10 }}>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 6 }}>گام ۱ — {c.companyName} <span style={{ fontWeight: 400, color: '#9199a3' }}>({c.user.phone})</span></div>
          <div style={{ fontSize: 12, color: '#4f5560', lineHeight: 1.9, marginBottom: 8 }}>
            شناسه‌ی ملی: {c.nationalId} — شماره‌ی ثبت: {c.registrationNumber} — {c.province}, {c.city}
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <form action={reviewKycLevel1Action}>
              <input type="hidden" name="companyId" value={c.id} />
              <input type="hidden" name="approve" value="true" />
              <input type="hidden" name="reviewerId" value={currentUser.id} />
              <ConfirmSubmitButton message={`هویت شرکت «${c.companyName}» تایید بشه؟`} style={{ ...btnStyle, padding: '6px 16px', fontSize: 12 }}>تایید</ConfirmSubmitButton>
            </form>
            <form action={reviewKycLevel1Action}>
              <input type="hidden" name="companyId" value={c.id} />
              <input type="hidden" name="approve" value="false" />
              <input type="hidden" name="reviewerId" value={currentUser.id} />
              <ConfirmSubmitButton message={`رد بشه؟`} style={{ ...statusBtn, ...inactiveStatus, padding: '6px 16px' }}>رد</ConfirmSubmitButton>
            </form>
          </div>
        </div>
      ))}

      {pendingProducerKyc.map((c) => (
        <div key={c.id} style={{ border: '1px solid #eceff3', borderRadius: 10, padding: 14, marginBottom: 10, background: '#fafbfc' }}>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 6 }}>گام ۲ (تولیدکننده) — {c.companyName}</div>
          <div style={{ fontSize: 12, color: '#4f5560', lineHeight: 1.9, marginBottom: 8 }}>
            شماره‌ی پروانه: {c.kyc?.productionLicenseNumber} {c.kyc?.productionLicenseIsSetup && '(جواز تاسیس، نه پروانه‌ی نهایی)'}
            <br />
            آدرس کارخانه: {c.kyc?.factoryAddress} — فعالیت: {c.kyc?.factoryActivityType}
            <br />
            {c.kyc?.productionLicenseFileUrl && <a href={c.kyc.productionLicenseFileUrl} target="_blank" style={{ color: '#1e357b' }}>تصویر پروانه ↗</a>}
          </div>
          <form action={reviewProducerLicenseAction} style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
            <input type="hidden" name="companyId" value={c.id} />
            <input type="hidden" name="reviewerId" value={currentUser.id} />
            <label style={{ fontSize: 11.5, display: 'flex', alignItems: 'center', gap: 5 }}>
              <input type="checkbox" name="licenseVerifiedManually" required />
              با behinyab.ir تطبیق دادم
            </label>
            <button type="submit" name="approve" value="true" style={{ ...btnStyle, padding: '6px 16px', fontSize: 12 }}>تایید تولیدکننده</button>
            <button type="submit" name="approve" value="false" style={{ ...statusBtn, ...inactiveStatus, padding: '6px 16px' }}>رد</button>
          </form>
        </div>
      ))}
    </div>
  )
}

// ==================== نمای مدیر: مدیریت کامل کاربران ====================

async function AdminFullView({ currentUser }: { currentUser: { id: string } }) {
  const staff = await prisma.user.findMany({
    where: { role: { in: ['staff', 'admin'] } },
    include: { permissions: true },
    orderBy: { createdAt: 'asc' },
  })
  const weeklyHours = await listWeeklyBusinessHours()
  const passwordPolicy = await getPasswordPolicy()

  return (
    <>
      <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 8 }}>مدیریت کاربران و دسترسی‌ها</h1>
      <p style={{ color: '#6f7680', fontSize: 13.5, marginBottom: 28, lineHeight: 1.9 }}>
        فقط یک نفر می‌تواند هم‌زمان نقش «مدیر» داشته باشد. مدیر می‌تواند همه‌چیز را تغییر دهد؛ برای تغییرات حساس (نقش، اطلاعات هویتی، غیرفعال‌سازی) یک تاییدیه نمایش داده می‌شود.
      </p>

      <KycReviewSection currentUser={currentUser} />

      <div style={cardStyle}>
        <h3 style={{ fontSize: 15, marginBottom: 6 }}>🕐 ساعات کاری هفتگی</h3>
        <p style={{ fontSize: 11.5, color: '#9199a3', marginBottom: 14, lineHeight: 1.8 }}>
          محور محاسبه‌ی همه‌ی مهلت‌های ساعت‌کاری سایت (کارمزد فروشنده، پرداخت خریدار، گزارش مغایرت، واریز وجه).
          اولویت با جدول تعطیلات رسمیه (توی بخش «معاملات تجاری»)؛ این فقط الگوی تکرارشونده‌ی هرهفته‌ست. این بخش
          عمداً فقط برای نقش «مدیر» در دسترسه، نه کارشناس.
        </p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {weeklyHours.map((d) => (
            <form key={d.dayOfWeek} action={upsertWeeklyHourAction} style={{ display: 'flex', gap: 10, alignItems: 'center', fontSize: 12.5, borderBottom: '1px dashed #eceff3', paddingBottom: 8 }}>
              <input type="hidden" name="dayOfWeek" value={d.dayOfWeek} />
              <span style={{ width: 66, fontWeight: 700 }}>{d.label}</span>
              <label style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                <input type="checkbox" name="isOpen" value="on" defaultChecked={d.isOpen} />
                باز
              </label>
              <span style={{ color: '#9199a3' }}>از</span>
              <input type="time" name="openTime" defaultValue={d.openTime} style={{ ...inputStyle, padding: '5px 8px' }} />
              <span style={{ color: '#9199a3' }}>تا</span>
              <input type="time" name="closeTime" defaultValue={d.closeTime} style={{ ...inputStyle, padding: '5px 8px' }} />
              <button type="submit" style={{ ...btnStyle, padding: '5px 14px', fontSize: 11.5 }}>ذخیره</button>
            </form>
          ))}
        </div>
      </div>

      <div style={cardStyle}>
        <h3 style={{ fontSize: 15, marginBottom: 6 }}>🔒 سیاست رمز عبور</h3>
        <p style={{ fontSize: 11.5, color: '#9199a3', marginBottom: 14, lineHeight: 1.8 }}>
          روی همه‌ی حساب‌های جدید (ثبت‌نام، بازیابی رمز) اعمال می‌شه. اگه «انقضا» رو فعال کنی، کاربرهایی که رمزشون
          قدیمی‌تر از این مدته، موقع ورود بعدی مجبور به تنظیم رمز جدید می‌شن.
        </p>
        <form action={updatePasswordPolicyAction} style={{ display: 'flex', flexDirection: 'column', gap: 10, fontSize: 12.5 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ width: 140 }}>حداقل طول رمز</span>
            <input type="number" name="minLength" min={4} max={64} defaultValue={passwordPolicy.minLength} style={{ ...inputStyle, width: 80, padding: '5px 8px' }} />
            <span style={{ color: '#9199a3' }}>کاراکتر</span>
          </div>
          <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <input type="checkbox" name="requireNumber" defaultChecked={passwordPolicy.requireNumber} />
            حداقل یک عدد الزامی باشه
          </label>
          <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <input type="checkbox" name="requireUppercase" defaultChecked={passwordPolicy.requireUppercase} />
            حداقل یک حرف بزرگ انگلیسی الزامی باشه
          </label>
          <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <input type="checkbox" name="requireSpecialChar" defaultChecked={passwordPolicy.requireSpecialChar} />
            حداقل یک نویسه‌ی خاص (! @ # ...) الزامی باشه
          </label>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ width: 140 }}>انقضای رمز عبور</span>
            <input type="number" name="expiryDays" min={0} placeholder="خالی = هیچ‌وقت" defaultValue={passwordPolicy.expiryDays ?? ''} style={{ ...inputStyle, width: 100, padding: '5px 8px' }} />
            <span style={{ color: '#9199a3' }}>روز (خالی بذار برای غیرفعال)</span>
          </div>
          <input type="hidden" name="updatedById" value={currentUser.id} />
          <ConfirmSubmitButton message="سیاست رمز عبور برای همه‌ی حساب‌ها تغییر می‌کنه. مطمئنی؟" style={{ ...btnStyle, alignSelf: 'flex-start', padding: '7px 20px' }}>
            ذخیره
          </ConfirmSubmitButton>
        </form>
      </div>

      <div style={cardStyle}>
        <h3 style={{ fontSize: 15, marginBottom: 14 }}>افزودن کارشناس جدید</h3>
        <form action={createStaffUser} style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
          <input name="companyName" placeholder="نام و نام خانوادگی" required style={inputStyle} />
          <input name="phone" placeholder="شماره تماس" required style={inputStyle} />
          <select name="role" style={inputStyle}>
            <option value="staff">کارشناس</option>
            <option value="admin">مدیر</option>
          </select>
          <button type="submit" style={btnStyle}>افزودن کارشناس</button>
        </form>
        <div style={{ fontSize: 11.5, color: '#9199a3', marginTop: 10 }}>
          اگر «مدیر» انتخاب شود ولی از قبل یک مدیر فعال دیگر وجود داشته باشد، حساب به‌جایش با نقش «کارشناس» ساخته می‌شود.
        </div>
      </div>

      {staff.map((u) => (
        <div key={u.id} style={cardStyle}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, flexWrap: 'wrap', gap: 10 }}>
            <div>
              <b style={{ fontSize: 14 }}>{u.companyName}</b>{' '}
              <span style={{ color: '#9199a3', fontSize: 12, fontFamily: 'monospace', direction: 'ltr', display: 'inline-block' }}>— {u.phone}</span>
            </div>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
              <form action={changeUserRole} style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                <input type="hidden" name="userId" value={u.id} />
                <select name="newRole" defaultValue={u.role} style={{ ...inputStyle, padding: '5px 8px', fontSize: 11.5 }}>
                  <option value="staff">کارشناس</option>
                  <option value="admin">مدیر</option>
                </select>
                <ConfirmSubmitButton
                  message={`آیا مطمئنی می‌خوای نقش «${u.companyName}» رو تغییر بدی؟ این یک عملیات حساسه.`}
                  style={{ ...btnStyle, padding: '5px 12px', fontSize: 11.5 }}
                >
                  اعمال نقش
                </ConfirmSubmitButton>
              </form>
              <form action={toggleUserActive}>
                <input type="hidden" name="userId" value={u.id} />
                <input type="hidden" name="value" value={(!u.isActive).toString()} />
                <ConfirmSubmitButton
                  message={u.isActive ? `«${u.companyName}» غیرفعال بشه؟ دیگه به هیچ بخشی دسترسی نخواهد داشت.` : `«${u.companyName}» دوباره فعال بشه؟`}
                  style={{ ...statusBtn, ...(u.isActive ? activeStatus : inactiveStatus) }}
                >
                  {u.isActive ? 'فعال' : 'غیرفعال'}
                </ConfirmSubmitButton>
              </form>
            </div>
          </div>

          <details style={{ marginBottom: 14 }}>
            <summary style={{ fontSize: 12.5, color: '#1e357b', cursor: 'pointer', fontWeight: 600 }}>تغییر اطلاعات کاربر</summary>
            <form action={updateUserInfo} style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginTop: 12 }}>
              <input type="hidden" name="userId" value={u.id} />
              <input name="companyName" defaultValue={u.companyName} style={inputStyle} />
              <input name="phone" defaultValue={u.phone ?? ''} style={{ ...inputStyle, direction: 'ltr' }} />
              <ConfirmSubmitButton message={`اطلاعات هویتی «${u.companyName}» تغییر کنه؟`} style={btnStyle}>
                ذخیره‌ی تغییرات
              </ConfirmSubmitButton>
            </form>
          </details>

          <table style={{ width: '100%', fontSize: 12.5, borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ color: '#6f7680', textAlign: 'right' }}>
                <th style={thStyle}>بخش پنل</th>
                <th style={{ ...thStyle, width: 90 }}>مشاهده</th>
                <th style={{ ...thStyle, width: 90 }}>ویرایش</th>
              </tr>
            </thead>
            <tbody>
              {SECTION_KEYS.map((sec) => {
                const perm = u.permissions.find((p) => p.section === sec.key)
                return (
                  <tr key={sec.key} style={{ borderTop: '1px solid #eceff3' }}>
                    <td style={tdStyle}>{sec.label}</td>
                    <td style={tdStyle}>
                      <form action={setPermission}>
                        <input type="hidden" name="userId" value={u.id} />
                        <input type="hidden" name="section" value={sec.key} />
                        <input type="hidden" name="field" value="canView" />
                        <input type="hidden" name="value" value={(!perm?.canView).toString()} />
                        <button type="submit" aria-label="مشاهده" style={{ ...checkBtn, background: perm?.canView ? '#22c55e' : '#eceff3', borderColor: perm?.canView ? '#22c55e' : '#c8d0da' }} />
                      </form>
                    </td>
                    <td style={tdStyle}>
                      <form action={setPermission}>
                        <input type="hidden" name="userId" value={u.id} />
                        <input type="hidden" name="section" value={sec.key} />
                        <input type="hidden" name="field" value="canEdit" />
                        <input type="hidden" name="value" value={(!perm?.canEdit).toString()} />
                        <button type="submit" aria-label="ویرایش" style={{ ...checkBtn, background: perm?.canEdit ? '#f6621b' : '#eceff3', borderColor: perm?.canEdit ? '#f6621b' : '#c8d0da' }} />
                      </form>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      ))}
    </>
  )
}

// ==================== نمای کارشناس عادی: فقط پروفایل خودش ====================

function SelfProfileView({ user }: { user: any }) {
  return (
    <>
      <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 8 }}>پروفایل من</h1>
      <p style={{ color: '#6f7680', fontSize: 13.5, marginBottom: 24 }}>اطلاعات حساب و دسترسی‌های خودت به بخش‌های مختلف پنل.</p>

      <div style={cardStyle}>
        <h3 style={{ fontSize: 15, marginBottom: 14 }}>اطلاعات حساب</h3>
        <div style={{ fontSize: 13.5, color: '#4f5560', lineHeight: 2.2 }}>
          <div><b style={{ color: '#1b1e24' }}>نام:</b> {user.companyName}</div>
          {user.username && <div><b style={{ color: '#1b1e24' }}>نام کاربری:</b> <span style={{ direction: 'ltr', display: 'inline-block' }}>{user.username}</span></div>}
          {user.phone && <div><b style={{ color: '#1b1e24' }}>شماره تماس:</b> <span style={{ direction: 'ltr', display: 'inline-block' }}>{user.phone}</span></div>}
          <div><b style={{ color: '#1b1e24' }}>نقش:</b> کارشناس</div>
        </div>
        <div style={{ fontSize: 11.5, color: '#9199a3', marginTop: 12 }}>
          برای تغییر این اطلاعات با مدیر سیستم هماهنگ کن.
        </div>
      </div>

      <div style={cardStyle}>
        <h3 style={{ fontSize: 15, marginBottom: 14 }}>بخش‌هایی که بهشون دسترسی داری</h3>
        {user.permissions.filter((p: any) => p.canView || p.canEdit).length === 0 ? (
          <div style={{ color: '#9199a3', fontSize: 13 }}>هنوز هیچ دسترسی‌ای برات تعریف نشده — با مدیر سیستم هماهنگ کن.</div>
        ) : (
          <table style={{ width: '100%', fontSize: 12.5, borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ color: '#6f7680', textAlign: 'right' }}>
                <th style={thStyle}>بخش پنل</th>
                <th style={thStyle}>سطح دسترسی</th>
              </tr>
            </thead>
            <tbody>
              {SECTION_KEYS.filter((sec) => user.permissions.some((p: any) => p.section === sec.key && (p.canView || p.canEdit))).map((sec) => {
                const perm = user.permissions.find((p: any) => p.section === sec.key)
                const label = perm.canView && perm.canEdit ? 'مشاهده و ویرایش' : perm.canView ? 'فقط مشاهده' : 'فقط ویرایش'
                return (
                  <tr key={sec.key} style={{ borderTop: '1px solid #eceff3' }}>
                    <td style={tdStyle}>{sec.label}</td>
                    <td style={tdStyle}>{label}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        )}
      </div>
    </>
  )
}

const cardStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 12, padding: 22, marginBottom: 16, background: '#fff', boxShadow: '0 1px 4px rgba(27,30,36,.05)' }
const inputStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 8, padding: '9px 12px', fontSize: 13, fontFamily: 'inherit' }
const btnStyle: React.CSSProperties = { background: '#1e357b', color: '#fff', border: 'none', borderRadius: 8, padding: '9px 18px', fontSize: 13, fontWeight: 700, cursor: 'pointer' }
const thStyle: React.CSSProperties = { padding: '6px 4px', fontWeight: 600 }
const tdStyle: React.CSSProperties = { padding: '8px 4px' }
const checkBtn: React.CSSProperties = { width: 20, height: 20, borderRadius: 5, border: '1px solid', cursor: 'pointer' }
const statusBtn: React.CSSProperties = { fontSize: 10.5, fontWeight: 700, borderRadius: 5, padding: '3px 10px', border: 'none', cursor: 'pointer' }
const activeStatus: React.CSSProperties = { background: '#dcfce7', color: '#146c3a' }
const inactiveStatus: React.CSSProperties = { background: '#fee2e2', color: '#a8241a' }
