'use server'

import { getCurrentUser } from '@/lib/currentUser'
import { submitCompanyDocuments, submitProducerLicense } from '@/lib/kyc'
import { revalidatePath } from 'next/cache'

export async function submitCompanyStepAction(formData: FormData) {
  const user = await getCurrentUser()

  await submitCompanyDocuments({
    userId: user.id,
    companyName: String(formData.get('companyName') || ''),
    legalType: String(formData.get('legalType') || 'factory'),
    nationalId: String(formData.get('nationalId') || ''),
    registrationNumber: String(formData.get('registrationNumber') || ''),
    province: String(formData.get('province') || ''),
    city: String(formData.get('city') || ''),
    address: String(formData.get('address') || ''),
  })

  revalidatePath('/verification')
}

export async function submitProducerStepAction(formData: FormData) {
  const user = await getCurrentUser()

  const licenseFile = formData.get('licenseFile') as File | null

  await submitProducerLicense({
    userId: user.id,
    productionLicenseNumber: String(formData.get('productionLicenseNumber') || ''),
    productionLicenseIsSetup: formData.get('productionLicenseIsSetup') === 'on',
    factoryAddress: String(formData.get('factoryAddress') || ''),
    factoryActivityType: String(formData.get('factoryActivityType') || ''),
    factoryProducts: String(formData.get('factoryProducts') || ''),
    licenseFile: licenseFile && licenseFile.size > 0 ? licenseFile : null,
  })

  revalidatePath('/verification')
}
