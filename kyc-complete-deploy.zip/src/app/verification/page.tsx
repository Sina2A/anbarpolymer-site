import { getCurrentUser } from '@/lib/currentUser'
import { getKycForUser } from '@/lib/kyc'
import { submitCompanyStepAction, submitProducerStepAction } from './actions'

export const dynamic = 'force-dynamic'

const LEGAL_TYPES = [
  { value: 'factory', label: 'کارخانه / واحد تولیدی' },
  { value: 'production_unit', label: 'واحد تولیدی کوچک' },
  { value: 'trading_company', label: 'شرکت بازرگانی' },
  { value: 'cooperative', label: 'تعاونی' },
  { value: 'official_agent', label: 'نماینده‌ی رسمی' },
  { value: 'importer', label: 'واردکننده' },
  { value: 'exporter', label: 'صادرکننده' },
]

export default async function VerificationPage() {
  const user = await getCurrentUser()
  const company = await getKycForUser(user.id)
  const kyc = company?.kyc

  const level = kyc?.level ?? 0
  const step1Pending = kyc?.documentsSubmittedAt && level < 1
  const step2Pending = kyc?.producerDocumentsSubmittedAt && level < 2 && level >= 1

  return (
    <div style={pageStyle}>
      <div style={containerStyle}>
        <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 6 }}>احراز هویت</h1>
        <p style={{ color: '#6f7680', fontSize: 13.5, marginBottom: 28, lineHeight: 1.9 }}>
          برای استفاده از همه‌ی امکانات سایت (دیدن قیمت دقیق، ارسال استعلام، خرید/فروش) باید مدارک هویتی رو تکمیل کنی.
          تا وقتی احراز نشده، فقط بخش عمومی (لیست گریدها، مقالات) رو می‌بینی.
        </p>

        <StatusBadge level={level} />

        {/* ---------- گام ۱: هویت شرکت ---------- */}
        <div style={cardStyle}>
          <h3 style={{ fontSize: 16, marginBottom: 4 }}>گام ۱ — هویت شرکت</h3>
          <p style={{ fontSize: 12, color: '#9199a3', marginBottom: 16 }}>
            برای دیدن قیمت‌های دقیق و ارسال استعلام لازمه. نیازی به آپلود مدرک نیست — فقط اطلاعات زیر رو دقیق وارد کن،
            کارشناس از طریق سامانه‌ی رسمی «روزنامه‌ی رسمی کشور» تطبیقش می‌ده.
          </p>

          {level >= 1 ? (
            <div style={{ background: '#eaf3de', color: '#27500a', borderRadius: 8, padding: '10px 14px', fontSize: 13, fontWeight: 600 }}>
              ✓ تایید شده
            </div>
          ) : step1Pending ? (
            <div style={{ background: '#fef3c7', color: '#92400e', borderRadius: 8, padding: '10px 14px', fontSize: 13, fontWeight: 600 }}>
              ⏳ اطلاعات ارسال شد، منتظر بررسی کارشناسه
            </div>
          ) : (
            <form action={submitCompanyStepAction} style={{ display: 'flex', flexDirection: 'column', gap: 12, marginTop: 10 }}>
              <input name="companyName" placeholder="نام کامل شرکت" defaultValue={company?.companyName} required style={inputStyle} />
              <select name="legalType" defaultValue={company?.legalType || 'factory'} style={inputStyle}>
                {LEGAL_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
              </select>
              <input name="nationalId" placeholder="شناسه‌ی ملی شرکت" defaultValue={company?.nationalId || ''} required style={inputStyle} />
              <input name="registrationNumber" placeholder="شماره‌ی ثبت" defaultValue={company?.registrationNumber || ''} required style={inputStyle} />
              <div style={{ display: 'flex', gap: 10 }}>
                <input name="province" placeholder="استان" defaultValue={company?.province || ''} required style={{ ...inputStyle, flex: 1 }} />
                <input name="city" placeholder="شهر" defaultValue={company?.city || ''} required style={{ ...inputStyle, flex: 1 }} />
              </div>
              <input name="address" placeholder="آدرس دقیق" defaultValue={company?.address || ''} required style={inputStyle} />

              <button type="submit" style={submitBtnStyle}>ارسال برای بررسی</button>
            </form>
          )}
        </div>

        {/* ---------- گام ۲: احراز تولیدکننده ---------- */}
        <div style={cardStyle}>
          <h3 style={{ fontSize: 16, marginBottom: 4 }}>گام ۲ — احراز تولیدکننده</h3>
          <p style={{ fontSize: 12, color: '#9199a3', marginBottom: 16 }}>فقط لازمه اگه می‌خوای توی سایت بار بفروشی (شبکه عرضه).</p>

          {level < 1 ? (
            <div style={{ background: '#f1eee8', color: '#6f7680', borderRadius: 8, padding: '10px 14px', fontSize: 13 }}>
              اول باید گام ۱ تایید بشه.
            </div>
          ) : level >= 2 ? (
            <div style={{ background: '#eaf3de', color: '#27500a', borderRadius: 8, padding: '10px 14px', fontSize: 13, fontWeight: 600 }}>
              ✓ تولیدکننده‌ی تایید‌شده — می‌تونی توی شبکه عرضه بار ثبت کنی
            </div>
          ) : step2Pending ? (
            <div style={{ background: '#fef3c7', color: '#92400e', borderRadius: 8, padding: '10px 14px', fontSize: 13, fontWeight: 600 }}>
              ⏳ مدارک ارسال شد، منتظر بررسی کارشناسه (تطبیق با سامانه‌ی بهین‌یاب)
            </div>
          ) : (
            <form action={submitProducerStepAction} style={{ display: 'flex', flexDirection: 'column', gap: 12, marginTop: 10 }}>
              <input name="productionLicenseNumber" placeholder="شماره‌ی پروانه‌ی بهره‌برداری" required style={inputStyle} />
              <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
                <input type="checkbox" name="productionLicenseIsSetup" />
                واحد هنوز در حال احداثه (به‌جاش جواز تاسیس دارم، نه پروانه‌ی نهایی)
              </label>
              <input name="factoryAddress" placeholder="آدرس دقیق کارخانه" required style={inputStyle} />
              <input name="factoryActivityType" placeholder="نوع فعالیت تولیدی" required style={inputStyle} />
              <textarea name="factoryProducts" placeholder="محصولات تولیدی" rows={3} style={{ ...inputStyle, fontFamily: 'inherit', resize: 'vertical' }} />

              <label style={fileLabelStyle}>
                تصویر پروانه‌ی بهره‌برداری (یا جواز تاسیس)
                <input type="file" name="licenseFile" accept=".pdf,image/*" required style={{ marginTop: 6 }} />
              </label>

              <button type="submit" style={submitBtnStyle}>ارسال برای بررسی</button>
            </form>
          )}
        </div>
      </div>
    </div>
  )
}

function StatusBadge({ level }: { level: number }) {
  const labels = ['کاربر ساده', 'شرکت تایید‌شده', 'تولیدکننده‌ی تایید‌شده']
  const colors = ['#6f7680', '#146c3a', '#146c3a']
  return (
    <div style={{ marginBottom: 24, fontSize: 13, fontWeight: 700, color: colors[level] }}>
      وضعیت فعلی: {labels[level]}
    </div>
  )
}

const pageStyle: React.CSSProperties = { minHeight: '100vh', background: '#faf8f4', padding: '32px 20px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl' }
const containerStyle: React.CSSProperties = { maxWidth: 560, margin: '0 auto' }
const cardStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 14, padding: '22px 20px', marginBottom: 20, background: '#fff' }
const inputStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 9, padding: '10px 14px', fontSize: 13.5, fontFamily: 'inherit' }
const fileLabelStyle: React.CSSProperties = { fontSize: 12.5, color: '#4f5560', display: 'flex', flexDirection: 'column' }
const submitBtnStyle: React.CSSProperties = { background: '#1e357b', color: '#fff', border: 'none', borderRadius: 9, padding: '13px 0', fontSize: 14, fontWeight: 800, cursor: 'pointer', marginTop: 6 }
