import { validateDriverToken } from '@/lib/driverAccess'
import DriverForm from './DriverForm'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'

export const dynamic = 'force-dynamic'

export default async function DriverAccessPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params
  const { valid, reason, link } = await validateDriverToken(token)

  if (!valid || !link) {
    return (
      <div style={pageStyle}>
        <div style={cardStyle}>
          <h1 style={{ fontSize: fontSize.lg, fontWeight: 800, color: colors.dangerText, marginBottom: spacing.sm }}>دسترسی ممکن نیست</h1>
          <p style={{ fontSize: fontSize.md, color: colors.neutralText }}>{reason}</p>
        </div>
      </div>
    )
  }

  const deal = link.deal
  let formType: 'loading' | 'unloading' | null = null
  if (deal.status === 'confirmed' || deal.status === 'payment_secured') formType = 'loading'
  else if (deal.status === 'in_transit') formType = 'unloading'

  if (!formType) {
    return (
      <div style={pageStyle}>
        <div style={cardStyle}>
          <h1 style={{ fontSize: fontSize.lg, fontWeight: 800, marginBottom: spacing.sm, color: colors.textPrimary }}>الان کاری برای ثبت نیست</h1>
          <p style={{ fontSize: fontSize.md, color: colors.neutralText }}>وضعیت فعلی این معامله («{deal.status}») نیازی به فرم بارگیری یا تخلیه نداره.</p>
        </div>
      </div>
    )
  }

  return (
    <div style={pageStyle}>
      <div style={cardStyle}>
        <h1 style={{ fontSize: fontSize.lg, fontWeight: 800, marginBottom: spacing.xs, color: colors.textPrimary }}>
          {formType === 'loading' ? 'تایید بارگیری' : 'تایید تخلیه'}
        </h1>
        <p style={{ fontSize: fontSize.base, color: colors.textMuted, marginBottom: spacing.xl }}>
          معامله #{deal.id.slice(0, 8)} — مقدار {deal.quantity}
        </p>
        <DriverForm token={token} type={formType} />
      </div>
    </div>
  )
}

const pageStyle: React.CSSProperties = {
  minHeight: '100vh', background: colors.bgPage, padding: `${spacing.xl}px ${spacing.lg}px`,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl',
}
const cardStyle: React.CSSProperties = {
  maxWidth: 460, margin: '0 auto', background: colors.bgCard, border: `1px solid ${colors.borderSubtle}`,
  borderRadius: 14, padding: `${spacing.xl}px 20px`, boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
