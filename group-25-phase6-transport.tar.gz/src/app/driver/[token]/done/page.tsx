import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'

export default function DriverDonePage() {
  return (
    <div style={{ minHeight: '100vh', background: colors.bgPage, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: spacing.lg, fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl' }}>
      <div style={{ maxWidth: 400, textAlign: 'center', background: colors.bgCard, border: `1px solid ${colors.borderSubtle}`, borderRadius: 14, padding: `${spacing.xxl}px ${spacing.xl}px` }}>
        <div style={{ fontSize: 40, marginBottom: spacing.md }}>✓</div>
        <h1 style={{ fontSize: fontSize.lg, fontWeight: 800, color: colors.successText, marginBottom: spacing.sm }}>ثبت شد، متشکریم</h1>
        <p style={{ fontSize: fontSize.base, color: colors.neutralText }}>فرم شما با موفقیت ثبت شد. می‌تونید این صفحه رو ببندید.</p>
      </div>
    </div>
  )
}
