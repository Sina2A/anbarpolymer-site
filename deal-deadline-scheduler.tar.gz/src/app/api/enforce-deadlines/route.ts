/**
 * POST /api/enforce-deadlines — automatic deadline scheduler tick.
 *
 * ⚠️  NETWORK-EXPOSED ENDPOINT — requires a shared secret token.
 *     Set DEADLINE_CRON_SECRET in .env on the server.
 *     The external cron (scripts/enforce_deadlines.py) sends:
 *       Authorization: Bearer <token>
 *
 * Runs BOTH deadline rule sets (deal-level + proforma) once and records a single
 * run summary in SystemLog (category 'deadline_scheduler', path 'auto') so the
 * monitor card in /admin-deals can show the last automatic runs. No request body
 * is needed. There is NO in-process timer — this is the poller.py-style pattern:
 * a protected endpoint driven by an external crontab entry, stable across restarts.
 */

import { NextRequest, NextResponse } from 'next/server'
import { runDeadlineEnforcement } from '@/lib/dealDeadlines'

export async function POST(request: NextRequest) {
  // ── Auth check ──
  const secret = process.env.DEADLINE_CRON_SECRET
  if (!secret) {
    // If the env var is not set, refuse to run (fail-closed)
    return NextResponse.json(
      { error: 'DEADLINE_CRON_SECRET is not configured on the server.' },
      { status: 503 },
    )
  }

  const authHeader = request.headers.get('authorization') ?? ''
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : ''

  if (token !== secret) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  // ── Run one enforcement tick (writes its own SystemLog run record) ──
  const result = await runDeadlineEnforcement('auto')

  return NextResponse.json({ ok: true, ...result })
}
