#!/usr/bin/env python3
"""
enforce_deadlines.py — Automatic deadline scheduler tick for AnbarPolymer.

POSTs to the /api/enforce-deadlines endpoint, which runs BOTH deal-level and
proforma deadline rules once and records a run summary in SystemLog. The
monitor card in /admin-deals reads those records to show the last automatic runs.

This is the poller.py-style pattern: a protected endpoint driven by an external
crontab entry, stable across service restarts (unlike an in-process setInterval).
Deadline enforcement is global DB work, so a single cron entry hitting any one
running instance is enough — do NOT schedule it against every SURFACE port.

Usage:
  # Dry-run (logs to console, no HTTP call):
  python3 enforce_deadlines.py

  # Live mode (sends to the site):
  DEADLINE_CRON_SECRET=your_token SITE_URL=https://example.com python3 enforce_deadlines.py

  # Run via cron every 15 minutes:
  */15 * * * * cd /var/www/anbarpolymer-app && DEADLINE_CRON_SECRET=xxx SITE_URL=https://example.com python3 scripts/enforce_deadlines.py >> /var/log/enforce_deadlines.log 2>&1

Environment variables:
  DEADLINE_CRON_SECRET  — shared secret (must match the server .env value)
  SITE_URL              — base URL of the site, e.g. http://localhost:3001

When DEADLINE_CRON_SECRET is not set, the script runs in dry-run mode:
it prints what it would do without making any HTTP call. This mirrors poller.py.
"""

import json
import os
import sys
import urllib.request
import urllib.error
from datetime import datetime

# ── Configuration ──────────────────────────────────────────────────────

SITE_URL = os.environ.get("SITE_URL", "http://localhost:3001").rstrip("/")
SECRET = os.environ.get("DEADLINE_CRON_SECRET", "")
ENDPOINT = f"{SITE_URL}/api/enforce-deadlines"

# ── Send to API ────────────────────────────────────────────────────────

def send_to_api():
    """POST to the enforce-deadlines endpoint with Bearer auth. No body needed."""
    req = urllib.request.Request(
        ENDPOINT,
        data=b"",
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {SECRET}",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            body = json.loads(resp.read().decode())
            print(f"[OK] {resp.status} — {json.dumps(body, ensure_ascii=False)}")
    except urllib.error.HTTPError as e:
        err_body = e.read().decode() if e.fp else ""
        print(f"[ERROR] HTTP {e.code}: {err_body}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as e:
        print(f"[ERROR] Connection failed: {e.reason}", file=sys.stderr)
        sys.exit(1)

# ── Main ───────────────────────────────────────────────────────────────

def main():
    print(f"[enforce_deadlines] {datetime.now().isoformat()} → {ENDPOINT}")

    if not SECRET:
        print("[DRY-RUN] DEADLINE_CRON_SECRET not set — skipping HTTP POST.")
        return

    send_to_api()

if __name__ == "__main__":
    main()
