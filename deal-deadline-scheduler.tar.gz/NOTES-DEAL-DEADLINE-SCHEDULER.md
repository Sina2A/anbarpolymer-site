# رفعِ کرشِ admin-deals + زمان‌بندِ خودکارِ مهلت‌ها

این بسته دو کارِ مستقل رو انجام می‌ده: (۱) رفعِ کرشِ صفحه‌ی `/admin-deals` روی یک معامله‌ی
خاص، و (۲) اضافه‌کردنِ زمان‌بندِ خودکارِ مهلت‌ها با کارتِ مانیتور + دکمه‌ی اجرای دستی.

---

## بخش ۱ — رفعِ کرشِ admin-deals (ستونِ حذف‌شده‌ی `Grade.packagingType`)

### علت
باز کردنِ یک معامله‌ی خاص در `/admin-deals` کلِ صفحه رو ۵۰۰ می‌کرد:
```
The column `Grade.packagingType` does not exist in the current database.
code: 'P2022' (ColumnNotFound)
```
سورس/اسکیمای Prisma از قبل مهاجرت شده بودن (ستون از `Grade` حذف و به `WarehouseStock`
منتقل شده)، ولی کلاینتِ Prismaِ **دیپلوی‌شده روی سرور کهنه** بود و هنوز ستونِ حذف‌شده رو
می‌شناخت. کوئریِ صفحه با `include: { grade: true }`، همه‌ی ستون‌های اسکالرِ `Grade` رو که
کلاینت می‌شناسه SELECT می‌کرد — و چون کلاینتِ کهنه `packagingType` رو جزوِ اون‌ها می‌دونست،
دیتابیس با P2022 کرش می‌کرد.

### رفع (کد — دفاعی)
در `src/app/admin-deals/page.tsx`، `grade: true` با یک `select` صریحِ چهارفیلدی جایگزین شد
(فقط همون فیلدهایی که این صفحه واقعاً رندر می‌کنه):
```ts
grade: { select: { code: true, producer: true, category: true, imageUrl: true } }
```
این هم برای `materialListing.grade` و هم `purchaseRequest.grade` اعمال شد. حالا کوئری فقط
همون چهار ستون رو می‌خواد و نسبت به ناهم‌ترازیِ کلاینت/دیتابیس مصونه.

### رفعِ ریشه‌ای (روی سرور — لازم)
رفعِ کد صفحه رو مصون می‌کنه، ولی ریشه‌ی مشکل، کلاینتِ کهنه‌ی دیپلوی‌شده‌ست. روی سرور:
```bash
cd /var/www/anbarpolymer-app && npx prisma generate && npm run build && pm2 restart all
```
این کلاینتِ Prisma رو با اسکیمای فعلی هم‌تراز می‌کنه و همین کلاسِ خطا رو برای همه‌ی
مسیرهای دیگه‌ی سایت هم می‌بنده.

---

## بخش ۲ — زمان‌بندِ خودکارِ مهلت‌ها

### زمینه
قوانین مهلت (`enforceDealDeadlines`, `enforceProformaDeadlines`) فقط وقتی اجرا می‌شدن که
یکی از چند صفحه‌ی خاص لود بشه؛ هیچ اجراکننده‌ی مستقلی نبود. اگه هیچ‌کس اون صفحه‌ها رو باز
نمی‌کرد، هیچ مهلتی هیچ‌وقت اجرا نمی‌شد.

### مکانیزم (Endpointِ محافظت‌شده + Cronِ بیرونی — عینِ poller.py)
درون‌فرایندی (`setInterval`) نیست تا با هر restart از نو شروع نشه و با چندنمونه‌ی pm2 دوبار
اجرا نشه. به‌جاش:

- **`src/app/api/enforce-deadlines/route.ts`** — یک `POST` محافظت‌شده با `Bearer` توکن.
  اگه `DEADLINE_CRON_SECRET` ست نباشه → `503` (fail-closed)؛ توکنِ نامطابق → `401`.
  یک‌بار `runDeadlineEnforcement('auto')` رو صدا می‌زنه.
- **`scripts/enforce_deadlines.py`** — اسکریپتِ cronِ بیرونی (عینِ poller.py)؛ بدونِ secret
  حالتِ dry-run.

چون enforcement کارِ سراسریِ دیتابیسه، **یک** cron روی **یک** نمونه کافیه — لازم نیست
برای هر SURFACE/پورت جدا تنظیم بشه.

### ذخیره‌ی «۳ اجرای آخر» (بدونِ جدولِ جدید)
هر اجرا یک رکورد در جدولِ موجودِ `SystemLog` می‌نویسه (بدونِ مهاجرت):
- `category = 'deadline_scheduler'`
- `path = 'auto'` (cron) یا `'manual'` (دکمه‌ی ادمین) — تا لیستِ نمایشی فقط خودکارها رو نشون بده
- `message` = خلاصه‌ی فارسیِ نتیجه (مثلاً «۳ معامله باطل شد»)
- `metaJson` = شمارشِ تفکیکیِ هر نوع اقدام

`getRecentDeadlineRuns(3)` سه اجرای خودکارِ آخر رو برای کارتِ مانیتور می‌خونه.

### UI (همون کارتِ «⏱ زمان‌بندی و مهلت‌های معامله»)
یک `<details open>`ِ جدید زیرِ «طول مهلت‌ها»، دقیقاً هم‌شکلِ الگوی موجود (`border-bottom: dashed`،
عنوانِ `font-weight:700` + توضیحِ `#9199a3` با `font-size:10.5px`):
- **بخشِ خودکار (فقط نمایشی، بدونِ فیلدِ ورودی):** «۳ اجرای خودکار آخر» — هرکدوم زمانِ دقیقِ
  تهران (`tehranJalaliDisplay` + `tehranClockDisplay`) + خلاصه‌ی نتیجه.
- **بخشِ دستی:** دکمه‌ی «اجرای همین الان» با استایلِ `btnPrimaryStyle` (همون «ذخیره‌ی تغییرات»)،
  با تاییدِ `ConfirmSubmitButton`. اکشنِ `runDeadlineEnforcementNowAction` فقط مدیر (چکِ
  سمتِ سرور)، با `trigger='manual'` تا توی لیستِ خودکارها قاطی نشه.

### تنظیمِ روی سرور (لازم)
۱. یک secret قوی توی `.env` سرور بذار:
```
DEADLINE_CRON_SECRET=<یک‌توکنِ‌تصادفیِ‌قوی>
```
۲. بعد از افزودنِ secret، اپ رو ری‌استارت کن تا خونده بشه: `pm2 restart all`.
۳. یک خط به crontab اضافه کن (هر ۱۵ دقیقه؛ `SITE_URL` رو به پورتِ نمونه‌ی adminِ درحال‌اجرا
اشاره بده، مثلاً `3001`):
```
*/15 * * * * cd /var/www/anbarpolymer-app && DEADLINE_CRON_SECRET=xxx SITE_URL=http://localhost:3001 python3 scripts/enforce_deadlines.py >> /var/log/enforce_deadlines.log 2>&1
```
بعد از اولین اجرای cron، «۳ اجرای آخر» توی کارتِ مانیتور ظاهر می‌شه.

---

## فایل‌های این بسته
- `src/app/admin-deals/page.tsx`            ← ویرایش (select صریحِ grade + کارتِ مانیتور/اجرای دستی)
- `src/app/admin-deals/actions.ts`          ← ویرایش (اکشنِ `runDeadlineEnforcementNowAction`)
- `src/lib/dealDeadlines.ts`                ← ویرایش (`runDeadlineEnforcement` + `getRecentDeadlineRuns`)
- `src/app/api/enforce-deadlines/route.ts`  ← جدید (Endpointِ محافظت‌شده‌ی cron)
- `scripts/enforce_deadlines.py`            ← جدید (اسکریپتِ cronِ بیرونی)

## راستی‌آزمایی
- `npx tsc --noEmit` → بدونِ خطا (EXIT=0).
- `npx next build`  → موفق (EXIT=0)؛ مسیرِ `ƒ /api/enforce-deadlines` ثبت شد.
- تستِ بصری روی سرورِ واقعی طبقِ توافق.
