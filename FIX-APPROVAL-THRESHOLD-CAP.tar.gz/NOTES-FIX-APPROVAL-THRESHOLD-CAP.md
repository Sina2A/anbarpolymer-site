# NOTES-FIX-APPROVAL-THRESHOLD-CAP — اصلاح سقف آستانه‌ی قوانین تایید + بازکردن تب approval

تاریخ: ۲۰۲۶-۱۰-۰۷

## ۱) چه چیزی عوض شد و چرا

باگ production: در `createApprovalRuleAction` و `updateApprovalRuleAction` (هر دو در `src/app/admin-pricing/actions.ts`) آستانه با `decimalOrNull` خوانده می‌شد. آن wrapper روی `parseDecimalInput` سوار است که سقف پیش‌فرض `1e9` دارد؛ پس آستانه‌ی تومانیِ ۵٬۰۰۰٬۰۰۰٬۰۰۰ (۵ میلیارد = بالاتر از ۱ میلیارد) با خطای `MoneyInputError: «حد آستانه» خارج از محدوده‌ی مجازه (حداکثر 1,000,000,000)` رد می‌شد.

اصلاح، فقط در همین دو اکشن:

| نوع شرط | parser | سقف | اعشار | دلیل |
|---|---|---|---|---|
| `amount` (مبلغ) | `parseTomanInput` | `MAX_TOMAN` = `1e13` (۱۰٬۰۰۰ میلیارد تومان) | ممنوع (عدد صحیح) | آستانه‌ی مبلغی، «جمع کل به تومان» است؛ سقف واحد پول سایت همان `MAX_TOMAN` است و نباید از موتور پول جدا بیفتد. عدد صحیح هم چون واحد پول سایت صحیح است. |
| `deviation_percent` (درصد انحراف) | `parseDecimalInput` | `1000` | مجاز (حداکثر ۴ رقم، پیش‌فرض) | انحراف مثبتِ قیمت می‌تواند از ۱۰۰٪ بگذرد؛ سقف ۱۰۰٪ موارد معتبر را بی‌دلیل رد می‌کرد. ۱۰۰۰٪ سقف عملیِ منطقی است و از `1e9` بی‌معنا فاصله دارد. |
| هر مقدار دیگر | — | — | — | با پیام «نوع شرط قانون تایید نامعتبر است.» رد می‌شود؛ دیگر مقدارِ نامعتبر بی‌صدا با parser اشتباه ذخیره نمی‌شود. |

منطق در یک تابع خالص مشترک گرد آمد: `src/lib/approvalThreshold.ts` → `parseApprovalThreshold(raw, conditionType)`. هر دو اکشن همان را صدا می‌زنند، پس مسیر واقعی هر دو اکشن با یک تست واحد سنجیده می‌شود.

در `updateApprovalRuleAction` مقدار `conditionType` پیش از خواندن آستانه استخراج و همان متغیر هم به `data`ی Prisma داده می‌شود، تا نوع شرطِ استفاده‌شده برای اعتبارسنجی دقیقاً همانی باشد که ذخیره می‌شود.

## ۲) ممیزی callerهای parserها (فقط گزارش — فقط دو آستانه اصلاح شد)

خانواده‌ی parserها در `src/lib/money.ts`: `parseMoneyInput`/`parseTomanInput` (سقف `MAX_TOMAN`، صحیح)، `parseTonInput` (`1e6` تن)، `parseKgInput` (`1e9` کیلو)، `parseIntegerInput` (`1e9`)، `parseDecimalInput` (`1e9`).

همه‌ی مصرف‌کننده‌ها در `src`:

| محل | فیلد | parser | آیا پول تومانیِ مستعد عبور از `1e9` است؟ |
|---|---|---|---|
| `admin-deals/actions.ts:1195,1263,1325` | قیمت واحد / جمع کل دستی / مبلغ تعدیل | `parseMoneyInput` | خیر — سقف `MAX_TOMAN` |
| `admin-deals/actions.ts:844,854` | وزن / مبلغ کمکی | `parseTonInput` / `parseMoneyInput` | خیر |
| `admin-orders/actions.ts:129,136,360` | قیمت نهایی ردیف / مالیات ردیف | `parseTomanInput` | خیر |
| `admin-warehouses/actions.ts:151,153` | مقدار موجودی / قیمت | `parseTonInput` / `parseTomanInput` | خیر |
| `api/material-listings/route.ts:65,71,72` | مقدار / قیمت آگهی / وزن باسکول | `parseTonInput` / `parseTomanInput` / `parseKgInput` | خیر (قیمت واحد تومان/کیلو، سقف `MAX_TOMAN`؛ وزن کیلو ≤ `1e9` کافی است) |
| `market/actions.ts:133,224` | قیمت پیشنهادی | `parseTomanInput` | خیر |
| `price-alerts/actions.ts:24` | سقف قیمت | `requireMoneyInput` | خیر |
| `purchase-requests/actions.ts:25,26,30` | مقدار / سقف قیمت / مدت اعتبار | `parseTonInput` / `parseTomanInput` / `parseIntegerInput` با `max:365` | خیر |
| `custom-request/actions.ts:29` | مقدار درخواستی | `parseTonInput` | خیر |
| `verification/actions.ts:83,91` | مصرف ماهانه / ظرفیت سالانه | `parseTonInput` (دومی `max:1e8`) | خیر — وزن است، نه پول |
| `admin-pricing/actions.ts` — `decimalOrNull` | مقدار تنظیم، اولویت، مدت پرداخت (روز)، ضریب درصد، سطوح حاشیه درصد، قیمت مرجع دلار، درصد تنظیم کلی | `parseDecimalInput` | خیر — درصد/روز/دلار است، نه مبلغ تومانی |
| `admin-pricing/actions.ts` — `integerOrNull` | اولویت | `parseIntegerInput` | خیر |
| `admin-pricing/actions.ts` — `tonnageOrNull` | حداقل تناژ | `parseTonInput` | خیر |
| `admin-pricing/actions.ts:434,456` | **آستانه‌ی قانون تایید** | **`decimalOrNull` → `1e9`** | **بله — فقط همین دو مورد اصلاح شد** |

نتیجه: در کل `src` تنها همین دو جایی که آستانه‌ی مبلغیِ قانون تایید خوانده می‌شد درگیر سقف پیش‌فرض `1e9` بودند. هیچ اصلاح دیگری انجام نشد (هیچ‌کدام از موارد بالا سقف خود را عوض نکردند و هیچ فایل دیگری از parserها دست نخورد).

## ۳) قفل «در حال توسعه» فقط از تب approval برداشته شد

منشأ قفل: `src/app/admin-pricing/page.tsx` خط ۵۰ — `<LockedTab><Tab6Approval /></LockedTab>`. کامپوننت `LockedTab` (حدود خط ۶۵۰ همان فایل) محتوای واقعی را با `filter: blur(8px)` و `pointerEvents: none` می‌پوشاند و overlay «این بخش در حال توسعه است» می‌گذارد.

تغییر: فقط همان یک خط به `{activeTab === 'approval' && <Tab6Approval />}` تبدیل شد. تب‌های `formula`، `waterfall`، `payment`، `volume` و `margins` با همان `<LockedTab>` و همان ظاهر باقی ماندند و کدشان دست نخورد. خود `LockedTab` و استایل‌هایش هم تغییر نکردند. حالا در تب «۶. قوانین تایید مدیر فروش» لیست قانون‌ها، دکمه‌ی «+ افزودن قانون» و لینک «ویرایش» هر ردیف قابل استفاده‌اند.

تب attendance در تیتر: تغییر navigation tab انجام نشد؛ `TabLink` تب ۶ از قبل وجود داشت و فقط محتوایش باز شد.

## ۴) فایل‌های این بسته

| فایل | وضعیت |
|---|---|
| `src/lib/approvalThreshold.ts` | جدید |
| `tests/unit/approvalThreshold.test.ts` | جدید |
| `src/app/admin-pricing/actions.ts` | تغییرکرده (import یکی، دو اکشن) |
| `src/app/admin-pricing/page.tsx` | تغییرکرده (فقط خط ۵۰) |

هیچ فایل دیگری در بسته نیست. `src/lib/money.ts`، `prisma/schema.prisma`، `priceEngine.ts` و فرم‌های `approval/new` و `approval/[id]` **تغییر نکرده‌اند** و لازم نیست در سرور جایگزین شوند.

## ۵) نصب روی سرور

فقط تکرار همان یک دستور در ریشه‌ی پروژه:

```bash
tar -xzf FIX-APPROVAL-THRESHOLD-CAP.tar.gz
```

- مسیرها در بسته نسبی‌اند (`src/...`، `tests/...`) و از ریشه‌ی پروژه باز می‌شوند.
- **`prisma generate` لازم نیست** — هیچ تغییری در `schema.prisma` یا مایگریشن‌ها نیست و هیچ ستون/جدول تازه‌ای اضافه نشده.
- **هیچ دستور دیتابیسی لازم نیست** — نه `migrate deploy`، نه `db push`.

سپس:

```bash
npx tsc --noEmit
```

```bash
npm run build
```

```bash
pm2 restart <نام‌پروسه‌ی‌اپ>
```

## ۶) نتیجه‌ی واقعی بررسی‌ها (روی کپی تمیز، نه checkout اصلی)

کپی تمیز: `D:\tmp\fixtc\verify\anbarpolymer-app` — نسخه‌ی کامل پروژه بدون `.next`، با `node_modules` موجود. هیچ دستور دیتابیسی و هیچ تست e2e (`tests/rfq-flow.spec.ts`) اجرا نشد.

| بررسی | دستور | نتیجه |
|---|---|---|
| TypeScript | `npx tsc --noEmit` | خروجی خالی، کد خروج `0` |
| تست واحد (همه) | `npx tsx --test tests/unit/*.test.ts` | ۱۴۰ تست، ۱۴۰ pass، ۰ fail |
| ↳ `approvalThreshold.test.ts` | — | ۲ تست، ۲ pass — شامل `amount = 5_000_000_000` پذیرفته و `amount = 10_000_000_000_001` رد، `deviation_percent = 1000.01` رد، نوع شرط ناشناخته رد |
| ↳ `money.test.ts` | — | ۸۵ pass (رگرسیون موتور پول سالم) |
| ↳ `financialHash.test.ts` | — | ۳۴ pass |
| ↳ `dealRoles.test.ts` | — | ۸ pass |
| ↳ `reservationQueue.pure.test.ts` | — | ۱۱ pass |
| build تولیدی | `npm run build` | موفق، کد خروج `0`؛ همه‌ی مسیرها کامپایل شدند (`/admin-pricing` هم بین خروجی‌ها) |

## ۷) نکته‌ی رفتار ورودی فرم

input آستانه در `approval/new` و `approval/[id]` همان `type="number" step="0.01"` باقی ماند و دست نخورد (کاربر خواسته بود فقط دو اکشن و یک خط از صفحه عوض شود). برای `conditionType=amount` سرور فقط عدد صحیح می‌پذیرد؛ اگر کاربر مقدار اعشاری وارد کند، پیام فارسی «حد آستانه باید عدد صحیح باشه (بدون اعشار).» را می‌بیند. برای `deviation_percent` همان input اعشار را تا ۴ رقم می‌پذیرد.

## ۸) کارهای انجام‌نشده (طبق درخواست)

- هیچ `commit` یا `push` انجام نشد.
- هیچ بسته‌ی کامل جدیدی ساخته نشد؛ بسته‌ی `FINAL-DEAL-LIFECYCLE-FINANCE.tar.gz` دست نخورد.
- هیچ دستوری روی دیتابیس اجرا نشد.