import { MAX_TOMAN, parseDecimalInput, parseTomanInput, requireParsed } from './money'

/** Parse the approval threshold according to the condition used by the rule. */
export function parseApprovalThreshold(raw: unknown, conditionType: string): number {
  if (conditionType === 'amount') {
    return requireParsed(parseTomanInput(raw, { label: 'حد آستانه', allowZero: true, max: MAX_TOMAN }))
  }
  if (conditionType === 'deviation_percent') {
    // A positive price deviation can exceed 100%; cap the configurable trigger at 1000%.
    return requireParsed(parseDecimalInput(raw, { label: 'حد آستانه', allowZero: true, max: 1000 }))
  }
  throw new Error('نوع شرط قانون تایید نامعتبر است.')
}
