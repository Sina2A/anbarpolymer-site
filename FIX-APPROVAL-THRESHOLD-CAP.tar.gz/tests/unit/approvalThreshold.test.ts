import { test } from 'node:test'
import assert from 'node:assert/strict'
import { parseApprovalThreshold } from '../../src/lib/approvalThreshold'
import { MoneyInputError } from '../../src/lib/money'

test('آستانه مبلغی دو اکشن: پنج میلیارد پذیرفته و بالاتر از سقف تومان رد می‌شود', () => {
  const amount = 5_000_000_000
  assert.equal(parseApprovalThreshold(String(amount), 'amount'), amount)
  assert.throws(() => parseApprovalThreshold('10000000000001', 'amount'), MoneyInputError)
  assert.throws(() => parseApprovalThreshold('5000000000.5', 'amount'), MoneyInputError)
})

test('آستانه درصد انحراف اعشاری تا هزار درصد مجاز است و نوع شرط ناشناخته رد می‌شود', () => {
  assert.equal(parseApprovalThreshold('100.25', 'deviation_percent'), 100.25)
  assert.equal(parseApprovalThreshold('1000', 'deviation_percent'), 1000)
  assert.throws(() => parseApprovalThreshold('1000.01', 'deviation_percent'), MoneyInputError)
  assert.throws(() => parseApprovalThreshold('1', 'invalid'), /نوع شرط/)
})
