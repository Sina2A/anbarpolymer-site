require('dotenv').config();

const express = require('express');
const session = require('express-session');
const multer = require('multer');
const AdmZip = require('adm-zip');
const fs = require('fs-extra');
const path = require('path');
const { exec } = require('child_process');
const http = require('http');
const https = require('https');

const PORT = process.env.PORT || 4000;
const SITE_DIR = process.env.SITE_DIR || '/var/www/html';
const VERSIONS_DIR = process.env.VERSIONS_DIR || '/var/www/deploy-versions';
const PASSWORD = process.env.DEPLOY_PASSWORD || 'change-this-password';
const SESSION_SECRET = process.env.SESSION_SECRET || 'change-this-to-a-random-long-string';
const PUBLIC_URL = process.env.PUBLIC_URL || 'http://localhost';

const UPLOAD_TMP = path.join(__dirname, 'tmp-uploads');
fs.ensureDirSync(UPLOAD_TMP);
fs.ensureDirSync(VERSIONS_DIR);

const upload = multer({ dest: UPLOAD_TMP });
const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(
  session({
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 1000 * 60 * 60 * 8 }, // 8 ساعت
  })
);

function requireAuth(req, res, next) {
  if (req.session && req.session.loggedIn) return next();
  return res.redirect('/login');
}

function layout(title, body) {
  return `<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${title} — پنل دیپلوی</title>
<style>
  *{box-sizing:border-box;}
  body{background:#faf8f4;color:#1b1e24;font-family:Tahoma,sans-serif;line-height:1.8;margin:0;padding:40px 20px;}
  .wrap{max-width:720px;margin:0 auto;}
  h1{font-size:22px;margin-bottom:6px;}
  .sub{color:#6f7680;font-size:13px;margin-bottom:28px;}
  .card{background:#fff;border:1px solid #d8dde3;border-radius:12px;padding:24px;margin-bottom:18px;box-shadow:0 1px 4px rgba(0,0,0,.04);}
  .card h3{font-size:15px;margin-bottom:12px;}
  input[type=password], input[type=file]{width:100%;padding:10px 12px;border:1px solid #c8d0da;border-radius:8px;font-size:14px;margin-bottom:14px;}
  button{background:#f6621b;color:#fff;border:none;border-radius:8px;padding:11px 20px;font-size:14px;font-weight:700;cursor:pointer;}
  button:hover{background:#e65716;}
  button.secondary{background:#1e357b;}
  button.secondary:hover{background:#17306a;}
  .msg{padding:12px 14px;border-radius:8px;font-size:13px;margin-bottom:18px;}
  .msg.ok{background:#dcfce7;color:#146c3a;}
  .msg.err{background:#fee2e2;color:#a8241a;}
  table{width:100%;border-collapse:collapse;}
  th,td{text-align:right;padding:10px 8px;border-bottom:1px solid #eceff3;font-size:13px;}
  th{color:#6f7680;font-weight:600;}
  .tag{display:inline-block;font-size:10.5px;font-family:monospace;background:#eef4fd;color:#1e357b;border-radius:5px;padding:2px 8px;}
  form.inline{display:inline;}
  a.logout{float:left;color:#6f7680;font-size:12.5px;}
</style>
</head>
<body>
<div class="wrap">
${body}
</div>
</body>
</html>`;
}

// ---------- Login ----------
app.get('/login', (req, res) => {
  const err = req.query.err ? '<div class="msg err">رمز عبور اشتباه است.</div>' : '';
  res.send(
    layout(
      'ورود',
      `
    <h1>پنل دیپلوی سایت</h1>
    <div class="sub">فقط با رمز عبور درست وارد شو — این پنل قدرت جایگزینی کامل فایل‌های سایته.</div>
    ${err}
    <div class="card">
      <form method="POST" action="/login">
        <label>رمز عبور</label>
        <input type="password" name="password" autofocus required>
        <button type="submit">ورود</button>
      </form>
    </div>
  `
    )
  );
});

app.post('/login', (req, res) => {
  if (req.body.password === PASSWORD) {
    req.session.loggedIn = true;
    return res.redirect('/');
  }
  res.redirect('/login?err=1');
});

app.get('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/login'));
});

// ---------- Dashboard ----------
app.get('/', requireAuth, async (req, res) => {
  const versions = await listVersions();
  const msg = req.query.msg ? `<div class="msg ok">${decodeURIComponent(req.query.msg)}</div>` : '';
  const err = req.query.err ? `<div class="msg err">${decodeURIComponent(req.query.err)}</div>` : '';

  const rows = versions.length
    ? versions
        .map(
          (v) => `
      <tr>
        <td>${v.label}</td>
        <td><span class="tag">${v.files} فایل</span></td>
        <td>
          <form class="inline" method="POST" action="/rollback/${v.name}" onsubmit="return confirm('مطمئنی می‌خوای سایت رو به این نسخه برگردونی؟');">
            <button type="submit" class="secondary">بازگشت به این نسخه</button>
          </form>
        </td>
      </tr>`
        )
        .join('')
    : `<tr><td colspan="3" style="color:#9a8f7c;">هنوز هیچ نسخه‌ای ذخیره نشده — اولین آپلود، اولین نسخه‌ی بکاپ رو خودش می‌سازه.</td></tr>`;

  res.send(
    layout(
      'پیشخوان',
      `
    <a class="logout" href="/logout">خروج</a>
    <h1>پنل دیپلوی سایت</h1>
    <div class="sub">پوشه‌ی زنده: <span class="tag">${SITE_DIR}</span></div>
    ${msg}${err}

    <div class="card">
      <h3>پاک‌سازی کش و بارگذاری مجدد</h3>
      <div class="sub" style="margin-bottom:14px;">Nginx رو reload می‌کنه، هر کشِ سمت سرور (اگه فعال باشه) رو پاک می‌کنه، و صفحه‌ی اصلی رو یه‌بار پیش‌بارگذاری می‌کنه. توجه: کش خودِ مرورگر کاربر رو نمی‌تونه از راه دور پاک کنه — اون سمت کاربره (رفرش سخت / Ctrl+F5).</div>
      <form method="POST" action="/clear-cache">
        <button type="submit" class="secondary">پاک‌سازی کش سرور و ریلود</button>
      </form>
    </div>

    <div class="card">
      <h3>آپلود نسخه‌ی جدید</h3>
      <div class="sub" style="margin-bottom:14px;">فایل zip سایت رو انتخاب کن. قبل از جایگزینی، از وضعیت فعلی خودکار یه بکاپ ساخته می‌شه.</div>
      <form method="POST" action="/deploy" enctype="multipart/form-data">
        <input type="file" name="siteZip" accept=".zip" required>
        <button type="submit">آپلود و اعمال روی سایت زنده</button>
      </form>
    </div>

    <div class="card">
      <h3>نسخه‌های قبلی</h3>
      <table>
        <thead><tr><th>تاریخ ثبت</th><th></th><th>عملیات</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
    </div>
  `
    )
  );
});

// ---------- Deploy (upload zip → backup current → replace live) ----------
app.post('/deploy', requireAuth, upload.single('siteZip'), async (req, res) => {
  try {
    if (!req.file) return res.redirect('/?err=' + encodeURIComponent('هیچ فایلی انتخاب نشد.'));

    // ۱. بکاپ گرفتن از وضعیت فعلی سایت
    const backupName = timestampName();
    const backupPath = path.join(VERSIONS_DIR, backupName);
    await fs.ensureDir(SITE_DIR);
    await fs.copy(SITE_DIR, backupPath);

    // ۲. باز کردن زیپ جدید توی یه پوشه‌ی موقت
    const extractTmp = path.join(UPLOAD_TMP, 'extract-' + Date.now());
    await fs.ensureDir(extractTmp);
    const zip = new AdmZip(req.file.path);
    zip.extractAllTo(extractTmp, true);

    // ۳. خالی کردن پوشه‌ی زنده و جایگزینی با محتوای جدید
    await fs.emptyDir(SITE_DIR);
    await fs.copy(extractTmp, SITE_DIR);

    // ۴. پاکسازی فایل‌های موقت
    await fs.remove(req.file.path);
    await fs.remove(extractTmp);

    res.redirect('/?msg=' + encodeURIComponent('نسخه‌ی جدید با موفقیت روی سایت اعمال شد. نسخه‌ی قبلی به‌عنوان بکاپ ذخیره شد.'));
  } catch (e) {
    console.error(e);
    res.redirect('/?err=' + encodeURIComponent('خطا در اعمال نسخه: ' + e.message));
  }
});

// ---------- Clear cache & reload ----------
app.post('/clear-cache', requireAuth, async (req, res) => {
  const steps = [];
  try {
    // ۱. اگه پوشه‌ی کش Nginx وجود داشت، خالیش کن
    const nginxCacheDir = '/var/cache/nginx';
    if (await fs.pathExists(nginxCacheDir)) {
      await fs.emptyDir(nginxCacheDir);
      steps.push('پوشه‌ی کش Nginx خالی شد.');
    } else {
      steps.push('پوشه‌ی کش Nginx پیدا نشد (احتمالاً از اول فعال نبوده — طبیعیه).');
    }

    // ۲. تاریخ آخرین تغییر فایل‌های سایت رو بروز کن (کمک به کش‌شکنی مرورگر بر پایه‌ی Last-Modified)
    await touchAllFiles(SITE_DIR);
    steps.push('تاریخ فایل‌های سایت بروزرسانی شد.');

    // ۳. Nginx رو reload کن
    await new Promise((resolve, reject) => {
      exec('nginx -s reload', (err, stdout, stderr) => {
        if (err) return reject(new Error(stderr || err.message));
        resolve();
      });
    });
    steps.push('Nginx با موفقیت reload شد.');

    // ۴. صفحه‌ی اصلی رو یه‌بار پیش‌بارگذاری کن
    try {
      await preloadUrl(PUBLIC_URL);
      steps.push('صفحه‌ی اصلی پیش‌بارگذاری شد.');
    } catch (e) {
      steps.push('پیش‌بارگذاری موفق نشد (سایت رو دستی چک کن): ' + e.message);
    }

    res.redirect('/?msg=' + encodeURIComponent(steps.join(' ')));
  } catch (e) {
    console.error(e);
    res.redirect('/?err=' + encodeURIComponent('خطا در پاک‌سازی کش: ' + e.message + (steps.length ? ' — تا اینجا انجام شد: ' + steps.join(' ') : '')));
  }
});


app.post('/rollback/:version', requireAuth, async (req, res) => {
  try {
    const versionPath = path.join(VERSIONS_DIR, req.params.version);
    const exists = await fs.pathExists(versionPath);
    if (!exists) return res.redirect('/?err=' + encodeURIComponent('این نسخه پیدا نشد.'));

    // قبل از rollback هم یه بکاپ از وضعیت فعلی می‌گیریم — که خودِ rollback هم قابل‌برگشت باشه
    const safetyBackup = timestampName() + '-before-rollback';
    await fs.copy(SITE_DIR, path.join(VERSIONS_DIR, safetyBackup));

    await fs.emptyDir(SITE_DIR);
    await fs.copy(versionPath, SITE_DIR);

    res.redirect('/?msg=' + encodeURIComponent('سایت به نسخه‌ی انتخاب‌شده برگردونده شد.'));
  } catch (e) {
    console.error(e);
    res.redirect('/?err=' + encodeURIComponent('خطا در بازگشت: ' + e.message));
  }
});

// ---------- Helpers ----------
function timestampName() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}_${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}`;
}

async function listVersions() {
  const entries = await fs.readdir(VERSIONS_DIR).catch(() => []);
  const dirs = [];
  for (const name of entries) {
    const full = path.join(VERSIONS_DIR, name);
    const stat = await fs.stat(full).catch(() => null);
    if (stat && stat.isDirectory()) {
      const files = await fs.readdir(full).catch(() => []);
      dirs.push({ name, label: name.replace('_', ' — '), files: files.length });
    }
  }
  // جدیدترین‌ها اول
  return dirs.sort((a, b) => (a.name < b.name ? 1 : -1));
}

async function touchAllFiles(dir) {
  const now = new Date();
  const entries = await fs.readdir(dir, { withFileTypes: true }).catch(() => []);
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      await touchAllFiles(full);
    } else {
      await fs.utimes(full, now, now).catch(() => {});
    }
  }
}

function preloadUrl(url) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith('https') ? https : http;
    const req = client.get(url, { timeout: 8000 }, (resp) => {
      resp.on('data', () => {});
      resp.on('end', resolve);
    });
    req.on('error', reject);
    req.on('timeout', () => {
      req.destroy();
      reject(new Error('timeout'));
    });
  });
}

app.listen(PORT, () => {
  console.log(`Deploy panel running on http://0.0.0.0:${PORT}`);
});
