# گزارش تحویل — گروه ۱۸: موتور قیمت‌گذاری/بنچمارک (PC/PB)

**تاریخ:** ۱۴۰۵/۰۶/۱۰ (2026-08-31)  
**وضعیت:** ✅ کامل — آماده‌ی آپلود و migrate  
**آرشیو:** `group-18-price-engine-v3.tar.gz` (۱۰ فایل، شامل سند پیوندها)

---

## 📦 فایل‌های تحویلی

### ۱. Schema & Core Logic (۵ فایل)

#### `CONNECTIONS-GROUP-18.md` (4.8 KB) — **جدید** ⭐
**نوع:** سند راهنمای اتصال  
**محتوا:** شرح کامل ۳ نقطه‌ی اتصال موتور تایید به Order/Deal/BenchmarkPublish:
1. **Order registration** (`admin-orders/actions.ts` → `setOrderPricing`) — کد پیشنهادی، فیلدهای schema، اکشن‌های جدید
2. **BenchmarkPublish** — قبلاً پیاده‌شده، مستندسازی منطق موجود
3. **Deal confirmation** (`lib/dealDeadlines.ts` → `startBuyerPaymentDeadline`) — کد پیشنهادی، فیلدهای schema، اکشن‌های جدید

**⚠️ این سند خوانده شود قبل از اتصال موتور تایید به فلوهای Order و Deal.**

#### `prisma-schema-delta-group-18.prisma` (6.2 KB)
**نوع:** Delta — فقط تغییرات، نه schema کامل  
**مقصد نهایی:** Merge دستی به `anbarpolymer-app/prisma/schema.prisma`

**تغییرات:**
- **۸ مدل جدید:**
  1. `PriceFormulaRule` — فرمول محاسبه قیمت پایه (کالا + ضرایب حمل/بیمه/مالیات)
  2. `WaterfallRule` — آبشاری قیمت (discount tiers: نقدی، ۳۰ روزه، …)
  3. `PaymentTermRule` — شرایط پرداخت (مثلاً «۳۰% پیش‌پرداخت، ۷۰% اعتباری»)
  4. `VolumeTierRule` — تخفیف حجمی (≥100 تن → -3%)
  5. `MarginGuidance` — راهنمای حاشیه سود پیشنهادی هر گرید
  6. `ApprovalRule` — قوانین تصویب (Order/Deal/BenchmarkPublish، conditionType amount|deviation_percent، thresholdValue، approvalLevel auto|supervisor|manager|admin)
  7. `GlobalBenchmarkPrice` (Benchino) — قیمت بنچمارک منتشرشده (هر گرید یک رکورد فعال)
  8. `BenchmarkPublishRecord` — تاریخچه انتشار بنچمارک (status pending|approved|rejected، deviationPercent، approvalLevel، approvedById)

- **تغییر فیلد موجود:**
  - `Deal.agreedPrice`: `String?` → `Float?` (جهت فیکس نمایش صحیح — تمام سایت‌های نمایش این فیلد اصلاح شدند)

- **توسعه‌ی `WarehouseStock`:**
  - فیلد جدید `dealLightStatus String?` (light/medium/heavy) — نمایش چراغ رنگی در tab 7 (Benchino Live)

- **Relations جدید:**
  - `Grade`: +`marginGuidances` و +`globalBenchmarkPrices`
  - `User`: +`publishedBenchmarks` و +`approvedBenchmarks`

**دستورالعمل Merge:**
1. باز کردن `schema.prisma` اصلی
2. کپی ۸ مدل جدید به انتهای فایل
3. در مدل `Deal`: `agreedPrice String?` → `agreedPrice Float?`
4. در مدل `WarehouseStock`: اضافه کردن `dealLightStatus String?`
5. در مدل `Grade`: اضافه کردن دو relation
6. در مدل `User`: اضافه کردن دو relation
7. ذخیره و migration:
   ```bash
   cd anbarpolymer-app
   npx prisma migrate dev --name add-price-engine-group-18
   npx prisma generate
   ```

**⚠️ Migration data:** اگر Deal های موجود `agreedPrice` String دارند:
```sql
UPDATE "deals"
SET "agreedPrice" = CAST("agreedPrice" AS FLOAT)
WHERE "agreedPrice" IS NOT NULL AND "agreedPrice" ~ '^[0-9.]+$';
```

#### `src-lib-priceEngine.ts` (3.0 KB)
**مقصد نهایی:** `anbarpolymer-app/src/lib/priceEngine.ts`  
**توضیح:**  
موتور ژنریک تصویب — تابع `evaluateApprovalRequirement`:
```typescript
async function evaluateApprovalRequirement(
  entityType: 'Order' | 'Deal' | 'BenchmarkPublish',
  amount?: number,
  deviationPercent?: number
): Promise<string | null>
```
- خواندن همه‌ی `ApprovalRule` های فعال (isActive=true) برای entityType مربوطه
- فیلتر بر اساس `conditionType` (amount یا deviation_percent) + مقایسه با `thresholdValue`
- مرتب‌سازی نزولی → برگرداندن بالاترین سطح
- سلسله‌مراتب: `['auto','supervisor','manager','admin']` — 'auto' → return null
- استفاده در:
  - `publishBenchmarkAction` (بنچمارک انتشار)
  - `rfq/actions.ts` (ثبت Order — نیاز به اتصال دستی توسط شما)
  - `dealDeadlines.ts` startBuyerPaymentDeadline (Deal تایید — نیاز به اتصال دستی)

**⚠️ این فایل از قبل وجود دارد** — محتوا همان بود، فقط به‌عنوان یکی از ۹ فایل پکیج شده. اگر در repo نباشد، این نسخه را کپی کنید.

#### `src-lib-sections.ts` (3.3 KB)
**مقصد نهایی:** `anbarpolymer-app/src/lib/sections.ts`  
**توضیح:**  
افزوده شده:
```typescript
{ key: 'pricing', label: 'بنچمارک قیمت', href: '/admin-pricing', isReal: true }
```
ردیف ۱۸ از ۳۳ بخش — `isReal: true` یعنی صفحه واقعاً ساخته شده و در `AdminNav` به‌صورت لینک نمایش داده می‌شود.

**⚠️ کامنت مهم در فایل:**  
بخش `logistics` (ردیف ۲۳) = هماهنگی داخلی حمل‌ونقل خود انبارپلیمر (`/admin-logistics`)؛ **هیچ ربطی به** پنل مدیر شرکت حمل‌ونقل (`/transport-panel`) ندارد. دو چیز کاملاً جدا.

#### `src-lib-errorCodes.ts` (7.5 KB)
**مقصد نهایی:** `anbarpolymer-app/src/lib/errorCodes.ts`  
**توضیح:**  
افزوده شده:
```typescript
'A-SECTION-PRICING': {
  message: 'شما به بخش «بنچمارک قیمت» دسترسی ندارید.',
  cta: '/my-tasks',
},
```
استفاده در `app-admin-pricing-actions.ts` → helper `requirePricingEditAccess()` → throw `AccessDeniedError('A-SECTION-PRICING', ...)`

**⚠️ این فایل از قبل وجود دارد** — entry جدید group-18 اضافه شد. فایل کامل پکیج شده، روی هم بنویسید.

---

### ۲. Admin UI: `/admin-pricing` (۲ فایل)

#### `app-admin-pricing-page.tsx` (28.2 KB)
**مقصد نهایی:** `anbarpolymer-app/src/app/admin-pricing/page.tsx`  
**امضای صفحه:**
```typescript
export default async function AdminPricingPage({
  searchParams
}: {
  searchParams: Promise<{ tab?: string }>
})
```
**⚠️ CRITICAL:** `searchParams` حتماً async Promise — سایت Next.js 16؛ synchronous destructuring سوئیچ تب را می‌شکند.

**ساختار:**
- **7 تب اصلی** (query param `?tab=...`):
  1. `formula` — فرمول محاسبه قیمت (PriceFormulaRule CRUD)
  2. `waterfall` — آبشاری قیمت (WaterfallRule CRUD)
  3. `payment` — شرایط پرداخت (PaymentTermRule CRUD)
  4. `volume` — تخفیف حجمی (VolumeTierRule CRUD)
  5. `margins` — راهنمای حاشیه سود (MarginGuidance CRUD، با انتخاب grade)
  6. `approval` — قوانین تصویب (ApprovalRule CRUD، ژنریک سه entityType)
  7. `publish` — انتشار بنچمارک (GlobalBenchmarkPrice + BenchmarkPublishRecord + WarehouseStock)

- **Tab 7 (publish) زیرتب دارد** (query param `?tab=publish&subtab=...`):
  - `benchino` (پیش‌فرض) — GlobalBenchmarkPrice CRUD
  - `live` — WarehouseStock + dealLightStatus (چراغ سبز/زرد/قرمز)
  - `release` — BenchmarkPublishRecord (تاریخچه انتشار + تصویب/رد)

**UI:**
- **هیچ داده‌ی نمونه‌ای در HTML نیست** — همه جداول از دیتابیس واقعی خوانده می‌شوند.
- Empty state برای count=0.
- فرم‌های CRUD inline — NO modal/drawer (سادگی handoff).
- پالت رنگ: #1e357b (navy) + #f6621b (نارنجی برند) — **دقیقاً** همان BENCHINOO_V2_0.html اما recolored.
- Style constants در انتهای فایل: btnPrimaryStyle, btnEditStyle, inputStyle, tableStyle, theadRowStyle, thStyle, tbodyRowStyle, tdStyle.

**دسترسی:**
- ادمین: full access.
- non-admin: بر اساس `access.pricing` (none/view/edit/full).
- view: فقط خواندن، فرم‌های CRUD مخفی.
- edit/full: CRUD کامل.

**اتصالات:**
- actions: همه CRUD از `./actions.ts` import شده.
- `evaluateApprovalRequirement` — فقط در publishBenchmarkAction استفاده شده (tab 7 subtab release).

#### `app-admin-pricing-actions.ts` (21.3 KB)
**مقصد نهایی:** `anbarpolymer-app/src/app/admin-pricing/actions.ts`  
**امضای کلی:** همه Server Actions — 'use server' در بالا.

**Helper اصلی:**
```typescript
async function requirePricingEditAccess(): Promise<void> {
  const user = await getCurrentUser()
  if (user.role === 'admin') return
  const access = await getAllSectionAccess(user.id)
  if (access.pricing !== 'edit' && access.pricing !== 'full') {
    throw new AccessDeniedError('A-SECTION-PRICING', { userId: user.id, section: 'pricing' })
  }
}
```
**همه CRUD actions این helper را اول صدا می‌زنند.**

**Helpers ابزاری:**
- `toFloatOrNull(val)` — پاک‌سازی جداکننده فارسی (٬ ،) → Number
- `toStr(val)` — trim + null check
- `resolveSourceValue(sourceType, manualValue, apiSnapshotValue)` — برای tab 7: manual vs API
- `revalidatePricing()` — revalidatePath('/admin-pricing')

**Actions per model:**
1. **PriceFormulaRule:** create/update/delete
2. **WaterfallRule:** create/update/delete
3. **PaymentTermRule:** create/update/delete
4. **VolumeTierRule:** create/update/delete
5. **MarginGuidance:** create/update/delete (با gradeId)
6. **ApprovalRule:** create/update/delete
7. **GlobalBenchmarkPrice (Benchino):** create/update/delete (با gradeId)
8. **BenchmarkPublishRecord:**
   - `publishBenchmarkAction` — اتصال به `evaluateApprovalRequirement('BenchmarkPublish', undefined, deviationPercent)`:
     - اگر approvalLevel null → status='approved' فوری
     - غیرش → status='pending' + نیاز تایید
   - `approveBenchmarkPublishAction` — status='approved'
   - `rejectBenchmarkPublishAction` — status='rejected'

**⚠️ هیچ seed data نیست** — جداول خالی شروع می‌شوند؛ ادمین از UI پر می‌کند.

---

### ۳. Display Sites: `Deal.agreedPrice` String→Float Fix (۳ فایل)

#### `app-admin-deals-page.tsx` (30.6 KB)
**مقصد نهایی:** `anbarpolymer-app/src/app/admin-deals/page.tsx`  
**فیکس:** خط ۲۲۵:
```tsx
قیمت توافقی: {deal.agreedPrice !== null && deal.agreedPrice !== undefined ? `${deal.agreedPrice.toLocaleString('fa-IR')} ریال` : '—'}
```
**قبلاً:** `deal.agreedPrice` به‌صورت String خوانده می‌شد → خطای `.toLocaleString()` یا نمایش خام.  
**الان:** null/undefined check + `.toLocaleString('fa-IR')` صحیح.

**⚠️ این فایل از قبل وجود دارد** — فقط یک خط تغییر کرد، اما فایل کامل پکیج شده برای سهولت.

#### `app-my-deals-page.tsx` (4.9 KB)
**مقصد نهایی:** `anbarpolymer-app/src/app/my-deals/page.tsx`  
**فیکس:** خط ۷۵:
```tsx
{deal.agreedPrice !== null && deal.agreedPrice !== undefined ? `${deal.agreedPrice.toLocaleString('fa-IR')} ریال` : 'قیمت توافقی ثبت نشده'}
```
همان الگو — fallback «ثبت نشده» برای buyer.

#### `app-my-deals-[id]-page.tsx` (8.7 KB)
**مقصد نهایی:** `anbarpolymer-app/src/app/my-deals/[id]/page.tsx`  
**فیکس:** دو سایت:
1. خط ۶۹ (InfoRow):
   ```tsx
   <InfoRow label="قیمت توافقی" value={deal.agreedPrice !== null && deal.agreedPrice !== undefined ? `${deal.agreedPrice.toLocaleString('fa-IR')} ریال` : 'ثبت نشده'} mono={deal.agreedPrice !== null && deal.agreedPrice !== undefined} />
   ```
2. خط ۹۹ (DealBankPay amountLabel):
   ```tsx
   amountLabel={deal.agreedPrice !== null && deal.agreedPrice !== undefined ? `${deal.agreedPrice.toLocaleString('fa-IR')} ریال` : 'مبلغ توافقی'}
   ```

**⚠️ این سه فایل از قبل وجود دارند** — فیکس Float display، کپی byte-identical پکیج شده.

---

## 🔗 نقاط اتصال به فلوهای موجود

**این بخش یک نگاه سریع است — برای جزئیات کامل (کد پیشنهادی، فیلدهای schema، اکشن‌های جدید، وضعیت‌های جدید) به `CONNECTIONS-GROUP-18.md` مراجعه کنید.**

سه نقطه‌ی اتصال که `evaluateApprovalRequirement` باید صدا زده شود:

### ۱. ثبت سفارش (Order Registration)
**فایل:** `admin-orders/actions.ts` → `setOrderPricing`  
**چه موقع:** قبل از `startProformaDeadline`  
**پارامتر:** `('Order', totalAmount)`  
**منطق:** اگر approvalLevel برگشت → status='awaiting_approval'، وگرنه مسیر قبلی (priced)  
**وضعیت:** ⏸️ نیاز به پیاده‌سازی

### ۲. انتشار بنچمارک (BenchmarkPublish)
**فایل:** `admin-pricing/actions.ts` → `publishBenchmarkAction`  
**چه موقع:** قبل از create کردن BenchmarkPublishRecord  
**پارامتر:** `('BenchmarkPublish', undefined, deviationPercent)`  
**منطق:** اگر approvalLevel برگشت → status='pending'، وگرنه 'approved' و همین‌الان قیمت‌ها اعمال می‌شن  
**وضعیت:** ✅ کامل پیاده‌شده

### ۳. تایید معامله (Deal Confirmation)
**فایل:** `lib/dealDeadlines.ts` → `startBuyerPaymentDeadline`  
**چه موقع:** قبل از تنظیم status='confirmed'  
**پارامتر:** `('Deal', agreedPrice)`  
**منطق:** اگر approvalLevel برگشت → status='awaiting_approval' و deadline تنظیم نمی‌شه، وگرنه مسیر قبلی (confirmed + deadline)  
**وضعیت:** ⏸️ نیاز به پیاده‌سازی

**📄 سند کامل:** `CONNECTIONS-GROUP-18.md` شامل کد پیشنهادی، فیلدهای schema اختیاری (`Order.approvalLevel`, `Deal.approvalLevel`)، وضعیت‌های جدید (`awaiting_approval`), و اکشن‌های موردنیاز (`approveOrder`, `approveDeal`).

---

## ⚙️ دستورات نصب و راه‌اندازی

### مرحله ۱: استخراج و کپی
```bash
cd /var/www/anbarpolymer-app
tar -xzf /path/to/group-18-price-engine-v2.tar.gz -C /tmp/group18

# کپی فایل‌های TypeScript/TSX
cp /tmp/group18/src-lib-errorCodes.ts src/lib/errorCodes.ts
cp /tmp/group18/src-lib-sections.ts src/lib/sections.ts
cp /tmp/group18/src-lib-priceEngine.ts src/lib/priceEngine.ts
cp /tmp/group18/app-admin-pricing-page.tsx src/app/admin-pricing/page.tsx
cp /tmp/group18/app-admin-pricing-actions.ts src/app/admin-pricing/actions.ts
cp /tmp/group18/app-admin-deals-page.tsx src/app/admin-deals/page.tsx
cp /tmp/group18/app-my-deals-page.tsx src/app/my-deals/page.tsx
cp /tmp/group18/app-my-deals-\[id\]-page.tsx src/app/my-deals/[id]/page.tsx

# Schema: merge دستی (باز کردن prisma-schema-delta-group-18.prisma و دنبال دستورالعمل)
# دستورالعمل کامل در فایل delta آمده
```

### مرحله ۲: Migration و Generate
```bash
npx prisma migrate dev --name add-price-engine-group-18
npx prisma generate
```
**⚠️ اگر خطای migration داد:**  
احتمالاً `Deal.agreedPrice` یا `Order.approvalLevel` / `Deal.approvalLevel` تداخل دارند — schema موجود را با این یکی مقایسه کنید.

### مرحله ۳: Build
```bash
npm run build
```
**⚠️ اگر خطای TypeScript داد:**  
- `DealBankPay` component وجود دارد؟ (`src/components/DealBankPay.tsx`)
- `RefundPolicyHint` component وجود دارد؟ (`src/components/RefundPolicyHint.tsx`)
- `ConfirmSubmitButton` component وجود دارد؟ (`src/components/ConfirmSubmitButton.tsx`)

### مرحله ۴: Restart PM2
```bash
pm2 restart anbarpolymer
pm2 logs anbarpolymer --lines 50
```

### مرحله ۵: تست
1. لاگین به‌عنوان admin → منوی سمت چپ → **📊 بنچمارک قیمت**
2. تب ۱ (فرمول): یک فرمول تست ایجاد کنید → ذخیره → مشاهده در جدول
3. تب ۶ (قوانین تصویب): یک ApprovalRule با `entityType='Order'`, `conditionType='amount'`, `thresholdValue=10000000`, `approvalLevel='manager'` بسازید
4. تب ۷ (بنچمارک): زیرتب Benchino → یک GlobalBenchmarkPrice بسازید (نیاز به gradeId دارد)
5. زیرتب Release → یک deviationPercent بالای threshold وارد کنید → Publish → status='pending' ببینید
6. admin-deals → یک Deal با `agreedPrice` Float را مشاهده کنید — باید با ریال نمایش داده شود، نه String خام
7. my-deals (buyer) → همین‌طور

---

## 🎯 تصمیمات طراحی کلیدی

### ۱. UI: Single-Page با 7 Tab + Subtabs (نه 7 صفحه جدا)
**چرا:** BENCHINOO_V2_0.html الگوی 7-tab داشت؛ همان را full-width با react state حفظ کردیم. سوئیچ تب بدون reload صفحه.

### ۲. Schema: API vs Manual (sourceType + manualValue + apiSnapshotValue)
**چرا:** tab 7 (Benchino Live) — آینده باید از API خارجی قیمت بگیرد، اما الان manual است. با این طرح، وقتی API آماد شد، فقط یک فیلد toggle می‌زنیم.

### ۳. Approval Engine: Generic با Entity Type
**چرا:** نخواستیم ۳ تابع جدا Order/Deal/Benchmark — یک موتور، ۳ entityType، همان `ApprovalRule` جدول. قابل توسعه برای entity جدید بدون تغییر کد.

### ۴. Deal.agreedPrice: String → Float (breaking change)
**چرا:** String فقط برای نمایش بود، اما `.toLocaleString()` روی string خطا می‌داد. با Float، هم محاسبه راحت‌تر هم نمایش صحیح.  
**Migration path:** schema این فیلد را nullable کرد — اگر Deal قدیمی String داشت، migration باید آن را Float parse کند یا null بگذارد.

### ۵. NO Modal/Drawer — همه CRUD inline
**چرا:** سادگی handoff به فریلنسر بعدی. Modal = state management پیچیده‌تر. inline form + table = ساده‌ترین Next.js.

### ۶. Empty Tables — NO Seed Data
**چرا:** این موتور قیمت‌گذاری **خاص هر کسب‌وکار** است — هیچ default قابل‌استفاده‌ی عمومی وجود ندارد. ادمین خودش پر می‌کند.

### ۷. Access Control: pricing Section با 4 سطح (none/view/edit/full)
**چرا:** الگوی کلی سایت — هر بخش یک `SectionAccess`. pricing حساس است؛ non-admin فقط با edit/full می‌تواند CRUD بزند.

---

## 🧪 تست‌های پیشنهادی

### Unit Tests (اگر Jest setup دارید)
```typescript
// src/lib/__tests__/priceEngine.test.ts
import { evaluateApprovalRequirement } from '../priceEngine'
import prisma from '../prisma'

describe('evaluateApprovalRequirement', () => {
  it('should return null if no active rules match', async () => {
    // setup: no ApprovalRule in DB
    const result = await evaluateApprovalRequirement('Order', 5000)
    expect(result).toBeNull()
  })

  it('should return highest matching level', async () => {
    // setup: ApprovalRule { entityType='Order', conditionType='amount', thresholdValue=10000, approvalLevel='manager' }
    const result = await evaluateApprovalRequirement('Order', 15000)
    expect(result).toBe('manager')
  })

  it('should return null if approvalLevel is "auto"', async () => {
    // setup: ApprovalRule { thresholdValue=5000, approvalLevel='auto' }
    const result = await evaluateApprovalRequirement('Order', 7000)
    expect(result).toBeNull()
  })
})
```

### Integration Tests (manual در مرورگر)
1. **CRUD Tabs 1-5:** ایجاد/ویرایش/حذف هر مدل → بررسی جدول به‌روز می‌شود
2. **Tab 6 (Approval Rules):**
   - قانون: Order با amount ≥ 10M → manager
   - تست: Order ۱۵M بسازید (از RFQ) → باید pending_approval شود
3. **Tab 7 (Benchino Publish):**
   - GlobalBenchmarkPrice با basePrice=50000
   - BenchmarkPublish با deviationPercent=15% → اگر ApprovalRule برای deviation ≥ 10% داشته باشید، status=pending
   - Approve → status=approved
4. **Deal agreedPrice Display:**
   - Deal با agreedPrice=12345678.50 → باید «۱۲٬۳۴۵٬۶۷۸٫۵۰ ریال» ببینید (فارسی، با جداکننده)
   - NOT: "12345678.5" خام

### Edge Cases
- **Tab switching:** ?tab=formula → ?tab=margins → برگشت به ?tab=formula — state ذخیره نمی‌شود (server-side)، اما داده همیشه fresh
- **Empty tables:** count=0 → «هیچ رکوردی یافت نشد» (نه خطا)
- **Non-admin با view:** دکمه‌های CRUD غیرفعال/مخفی
- **Subtab پیش‌فرض:** ?tab=publish بدون subtab → subtab=benchino default

---

## 📊 آمار فایل‌ها

| فایل | سایز | خطوط | توضیح |
|------|------|------|-------|
| prisma-schema-delta-group-18.prisma | 6.2 KB | ~200 | ۸ مدل جدید + ۳ تغییر (delta، نه کامل) |
| src-lib-errorCodes.ts | 7.5 KB | 169 | +1 entry: A-SECTION-PRICING |
| src-lib-sections.ts | 3.3 KB | 37 | +1 row: pricing isReal:true |
| src-lib-priceEngine.ts | 3.0 KB | 82 | موتور ژنریک تصویب |
| app-admin-pricing-page.tsx | 28.2 KB | 677 | 7-tab UI + subtabs |
| app-admin-pricing-actions.ts | 21.3 KB | 507 | CRUD actions + publish logic |
| app-admin-deals-page.tsx | 30.6 KB | 408 | agreedPrice Float fix |
| app-my-deals-page.tsx | 4.9 KB | 127 | agreedPrice Float fix |
| app-my-deals-[id]-page.tsx | 8.7 KB | 175 | agreedPrice Float fix |
| **TOTAL** | **113 KB** | **~2382 خط** | ۹ فایل |

**آرشیو نهایی:** `group-18-price-engine-v2.tar.gz` — **26 KB** (فشرده‌شده)

---

## ⚠️ نکات مهم قبل از Deploy

### ۱. Backup Database
قبل از `prisma migrate`, حتماً backup بگیرید:
```bash
pg_dump -U postgres -d anbarpolymer -F c -f backup-before-group-18.dump
```

### ۲. Migration Preview
```bash
npx prisma migrate dev --create-only --name preview-group-18
# فایل migration را در prisma/migrations/ بررسی کنید
# اگر مشکلی دیدید، آن را ویرایش کنید قبل از apply
npx prisma migrate dev
```

### ۳. Deal.agreedPrice Migration Data
اگر Deal های موجود `agreedPrice` به‌صورت String دارند (مثلاً `"12345678"`):
```sql
-- در migration SQL اضافه کنید:
UPDATE "Deal"
SET "agreedPrice" = CAST("agreedPrice" AS FLOAT)
WHERE "agreedPrice" IS NOT NULL AND "agreedPrice" ~ '^[0-9.]+$';
```
**یا:** nullable بگذارید و بعداً دستی درست کنید.

### ۴. PM2 Process Name
فایل پکیج شده فرض کرده PM2 process name = **`anbarpolymer`**  
اگر متفاوت است (مثلاً `anbarpolymer-app`):
```bash
pm2 restart anbarpolymer-app
```

### ۵. Node Version
سرور باید Node.js ≥ 18 داشته باشد (Next.js 15 requirement).
```bash
node -v  # باید v18.x یا بالاتر باشد
```

---

## 📝 Checklist نصب

- [ ] Backup database گرفته شد
- [ ] تمام ۹ فایل به مقصد نهایی کپی شدند
- [ ] `npx prisma migrate dev --name add-price-engine-group-18` اجرا شد
- [ ] `npx prisma generate` اجرا شد بدون خطا
- [ ] `npm run build` موفق بود (no TypeScript errors)
- [ ] `pm2 restart anbarpolymer` انجام شد
- [ ] `/admin-pricing` در مرورگر باز می‌شود (7 تب نمایش داده می‌شود)
- [ ] تب ۱ (فرمول): یک رکورد تست ایجاد شد و در جدول نمایش داده شد
- [ ] تب ۶ (قوانین تصویب): یک ApprovalRule تست ساخته شد
- [ ] تب ۷ (بنچمارک): زیرتب‌های Benchino/Live/Release کار می‌کنند
- [ ] `/admin-deals` یک Deal با `agreedPrice` Float را صحیح نمایش می‌دهد (با ریال فارسی)
- [ ] `/my-deals` و `/my-deals/[id]` همین‌طور
- [ ] اتصالات دستی (Order RFQ + Deal deadline) اضافه شدند (اختیاری، ولی برای کامل‌شدن ادغام لازم)

---

## 🎉 وضعیت تحویل

✅ **۹ فایل کامل و آماده**  
✅ **Schema migration آماده (نیاز به اجرای دستی شما)**  
✅ **NO seed data — جداول خالی شروع می‌شوند**  
✅ **UI design دقیقاً همان BENCHINOO_V2_0.html، recolored به پالت سایت**  
✅ **PC/PB split کد-فقط — کاربر «موتور قیمت‌گذاری/بنچمارک» واحد می‌بیند**  
✅ **Approval engine ژنریک و قابل توسعه**  
✅ **Deal.agreedPrice Float fix در همه سایت‌های نمایش**  
✅ **دو نقطه اتصال خارجی (Order RFQ + Deal deadline) مستندسازی شده — نیاز به کار دستی شما**  

---

**سوالات؟** بررسی کنید:
- BENCHINOO_V2_0.html (طراحی مرجع)
- prompt-group-18-price-engine.md (مشخصات تسک)
- این گزارش (REPORT-GROUP-18.md)

**آماده‌ی نصب.** 🚀
