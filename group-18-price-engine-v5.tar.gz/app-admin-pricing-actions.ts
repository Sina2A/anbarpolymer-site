'use server'

// اکشن‌های پنل مدیریت بنچمارک قیمت (گروه ۱۸ — موتور قیمت‌گذاری و بنچمارک)
//
// CRUD هشت مدل جدید + انتشار بنچمارک با اتصال به موتور تایید عمومی
// (evaluateApprovalRequirement از src/lib/priceEngine.ts).
// هیچ عدد تجاری اینجا هاردکد نشده — همه‌چیز از جدول‌های
// ApprovalRule و بقیه‌ی مدل‌ها خونده می‌شه.
//
// فیلدهای manual/api روی مدل‌هایِ API-خوان (PriceFormulaRule,
// GlobalBenchmarkPrice) منطق «تغییر دستی روی داده‌ی خودکار» رو پشتیبانی
// می‌کنن: sourceType=manual → manualValue؛ sourceType=api → apiSnapshotValue.

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import { AccessDeniedError } from '@/lib/errorCodes'
import { logAudit } from '@/lib/logger'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import { evaluateApprovalRequirement } from '@/lib/priceEngine'

/** چک دسترسی نوشتن — مدیر همیشه مجاز؛ کارشناس فقط اگه canEdit روی «pricing» داشته باشه. */
async function requirePricingEditAccess() {
  const user = await getCurrentUser()
  if (user.role === 'admin') return user
  const access = await getAllSectionAccess(user.id)
  if (access.pricing !== 'edit' && access.pricing !== 'full') {
    throw new AccessDeniedError(
      'A-SECTION-PRICING',
      'دسترسی ویرایش «بنچمارک قیمت» رو نداری — از مدیر بخواه بهت بده.'
    )
  }
  return user
}

/** عدد فشرده (ممیز فارسی/انگلیسی) → عدد. خالی → null. */
function toFloatOrNull(s: string | undefined | null): number | null {
  const t = (s ?? '').trim().replace(/٬/g, '').replace(/[،]/g, '').replace(/,/g, '.')
  if (t === '') return null
  const n = Number(t)
  return Number.isFinite(n) ? n : null
}

function toStr(value: FormDataEntryValue | null | undefined): string {
  return (value as string | null | undefined) ?? ''
}

/**
 * مولفه‌ی مشترک اعتبارسنجی mode: دستی / API — برای مدل‌هایی که toggle
 * منبع دارن (PriceFormulaRule، GlobalBenchmarkPrice).
 */
function resolveSourceValue(sourceType: string, manualValue: string, apiSnapshotValue: string) {
  return {
    sourceType: sourceType === 'api' ? 'api' : 'manual',
    manualValue: sourceType === 'api' ? null : toFloatOrNull(manualValue),
    apiSnapshotValue: sourceType === 'api' ? toFloatOrNull(apiSnapshotValue) : null,
  }
}

function revalidatePricing() {
  revalidatePath('/admin-pricing')
}

// ═══════════════════════ تب ۱: فرمول پایه & Reference ═══════════════════════

export async function createPriceFormulaAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const gradeId = toStr(formData.get('gradeId')) || null
  const formulaText = toStr(formData.get('formulaText')).trim()
  if (!formulaText) throw new Error('متن فرمول الزامی است.')

  const sourceType = toStr(formData.get('sourceType'))
  const src = resolveSourceValue(sourceType, toStr(formData.get('manualValue')), toStr(formData.get('apiSnapshotValue')))

  await prisma.priceFormulaRule.create({
    data: {
      gradeId,
      formulaText,
      sourceType: src.sourceType,
      manualValue: src.manualValue,
      apiSnapshotValue: src.apiSnapshotValue,
      isActive: formData.get('isActive') === 'on',
    },
  })

  await logAudit('pricing', `فرمول قیمت ${gradeId ? 'برای گرید ' + gradeId : 'عمومی'} ثبت شد`, user.id, { gradeId })
  revalidatePricing()
  redirect('/admin-pricing?tab=formula')
}

export async function updatePriceFormulaAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const id = toStr(formData.get('id'))
  const gradeId = toStr(formData.get('gradeId')) || null
  const formulaText = toStr(formData.get('formulaText')).trim()
  if (!formulaText) throw new Error('متن فرمول الزامی است.')
  const sourceType = toStr(formData.get('sourceType'))
  const src = resolveSourceValue(sourceType, toStr(formData.get('manualValue')), toStr(formData.get('apiSnapshotValue')))

  await prisma.priceFormulaRule.update({
    where: { id },
    data: {
      gradeId,
      formulaText,
      sourceType: src.sourceType,
      manualValue: src.manualValue,
      apiSnapshotValue: src.apiSnapshotValue,
      isActive: formData.get('isActive') === 'on',
    },
  })

  await logAudit('pricing', `فرمول قیمت ${id} ویرایش شد`, user.id, { id })
  revalidatePricing()
  redirect('/admin-pricing?tab=formula')
}

export async function deletePriceFormulaAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const id = toStr(formData.get('id'))
  await prisma.priceFormulaRule.delete({ where: { id } })
  await logAudit('pricing', `فرمول قیمت ${id} حذف شد`, user.id, { id })
  revalidatePricing()
}

// ═══════════════════════ تب ۲: آبشار قیمت ═══════════════════════

export async function createWaterfallRuleAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const conditionType = toStr(formData.get('conditionType'))
  const conditionValue = toStr(formData.get('conditionValue')).trim()
  const adjustmentType = toStr(formData.get('adjustmentType'))
  const adjustmentValue = toFloatOrNull(toStr(formData.get('adjustmentValue')))
  if (!conditionValue || adjustmentValue === null) throw new Error('مقدار شرط و مقدار تنظیم الزامی است.')

  await prisma.waterfallRule.create({
    data: {
      priority: toFloatOrNull(toStr(formData.get('priority'))) ?? 0,
      conditionType,
      conditionValue,
      adjustmentType,
      adjustmentValue,
      isActive: formData.get('isActive') === 'on',
    },
  })

  await logAudit('pricing', `قانون آبشار (${conditionType}: ${conditionValue}) ثبت شد`, user.id, {})
  revalidatePricing()
  redirect('/admin-pricing?tab=waterfall')
}

export async function updateWaterfallRuleAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const id = toStr(formData.get('id'))
  const conditionValue = toStr(formData.get('conditionValue')).trim()
  const adjustmentValue = toFloatOrNull(toStr(formData.get('adjustmentValue')))
  if (!conditionValue || adjustmentValue === null) throw new Error('مقدار شرط و مقدار تنظیم الزامی است.')

  await prisma.waterfallRule.update({
    where: { id },
    data: {
      priority: toFloatOrNull(toStr(formData.get('priority'))) ?? 0,
      conditionType: toStr(formData.get('conditionType')),
      conditionValue,
      adjustmentType: toStr(formData.get('adjustmentType')),
      adjustmentValue,
      isActive: formData.get('isActive') === 'on',
    },
  })

  await logAudit('pricing', `قانون آبشار ${id} ویرایش شد`, user.id, { id })
  revalidatePricing()
  redirect('/admin-pricing?tab=waterfall')
}

export async function deleteWaterfallRuleAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const id = toStr(formData.get('id'))
  await prisma.waterfallRule.delete({ where: { id } })
  await logAudit('pricing', `قانون آبشار ${id} حذف شد`, user.id, { id })
  revalidatePricing()
}

// ═══════════════════════ تب ۳: ضرایب تسویه ═══════════════════════

export async function createPaymentTermRuleAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const termDays = toFloatOrNull(toStr(formData.get('termDays')))
  const adjustmentPercent = toFloatOrNull(toStr(formData.get('adjustmentPercent')))
  if (termDays === null || adjustmentPercent === null) throw new Error('مدت پرداخت و ضریب الزامی است.')

  await prisma.paymentTermRule.create({
    data: {
      termDays,
      adjustmentPercent,
      isActive: formData.get('isActive') === 'on',
    },
  })

  await logAudit('pricing', `شرط تسویه ${termDays} روزه (${adjustmentPercent}%) ثبت شد`, user.id, {})
  revalidatePricing()
  redirect('/admin-pricing?tab=payment')
}

export async function updatePaymentTermRuleAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const id = toStr(formData.get('id'))
  const termDays = toFloatOrNull(toStr(formData.get('termDays')))
  const adjustmentPercent = toFloatOrNull(toStr(formData.get('adjustmentPercent')))
  if (termDays === null || adjustmentPercent === null) throw new Error('مدت پرداخت و ضریب الزامی است.')

  await prisma.paymentTermRule.update({
    where: { id },
    data: { termDays, adjustmentPercent, isActive: formData.get('isActive') === 'on' },
  })

  await logAudit('pricing', `شرط تسویه ${id} ویرایش شد`, user.id, { id })
  revalidatePricing()
  redirect('/admin-pricing?tab=payment')
}

export async function deletePaymentTermRuleAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const id = toStr(formData.get('id'))
  await prisma.paymentTermRule.delete({ where: { id } })
  await logAudit('pricing', `شرط تسویه ${id} حذف شد`, user.id, { id })
  revalidatePricing()
}

// ═══════════════════════ تب ۴: ضرایب حجم و انبارداری ═══════════════════════

export async function createVolumeTierRuleAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const minTonnage = toFloatOrNull(toStr(formData.get('minTonnage')))
  const adjustmentPercent = toFloatOrNull(toStr(formData.get('adjustmentPercent')))
  if (minTonnage === null || adjustmentPercent === null) throw new Error('حداقل تناژ و ضریب الزامی است.')

  await prisma.volumeTierRule.create({
    data: {
      minTonnage,
      adjustmentPercent,
      storageType: toStr(formData.get('storageType')) || null,
      isActive: formData.get('isActive') === 'on',
    },
  })

  await logAudit('pricing', `پله حجم ${minTonnage} تن (${adjustmentPercent}%) ثبت شد`, user.id, {})
  revalidatePricing()
  redirect('/admin-pricing?tab=volume')
}

export async function updateVolumeTierRuleAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const id = toStr(formData.get('id'))
  const minTonnage = toFloatOrNull(toStr(formData.get('minTonnage')))
  const adjustmentPercent = toFloatOrNull(toStr(formData.get('adjustmentPercent')))
  if (minTonnage === null || adjustmentPercent === null) throw new Error('حداقل تناژ و ضریب الزامی است.')

  await prisma.volumeTierRule.update({
    where: { id },
    data: {
      minTonnage,
      adjustmentPercent,
      storageType: toStr(formData.get('storageType')) || null,
      isActive: formData.get('isActive') === 'on',
    },
  })

  await logAudit('pricing', `پله حجم ${id} ویرایش شد`, user.id, { id })
  revalidatePricing()
  redirect('/admin-pricing?tab=volume')
}

export async function deleteVolumeTierRuleAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const id = toStr(formData.get('id'))
  await prisma.volumeTierRule.delete({ where: { id } })
  await logAudit('pricing', `پله حجم ${id} حذف شد`, user.id, { id })
  revalidatePricing()
}

// ═══════════════════════ تب ۵: سطوح Floor/Target/Stretch ═══════════════════════

export async function createMarginGuidanceAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const gradeId = toStr(formData.get('gradeId'))
  const floorPercent = toFloatOrNull(toStr(formData.get('floorPercent')))
  const targetPercent = toFloatOrNull(toStr(formData.get('targetPercent')))
  const stretchPercent = toFloatOrNull(toStr(formData.get('stretchPercent')))
  if (!gradeId || floorPercent === null || targetPercent === null || stretchPercent === null) {
    throw new Error('گرید و هر سه سطح حاشیه الزامی است.')
  }

  await prisma.marginGuidance.create({
    data: { gradeId, floorPercent, targetPercent, stretchPercent, isActive: formData.get('isActive') === 'on' },
  })

  await logAudit('pricing', `سطوح حاشیه (${floorPercent}/${targetPercent}/${stretchPercent}) برای گرید ${gradeId} ثبت شد`, user.id, { gradeId })
  revalidatePricing()
  redirect('/admin-pricing?tab=margins')
}

export async function updateMarginGuidanceAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const id = toStr(formData.get('id'))
  const floorPercent = toFloatOrNull(toStr(formData.get('floorPercent')))
  const targetPercent = toFloatOrNull(toStr(formData.get('targetPercent')))
  const stretchPercent = toFloatOrNull(toStr(formData.get('stretchPercent')))
  if (floorPercent === null || targetPercent === null || stretchPercent === null) {
    throw new Error('هر سه سطح حاشیه الزامی است.')
  }

  await prisma.marginGuidance.update({
    where: { id },
    data: { floorPercent, targetPercent, stretchPercent, isActive: formData.get('isActive') === 'on' },
  })

  await logAudit('pricing', `سطوح حاشیه ${id} ویرایش شد`, user.id, { id })
  revalidatePricing()
  redirect('/admin-pricing?tab=margins')
}

export async function deleteMarginGuidanceAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const id = toStr(formData.get('id'))
  await prisma.marginGuidance.delete({ where: { id } })
  await logAudit('pricing', `سطوح حاشیه ${id} حذف شد`, user.id, { id })
  revalidatePricing()
}

// ═══════════════════════ تب ۶: قوانین تایید مدیر فروش ═══════════════════════

export async function createApprovalRuleAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const entityType = toStr(formData.get('entityType'))
  const conditionType = toStr(formData.get('conditionType'))
  const thresholdValue = toFloatOrNull(toStr(formData.get('thresholdValue')))
  const requiredLevel = toStr(formData.get('requiredLevel'))
  if (thresholdValue === null) throw new Error('حد آستانه الزامی است.')

  await prisma.approvalRule.create({
    data: {
      entityType,
      conditionType,
      thresholdValue,
      requiredLevel,
      isActive: formData.get('isActive') === 'on',
    },
  })

  await logAudit('pricing', `قانون تایید (${entityType}/${conditionType} ≥ ${thresholdValue} → ${requiredLevel}) ثبت شد`, user.id, {})
  revalidatePricing()
  redirect('/admin-pricing?tab=approval')
}

export async function updateApprovalRuleAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const id = toStr(formData.get('id'))
  const thresholdValue = toFloatOrNull(toStr(formData.get('thresholdValue')))
  if (thresholdValue === null) throw new Error('حد آستانه الزامی است.')

  await prisma.approvalRule.update({
    where: { id },
    data: {
      entityType: toStr(formData.get('entityType')),
      conditionType: toStr(formData.get('conditionType')),
      thresholdValue,
      requiredLevel: toStr(formData.get('requiredLevel')),
      isActive: formData.get('isActive') === 'on',
    },
  })

  await logAudit('pricing', `قانون تایید ${id} ویرایش شد`, user.id, { id })
  revalidatePricing()
  redirect('/admin-pricing?tab=approval')
}

export async function deleteApprovalRuleAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const id = toStr(formData.get('id'))
  await prisma.approvalRule.delete({ where: { id } })
  await logAudit('pricing', `قانون تایید ${id} حذف شد`, user.id, { id })
  revalidatePricing()
}

// ═══════════════════════ تب ۷: مدیریت لیست‌های بنچینو & انتشار ═══════════════════════

// ۷.۱ — قیمت مرجع جهانی گریدها

export async function createBenchinoPriceAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const gradeId = toStr(formData.get('gradeId'))
  if (!gradeId) throw new Error('گرید الزامی است.')

  const sourceType = toStr(formData.get('sourceType'))
  const manualValue = toFloatOrNull(toStr(formData.get('manualValue')))
  const apiSnapshotValue = toFloatOrNull(toStr(formData.get('apiSnapshotValue')))
  const priceUsd = sourceType === 'api' ? apiSnapshotValue : manualValue
  if (priceUsd === null) throw new Error('قیمت (دستی یا اسنپشات API) الزامی است.')

  await prisma.globalBenchmarkPrice.create({
    data: {
      gradeId,
      priceUsd,
      sourceLabel: sourceType === 'api' ? 'API' : toStr(formData.get('sourceLabel')) || 'manual',
    },
  })

  await logAudit('pricing', `قیمت مرجع جهانی گرید ${gradeId} = ${priceUsd}$ ثبت شد`, user.id, { gradeId, priceUsd })
  revalidatePricing()
  redirect('/admin-pricing?tab=publish&subtab=benchino')
}

export async function updateBenchinoPriceAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const id = toStr(formData.get('id'))
  const manualValue = toFloatOrNull(toStr(formData.get('manualValue')))
  const apiSnapshotValue = toFloatOrNull(toStr(formData.get('apiSnapshotValue')))
  const priceUsd = toStr(formData.get('sourceType')) === 'api' ? apiSnapshotValue : manualValue
  if (priceUsd === null) throw new Error('قیمت الزامی است.')

  await prisma.globalBenchmarkPrice.update({
    where: { id },
    data: {
      priceUsd,
      sourceLabel: toStr(formData.get('sourceLabel')) || 'manual',
    },
  })

  await logAudit('pricing', `قیمت مرجع جهانی ${id} ویرایش شد`, user.id, { id })
  revalidatePricing()
  redirect('/admin-pricing?tab=publish&subtab=benchino')
}

export async function deleteBenchinoPriceAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const id = toStr(formData.get('id'))
  await prisma.globalBenchmarkPrice.delete({ where: { id } })
  await logAudit('pricing', `قیمت مرجع جهانی ${id} حذف شد`, user.id, { id })
  revalidatePricing()
}

// ۷.۳ — انتشار بنچمارک (اتصال به موتور تایید عمومی)

export async function publishBenchmarkAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const mode = toStr(formData.get('mode')) === 'detailed' ? 'detailed' : 'global'
  const globalAdjustPercent = toFloatOrNull(toStr(formData.get('globalAdjustPercent')))

  // اتصال به موتور تایید: انحراف بنچمارک در حالت کلی = |درصد تنظیم|
  // (بهازای گرید جداگانه در حالت جزئی می‌تونه در future برگرده — اینجا سطح
  // تایید بر اساس همان درصد کلی / عدم حضور قانون محاسبه می‌شه.)
  const deviationPercent = mode === 'global' && globalAdjustPercent !== null ? globalAdjustPercent : undefined
  const approvalLevel = await evaluateApprovalRequirement('BenchmarkPublish', undefined, deviationPercent)

  const record = await prisma.benchmarkPublishRecord.create({
    data: {
      publishedById: user.id,
      mode,
      globalAdjustPercent,
      status: approvalLevel ? 'pending' : 'approved',
      approvalLevel,
    },
  })

  await logAudit(
    'pricing',
    `انتشار بنچمارک (${mode})${approvalLevel ? ` — نیاز به تایید ${approvalLevel}` : ''} ثبت شد`,
    user.id,
    { recordId: record.id, approvalLevel }
  )
  revalidatePricing()
  redirect('/admin-pricing?tab=publish&subtab=release')
}

export async function approveBenchmarkPublishAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const id = toStr(formData.get('id'))
  const record = await prisma.benchmarkPublishRecord.findUnique({ where: { id } })
  if (!record) throw new Error('سابقه‌ی انتشار یافت نشد.')
  if (record.status !== 'pending') throw new Error('فقط بنچمارک «در انتظار تایید» قابل تایید است.')

  await prisma.benchmarkPublishRecord.update({
    where: { id },
    data: { status: 'approved', approvedById: user.id, approvedAt: new Date() },
  })

  await logAudit('pricing', `بنچمارک ${id} تایید شد`, user.id, { id })
  revalidatePricing()
}

export async function rejectBenchmarkPublishAction(formData: FormData) {
  const user = await requirePricingEditAccess()
  const id = toStr(formData.get('id'))
  const record = await prisma.benchmarkPublishRecord.findUnique({ where: { id } })
  if (!record) throw new Error('سابقه‌ی انتشار یافت نشد.')
  if (record.status !== 'pending') throw new Error('فقط بنچمارک «در انتظار تایید» قابل رد است.')

  await prisma.benchmarkPublishRecord.update({
    where: { id },
    data: { status: 'rejected' },
  })

  await logAudit('pricing', `بنچمارک ${id} رد شد`, user.id, { id })
  revalidatePricing()
}
