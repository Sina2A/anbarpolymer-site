# گزارش اصلاحی v4 — گروه ۱۸

**تاریخ:** ۱۴۰۵/۰۶/۱۰ (2026-09-01)  
**آرشیو:** `group-18-price-engine-v4.tar.gz`

---

## تغییرات v4 نسبت به v3

### ۱. رفع `approvalLevel` → `requiredLevel` در ApprovalRule ✅

**فایل:** `prisma-schema-delta-group-18.prisma`  
**خط ۹۴:**
```
- approvalLevel  String   // 'auto' | 'supervisor' | 'manager' | 'admin'
+ requiredLevel  String   // 'auto' | 'supervisor' | 'manager' | 'admin'
```

---

### ۲. اصلاح مقادیر `WarehouseStock.dealLightStatus` ✅

**فایل:** `prisma-schema-delta-group-18.prisma`  
**خط ۱۶۵:**
```
- dealLightStatus  String?  // 'light' | 'medium' | 'heavy'
+ dealLightStatus  String?  @default("available") // available | negotiating | recently_sold
```

---

### ۳. اتصال واقعی به `admin-orders/actions.ts` ✅

**فایل:** `src/app/admin-orders/actions.ts`  
**تغییرات:**
- `import { evaluateApprovalRequirement } from '@/lib/priceEngine'` اضافه شد
- بعد از ذخیره‌ی finalPrice هر OrderItem، مجموع مبلغ کل سفارش محاسبه می‌شود
- `evaluateApprovalRequirement('Order', totalAmount)` صدا زده می‌شود
- اگر approvalLevel غیر null → status='awaiting_approval' با logStatusEvent
- اگر approvalLevel null → مسیر قبلی (startProformaDeadline) بدون تغییر
- اکشن جدید `approveOrderAction(orderId)` اضافه شد (فقط `role=admin`)
- وضعیت 'awaiting_approval' به `translateOrderStatus` در `dashboard/page.tsx` و `my-requests/page.tsx` اضافه شد

**فایل جدید:** `app-admin-orders-actions.ts`

---

### ۴. اتصال واقعی به `dealDeadlines.ts` ✅

**فایل:** `src/lib/dealDeadlines.ts`  
**تغییرات:**
- `import { evaluateApprovalRequirement } from './priceEngine'` اضافه شد
- در `startBuyerPaymentDeadline` قبل از تنظیم status='confirmed':
  - `deal.agreedPrice` چک می‌شود
  - اگر مقدار داشت: `evaluateApprovalRequirement('Deal', agreedPrice)` صدا زده می‌شود
  - اگر approvalLevel غیر null → status='awaiting_approval' و deadline=null
  - اگر approvalLevel null → مسیر قبلی (status='confirmed' + deadline)
- اکشن جدید `approveDealAction(dealId)` در `admin-deals/actions.ts` اضافه شد
  - فورک داینامیک از `startBuyerPaymentDeadline` برای شروع مهلت بعد از تایید
  - فقط `role=admin`

**فایل جدید:** `app-admin-deals-actions.ts`, `src-lib-dealDeadlines.ts`

---

### ۵. وضعیت جدید در UI ✅

**ترجمه 'awaiting_approval' اضافه شد به:**
- `dashboard/page.tsx` → `translateOrderStatus`: "در انتظار تایید مدیر"
- `my-requests/page.tsx` → `translateOrderStatus`: "در انتظار تایید مدیر"
- `app-admin-deals-page.tsx` → `STATUS_LABELS`: "در انتظار تایید مدیر"
- `app-my-deals-page.tsx` → `STATUS_LABELS`: "در انتظار تایید مدیر"
- `app-my-deals-[id]-page.tsx` → `STATUS_TEXT`: "در انتظار تایید مدیر"
- `anbarpolymer-app/.../admin-deals/page.tsx` → `STATUS_LABELS`: "در انتظار تایید مدیر"

---

## فایل‌های v4

```
NEW FILES/
├── prisma-schema-delta-group-18.prisma     (6.2 KB) — رفع فیلد + dealLightStatus
├── src-lib-priceEngine.ts                  (2.2 KB) — موتور تایید (بدون تغییر)
├── src-lib-dealDeadlines.ts                (8.1 KB) — ⭐ اتصال موتور تایید
├── app-admin-pricing-page.tsx              (22 KB)  — صفحه بنچمارک
├── app-admin-pricing-actions.ts            (16 KB)  — اکشن‌های بنچمارک
├── app-admin-orders-actions.ts             (5.4 KB) — ⭐ اتصال موتور تایید + approveOrderAction
├── app-admin-deals-actions.ts              (4.5 KB) — ⭐ approveDealAction
├── app-admin-deals-page.tsx                (32 KB)  — صفحه معاملات ادمین
├── app-my-deals-page.tsx                   (3.4 KB) — لیست معاملات خریدار
├── app-my-deals-[id]-page.tsx              (5.2 KB) — جزئیات معامله خریدار
├── app-dashboard-page.tsx                  (10 KB)  — ترجمه وضعیت جدید
├── app-my-requests-page.tsx                (6.2 KB) — ترجمه وضعیت جدید
├── CONNECTIONS-GROUP-18.md                 (4.8 KB) — راهنمای اتصال
├── REPORT-GROUP-18.md                      (11 KB)  — گزارش کلی
└── REPORT-GROUP-18-v4.md                   (این فایل) — گزارش v4
```

**آرشیو:** `group-18-price-engine-v4.tar.gz` (13 فایل، ~140 KB)
