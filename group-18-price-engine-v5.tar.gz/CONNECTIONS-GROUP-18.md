# پیوندهای موتور تایید — گروه ۱۸

این سند **سه نقطه‌ی اتصال** موتور تایید (`evaluateApprovalRequirement`) به فلوهای موجود رو شرح می‌ده — کجا صدا می‌شه، چه پارامترهایی می‌گیره، و وضعیت چطور تغییر می‌کنه.

---

## ۱. ثبت سفارش (Order registration)

**فایل:** `src/app/admin-orders/actions.ts`  
**تابع:** `setOrderPricing`  
**خط:** ۱۶-۴۴

### وضعیت فعلی
```typescript
export async function setOrderPricing(formData: FormData) {
  const user = await getCurrentUser()
  const orderId = String(formData.get('orderId'))

  const order = await prisma.order.findUnique({ where: { id: orderId }, include: { items: true } })
  if (!order) throw new Error('سفارش پیدا نشد.')

  // ذخیره‌ی finalPrice برای هر قلم
  await prisma.$transaction(
    order.items.map((item) =>
      prisma.orderItem.update({
        where: { id: item.id },
        data: { finalPrice: parseFloat(String(formData.get(`finalPrice-${item.id}`) || item.price)) },
      })
    )
  )

  // وضعیت priced + مهلت تایید پیش‌فاکتور مشتری (ساعت کاری، از تنظیمات) یک‌جا ثبت می‌شن
  await startProformaDeadline(orderId)

  await logStatusEvent({
    recordType: 'Order',
    recordId: orderId,
    newStageKey: 'priced',
    performedById: user.id,
    note: 'قیمت نهایی توسط کارشناس فروش ثبت شد',
  })

  revalidatePath('/admin-orders')
}
```

### اتصال پیشنهادی
**قبل از** `startProformaDeadline`، جمع مبلغ نهایی رو محاسبه کن و موتور تایید رو صدا بزن:

```typescript
import { evaluateApprovalRequirement } from '@/lib/priceEngine'

export async function setOrderPricing(formData: FormData) {
  const user = await getCurrentUser()
  const orderId = String(formData.get('orderId'))

  const order = await prisma.order.findUnique({ where: { id: orderId }, include: { items: true } })
  if (!order) throw new Error('سفارش پیدا نشد.')

  await prisma.$transaction(
    order.items.map((item) =>
      prisma.orderItem.update({
        where: { id: item.id },
        data: { finalPrice: parseFloat(String(formData.get(`finalPrice-${item.id}`) || item.price)) },
      })
    )
  )

  // محاسبه‌ی مبلغ کل (ریال)
  const updatedItems = await prisma.orderItem.findMany({ where: { orderId } })
  const totalAmount = updatedItems.reduce((sum, item) => sum + (item.finalPrice ?? item.price) * item.quantity, 0)

  // ارزیابی نیاز به تایید
  const approvalLevel = await evaluateApprovalRequirement('Order', totalAmount)

  if (approvalLevel) {
    // نیاز به تایید — وضعیت awaiting_approval + approvalLevel ذخیره می‌شه
    await prisma.order.update({
      where: { id: orderId },
      data: {
        status: 'awaiting_approval',
        // approvalLevel: approvalLevel  ← فیلد جدید نیاز داره (اختیاری)
      },
    })

    await logStatusEvent({
      recordType: 'Order',
      recordId: orderId,
      newStageKey: 'awaiting_approval',
      performedById: user.id,
      note: `مبلغ ${totalAmount.toLocaleString('fa-IR')} ریال نیاز به تایید ${approvalLevel} دارد`,
    })
  } else {
    // خودکار تایید — مسیر قبلی
    await startProformaDeadline(orderId)

    await logStatusEvent({
      recordType: 'Order',
      recordId: orderId,
      newStageKey: 'priced',
      performedById: user.id,
      note: 'قیمت نهایی توسط کارشناس فروش ثبت شد',
    })
  }

  revalidatePath('/admin-orders')
}
```

**توجه:**
- وضعیت جدید `awaiting_approval` باید به `translateOrderStatus` در `dashboard/page.tsx` و `my-requests/page.tsx` اضافه بشه
- اگه می‌خوای `approvalLevel` رو روی Order ذخیره کنی (برای نمایش در پنل)، فیلد `approvalLevel String?` رو به مدل Order اضافه کن
- یه اکشن جدید مثل `approveOrder(orderId)` لازمه که بعد از تایید مدیر، `startProformaDeadline` رو صدا بزنه

---

## ۲. انتشار بنچمارک (BenchmarkPublish)

**فایل:** `src/app/admin-pricing/actions.ts`  
**تابع:** `publishBenchmarkAction`  
**خط:** حدود ۴۸۰ (از NEW FILES)

### وضعیت **قبلاً پیاده‌شده** ✅
```typescript
export async function publishBenchmarkAction(formData: FormData) {
  const user = await getCurrentUser()
  await requirePricingEditAccess()

  const mode = String(formData.get('mode')) // 'global' | 'detailed'
  let globalAdjustPercent: number | undefined
  let detailSnapshot: unknown

  if (mode === 'global') {
    globalAdjustPercent = parseFloat(String(formData.get('globalAdjustPercent') || '0'))
  } else {
    const rawJson = String(formData.get('detailSnapshot') || '[]')
    detailSnapshot = JSON.parse(rawJson)
  }

  // ارزیابی نیاز به تایید — درصد انحراف (برای global) یا محاسبه‌ی میانگین انحراف (برای detailed)
  const deviationPercent = mode === 'global' ? Math.abs(globalAdjustPercent ?? 0) : 0 // برای detailed باید محاسبه بشه
  const approvalLevel = await evaluateApprovalRequirement('BenchmarkPublish', undefined, deviationPercent)

  const status = approvalLevel ? 'pending' : 'approved'

  const record = await prisma.benchmarkPublishRecord.create({
    data: {
      publishedById: user.id,
      mode,
      globalAdjustPercent: mode === 'global' ? globalAdjustPercent : null,
      detailSnapshot: mode === 'detailed' ? JSON.stringify(detailSnapshot) : null,
      status,
      approvalLevel,
    },
  })

  if (!approvalLevel) {
    // خودکار تایید — قیمت‌ها رو همین‌الان به‌روز کن
    await applyBenchmarkChanges(record.id)
  }

  await logAudit({
    category: 'pricing',
    message: `Benchmark publish ${status}: mode=${mode}, approvalLevel=${approvalLevel || 'auto'}`,
    userId: user.id,
  })

  revalidatePath('/admin-pricing')
  return { success: true, recordId: record.id, status }
}
```

**هیچ کار اضافی لازم نیست** — این اتصال کامل پیاده‌شده.

---

## ۳. تایید معامله (Deal confirmation)

**فایل:** `src/lib/dealDeadlines.ts`  
**تابع:** `startBuyerPaymentDeadline`  
**خط:** ۲۴۹-۲۵۷

### وضعیت فعلی
```typescript
export async function startBuyerPaymentDeadline(dealId: string) {
  const rules = await getDealRuleSettings()
  const deadline = await calculateBusinessHoursDeadline(new Date(), rules.buyerPaymentHours)

  await prisma.deal.update({
    where: { id: dealId },
    data: { status: 'confirmed', buyerConfirmDeadline: deadline },
  })

  return deadline
}
```

### اتصال پیشنهادی
**قبل از** تنظیم وضعیت `confirmed`, اگه `agreedPrice` پر شده باشه، موتور تایید رو صدا بزن:

```typescript
import { evaluateApprovalRequirement } from './priceEngine'

export async function startBuyerPaymentDeadline(dealId: string) {
  const rules = await getDealRuleSettings()
  const deadline = await calculateBusinessHoursDeadline(new Date(), rules.buyerPaymentHours)

  // بارگیری‌ی Deal برای چک کردن agreedPrice
  const deal = await prisma.deal.findUnique({ where: { id: dealId } })
  if (!deal) throw new Error('معامله پیدا نشد.')

  let finalStatus = 'confirmed'
  let approvalLevel: string | null = null

  if (deal.agreedPrice) {
    // ارزیابی نیاز به تایید
    approvalLevel = await evaluateApprovalRequirement('Deal', deal.agreedPrice)
    if (approvalLevel) {
      finalStatus = 'awaiting_approval'
    }
  }

  await prisma.deal.update({
    where: { id: dealId },
    data: {
      status: finalStatus,
      buyerConfirmDeadline: approvalLevel ? null : deadline, // مهلت فقط برای تایید خودکار
      // approvalLevel: approvalLevel  ← فیلد جدید نیاز داره (اختیاری)
    },
  })

  return deadline
}
```

**توجه:**
- وضعیت جدید `awaiting_approval` باید به `STATUS_LABELS` در `app/my-deals/page.tsx` و `app/my-deals/[id]/page.tsx` اضافه بشه
- اگه می‌خوای `approvalLevel` رو روی Deal ذخیره کنی، فیلد `approvalLevel String?` رو به مدل Deal اضافه کن
- یه اکشن جدید مثل `approveDeal(dealId)` لازمه که بعد از تایید مدیر، وضعیت رو به `confirmed` تغییر بده و مهلت رو تنظیم کنه

---

## جمع‌بندی

| نقطه‌ی اتصال | فایل | تابع | پارامتر موتور | وضعیت پیاده‌سازی |
|---|---|---|---|---|
| **۱. ثبت سفارش** | `admin-orders/actions.ts` | `setOrderPricing` | `('Order', totalAmount)` | ⏸️ نیاز به پیاده‌سازی |
| **۲. انتشار بنچمارک** | `admin-pricing/actions.ts` | `publishBenchmarkAction` | `('BenchmarkPublish', undefined, deviationPercent)` | ✅ کامل پیاده‌شده |
| **۳. تایید معامله** | `lib/dealDeadlines.ts` | `startBuyerPaymentDeadline` | `('Deal', agreedPrice)` | ⏸️ نیاز به پیاده‌سازی |

**فیلدهای schema اختیاری:**
- `Order.approvalLevel String?` — سطح تایید موردنیاز (supervisor|manager|admin)
- `Deal.approvalLevel String?` — سطح تایید موردنیاز

**وضعیت‌های جدید:**
- `Order.status = 'awaiting_approval'` — در انتظار تایید مدیر
- `Deal.status = 'awaiting_approval'` — در انتظار تایید مدیر

**اکشن‌های جدید موردنیاز:**
- `approveOrder(orderId: string)` — تایید سفارش توسط مدیر → `startProformaDeadline` → status='priced'
- `approveDeal(dealId: string)` — تایید معامله توسط مدیر → تنظیم deadline → status='confirmed'

---

**تاریخ:** ۱ شهریور ۱۴۰۵  
**نسخه:** گروه ۱۸ — موتور قیمت‌گذاری/بنچمارک
