import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import UserNav from '@/components/UserNav'

export const dynamic = 'force-dynamic'

export default async function MyRequestsPage() {
  const user = await getCurrentUser()

  // Order هایی که هنوز قیمت نهایی نگرفتن (pending یا priced که هنوز confirmed نشده)
  const pendingOrders = await prisma.order.findMany({
    where: {
      userId: user.id,
      status: { in: ['pending', 'priced'] },
    },
    orderBy: { createdAt: 'desc' },
    include: {
      items: {
        include: { grade: true },
      },
    },
  })

  // MaterialListing هایی که کاربر رزرو کرده ولی هنوز Deal نهایی نشده
  // (یعنی Deal با status='draft' یا اصلاً Deal وجود نداره ولی listing رزرو شده)
  const reservedListings = await prisma.materialListing.findMany({
    where: {
      validityStatus: 'reserved',
      deals: {
        some: {
          buyerId: user.id,
          status: 'draft',
        },
      },
    },
    include: {
      grade: true,
      deals: {
        where: {
          buyerId: user.id,
          status: 'draft',
        },
        take: 1,
      },
    },
  })

  return (
    <div style={pageStyle}>
      <div style={{ maxWidth: 1100, margin: '0 auto', display: 'flex', gap: 24 }} className="admin-page-wrap">
        <UserNav currentUserName={user.companyName} activeSection="requests" />
        <div style={{ flex: 1, minWidth: 0 }}>
          <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>درخواست‌های خرید من</h1>
          <p style={{ fontSize: 13, color: '#9199a3', marginBottom: 20 }}>
            سفارش‌ها و آگهی‌هایی که در حال بررسی یا رزرو هستند
          </p>

          {/* سفارش‌های در انتظار */}
          <div style={cardStyle}>
            <div style={cardHeaderStyle}>
              <b style={{ fontSize: 14 }}>سفارش‌های در انتظار قیمت‌گذاری/تایید</b>
              <span style={badgeStyle}>{pendingOrders.length}</span>
            </div>

            {pendingOrders.length === 0 ? (
              <div style={emptyStyle}>همه سفارش‌ها قیمت‌گذاری و تایید شده‌اند.</div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {pendingOrders.map((order) => (
                  <div key={order.id} style={itemStyle}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: 8 }}>
                      <div>
                        <span style={{ fontSize: 13, fontWeight: 700, fontFamily: 'monospace' }}>
                          #{order.id.slice(0, 8)}
                        </span>
                        <span style={{ ...statusTag, ...statusColors(order.status), marginRight: 8 }}>
                          {translateOrderStatus(order.status)}
                        </span>
                      </div>
                      <span style={{ fontSize: 11, color: '#9199a3' }}>
                        {new Date(order.createdAt).toLocaleDateString('fa-IR')}
                      </span>
                    </div>
                    <div style={{ fontSize: 12.5, color: '#4f5560' }}>
                      {order.items.map((item, idx) => (
                        <div key={item.id} style={{ marginBottom: 4 }}>
                          • {item.grade.code} — {item.quantity} کیلوگرم
                          {item.finalPrice && (
                            <span style={{ color: '#e65716', fontWeight: 700, marginRight: 6 }}>
                              ({item.finalPrice.toLocaleString('fa-IR')} ریال/کیلو)
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* آگهی‌های رزرو شده (Deal در مرحله draft) */}
          <div style={cardStyle}>
            <div style={cardHeaderStyle}>
              <b style={{ fontSize: 14 }}>آگهی‌های رزرو شده (در حال مذاکره)</b>
              <span style={badgeStyle}>{reservedListings.length}</span>
            </div>

            {reservedListings.length === 0 ? (
              <div style={emptyStyle}>هیچ آگهی رزروی در دست مذاکره نیست.</div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {reservedListings.map((listing) => {
                  const deal = listing.deals[0]
                  return (
                    <div key={listing.id} style={itemStyle}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: 8 }}>
                        <div>
                          <span style={{ fontSize: 13, fontWeight: 700 }}>
                            {listing.grade.code}
                          </span>
                          <span style={{ ...statusTag, background: '#fef3c7', color: '#92400e', marginRight: 8 }}>
                            رزرو شده
                          </span>
                        </div>
                        <span style={{ fontSize: 11, color: '#9199a3' }}>
                          {new Date(listing.createdAt).toLocaleDateString('fa-IR')}
                        </span>
                      </div>
                      <div style={{ fontSize: 12.5, color: '#4f5560', marginBottom: 6 }}>
                        مقدار: <b>{listing.quantityTon} تن</b> | محل: {listing.city}, {listing.province}
                      </div>
                      <div style={{ fontSize: 12, color: '#6b7280' }}>
                        قیمت درخواستی: <b>{listing.askingPriceToman.toLocaleString('fa-IR')}</b> تومان/کیلو
                      </div>
                      {deal && (
                        <div style={{ fontSize: 11, color: '#9199a3', marginTop: 6, fontStyle: 'italic' }}>
                          معامله #{deal.id.slice(0, 8)} — در حال بررسی توسط کارشناس
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

// ── ترجمه ───────────────────────────────────────────────────────────────
function translateOrderStatus(status: string): string {
  const map: Record<string, string> = {
    pending: 'در انتظار قیمت‌گذاری',
    priced: 'قیمت‌گذاری شده',
    awaiting_approval: 'در انتظار تایید مدیر',
    confirmed: 'تایید شده',
    completed: 'تکمیل شده',
    cancelled: 'لغو شده',
  }
  return map[status] ?? status
}

function statusColors(status: string): React.CSSProperties {
  if (status === 'pending') return { background: '#fef3c7', color: '#92400e' }
  if (status === 'priced') return { background: '#dbeafe', color: '#1e3a8a' }
  return { background: '#f1efe8', color: '#4f5560' }
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: '#faf8f4',
  padding: '32px 20px',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const cardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 18,
  marginBottom: 14,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const cardHeaderStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: 12,
}
const emptyStyle: React.CSSProperties = {
  fontSize: 12.5,
  color: '#9199a3',
  padding: '16px 0',
  textAlign: 'center',
}
const itemStyle: React.CSSProperties = {
  padding: '14px 16px',
  border: '1px solid #e8e4db',
  borderRadius: 10,
  background: '#faf8f4',
}
const statusTag: React.CSSProperties = {
  fontSize: 10,
  fontWeight: 700,
  borderRadius: 6,
  padding: '3px 8px',
  display: 'inline-block',
}
const badgeStyle: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 700,
  background: '#e65716',
  color: '#fff',
  borderRadius: 8,
  padding: '2px 10px',
}
