'use server'

import prisma from './prisma'

/**
 * موتور عمومی ارزیابی تایید — هیچ عدد تجاری هاردکد شده نداره.
 *
 * وقتی یه سفارش، معامله، یا انتشار بنچمارک ثبت میشه، این تابع رو صدا بزن
 * تا ببینه آیا نیاز به تایید مدیر فروش داره یا خودکاره.
 *
 * @param entityType - نوع موجودیت: Order | Deal | BenchmarkPublish
 * @param amount - مبلغ (تومان) — برای conditionType=amount
 * @param deviationPercent - درصد انحراف از بنچمارک — برای conditionType=deviation_percent
 * @returns سطح تایید موردنیاز: null (خودکار) | "supervisor" | "manager" | "admin"
 *
 * نحوهی استفاده در مسیرهای Order/Deal/Benchmark:
 * 1. Order registration (admin-orders/actions.ts → setOrderPricing):
 *    const level = await evaluateApprovalRequirement('Order', totalAmount)
 *    if (level) { status = 'needs_supervisor_approval' } else { status = 'priced' }
 *
 * 2. Deal confirmation (dealDeadlines.ts → startBuyerPaymentDeadline):
 *    const level = await evaluateApprovalRequirement('Deal', parseFloat(agreedPrice))
 *    if (level) { status = 'needs_approval' } else { status = 'confirmed' }
 *
 * 3. Benchmark publishing (admin-pricing/actions.ts → publishBenchmarkAction):
 *    const level = await evaluateApprovalRequirement('BenchmarkPublish', 0, globalPercent)
 *    record.approvalLevel = level; record.status = level ? 'pending' : 'approved'
 */
export async function evaluateApprovalRequirement(
  entityType: 'Order' | 'Deal' | 'BenchmarkPublish',
  amount?: number,
  deviationPercent?: number
): Promise<string | null> {
  // بردار همهی قوانین فعال برای این نوع موجودیت، مرتب از بالاترین threshold
  const rules = await prisma.approvalRule.findMany({
    where: { entityType, isActive: true },
    orderBy: { thresholdValue: 'desc' },
  })

  let highestLevel: string | null = null

  for (const rule of rules) {
    let matches = false

    if (rule.conditionType === 'amount' && amount !== undefined) {
      matches = amount >= rule.thresholdValue
    } else if (rule.conditionType === 'deviation_percent' && deviationPercent !== undefined) {
      matches = Math.abs(deviationPercent) >= rule.thresholdValue
    }

    if (matches) {
      // اگه requiredLevel این قانون بالاتر از چیزی که تا الان دیدیم باشه، جایگزین میشه
      // ترتیب سلسلهمراتب: auto < supervisor < manager < admin
      const hierarchy = ['auto', 'supervisor', 'manager', 'admin']
      const currentRank = highestLevel ? hierarchy.indexOf(highestLevel) : -1
      const ruleRank = hierarchy.indexOf(rule.requiredLevel)

      if (ruleRank > currentRank) {
        highestLevel = rule.requiredLevel
      }
    }
  }

  // اگه بالاترین سطح 'auto' بود، یعنی خودکاره — برمیگردونیم null
  return highestLevel === 'auto' ? null : highestLevel
}
