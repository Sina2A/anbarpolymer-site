# گزارش اصلاحی v5 — گروه ۱۸

**تاریخ:** ۱۴۰۵/۰۶/۱۰ (2026-09-01)  
**آرشیو:** `group-18-price-engine-v5.tar.gz`

---

## تغییرات v5 نسبت به v4

### هدف: تطبیق کامل delta schema با actions.ts و page.tsx

فایل اصلی delta (`prisma-schema-delta-group-18.prisma`) حاوی تعریف اولیه‌ی ۸ مدل بود
که **فقط ApprovalRule** با اکشن‌های واقعی تطبیق کامل داشت. ۷ مدل دیگر فاقد فیلدهایی
بودند که `app-admin-pricing-actions.ts` واقعاً ارسال می‌کرد و `app-admin-pricing-page.tsx`
واقعاً می‌خواند.

---

### جدول مقایسه یک‌به‌یک (قبل از fix2)

| تب | مدل | actions.ts ارسال می‌کند | delta schema داشت | تطبیق |
|---|---|---|---|---|
| ۱ | PriceFormulaRule | gradeId, formulaText, sourceType, manualValue, apiSnapshotValue, isActive | name, baseFormula, transportFactor, insuranceFactor, taxFactor, isActive | ❌ |
| ۲ | WaterfallRule | priority, conditionType, conditionValue, adjustmentType, adjustmentValue, isActive | tierName, discountPercent, priority, isActive | ❌ |
| ۳ | PaymentTermRule | termDays, adjustmentPercent, isActive | termName, downPaymentPct, creditPct, creditDays, adjustmentPct, isActive | ❌ |
| ۴ | VolumeTierRule | minTonnage, adjustmentPercent, storageType, isActive | minQuantity, discountPercent, isActive | ❌ |
| ۵ | MarginGuidance | gradeId, floorPercent, targetPercent, stretchPercent, isActive | gradeId, suggestedMarginPct, note, isActive | ⚠️ |
| ۶ | ApprovalRule | entityType, conditionType, thresholdValue, requiredLevel, isActive | entityType, conditionType, thresholdValue, requiredLevel, isActive | ✅ |
| ۷.۱ | GlobalBenchmarkPrice | gradeId, priceUsd, sourceLabel | gradeId, basePrice, sourceType, manualValue, apiSnapshotValue, isActive | ⚠️ |
| ۷.۳ | BenchmarkPublishRecord | publishedById, mode, globalAdjustPercent, status, approvalLevel, approvedById, approvedAt | gradeId?, oldPrice, newPrice, deviationPercent, status, approvalLevel, publishedById, approvedById, rejectionReason | ⚠️ |

---

### فایل جدید: `prisma-schema-delta-group-18-fix2.prisma`

این فایل فقط **فیلدهای اضافه‌شونده** را تعریف می‌کند (نه کل مدل‌ها).

**۲۳ فیلد در ۷ مدل:**

| مدل | فیلدهای جدید |
|---|---|
| PriceFormulaRule | gradeId?, formulaText, sourceType, manualValue?, apiSnapshotValue? |
| WaterfallRule | conditionType, conditionValue, adjustmentType, adjustmentValue |
| PaymentTermRule | termDays, adjustmentPercent |
| VolumeTierRule | minTonnage, adjustmentPercent, storageType? |
| MarginGuidance | floorPercent, targetPercent, stretchPercent |
| ApprovalRule | ✅ بدون تغییر |
| GlobalBenchmarkPrice | priceUsd, sourceLabel?, effectiveDate |
| BenchmarkPublishRecord | mode, globalAdjustPercent?, detailSnapshot?, approvedAt? |

---

### بررسی actions.ts — اصلاحات

پس از بررسی کامل ۸ تابع CRUD در actions.ts:

**باگ جدی وجود ندارد.** تمام ۱۵ تابع (create × 8، update × 7، delete × 8 — بعضی مدل‌ها فقط create/delete دارن، publish سه تابع جداگانه دارد) به‌درستی کار می‌کنند.

یافته‌های جزئی (نه باگ):
- GlobalBenchmarkPrice و BenchmarkPublishRecord در page.tsx با `as any` کست شده‌اند — با اضافه‌شدن فیلدهای جدید به delta، cast‌ها غیرضروری می‌شوند ولی مشکلی ایجاد نمی‌کنند.
- `approveBenchmarkPublishAction` و `rejectBenchmarkPublishAction` فقط `requirePricingEditAccess()` دارند (admin + pricing edit/full) — بررسی نقش صریح admin ندارند. این رفتار عمدی است چون کارشناس مالی با دسترسی pricing می‌تواند تایید/رد کند.

**هیچ ویرایشی روی actions.ts اعمال نشد** — کد واقعی صحیح است و delta فایل عقب‌افتاده بود.

---

### نحوه استفاده

```
۱. prisma-schema-delta-group-18.prisma  → اعمال کامل (مدل‌های اصلی)
۲. prisma-schema-delta-group-18-fix2.prisma  → فقط فیلدهای جدید به هر مدل اضافه شود
۳. npx prisma migrate dev --name add-group18-fix2
۴. npx prisma generate
```

⚠️ اگر schema deployed شما قبلاً برخی فیلدها را دارد (مثلاً floorPercent در MarginGuidance
یا priceUsd در GlobalBenchmarkPrice)، فقط فیلدهای مفقود را اضافه کنید.

---

## فایل‌های v5

```
NEW FILES/
├── prisma-schema-delta-group-18.prisma        (6.2 KB) — مدل‌های اصلی (بدون تغییر)
├── prisma-schema-delta-group-18-fix2.prisma    (4.5 KB) — ⭐ فیلدهای اضافه‌شونده
├── src-lib-priceEngine.ts                     (2.2 KB) — موتور تایید (بدون تغییر)
├── src-lib-dealDeadlines.ts                   (8.1 KB) — اتصال موتور تایید
├── app-admin-pricing-page.tsx                 (22 KB)  — صفحه بنچمارک (بدون تغییر)
├── app-admin-pricing-actions.ts               (16 KB)  — اکشن‌های بنچمارک (بدون تغییر)
├── app-admin-orders-actions.ts                (5.4 KB) — اتصال موتور تایید + approveOrderAction
├── app-admin-deals-actions.ts                 (4.5 KB) — approveDealAction
├── app-admin-deals-page.tsx                   (32 KB)  — صفحه معاملات ادمین
├── app-my-deals-page.tsx                      (3.4 KB) — لیست معاملات خریدار
├── app-my-deals-[id]-page.tsx                 (5.2 KB) — جزئیات معامله خریدار
├── app-dashboard-page.tsx                     (10 KB)  — ترجمه وضعیت جدید
├── app-my-requests-page.tsx                   (6.2 KB) — ترجمه وضعیت جدید
├── CONNECTIONS-GROUP-18.md                    (4.8 KB) — راهنمای اتصال
├── REPORT-GROUP-18.md                         (11 KB)  — گزارش کلی
├── REPORT-GROUP-18-v4.md                      (2.5 KB) — گزارش v4
└── REPORT-GROUP-18-v5.md                      (این فایل) — گزارش v5
```

**آرشیو:** `group-18-price-engine-v5.tar.gz` (17 فایل، ~47 KB)
