// ==================== سیستم کد خطای اختصاصی ====================
//
// وقتی گیت‌ها throw می‌کنن، صفحه‌ی error.tsx برندشده این کد رو مچ می‌کنه
// و به‌جای صفحه‌ی زشت Next، پیام دوستانه + دکمه‌ی CTA نشون می‌ده.
//
// فرمت کد: [پنل]-[نوع‌مانع]-[مسیر]
//   پنل:   U = کاربر | A = ادمین
//   مانع:  KYC1 (هویت شرکت) | KYC2 (احراز تولیدکننده)
//          ROLE (نقش مدیر) | SECTION (دسترسی بخش)
//
// این فایل سمت کلاینت هم ایمپورت می‌شه (داخل error.tsx) پس:
// هیچ ایمپورتی از prisma یا کد سرور-فقط (server-only) نداشته باش.
// اضافه‌کردن کد جدید = فقط یک ورودی اینجا + set کردن همون کد روی خطا.

export const ERROR_CODES = {
  // ── پنل کاربر — مانع احراز هویت ──
  'U-KYC1-PURCHASEREQ': {
    message: 'برای ثبت درخواست خرید، اول باید هویت شرکتت رو تایید کنی.',
    cta: '/verification',
  },
  'U-KYC1-RFQ': {
    message: 'برای ثبت استعلام قیمت (RFQ)، اول باید هویت شرکتت رو تایید کنی.',
    cta: '/verification',
  },
  'U-KYC1-CUSTOMREQ': {
    message: 'برای ثبت درخواست محصول غیرکاتالوگی، اول باید هویت شرکتت رو تایید کنی.',
    cta: '/verification',
  },
  'U-KYC2-LISTING': {
    message: 'برای ثبت آگهی فروش، باید احراز تولیدکننده (پروانه بهره‌برداری) رو کامل کنی.',
    cta: '/verification',
  },

  // ── پنل ادمین — نقش مدیر ──
  'A-ROLE-KYC': {
    message: 'ویرایش کامل پرونده‌ی احراز هویت فقط برای نقش مدیره.',
    cta: '/admin-kyc',
  },
  'A-ROLE-LOGS': {
    message: 'مدیریت و پاکسازی لاگ‌ها فقط برای نقش مدیره.',
    cta: '/admin-logs',
  },
  'A-ROLE-DEALS': {
    message: 'قوانین معامله و دستور پرداخت فقط برای مدیر یا کارشناس مجازه.',
    cta: '/admin-deals',
  },
  'A-ROLE-USERS': {
    message: 'تنظیمات سیستمی کاربران فقط برای نقش مدیره.',
    cta: '/admin-users',
  },

  // ── پنل ادمین — دسترسی بخش (Section) ──
  'A-SECTION-ARTICLES': {
    message: 'برای مدیریت مقالات و اخبار باید دسترسی بخش «مقالات» رو داشته باشی.',
    cta: '/my-tasks',
  },
  'A-SECTION-CONTACT': {
    message: 'برای مدیریت پیام‌های تماس با ما باید دسترسی بخش «پیام‌ها» رو داشته باشی.',
    cta: '/my-tasks',
  },
  'A-SECTION-SUPPORT': {
    message: 'برای رسیدگی به تیکت‌ها باید دسترسی بخش «پشتیبانی» رو داشته باشی.',
    cta: '/my-tasks',
  },
  'A-SECTION-GRADES': {
    message: 'برای ویرایش گریدها باید دسترسی بخش «گریدها» رو داشته باشی.',
    cta: '/my-tasks',
  },
  'A-SECTION-CUSTOMRFQ': {
    message: 'برای رسیدگی به درخواست‌های غیرکاتالوگی باید دسترسی بخش رو داشته باشی.',
    cta: '/my-tasks',
  },
  'A-SECTION-PRICING': {
    message: 'برای مدیریت بنچمارک قیمت باید دسترسی بخش «بنچمارک قیمت» رو داشته باشی.',
    cta: '/my-tasks',
  },
} as const

export type ErrorCodeKey = keyof typeof ERROR_CODES

/**
 * خطای دسترسی ادمین — معادل KycRequiredError برای پنل ادمین.
 * چون این فایل هیچ ایمپورت سروری نداره، هم توی actions سرور throw می‌شه
 * هم توی error.tsx کلاینت مچ می‌شه.
 *
 * digest تنها فیلدیه که Next از سرور به کلاینت می‌رسونه (بقیه در build
 * تولیدی redact می‌شن)، پس کد رو همیشه اونجا هم می‌ذاریم.
 *
 * @example throw new AccessDeniedError('A-SECTION-ARTICLES')
 */
export class AccessDeniedError extends Error {
  code: ErrorCodeKey
  digest: string

  constructor(code: ErrorCodeKey, overrideMessage?: string) {
    super(overrideMessage ?? ERROR_CODES[code].message)
    this.name = 'AccessDeniedError'
    this.code = code
    this.digest = code
  }
}

// ── مچ پیام‌های legacy که هنوز کد ندارن ──
// برای خطاهایی که از قبل throw می‌شدن و هنوز کد روشون ست نشده، با متن فارسی مچ
// می‌کنیم تا error.tsx بتونه کد درست رو نشون بده. تا وقتی قدم ۳ همه‌جا کد ست کنه.
const LEGACY_MATCHES: [string, ErrorCodeKey][] = [
  // admin-kyc/[companyId]/actions.ts — requireAdmin کپی‌نشده اینجا، ولی پیامش:
  ['این بخش (ویرایش کامل پرونده‌ی احراز هویت)', 'A-ROLE-KYC'],
  ['شما به بخش مقالات', 'A-SECTION-ARTICLES'],
  ['شما به بخش پیام', 'A-SECTION-CONTACT'],
  ['شما به بخش پشتیبانی', 'A-SECTION-SUPPORT'],
  ['دسترسی ویرایش گریدها', 'A-SECTION-GRADES'],
]

// کد عمومی وقتی هیچ‌کد شناخته‌شده‌ای روی خطا نبود
const GENERIC_CODE = 'GENERIC'
const GENERIC = {
  message: 'مشکلی پیش اومد. لطفاً دوباره تلاش کن، یا اگه دوباره دیدیش با پشتیبانی تماس بگیر.',
  cta: '/support',
}

// الگوی کد معتبر: مثل U-KYC1-PURCHASEREQ یا A-SECTION-GRADES
const CODE_PATTERN = /^[UA]-[A-Z0-9]+-[A-Z]+$/

export interface ResolvedError {
  code: string
  message: string
  cta: string
}

/**
 * کد خطا رو از exception استخراج می‌کنه — اول از فیلد code، بعد digest،
 * بعد مچ با پیام legacy، و در آخر عمومی. برای استفاده در error.tsx و
 * هر جایی که می‌خواد پیام برندشده نشون بده.
 */
export function resolveErrorCode(error: unknown): ResolvedError {
  const err = (error ?? {}) as { code?: string; digest?: string; message?: string }

  // ۱) فیلد code صریح (کلاس‌های جدید خطا)
  if (err.code && err.code in ERROR_CODES) {
    const info = ERROR_CODES[err.code as ErrorCodeKey]
    return { code: err.code, message: info.message, cta: info.cta }
  }

  // ۲) digest — Next این رو روی خطا سرور حفظ می‌کنه و تا کلاینت می‌رسه؛
  //    کلاس‌های ما digest رو همون کد می‌ذارن تا در پرواز (پیش‌فرض) هم بشه
  if (err.digest && err.digest in ERROR_CODES) {
    const info = ERROR_CODES[err.digest as ErrorCodeKey]
    return { code: err.digest, message: info.message, cta: info.cta }
  }

  // ۳) مچ با پیام فارسی legacy
  const msg = err.message ?? ''
  for (const [text, code] of LEGACY_MATCHES) {
    if (msg.includes(text)) {
      const info = ERROR_CODES[code]
      return { code, message: info.message, cta: info.cta }
    }
  }

  // ۴) digest بدون کد شناخته‌شده ولی با قالب کد → خودش میشه کد نمایشی
  if (err.digest && CODE_PATTERN.test(err.digest)) {
    return { code: err.digest, message: GENERIC.message, cta: GENERIC.cta }
  }

  // ۵) عمومی
  return { code: GENERIC_CODE, message: GENERIC.message, cta: GENERIC.cta }
}
