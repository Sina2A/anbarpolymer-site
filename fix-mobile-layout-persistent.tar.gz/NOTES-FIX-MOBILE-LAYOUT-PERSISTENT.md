# رفع نهایی — چیدمان موبایل دوستونه‌ی فشرده (contact / warehouses / about) + Overflow جدول

## خلاصه‌ی علت ریشه‌ای — هیچ‌کدام از ۴ فرضیه‌ی گزارش درست نبود

فرضیه‌های ۱ تا ۳ با **پارس واقعی CSS کامپایل‌شده** (نه `grep`) رد شدند:

- **فرضیه ۱ (CSS قدیمی روی سرور):** رد شد. فایل کامپایل‌شده‌ی `.next/static/chunks/*.css` با `postcss` پارس شد؛ قوانین `@media (max-width:899px)` برای `.contact-grid` و `.wh-layout` واقعاً حاضر و درست‌اند.
- **فرضیه ۲ (براکت ناقص در globals.css):** رد شد. پارس موفقِ `postcss` روی کل فایل کامپایل‌شده یعنی براکت‌ها کاملاً متوازن‌اند (در صورت عدم توازن، پارسر خطا می‌داد).
- **فرضیه ۳ (ناهماهنگی breakpoint):** رد شد. breakpoint دقیقاً `899px` است و در viewport و CSS هماهنگ.
- **فرضیه ۴ (تغییر سراسری روی about):** نزدیک به واقعیت (یک استایل مشترک)، ولی منبعش `overflow-x:clip` نبود.

### علت واقعی: استایل inline در JS که هیچ ابزار CSS نمی‌بیند

`pageWrapStyle` در `src/lib/styles/shared.ts` یک **flex ردیفی** است
(`display:flex` بدون `flex-direction`) — برای چیدمان «سایدبار + محتوا»ی پنل ادمین طراحی شده و حدود ۳۴ مصرف‌کننده دارد.

در `/contact` و `/warehouses` این استایل داخل `mainStyle` اسپرد می‌شد **بدون** `flexDirection:'column'`.
نتیجه: `<main>` یک **flex-row** می‌ماند و بلوک هیرو را **کنارِ** گرید (`.contact-grid` / `.wh-layout`)
می‌چیند — در هر عرضی. مدیاکوئریِ ۸۹۹px فقط ستون‌های **داخلیِ** گرید را جمع می‌کند،
نه ردیفِ والد را؛ برای همین سه «رفع» قبلی که فقط CSS بودند بی‌اثر ماندند.

**مدرک قطعی:** صفحه‌ی `/warehouses/[id]` که این باگ را **ندارد**، تنها تفاوتش این است که
`mainStyle`‌اش از قبل `flexDirection:'column'` داشت.

### مورد about (باگ جدا و قدیمی)

`problemGridStyle` در `src/app/about/page.tsx` یک گرید inline با
`gridTemplateColumns:'1fr 1.15fr'` و **بدون هیچ breakpoint** بود؛ برای همین هیچ‌وقت در موبایل
جمع نمی‌شد. ربطی به تغییرات امروز نداشت.

### مورد Overflow جدول در warehouses/[id]

رَپرِ جدول از قبل `overflowX:'auto'` داشت، ولی کافی نبود: `<section>`ِ والد یک
flex-item داخل `<main>`ِ ستونی بود و `min-width:auto` (پیش‌فرض) داشت؛ حداقلِ خودکارِ
محتوای flex، سکشن را از عرض ویوپورت پهن‌تر می‌کرد، پس رَپر هیچ‌وقت سرریز نمی‌کرد و
گاردِ سراسریِ `html,body{overflow-x:clip}` ستون آخر را می‌بُرید.

## تغییرات اعمال‌شده

| فایل | تغییر |
|---|---|
| `src/app/contact/page.tsx` | افزودن `flexDirection:'column'` به `mainStyle` |
| `src/app/warehouses/page.tsx` | افزودن `flexDirection:'column'` به `mainStyle` |
| `src/app/warehouses/[id]/page.tsx` | افزودن `minWidth:0` به `sectionStyle` (اجازه‌ی سرریزِ درستِ رَپرِ جدول) |
| `src/app/about/page.tsx` | حذف `gridTemplateColumns` inline از `problemGridStyle` + افزودن کلاس `about-problem-grid` |
| `src/app/globals.css` | افزودن کلاس `.about-problem-grid` (دسکتاپ `1fr 1.15fr` / زیر ۸۹۹px تک‌ستون) |

## راستی‌آزمایی (با روشی غیر از grep)

1. `npx tsc --noEmit` → بدون خطا.
2. `npx next build` → موفق.
3. **پارس CSS کامپایل‌شده با `postcss`** روی `.next/static/chunks/*.css`
   (پارسِ موفق = توازنِ براکت‌ها):
   - `.contact-grid` → BASE `340px 1fr` / `@899` `1fr` ✅
   - `.wh-layout` → BASE `1fr 380px` / `@899` `1fr` ✅
   - `.about-problem-grid` → BASE `1fr 1.15fr` / `@899` `1fr` ✅

## نکته برای آینده

اگر صفحه‌ای `pageWrapStyle` را داخل `mainStyle` اسپرد می‌کند و چیدمان تک‌ستونی می‌خواهد،
حتماً باید `flexDirection:'column'` را هم اضافه کند (چون `pageWrapStyle` ذاتاً ردیفی است).
هر ۴ مصرف‌کننده‌ی فعلی (`contact`, `warehouses`, `warehouses/[id]`, `rfq-public`) بررسی و درست شدند.
