import { notFound } from 'next/navigation'
import prisma from '@/lib/prisma'
import { SPEC_GROUPS, SPEC_FIELD_BY_KEY, parseSpecs } from '@/lib/gradeSpecs'
import { findSimilarGrades } from '@/lib/gradeMatch'
import CurrencyTicker from '@/components/CurrencyTicker'
import PublicHeader from '@/components/PublicHeader'
import Footer from '@/components/Footer'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { cardStyle as sharedCardStyle, badgeStyle, emptyStateStyle } from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

export default async function GradeDetailPage({
  params,
}: {
  params: Promise<{ code: string }>
}) {
  const { code } = await params
  const decoded = decodeURIComponent(code)

  const grade = await prisma.grade.findUnique({
    where: { code: decoded },
    include: { documents: { orderBy: { createdAt: 'desc' } } },
  })
  if (!grade || !grade.isActive) notFound()

  // specsJson → دسته‌بندی‌شده بر اساس SPEC_GROUPS
  const specs = parseSpecs(grade.specsJson)
  const specEntries = Object.entries(specs) // [key, value][]
  const groupedSpecs = SPEC_GROUPS.map((g) => ({
    group: g,
    fields: specEntries
      .filter(([k]) => SPEC_FIELD_BY_KEY[k]?.group === g.key)
      .map(([k, v]) => ({ field: SPEC_FIELD_BY_KEY[k], value: v })),
  })).filter((g) => g.fields.length > 0)

  // گریدهای مشابه
  const similar = await findSimilarGrades(grade.id, 6)

  // ۶.۱ — امتیاز معامله‌های این گرید: میانگین rating از Reviewهایی که
  // روی معامله‌های همین گرید ثبت شده‌اند (Review → Deal → MaterialListing → Grade).
  // فقط aggregate عددی — هیچ رکورد Userی به payload عمومی صفحه serialize نمی‌شه.
  const ratingAgg = await prisma.review.aggregate({
    _avg: { rating: true },
    _count: true,
    where: { deal: { materialListing: { gradeId: grade.id } } },
  })
  const ratingAvg = ratingAgg._avg.rating // null یعنی هنوز هیچ امتیازی ثبت نشده
  const ratingCount = ratingAgg._count
  const fullStars = ratingAvg != null ? Math.round(ratingAvg) : 0

  // ۶.۴ — آیا این گرید توی انبارها موجوده؟
  // این فراخوانی فقط برای نمایش دکمه‌ی هوشمند اف_limits نیست — نشون می‌دهیم
  // کاربر مستقیم از این صفحه می‌تونه سفارش بده یا RFQ بزنه.
  const stock = await prisma.warehouseStock.findFirst({
    where: { gradeId: grade.id, quantityTon: { gt: 0 } },
  })

  return (
    <>
      <CurrencyTicker />
      <PublicHeader activePage="/grades" />

      <section>
        <div className="wrap">
          {/* مسیر */}
          <div style={breadcrumbStyle}>
            <a href="/grades">گریدها</a> &nbsp;/&nbsp; <span>{grade.code}</span>
          </div>

          {/* ---------- هدر ---------- */}
          <div style={headerCardStyle}>
            <div style={thumbWrapStyle}>
              {grade.imageUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={grade.imageUrl} alt={grade.code} style={thumbImgStyle} />
              ) : (
                <div style={thumbPlaceholderStyle}>بدون تصویر</div>
              )}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={codeStyle}>{grade.code}</div>
              <div style={producerStyle}>{grade.producer}</div>
              <div style={categoryBadgeStyle}>{grade.category}</div>
              {/* ۶.۱ — بلوک امتیاز: میانگین Reviewهای معامله‌های همین گرید */}
              <div style={ratingWrapStyle}>
                <span style={ratingStarsStyle} aria-label={`امتیاز ${ratingAvg != null ? Math.round(ratingAvg * 10) / 10 : 0} از ۵`}>
                  {[1, 2, 3, 4, 5].map((i) => (
                    <span key={i} style={{ color: i <= fullStars ? colors.orange : colors.borderStrong }}>
                      ★
                    </span>
                  ))}
                </span>
                {ratingCount > 0 && ratingAvg != null ? (
                  <span style={ratingTextStyle}>
                    {(Math.round(ratingAvg * 10) / 10).toLocaleString('fa-IR')} از ۵ —{' '}
                    {ratingCount.toLocaleString('fa-IR')} امتیاز ثبت‌شده از معامله‌های این گرید
                  </span>
                ) : (
                  <span style={ratingTextStyle}>هنوز امتیازی برای معامله‌های این گرید ثبت نشده است</span>
                )}
              </div>
              {grade.description && (
                <p style={descStyle}>{grade.description}</p>
              )}
              {grade.datasheetUrl && (
                <a
                  href={grade.datasheetUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-sm"
                  style={{ marginTop: 12, display: 'inline-block', textDecoration: 'none' }}
                >
                  دانلود دیتاشیت (PDF) ↗
                </a>
              )}
              {/* ۶.۴ — دکمه‌ی هوشمند بر اساس موجودی انبار */}
              <div style={{ marginTop: 16 }}>
                {stock ? (
                  <a
                    href="/purchase-requests"
                    style={purchaseBtnStyle}
                  >
                    ➕ افزودن به درخواست خرید ({grade.code})
                  </a>
                ) : (
                  <div style={emptyStockStyle}>
                    <div style={{ marginBottom: 8 }}>📦 موجودی فعلی این محصول صفر می‌باشد، در صورت نیاز درخواست قیمت بدهید.</div>
                    <a href={`/custom-request?grade=${encodeURIComponent(grade.code)}`} style={rfqLinkStyle}>
                      درخواست استعلام قیمت برای {grade.code} →
                    </a>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* ---------- مشخصات کلیدی ---------- */}
          <h3 style={sectionTitleStyle}>مشخصات کلیدی</h3>
          <div style={keyGridStyle}>
            <KeyCell label="MFI" value={grade.mfi != null ? `${grade.mfi} g/10min` : '—'} sub={grade.mfiTestCondition || undefined} />
            <KeyCell label="چگالی" value={grade.density != null ? `${grade.density} g/cm³` : '—'} />
            <KeyCell label="کاربرد" value={grade.applicationType || '—'} />
            <KeyCell label="خانواده پلیمری" value={grade.polymerFamily || '—'} />
            <KeyCell label="کشور مبدا" value={grade.originCountry || '—'} />
            <KeyCell label="نوع بسته‌بندی" value={grade.packagingType || '—'} />
          </div>

          {/* ---------- مشخصات فنی تکمیلی ---------- */}
          {groupedSpecs.length > 0 ? (
            <>
              <h3 style={sectionTitleStyle}>مشخصات فنی تکمیلی</h3>
              {groupedSpecs.map(({ group, fields }) => (
                <div key={group.key} style={{ marginBottom: 20 }}>
                  <div style={groupLabelStyle}>{group.label}</div>
                  <table className="g-table">
                    <thead>
                      <tr>
                        <th>پارامتر</th>
                        <th>مقدار</th>
                        <th>واحد</th>
                        <th>استاندارد</th>
                      </tr>
                    </thead>
                    <tbody>
                      {fields.map(({ field, value }) => (
                        <tr key={field.key}>
                          <td>{field.label}</td>
                          <td style={{ fontWeight: 700, direction: 'ltr', textAlign: 'right' }}>{value}</td>
                          <td style={{ color: colors.textMuted, fontSize: fontSize.xs }}>{field.unit || '—'}</td>
                          <td style={{ color: colors.textMuted, fontSize: fontSize.xs, fontFamily: 'monospace' }}>{field.standard}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ))}
            </>
          ) : (
            <div style={emptySpecsStyle}>برای این گرید مشخصات تکمیلی ثبت نشده است.</div>
          )}

          {/* ---------- اسناد فنی قابل دانلود ---------- */}
          {grade.documents.length > 0 && (
            <>
              <h3 style={sectionTitleStyle}>اسناد فنی</h3>
              <div style={docsGridStyle}>
                {grade.documents.map((doc) => (
                  <a
                    key={doc.id}
                    href={doc.fileUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    style={docCardStyle}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                      <span style={docIconStyle}>PDF</span>
                      <span style={docTypeBadgeStyle}>{DOC_TYPE_LABELS[doc.docType] ?? doc.docType}</span>
                    </div>
                    <div style={{ fontSize: fontSize.base, fontWeight: 700, color: colors.textPrimary }}>{doc.title}</div>
                    <div style={{ fontSize: fontSize.xs, color: colors.textMuted, marginTop: 4, fontFamily: 'monospace' }}>
                      {new Date(doc.createdAt).toLocaleDateString('fa-IR')}
                    </div>
                  </a>
                ))}
              </div>
            </>
          )}

          {/* ---------- گریدهای مشابه ---------- */}
          {similar.length > 0 && (
            <>
              <h3 style={sectionTitleStyle}>گریدهای مشابه</h3>
              <p style={{ fontSize: fontSize.xs, color: colors.textMuted, marginBottom: spacing.md }}>
                بر اساس خانواده پلیمری، کاربرد، MFI و چگالی — پیشنهاد خودکار، نه توصیه‌ی خرید.
              </p>
              <div style={similarGridStyle}>
                {similar.map((g) => (
                  <a
                    key={g.id}
                    href={`/grades/${encodeURIComponent(g.code)}`}
                    style={similarCardStyle}
                  >
                    <div style={{ fontSize: fontSize.base, fontWeight: 800, color: colors.textPrimary }}>{g.code}</div>
                    <div style={{ fontSize: fontSize.xs, color: colors.textSecondary, marginTop: 2 }}>{g.producer}</div>
                    <div style={{ fontSize: fontSize.xs, color: colors.textMuted }}>{g.category}</div>
                  </a>
                ))}
              </div>
            </>
          )}
        </div>
      </section>

      <Footer />
    </>
  )
}

function KeyCell({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div style={keyCellStyle}>
      <div style={keyLabelStyle}>{label}</div>
      <div style={keyValueStyle}>{value}</div>
      {sub && <div style={keySubStyle}>{sub}</div>}
    </div>
  )
}

// ---------- style objects ----------

const breadcrumbStyle: React.CSSProperties = {
  fontSize: fontSize.xs,
  color: colors.textMuted,
  marginBottom: spacing.lg,
}

const headerCardStyle: React.CSSProperties = {
  display: 'flex',
  flexWrap: 'wrap',
  gap: spacing.xl,
  padding: spacing.xl,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
  background: colors.bgCard,
  marginBottom: 28,
}

const thumbWrapStyle: React.CSSProperties = {
  width: 220,
  height: 180,
  flexShrink: 0,
  background: colors.neutralBg,
  borderRadius: radius.lg,
  overflow: 'hidden',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
}

const thumbImgStyle: React.CSSProperties = { width: '100%', height: '100%', objectFit: 'cover' }
const thumbPlaceholderStyle: React.CSSProperties = { color: colors.textMuted, fontSize: fontSize.xs }

const codeStyle: React.CSSProperties = { fontSize: fontSize.xxl, fontWeight: 900, color: colors.textPrimary }
const producerStyle: React.CSSProperties = { fontSize: fontSize.base, color: colors.textSecondary, marginTop: spacing.xs }
const categoryBadgeStyle: React.CSSProperties = {
  ...badgeStyle('neutral'),
  marginTop: spacing.sm,
}

// ۶.۱ — بلوک امتیاز
const ratingWrapStyle: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: spacing.sm,
  marginTop: spacing.md,
  flexWrap: 'wrap',
}
const ratingStarsStyle: React.CSSProperties = { fontSize: fontSize.md, letterSpacing: 1, lineHeight: 1, direction: 'ltr' }
const ratingTextStyle: React.CSSProperties = { fontSize: fontSize.xs, color: colors.textMuted }

const descStyle: React.CSSProperties = {
  marginTop: spacing.md,
  fontSize: fontSize.base,
  color: colors.neutralText,
  lineHeight: 1.7,
  whiteSpace: 'pre-wrap',
}

const sectionTitleStyle: React.CSSProperties = {
  fontSize: fontSize.lg,
  fontWeight: 800,
  color: colors.textPrimary,
  marginBottom: spacing.md,
  marginTop: spacing.sm,
}

const keyGridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))',
  gap: spacing.md,
  marginBottom: 28,
}

const keyCellStyle: React.CSSProperties = {
  padding: `${spacing.md}px 14px`,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
  background: colors.bgHover,
}

const keyLabelStyle: React.CSSProperties = { fontSize: fontSize.xs, color: colors.textMuted, marginBottom: spacing.xs }
const keyValueStyle: React.CSSProperties = { fontSize: fontSize.base, fontWeight: 700, color: colors.textPrimary }
const keySubStyle: React.CSSProperties = { fontSize: fontSize.xs, color: colors.textMuted, marginTop: 2 }

const groupLabelStyle: React.CSSProperties = {
  fontSize: fontSize.xs,
  fontWeight: 700,
  color: colors.orange,
  marginBottom: spacing.sm,
}

const emptySpecsStyle: React.CSSProperties = {
  ...emptyStateStyle,
  padding: spacing.xl,
  border: `1px dashed ${colors.borderStrong}`,
  borderRadius: radius.lg,
  marginBottom: 28,
}

const similarGridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))',
  gap: spacing.md,
}

const similarCardStyle: React.CSSProperties = {
  display: 'block',
  padding: `${spacing.md}px 14px`,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
  background: colors.bgCard,
  textDecoration: 'none',
}

// ۶.۳ — اسناد فنی قابل دانلود
const docsGridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))',
  gap: spacing.md,
  marginBottom: 28,
}

const docCardStyle: React.CSSProperties = {
  display: 'block',
  padding: `${spacing.md}px 14px`,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
  background: colors.bgCard,
  textDecoration: 'none',
  transition: 'border-color .15s',
}

const docIconStyle: React.CSSProperties = {
  fontSize: 9,
  fontWeight: 800,
  color: '#fff',
  background: '#c0392b',
  borderRadius: 3,
  padding: '1px 4px',
  fontFamily: 'monospace',
  letterSpacing: 0.5,
}

const docTypeBadgeStyle: React.CSSProperties = {
  ...badgeStyle('info'),
  fontWeight: 700,
}

const DOC_TYPE_LABELS: Record<string, string> = {
  tds: 'TDS',
  sds: 'SDS',
  coa: 'COA',
  certificate: 'گواهی',
  other: 'سایر',
}

// ۶.۴ — استایل‌های دکمه‌ی هوشمند
const purchaseBtnStyle: React.CSSProperties = {
  display: 'inline-block',
  background: colors.navy,
  color: '#fff',
  border: 'none',
  borderRadius: radius.md,
  padding: '10px 20px',
  fontSize: fontSize.base,
  fontWeight: 700,
  textDecoration: 'none',
  cursor: 'pointer',
  fontFamily: 'inherit',
}

const emptyStockStyle: React.CSSProperties = {
  padding: '14px 18px',
  background: colors.bgHover,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
  fontSize: fontSize.base,
  color: colors.textMuted,
}

const rfqLinkStyle: React.CSSProperties = {
  display: 'inline-block',
  background: colors.orange,
  color: '#fff',
  border: 'none',
  borderRadius: radius.md,
  padding: '8px 16px',
  fontSize: fontSize.xs,
  fontWeight: 700,
  textDecoration: 'none',
  cursor: 'pointer',
  fontFamily: 'inherit',
}
