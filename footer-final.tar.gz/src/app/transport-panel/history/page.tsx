import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import LogisticsNav from '@/components/LogisticsNav'
import PanelHeader from '@/components/PanelHeader'
import Footer from '@/components/Footer'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'

export const dynamic = 'force-dynamic'

// ⚠️ این صفحه فعلاً فقط اسکلت/چیدمانه — هیچ کوئری Deal واقعی‌ای نداره.
// تنها کوئری Prisma اینجا «گیت دسترسی» شرکته که عیناً از /transport-panel فعلی کپی شده.
// قرار نهایی (برای مرحله‌ی بعد): این صفحه باید همه‌ی رکوردهای تاریخی همون شرکت رو
// نشون بده، نه فقط چندتای آخر — یعنی بدون take/slice، احتمالاً با صفحه‌بندی.
const PLACEHOLDER_ROWS = Array.from({ length: 10 }, (_, i) => ({
  n: i + 1,
  v1: `مقدار${i + 1}`,
  v2: `مقدار${i + 1}`,
  v3: `مقدار${i + 1}`,
  v4: `مقدار${i + 1}`,
  v5: `مقدار${i + 1}`,
}))

export default async function TransportHistoryPage() {
  const user = await getCurrentUser()

  const company = await prisma.transportCompany.findUnique({
    where: { managerUserId: user.id },
  })

  if (!company) {
    return (
      <div style={pageStyle}>
        <div style={cardStyle}>
          <h1 style={{ fontSize: fontSize.lg, fontWeight: 800, marginBottom: spacing.sm, color: colors.textPrimary }}>
            پنل شرکت حمل‌ونقل — دسترسی ندارید
          </h1>
          <p style={{ fontSize: fontSize.base, color: colors.neutralText }}>این حساب به هیچ شرکت حمل‌ونقلی وصل نیست. با پشتیبانی انبار پلیمر تماس بگیرید.</p>
        </div>
      </div>
    )
  }

  // گیت دسترسی پنل — جدای از خودِ قرارداد حمل. اگه مدیر دسترسی رو قطع کرده باشه،
  // شرکت اصلاً محتوای پنل رو نمی‌بینه (عیناً همون منطق /transport-panel فعلی).
  if (!company.logisticsAccessEnabled) {
    return (
      <div style={pageStyle}>
        <div style={cardStyle}>
          <h1 style={{ fontSize: fontSize.lg, fontWeight: 800, marginBottom: spacing.sm, color: colors.textPrimary }}>
            پنل شرکت حمل‌ونقل — دسترسی غیرفعال
          </h1>
          <p style={{ fontSize: fontSize.base, color: colors.neutralText }}>
            دسترسی پنل حمل‌ونقل برای <b style={{ color: colors.textPrimary }}>{company.name}</b> در حال حاضر غیرفعاله. برای فعال‌شدن با پشتیبانی انبار پلیمر تماس بگیرید.
          </p>
        </div>
      </div>
    )
  }

  return (
    <>
      <PanelHeader currentUserName={company.name} />
      <div style={pageStyle}>
      <div className="admin-page-wrap">
        <LogisticsNav currentUserName={company.name} activeSection="history" />
        <div style={{ flex: 1, minWidth: 0 }}>
          <h1 style={{ fontSize: fontSize.xxl, fontWeight: 800, marginBottom: spacing.sm, color: colors.textPrimary }}>حمل‌ونقل‌های گذشته</h1>
          <p style={{ fontSize: fontSize.base, color: colors.textMuted, marginBottom: 20 }}>
            <b style={{ color: colors.textSecondary, fontWeight: 700 }}>{company.name}</b>
            {' — '}
            تاریخچه‌ی کامل محموله‌های این شرکت حمل‌ونقل
          </p>

          <div style={tableCardStyle}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12.5 }}>
              <thead>
                <tr style={{ background: colors.bgHover, color: colors.textMuted, textAlign: 'right' }}>
                  <th style={thStyle}>ردیف</th>
                  <th style={thStyle}>متغیر ۱</th>
                  <th style={thStyle}>متغیر ۲</th>
                  <th style={thStyle}>متغیر ۳</th>
                  <th style={thStyle}>متغیر ۴</th>
                  <th style={thStyle}>متغیر ۵</th>
                </tr>
              </thead>
              <tbody>
                {PLACEHOLDER_ROWS.map((row) => (
                  <tr key={row.n} style={{ borderTop: `1px solid ${colors.borderSubtle}` }}>
                    <td style={{ ...tdStyle, fontFamily: 'monospace', color: colors.textMuted }}>{row.n}</td>
                    <td style={tdStyle}>{row.v1}</td>
                    <td style={tdStyle}>{row.v2}</td>
                    <td style={tdStyle}>{row.v3}</td>
                    <td style={tdStyle}>{row.v4}</td>
                    <td style={tdStyle}>{row.v5}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
      <Footer />
    </>
  )
}

const pageStyle: React.CSSProperties = { minHeight: '100vh', background: colors.bgPage, padding: `${spacing.xxl}px ${spacing.xl}px`, fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl' }
const cardStyle: React.CSSProperties = { border: `1px solid ${colors.borderSubtle}`, borderRadius: radius.lg, padding: 18, marginBottom: spacing.lg, background: colors.bgCard, boxShadow: '0 1px 4px rgba(27,30,36,.05)', maxWidth: 780, margin: '0 auto' }
const tableCardStyle: React.CSSProperties = { border: `1px solid ${colors.borderSubtle}`, borderRadius: radius.lg, background: colors.bgCard, boxShadow: '0 1px 4px rgba(27,30,36,.05)', overflow: 'hidden' }
const thStyle: React.CSSProperties = { padding: '10px 12px', fontWeight: 700, fontSize: fontSize.sm, color: colors.textMuted }
const tdStyle: React.CSSProperties = { padding: '9px 12px', color: colors.textPrimary }
