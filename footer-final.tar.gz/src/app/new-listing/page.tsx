import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getUserKycLevel } from '@/lib/kyc'
import { isUserRestricted } from '@/lib/dealDeadlines'
import UserNav from '@/components/UserNav'
import PanelHeader from '@/components/PanelHeader'
import Footer from '@/components/Footer'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { cardStyle as sharedCardStyle, btnPrimaryStyle, inputStyle as sharedInputStyle, selectStyle as sharedSelectStyle, labelStyle as sharedLabelStyle } from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

type SearchParams = Promise<Record<string, string | string[] | undefined>>

function one(v: string | string[] | undefined): string | undefined {
  if (Array.isArray(v)) return v[0]
  return v
}

/** پیام فارسیِ کدهای خطای api/material-listings — روی فرم نمایش داده می‌شه */
function errorMessage(code: string): string | null {
  const map: Record<string, string> = {
    kyc: 'برای ثبت آگهی باید احراز تولیدکننده (پروانه بهره‌برداری) تکمیل و تایید بشه.',
    restricted: 'به‌خاطر نقض مهلت‌ها، تا پایان دوره‌ی محدودیت نمی‌تونی آگهی جدید ثبت کنی.',
    'no-grade': 'گرید انتخاب‌شده معتبر نیست.',
    'bad-quantity': 'مقدار باید بیشتر از صفر باشه.',
    'no-location': 'استان و شهر بار رو کامل وارد کن.',
    'no-specs': 'مشخصات بسته‌بندی و کیفیت مواد رو کامل کن.',
    'bad-price': 'قیمت پیشنهادی باید بیشتر از صفر باشه.',
    'bad-weight': 'وزن خالص روی قبض باید بیشتر از صفر باشه.',
    'no-ticket-date': 'تاریخ قبض باسکول رو وارد کن.',
    'bad-ticket-date': 'تاریخ قبض معتبر نیست.',
    'ticket-not-today': 'طبق قواعد سایت، تاریخ قبض باسکول باید همون امروز باشه.',
    'no-ticket': 'عکس قبض باسکول اجباریه — بدون اون آگهی ثبت نمی‌شه.',
    'too-big': 'حجم عکس قبض بیش از حد مجازه (۲۰ مگابایت).',
    'not-image': 'فایل قبض باید عکس JPG یا PNG یا WebP باشه.',
    'no-request': 'درخواست خرید موردنظر پیدا نشد.',
    'request-closed': 'این درخواست خرید بسته شده.',
    'request-expired': 'این درخواست خرید منقضی شده.',
  }
  return map[code] ?? null
}
export default async function NewListingPage({
  searchParams,
}: {
  searchParams: SearchParams
}) {
  const sp = await searchParams
  const user = await getCurrentUser()
  const requestId = one(sp.request) || null
  const errorCode = one(sp.error) || null

  const kycLevel = await getUserKycLevel(user.id)
  const restriction = await isUserRestricted(user.id)

  // اگه آگهی در پاسخ به درخواست خرید باشه، فرم از روی درخواست پیش‌پر می‌شه
  const request = requestId
    ? await prisma.purchaseRequest.findUnique({
        where: { id: requestId },
        include: { grade: true },
      })
    : null

  const grades = await prisma.grade.findMany({
    where: { isActive: true },
    orderBy: { code: 'asc' },
    select: { id: true, code: true, producer: true, category: true },
  })

  // تاریخ امروز به وقت محلی — مقدار پیش‌فرض input تاریخ (قبض باید مال امروز باشه)
  const t = new Date()
  const todayStr = `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(t.getDate()).padStart(2, '0')}`

  const errText = errorCode ? errorMessage(errorCode) : null

  return (
    <>
    <PanelHeader currentUserName={user.companyName} />
    <div style={pageStyle}>
      <div style={{ width: '100%', display: 'flex', gap: 24 }} className="admin-page-wrap">
        <UserNav currentUserName={user.companyName} activeSection="listings" />
        <div style={{ flex: 1, minWidth: 0 }}>
          <h1 style={h1Style}>ثبت آگهی عرضه</h1>
          <p style={subStyle}>
            بارِ خودت رو توی شبکه‌ی عرضه بذار — خریدارها می‌بینن و رزرو می‌کنن
          </p>
          {errText && <div style={errorBannerStyle}>{errText}</div>}

          {request && (
            <div style={requestCardStyle}>
              <div style={{ fontSize: fontSize.base, fontWeight: 800, marginBottom: 6 }}>
                در پاسخ به درخواست خرید #{request.id.slice(0, 8)}
              </div>
              <div style={{ fontSize: fontSize.sm, color: colors.neutralText, display: 'flex', gap: 20, flexWrap: 'wrap' }}>
                <span>گرید: <b>{request.grade.code}</b></span>
                <span>مقدار درخواستی: <b>{request.quantityTon} تن</b></span>
                {request.maxPriceToman && (
                  <span>سقف قیمت خریدار: <b style={{ color: colors.orange }}>{request.maxPriceToman.toLocaleString('fa-IR')} تومان/کیلو</b></span>
                )}
                {request.province && <span>استان: <b>{request.province}</b></span>}
              </div>
              {request.description && (
                <div style={{ fontSize: fontSize.xs, color: colors.textMuted, marginTop: 6, fontStyle: 'italic' }}>
                  {request.description}
                </div>
              )}
            </div>
          )}
          {kycLevel < 2 ? (
            <div style={cardStyle}>
              <b style={{ fontSize: fontSize.md }}>احراز تولیدکننده لازمه</b>
              <p style={noteStyle}>
                ثبت آگهی عرضه فقط برای فروشنده‌های تاییدشده بازه. برای فروش در سیستم،
                باید پروانه بهره‌برداری رو توی بخش احراز هویت بارگذاری کنی و منتظر تایید بمونی.
              </p>
              <a href="/verification" style={linkBtnStyle}>رفتن به احراز هویت</a>
            </div>
          ) : restriction.restricted ? (
            <div style={cardStyle}>
              <b style={{ fontSize: fontSize.md }}>حسابت موقتاً محدوده</b>
              <p style={noteStyle}>
                به‌خاطر نقض مهلت‌های معامله، تا{' '}
                <b>{new Date(restriction.until).toLocaleDateString('fa-IR')}</b>{' '}
                نمی‌تونی آگهی جدید ثبت کنی.
                {restriction.reason ? ` دلیل: ${restriction.reason}` : ''}
              </p>
            </div>
          ) : (
            <form action="/api/material-listings" method="post" encType="multipart/form-data">
              {request && <input type="hidden" name="purchaseRequestId" value={request.id} />}

              <div style={cardStyle}>
                <h3 style={sectionTitleStyle}>مشخصات بار</h3>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
                  <div>
                    <div style={labelStyle}>گرید *</div>
                    <select name="gradeId" required defaultValue={request?.gradeId ?? ''} style={selectStyle}>
                      <option value="">انتخاب گرید…</option>
                      {grades.map((g) => (
                        <option key={g.id} value={g.id}>
                          {g.code} — {g.producer} ({g.category})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <div style={labelStyle}>مقدار (تن) *</div>
                    <input name="quantityTon" type="number" step="0.1" min="0.1" required
                      defaultValue={request ? String(request.quantityTon) : undefined}
                      placeholder="مثلاً ۲۵" style={inputStyle} />
                  </div>
                  <div>
                    <div style={labelStyle}>استان بار *</div>
                    <input name="province" required
                      defaultValue={request?.province ?? ''}
                      placeholder="مثلاً تهران" style={inputStyle} />
                  </div>
                  <div>
                    <div style={labelStyle}>شهر بار *</div>
                    <input name="city" required placeholder="مثلاً فیروزکوه" style={inputStyle} />
                  </div>
                </div>
              </div>
              <div style={cardStyle}>
                <h3 style={sectionTitleStyle}>بسته‌بندی و کیفیت</h3>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
                  <div>
                    <div style={labelStyle}>نوع بسته‌بندی *</div>
                    <input name="packagingType" required
                      placeholder="مثلاً کیسه ۲۵ کیلویی" style={inputStyle} />
                  </div>
                  <div>
                    <div style={labelStyle}>کیفیت بسته‌بندی *</div>
                    <input name="packagingQuality" required
                      placeholder="مثلاً نو / در حد نو" style={inputStyle} />
                  </div>
                  <div>
                    <div style={labelStyle}>کیفیت مواد *</div>
                    <input name="materialQuality" required
                      placeholder="مثلاً virgin / در حد نو / بازیافت" style={inputStyle} />
                  </div>
                  <div>
                    <div style={labelStyle}>قیمت پیشنهادی (تومان/کیلو) *</div>
                    <input name="askingPriceToman" type="number" step="1" min="1" required
                      placeholder="مثلاً ۹۵۰۰۰" style={inputStyle} />
                    {request?.maxPriceToman && (
                      <div style={hintStyle}>
                        سقف قیمت خریدار: {request.maxPriceToman.toLocaleString('fa-IR')} تومان/کیلو
                      </div>
                    )}
                  </div>
                </div>
              </div>
              <div style={cardStyle}>
                <h3 style={sectionTitleStyle}>قبض باسکول — فیلتر اولیه (اجباری)</h3>
                <p style={{ ...noteStyle, marginTop: 0 }}>
                  عکس قبضِ باسکولِ همون امروز رو بارگذاری کن. این اثباتِ نهایی نیست، فقط
                  نشون می‌ده این بار واقعاً موجودیه — بررسی کامل بعداً انجام می‌شه.
                </p>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
                  <div>
                    <div style={labelStyle}>وزن خالص روی قبض (کیلوگرم) *</div>
                    <input name="weighbridgeNetWeightKg" type="number" step="1" min="1" required
                      placeholder="مثلاً ۲۴۸۰۰" style={inputStyle} />
                  </div>
                  <div>
                    <div style={labelStyle}>تاریخ قبض *</div>
                    <input name="weighbridgeDate" type="date" required
                      defaultValue={todayStr} max={todayStr} style={inputStyle} />
                  </div>
                  <div>
                    <div style={labelStyle}>پلاک روی قبض</div>
                    <input name="weighbridgePlate"
                      placeholder="اختیاری" style={inputStyle} />
                  </div>
                  <div>
                    <div style={labelStyle}>عکس قبض (JPG / PNG / WebP — حداکثر ۲۰MB) *</div>
                    <input name="weighbridgeTicket" type="file" required accept="image/jpeg,image/png,image/webp"
                      style={fileInputStyle} />
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginBottom: 20 }}>
                <a href="/my-listings" style={cancelLinkStyle}>انصراف</a>
                <button type="submit" style={submitBtnStyle}>ثبت آگهی</button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
    <Footer />
  </>
)
}
// ── استایل‌ها ─────────────────────────────────────────────────────────
const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: colors.bgPage,
  padding: `${spacing.xxl}px ${spacing.xl}px`,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const h1Style: React.CSSProperties = {
  fontSize: fontSize.xxl, fontWeight: 800, margin: 0, marginBottom: spacing.xs, color: colors.textPrimary,
}
const subStyle: React.CSSProperties = {
  fontSize: fontSize.base, color: colors.textMuted, margin: 0, marginBottom: spacing.lg,
}
const errorBannerStyle: React.CSSProperties = {
  background: colors.dangerBg, color: colors.dangerText, borderRadius: radius.md,
  padding: '10px 16px', fontSize: fontSize.sm, fontWeight: 600, marginBottom: 14,
}
const requestCardStyle: React.CSSProperties = {
  border: `1px solid ${colors.orange}`, borderRadius: radius.lg, padding: '14px 16px',
  background: colors.warningBg, marginBottom: 14,
}
const cardStyle: React.CSSProperties = {
  ...sharedCardStyle, padding: 18, marginBottom: 14,
}
const sectionTitleStyle: React.CSSProperties = {
  fontSize: fontSize.lg, fontWeight: 700, margin: 0, marginBottom: 14,
}
const noteStyle: React.CSSProperties = {
  fontSize: fontSize.sm, color: colors.neutralText, lineHeight: 1.8, marginTop: 8, marginBottom: 0,
}
const hintStyle: React.CSSProperties = {
  fontSize: fontSize.xs, color: colors.warningText, marginTop: 4,
}
const linkBtnStyle: React.CSSProperties = {
  display: 'inline-block', background: colors.navy, color: '#fff', borderRadius: radius.md,
  padding: '9px 18px', fontSize: fontSize.sm, fontWeight: 700,
  textDecoration: 'none', cursor: 'pointer', marginTop: spacing.md,
}
const labelStyle: React.CSSProperties = {
  ...sharedLabelStyle,
}
const inputStyle: React.CSSProperties = {
  ...sharedInputStyle, width: '100%',
}
const selectStyle: React.CSSProperties = {
  ...sharedSelectStyle, width: '100%',
}
const fileInputStyle: React.CSSProperties = {
  border: `1px solid ${colors.borderSubtle}`, borderRadius: radius.md,
  padding: '7px 10px', fontSize: fontSize.xs, fontFamily: 'inherit', width: '100%',
  background: colors.bgCard,
}
const submitBtnStyle: React.CSSProperties = {
  ...btnPrimaryStyle, padding: '11px 28px', fontSize: fontSize.md, fontWeight: 800,
}
const cancelLinkStyle: React.CSSProperties = {
  background: colors.neutralBg, color: colors.neutralText, borderRadius: radius.md,
  padding: '9px 18px', fontSize: fontSize.sm, fontWeight: 600,
  textDecoration: 'none', cursor: 'pointer',
}
