import prisma from '@/lib/prisma'
import { notFound } from 'next/navigation'
import { getCurrentUserOrNull } from '@/lib/currentUser'
import CurrencyTicker from '@/components/CurrencyTicker'
import PublicHeader from '@/components/PublicHeader'
import Footer from '@/components/Footer'

export const dynamic = 'force-dynamic'

type Params = Promise<{ id: string }>

function faDate(d: Date | null | undefined): string {
  if (!d) return '—'
  return new Date(d).toLocaleDateString('fa-IR')
}

export default async function ReportDetailPage({ params }: { params: Params }) {
  const { id } = await params
  const user = await getCurrentUserOrNull()
  const now = new Date()

  // نکته‌ی امنیتی: صفحه عمومیه — author فقط با select: { companyName }.
  const article = await prisma.article.findUnique({
    where: { id },
    include: { author: { select: { companyName: true } } },
  })

  // فقط مقاله‌ی منتشرشده با تاریخ انتشار گذشته قابل مشاهده‌ی عمومیه؛
  // پیش‌نویس و زمان‌بندی‌شده مثل نبودن رفتار می‌کنن.
  const isPublic =
    !!article && article.isPublished && !!article.publishedAt && article.publishedAt.getTime() <= now.getTime()
  if (!article || !isPublic) notFound()

  const paragraphs = article.content.split(/\n{2,}/).map((p) => p.trim()).filter(Boolean)

  // چند گزارش دیگر برای پایین صفحه
  const others = await prisma.article.findMany({
    where: { isPublished: true, publishedAt: { not: null, lte: now }, id: { not: article.id } },
    select: { id: true, title: true, publishedAt: true },
    orderBy: { publishedAt: 'desc' },
    take: 3,
  })

  return (
    <>
      <CurrencyTicker />
      <PublicHeader activePage="/reports" isLoggedIn={!!user} />

      <section style={sectionStyle}>
        <div className="wrap">
          <a href="/reports" style={backLinkStyle}>
            ← همه‌ی گزارش‌ها
          </a>

          <article style={articleWrapStyle}>
            <div className="eyebrow">گزارش بازار</div>
            <h1 style={titleStyle}>{article.title}</h1>
            <div style={metaRowStyle}>
              <span>{faDate(article.publishedAt)}</span>
              {article.author?.companyName && (
                <>
                  <span style={dotSepStyle}>•</span>
                  <span>{article.author.companyName}</span>
                </>
              )}
            </div>

            <div style={bodyStyle}>
              {paragraphs.length > 0 ? (
                paragraphs.map((p, i) => (
                  <p key={i} style={paragraphStyle}>
                    {p}
                  </p>
                ))
              ) : (
                <p style={paragraphStyle}>{article.content}</p>
              )}
            </div>
          </article>
        </div>
      </section>

      {others.length > 0 && (
        <section className="section-line" style={sectionStyle}>
          <div className="wrap">
            <div className="eyebrow">ادامه‌ی مطالب</div>
            <div className="sec-title">گزارش‌های دیگر</div>
            <div className="sec-sub" style={{ marginBottom: 22 }}>
              تحلیل‌های تازه‌ی بازار مواد اولیه پلیمری.
            </div>
            <div className="news-grid">
              {others.map((o) => (
                <a key={o.id} href={`/reports/${o.id}`} className="news-card">
                  <div className="thumb"></div>
                  <div className="body">
                    <div className="cat">گزارش بازار</div>
                    <h4>{o.title}</h4>
                    <div className="time">{faDate(o.publishedAt)}</div>
                  </div>
                </a>
              ))}
            </div>
          </div>
        </section>
      )}

      <Footer />
    </>
  )
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const sectionStyle: React.CSSProperties = { padding: '48px 0' }
const backLinkStyle: React.CSSProperties = {
  fontSize: 12.5,
  fontWeight: 600,
  color: 'var(--cyan)',
  display: 'inline-block',
  marginBottom: 18,
}
const articleWrapStyle: React.CSSProperties = {
  border: '1px solid var(--border)',
  borderRadius: 12,
  padding: 32,
  background: 'var(--panel)',
  maxWidth: 820,
}
const titleStyle: React.CSSProperties = {
  fontSize: 25,
  fontWeight: 800,
  lineHeight: 1.6,
  marginBottom: 12,
}
const metaRowStyle: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 8,
  fontSize: 12,
  color: 'var(--ink-mute)',
  fontFamily: 'var(--mono)',
  paddingBottom: 18,
  borderBottom: '1px solid var(--border)',
  flexWrap: 'wrap',
}
const dotSepStyle: React.CSSProperties = { color: 'var(--border-strong)' }
const bodyStyle: React.CSSProperties = { paddingTop: 22 }
const paragraphStyle: React.CSSProperties = {
  fontSize: 14.5,
  lineHeight: 2,
  color: 'var(--ink-dim)',
  marginBottom: 16,
  whiteSpace: 'pre-wrap',
}
