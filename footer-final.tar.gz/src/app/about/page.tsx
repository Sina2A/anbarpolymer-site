import prisma from '@/lib/prisma'
import { getCurrentUserOrNull } from '@/lib/currentUser'
import CurrencyTicker from '@/components/CurrencyTicker'
import PublicHeader from '@/components/PublicHeader'
import Footer from '@/components/Footer'

export const dynamic = 'force-dynamic'

export default async function AboutPage() {
  const user = await getCurrentUserOrNull()
  const now = new Date()

  // ── آمار زنده از دیتابیس ──
  // نکته‌ی امنیتی: هیچ رکورد User سریالایز نمی‌شود؛ فقط شمارش و میانگین.
  const [gradeCount, activeListingCount, warehouseCount, publishedArticleCount, reviewAgg] = await Promise.all([
    prisma.grade.count({ where: { isActive: true } }),
    prisma.materialListing.count({ where: { validityStatus: 'active' } }),
    prisma.warehouse.count(),
    prisma.article.count({ where: { isPublished: true, publishedAt: { not: null, lte: now } } }),
    prisma.review.aggregate({ _avg: { rating: true }, _count: true }),
  ])
  const ratingAvg = reviewAgg._avg.rating
  const ratingCount = reviewAgg._count

  return (
    <>
      <CurrencyTicker />
      <PublicHeader activePage="/about" isLoggedIn={!!user} />

      <section style={sectionStyle}>
        <div className="wrap">
          <div className="eyebrow">درباره ما</div>
          <div className="sec-title">انبار پلیمر — بستر تخصصی تجارت مواد اولیه پلیمری</div>
          <div className="sec-sub">
            واردکننده و فروشنده‌ی مستقیم مواد اولیه پلیمری برای کارخانه‌های تولیدی سراسر کشور.
          </div>
        </div>
      </section>

      <section className="section-line" style={sectionStyle}>
        <div className="wrap">
          <div className="two-col">
            <div>
              <div className="eyebrow">داستان ما</div>
              <div className="sec-title">چرا انبار پلیمر ساخته شد؟</div>
              <div className="sec-sub" style={{ marginBottom: 20, maxWidth: 'none' }}>
                خرید مواد اولیه پلیمری در بازار سنتی پر از قیمت غیرشفاف، مشخصات فنی نامشخص و ریسک معاملاتی است.
              </div>
              <p style={storyParaStyle}>
                انبار پلیمر با هدف شفاف‌سازی زنجیره‌ی تأمین مواد اولیه پلیمری راه‌اندازی شد. کاتالوگ گریدهای ما با
                مشخصات فنی استاندارد و قابل‌مقایسه (MFI، دانسیته، نوع کاربرد)، در کنار آگهی‌های عرضه‌ی واقعی از
                انبارهای سراسر کشور، باعث می‌شود خریدار بدون حدس و گمان و تماس‌های متعدد، بهترین انتخاب را انجام دهد.
              </p>
              <p style={storyParaStyle}>
                فروشنده‌ها هم بدون هزینه‌ی تبلیغات، آگهی‌هایشان را در برابر خریداران واقعی و احراز هویت‌شده نمایش
                می‌دهند؛ قیمت‌گذاری بر اساس شاخص‌های بنچمارک جهانی انجام می‌شود و همه‌ی مراحل معامله — از استعلام تا
                تحویل — در پلتفرم ثبت و قابل پیگیری است.
              </p>
              <p style={storyParaStyle}>
                ما به‌جای واسطه‌گری پرریسک، زیرساخت امن معامله می‌سازیم: احراز هویت اجباری طرفین، پیش‌فاکتور رسمی با
                مهلت مشخص، تایید فیش پرداخت توسط تیم مالی و امتیازدهی دوطرفه پس از هر تحویل.
              </p>
            </div>
            <div>
              <div className="price-block">
                <h4>چرا انبار پلیمر؟</h4>
                <div className="hint">چیزی که معامله را اینجا متفاوت می‌کند</div>
                <ul className="check-list">
                  <li>قیمت شفاف بر پایه‌ی شاخص‌های بنچمارک جهانی</li>
                  <li>مشخصات فنی استاندارد و قابل‌مقایسه برای هر گرید</li>
                  <li>احراز هویت اجباری خریدار و فروشنده (KYC)</li>
                  <li>پیش‌فاکتور رسمی با مهلت تایید مشخص</li>
                  <li>تایید فیش پرداخت قبل از خروج کالا از انبار</li>
                  <li>امتیازدهی دوطرفه پس از هر معامله</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section-line" style={sectionStyle}>
        <div className="wrap">
          <div className="eyebrow">آمار به‌زبان اعداد</div>
          <div className="sec-title">انبار پلیمر در یک نگاه</div>
          <div className="sec-sub" style={{ marginBottom: 24 }}>
            آمار زنده، مستقیم از پلتفرم — نه عدد تبلیغاتی.
          </div>
          <div className="kpi-row">
            <div className="kpi">
              <div className="k">گریدهای فعال</div>
              <div className="v">{gradeCount.toLocaleString('fa-IR')}</div>
            </div>
            <div className="kpi">
              <div className="k">آگهی‌های عرضه‌ی فعال</div>
              <div className="v">{activeListingCount.toLocaleString('fa-IR')}</div>
            </div>
            <div className="kpi">
              <div className="k">انبارهای زیر پوشش</div>
              <div className="v">{warehouseCount.toLocaleString('fa-IR')}</div>
            </div>
            <div className="kpi">
              <div className="k">گزارش‌های منتشرشده</div>
              <div className="v">{publishedArticleCount.toLocaleString('fa-IR')}</div>
            </div>
          </div>
          {ratingAvg !== null && ratingCount > 0 && (
            <p style={ratingLineStyle}>
              میانگین رضایت طرف‌های معامله:{' '}
              <b style={{ color: 'var(--ink)' }}>{(Math.round(ratingAvg * 10) / 10).toLocaleString('fa-IR')}</b> از ۵ —
              بر اساس {ratingCount.toLocaleString('fa-IR')} امتیاز ثبت‌شده پس از تحویل کالا.
            </p>
          )}
        </div>
      </section>

      <section className="section-line" style={sectionStyle}>
        <div className="wrap">
          <div className="eyebrow">ارزش‌های ما</div>
          <div className="sec-title">سه اصلی که معامله را امن می‌کند</div>
          <div className="sec-sub" style={{ marginBottom: 26 }}>
            همه‌ی امکانات پلتفرم حول همین سه اصل طراحی شده‌اند.
          </div>
          <div className="grid3">
            <div className="feat-card">
              <div className="num">01</div>
              <h3>شفافیت قیمت</h3>
              <p>
                قیمت‌گذاری بر اساس شاخص‌های بنچمارک جهانی (IME، ARGUS و…) انجام می‌شود و قیمت نهایی در پیش‌فاکتور
                رسمی، بدون هیچ هزینه‌ی پنهانی اعلام می‌شود.
              </p>
            </div>
            <div className="feat-card">
              <div className="num">02</div>
              <h3>اصالت و کیفیت کالا</h3>
              <p>
                هر آگهی به یک گرید ثبت‌شده در کاتالوگ متصل است؛ مشخصات فنی، دیتاشیت و تصویر واقعی کالا پیش از خرید
                قابل بررسی است و قبض باسکول لحظه‌ی ثبت آگهی کنترل می‌شود.
              </p>
            </div>
            <div className="feat-card">
              <div className="num">03</div>
              <h3>امنیت معامله</h3>
              <p>
                احراز هویت اجباری طرفین، پیش‌فاکتور با مهلت تایید، بررسی فیش پرداخت توسط تیم مالی و امکان ثبت اختلاف
                با مستندات — برای اینکه معامله بدون ریسک باشد.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="section-line" style={sectionStyle}>
        <div className="wrap">
          <div className="eyebrow">گام بعدی</div>
          <div className="sec-title">با ما در تماس باش</div>
          <div className="sec-sub" style={{ marginBottom: 22 }}>
            سوالی درباره‌ی همکاری، خرید سازمانی یا عرضه‌ی کالا داری؟
          </div>
          <div style={ctaRowStyle}>
            <a href="/contact" className="btn btn-cyan">
              تماس با ما
            </a>
            <a href="/services" className="btn btn-outline">
              خدمات سازمانی
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </>
  )
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const sectionStyle: React.CSSProperties = { padding: '56px 0' }
const storyParaStyle: React.CSSProperties = {
  fontSize: 14,
  lineHeight: 2.05,
  color: 'var(--ink-dim)',
  marginBottom: 16,
}
const ratingLineStyle: React.CSSProperties = {
  fontSize: 13.5,
  color: 'var(--ink-dim)',
  background: 'var(--panel-2)',
  border: '1px solid var(--border)',
  borderRadius: 10,
  padding: '14px 18px',
}
const ctaRowStyle: React.CSSProperties = { display: 'flex', gap: 12, flexWrap: 'wrap' }
