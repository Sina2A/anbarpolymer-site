import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import UserNav from '@/components/UserNav'
import PanelHeader from '@/components/PanelHeader'
import Footer from '@/components/Footer'
import { colors, radius, fontSize, shadow } from '@/lib/styles/tokens'
import {
  pageStyle as sharedPageStyle,
  pageWrapStyle as sharedPageWrapStyle,
  contentStyle as sharedContentStyle,
  cardStyle as sharedCardStyle,
  cardHeaderStyle as sharedCardHeaderStyle,
  emptyStateStyle as sharedEmptyStateStyle,
} from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

export default async function MyRequestsPage() {
  const user = await getCurrentUser()

  // Order هایی که هنوز قیمت نهایی نگرفتن (pending یا priced که هنوز confirmed نشده)
  const pendingOrders = await prisma.order.findMany({
    where: {
      userId: user.id,
      status: { in: ['pending', 'priced'] },
    },
    orderBy: { createdAt: 'desc' },
    include: {
      items: {
        include: { grade: true },
      },
    },
  })

  // MaterialListing هایی که کاربر رزرو کرده ولی هنوز Deal نهایی نشده
  // (یعنی Deal با status='draft' یا اصلاً Deal وجود نداره ولی listing رزرو شده)
  const reservedListings = await prisma.materialListing.findMany({
    where: {
      validityStatus: 'reserved',
      deals: {
        some: {
          buyerId: user.id,
          status: 'draft',
        },
      },
    },
    include: {
      grade: true,
      deals: {
        where: {
          buyerId: user.id,
          status: 'draft',
        },
        take: 1,
      },
    },
  })

  return (
    <>
    <PanelHeader currentUserName={user.companyName} />
    <div style={sharedPageStyle}>
      <div style={sharedPageWrapStyle} className="admin-page-wrap">
        <UserNav currentUserName={user.companyName} activeSection="requests" />
        <div style={sharedContentStyle}>
          <h1 style={{ fontSize: fontSize.xxl, fontWeight: 800, color: colors.textPrimary, marginBottom: 4 }}>درخواست‌های خرید من</h1>
          <p style={{ fontSize: fontSize.base, color: colors.textMuted, marginBottom: 20 }}>
            سفارش‌ها و آگهی‌هایی که در حال بررسی یا رزرو هستند
          </p>

          {/* سفارش‌های در انتظار */}
          <div style={{ ...sharedCardStyle, boxShadow: shadow.card }}>
            <div style={sharedCardHeaderStyle}>
              <b style={{ fontSize: fontSize.md }}>سفارش‌های در انتظار قیمت‌گذاری/تایید</b>
              <span style={badgeStyle}>{pendingOrders.length}</span>
            </div>

            {pendingOrders.length === 0 ? (
              <div style={sharedEmptyStateStyle}>همه سفارش‌ها قیمت‌گذاری و تایید شده‌اند.</div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {pendingOrders.map((order) => (
                  <div key={order.id} style={itemStyle}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: 8 }}>
                      <div>
                        <span style={{ fontSize: fontSize.base, fontWeight: 700, fontFamily: 'monospace' }}>
                          #{order.id.slice(0, 8)}
                        </span>
                        <span style={{ ...statusTag, ...statusColors(order.status), marginRight: 8 }}>
                          {translateOrderStatus(order.status)}
                        </span>
                      </div>
                      <span style={{ fontSize: fontSize.xs, color: colors.textMuted }}>
                        {new Date(order.createdAt).toLocaleDateString('fa-IR')}
                      </span>
                    </div>
                    <div style={{ fontSize: fontSize.sm, color: colors.neutralText }}>
                      {order.items.map((item, idx) => (
                        <div key={item.id} style={{ marginBottom: 4 }}>
                          • {item.grade.code} — {item.quantity} کیلوگرم
                          {item.finalPrice && (
                            <span style={{ color: colors.orange, fontWeight: 700, marginRight: 6 }}>
                              ({item.finalPrice.toLocaleString('fa-IR')} ریال/کیلو)
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* آگهی‌های رزرو شده (Deal در مرحله draft) */}
          <div style={{ ...sharedCardStyle, boxShadow: shadow.card }}>
            <div style={sharedCardHeaderStyle}>
              <b style={{ fontSize: fontSize.md }}>آگهی‌های رزرو شده (در حال مذاکره)</b>
              <span style={badgeStyle}>{reservedListings.length}</span>
            </div>

            {reservedListings.length === 0 ? (
              <div style={sharedEmptyStateStyle}>هیچ آگهی رزروی در دست مذاکره نیست.</div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {reservedListings.map((listing) => {
                  const deal = listing.deals[0]
                  return (
                    <div key={listing.id} style={itemStyle}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: 8 }}>
                        <div>
                          <span style={{ fontSize: fontSize.base, fontWeight: 700 }}>
                            {listing.grade.code}
                          </span>
                          <span style={{ ...statusTag, background: '#fef3c7', color: colors.warningText, marginRight: 8 }}>
                            رزرو شده
                          </span>
                        </div>
                        <span style={{ fontSize: fontSize.xs, color: colors.textMuted }}>
                          {new Date(listing.createdAt).toLocaleDateString('fa-IR')}
                        </span>
                      </div>
                      <div style={{ fontSize: fontSize.sm, color: colors.neutralText, marginBottom: 6 }}>
                        مقدار: <b>{listing.quantityTon} تن</b> | محل: {listing.city}, {listing.province}
                      </div>
                      <div style={{ fontSize: 12, color: '#6b7280' }}>
                        قیمت درخواستی: <b>{listing.askingPriceToman.toLocaleString('fa-IR')}</b> تومان/کیلو
                      </div>
                      {deal && (
                        <div style={{ fontSize: fontSize.xs, color: colors.textMuted, marginTop: 6, fontStyle: 'italic' }}>
                          معامله #{deal.id.slice(0, 8)} — در حال بررسی توسط کارشناس
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
    <Footer />
  </>
)
}

// ── ترجمه ───────────────────────────────────────────────────────────────
function translateOrderStatus(status: string): string {
  const map: Record<string, string> = {
    pending: 'در انتظار قیمت‌گذاری',
    priced: 'قیمت‌گذاری شده',
    awaiting_approval: 'در انتظار تایید مدیر',
    confirmed: 'تایید شده',
    completed: 'تکمیل شده',
    cancelled: 'لغو شده',
  }
  return map[status] ?? status
}

function statusColors(status: string): React.CSSProperties {
  if (status === 'pending') return { background: '#fef3c7', color: colors.warningText }
  if (status === 'priced') return { background: '#dbeafe', color: '#1e3a8a' }
  return { background: '#f1efe8', color: colors.neutralText }
}

const itemStyle: React.CSSProperties = {
  padding: '14px 16px',
  border: '1px solid #e8e4db',
  borderRadius: 10,
  background: '#faf8f4',
}
const statusTag: React.CSSProperties = {
  fontSize: 10,
  fontWeight: 700,
  borderRadius: radius.sm,
  padding: '3px 8px',
  display: 'inline-block',
}
const badgeStyle: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 700,
  background: colors.orange,
  color: '#fff',
  borderRadius: radius.md,
  padding: '2px 10px',
}
