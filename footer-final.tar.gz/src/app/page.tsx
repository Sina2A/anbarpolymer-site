import { getCurrentUserOrNull } from '@/lib/currentUser'
import PublicHeader from '@/components/PublicHeader'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import Footer from '@/components/Footer'

export const dynamic = 'force-dynamic'

export default async function Home() {
  const user = await getCurrentUserOrNull()

  return (
    <div style={pageStyle}>
      <PublicHeader activePage="/" isLoggedIn={!!user} />

      <main>
        {/* Hero */}
        <section style={heroSection}>
          <div style={heroInner}>
            <h1 style={heroTitle}>
              انبار پلیمر
            </h1>
            <p style={heroSub}>
              بزرگ‌ترین شبکه‌ی خرید و فروش مواد اولیه پلیمری ایران — خریدارها و فروشنده‌ها مستقیم و بدون واسطه معامله می‌کنن.
            </p>
            <div style={heroActions}>
              <a href="/market" style={btnPrimary}>بازار صنعتی ←</a>
              <a href="/grades" style={btnSecondary}>کاتالوگ گریدها</a>
            </div>
          </div>
        </section>

        {/* Features */}
        <section style={featuresSection}>
          <div style={featuresInner}>
            {FEATURES.map((f) => (
              <div key={f.title} style={featureCard}>
                <div style={featureIcon}>{f.icon}</div>
                <div style={featureTitle}>{f.title}</div>
                <div style={featureDesc}>{f.desc}</div>
              </div>
            ))}
          </div>
        </section>

        {/* CTA */}
        <section style={ctaSection}>
          <div style={ctaInner}>
            <div style={ctaText}>
              <h2 style={ctaTitle}>آماده‌اید شروع کنید؟</h2>
              <p style={ctaSub}>
                همین الان ثبت‌نام کنید و قیمت به‌روز مواد اولیه پلیمری رو ببینید.
              </p>
            </div>
            <a href={user ? '/dashboard' : '/signup'} style={btnPrimary}>
              {user ? 'پیشخوان' : 'ثبت‌نام رایگان'}
            </a>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}

const FEATURES = [
  { icon: '📦', title: 'بازار دوطرفه', desc: 'فروشنده آگهی می‌ذاره، خریدار درخواست خرید ثبت می‌کنه — هر دو طرف پیدا می‌شن.' },
  { icon: '🔍', title: 'جستجو و فیلتر پیشرفته', desc: 'بر اساس گرید، تولیدکننده، خانواده پلیمری، استان و کاربرد فیلتر کنید.' },
  { icon: '📄', title: 'دیتاشیت فنی', desc: 'مشخصات کامل هر گرید با MFI، چگالی، استاندارد و اسناد قابل دانلود.' },
  { icon: '🛡️', title: 'احراز هویت تولیدکننده', desc: 'فروشنده‌ها پروانه بهره‌برداری بارگذاری می‌کنن — معامله با اطمینان بیشتر.' },
]

// ── استایل‌ها ─────────────────────────────────────────────────────────
const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: colors.bgPage,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
  display: 'flex',
  flexDirection: 'column',
}
const heroSection: React.CSSProperties = {
  background: colors.navy,
  padding: `${spacing.xxl * 2}px ${spacing.xl}px`,
  textAlign: 'center',
}
const heroInner: React.CSSProperties = {
  maxWidth: 700,
  margin: '0 auto',
}
const heroTitle: React.CSSProperties = {
  fontSize: 36,
  fontWeight: 800,
  color: '#ffffff',
  margin: 0,
  marginBottom: spacing.lg,
  letterSpacing: '-0.02em',
}
const heroSub: React.CSSProperties = {
  fontSize: fontSize.lg,
  color: 'rgba(255,255,255,0.8)',
  lineHeight: 1.8,
  margin: 0,
  marginBottom: spacing.xl,
}
const heroActions: React.CSSProperties = {
  display: 'flex',
  gap: spacing.md,
  justifyContent: 'center',
  flexWrap: 'wrap',
}
const btnPrimary: React.CSSProperties = {
  display: 'inline-block',
  background: colors.orange,
  color: '#fff',
  borderRadius: radius.sm,
  padding: '12px 28px',
  fontSize: fontSize.md,
  fontWeight: 700,
  textDecoration: 'none',
  cursor: 'pointer',
  fontFamily: 'inherit',
}
const btnSecondary: React.CSSProperties = {
  display: 'inline-block',
  background: 'transparent',
  color: '#fff',
  border: '1px solid rgba(255,255,255,0.4)',
  borderRadius: radius.sm,
  padding: '12px 28px',
  fontSize: fontSize.md,
  fontWeight: 600,
  textDecoration: 'none',
  cursor: 'pointer',
  fontFamily: 'inherit',
}
const featuresSection: React.CSSProperties = {
  padding: `${spacing.xxl * 2}px ${spacing.xl}px`,
}
const featuresInner: React.CSSProperties = {
  maxWidth: 1100,
  margin: '0 auto',
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))',
  gap: spacing.lg,
}
const featureCard: React.CSSProperties = {
  background: colors.bgCard,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
  padding: spacing.xl,
}
const featureIcon: React.CSSProperties = {
  fontSize: 28,
  marginBottom: spacing.md,
}
const featureTitle: React.CSSProperties = {
  fontSize: fontSize.lg,
  fontWeight: 700,
  color: colors.textPrimary,
  marginBottom: spacing.sm,
}
const featureDesc: React.CSSProperties = {
  fontSize: fontSize.sm,
  color: colors.textSecondary,
  lineHeight: 1.7,
}
const ctaSection: React.CSSProperties = {
  padding: `${spacing.xxl * 2}px ${spacing.xl}px`,
}
const ctaInner: React.CSSProperties = {
  maxWidth: 700,
  margin: '0 auto',
  textAlign: 'center',
  background: colors.bgCard,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
  padding: `${spacing.xxl * 2}px ${spacing.xl}`,
}
const ctaText: React.CSSProperties = {}
const ctaTitle: React.CSSProperties = {
  fontSize: fontSize.xxl,
  fontWeight: 800,
  color: colors.textPrimary,
  margin: 0,
  marginBottom: spacing.sm,
}
const ctaSub: React.CSSProperties = {
  fontSize: fontSize.base,
  color: colors.textSecondary,
  margin: 0,
  marginBottom: spacing.xl,
  lineHeight: 1.7,
}
