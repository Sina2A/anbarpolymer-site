'use client'

import { useState, useEffect } from 'react'
import { getBenchmarkDataForGrade } from '@/app/admin-pricing/actions'
import BenchmarkCurrentStatus from './BenchmarkCurrentStatus'
import BenchmarkPriceChart from './BenchmarkPriceChart'
import BenchmarkHistoryTable from './BenchmarkHistoryTable'
import { colors } from '@/lib/styles/tokens'

type Grade = { id: string; code: string }
type BenchmarkData = Awaited<ReturnType<typeof getBenchmarkDataForGrade>>

export default function Tab7_1BenchinoClient({ grades }: { grades: Grade[] }) {
  const [selectedGrade, setSelectedGrade] = useState<string>(grades[0]?.id || '')
  const [data, setData] = useState<BenchmarkData | null>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!selectedGrade) return

    setLoading(true)
    getBenchmarkDataForGrade(selectedGrade)
      .then(setData)
      .catch((err) => {
        console.error('خطا در بارگذاری دیتای بنچمارک:', err)
        setData(null)
      })
      .finally(() => setLoading(false))
  }, [selectedGrade])

  return (
    <div className="tab-body">
      <div className="eyebrow">نمودار روند قیمت</div>

      <select
        value={selectedGrade}
        onChange={(e) => setSelectedGrade(e.target.value)}
        style={{
          marginBottom: 24,
          padding: '10px 14px',
          fontSize: 14,
          border: `1px solid ${colors.borderSubtle}`,
          borderRadius: 8,
          background: colors.bgCard,
          color: colors.textPrimary,
          cursor: 'pointer',
          minWidth: 200,
        }}
      >
        {grades.map((g) => (
          <option key={g.id} value={g.id}>
            {g.code}
          </option>
        ))}
      </select>

      {loading && (
        <div style={{ padding: 40, textAlign: 'center', color: colors.textMuted }}>
          در حال بارگذاری...
        </div>
      )}

      {!loading && data && (
        <>
          {data.currentPrice && (
            <BenchmarkCurrentStatus
              price={data.currentPrice.price}
              sourceType={data.currentPrice.sourceType}
              sourceLabel={data.currentPrice.sourceLabel}
              effectiveDate={data.currentPrice.effectiveDate}
              gradeCode={data.currentPrice.gradeCode}
            />
          )}

          {data.chartData.length > 0 && (
            <BenchmarkPriceChart data={data.chartData} gradeCode={data.currentPrice?.gradeCode || ''} />
          )}

          <BenchmarkHistoryTable records={data.historyRecords} />
        </>
      )}

      {!loading && data && !data.currentPrice && data.historyRecords.length === 0 && (
        <div
          style={{
            padding: 60,
            textAlign: 'center',
            color: colors.textMuted,
            fontSize: 14,
            background: colors.bgCard,
            border: `1px solid ${colors.borderSubtle}`,
            borderRadius: 12,
          }}
        >
          هیچ داده‌ای برای این گرید ثبت نشده
        </div>
      )}
    </div>
  )
}
