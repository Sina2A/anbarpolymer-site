'use client'

import { useMemo } from 'react'
import {
  useReactTable,
  getCoreRowModel,
  getSortedRowModel,
  flexRender,
  createColumnHelper,
} from '@tanstack/react-table'
import { colors } from '@/lib/styles/tokens'

type Record = {
  id: string
  date: string
  approvedAt: string | null
  gradeCode: string
  oldPrice: number | null
  newPrice: number
  deviationPercent: number | null
  status: string
  approverName: string | null
}

const columnHelper = createColumnHelper<Record>()

export default function BenchmarkHistoryTable({ records }: { records: Record[] }) {
  const columns = useMemo(
    () => [
      columnHelper.accessor('date', {
        header: 'تاریخ ثبت',
        cell: (info) => new Date(info.getValue()).toLocaleDateString('fa-IR'),
      }),
      columnHelper.accessor('gradeCode', {
        header: 'گرید',
      }),
      columnHelper.accessor('oldPrice', {
        header: 'قیمت قدیم',
        cell: (info) => {
          const val = info.getValue()
          return val !== null ? val.toLocaleString('fa-IR') : '—'
        },
      }),
      columnHelper.accessor('newPrice', {
        header: 'قیمت جدید',
        cell: (info) => info.getValue().toLocaleString('fa-IR'),
      }),
      columnHelper.accessor('deviationPercent', {
        header: 'تغییر (%)',
        cell: (info) => {
          const val = info.getValue()
          if (val === null) return '—'
          const color = val > 0 ? colors.successText : val < 0 ? colors.dangerText : colors.textMuted
          return <span style={{ color, fontWeight: 600 }}>{val.toFixed(1)}%</span>
        },
      }),
      columnHelper.accessor('status', {
        header: 'وضعیت',
        cell: (info) => {
          const status = info.getValue()
          const bgColor =
            status === 'approved'
              ? colors.successBg
              : status === 'rejected'
                ? colors.dangerBg
                : colors.neutralBg
          const textColor =
            status === 'approved'
              ? colors.successText
              : status === 'rejected'
                ? colors.dangerText
                : colors.neutralText
          const label =
            status === 'approved' ? 'تایید' : status === 'rejected' ? 'رد' : 'در انتظار'
          return (
            <span
              style={{
                background: bgColor,
                color: textColor,
                padding: '4px 10px',
                borderRadius: 6,
                fontSize: 12,
                fontWeight: 600,
              }}
            >
              {label}
            </span>
          )
        },
      }),
      columnHelper.accessor('approverName', {
        header: 'تاییدکننده',
        cell: (info) => info.getValue() || '—',
      }),
    ],
    []
  )

  const table = useReactTable({
    data: records,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    initialState: {
      sorting: [{ id: 'date', desc: true }],
    },
  })

  return (
    <div style={{ marginTop: 32 }}>
      <h4 style={{ fontSize: 16, fontWeight: 700, marginBottom: 16 }}>تاریخچه تغییرات</h4>
      <table
        style={{
          width: '100%',
          borderCollapse: 'collapse',
          fontSize: 13,
          background: colors.bgCard,
          border: `1px solid ${colors.borderSubtle}`,
          borderRadius: 8,
          overflow: 'hidden',
        }}
      >
        <thead>
          {table.getHeaderGroups().map((hg) => (
            <tr key={hg.id}>
              {hg.headers.map((h) => (
                <th
                  key={h.id}
                  onClick={h.column.getToggleSortingHandler()}
                  style={{
                    background: colors.bgPage,
                    color: colors.textSecondary,
                    fontWeight: 700,
                    padding: '12px 14px',
                    textAlign: 'right',
                    cursor: h.column.getCanSort() ? 'pointer' : 'default',
                    borderBottom: `1px solid ${colors.borderSubtle}`,
                  }}
                >
                  {flexRender(h.column.columnDef.header, h.getContext())}
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody>
          {table.getRowModel().rows.map((row) => (
            <tr key={row.id}>
              {row.getVisibleCells().map((cell) => (
                <td
                  key={cell.id}
                  style={{
                    padding: '12px 14px',
                    borderBottom: `1px solid ${colors.borderSubtle}`,
                    color: colors.textPrimary,
                  }}
                >
                  {flexRender(cell.column.columnDef.cell, cell.getContext())}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      {records.length === 0 && (
        <div
          style={{
            padding: 40,
            textAlign: 'center',
            color: colors.textMuted,
            fontSize: 14,
          }}
        >
          هیچ تاریخچه‌ای برای این گرید ثبت نشده
        </div>
      )}
    </div>
  )
}
