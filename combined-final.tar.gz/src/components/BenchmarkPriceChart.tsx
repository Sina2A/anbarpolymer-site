'use client'

import ReactEChartsCore from 'echarts-for-react/lib/core'
import * as echarts from 'echarts/core'
import { LineChart } from 'echarts/charts'
import { GridComponent, TooltipComponent } from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import { colors } from '@/lib/styles/tokens'

echarts.use([LineChart, GridComponent, TooltipComponent, CanvasRenderer])

type Props = {
  data: Array<{ date: string; price: number }>
  gradeCode: string
}

export default function BenchmarkPriceChart({ data, gradeCode }: Props) {
  const option = {
    tooltip: {
      trigger: 'axis',
      formatter: (params: any) => {
        const p = params[0]
        const date = new Date(p.name).toLocaleDateString('fa-IR')
        return `${date}<br/>${p.value.toLocaleString('fa-IR')} دلار`
      },
    },
    grid: { left: 60, right: 40, top: 40, bottom: 60 },
    xAxis: {
      type: 'category',
      data: data.map((d) => d.date),
      axisLabel: {
        formatter: (value: string) => new Date(value).toLocaleDateString('fa-IR', {
          month: 'short',
          day: 'numeric',
        }),
      },
    },
    yAxis: {
      type: 'value',
      axisLabel: {
        formatter: (value: number) => value.toLocaleString('fa-IR'),
      },
    },
    series: [
      {
        type: 'line',
        data: data.map((d) => d.price),
        itemStyle: { color: colors.navy },
        lineStyle: { width: 2, color: colors.navy },
        symbol: 'circle',
        symbolSize: 6,
      },
    ],
  }

  return (
    <div style={{ marginTop: 24 }}>
      <h4 style={{ fontSize: 16, fontWeight: 700, marginBottom: 16 }}>
        روند قیمت {gradeCode}
      </h4>
      <ReactEChartsCore echarts={echarts} option={option} style={{ height: 350 }} />
    </div>
  )
}
