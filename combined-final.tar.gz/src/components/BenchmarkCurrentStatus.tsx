'use client'

import { colors } from '@/lib/styles/tokens'

type Props = {
  price: number
  sourceType: string
  sourceLabel: string | null
  effectiveDate: string
  gradeCode: string
}

export default function BenchmarkCurrentStatus({
  price,
  sourceType,
  sourceLabel,
  effectiveDate,
  gradeCode,
}: Props) {
  const faDate = new Date(effectiveDate).toLocaleDateString('fa-IR')
  const sourceText = sourceType === 'manual' ? 'دستی' : 'API'

  return (
    <div
      style={{
        background: colors.bgCard,
        border: `1px solid ${colors.borderSubtle}`,
        borderRadius: 12,
        padding: 20,
        marginBottom: 24,
      }}
    >
      <div style={{ fontSize: 13, color: colors.textMuted, marginBottom: 8 }}>
        قیمت فعلی
      </div>
      <div
        style={{
          fontSize: 28,
          fontWeight: 800,
          color: colors.navy,
          fontFamily: 'var(--mono)',
          marginBottom: 12,
        }}
      >
        {price.toLocaleString('fa-IR')} دلار
      </div>
      <div style={{ fontSize: 13, color: colors.textSecondary, marginBottom: 6 }}>
        گرید: <strong style={{ color: colors.textPrimary }}>{gradeCode}</strong>
      </div>
      <div style={{ fontSize: 13, color: colors.textSecondary, marginBottom: 6 }}>
        منبع: {sourceText}
        {sourceLabel && ` — ${sourceLabel}`}
      </div>
      <div style={{ fontSize: 12, color: colors.textMuted }}>
        آخرین به‌روزرسانی: {faDate}
      </div>
    </div>
  )
}
