export async function GET() {
  throw new Error('Sentry test error from API route — این خطا عمدی برای تست Sentry است')
}
