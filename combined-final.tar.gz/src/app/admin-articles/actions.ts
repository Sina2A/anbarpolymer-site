'use server'

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import { AccessDeniedError } from '@/lib/errorCodes'
import { logAudit } from '@/lib/logger'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import { ArticleSchema } from '@/schemas/article'

// گیت دسترسی — فقط مدیر یا کارشناسِ دارای دسترسی بخش «articles» مجازه.
// مدیر روی همه‌چیز دسترسی داره (مثل الگوی صفحات admin-* موجود).
async function requireArticlesAccess() {
  const user = await getCurrentUser()
  const isAdmin = user.role === 'admin'
  if (!isAdmin) {
    const access = await getAllSectionAccess(user.id)
    const level = access['articles'] ?? 'none'
    if (level === 'none') throw new AccessDeniedError('A-SECTION-ARTICLES')
  }
  return { user, isAdmin }
}

// ورودی تاریخ فرم (datetime-local) → Date؛ خالی → null
function parsePublishedAt(raw: string): Date | null {
  const v = raw.trim()
  if (!v) return null
  const d = new Date(v)
  if (isNaN(d.getTime())) throw new Error('تاریخ انتشار معتبر نیست.')
  return d
}

// ==================== نوشتن مقاله‌ی جدید ====================

export async function createArticleAction(formData: FormData) {
  const { user } = await requireArticlesAccess()

  const title = String(formData.get('title') || '').trim()
  const content = String(formData.get('content') || '').trim()
  const publishedAt = parsePublishedAt(String(formData.get('publishedAt') || ''))

  // Zod validation
  const result = ArticleSchema.safeParse({ title, content, publishedAt })
  if (!result.success) {
    const firstError = Object.values(result.error.flatten().fieldErrors)[0]?.[0] ||
                       result.error.flatten().formErrors[0] ||
                       'ورودی معتبر نیست'
    throw new Error(firstError)
  }

  // مقاله همیشه به‌صورت پیش‌نویس شروع می‌شه — انتشار جداگانه و آگاهانه انجام می‌شه.
  const article = await prisma.article.create({
    data: {
      title: result.data.title,
      content: result.data.content,
      publishedAt: result.data.publishedAt,
      authorId: user.id
    },
  })

  await logAudit('articles', `مقاله‌ی جدید: «${result.data.title}»`, user.id, { id: article.id })

  revalidatePath('/admin-articles')
  redirect(`/admin-articles/${article.id}`)
}

// ==================== ویرایش مقاله ====================

export async function updateArticleAction(formData: FormData) {
  const { user } = await requireArticlesAccess()

  const id = String(formData.get('id') || '').trim()
  const title = String(formData.get('title') || '').trim()
  const content = String(formData.get('content') || '').trim()
  const publishedAt = parsePublishedAt(String(formData.get('publishedAt') || ''))

  if (!id) throw new Error('شناسه‌ی مقاله مشخص نیست.')

  // Zod validation
  const result = ArticleSchema.safeParse({ title, content, publishedAt })
  if (!result.success) {
    const firstError = Object.values(result.error.flatten().fieldErrors)[0]?.[0] ||
                       result.error.flatten().formErrors[0] ||
                       'ورودی معتبر نیست'
    throw new Error(firstError)
  }

  const article = await prisma.article.findUnique({ where: { id } })
  if (!article) throw new Error('مقاله پیدا نشد.')

  await prisma.article.update({
    where: { id },
    data: {
      title: result.data.title,
      content: result.data.content,
      publishedAt: result.data.publishedAt
    }
  })

  await logAudit('articles', `ویرایش مقاله: «${result.data.title}»`, user.id, { id })

  revalidatePath(`/admin-articles/${id}`)
  revalidatePath('/admin-articles')
}

// ==================== انتشار / لغو انتشار ====================

export async function togglePublishAction(formData: FormData) {
  const { user } = await requireArticlesAccess()

  const id = String(formData.get('id') || '').trim()
  if (!id) throw new Error('شناسه‌ی مقاله مشخص نیست.')

  const article = await prisma.article.findUnique({ where: { id } })
  if (!article) throw new Error('مقاله پیدا نشد.')

  if (!article.isPublished) {
    // اولین انتشار: اگه تاریخ دستی ثبت نشده بود، همین الان ثبت می‌شه
    await prisma.article.update({
      where: { id },
      data: { isPublished: true, publishedAt: article.publishedAt ?? new Date() },
    })
    await logAudit('articles', `انتشار مقاله: «${article.title}»`, user.id, { id })
  } else {
    // لغو انتشار — publishedAt به‌عنوان سابقه نگه داشته می‌شه
    await prisma.article.update({ where: { id }, data: { isPublished: false } })
    await logAudit('articles', `لغو انتشار مقاله: «${article.title}»`, user.id, { id })
  }

  revalidatePath(`/admin-articles/${id}`)
  revalidatePath('/admin-articles')
}

// ==================== حذف مقاله ====================

export async function deleteArticleAction(formData: FormData) {
  const { user } = await requireArticlesAccess()

  const id = String(formData.get('id') || '').trim()
  if (!id) throw new Error('شناسه‌ی مقاله مشخص نیست.')

  const article = await prisma.article.findUnique({ where: { id } })
  if (!article) throw new Error('مقاله پیدا نشد.')

  await prisma.article.delete({ where: { id } })

  await logAudit('articles', `حذف مقاله: «${article.title}»`, user.id, { id })

  revalidatePath('/admin-articles')
  redirect('/admin-articles')
}
