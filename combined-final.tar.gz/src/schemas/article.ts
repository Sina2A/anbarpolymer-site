// src/schemas/article.ts
import { z } from 'zod'

export const ArticleSchema = z.object({
  title: z
    .string()
    .min(1, 'عنوان مقاله خالیه')
    .max(200, 'عنوان خیلی بلنده — حداکثر ۲۰۰ کاراکتر'),
  content: z
    .string()
    .min(1, 'متن مقاله خالیه')
    .max(50000, 'متن مقاله خیلی بلنده — حداکثر ۵۰٬۰۰۰ کاراکتر'),
  publishedAt: z.date().nullable(),
})

export type ArticleInput = z.infer<typeof ArticleSchema>
