// src/schemas/purchaseRequest.ts
import { z } from 'zod'

export const PurchaseRequestSchema = z.object({
  gradeId: z.string().min(1, 'گرید مشخص نیست'),
  quantityTon: z
    .number()
    .positive('مقدار درخواستی باید بیشتر از صفر باشه')
    .max(10000, 'مقدار خیلی زیاده — حداکثر ۱۰٬۰۰۰ تن'),
  maxPriceToman: z
    .number()
    .positive('سقف قیمت باید بیشتر از صفر باشه')
    .nullable(),
  deliveryLocation: z.string().max(200, 'آدرس تحویل خیلی بلنده').nullable(),
  notes: z.string().max(1000, 'یادداشت خیلی بلنده — حداکثر ۱٬۰۰۰ کاراکتر').nullable(),
})

export type PurchaseRequestInput = z.infer<typeof PurchaseRequestSchema>
