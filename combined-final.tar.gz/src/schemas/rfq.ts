// src/schemas/rfq.ts
import { z } from 'zod'

const CartItemSchema = z.object({
  gradeId: z.string().min(1, 'شناسه گرید خالیه'),
  warehouseId: z.string().min(1, 'شناسه انبار خالیه'),
  quantity: z
    .number()
    .positive('مقدار باید بیشتر از صفر باشه')
    .max(10000, 'مقدار خیلی زیاده — حداکثر ۱۰٬۰۰۰ تن'),
})

export const SubmitRfqSchema = z.object({
  cartItems: z
    .array(CartItemSchema)
    .min(1, 'سبد درخواست خالیه')
    .max(50, 'حداکثر ۵۰ قلم در هر استعلام'),
})

export type SubmitRfqInput = z.infer<typeof SubmitRfqSchema>
