# Benchmark Dashboard Redesign — Implementation Notes

## Overview
Complete redesign of Price Benchmark dashboard (Tab 7.1 in admin-pricing) with ECharts line chart, TanStack Table for history, and current status display. Also includes Phase 2 database model design for future market observations. Implemented September 12, 2026.

## Changes Made

### Phase 1: Dashboard with Real Data

#### 1. Server Action — Data Fetching

**Location:** `src/app/admin-pricing/actions.ts`

**New Function:** `getBenchmarkDataForGrade(gradeId: string)`

**Returns:**
```typescript
{
  currentPrice: {
    price: number
    sourceType: string
    sourceLabel: string | null
    effectiveDate: string (ISO)
    gradeCode: string
  } | null,
  chartData: Array<{ date: string (ISO), price: number }>,
  historyRecords: Array<{
    id: string
    date: string (ISO)
    approvedAt: string | null (ISO)
    gradeCode: string
    oldPrice: number | null
    newPrice: number
    deviationPercent: number | null
    status: string
    approverName: string | null
  }>
}
```

**Data Sources:**
- **Current price:** `GlobalBenchmarkPrice` where `isActive: true` (1 record per grade)
- **Chart data:** `BenchmarkPublishRecord` where `status: 'approved'`, ordered by `createdAt asc`, limited to 100 records
- **Table data:** Same as chart data, includes all fields for table display

**Date Serialization:** All `Date` objects converted to ISO strings (`toISOString()`) because Server Actions cannot return Date objects across client/server boundary.

#### 2. Client Component Wrapper — Grade Selector + State Management

**Location:** `src/components/Tab7_1BenchinoClient.tsx`

**Props:** `{ grades: Array<{ id: string, code: string }> }`

**State:**
- `selectedGrade` (string) — current grade ID
- `data` (BenchmarkData | null) — fetched data from server action
- `loading` (boolean) — loading state

**Behavior:**
- `useEffect` triggers on `selectedGrade` change
- Calls `getBenchmarkDataForGrade()` server action
- Updates state with response
- Shows loading spinner during fetch
- Shows empty state if no data exists for grade

**UI Elements:**
- Dropdown selector for grades (styled with tokens)
- Loading indicator
- Empty state message when no data
- Renders child components when data available

#### 3. Current Status Card

**Location:** `src/components/BenchmarkCurrentStatus.tsx`

**Props:**
```typescript
{
  price: number
  sourceType: string
  sourceLabel: string | null
  effectiveDate: string (ISO)
  gradeCode: string
}
```

**Display:**
- Large price display (28px, navy color, mono font)
- Grade code
- Source type: "دستی" (manual) or "API"
- Source label (if available)
- Last updated date (Persian calendar)

**Styling:** Uses `colors` tokens from `@/lib/styles/tokens` — card background, borders, text colors all from design system.

#### 4. Line Chart — Price Trend

**Location:** `src/components/BenchmarkPriceChart.tsx`

**Props:**
```typescript
{
  data: Array<{ date: string (ISO), price: number }>
  gradeCode: string
}
```

**Library:** ECharts with `echarts-for-react`

**Chart Configuration:**
- **Type:** Line chart with markers
- **X-axis:** Dates formatted in Persian (short month + day)
- **Y-axis:** Prices formatted with Persian numerals
- **Tooltip:** Shows date + price on hover (Persian format)
- **Line style:** Navy color (`colors.navy` — hex value, NOT CSS variable)
- **Height:** 350px

**Critical Fix Applied:** Uses `colors.navy` (hex: `#1e357b`) directly instead of CSS variable `'var(--navy)'` because ECharts renders on canvas, which cannot resolve CSS variables. This was the final architectural fix approved by user.

#### 5. History Table — TanStack Table

**Location:** `src/components/BenchmarkHistoryTable.tsx`

**Props:**
```typescript
{
  records: Array<{
    id: string
    date: string (ISO)
    approvedAt: string | null
    gradeCode: string
    oldPrice: number | null
    newPrice: number
    deviationPercent: number | null
    status: string
    approverName: string | null
  }>
}
```

**Columns:**
1. تاریخ ثبت (Registration Date) — Persian format
2. گرید (Grade Code)
3. قیمت قدیم (Old Price) — Persian numerals or "—"
4. قیمت جدید (New Price) — Persian numerals
5. تغییر (%) (Change %) — colored badge (green/red/gray)
6. وضعیت (Status) — badge with color coding:
   - `approved` → green badge "تایید"
   - `rejected` → red badge "رد"
   - `pending` → gray badge "در انتظار"
7. تاییدکننده (Approver) — company name or "—"

**Features:**
- Sortable columns (click header to sort)
- Initial sort: date descending (most recent first)
- Empty state message when no records
- Styled with tokens (colors, borders, padding)

**Badge Colors:** Uses status tokens from design system:
- Success: `colors.successBg` + `colors.successText`
- Danger: `colors.dangerBg` + `colors.dangerText`
- Neutral: `colors.neutralBg` + `colors.neutralText`

### Phase 2: Database Model Design (Design Only — No Migration)

#### Purpose
Enable future market observation tracking for scatter plots and boxplots — capturing multiple price points from various sources, not just the final approved benchmark price.

#### Proposed Model

```prisma
model BenchmarkObservation {
  id           String   @id @default(cuid())
  gradeId      String
  grade        Grade    @relation(fields: [gradeId], references: [id], onDelete: Cascade)
  
  // Price and volume
  price        Float    // Observed price (USD/ton or standard unit)
  quantity     Float?   // Transaction volume (tons) — optional, for weighting credibility
  
  // Source
  sourceType   String   // 'transaction' | 'offer' | 'market' | 'api'
  sourceName   String?  // Source identifier (e.g., "ICIS", "Platts", "Company X transaction")
  
  // Verification
  verification String   @default("unverified") // 'verified' | 'unverified' | 'flagged'
  
  // Time
  observedAt   DateTime @default(now()) // Actual observation/transaction time
  createdAt    DateTime @default(now()) // System record time
  
  @@index([gradeId, observedAt])
  @@map("benchmark_observations")
}
```

#### Field Justification

1. **`price` (Float, required):**
   - Core observation — the price seen in market
   - Can come from actual transaction, market offer, or API index

2. **`quantity` (Float, nullable):**
   - Transaction volume for weighting in analysis
   - 100-ton transaction has more credibility than 1-ton offer
   - `null` for prices without specific volume (e.g., API indices)

3. **`sourceType` (String, enum-like):**
   - `'transaction'`: Completed real transaction (highest credibility)
   - `'offer'`: Market offer/bid (medium credibility)
   - `'market'`: General market price without specific volume
   - `'api'`: Automatic feed from external API (ICIS, Platts, etc.)

4. **`sourceName` (String, nullable):**
   - Identifies exact source for audit trail
   - Examples: "Company X transaction", "ICIS Polyethylene Index"

5. **`verification` (String, default 'unverified'):**
   - `'verified'`: Expert-approved observation
   - `'unverified'`: Initial record, needs review
   - `'flagged'`: Suspicious (outlier detection flagged it)
   - Enables future workflow: auto-capture → manual review → approve/flag

6. **`observedAt` vs `createdAt`:**
   - `observedAt`: Actual market event time (important for trend analysis)
   - `createdAt`: System record time (may be delayed)

#### Future Use Cases

**Scatter Plot:** X-axis: time (`observedAt`), Y-axis: price, marker size: quantity
**Boxplot:** Distribution of prices in time window (e.g., this week's range)
**Weighted Average:** Mean price weighted by `quantity`
**Outlier Detection:** Flag prices outside normal range → `verification: 'flagged'`

#### Relationship with Existing Models

- **`GlobalBenchmarkPrice`** remains "official approved price" — single source of truth for pricing engine
- **`BenchmarkObservation`** is "raw market data" — multiple observations feed into analysis, but don't directly affect pricing until human approves
- **`BenchmarkPublishRecord`** remains change history — tracks when official price was updated and why

#### Migration Considerations

**DO NOT implement this migration yet.** This is design-only phase. Before implementing:

1. **Discuss with product owner:**
   - Expected data volume (observations per day/week)
   - Actual external sources to integrate (API feeds, manual entry)
   - Cleanup/archiving strategy (keep how many months?)

2. **Technical planning:**
   - Index strategy (large table will need careful indexing)
   - API integration architecture (cron jobs? webhooks?)
   - Outlier detection algorithm

3. **Data retention:**
   - Archive old observations after N months?
   - Keep aggregated stats but delete raw data?
   - Storage cost estimation

## Architecture — Client/Server Data Flow

```
1. Server Component (admin-pricing/page.tsx)
   ↓ Fetch list of grades from Prisma
   ↓ Pass to Client Component
   
2. Client Component (Tab7_1BenchinoClient)
   ↓ User selects grade from dropdown
   ↓ onChange → setSelectedGrade(gradeId)
   ↓ useEffect triggers
   ↓ Call Server Action: getBenchmarkDataForGrade(gradeId)
   
3. Server Action (actions.ts)
   ↓ Prisma queries:
      - GlobalBenchmarkPrice (current status)
      - BenchmarkPublishRecord (history + chart data)
   ↓ Serialize dates with toISOString()
   ↓ Return JSON-serializable object
   
4. Client Component
   ↓ setData(response)
   ↓ Pass data to child components
   
5. Display Components
   ↓ BenchmarkCurrentStatus (status card)
   ↓ BenchmarkPriceChart (ECharts line chart)
   ↓ BenchmarkHistoryTable (TanStack Table)
```

**Key Point:** Prisma queries run **only on server** (in Server Action). Client Component calls the action and receives serialized data. This avoids "cannot use Prisma in Client Component" error.

## Known Limitations

1. **No Integration with admin-pricing/page.tsx:** Tab7_1BenchinoClient component created but NOT yet integrated into main page. Integration requires:
   - Import `Tab7_1BenchinoClient` in `admin-pricing/page.tsx`
   - Replace existing Tab 7.1 content with new client component
   - Pass `grades` array from server component query

2. **Chart Data Limited to 100 Records:** `getBenchmarkDataForGrade` limits history to 100 approved records. For grades with long history, only most recent 100 changes shown. Adjust `take: 100` if more needed.

3. **No Pagination on Table:** All records (up to 100) load at once. For very active grades, consider adding TanStack Table pagination.

4. **Phase 2 Model Not Implemented:** `BenchmarkObservation` is design-only. No migration, no schema change, no data entry. Scatter/Boxplot features not available until Phase 2 is implemented.

5. **Mobile Responsive:** Components use fixed widths and desktop-optimized layouts. May need media queries for mobile/tablet screens.

## Breaking Changes

None. Phase 1 adds new components without modifying existing logic. Phase 2 is design-only.

## Migration Notes

- **No database migrations required** (Phase 2 is design-only)
- **No environment variables added**
- **Dependencies installed:** `echarts`, `echarts-for-react`, `@tanstack/react-table`

## Testing Checklist

### Phase 1 — Dashboard:
- [ ] Grade selector dropdown displays all grades
- [ ] Selecting grade triggers data fetch
- [ ] Loading state shows during fetch
- [ ] Current status card displays price, source, date
- [ ] Line chart renders with correct data points
- [ ] Chart tooltip shows Persian date + price on hover
- [ ] History table displays all approved records
- [ ] Table columns sortable (click header)
- [ ] Status badges colored correctly (green/red/gray)
- [ ] Empty state shows when no data for grade
- [ ] No console errors in browser
- [ ] ECharts colors render correctly (navy line visible)

### Phase 2 — Design Review:
- [ ] Model design reviewed with product owner
- [ ] Data volume estimates collected
- [ ] External API sources identified
- [ ] Retention policy decided

## Files Modified

**Phase 1 Implementation:**
- `src/app/admin-pricing/actions.ts` — added `getBenchmarkDataForGrade()` (70 lines)

**Phase 1 New Files:**
- `src/components/Tab7_1BenchinoClient.tsx` — 95 lines
- `src/components/BenchmarkCurrentStatus.tsx` — 60 lines
- `src/components/BenchmarkPriceChart.tsx` — 65 lines
- `src/components/BenchmarkHistoryTable.tsx` — 155 lines
- `NOTES-BENCHMARK-DASHBOARD.md` — this file

**Phase 2 (Design Only):**
- No files created (design documented in this NOTES file only)

## References

- Original prompt: `prompt-benchmark-dashboard.md`
- ECharts documentation: https://echarts.apache.org/en/index.html
- TanStack Table: https://tanstack.com/table/latest
- Design tokens: `src/lib/styles/tokens.ts`

## Next Steps

### Immediate (Complete Phase 1):
1. Integrate `Tab7_1BenchinoClient` into `admin-pricing/page.tsx`
2. Test with real data in development environment
3. Verify chart colors render correctly (navy line visible on canvas)

### Future (Phase 2):
1. Discuss Phase 2 model design with product owner
2. Plan API integrations for external price feeds
3. Implement migration for `BenchmarkObservation` model
4. Build data entry UI for manual observations
5. Implement scatter plot / boxplot charts
6. Add outlier detection workflow
