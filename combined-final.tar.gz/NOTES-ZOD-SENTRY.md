# Zod + Sentry + Lucide Integration — Implementation Notes

## Overview
Integration of Zod for Server Action validation, Sentry for error tracking, and Lucide React for icons. Implemented September 12, 2026.

## Changes Made

### 1. Zod Schema Validation

**Schemas Created:**

1. **`src/schemas/rfq.ts`** — RFQ submission validation
   - CartItemSchema: validates gradeId, warehouseId, quantity (max 10,000 tons)
   - SubmitRfqSchema: validates cartItems array (min 1, max 50 items)

2. **`src/schemas/purchaseRequest.ts`** — Purchase request validation
   - Validates: gradeId, quantityTon (max 10,000), maxPriceToman (nullable), deliveryLocation, notes

3. **`src/schemas/article.ts`** — Article CRUD validation
   - Validates: title (max 200 chars), content (max 50,000 chars), publishedAt (nullable Date)

**Actions Updated:**

1. **`src/app/rfq/actions.ts`** — `submitRfq()`
   - Replaced manual validation (`if (cartItems.length === 0)`, `if (item.quantity <= 0)`) with Zod schema
   - Uses `safeParse()` → extracts first error message → throws Error in Persian

2. **`src/app/purchase-requests/actions.ts`** — `createPurchaseRequestAction()`
   - Replaced manual checks (`if (!gradeId)`, `if (!quantityTon)`) with Zod schema
   - Maps form fields to schema (province → deliveryLocation, description → notes)

3. **`src/app/admin-articles/actions.ts`** — `createArticleAction()`, `updateArticleAction()`
   - Replaced `validateArticle()` helper function with Zod schema
   - Removed now-unused `validateArticle()` function (lines 34-39 of original)

**Pattern Used:**
```typescript
const result = Schema.safeParse(data)
if (!result.success) {
  const firstError = Object.values(result.error.flatten().fieldErrors)[0]?.[0] ||
                     result.error.flatten().formErrors[0] ||
                     'ورودی معتبر نیست'
  throw new Error(firstError)
}
// Use result.data (validated and typed)
```

**Actions NOT Covered (candidates for future phases):**

Total Server Actions in project: 90 actions in 25 files

**High Priority (Phase 2):**
- KYC form submissions (`src/app/kyc/actions.ts`)
- Grade document uploads (`src/app/admin-grades/actions.ts`)
- User management actions (`src/app/admin-users/actions.ts`)
- Pricing engine actions (remaining actions in `admin-pricing/actions.ts`)

**Medium Priority (Phase 3):**
- Order status transitions (`src/app/admin-orders/actions.ts`)
- Warehouse stock management (`src/app/admin-warehouses/actions.ts`)
- Material listing admin actions (`src/app/admin-material-listings/actions.ts`)

**Lower Priority (Phase 4+):**
- Remaining 70+ actions across various admin sections

**Why Not Material Listing Creation?**
`src/app/api/material-listings/route.ts` uses Route Handler (not Server Action) because weighbridge ticket images exceed Server Action body size limit (1MB default). Validation is manual inside the route handler — converting it to Zod would require different approach (validating multipart FormData in Route Handler context).

### 2. Lucide React Icons

**Installation:** `npm install lucide-react`

**Status:** Library installed and available for import. No existing code modified.

**Usage:** Reserved for future prompts that require icons (e.g., dashboard redesigns, new UI components).

### 3. Sentry Error Tracking

**Files Created:**

1. **`sentry.client.config.ts`** — Client-side Sentry initialization
   - DSN: `process.env.NEXT_PUBLIC_SENTRY_DSN`
   - Enabled only when DSN is set (safely no-op without it)
   - Filters common browser errors (ResizeObserver, Non-Error promise rejection)
   - Sample rate: 10% of requests

2. **`sentry.server.config.ts`** — Server-side Sentry initialization
   - DSN: `process.env.SENTRY_DSN`
   - Sample rate: 10%

3. **`sentry.edge.config.ts`** — Edge runtime Sentry initialization
   - Same config as server

4. **`instrumentation.ts`** — Next.js instrumentation hook
   - Loads appropriate Sentry config based on runtime (nodejs/edge)
   - Requires `experimental.instrumentationHook: true` in next.config

5. **`next.config.js`** — Next.js configuration with Sentry wrapper
   - Wraps config with `withSentryConfig()`
   - Enables instrumentation hook
   - Configures sourcemap upload (optional, requires SENTRY_AUTH_TOKEN)

6. **`src/app/api/sentry-test/route.ts`** — Test endpoint for Sentry
   - Throws intentional error for testing Sentry integration
   - Visit `/api/sentry-test` to verify error reaches Sentry dashboard

7. **`.env.local.example`** — Environment variable template
   - Documents required Sentry variables
   - Includes instructions for obtaining DSN from Sentry dashboard

**Environment Variables Required:**

```bash
# Required for error tracking
SENTRY_DSN=                      # Server-side DSN (from Sentry dashboard)
NEXT_PUBLIC_SENTRY_DSN=          # Client-side DSN (same value as above)

# Optional — only for build-time sourcemap upload
SENTRY_ORG=                      # Sentry organization slug
SENTRY_PROJECT=                  # Sentry project slug
SENTRY_AUTH_TOKEN=               # Auth token from Sentry settings
```

**How to Get DSN:**

1. Create Sentry account at https://sentry.io
2. Create new project → select "Next.js"
3. Go to Settings → Projects → [Your Project] → Client Keys (DSN)
4. Copy DSN and add to `.env.local` as both `SENTRY_DSN` and `NEXT_PUBLIC_SENTRY_DSN`

**Behavior Without DSN:**

Sentry is **safely disabled** when DSN is not set:
- No errors thrown
- No network requests made
- Application runs normally
- Errors logged to console only (standard Next.js behavior)

This allows local development without Sentry account, while production can use it once DSN is configured.

**Testing Sentry:**

After adding DSN to `.env.local`:
1. Restart dev server: `npm run dev`
2. Visit: `http://localhost:3000/api/sentry-test`
3. Check Sentry dashboard → Issues → should see the test error

**Prisma Tracing:**

Sentry does not currently have official Prisma integration. If added in future Sentry versions, enable with:
```typescript
import { PrismaInstrumentation } from '@prisma/instrumentation'
Sentry.addIntegration(new PrismaInstrumentation())
```

## Known Limitations

1. **Zod Coverage:** Only 4 Server Actions (out of 90) use Zod validation. Remaining 86 actions listed in NOTES for future phases.

2. **Material Listing:** Route handler validation not converted to Zod (requires different pattern for multipart FormData with file uploads).

3. **Breaking Changes:** Zod schemas enforce stricter validation than previous manual checks:
   - RFQ: maximum 50 items per request (previously unlimited)
   - RFQ: maximum 10,000 tons per item (previously unlimited)
   - Purchase Request: maximum 10,000 tons (previously unlimited)
   - Article: exact character limits enforced (200 for title, 50,000 for content)

   These limits are sensible defaults to prevent abuse/mistakes. If legitimate use cases exceed them, adjust schema maximums.

4. **Sentry Sourcemaps:** Optional `SENTRY_AUTH_TOKEN` uploads sourcemaps during build for better stack traces in production. Not required for basic error tracking.

5. **Lucide Icons:** Library installed but not yet used in codebase. Reserved for future UI work.

## Migration Notes

- **No database migrations required**
- **No environment variables required for local dev** (Sentry gracefully disabled without DSN)
- **Zod validates same rules as before** — existing forms work unchanged, now with type safety

## Testing Checklist

### Zod Validation:
- [ ] RFQ submission with empty cart → error "سبد درخواست خالیه"
- [ ] RFQ submission with quantity 0 → error "مقدار باید بیشتر از صفر باشه"
- [ ] RFQ submission with 51 items → error "حداکثر ۵۰ قلم در هر استعلام"
- [ ] Purchase request with no gradeId → error "گرید مشخص نیست"
- [ ] Article creation with empty title → error "عنوان مقاله خالیه"
- [ ] Article creation with 201-char title → error "عنوان خیلی بلنده"

### Sentry (after adding DSN):
- [ ] Visit `/api/sentry-test` → error appears in Sentry dashboard
- [ ] Trigger validation error → logged to Sentry
- [ ] Server Action throws error → logged to Sentry
- [ ] Client-side error → logged to Sentry

### Lucide:
- [ ] Import works: `import { Check } from 'lucide-react'`
- [ ] No need to test usage (not implemented yet)

## Files Modified

**Zod Integration:**
- `src/app/rfq/actions.ts` — 42 lines (replaced manual validation)
- `src/app/purchase-requests/actions.ts` — 35 lines (replaced manual validation)
- `src/app/admin-articles/actions.ts` — 112 lines (replaced validateArticle helper)

**Sentry Integration:**
- `next.config.js` — created (14 lines)
- `sentry.client.config.ts` — created (13 lines)
- `sentry.server.config.ts` — created (7 lines)
- `sentry.edge.config.ts` — created (7 lines)
- `instrumentation.ts` — created (9 lines)
- `src/app/api/sentry-test/route.ts` — created (3 lines)
- `.env.local.example` — created (12 lines)

**Zod Schemas:**
- `src/schemas/rfq.ts` — created (18 lines)
- `src/schemas/purchaseRequest.ts` — created (16 lines)
- `src/schemas/article.ts` — created (13 lines)

## References

- Zod documentation: https://zod.dev
- Sentry Next.js guide: https://docs.sentry.io/platforms/javascript/guides/nextjs/
- Lucide React: https://lucide.dev/guide/packages/lucide-react

## Next Steps (Future Phases)

**Phase 2 — Zod:**
- Add schemas for KYC forms (4-5 actions)
- Add schemas for grade document uploads
- Add schemas for user management

**Phase 2 — Sentry:**
- Add custom context to errors (userId, companyName, request metadata)
- Set up alerts for critical errors (payment failures, KYC errors)
- Configure release tracking with git SHA

**Lucide:**
- Will be used in future UI redesigns when icons are needed
