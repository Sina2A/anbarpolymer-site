# NOTES — مگاتسک: ناوبری، هدر، پیشخوان موبایل و صفحه‌بندی

**تایید:** `npx tsc --noEmit` → EXIT 0
**قواعد:** بدون داده‌ی جعلی / دسکتاپ فقط در موارد صریح تغییر کرده / commit نشده

---

## بخش ۱ — ناوبری پایین موبایل (مهمان + کاربر)

- `src/lib/mobileNavItems.ts`: `USER_BOTTOM_TABS` جدید با ۵ تب: خانه، پیشخوان `/dashboard` (تب دوم)، بازار صنعتی، گزارش بازار، تماس با ما. `GUEST_BOTTOM_TABS` دست‌نخورده.
- ۴ آیتم منتقل‌شده (حساب من، سفارش‌ها، بازار من، معاملات و حمل) به ابتدای `USER_SHEET_ITEMS` — هیچ آیتمی گم نشده.
- `src/components/mobile/UserBottomNav.tsx`: تب خانه از `homeHref` استفاده می‌کند (قانون سطح‌ها).
- `globals.css`: زیر ۹۰۰px فونت تب‌ها 9.5px + فشرده‌سازی padding/gap نوار (مهمان هم همان CSS را دارد و ظرفیتش بیشتر است).

## بخش ۲ — باگ ناوبری دسکتاپ

- `src/components/UserNav.tsx`: «هشدار قیمت» → `href:'/price-alerts', isReal:true` (قبلاً `#` بود).

## بخش ۳ — MoreSheet

- `globals.css` `.mobile-sheet-item`: `font-family:inherit` (دکمه‌ی خروج مثل بقیه IRANYekanX می‌شود).
- `padding` آیتم 11px→9px، font-size 13→12، gap 10→8، آیکون 19→18 (MoreSheet.tsx) — ~۱۴ آیتم بدون اسکرول جا می‌شود.

## بخش ۴ — هم‌اندازه‌سازی سه دکمه‌ی هدر

- `PublicHeader.tsx` `acctBtnStyle` + `PanelHeader.tsx` `backToSiteStyle`: height مشترک **36px**، fontSize مشترک **14.5px** (+ fontFamily/fontWeight/lineHeight یکسان). دسکتاپ و موبایل هر دو.

## بخش ۵ — پیشخوان موبایل: Bento Grid دوستونه

- `src/app/dashboard/page.tsx` + `loading.tsx` (+ `SkeletonCard.tsx`): زیر ۸۹۹px چیدمان Bento با کلاس‌های `dash-m-grid` / `dash-m-hero` / `dash-m-wide` / `dash-m-actions` در globals.css:
  1. دو کارت قهرمان نیم‌عرض (سفارش‌های ثبت‌شده + محموله در حال حمل)
  2. کارت تمام‌عرض «آگهی فعال»
  3. شبکه‌ی اقدام‌ها دوستونه (۶ اقدام، آیکون + عنوان + badge، توضیح حذف در موبایل)
  4. فعالیت اخیر تمام‌عرض پایین
- رندر دسکتاپ (inline فعلی) بدون تغییر.

## بخش ۶ — صفحه‌بندی + شماره‌گذاری پایدار (۵ صفحه)

**روش شماره‌گذاری:** `orderBy:[{createdAt:'desc'},{id:'asc'}]` (support: `[{updatedAt:'desc'},{id:'asc'}]`) — tiebreaker پایدار id (cuid). شماره‌ی ردیف = `(page-1)*perPage + i + 1` (دسته‌ی الف) یا `i + 1` (دسته‌ی ب).

### دسته‌ی الف — صفحه‌بندی کامل
- `src/components/Pagination.tsx` (جدید): server component، props `{page, totalPages, buildPageHref}`، پنجره ±۳، قبلی/بعدی، ellipsis، اعداد `fa-IR`.
- `globals.css`: کلاس عمومی `.pagination` (برگرفته از الگوی transport) + `.per-page-row`.
- `/proformas`: Pagination بالای لیست داخل Container، شماره‌ی ردیف، فرم GET «تعداد در صفحه» (10/20/30، default 20) پایین — تغییر perPage صفحه را به ۱ برمی‌گرداند (پارامتر page در فرم نیست). `enforceProformaDeadlines()` قبل از findMany مانده.
- `/custom-request`: همان الگو + حفظ `?grade=` در buildPageHref (encodeURIComponent) و hidden input در فرم per-page.

### دسته‌ی ب — فقط اسکرول داخلی (`.scroll-panel`)
- `globals.css`: `.scroll-panel` (دسکتاپ max-height `calc(100vh - 220px)`، موبایل 70vh، overflow-y auto) + `.scroll-section-title` (sticky).
- `/my-listings`, `/support`: لیست داخل Container والد اسکرول‌شونده + شماره‌ی ردیف `i + 1`.
- `/price-alerts`: یک Container واحد هر دو بخش (فعال + فعال‌شده)، عنوان بخش‌ها sticky، شماره‌گذاری مستقل از ۱ در هر گروه.

---

## فایل‌های تغییر‌یافته

| فایل | بخش |
|---|---|
| `src/lib/mobileNavItems.ts` | ۱ |
| `src/components/mobile/UserBottomNav.tsx` | ۱ |
| `src/components/UserNav.tsx` | ۲ |
| `src/components/mobile/MoreSheet.tsx` | ۳ |
| `src/app/globals.css` | ۱، ۳، ۵، ۶ |
| `src/components/PublicHeader.tsx` | ۴ |
| `src/components/PanelHeader.tsx` | ۴ |
| `src/app/dashboard/page.tsx` | ۵ |
| `src/app/dashboard/loading.tsx` | ۵ |
| `src/components/SkeletonCard.tsx` | ۵ |
| `src/components/Pagination.tsx` (جدید) | ۶ |
| `src/app/proformas/page.tsx` | ۶ الف |
| `src/app/custom-request/page.tsx` | ۶ الف |
| `src/app/my-listings/page.tsx` | ۶ ب |
| `src/app/price-alerts/page.tsx` | ۶ ب |
| `src/app/support/page.tsx` | ۶ ب |
