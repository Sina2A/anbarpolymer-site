import prisma from '@/lib/prisma'
import { getSurfaceHome } from '@/lib/surfaceHome'
import { getCurrentUser } from '@/lib/currentUser'
import UserNav from '@/components/UserNav'
import PanelHeader from '@/components/PanelHeader'
import Footer from '@/components/Footer'
import { enforceProformaDeadlines } from '@/lib/dealDeadlines'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { cardStyle as sharedCardStyle, badgeStyle, emptyStateStyle, orderStatusBadgeStyle, getOrderStatusLabel } from '@/lib/styles/shared'
import Pagination from '@/components/Pagination'

export const dynamic = 'force-dynamic'

type SearchParams = Promise<Record<string, string | string[] | undefined>>

function one(v: string | string[] | undefined): string | undefined {
  if (Array.isArray(v)) return v[0]
  return v
}

/**
 * صفحه‌ی لیست «پیش‌فاکتورهای من» — فقط سفارش‌هایی که کارشناس قیمت‌گذاری کرده
 * (status: priced) یا مشتری تایید کرده و در مرحله‌ی قرارداد (buyer_confirmed / contracted).
 *
 * وضعیت‌های واقعی از workflow.ts:
 *   priced → buyer_confirmed → contracted
 */

const STATUS_LABELS: Record<string, string> = {
  priced: 'در انتظار تایید شما',
  buyer_confirmed: 'تایید شد — در حال عقد قرارداد',
  contracted: getOrderStatusLabel('contracted'),
}

export default async function ProformasPage({ searchParams }: { searchParams: SearchParams }) {
  const user = await getCurrentUser()
  const sp = await searchParams

  // صفحه‌بندی — تعداد در صفحه ۱۰/۲۰/۳۰، پیش‌فرض ۲۰
  const perPageRaw = parseInt(one(sp.perPage) ?? '20', 10)
  const perPage = [10, 20, 30].includes(perPageRaw) ? perPageRaw : 20
  const total = await prisma.order.count({
    where: {
      userId: user.id,
      status: { in: ['priced', 'buyer_confirmed', 'contracted'] },
    },
  })
  const totalPages = Math.max(1, Math.ceil(total / perPage))
  const pageRaw = parseInt(one(sp.page) ?? '1', 10)
  const page = Math.min(Math.max(1, isNaN(pageRaw) ? 1 : pageRaw), totalPages)

  const buildPageHref = (p: number) => `/proformas?page=${p}&perPage=${perPage}`

  // مثل بقیه‌ی مهلت‌ها (بدون cron): موقع لود این صفحه، سفارش‌هایی که مهلت
  // تاییدشون گذشته خودکار باطل و موجودیشون به انبار برمی‌گرده.
  await enforceProformaDeadlines()

  const orders = await prisma.order.findMany({
    where: {
      userId: user.id,
      status: { in: ['priced', 'buyer_confirmed', 'contracted'] },
    },
    include: { items: { include: { grade: true } } },
    orderBy: [{ createdAt: 'desc' }, { id: 'asc' }],
    skip: (page - 1) * perPage,
    take: perPage,
  })

  return (
    <>
    <PanelHeader homeHref={getSurfaceHome()} currentUserName={user.companyName} />
    <div style={pageStyle}>
      <div style={{ width: '100%', display: 'flex', gap: 24 }} className="admin-page-wrap">
        <UserNav currentUserName={user.companyName} activeSection="proformas" />
        <div style={{ flex: 1, minWidth: 0 }}>
          <h1 style={{ fontSize: fontSize.xxl, fontWeight: 800, marginBottom: spacing.xs, color: colors.textPrimary }}>پیش‌فاکتورهای من</h1>
          <p style={{ fontSize: fontSize.base, color: colors.textMuted, marginBottom: spacing.xl }}>
            سفارش‌هایی که قیمت‌گذاری شدن و منتظر تایید یا در مرحله‌ی قرارداد هستن
          </p>

          {total === 0 && (
            <div style={emptyBox}>
              هیچ پیش‌فاکتور فعالی ندارید — وقتی کارشناس فروش قیمت سفارش شما را ثبت کنه، اینجا نمایش داده می‌شه.
            </div>
          )}

          {total > 0 && (
            <div style={listContainerStyle}>
              <div style={{ marginBottom: spacing.md }}>
                <Pagination page={page} totalPages={totalPages} buildPageHref={buildPageHref} />
              </div>

              {orders.map((order, i) => {
            const gradeSummary = order.items.map((i) => i.grade.code).join(' + ')
            const totalRial = order.items.reduce(
              (sum, it) => sum + (it.finalPrice ?? it.price) * it.quantity,
              0
            )

            return (
              <a key={order.id} href={`/proformas/${order.id}`} style={cardLink}>
                <div style={cardStyle}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.md }}>
                    <b style={{ fontSize: fontSize.md }}>
                      {(page - 1) * perPage + i + 1}. سفارش #{order.id.slice(0, 8)}
                    </b>
                    <span style={orderStatusBadgeStyle(order.status)}>{STATUS_LABELS[order.status] || order.status}</span>
                  </div>

                  <div style={{ fontSize: fontSize.sm, color: colors.neutralText, marginBottom: 6 }}>
                    <span style={{ fontFamily: 'monospace' }}>{gradeSummary}</span>
                  </div>

                  {order.status === 'priced' && order.proformaDeadline && (
                    <div style={{ fontSize: fontSize.sm, color: colors.warningText, marginBottom: 6 }}>
                      ⏳ مهلت تایید: {new Date(order.proformaDeadline).toLocaleString('fa-IR', { dateStyle: 'short', timeStyle: 'short' })} — بعد از این زمان سفارش خودکار باطل می‌شود
                    </div>
                  )}

                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: fontSize.sm, fontWeight: 700 }}>
                      {totalRial.toLocaleString('en-US')} ریال
                    </span>
                    <span style={{ fontSize: fontSize.xs, color: colors.textMuted }}>
                      {new Date(order.createdAt).toLocaleDateString('fa-IR')}
                    </span>
                  </div>
                </div>
              </a>
            )
          })}

              {/* تعداد در صفحه — تغییر آن صفحه را به ۱ برمی‌گرداند */}
              <form method="get" action="/proformas" className="per-page-row">
                <span>تعداد در صفحه:</span>
                <select name="perPage" defaultValue={String(perPage)}>
                  <option value="10">۱۰</option>
                  <option value="20">۲۰</option>
                  <option value="30">۳۰</option>
                </select>
                <button type="submit" style={perPageBtnStyle}>اعمال</button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
    <Footer homeHref={getSurfaceHome()} />
  </>
)
}

const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: colors.bgCard,
  padding: `${spacing.xxl}px ${spacing.xl}px`,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const emptyBox: React.CSSProperties = {
  ...emptyStateStyle,
  padding: 32,
}
const cardLink: React.CSSProperties = {
  display: 'block',
  textDecoration: 'none',
  color: 'inherit',
}
const cardStyle: React.CSSProperties = {
  ...sharedCardStyle,
  padding: 18,
  marginBottom: 14,
  transition: 'border-color .15s',
}
const listContainerStyle: React.CSSProperties = {
  ...sharedCardStyle,
  padding: 16,
}
const perPageBtnStyle: React.CSSProperties = {
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.md,
  background: colors.bgCard,
  color: colors.textSecondary,
  fontSize: fontSize.xs,
  fontWeight: 600,
  padding: '4px 12px',
  cursor: 'pointer',
}
