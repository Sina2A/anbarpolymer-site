// src/components/Pagination.tsx
//
// صفحه‌بندی مشترک — بر اساس الگوی transport-shipments-pagination
// کامپوننت سرور؛ اعداد فارسی؛ پنجره‌ی ±۳.

type Props = {
  page: number
  totalPages: number
  /** href کامل صفحه‌ی موردنظر (پارامترهای موجود مثل ?grade= را باید حفظ کند) */
  buildPageHref: (page: number) => string
}

const WINDOW = 3

export default function Pagination({ page, totalPages, buildPageHref }: Props) {
  if (totalPages <= 1) return null

  const from = Math.max(1, page - WINDOW)
  const to = Math.min(totalPages, page + WINDOW)
  const pages: number[] = []
  for (let p = from; p <= to; p++) pages.push(p)

  return (
    <nav className="pagination" aria-label="صفحه‌بندی">
      {page > 1 ? (
        <a href={buildPageHref(page - 1)}>قبلی</a>
      ) : (
        <span className="is-disabled">قبلی</span>
      )}

      {from > 1 && (
        <>
          <a href={buildPageHref(1)}>{(1).toLocaleString('fa-IR')}</a>
          {from > 2 && <span className="is-disabled">…</span>}
        </>
      )}

      {pages.map((p) =>
        p === page ? (
          <a key={p} href={buildPageHref(p)} className="is-active" aria-current="page">
            {p.toLocaleString('fa-IR')}
          </a>
        ) : (
          <a key={p} href={buildPageHref(p)}>
            {p.toLocaleString('fa-IR')}
          </a>
        ),
      )}

      {to < totalPages && (
        <>
          {to < totalPages - 1 && <span className="is-disabled">…</span>}
          <a href={buildPageHref(totalPages)}>{totalPages.toLocaleString('fa-IR')}</a>
        </>
      )}

      {page < totalPages ? (
        <a href={buildPageHref(page + 1)}>بعدی</a>
      ) : (
        <span className="is-disabled">بعدی</span>
      )}
    </nav>
  )
}
