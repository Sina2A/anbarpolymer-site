// src/components/SkeletonCard.tsx
//
// کارت skeleton با چند خط shimmer

import SkeletonLine from './SkeletonLine'
import { colors, spacing, radius } from '@/lib/styles/tokens'
import type { CSSProperties } from 'react'

type Props = {
  height?: number
  lines?: number
  className?: string
}

export default function SkeletonCard({ height = 120, lines = 3, className }: Props) {
  const cardStyle: CSSProperties = {
    background: colors.bgCard,
    border: `1px solid ${colors.borderSubtle}`,
    borderRadius: radius.lg,
    padding: spacing.md,
    height,
    display: 'flex',
    flexDirection: 'column',
    gap: spacing.xs,
  }

  const widths = ['100%', '80%', '60%']

  return (
    <div style={cardStyle} className={className}>
      {Array.from({ length: lines }).map((_, i) => (
        <SkeletonLine key={i} width={widths[i % widths.length]} />
      ))}
    </div>
  )
}
