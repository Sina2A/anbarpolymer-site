'use client'

// src/components/mobile/MoreSheet.tsx
//
// Bottom Sheet مشترک «بیشتر» — هم برای مهمان هم کاربر لاگین‌شده؛ فقط لیست
// آیتم‌ها به‌صورت prop می‌آید. دکمه‌ی بازکننده جدا است و در هدر رندر می‌شود
// (PublicHeader) یا از تب «حساب من» (UserBottomNav) — این کامپوننت فقط خودِ
// شیت + اسکریم را دارد.
//
// طبق قانون سطح‌ها: هیچ process.env.SURFACE ای اینجا نیست؛ لینک خانه لازم
// ندارد چون آیتم‌های شیت همه href مطلق دارند.

import { useEffect } from 'react'
import { X, LogOut } from 'lucide-react'
import { logoutAction } from '@/app/logout/actions'
import type { MobileSheetItem } from '@/lib/mobileNavItems'

export default function MoreSheet({
  items,
  open,
  onClose,
  title,
}: {
  items: MobileSheetItem[]
  open: boolean
  onClose: () => void
  title: string
}) {
  // بستن با Escape — دسترس‌پذیری پایه
  useEffect(() => {
    if (!open) return
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [open, onClose])

  // قفل اسکرول بدنه وقتی شیت باز است
  useEffect(() => {
    if (!open) return
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      document.body.style.overflow = prev
    }
  }, [open])

  if (!open) return null

  return (
    <>
      <button
        type="button"
        className="mobile-sheet-scrim open"
        aria-label="بستن منوی بیشتر"
        onClick={onClose}
      />
      <div className="mobile-sheet open" role="dialog" aria-modal="true" aria-label={title}>
        <div className="mobile-sheet-handle" aria-hidden="true" />
        <div className="mobile-sheet-head">
          <span className="mobile-sheet-title">{title}</span>
          <button
            type="button"
            className="mobile-sheet-close"
            aria-label="بستن"
            onClick={onClose}
          >
            <X size={18} strokeWidth={2.2} />
          </button>
        </div>
        <nav className="mobile-sheet-list">
          {items.map((item) => {
            const Icon = item.isLogout ? LogOut : item.icon
            if (item.isLogout) {
              return (
                <form key={item.label} action={logoutAction} className="mobile-sheet-form">
                  <button type="submit" className="mobile-sheet-item mobile-sheet-item-logout">
                    <Icon size={18} strokeWidth={1.9} />
                    <span>{item.label}</span>
                  </button>
                </form>
              )
            }
            return (
              <a
                key={item.label}
                href={item.href}
                className="mobile-sheet-item"
                onClick={onClose}
              >
                <Icon size={18} strokeWidth={1.9} />
                <span>{item.label}</span>
              </a>
            )
          })}
        </nav>
      </div>
    </>
  )
}
