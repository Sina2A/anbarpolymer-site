'use client'

import { usePathname } from 'next/navigation'
import { USER_BOTTOM_TABS, isActivePath } from '@/lib/mobileNavItems'

export default function UserBottomNav({ homeHref = '/' }: { homeHref?: string }) {
  const pathname = usePathname()
  return (
    <div className="mobile-bottom-nav-wrap" data-mobile-nav="user">
      <nav className="mobile-bottom-nav" aria-label="ناوبری موبایل پنل کاربری">
        {USER_BOTTOM_TABS.map((tab) => {
          const href = tab.href === '/' ? homeHref : tab.href
          const active = isActivePath(pathname, tab.href)
          const Icon = tab.icon
          return (
            <a key={tab.label} href={href} className={`mobile-nav-item${active ? ' active' : ''}`} aria-current={active ? 'page' : undefined}>
              <Icon size={16} strokeWidth={active ? 2.3 : 1.8} />
              <span>{tab.label}</span>
            </a>
          )
        })}
      </nav>
    </div>
  )
}
