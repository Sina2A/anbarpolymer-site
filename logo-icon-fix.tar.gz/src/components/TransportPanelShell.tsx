'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useEffect, useState, type ReactNode } from 'react'
import { BrandCoin } from '@/components/BrandMark'
import { logoutAction } from '@/app/logout/actions'

const Icon = ({ children }: { children: ReactNode }) => (
  <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    {children}
  </svg>
)

const navItems = [
  { label: 'پیشخوان', href: '/transport-panel', exact: true, icon: <Icon><rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" /><rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" /></Icon> },
  { label: 'محموله‌های جاری', href: '/transport-panel/current', icon: <Icon><path d="M3 7h11v10H3z" /><path d="M14 10h4l3 3v4h-7z" /><circle cx="7" cy="18" r="2" /><circle cx="17" cy="18" r="2" /></Icon> },
  { label: 'تاریخچه‌ی محموله‌ها', href: '/transport-panel/history', icon: <Icon><path d="M3 12a9 9 0 1 0 3-6.7L3 8" /><path d="M3 3v5h5M12 7v5l3 2" /></Icon> },
  { label: 'راننده‌ها', href: '/transport-panel#drivers', exact: true, icon: <Icon><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></Icon> },
  { label: 'افزودن راننده', href: '/transport-panel#add-driver', exact: true, icon: <Icon><circle cx="9" cy="8" r="4" /><path d="M2 21a7 7 0 0 1 14 0M19 8v6M16 11h6" /></Icon> },
]

export default function TransportPanelShell({ companyName, children }: { companyName: string; children: ReactNode }) {
  const pathname = usePathname()
  const [menuOpen, setMenuOpen] = useState(false)
  const [currentHash, setCurrentHash] = useState('')

  useEffect(() => {
    const syncHash = () => setCurrentHash(window.location.hash)
    syncHash()
    window.addEventListener('hashchange', syncHash)
    return () => window.removeEventListener('hashchange', syncHash)
  }, [pathname])

  useEffect(() => setMenuOpen(false), [pathname, currentHash])

  return (
    <div className="transport-panel-shell" dir="rtl">
      <header className="transport-panel-header">
        <a className="transport-panel-brand" href="/">
          <BrandCoin coin={44} mark={36} />
          <span>انبار پلیمر</span>
        </a>
        <a className="transport-panel-support" href="tel:+982191234567">
          <Icon><path d="M4 14v-2a8 8 0 0 1 16 0v2" /><path d="M4 14h3v6H5a2 2 0 0 1-2-2v-2a2 2 0 0 1 1-2ZM20 14h-3v6h2a2 2 0 0 0 2-2v-2a2 2 0 0 0-1-2Z" /></Icon>
          <span><b>پشتیبانی فنی</b><small>۰۲۱-۹۱۲۳۴۵۶۷</small></span>
        </a>
        <div className="transport-panel-profile">
          <span className="transport-panel-avatar"><Icon><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></Icon></span>
          <span><small>مدیر شرکت حمل‌ونقل</small><b>{companyName}</b></span>
          <span className="transport-panel-profile-caret" aria-hidden="true">⌄</span>
        </div>
        <button className="transport-panel-menu-button" type="button" aria-label="باز کردن فهرست پنل" aria-expanded={menuOpen} onClick={() => setMenuOpen((open) => !open)}>
          <Icon><path d="M4 6h16M4 12h16M4 18h16" /></Icon>
        </button>
      </header>

      <div className="transport-panel-body">
        {menuOpen && <button className="transport-panel-overlay" type="button" aria-label="بستن فهرست پنل" onClick={() => setMenuOpen(false)} />}
        <aside className={`transport-panel-sidebar${menuOpen ? ' is-open' : ''}`}>
          <nav aria-label="ناوبری پنل حمل‌ونقل">
            {navItems.map((item) => {
              const [itemPath, itemHash = ''] = item.href.split('#')
              const active = item.exact
                ? pathname === itemPath && currentHash === (itemHash ? `#${itemHash}` : '')
                : pathname.startsWith(item.href)
              return <Link key={item.label} href={item.href} className={active ? 'active' : undefined}>{item.icon}<span>{item.label}</span></Link>
            })}
            <span className="transport-panel-nav-disabled" aria-disabled="true">
              <Icon><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1A1.7 1.7 0 0 0 9 4.6 1.7 1.7 0 0 0 10 3V2.8h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z" /></Icon>
              <span>تنظیمات <small>به‌زودی</small></span>
            </span>
          </nav>
          <form action={logoutAction} className="transport-panel-logout"><button type="submit">خروج از حساب</button></form>
        </aside>
        <main className="transport-panel-main">{children}</main>
      </div>
    </div>
  )
}
