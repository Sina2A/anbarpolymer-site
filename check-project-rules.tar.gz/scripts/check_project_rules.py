#!/usr/bin/env python3
"""
scripts/check_project_rules.py

بررسی ۴ قاعده‌ی قابل‌اتوماسیون این پروژه:
۱. صفحات عمومی باید getCurrentUserOrNull صدا بزنن (هدر شخصی‌سازی‌شده)
۲. صفحات عمومی باید CurrencyTicker داشته باشن
۳. هیچ‌جای کدبیس نباید include:{user:true} کامل باشه (نشتی passwordHash)
۴. اسم فایل آپلودی نباید مستقیم از ورودی کاربر (file.name) ساخته بشه

اجرا: python3 scripts/check_project_rules.py
(از ریشه‌ی پروژه)

⚠️ رول‌های ۳ و ۴ heuristic هستن (بر پایه‌ی الگوی متنی، نه تحلیل واقعی نوع)،
پس ممکنه false-positive بدن — نتیجه رو دستی هم مرور کن.
این اسکریپت فقط می‌خونه، هیچ فایلی رو تغییر نمی‌ده.
"""

import os
import re
import sys

ROOT = os.getcwd()
APP_DIR = os.path.join(ROOT, "src", "app")
SRC_DIR = os.path.join(ROOT, "src")

# ──────────────────────────────────────────────────────────
# رول ۱ و ۲ — فقط صفحات عمومی شناخته‌شده
# ──────────────────────────────────────────────────────────
PUBLIC_PAGE_DIRS = [
    "", "market", "grades", "grades/[code]", "warehouses",
    "contact", "about", "services", "reports", "reports/[id]",
]

LOGIN_TEXT_PATTERNS = [r"ورود\s*/\s*ثبت‌نام", r">ورود<"]
AUTH_CHECK_PATTERNS = [r"getCurrentUserOrNull", r"getCurrentUser\b"]
CURRENCY_TICKER_PATTERN = r"CurrencyTicker"

# ──────────────────────────────────────────────────────────
# رول ۳ و ۴ — کل کدبیس
# ──────────────────────────────────────────────────────────
# فیلدهای رابطه‌ای که به مدل User اشاره می‌کنن — include:{field:true} خطرناکه
USER_RELATION_FIELDS = [
    "user", "author", "raisedBy", "resolvedBy", "publishedBy",
    "approvedBy", "buyer", "seller",
]

UPLOAD_CALL_PATTERNS = [r"writeFile", r"createWriteStream", r"\.save\(", r"fs\.write"]
RISKY_FILENAME_PATTERNS = [r"file\.name\b", r"\.originalname\b", r"formData\.get\([^)]+\)\.name\b"]


def read_file(path):
    try:
        with open(path, encoding="utf-8") as f:
            return f.read()
    except (FileNotFoundError, UnicodeDecodeError):
        return None


def walk_ts_files(base_dir):
    for dirpath, _dirnames, filenames in os.walk(base_dir):
        if "node_modules" in dirpath or ".next" in dirpath:
            continue
        for fn in filenames:
            if fn.endswith(".ts") or fn.endswith(".tsx"):
                yield os.path.join(dirpath, fn)


# ──────────────────────────────────────────────────────────
# رول ۱ و ۲
# ──────────────────────────────────────────────────────────
def check_public_page(rel_dir):
    dir_path = os.path.join(APP_DIR, rel_dir) if rel_dir else APP_DIR
    page_path = os.path.join(dir_path, "page.tsx")
    content = read_file(page_path)
    label = f"/{rel_dir}" if rel_dir else "/"

    if content is None:
        return {"path": label, "exists": False}

    has_login_text = any(re.search(p, content) for p in LOGIN_TEXT_PATTERNS)
    has_auth_check = any(re.search(p, content) for p in AUTH_CHECK_PATTERNS)
    has_ticker = re.search(CURRENCY_TICKER_PATTERN, content) is not None

    return {
        "path": label,
        "exists": True,
        "rule1_fail": has_login_text and not has_auth_check,
        "rule2_fail": not has_ticker,
    }


# ──────────────────────────────────────────────────────────
# رول ۳ — include:{user:true} کامل
# ──────────────────────────────────────────────────────────
def check_rule3():
    findings = []
    for path in walk_ts_files(SRC_DIR):
        content = read_file(path)
        if not content:
            continue
        for field in USER_RELATION_FIELDS:
            # الگو: fieldName: true  (نه fieldName: { select: ...})
            pattern = rf"\b{field}\s*:\s*true\b"
            for m in re.finditer(pattern, content):
                line_no = content[: m.start()].count("\n") + 1
                findings.append((os.path.relpath(path, ROOT), line_no, field))
    return findings


# ──────────────────────────────────────────────────────────
# رول ۴ — اسم فایل آپلودی از ورودی کاربر
# ──────────────────────────────────────────────────────────
def check_rule4():
    findings = []
    for path in walk_ts_files(SRC_DIR):
        content = read_file(path)
        if not content:
            continue
        has_upload_call = any(re.search(p, content) for p in UPLOAD_CALL_PATTERNS)
        if not has_upload_call:
            continue
        for pattern in RISKY_FILENAME_PATTERNS:
            for m in re.finditer(pattern, content):
                line_no = content[: m.start()].count("\n") + 1
                findings.append((os.path.relpath(path, ROOT), line_no, m.group(0)))
    return findings


def main():
    print("=" * 60)
    print("=== رول ۱ و ۲ — صفحات عمومی (هدر شخصی‌سازی‌شده + تیکر) ===")
    print("=" * 60)
    page_results = [check_public_page(d) for d in PUBLIC_PAGE_DIRS]
    rule1_fails = [r for r in page_results if r["exists"] and r.get("rule1_fail")]
    rule2_fails = [r for r in page_results if r["exists"] and r.get("rule2_fail")]
    missing = [r for r in page_results if not r["exists"]]

    if not rule1_fails:
        print("رول ۱ (getCurrentUserOrNull): همه سالم ✅")
    else:
        print(f"رول ۱ — {len(rule1_fails)} صفحه با هدر ثابت (بدون چک لاگین):")
        for r in rule1_fails:
            print(f"  ⚠️  {r['path']}")

    if not rule2_fails:
        print("رول ۲ (CurrencyTicker): همه سالم ✅")
    else:
        print(f"رول ۲ — {len(rule2_fails)} صفحه بدون تیکر نرخ ارز:")
        for r in rule2_fails:
            print(f"  ⚠️  {r['path']}")

    if missing:
        print(f"\n⚠️ {len(missing)} مسیر پیدا نشد: {', '.join(r['path'] for r in missing)}")

    print()
    print("=" * 60)
    print("=== رول ۳ — نشتی احتمالی include:{user:true} (کل کدبیس) ===")
    print("=" * 60)
    r3 = check_rule3()
    if not r3:
        print("هیچی — همه‌جا امن به‌نظر می‌رسه ✅\n")
    else:
        print(f"{len(r3)} مورد مشکوک پیدا شد (ممکنه false-positive باشه، دستی چک کن):")
        for path, line, field in r3:
            print(f"  ⚠️  {path}:{line} — «{field}: true»")
        print()

    print("=" * 60)
    print("=== رول ۴ — اسم فایل آپلودی از ورودی کاربر (کل کدبیس) ===")
    print("=" * 60)
    r4 = check_rule4()
    if not r4:
        print("هیچی — الگوی مشکوکی پیدا نشد ✅\n")
    else:
        print(f"{len(r4)} مورد مشکوک پیدا شد (heuristic، حتماً دستی چک کن):")
        for path, line, match in r4:
            print(f"  ⚠️  {path}:{line} — «{match}»")
        print()

    print("=" * 60)
    print("=== خلاصه ===")
    print("=" * 60)
    print(f"رول ۱ (هدر): {len(rule1_fails)} مشکل")
    print(f"رول ۲ (تیکر): {len(rule2_fails)} مشکل")
    print(f"رول ۳ (نشتی user): {len(r3)} مورد مشکوک")
    print(f"رول ۴ (اسم فایل): {len(r4)} مورد مشکوک")

    total = len(rule1_fails) + len(rule2_fails) + len(r3) + len(r4)
    if total > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
