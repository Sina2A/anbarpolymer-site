# رفع نامتقارنیِ خریدار/فروشنده — گذار به snapshot + فالبک

## باگ
مدل ۴نقشیِ v2 فیلد snapshotِ `Deal.sellerId` را اضافه کرد، ولی بیشترِ کد هنوز
فروشنده را از `materialListing.userId` استنتاج می‌کرد. این دو حالت را می‌شکست:

1. **معامله‌های BUY** (پذیرشِ `PurchaseRequest`) هیچ آگهی ندارند ⇒ استنتاج `null`
   می‌شد. فروشنده از قبول/رد/لغو قفل می‌شد، هرگز جریمه نمی‌خورد، در سندِ اختلاف خالی می‌ماند.
2. **معامله‌های legacy** (قبل از v2) هنوز `sellerId=null` دارند ⇒ کدی که به
   `sellerId`ِ خالص گیت می‌کرد، فروشنده‌ی واقعی را ۴۰۴ می‌کرد.

## راه‌حل
یک الگوی واحد همه‌جا: **`deal.sellerId ?? deal.materialListing?.userId`** (snapshot، بعد فالبک).
این منطق در یک helperِ خالص و بدونِ‌وابستگی متمرکز شد تا تنها منبعِ حقیقت باشد و
قابلِ واحدْ‌تست شود:

- `src/lib/dealRoles.ts` (**جدید**) — `resolveSellerId(deal)` و `isDealSeller(deal, userId)`.

## فایل‌های رفع‌شده (۷)
| # | فایل | تغییر |
|---|------|-------|
| ۱ | `src/app/my-deals/actions.ts` | سه گیتِ accept/reject/cancel از راهِ `isDealSeller`؛ گاردِ پنهانِ `!deal.materialListing` به `!deal` شل شد تا فروشنده‌ی BUY به گیت برسد |
| ۲ | `src/app/my-deals/[id]/page.tsx` | شاخه‌ی OR برای `sellerId` + فالبکِ آگهی؛ `isSeller` از helper |
| ۳ | `src/app/dashboard/page.tsx` | دو کوئری (`inTransitCount`, `recentDeals`): شاخه‌ی `{ sellerId }` افزوده شد |
| ۴ | `src/app/transport/page.tsx` | کوئریِ `activeDeals`: شاخه‌ی `{ sellerId }` افزوده شد |
| ۵ | `src/app/my-deals/page.tsx` | `receivedOffers`: `OR` روی `sellerId` و آگهی تا پیشنهادهای BUY هم دیده شوند |
| ۶ | `src/lib/dealDeadlines.ts` | جریمه‌ی دیرکردِ کارمزد: فروشنده از `resolveSellerId`؛ آزادسازیِ آگهی مشروط به `materialListingId`؛ محدودسازی از `restrictUser()` |
| ۷ | `src/app/admin-disputes/actions.ts` | سندِ خروجی: `include: { seller: true }`؛ نام/شناسه از رابطه‌ی `seller` با فالبکِ آگهی |

## تستِ رگرسیون (جدید)
`tests/unit/dealRoles.test.ts` — ۸ کیس روی هر سه شکلِ معامله؛ اجرا با:

```bash
npx tsx --test tests/unit/dealRoles.test.ts
```

پوششِ کلیدی:
- **BUY-seller** (بدون آگهی، فقط `sellerId`) → فروشنده شناخته می‌شود ← رفعِ باگِ اصلی
- **SELL-seller v2** (هر دو موجود) → snapshot برنده است
- **legacy** (`sellerId=null`، آگهی موجود) → فالبک درست کار می‌کند
- **بی‌فروشنده** (هر دو خالی) → همیشه `false` (امنیتِ گیت)

## وضعیت راستی‌آزمایی
- ✅ `npx tsx --test` → **۸/۸ pass**.
- ✅ `npx tsc --noEmit` روی فایل‌های لمس‌شده تمیز است؛ تنها خطا `lucide-react` روی
  `dashboard/page.tsx:9` است که **از پیش موجود** و بی‌ربط به این تغییر است (ماژولِ نصب‌نشده).
- ⚠️ طبقِ محدودیتِ تأییدشده: فقط کد نوشته شد — بدون build / migrate / commit.

> آرشیو شاملِ **۱۰ فایل** است: ۷ فایلِ رفع‌شده + helperِ جدید (`dealRoles.ts`، که ۷ فایل به آن وابسته‌اند) + تستِ جدید + همین یادداشت.
