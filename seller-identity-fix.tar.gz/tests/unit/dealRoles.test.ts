import { test } from 'node:test'
import assert from 'node:assert/strict'
import { resolveSellerId, isDealSeller } from '../../src/lib/dealRoles'

/**
 * تستِ رگرسیون برای «نامتقارنیِ خریدار/فروشنده» — همان کلاس باگی که چندبار تکرار شد:
 * فروشنده‌ی معامله‌ی BUY (بدون آگهی) یا legacy از قبول/رد/لغو قفل می‌شد، چون هویتش
 * فقط از materialListing.userId استنتاج می‌شد. این تست منطقِ متمرکزشده در dealRoles را
 * روی هر سه شکلِ معامله می‌بندد تا برگشتِ باگ در آینده fail بدهد.
 *
 * اجرا: npx tsx --test tests/unit/dealRoles.test.ts
 */

const SELLER = 'user_seller'
const BUYER = 'user_buyer'
const LISTING_OWNER = 'user_listing_owner'

// ── resolveSellerId: ترتیبِ اولویت snapshot → فالبک ─────────────────────────

test('resolveSellerId: snapshotِ seller, وقتی ست است، برنده است (BUY یا SELLِ v2)', () => {
  assert.equal(resolveSellerId({ sellerId: SELLER, materialListing: null }), SELLER)
})

test('resolveSellerId: فالبک به materialListing.userId برای معامله‌ی legacy (sellerId=null)', () => {
  assert.equal(
    resolveSellerId({ sellerId: null, materialListing: { userId: LISTING_OWNER } }),
    LISTING_OWNER,
  )
})

test('resolveSellerId: snapshot بر آگهی مقدم است حتی وقتی هر دو موجودند', () => {
  assert.equal(
    resolveSellerId({ sellerId: SELLER, materialListing: { userId: LISTING_OWNER } }),
    SELLER,
  )
})

test('resolveSellerId: اگر هیچ منبعی نباشد → null (نه خطا)', () => {
  assert.equal(resolveSellerId({ sellerId: null, materialListing: null }), null)
  assert.equal(resolveSellerId({}), null)
  assert.equal(resolveSellerId({ materialListing: { userId: null } }), null)
})

// ── isDealSeller: گیتِ واقعیِ accept/reject/cancel ──────────────────────────

test('BUY-seller: فروشنده‌ی معامله‌ی BUY (بدون آگهی) فروشنده شناخته می‌شود — رفعِ باگِ اصلی', () => {
  const buyDeal = { sellerId: SELLER, materialListing: null }
  assert.equal(isDealSeller(buyDeal, SELLER), true)
  assert.equal(isDealSeller(buyDeal, BUYER), false)
})

test('SELL-seller (v2): فروشنده‌ی snapshot‌شده روی آگهیِ خودش', () => {
  const sellDeal = { sellerId: SELLER, materialListing: { userId: SELLER } }
  assert.equal(isDealSeller(sellDeal, SELLER), true)
})

test('legacy-seller: فروشنده‌ی معامله‌ی قدیمی از طریق فالبکِ آگهی', () => {
  const legacyDeal = { sellerId: null, materialListing: { userId: LISTING_OWNER } }
  assert.equal(isDealSeller(legacyDeal, LISTING_OWNER), true)
  assert.equal(isDealSeller(legacyDeal, BUYER), false)
})

test('فروشنده‌ی نامشخص (هر دو منبع خالی) هرگز فروشنده نیست — امنیتِ گیت', () => {
  const orphan = { sellerId: null, materialListing: null }
  assert.equal(isDealSeller(orphan, SELLER), false)
  assert.equal(isDealSeller(orphan, ''), false)
})
