import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getUserKycLevel } from '@/lib/kyc'
import KycStatusBanner from '@/components/KycStatusBanner'
import UserNav from '@/components/UserNav'
import PanelHeader from '@/components/PanelHeader'
import Footer from '@/components/Footer'
import QuickActionCard from '@/components/QuickActionCard'
import { Package, ShoppingCart, ClipboardList, Megaphone, Handshake, MessageCircle } from 'lucide-react'
import StatCard from '@/components/StatCard'
import RecentItemsList from '@/components/RecentItemsList'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'

export const dynamic = 'force-dynamic'

export default async function DashboardPage() {
  const user = await getCurrentUser()
  const kycLevel = await getUserKycLevel(user.id)

  // کارت خلاصه سفارش‌ها
  const orderStats = await prisma.order.groupBy({
    by: ['status'],
    where: { userId: user.id },
    _count: true,
  })
  const orderStatusMap = Object.fromEntries(orderStats.map((s) => [s.status, s._count]))
  const totalOrders = orderStats.reduce((sum, s) => sum + s._count, 0)

  // کارت خلاصه حمل‌ونقل
  const inTransitCount = await prisma.deal.count({
    where: {
      status: 'in_transit',
      OR: [
        { buyerId: user.id },
        { sellerId: user.id },
        { materialListing: { userId: user.id } },
      ],
    },
  })

  // کوئری جدید: تعداد آگهی‌های فعال
  const activeListingsCount = await prisma.materialListing.count({
    where: { userId: user.id, validityStatus: 'active' },
  })

  // جدول «درخواست‌های اخیر» — ترکیب Order + MaterialListing + Deal
  const recentOrders = await prisma.order.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    take: 5,
    include: { items: { include: { grade: true } } },
  })

  const recentListings = await prisma.materialListing.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    take: 5,
    include: { grade: true },
  })

  const recentDeals = await prisma.deal.findMany({
    where: {
      OR: [
        { buyerId: user.id },
        { sellerId: user.id },
        { materialListing: { userId: user.id } },
      ],
    },
    orderBy: { createdAt: 'desc' },
    take: 5,
    include: { materialListing: { include: { grade: true } } },
  })

  // بدج‌های پویا برای دسترسی سریع
  const pendingOrdersCount = (orderStatusMap['pending'] || 0) + (orderStatusMap['priced'] || 0)

  // Breakdown برای کارت آماری سفارش‌ها
  const orderBreakdown = Object.entries(orderStatusMap)
    .map(([status, count]) => `${count} ${translateOrderStatus(status)}`)
    .join('، ')

  return (
    <>
      <PanelHeader currentUserName={user.companyName} />
      <div style={pageStyle}>
        <div style={pageWrapStyle}>
          <UserNav currentUserName={user.companyName} activeSection="dashboard" />

          <div style={containerStyle}>
            <h1 style={h1Style}>پیشخوان</h1>
            <p style={subtitleStyle}>خلاصه‌ی وضعیت خرید و فروش شما در انبار پلیمر</p>

            <KycStatusBanner level={kycLevel} />

            {/* چیدمان اصلی: دسترسی سریع (2fr) + آمار (1fr) */}
            <div style={topGridStyle}>
              {/* بلوک چپ: دسترسی سریع */}
              <div style={quickActionsGridStyle}>
                {kycLevel >= 2 && (
                  <QuickActionCard
                    icon={<Package size={28} color={colors.navy} />}
                    title="ثبت آگهی فروش"
                    description="بار خودت رو توی شبکه عرضه بذار"
                    href="/new-listing"
                  />
                )}

                {kycLevel >= 1 && (
                  <QuickActionCard
                    icon={<ShoppingCart size={28} color={colors.navy} />}
                    title="درخواست خرید جدید"
                    description="گرید موردنیازت رو سفارش بده"
                    href="/rfq"
                  />
                )}

                <QuickActionCard
                  icon={<ClipboardList size={28} color={colors.navy} />}
                  title="سفارش‌های من"
                  badge={pendingOrdersCount > 0 ? pendingOrdersCount : undefined}
                  href="/my-orders"
                />

                <QuickActionCard
                  icon={<Megaphone size={28} color={colors.navy} />}
                  title="آگهی‌های من"
                  badge={activeListingsCount > 0 ? activeListingsCount : undefined}
                  href="/my-listings"
                />

                <QuickActionCard
                  icon={<Handshake size={28} color={colors.navy} />}
                  title="معامله‌های من"
                  badge={inTransitCount > 0 ? inTransitCount : undefined}
                  href="/my-deals"
                />

                <QuickActionCard
                  icon={<MessageCircle size={28} color={colors.navy} />}
                  title="پشتیبانی"
                  description="سوالی داری؟ ازمون بپرس"
                  href="/support"
                />
              </div>

              {/* بلوک راست: آمار */}
              <div style={statsColStyle}>
                <StatCard
                  value={totalOrders}
                  label="سفارش ثبت‌شده"
                  breakdown={orderBreakdown}
                  color="navy"
                />
                <StatCard
                  value={inTransitCount}
                  label="محموله در حال حمل"
                  cta={{ text: 'مشاهده همه', href: '/my-deals?status=in_transit' }}
                  color="orange"
                />
                <StatCard
                  value={activeListingsCount}
                  label="آگهی فعال"
                  color="navy"
                />
              </div>
            </div>

            {/* فعالیت اخیر — سه ستون دسته‌بندی‌شده */}
            <div style={recentGridStyle}>
              <RecentItemsList
                title="سفارش‌های اخیر"
                items={recentOrders.map((o) => ({
                  id: o.id,
                  description: `${o.items.length} قلم — ${o.items.map((i) => i.grade.code).join('، ')}`,
                  status: o.status,
                  date: o.createdAt,
                }))}
                emptyText="هنوز سفارشی ثبت نشده."
                linkToAll="/my-orders"
                statusTranslator={translateOrderStatus}
                statusKind={orderStatusKind}
              />

              <RecentItemsList
                title="آگهی‌های اخیر"
                items={recentListings.map((l) => ({
                  id: l.id,
                  description: (<>{l.grade.code} — <bdi>{l.quantityTon} تن</bdi></>),
                  status: l.validityStatus,
                  date: l.createdAt,
                }))}
                emptyText="هنوز آگهی ثبت نشده."
                linkToAll="/my-listings"
                statusTranslator={translateListingStatus}
                statusKind={listingStatusKind}
              />

              <RecentItemsList
                title="معامله‌های اخیر"
                items={recentDeals.map((d) => ({
                  id: d.id,
                  description: (<>{d.materialListing?.grade.code ?? 'معامله'} — <bdi>{d.quantity}</bdi></>),
                  status: d.status,
                  date: d.createdAt,
                }))}
                emptyText="هنوز معامله‌ای انجام نشده."
                linkToAll="/my-deals"
                statusTranslator={translateDealStatus}
                statusKind={dealStatusKind}
              />
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  )
}

// ── تابع‌های ترجمه و رنگ‌بندی ──────────────────────────────────────────────

function translateOrderStatus(status: string): string {
  const map: Record<string, string> = {
    pending: 'در انتظار',
    priced: 'قیمت‌گذاری‌شده',
    awaiting_approval: 'در انتظار تایید',
    confirmed: 'تایید‌شده',
    completed: 'تکمیل‌شده',
    cancelled: 'لغو شده',
    rejected: 'رد شده',
  }
  return map[status] ?? status
}

function orderStatusKind(status: string): 'success' | 'warning' | 'danger' | 'neutral' {
  if (['confirmed', 'completed'].includes(status)) return 'success'
  if (['priced', 'awaiting_approval'].includes(status)) return 'warning'
  if (['cancelled', 'rejected'].includes(status)) return 'danger'
  return 'neutral'
}

function translateListingStatus(status: string): string {
  const map: Record<string, string> = {
    active: 'فعال',
    reserved: 'رزرو',
    needs_reverification: 'نیازمند بررسی',
    completed: 'انجام‌شده',
    cancelled: 'لغو‌شده',
  }
  return map[status] ?? status
}

function listingStatusKind(status: string): 'success' | 'warning' | 'danger' | 'neutral' {
  if (['active', 'completed'].includes(status)) return 'success'
  if (['reserved'].includes(status)) return 'warning'
  if (['needs_reverification', 'cancelled'].includes(status)) return 'danger'
  return 'neutral'
}

function translateDealStatus(status: string): string {
  const map: Record<string, string> = {
    draft: 'پیش‌نویس',
    confirmed: 'تایید‌شده',
    seller_fee_paid: 'کارمزد پرداخت‌شده',
    payment_secured: 'پرداخت تامین‌شده',
    transport_pending: 'در انتظار حمل',
    loading: 'در حال بارگیری',
    in_transit: 'در حال حمل',
    delivered: 'تحویل‌شده',
    settled: 'تسویه‌شده',
    void: 'باطل‌شده',
  }
  return map[status] ?? status
}

function dealStatusKind(status: string): 'success' | 'warning' | 'danger' | 'neutral' {
  if (['confirmed', 'settled', 'delivered'].includes(status)) return 'success'
  if (['in_transit', 'loading', 'seller_fee_paid', 'payment_secured', 'transport_pending'].includes(status)) return 'warning'
  return 'neutral'
}

// ── استایل‌ها ─────────────────────────────────────────────────────────────

const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: colors.bgCard,
  padding: `${spacing.xxl}px ${spacing.xl}px`,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}

const pageWrapStyle: React.CSSProperties = {
  width: '100%',
  display: 'flex',
  gap: spacing.xl,
}

const containerStyle: React.CSSProperties = {
  flex: 1,
  minWidth: 0,
}

const backLinkStyle: React.CSSProperties = {
  fontSize: fontSize.sm,
  color: colors.navy,
  textDecoration: 'none',
}

const h1Style: React.CSSProperties = {
  fontSize: fontSize.xxl,
  fontWeight: 800,
  marginBottom: spacing.xs,
  marginTop: spacing.sm,
  color: colors.textPrimary,
}

const subtitleStyle: React.CSSProperties = {
  fontSize: fontSize.base,
  color: colors.textMuted,
  marginBottom: spacing.xl,
}

const topGridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: '2fr 1fr',
  gap: 16,
  marginBottom: 20,
}

const quickActionsGridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))',
  gap: 12,
}

const statsColStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 10,
}

const recentGridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
  gap: 14,
}
