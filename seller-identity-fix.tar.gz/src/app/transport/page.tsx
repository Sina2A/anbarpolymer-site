import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import UserNav from '@/components/UserNav'
import PanelHeader from '@/components/PanelHeader'
import Footer from '@/components/Footer'
import TransportMap from '@/components/TransportMap'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { cardStyle as sharedCardStyle } from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

export default async function TransportPage() {
  const user = await getCurrentUser()

  // Deal های in_transit که کاربر خریدار یا فروشنده‌ست
  const activeDeals = await prisma.deal.findMany({
    where: {
      status: 'in_transit',
      OR: [
        { buyerId: user.id },
        { sellerId: user.id },
        { materialListing: { userId: user.id } },
      ],
    },
    include: {
      materialListing: {
        include: { grade: true },
      },
      confirmations: {
        where: { type: 'loading' },
        take: 1,
        orderBy: { confirmedAt: 'desc' },
      },
    },
  })

  const hasActiveDeals = activeDeals.length > 0

  return (
    <>
      <PanelHeader currentUserName={user.companyName} />
      <div style={pageStyle}>
      <div style={{ width: '100%', display: 'flex', gap: 24 }} className="admin-page-wrap">
        <UserNav currentUserName={user.companyName} activeSection="transport" />
        <div style={{ flex: 1, minWidth: 0 }}>
          <h1 style={{ fontSize: fontSize.xxl, fontWeight: 800, marginBottom: spacing.xs, color: colors.textPrimary }}>حمل و نقل</h1>
          <p style={{ fontSize: fontSize.base, color: colors.textMuted, marginBottom: spacing.xl }}>
            ردیابی زنده محموله‌های در حال حمل
          </p>

          {!hasActiveDeals ? (
            <div style={emptyStateStyle}>
              <div style={{ position: 'relative', width: '100%', height: 400, borderRadius: radius.lg, overflow: 'hidden' }}>
                <div style={{ filter: 'blur(8px)', width: '100%', height: '100%', background: colors.neutralBg }} />
                <div style={overlayTextStyle}>
                  <div style={{ fontSize: fontSize.lg, fontWeight: 700, color: colors.textPrimary, marginBottom: spacing.sm }}>
                    صفحه‌ی لایو لجستیک
                  </div>
                  <div style={{ fontSize: fontSize.md, color: colors.neutralText, lineHeight: 1.6 }}>
                    به شما اطلاعات از وضعیت بار و ماشین حمل را ارائه می‌دهد.
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <TransportMap deals={activeDeals} />
          )}
        </div>
      </div>
    </div>
      <Footer />
    </>
  )
}

const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: colors.bgCard,
  padding: `${spacing.xxl}px ${spacing.xl}px`,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const emptyStateStyle: React.CSSProperties = {
  ...sharedCardStyle,
  overflow: 'hidden',
  marginBottom: 0,
}
const overlayTextStyle: React.CSSProperties = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  textAlign: 'center',
  padding: '24px 32px',
  background: 'rgba(255,255,255,0.95)',
  borderRadius: radius.lg,
  boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
}
