'use server'

import { revalidatePath } from 'next/cache'
import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'

export async function resolveDisputeAction(formData: FormData) {
  const currentUser = await getCurrentUser()
  const disputeId = formData.get('disputeId') as string
  const status = formData.get('status') as string
  const resolution = formData.get('resolution') as string

  await prisma.dispute.update({
    where: { id: disputeId },
    data: {
      status,
      resolution,
      resolvedById: currentUser.id,
      resolvedAt: new Date(),
    },
  })

  revalidatePath('/admin-disputes')
}

export async function exportDisputeEvidenceAction(dealId: string) {
  const currentUser = await getCurrentUser()

  // جمع‌آوری تمام داده‌های مرتبط با این Deal
  const deal = await prisma.deal.findUnique({
    where: { id: dealId },
    include: {
      buyer: true,
      seller: true,
      materialListing: {
        include: {
          user: true,
          grade: true,
        },
      },
      confirmations: {
        orderBy: { confirmedAt: 'asc' },
      },
      disputes: {
        include: {
          raisedBy: true,
        },
      },
    },
  })

  if (!deal) {
    throw new Error('معامله پیدا نشد')
  }

  // لاگ‌های سیستمی مرتبط با این Deal
  const logs = await prisma.systemLog.findMany({
    where: {
      OR: [
        { metaJson: { contains: dealId } },
        { message: { contains: dealId } },
      ],
    },
    orderBy: { createdAt: 'asc' },
  })

  // ساخت HTML قابل چاپ — مرورگر می‌تونه Print to PDF کنه
  const html = `<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>مستندات معامله ${deal.id.slice(0, 8)}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: Tahoma, Arial, sans-serif; font-size: 13px; line-height: 1.6; padding: 24px; background: #fff; color: #1a1a2e; }
    h1 { font-size: 20px; margin-bottom: 8px; color: #1e357b; }
    h2 { font-size: 16px; margin: 24px 0 12px; border-bottom: 2px solid #d8dde3; padding-bottom: 6px; color: #1e357b; }
    h3 { font-size: 14px; margin: 16px 0 8px; color: #4f5560; }
    table { width: 100%; border-collapse: collapse; margin: 12px 0; }
    th, td { border: 1px solid #d8dde3; padding: 8px 10px; text-align: right; }
    th { background: #f7f8fa; font-weight: 700; }
    .meta { font-size: 11px; color: #6b7280; margin-bottom: 20px; }
    .badge { display: inline-block; padding: 3px 8px; border-radius: 4px; font-size: 10px; font-weight: 700; }
    .badge-active { background: #d1fae5; color: #065f46; }
    .badge-warning { background: #fef3c7; color: #92400e; }
    .badge-danger { background: #fee2e2; color: #991b1b; }
    @media print {
      body { padding: 12px; }
      .no-print { display: none; }
    }
  </style>
</head>
<body>
  <h1>مستندات کامل معامله</h1>
  <div class="meta">
    شناسه معامله: <strong>${deal.id}</strong><br>
    تاریخ تهیه: <strong>${new Date().toLocaleString('fa-IR')}</strong><br>
    تهیه‌کننده: <strong>${currentUser.companyName}</strong>
  </div>

  <h2>اطلاعات طرفین</h2>
  <table>
    <tr>
      <th>نقش</th>
      <th>شرکت</th>
      <th>شناسه کاربر</th>
    </tr>
    <tr>
      <td>خریدار</td>
      <td>${deal.buyer.companyName}</td>
      <td style="font-family: monospace; font-size: 10px;">${deal.buyerId}</td>
    </tr>
    <tr>
      <td>فروشنده</td>
      <td>${deal.seller?.companyName ?? deal.materialListing?.user.companyName ?? 'نامشخص'}</td>
      <td style="font-family: monospace; font-size: 10px;">${deal.sellerId ?? deal.materialListing?.userId ?? '—'}</td>
    </tr>
  </table>

  <h2>جزئیات معامله</h2>
  <table>
    <tr>
      <th>گرید</th>
      <td>${deal.materialListing?.grade.code ?? '—'}</td>
    </tr>
    <tr>
      <th>مقدار</th>
      <td>${deal.quantity}</td>
    </tr>
    <tr>
      <th>قیمت توافقی</th>
      <td>${deal.agreedPrice ?? '—'} ریال/کیلوگرم</td>
    </tr>
    <tr>
      <th>وضعیت</th>
      <td><span class="badge ${deal.status === 'settled' ? 'badge-active' : deal.status === 'in_transit' ? 'badge-warning' : ''}">${deal.status}</span></td>
    </tr>
    <tr>
      <th>تاریخ ایجاد</th>
      <td>${new Date(deal.createdAt).toLocaleString('fa-IR')}</td>
    </tr>
    <tr>
      <th>آخرین به‌روزرسانی</th>
      <td>${new Date(deal.updatedAt).toLocaleString('fa-IR')}</td>
    </tr>
  </table>

  <h2>تایم‌لاین تاییدیه‌ها (DealConfirmation)</h2>
  ${deal.confirmations.length === 0 ? '<p>هیچ تاییدیه‌ای ثبت نشده.</p>' : `
  <table>
    <tr>
      <th>نوع</th>
      <th>راننده</th>
      <th>پلاک</th>
      <th>موقعیت GPS</th>
      <th>تاریخ تایید</th>
      <th>حکم نهایی</th>
    </tr>
    ${deal.confirmations.map(c => `
    <tr>
      <td>${c.type}</td>
      <td>${c.driverName ?? '—'}</td>
      <td style="font-family: monospace;">${c.vehiclePlate ?? '—'}</td>
      <td style="font-size: 10px;">${c.latitude && c.longitude ? `${c.latitude.toFixed(6)}, ${c.longitude.toFixed(6)}` : '—'}</td>
      <td>${c.confirmedAt ? new Date(c.confirmedAt).toLocaleString('fa-IR') : '—'}</td>
      <td>${c.finalVerdict ?? '—'}</td>
    </tr>
    `).join('')}
  </table>
  `}

  <h3>عکس‌های شواهد</h3>
  ${deal.confirmations.filter(c => c.photoUrl).length === 0 ? '<p>هیچ عکسی ضمیمه نشده.</p>' : `
    <ul>
      ${deal.confirmations.filter(c => c.photoUrl).map(c => `
        <li>
          <strong>${c.type}</strong> —
          <a href="${c.photoUrl}" target="_blank">${c.photoUrl}</a>
          ${c.confirmedAt ? `(${new Date(c.confirmedAt).toLocaleDateString('fa-IR')})` : ''}
        </li>
      `).join('')}
    </ul>
  `}

  <h2>اختلافات ثبت‌شده</h2>
  ${deal.disputes.length === 0 ? '<p>هیچ اختلافی ثبت نشده.</p>' : `
  <table>
    <tr>
      <th>دلیل</th>
      <th>ایجادکننده</th>
      <th>وضعیت</th>
      <th>نتیجه</th>
      <th>تاریخ</th>
    </tr>
    ${deal.disputes.map(d => `
    <tr>
      <td>${d.reason}</td>
      <td>${d.raisedBy.companyName}</td>
      <td><span class="badge ${d.status === 'resolved' ? 'badge-active' : d.status === 'open' ? 'badge-warning' : 'badge-danger'}">${d.status}</span></td>
      <td>${d.resolution ?? '—'}</td>
      <td>${new Date(d.createdAt).toLocaleString('fa-IR')}</td>
    </tr>
    `).join('')}
  </table>
  `}

  <h2>لاگ‌های سیستمی</h2>
  ${logs.length === 0 ? '<p>هیچ لاگی یافت نشد.</p>' : `
  <table>
    <tr>
      <th>سطح</th>
      <th>دسته</th>
      <th>پیام</th>
      <th>تاریخ</th>
    </tr>
    ${logs.map(l => `
    <tr>
      <td><span class="badge ${l.level === 'error' ? 'badge-danger' : l.level === 'warn' ? 'badge-warning' : ''}">${l.level}</span></td>
      <td>${l.category}</td>
      <td style="font-size: 11px;">${l.message}</td>
      <td style="font-size: 10px;">${new Date(l.createdAt).toLocaleString('fa-IR')}</td>
    </tr>
    `).join('')}
  </table>
  `}

  <div style="margin-top: 40px; padding-top: 20px; border-top: 2px solid #d8dde3; font-size: 11px; color: #9199a3;">
    <p>این مستند به‌صورت خودکار توسط سیستم انبار پلیمر تولید شده است.</p>
    <p>برای ارجاع به مرجع قضایی یا داوری، این صفحه را از مرورگر «Print to PDF» کنید.</p>
  </div>

  <script>
    // دکمه چاپ خودکار برای راحتی کاربر
    window.onload = function() {
      const btn = document.createElement('button');
      btn.textContent = '🖨️ چاپ / ذخیره PDF';
      btn.className = 'no-print';
      btn.style.cssText = 'position: fixed; top: 20px; left: 20px; padding: 12px 20px; background: #1e357b; color: #fff; border: none; border-radius: 8px; font-size: 14px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 12px rgba(0,0,0,0.2); z-index: 9999;';
      btn.onclick = () => window.print();
      document.body.appendChild(btn);
    }
  </script>
</body>
</html>`

  // برگرداندن HTML به‌عنوان response — صفحه‌ی ادمین می‌تونه window.open باز کنه
  return {
    success: true,
    html,
    dealId: deal.id,
  }
}
