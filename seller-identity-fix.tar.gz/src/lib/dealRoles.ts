/**
 * منبعِ حقیقتِ واحد برای تشخیص هویتِ فروشنده‌ی یک معامله.
 *
 * چرا متمرکز شد: مدل ۴نقشی v2 فیلد snapshotِ `sellerId` را روی Deal اضافه کرد، ولی
 * معامله‌های legacy (قبل از v2) هنوز `sellerId=null` دارند و فروشنده‌شان فقط از
 * `materialListing.userId` قابل استنتاج است؛ معامله‌های BUY هم اصلاً آگهی ندارند و
 * فقط `sellerId` دارند. تکرارِ درجای الگوی `sellerId ?? materialListing?.userId` در
 * چند فایل بارها به «نامتقارنیِ خریدار/فروشنده» منجر شد (فروشنده‌ی BUY/legacy از
 * قبول/رد/لغو قفل می‌شد). این helper همان منطق را یک‌بار و به‌شکلِ خالص و قابل‌تست
 * می‌کند تا آن کلاسِ باگ برنگردد.
 *
 * عمداً بدونِ هیچ وابستگی (نه prisma، نه env) نوشته شده تا واحدْ‌تست بتواند مستقیم
 * import‌اش کند.
 */

/** حداقلِ شکلِ Deal که برای تشخیص فروشنده لازم است — سبک، تا خروجیِ هر کوئری‌ای بسازدش. */
export interface SellerIdentityDeal {
  sellerId?: string | null
  materialListing?: { userId?: string | null } | null
}

/**
 * شناسه‌ی فروشنده‌ی معامله: اول snapshotِ v2 (`sellerId`)، بعد فالبک به آگهی (legacy).
 * اگر هیچ‌کدام نباشد → null.
 */
export function resolveSellerId(deal: SellerIdentityDeal): string | null {
  return deal.sellerId ?? deal.materialListing?.userId ?? null
}

/**
 * آیا `userId` فروشنده‌ی این معامله است؟ اگر فروشنده قابلِ‌تشخیص نباشد (هر دو منبع
 * خالی) → false، تا هرگز به کاربرِ نامشخص دسترسیِ فروشنده داده نشود.
 */
export function isDealSeller(deal: SellerIdentityDeal, userId: string): boolean {
  const sellerId = resolveSellerId(deal)
  return sellerId !== null && sellerId === userId
}
