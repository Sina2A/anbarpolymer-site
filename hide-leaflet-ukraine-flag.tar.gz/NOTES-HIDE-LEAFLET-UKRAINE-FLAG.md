# NOTES — مخفی‌کردن پرچمِ اوکراین از Attributionِ نقشه‌ی Leaflet

## خواسته
Leaflet به‌صورت پیش‌فرض یک پرچمِ کوچکِ اوکراین در بخشِ Attribution (گوشه‌ی نقشه) نشان می‌دهد
(کلاسِ `.leaflet-attribution-flag`). این پرچم باید از همه‌ی نقشه‌های سایت مخفی شود.

## تغییر
### `src/app/globals.css`
افزودنِ یک قانونِ CSS در انتهای فایل:
```css
.leaflet-attribution-flag{display:none !important}
```
- محل: `globals.css` که سراسری بارگذاری می‌شود → روی **همه‌ی** نقشه‌ها اثر می‌کند:
  `WarehousesMap`، `LocationPicker`/`LocationPickerMap`، و `TransportMap`.
- `!important` برای غلبه بر استایلِ inlineِ خودِ Leaflet روی این المان.
- متنِ Attribution و لینکِ OpenStreetMap دست‌نخورده باقی می‌مانند (فقط آیکنِ پرچم مخفی می‌شود) —
  الزامِ حقوقیِ نمایشِ منبعِ کاشی‌ها همچنان رعایت می‌شود.

## محتوای این بسته
```
NOTES-HIDE-LEAFLET-UKRAINE-FLAG.md   (همین فایل)
src/app/globals.css                   (افزودنِ یک قانونِ CSS)
```

## نحوه‌ی اعمال روی مخزن
```bash
tar -xzf hide-leaflet-ukraine-flag.tar.gz
```
> فقط CSS است؛ نیازی به نصبِ وابستگی یا build مجدد برای اعتبارسنجی نیست
> (در build بعدی خودبه‌خود در باندلِ CSS می‌آید).
