/**
 * Next.js این فایل رو خودش، یه‌بار موقع بالا اومدن سرور، اجرا می‌کنه (بدون
 * نیاز به import دستی جایی). این‌جا یه محافظ کلی می‌ذاریم که هر خطای
 * catch‌نشده‌ی سطح پروسه (نه فقط خطاهای داخل یه اکشن خاص) رو توی SystemLog
 * ثبت کنه — یه لایه‌ی امنیتی برای چیزهایی که در طول توسعه فراموش می‌شه توی
 * جای درستش try/catch بذاریم.
 *
 * توجه: اگه npm run build خطا داد که experimental.instrumentationHook لازمه،
 * این خط رو به next.config.js اضافه کن:
 *   module.exports = { experimental: { instrumentationHook: true } }
 * (توی Next.js 15+ معمولاً دیگه لازم نیست، چون پیش‌فرض فعاله.)
 */
export async function register() {
  if (process.env.NEXT_RUNTIME === 'nodejs') {
    const { logError } = await import('./src/lib/logger')

    process.on('uncaughtException', (err) => {
      logError('system', err.message, { stack: err.stack, kind: 'uncaughtException' })
    })

    process.on('unhandledRejection', (reason) => {
      const message = reason instanceof Error ? reason.message : String(reason)
      const stack = reason instanceof Error ? reason.stack : undefined
      logError('system', message, { stack, kind: 'unhandledRejection' })
    })
  }
}
