import prisma from './prisma'

export type LogLevel = 'error' | 'warn' | 'info' | 'audit'

/**
 * تابع واحد ثبت لاگ — همه‌جای سایت باید از همینجا استفاده کنه، نه console.log
 * پراکنده. دو مقصد همزمان داره:
 *   ۱. دیتابیس (SystemLog) — برای مرور/فیلتر توی پنل ادمین، دائمی می‌مونه
 *   ۲. کنسول (که PM2 می‌گیره) — لایه‌ی دوم، برای وقتی خودِ دیتابیس در دسترس نیست
 *
 * **هیچ‌وقت نباید خودش خطا بندازه** — اگه ثبت لاگ توی دیتابیس شکست بخوره،
 * نباید کاری که داشت لاگ می‌شد (مثلاً یه لاگین یا یه پرداخت) رو خراب کنه.
 */
export async function logEvent(params: {
  level: LogLevel
  category: string
  message: string
  userId?: string | null
  path?: string | null
  meta?: Record<string, unknown>
}) {
  const { level, category, message, userId, path, meta } = params

  // همیشه توی کنسول هم بنویس (PM2 logs) — این خط هرگز شکست نمی‌خوره
  const consoleFn = level === 'error' ? console.error : level === 'warn' ? console.warn : console.log
  consoleFn(`[${level.toUpperCase()}] [${category}] ${message}`, meta ? JSON.stringify(meta) : '')

  try {
    await prisma.systemLog.create({
      data: {
        level,
        category,
        message,
        userId: userId || null,
        path: path || null,
        metaJson: meta ? JSON.stringify(meta) : null,
      },
    })
  } catch (e) {
    // اگه خودِ دیتابیس در دسترس نبود (دقیقاً یکی از سناریوهایی که می‌خوایم
    // لاگ کنیم!)، حداقل توی کنسول یه اثر ازش بمونه.
    console.error('logEvent: failed to write to database:', e)
  }
}

/** برای دیباگ فنی — خطا/کرش/استثنا. */
export function logError(category: string, message: string, meta?: Record<string, unknown>, userId?: string | null) {
  return logEvent({ level: 'error', category, message, meta, userId })
}

/** برای ردیابی فعالیت کاربر — «کی چیکار کرد». userId اختیاریه (مثلاً وقتی فقط شماره موجوده، نه هویت کامل کاربر). */
export function logAudit(category: string, message: string, userId?: string | null, meta?: Record<string, unknown>) {
  return logEvent({ level: 'audit', category, message, userId, meta })
}
