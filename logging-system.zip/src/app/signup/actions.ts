'use server'

import prisma from '@/lib/prisma'
import { hashPassword } from '@/lib/auth'
import { requestOtp } from '@/lib/otp'
import { logAudit, logError } from '@/lib/logger'
import { redirect } from 'next/navigation'

export async function signupAction(prevState: { error: string }, formData: FormData) {
  const companyName = String(formData.get('companyName') || '').trim()
  const phone = String(formData.get('phone') || '').trim()
  const password = String(formData.get('password') || '')
  const confirmPassword = String(formData.get('confirmPassword') || '')

  if (!companyName || !phone || !password || !confirmPassword) {
    return { error: 'همه‌ی فیلدها رو کامل کن.' }
  }
  if (password !== confirmPassword) {
    return { error: 'رمز عبور و تکرارش یکی نیستن.' }
  }
  if (password.length < 8) {
    return { error: 'رمز عبور باید حداقل ۸ کاراکتر باشه.' }
  }
  // اعتبارسنجی سطحی فرمت شماره — فقط ضد تایپ اشتباه، نه احراز واقعی
  // (احراز واقعی همینجا با OTP، و بعداً با KYC انجام می‌شه)
  if (!/^09\d{9}$/.test(phone)) {
    return { error: 'شماره موبایل باید به‌شکل ۰۹xxxxxxxxx باشه.' }
  }

  const existing = await prisma.user.findUnique({ where: { phone } })
  if (existing) {
    await logError('auth', 'تلاش ثبت‌نام با شماره‌ی تکراری', { phone })
    return { error: 'حسابی با این شماره موبایل از قبل وجود داره — وارد شو یا رمزت رو بازیابی کن.' }
  }

  const user = await prisma.user.create({
    data: {
      companyName,
      phone,
      passwordHash: hashPassword(password),
      role: 'buyer',
      isActive: true,
      phoneVerified: false,
    },
  })
  await logAudit('auth', 'ثبت‌نام جدید', user.id, { companyName })

  // بدون این‌که کاربر وارد بشه، همین‌جا کد تایید فرستاده می‌شه — verifyOtp
  // بر اساس شماره کار می‌کنه، نه نشست، پس صفحه‌ی بعدی نیازی به لاگین نداره.
  await requestOtp(phone, 'signup_verify')

  redirect(`/verify-phone?phone=${encodeURIComponent(phone)}`)
}
