'use client'

import { useEffect, useRef } from 'react'
import { logoutAction } from '@/app/logout/actions'

export default function UserNav({
  currentUserName,
  activeSection,
}: {
  currentUserName: string
  activeSection?: string
}) {
  const detailsRef = useRef<HTMLDetailsElement>(null)

  useEffect(() => {
    const handleResize = () => {
      if (detailsRef.current) {
        detailsRef.current.open = window.innerWidth >= 900
      }
    }
    handleResize()
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  const items = [
    { key: 'dashboard', label: 'پیشخوان', href: '/dashboard', isReal: true },
    { key: 'requests', label: 'درخواست‌های خرید من', href: '/my-requests', isReal: true },
    { key: 'orders', label: 'سفارش‌های من', href: '/my-orders', isReal: true },
    { key: 'proformas', label: 'پیش‌فاکتورهای من', href: '/proformas', isReal: true },
    { key: 'listings', label: 'شبکه عرضه مواد اولیه من', href: '/my-listings', isReal: true },
    { key: 'deals', label: 'معاملات من', href: '/my-deals', isReal: true },
    { key: 'transport', label: 'حمل و نقل', href: '/transport', isReal: true },
    { key: 'verification', label: 'احراز هویت', href: '/verification', isReal: true },
    { key: 'grades', label: 'گریدها', href: '/grades', isReal: true },
    { key: 'account', label: 'ویرایش حساب کاربری', href: '/account', isReal: true },
    { key: 'price-alerts', label: 'هشدار قیمت', href: '#', isReal: false },
    { key: 'support', label: 'پشتیبانی', href: '#', isReal: false },
  ]

  const activeLabel = items.find((i) => i.key === activeSection)?.label ?? 'منوی من'

  return (
    <details className="user-nav" ref={detailsRef}>
      <summary className="user-nav-toggle">
        <span>☰ {activeLabel}</span>
        <span className="user-nav-caret">▾</span>
      </summary>

      <div className="user-nav-body">
        <div
          style={{
            paddingBottom: 12,
            marginBottom: 10,
            borderBottom: '1px solid #eceff3',
            fontSize: 13,
            fontWeight: 700,
          }}
        >
          {currentUserName}
        </div>
        <nav style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {items.map((item) => {
            if (!item.isReal) {
              return (
                <span
                  key={item.key}
                  style={{
                    display: 'block',
                    padding: '9px 8px',
                    borderRadius: 6,
                    fontSize: 13,
                    color: '#9199a3',
                    cursor: 'default',
                  }}
                  title="هنوز صفحه‌ی این بخش ساخته نشده"
                >
                  {item.label}
                  <span
                    style={{
                      fontSize: 9.5,
                      fontFamily: 'monospace',
                      background: '#f1efe8',
                      color: '#9199a3',
                      borderRadius: 4,
                      padding: '1px 6px',
                      marginRight: 6,
                    }}
                  >
                    به‌زودی
                  </span>
                </span>
              )
            }

            return (
              <a
                key={item.key}
                href={item.href}
                style={{
                  display: 'block',
                  padding: '9px 8px',
                  borderRadius: 6,
                  fontSize: 13,
                  textDecoration: 'none',
                  color: item.key === activeSection ? '#e65716' : '#4f5560',
                  background: item.key === activeSection ? '#fff4ee' : 'transparent',
                  fontWeight: item.key === activeSection ? 700 : 400,
                }}
              >
                {item.label}
              </a>
            )
          })}
        </nav>

        {/* ── خروج از حساب — پایین‌ترین آیتم، جدا از بقیه با خط جداکننده ── */}
        <div style={logoutDividerStyle} />
        <form action={logoutAction}>
          <button
            type="submit"
            style={{
              display: 'block',
              width: '100%',
              padding: '9px 8px',
              borderRadius: 6,
              fontSize: 13,
              textDecoration: 'none',
              color: '#9b1c1c',
              background: 'transparent',
              border: 'none',
              textAlign: 'right',
              cursor: 'pointer',
              fontFamily: 'inherit',
            }}
          >
            خروج از حساب
          </button>
        </form>
      </div>
    </details>
  )
}

const logoutDividerStyle: React.CSSProperties = { height: 1, background: '#eceff3', margin: '10px 0' }
