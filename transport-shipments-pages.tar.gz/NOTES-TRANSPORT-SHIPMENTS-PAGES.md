# محموله‌های جاری و تاریخچه — یادداشت پیاده‌سازی

## خلاصه
محتوای placeholder دو صفحه‌ی `/transport-panel/current` و `/transport-panel/history` با UI واقعی مطابق `preview (1).html` جایگزین شد؛ فقط فیلدهای دارای داده‌ی واقعی Prisma پر می‌شوند، بدون داده‌ی جعلی. پوسته‌ی مشترک `TransportPanelShell`/`layout.tsx`، گیت `logisticsAccessEnabled` و `actions.ts` دست‌نخورده ماندند.

## فایل‌های تغییریافته
- `src/app/transport-panel/current/page.tsx` — سرور کامپوننت با `searchParams: Promise<...>`، فیلتر/جستجوی واقعی، کارت‌های محموله
- `src/app/transport-panel/history/page.tsx` — سرور کامپوننت با pagination واقعی (count+skip/take)، جدول تاریخچه
- `src/app/globals.css` — استایل scoped با پیشوند `transport-shipments-*` (summary/toolbar/card/table/pagination + responsive 1100/800)
- `NOTES-TRANSPORT-SHIPMENTS-PAGES.md` — همین فایل

## تصمیمات تاییدشده (۵ مورد)
1. مقصد نامشخص → `نامشخص` (نه «به‌زودی»)
2. نیازمند پیگیری → `driverSilenceFlaggedAt != null`
3. PAGE_SIZE تاریخچه → `20` (هماهنگ با my-tasks)
4. کد محموله → short-id موقت `AP-` + ۸ کاراکتر ابتدایی `Deal.id` به‌صورت LTR با tooltip شناسه‌ی کامل، بدون فیلد جدید
5. تعداد کامیون → کاملاً حذف (نه هاردکد «۱ کامیون»)

## ماتریس ✅/❌ هر فیلد دیزاین
| فیلد دیزاین | وضعیت | منبع واقعی | رفتار پیاده‌شده |
|---|---|---|---|
| کد محموله AP-xxxx | ⚠️ موقت | `Deal.id` (cuid، بدون کد انسانی) | `AP-` + ۸ کاراکتر ابتدایی id، LTR، `title=id` |
| محصول | ✅ | `materialListing.grade.code` | مستقیم؛ fallback «بدون گرید» |
| مقدار (تن) | ✅ | `Deal.quantity` (string) | مستقیم |
| تعداد کامیون | ❌ حذف | مدلی ندارد | از UI حذف شد |
| مسیر مبدا | ✅ | `MaterialListing.province/city` | `province، city` |
| مسیر مقصد | ⚠️ ناقص | `PurchaseRequest.province` (بدون city) | اگر null/خالی → `نامشخص` |
| راننده (نام/آواتار/تلفن) | ⚠️ با fallback | `Deal.driver` ترجیحاً، وگرنه `DealConfirmation` (type=loading) | initials از نام؛ تلفن LTR؛ اگر هیچ‌کدام → `—` |
| پلاک خودرو | ⚠️ snapshot | `DealConfirmation.vehiclePlate` | اگر موجود LTR، وگرنه `—` |
| نوع کامیون | ⚠️ snapshot | `DealConfirmation.vehicleType` | نگاشت truck/trailer/khavar/pickup → فارسی؛ وگرنه `—` |
| وضعیت حمل | ✅ با نگاشت | `Deal.status` | نگاشت به برچسب فارسی + رنگ توکن‌ها؛ `attention` = flagged |
| تاریخ حمل | ✅ | `Deal.createdAt` + `DealConfirmation.confirmedAt` (loading) | کارت جاری: `createdAt`؛ جدول تاریخچه: `confirmedAt` ترجیحاً وگرنه `createdAt`، شمسی fa-IR + ساعت |
| وضعیت‌های تاریخچه | ✅ با نگاشت | `delivered/settled/void/cancelled` | `تحویل‌شده` شامل delivered+settled؛ `متوقف‌شده`=void؛ `لغوشده`=cancelled |

## نگاشت وضعیت
- `payment_secured` → «در انتظار بارگیری» (warning)
- `loading` → «در حال بارگیری» (info)
- `in_transit` → «در مسیر» (info)
- `delivered` → «تحویل‌شده» (success)
- `settled` → «تسویه‌شده» (success، در تاریخچه زیر «تحویل‌شده» تجمیع)
- `void` → «متوقف‌شده» (danger)
- `cancelled` → «لغوشده» (danger)
- `attention` (مجازی) → «نیازمند پیگیری» (danger) وقتی `driverSilenceFlaggedAt != null`

## کوئری و scope
- Scope ثابت: `where: { transportCompanyId: company.id }` — هرگز از URL خوانده نمی‌شود؛ `OR` با driver گسترش داده نشد تا داده‌ی کثیف قاطی نشود.
- Current: `status in [payment_secured, loading, in_transit]`؛ فیلتر `attention` = همین سه + `driverSilenceFlaggedAt not null`؛ فیلتر تکی status مقدار مستقیم.
- History: `status in [delivered, settled, void, cancelled]`؛ فیلتر `delivered` = `in [delivered, settled]`؛ بقیه مستقیم.
- جستجو (هر دو صفحه): `OR` روی `Deal.id contains`, `Deal.quantity contains`, `Grade.code contains`, `Driver.fullName/phone contains`, `MaterialListing.province/city contains`, `PurchaseRequest.province contains`, `DealConfirmation.vehiclePlate/driverName/driverPhone contains` (via `some`).
- Include مشترک: `driver`, `materialListing { grade }`, `purchaseRequest`, `confirmations orderBy confirmedAt desc take 4`.
- مرتب‌سازی: `createdAt desc`.
- تاریخچه pagination: `count` + `findMany skip/take` با `PAGE_SIZE=20`؛ `page` با regex `^\d+$`، نامعتبر/خارج بازه → ۱؛ `totalPages = max(1, ceil(total/PAGE_SIZE))`.

## فیلتر/جستجو و pagination (URL-driven، سمت سرور)
- پارامترها: `?q=&status=` (هر دو صفحه) + `?page=` (فقط تاریخچه).
- فرم `GET` با `select` و `input` و `defaultValue` از `searchParams`؛ مقادیر `status` اعتبارسنجی با Set، نامعتبر → `all`.
- Pagination تاریخچه: لینک‌ها scalar params را حفظ می‌کنند؛ فوتر `نمایش X تا Y از Z` (fa-IR)؛ دکمه‌ها LTR `‹ ›` و شماره‌ها با window ±۲؛ قبلی/بعدی در مرز disabled.

## استایل
- توکن‌ها: `--transport-navy/navy-dark/orange/page/card/border/text/muted` موجود؛ رنگ وضعیت‌ها از `colors.success/warning/danger/info/neutral` (نه هاردکد جدید).
- کلاس‌ها با پیشوند `transport-shipments-*` از `transport-panel-*` جدا تا shell دست‌نخورده بماند.
- Summary: گرید ۴ستونه ۷۲px، border ۱۰px، label ۱۰px، value ۱۸px/800.
- Toolbar: کارت سفید با select + search (input + دکمه ۳۶px).
- Current: کارت ۶ستونه با hover؛ responsive: ≤۱۱۰۰ خودرو مخفی، ≤۸۰۰ فقط هویت+وضعیت+اکشن، summary ۲×۲.
- History: `.transport-shipments-history-card` + جدول thead ۴۷px / row ۶۷px + فوتر + pagination ۲۸px (active navy).
- از `.table-scroll` موجود برای افقی استفاده می‌شود؛ Vazirmatn خودمیزبان پروژه.

## قوانین رعایت‌شده
- بدون داده‌ی جعلی/نمونه از `preview.html` در کد نهایی
- `logisticsAccessEnabled` در هر دو صفحه دست‌نخورده
- `actions.ts` و مدل‌های Prisma بدون تغییر؛ migration پیشنهادی فقط در این یادداشت (زیر)
- اجرا/build/migration انجام نشد — فقط نوشتن
- پوسته‌ی مشترک دست‌نخورده

## پیشنهاد migration (فاز جدا، پیاده نشده)
- `Deal.shipmentCode` انسانی و یکتا (جایگزین short-id موقت)
- `Deal.destinationProvince/destinationCity` یا تکمیل `PurchaseRequest` برای مقصد دقیق
- `Deal.truckCount` اگر واقعاً چندکامیونه شود
- `Deal.currentStatusDetail` اگر تفکیک «رسیده به مقصد» از «تحویل‌شده» لازم شد

## بررسی (بدون اجرا)
- `Read` فایل‌های تغییریافته، تطابق کلاس‌ها با CSS، عدم وجود داده‌ی جعلی، حفظ گیت‌ها، عدم تغییر shell/actions
- `git status` / `git diff --stat` / `tar tzf` / `sha256sum` — بدون `next build`/`dev`/`lint`/`test`/`playwright`

## بسته‌ی تحویل
- `transport-shipments-pages.tar.gz` (فقط فایل‌های همین تسک)
- `transport-shipments-pages.tar.gz.sha256`
