import Link from 'next/link'
import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { colors } from '@/lib/styles/tokens'

export const dynamic = 'force-dynamic'

const ACTIVE_STATUSES = ['payment_secured', 'loading', 'in_transit'] as const
type ActiveStatus = (typeof ACTIVE_STATUSES)[number]
type CurrentStatusParam = 'all' | ActiveStatus | 'attention'

const ALLOWED_CURRENT_STATUSES: ReadonlySet<string> = new Set<string>([
  'all',
  ...ACTIVE_STATUSES,
  'attention',
])

const CARRIER_STATUS: Record<string, { label: string; bg: string; color: string }> = {
  payment_secured: { label: 'در انتظار بارگیری', bg: colors.warningBg, color: colors.warningText },
  loading: { label: 'در حال بارگیری', bg: colors.infoBg, color: colors.infoText },
  in_transit: { label: 'در مسیر', bg: colors.infoBg, color: colors.infoText },
  delivered: { label: 'تحویل‌شده', bg: colors.successBg, color: colors.successText },
  settled: { label: 'تسویه‌شده', bg: colors.successBg, color: colors.successText },
  void: { label: 'متوقف‌شده', bg: colors.dangerBg, color: colors.dangerText },
  cancelled: { label: 'لغوشده', bg: colors.dangerBg, color: colors.dangerText },
}

const ATTENTION_LABEL = { label: 'نیازمند پیگیری', bg: colors.dangerBg, color: colors.dangerText }

const VEHICLE_TYPE_LABEL: Record<string, string> = {
  truck: 'کامیون',
  trailer: 'تریلی',
  khavar: 'خاور',
  pickup: 'وانت',
}

type SearchParams = Record<string, string | string[] | undefined>

function scalar(value: string | string[] | undefined): string | undefined {
  if (Array.isArray(value)) return value[0]
  return value
}

function normalizeSearchParams(params: SearchParams): { q: string; status: CurrentStatusParam } {
  const rawQ = scalar(params.q)?.trim() ?? ''
  const q = rawQ.slice(0, 80)
  const rawStatus = scalar(params.status)?.trim() ?? 'all'
  const status: CurrentStatusParam = ALLOWED_CURRENT_STATUSES.has(rawStatus)
    ? (rawStatus as CurrentStatusParam)
    : 'all'
  return { q, status }
}

function shortShipmentCode(id: string): string {
  const head = id.replace(/[^a-zA-Z0-9]/g, '').slice(0, 8) || id.slice(0, 8)
  return `AP-${head.toUpperCase()}`
}

function initialsFromName(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean)
  if (parts.length === 0) return '—'
  if (parts.length === 1) return parts[0].slice(0, 2)
  return (parts[0][0] ?? '') + (parts[parts.length - 1][0] ?? '')
}

function formatFaDate(value: Date): string {
  return new Date(value).toLocaleDateString('fa-IR')
}

function formatFaDateTime(value: Date): string {
  return new Date(value).toLocaleString('fa-IR', { dateStyle: 'short', timeStyle: 'short' })
}

function originLabel(listing: { province: string; city: string } | null | undefined): string {
  if (!listing) return 'نامشخص'
  const province = listing.province?.trim() ?? ''
  const city = listing.city?.trim() ?? ''
  if (province && city) return `${province}، ${city}`
  return province || city || 'نامشخص'
}

function destinationLabel(purchaseRequest: { province: string | null } | null | undefined): string {
  const province = purchaseRequest?.province?.trim() ?? ''
  return province || 'نامشخص'
}

function buildSearchWhere(q: string): object | null {
  if (!q) return null
  return {
    OR: [
      { id: { contains: q } },
      { quantity: { contains: q } },
      { materialListing: { grade: { code: { contains: q } } } },
      { materialListing: { province: { contains: q } } },
      { materialListing: { city: { contains: q } } },
      { driver: { fullName: { contains: q } } },
      { driver: { phone: { contains: q } } },
      { purchaseRequest: { province: { contains: q } } },
      { confirmations: { some: { vehiclePlate: { contains: q } } } },
      { confirmations: { some: { driverName: { contains: q } } } },
      { confirmations: { some: { driverPhone: { contains: q } } } },
    ],
  }
}

export default async function TransportCurrentPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>
}) {
  const user = await getCurrentUser()
  const company = await prisma.transportCompany.findUnique({ where: { managerUserId: user.id } })

  if (!company) {
    return (
      <AccessCard title="پنل شرکت حمل‌ونقل — دسترسی ندارید">
        این حساب به هیچ شرکت حمل‌ونقلی وصل نیست. با پشتیبانی انبار پلیمر تماس بگیرید.
      </AccessCard>
    )
  }
  if (!company.logisticsAccessEnabled) {
    return (
      <AccessCard title="پنل شرکت حمل‌ونقل — دسترسی غیرفعال">
        دسترسی پنل حمل‌ونقل برای <b>{company.name}</b> در حال حاضر غیرفعاله. برای فعال‌شدن با پشتیبانی
        انبار پلیمر تماس بگیرید.
      </AccessCard>
    )
  }

  const params = await searchParams
  const { q, status } = normalizeSearchParams(params)
  const searchWhere = buildSearchWhere(q)

  const baseActiveWhere = {
    transportCompanyId: company.id,
    status: { in: [...ACTIVE_STATUSES] as string[] },
  }

  const [totalActive, inTransitCount, loadingCount, attentionCount] = await Promise.all([
    prisma.deal.count({ where: { ...baseActiveWhere, ...(searchWhere ?? {}) } }),
    prisma.deal.count({
      where: { transportCompanyId: company.id, status: 'in_transit', ...(searchWhere ?? {}) },
    }),
    prisma.deal.count({
      where: { transportCompanyId: company.id, status: 'loading', ...(searchWhere ?? {}) },
    }),
    prisma.deal.count({
      where: {
        transportCompanyId: company.id,
        status: { in: [...ACTIVE_STATUSES] as string[] },
        driverSilenceFlaggedAt: { not: null },
        ...(searchWhere ?? {}),
      },
    }),
  ])

  const listWhere: Record<string, unknown> = {
    transportCompanyId: company.id,
  }

  if (status === 'attention') {
    ;(listWhere as Record<string, unknown>).status = { in: [...ACTIVE_STATUSES] as string[] }
    ;(listWhere as Record<string, unknown>).driverSilenceFlaggedAt = { not: null }
  } else if (status !== 'all') {
    ;(listWhere as Record<string, unknown>).status = status
  } else {
    ;(listWhere as Record<string, unknown>).status = { in: [...ACTIVE_STATUSES] as string[] }
  }

  if (searchWhere) Object.assign(listWhere, searchWhere)

  const deals = await prisma.deal.findMany({
    where: listWhere as never,
    orderBy: { createdAt: 'desc' },
    include: {
      driver: true,
      materialListing: { include: { grade: true } },
      purchaseRequest: true,
      confirmations: { orderBy: { confirmedAt: 'desc' }, take: 4 },
    },
  })

  const hasActiveFilter = status !== 'all' || q.length > 0

  return (
    <div className="transport-shipments-page" dir="rtl">
      <div className="transport-panel-page-heading">
        <h1>محموله‌های جاری</h1>
        <p>
          <b>{company.name}</b> — محموله‌های در حال انجام این شرکت حمل‌ونقل
        </p>
      </div>

      <div className="transport-shipments-summary">
        <div className="transport-shipments-summary-card">
          <span className="transport-shipments-summary-label">کل محموله‌های جاری</span>
          <b className="transport-shipments-summary-value">{totalActive.toLocaleString('fa-IR')}</b>
        </div>
        <div className="transport-shipments-summary-card">
          <span className="transport-shipments-summary-label">در حال حمل</span>
          <b className="transport-shipments-summary-value">{inTransitCount.toLocaleString('fa-IR')}</b>
        </div>
        <div className="transport-shipments-summary-card">
          <span className="transport-shipments-summary-label">در حال بارگیری</span>
          <b className="transport-shipments-summary-value">{loadingCount.toLocaleString('fa-IR')}</b>
        </div>
        <div className="transport-shipments-summary-card is-attention">
          <span className="transport-shipments-summary-label">نیازمند پیگیری</span>
          <b className="transport-shipments-summary-value">{attentionCount.toLocaleString('fa-IR')}</b>
        </div>
      </div>

      <form method="GET" className="transport-shipments-toolbar" role="search" aria-label="فیلتر محموله‌های جاری">
        <label className="transport-shipments-select-wrap" aria-label="فیلتر وضعیت">
          <select name="status" defaultValue={status} aria-label="وضعیت محموله">
            <option value="all">همه وضعیت‌ها</option>
            <option value="payment_secured">در انتظار بارگیری</option>
            <option value="loading">در حال بارگیری</option>
            <option value="in_transit">در حال حمل</option>
            <option value="attention">نیازمند پیگیری</option>
          </select>
          <span aria-hidden="true" className="transport-shipments-select-caret">
            ▾
          </span>
        </label>
        <div className="transport-shipments-search">
          <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
            <circle cx="11" cy="11" r="7" />
            <path d="M15.5 15.5 21 21" />
          </svg>
          <input
            name="q"
            defaultValue={q}
            placeholder="جستجوی کد محموله، راننده یا مسیر..."
            aria-label="جستجوی محموله"
            dir="auto"
          />
          <button type="submit">جستجو</button>
        </div>
      </form>

      {deals.length === 0 ? (
        <div className="transport-shipments-empty">
          <b>محموله‌ای یافت نشد.</b>
          <p>
            {hasActiveFilter
              ? 'با فیلتر فعلی موردی ثبت نشده — فیلتر را تغییر دهید یا جستجو را پاک کنید.'
              : 'در حال حاضر محموله‌ی جاری‌ای به این شرکت سپرده نشده.'}
          </p>
          {q && (
            <p className="transport-shipments-empty-hint">
              عبارت جستجو: <bdi dir="ltr">{q}</bdi>
            </p>
          )}
        </div>
      ) : (
        <div className="transport-shipments-list" role="list">
          {deals.map((deal) => {
            const code = shortShipmentCode(deal.id)
            const gradeCode = (deal.materialListing as unknown as { grade?: { code: string } } | null)?.grade?.code
            const origin = originLabel(
              deal.materialListing as unknown as { province: string; city: string } | null,
            )
            const destination = destinationLabel(
              deal.purchaseRequest as unknown as { province: string | null } | null,
            )
            const isAttention = deal.driverSilenceFlaggedAt != null
            const statusKey = isAttention && status === 'attention' ? 'attention' : deal.status
            const badge =
              statusKey === 'attention'
                ? ATTENTION_LABEL
                : (CARRIER_STATUS[deal.status] ?? {
                    label: deal.status,
                    bg: colors.neutralBg,
                    color: colors.neutralText,
                  })

            // راننده: ترجیح با رابطه‌ی زنده، وگرنه snapshot تاییدیه‌ی بارگیری
            const loadingConfirmation =
              (deal.confirmations as unknown as Array<{
                type: string
                driverName: string | null
                driverPhone: string | null
                vehiclePlate: string | null
                vehicleType: string | null
              }>).find((c) => c.type === 'loading') ?? (deal.confirmations as unknown as Array<never>)[0]

            const driverName =
              (deal.driver as unknown as { fullName: string } | null)?.fullName ??
              (loadingConfirmation as unknown as { driverName: string | null } | undefined)?.driverName ??
              null
            const driverPhone =
              (deal.driver as unknown as { phone: string } | null)?.phone ??
              (loadingConfirmation as unknown as { driverPhone: string | null } | undefined)?.driverPhone ??
              null
            const vehiclePlate =
              (loadingConfirmation as unknown as { vehiclePlate: string | null } | undefined)?.vehiclePlate ?? null
            const vehicleTypeRaw =
              (loadingConfirmation as unknown as { vehicleType: string | null } | undefined)?.vehicleType ?? null
            const vehicleType = vehicleTypeRaw ? (VEHICLE_TYPE_LABEL[vehicleTypeRaw] ?? vehicleTypeRaw) : null

            return (
              <article key={deal.id} className="transport-shipments-card" role="listitem">
                <div className="transport-shipments-card-identity">
                  <span className="transport-shipments-dot" aria-hidden="true" />
                  <div className="transport-shipments-identity-main">
                    <code dir="ltr" title={deal.id} className="transport-shipments-code">
                      {code}
                    </code>
                    <span className="transport-shipments-product">
                      {gradeCode ?? 'بدون گرید'} — {String(deal.quantity)}
                    </span>
                    <span className="transport-shipments-date">{formatFaDate(deal.createdAt as unknown as Date)}</span>
                  </div>
                </div>

                <div className="transport-shipments-card-route">
                  <span className="transport-shipments-cell-label">مسیر سفر</span>
                  <span className="transport-shipments-route-value">
                    <span>{origin}</span>
                    <span aria-hidden="true" className="transport-shipments-route-arrow">
                      ←
                    </span>
                    <span>{destination}</span>
                  </span>
                </div>

                <div className="transport-shipments-card-driver">
                  <span className="transport-shipments-cell-label">راننده</span>
                  {driverName ? (
                    <span className="transport-shipments-driver">
                      <span className="transport-shipments-avatar" aria-hidden="true">
                        {initialsFromName(driverName)}
                      </span>
                      <span className="transport-shipments-driver-meta">
                        <b>{driverName}</b>
                        <small dir="ltr">{driverPhone ?? '—'}</small>
                      </span>
                    </span>
                  ) : (
                    <span className="transport-shipments-muted">—</span>
                  )}
                </div>

                <div className="transport-shipments-card-vehicle">
                  <span className="transport-shipments-cell-label">خودرو</span>
                  <span className="transport-shipments-vehicle-value" dir="ltr">
                    {vehiclePlate ?? '—'}
                  </span>
                  <small className="transport-shipments-vehicle-type">{vehicleType ?? '—'}</small>
                </div>

                <div className="transport-shipments-card-status">
                  <span className="transport-shipments-cell-label">وضعیت</span>
                  <span
                    className="transport-shipments-badge"
                    style={{ background: badge.bg, color: badge.color }}
                  >
                    <span className="transport-shipments-badge-dot" style={{ background: badge.color }} aria-hidden="true" />
                    {badge.label}
                  </span>
                  {isAttention && deal.driverSilenceFlaggedAt && (
                    <small className="transport-shipments-attention-hint">
                      از {formatFaDateTime(deal.driverSilenceFlaggedAt as unknown as Date)}
                    </small>
                  )}
                </div>

                <div className="transport-shipments-card-action">
                  <Link href={`/my-deals/${deal.id}`} className="transport-shipments-detail-link">
                    مشاهده جزئیات
                  </Link>
                </div>
              </article>
            )
          })}
        </div>
      )}
    </div>
  )
}

function AccessCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="transport-panel-page">
      <div className="transport-panel-access-card">
        <h1>{title}</h1>
        <p>{children}</p>
      </div>
    </div>
  )
}
