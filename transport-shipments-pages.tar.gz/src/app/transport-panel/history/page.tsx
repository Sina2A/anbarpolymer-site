import Link from 'next/link'
import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { colors } from '@/lib/styles/tokens'

export const dynamic = 'force-dynamic'

const PAGE_SIZE = 20
const HISTORY_STATUSES = ['delivered', 'settled', 'void', 'cancelled'] as const
type HistoryStatus = (typeof HISTORY_STATUSES)[number]
type HistoryStatusParam = 'all' | HistoryStatus | 'delivered_group'

const ALLOWED_HISTORY_STATUSES: ReadonlySet<string> = new Set<string>([
  'all',
  'delivered',
  'void',
  'cancelled',
])

const CARRIER_STATUS: Record<string, { label: string; bg: string; color: string }> = {
  delivered: { label: 'تحویل‌شده', bg: colors.successBg, color: colors.successText },
  settled: { label: 'تسویه‌شده', bg: colors.successBg, color: colors.successText },
  void: { label: 'متوقف‌شده', bg: colors.dangerBg, color: colors.dangerText },
  cancelled: { label: 'لغوشده', bg: colors.dangerBg, color: colors.dangerText },
}

const VEHICLE_TYPE_LABEL: Record<string, string> = {
  truck: 'کامیون',
  trailer: 'تریلی',
  khavar: 'خاور',
  pickup: 'وانت',
}

type SearchParams = Record<string, string | string[] | undefined>

function scalar(value: string | string[] | undefined): string | undefined {
  if (Array.isArray(value)) return value[0]
  return value
}

function normalizeSearchParams(params: SearchParams): { q: string; status: HistoryStatusParam; page: number } {
  const rawQ = scalar(params.q)?.trim() ?? ''
  const q = rawQ.slice(0, 80)
  const rawStatus = scalar(params.status)?.trim() ?? 'all'
  const status: HistoryStatusParam = ALLOWED_HISTORY_STATUSES.has(rawStatus)
    ? (rawStatus as HistoryStatusParam)
    : 'all'
  const rawPage = scalar(params.page)?.trim() ?? '1'
  const parsed = /^\d+$/.test(rawPage) ? parseInt(rawPage, 10) : 1
  const page = Number.isFinite(parsed) && parsed >= 1 ? parsed : 1
  return { q, status, page }
}

function shortShipmentCode(id: string): string {
  const head = id.replace(/[^a-zA-Z0-9]/g, '').slice(0, 8) || id.slice(0, 8)
  return `AP-${head.toUpperCase()}`
}

function originLabel(listing: { province: string; city: string } | null | undefined): string {
  if (!listing) return 'نامشخص'
  const province = listing.province?.trim() ?? ''
  const city = listing.city?.trim() ?? ''
  if (province && city) return `${province}، ${city}`
  return province || city || 'نامشخص'
}

function destinationLabel(purchaseRequest: { province: string | null } | null | undefined): string {
  const province = purchaseRequest?.province?.trim() ?? ''
  return province || 'نامشخص'
}

function formatFaDate(value: Date): { date: string; time: string } {
  const d = new Date(value)
  return {
    date: d.toLocaleDateString('fa-IR'),
    time: d.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
  }
}

function buildSearchWhere(q: string): object | null {
  if (!q) return null
  return {
    OR: [
      { id: { contains: q } },
      { quantity: { contains: q } },
      { materialListing: { grade: { code: { contains: q } } } },
      { materialListing: { province: { contains: q } } },
      { materialListing: { city: { contains: q } } },
      { driver: { fullName: { contains: q } } },
      { driver: { phone: { contains: q } } },
      { purchaseRequest: { province: { contains: q } } },
      { confirmations: { some: { vehiclePlate: { contains: q } } } },
      { confirmations: { some: { driverName: { contains: q } } } },
    ],
  }
}

function buildPageHref(base: { q: string; status: HistoryStatusParam }, page: number): string {
  const sp = new URLSearchParams()
  if (base.q) sp.set('q', base.q)
  if (base.status !== 'all') sp.set('status', base.status)
  if (page !== 1) sp.set('page', String(page))
  const qs = sp.toString()
  return `/transport-panel/history${qs ? `?${qs}` : ''}`
}

export default async function TransportHistoryPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>
}) {
  const user = await getCurrentUser()
  const company = await prisma.transportCompany.findUnique({ where: { managerUserId: user.id } })

  if (!company) {
    return (
      <AccessCard title="پنل شرکت حمل‌ونقل — دسترسی ندارید">
        این حساب به هیچ شرکت حمل‌ونقلی وصل نیست. با پشتیبانی انبار پلیمر تماس بگیرید.
      </AccessCard>
    )
  }
  if (!company.logisticsAccessEnabled) {
    return (
      <AccessCard title="پنل شرکت حمل‌ونقل — دسترسی غیرفعال">
        دسترسی پنل حمل‌ونقل برای <b>{company.name}</b> در حال حاضر غیرفعاله. برای فعال‌شدن با پشتیبانی
        انبار پلیمر تماس بگیرید.
      </AccessCard>
    )
  }

  const params = await searchParams
  const { q, status, page: rawPage } = normalizeSearchParams(params)
  const searchWhere = buildSearchWhere(q)

  const baseHistoryWhere = {
    transportCompanyId: company.id,
    status: { in: [...HISTORY_STATUSES] as string[] },
  }

  const [totalHistory, deliveredCount, voidCount, cancelledCount] = await Promise.all([
    prisma.deal.count({ where: { ...baseHistoryWhere, ...(searchWhere ?? {}) } }),
    prisma.deal.count({
      where: {
        transportCompanyId: company.id,
        status: { in: ['delivered', 'settled'] },
        ...(searchWhere ?? {}),
      },
    }),
    prisma.deal.count({
      where: { transportCompanyId: company.id, status: 'void', ...(searchWhere ?? {}) },
    }),
    prisma.deal.count({
      where: { transportCompanyId: company.id, status: 'cancelled', ...(searchWhere ?? {}) },
    }),
  ])

  const listWhere: Record<string, unknown> = {
    transportCompanyId: company.id,
  }

  if (status === 'all') {
    ;(listWhere as Record<string, unknown>).status = { in: [...HISTORY_STATUSES] as string[] }
  } else if (status === 'delivered') {
    // فیلتر «تحویل‌شده» شامل delivered و settled است
    ;(listWhere as Record<string, unknown>).status = { in: ['delivered', 'settled'] }
  } else {
    ;(listWhere as Record<string, unknown>).status = status
  }

  if (searchWhere) Object.assign(listWhere, searchWhere)

  const totalFiltered = await prisma.deal.count({ where: listWhere as never })
  const totalPages = Math.max(1, Math.ceil(totalFiltered / PAGE_SIZE))
  const page = rawPage > totalPages ? 1 : rawPage
  const skip = (page - 1) * PAGE_SIZE

  const deals = await prisma.deal.findMany({
    where: listWhere as never,
    orderBy: { createdAt: 'desc' },
    skip,
    take: PAGE_SIZE,
    include: {
      driver: true,
      materialListing: { include: { grade: true } },
      purchaseRequest: true,
      confirmations: { orderBy: { confirmedAt: 'desc' }, take: 4 },
    },
  })

  const hasFilter = status !== 'all' || q.length > 0
  const rangeStart = totalFiltered === 0 ? 0 : skip + 1
  const rangeEnd = Math.min(skip + deals.length, totalFiltered)

  return (
    <div className="transport-shipments-page" dir="rtl">
      <div className="transport-panel-page-heading">
        <h1>تاریخچه‌ی محموله‌ها</h1>
        <p>
          <b>{company.name}</b> — تاریخچه‌ی کامل محموله‌های این شرکت حمل‌ونقل
        </p>
      </div>

      <div className="transport-shipments-summary">
        <div className="transport-shipments-summary-card">
          <span className="transport-shipments-summary-label">کل</span>
          <b className="transport-shipments-summary-value">{totalHistory.toLocaleString('fa-IR')}</b>
        </div>
        <div className="transport-shipments-summary-card">
          <span className="transport-shipments-summary-label">تحویل‌شده</span>
          <b className="transport-shipments-summary-value">{deliveredCount.toLocaleString('fa-IR')}</b>
        </div>
        <div className="transport-shipments-summary-card">
          <span className="transport-shipments-summary-label">متوقف‌شده</span>
          <b className="transport-shipments-summary-value">{voidCount.toLocaleString('fa-IR')}</b>
        </div>
        <div className="transport-shipments-summary-card">
          <span className="transport-shipments-summary-label">لغوشده</span>
          <b className="transport-shipments-summary-value">{cancelledCount.toLocaleString('fa-IR')}</b>
        </div>
      </div>

      <form method="GET" className="transport-shipments-toolbar" role="search" aria-label="فیلتر تاریخچه">
        <label className="transport-shipments-select-wrap" aria-label="فیلتر وضعیت">
          <select name="status" defaultValue={status} aria-label="وضعیت محموله">
            <option value="all">همه وضعیت‌ها</option>
            <option value="delivered">تحویل‌شده</option>
            <option value="void">متوقف‌شده</option>
            <option value="cancelled">لغوشده</option>
          </select>
          <span aria-hidden="true" className="transport-shipments-select-caret">
            ▾
          </span>
        </label>
        <div className="transport-shipments-search">
          <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
            <circle cx="11" cy="11" r="7" />
            <path d="M15.5 15.5 21 21" />
          </svg>
          <input
            name="q"
            defaultValue={q}
            placeholder="جستجوی کد محموله، محصول، راننده یا مسیر..."
            aria-label="جستجوی تاریخچه"
            dir="auto"
          />
          <button type="submit">جستجو</button>
        </div>
      </form>

      {deals.length === 0 ? (
        <div className="transport-shipments-empty">
          <b>موردی یافت نشد.</b>
          <p>
            {hasFilter
              ? 'با فیلتر فعلی موردی ثبت نشده — فیلتر را تغییر دهید یا جستجو را پاک کنید.'
              : 'هنوز محموله‌ی تکمیل‌شده‌ای برای این شرکت ثبت نشده.'}
          </p>
        </div>
      ) : (
        <div className="transport-shipments-history-card">
          <div className="table-scroll">
            <table className="transport-shipments-table">
              <thead>
                <tr>
                  <th style={{ width: 56 }}>#</th>
                  <th>محموله</th>
                  <th>مسیر سفر</th>
                  <th>راننده / خودرو</th>
                  <th>تاریخ حمل</th>
                  <th>وضعیت</th>
                  <th style={{ width: 92 }} />
                </tr>
              </thead>
              <tbody>
                {deals.map((deal, idx) => {
                  const code = shortShipmentCode(deal.id)
                  const gradeCode = (deal.materialListing as unknown as { grade?: { code: string } } | null)?.grade
                    ?.code
                  const quantity = String(deal.quantity)
                  const origin = originLabel(
                    deal.materialListing as unknown as { province: string; city: string } | null,
                  )
                  const destination = destinationLabel(
                    deal.purchaseRequest as unknown as { province: string | null } | null,
                  )
                  const badge = CARRIER_STATUS[deal.status] ?? {
                    label: deal.status,
                    bg: colors.neutralBg,
                    color: colors.neutralText,
                  }
                  const loadingConfirmation =
                    (deal.confirmations as unknown as Array<{
                      type: string
                      driverName: string | null
                      vehiclePlate: string | null
                      vehicleType: string | null
                      confirmedAt: Date
                    }>).find((c) => c.type === 'loading') ??
                    (deal.confirmations as unknown as Array<never>)[0]
                  const driverName =
                    (deal.driver as unknown as { fullName: string } | null)?.fullName ??
                    (loadingConfirmation as unknown as { driverName: string | null } | undefined)?.driverName ??
                    null
                  const vehiclePlate =
                    (loadingConfirmation as unknown as { vehiclePlate: string | null } | undefined)?.vehiclePlate ??
                    null
                  const vehicleTypeRaw =
                    (loadingConfirmation as unknown as { vehicleType: string | null } | undefined)?.vehicleType ??
                    null
                  const vehicleType = vehicleTypeRaw
                    ? (VEHICLE_TYPE_LABEL[vehicleTypeRaw] ?? vehicleTypeRaw)
                    : null
                  const dateVal = (loadingConfirmation as unknown as { confirmedAt: Date } | undefined)?.confirmedAt ??
                    (deal.createdAt as unknown as Date)
                  const { date, time } = formatFaDate(dateVal)
                  const rowNumber = skip + idx + 1

                  return (
                    <tr key={deal.id}>
                      <td className="transport-shipments-col-index">{rowNumber.toLocaleString('fa-IR')}</td>
                      <td>
                        <div className="transport-shipments-cell-shipment">
                          <code dir="ltr" title={deal.id}>
                            {code}
                          </code>
                          <span>
                            {gradeCode ?? 'بدون گرید'} · {quantity}
                          </span>
                        </div>
                      </td>
                      <td>
                        <span className="transport-shipments-route-inline">
                          {origin} ← {destination}
                        </span>
                      </td>
                      <td>
                        <span className="transport-shipments-driver-compact">
                          <b>{driverName ?? '—'}</b>
                          <small dir="ltr">
                            {vehiclePlate ?? '—'}
                            {vehicleType ? ` · ${vehicleType}` : ''}
                          </small>
                        </span>
                      </td>
                      <td>
                        <span className="transport-shipments-date-compact">
                          <b>{date}</b>
                          <small>{time}</small>
                        </span>
                      </td>
                      <td>
                        <span className="transport-shipments-badge" style={{ background: badge.bg, color: badge.color }}>
                          <span
                            className="transport-shipments-badge-dot"
                            style={{ background: badge.color }}
                            aria-hidden="true"
                          />
                          {badge.label}
                        </span>
                      </td>
                      <td>
                        <Link href={`/my-deals/${deal.id}`} className="transport-shipments-detail-link is-table">
                          جزئیات
                        </Link>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>

          <div className="transport-shipments-table-footer">
            <span>
              نمایش {rangeStart.toLocaleString('fa-IR')} تا {rangeEnd.toLocaleString('fa-IR')} از{' '}
              {totalFiltered.toLocaleString('fa-IR')}
            </span>
            <nav className="transport-shipments-pagination" aria-label="صفحه‌بندی" dir="ltr">
              <Link
                href={buildPageHref({ q, status }, Math.max(1, page - 1))}
                aria-disabled={page <= 1}
                className={page <= 1 ? 'is-disabled' : undefined}
                aria-label="صفحه‌ی قبل"
              >
                ‹
              </Link>
              {Array.from({ length: totalPages }, (_, i) => i + 1)
                .slice(Math.max(0, page - 3), Math.min(totalPages, page + 2))
                .map((n) => (
                  <Link
                    key={n}
                    href={buildPageHref({ q, status }, n)}
                    className={n === page ? 'is-active' : undefined}
                    aria-current={n === page ? 'page' : undefined}
                    aria-label={`صفحه‌ی ${n}`}
                  >
                    {n}
                  </Link>
                ))}
              <Link
                href={buildPageHref({ q, status }, Math.min(totalPages, page + 1))}
                aria-disabled={page >= totalPages}
                className={page >= totalPages ? 'is-disabled' : undefined}
                aria-label="صفحه‌ی بعد"
              >
                ›
              </Link>
            </nav>
          </div>
        </div>
      )}
    </div>
  )
}

function AccessCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="transport-panel-page">
      <div className="transport-panel-access-card">
        <h1>{title}</h1>
        <p>{children}</p>
      </div>
    </div>
  )
}
