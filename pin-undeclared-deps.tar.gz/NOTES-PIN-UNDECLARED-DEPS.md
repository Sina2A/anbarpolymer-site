# رفع دائمی — Pin‌کردن وابستگی‌های اعلام‌نشده (رفع چرخه‌ی خوابیدن سایت)

## خلاصه

علتِ چهاربار خوابیدن سایت این بود که چند پکیجِ **استفاده‌شده در کد** هیچ‌وقت در
`package.json` ثبت نشده بودند و فقط روی دیسک به‌صورت دستی/گذرا نصب بودند
(`extraneous`). هر `npm install` معمولی این‌ها را «اضافی» می‌دید و **حذف** می‌کرد →
شکست Build.

این تسک چرخه را برای همیشه بست: همه‌ی وابستگی‌های واقعیِ اعلام‌نشده با **نسخه‌ی دقیق
Pin‌شده** (بدون `^`/`~`) به `package.json` اضافه شدند، و یک اسکریپت `postinstall`
اضافه شد تا نصب از صفر همیشه کامل و قابل‌Build باشد.

## ممیزی کامل (طبق قاعده‌ی ۵) — مقایسه‌ی importهای پروژه با `dependencies`

با اسکن سراسریِ importها در برابر `package.json` مشخص شد مشکل **فراتر از ۴ پکیجِ
نام‌برده** بود. همه‌ی مواردِ اعلام‌نشده‌ی واقعی:

### وابستگی‌های زمان‌اجرا (به `dependencies`، Pin دقیق)

| پکیج | نسخه‌ی Pin‌شده | وضعیت | محل استفاده |
|---|---|---|---|
| `lucide-react` | `1.48.0` | نام‌برده — extraneous | `dashboard`, `MobileGradeCatalog`, `AdminMobileDrawer`, `MoreSheet`, ... |
| `@tanstack/react-table` | `8.21.3` (v8 ✓) | نام‌برده — extraneous | `BenchmarkHistoryTable.tsx` (`useReactTable`/`getCoreRowModel`/`flexRender`) |
| `echarts` | `6.1.0` | نام‌برده — extraneous | `BenchmarkPriceChart.tsx` |
| `echarts-for-react` | `3.0.6` | نام‌برده — extraneous | `BenchmarkPriceChart.tsx` |
| `zod` | `4.4.3` | **قربانیِ جدید** — فقط ترانزیتیو (از `eslint-config-next`) | `schemas/article.ts`, `schemas/purchaseRequest.ts`, `schemas/rfq.ts` |
| `d3-geo` | `3.1.0` | **قربانیِ جدید** — فقط ترانزیتیو (از `react-simple-maps`) | `IranMap.tsx` |
| `topojson-client` | `3.1.0` | **قربانیِ جدید** — فقط ترانزیتیو | `IranMap.tsx` |

### وابستگی‌های فقط-تایپ (به `devDependencies`، Pin دقیق)

| پکیج | نسخه‌ی Pin‌شده | محل استفاده |
|---|---|---|
| `@types/d3-geo` | `3.1.0` | تایپِ `d3-geo` در `IranMap.tsx` |
| `@types/geojson` | `7946.0.16` | `IranMap.tsx`, `types/topojson-client.d.ts` |
| `@types/topojson-specification` | `1.0.5` | `IranMap.tsx`, `types/topojson-client.d.ts` |

> `zod`/`d3-geo`/`topojson-client` امروز فقط چون ترانزیتیوِ پکیج‌های دیگر بودند اتفاقی
> resolve می‌شدند؛ با هر تغییرِ آن والدها یا یک prune، دقیقاً همان چرخه‌ی خوابیدن دوباره
> برمی‌گشت. Pin مستقیم این ریسک را حذف کرد.

## `@sentry/nextjs` — ابتدا مستثنا شد، سپس **اضافه/Pin شد** (اصلاح)

> **اصلاحیه:** تصمیمِ اولیه‌ی «اضافه نشود» اشتباه بود و برگردانده شد. build واقعی روی
> سرور بدون این پکیج شکست و کاربر آن را دستی نصب کرد؛ حالا در همین مخزن هم `@sentry/nextjs`
> با نسخه‌ی دقیق **`10.75.3`** (شاخه‌ی ۱۰) Pin شده است.

### چه چیزی درست بود و چه چیزی اشتباه
بررسیِ اولیه فقط **همین checkout** را دید و این‌ها واقعاً درست بودند: نصب نبود، در
`package-lock.json` نبود (شمارش = ۰)، و هیچ `import`ی از `@sentry/...` یا `withSentryConfig`
در این مخزن وجود نداشت (تنها ردِ Sentry: یک route تستی + کامنت‌ها).

**خطای واقعی:** نتیجه‌ی سطحِ *checkout* («این‌جا استفاده نمی‌شود») به‌اشتباه به سطحِ
*deployment* تعمیم داده شد. خودِ گزارش، `@sentry/nextjs@v10` را «تاییدشده‌ی امروز» خوانده
بود — یعنی محیطِ کاریِ کاربر آن را داشت و لازم داشت. فایل‌هایی که build سرور می‌خواست
(`sentry.client.config.ts` / `sentry.edge.config.ts` / `sentry.server.config.ts` /
`next.config.js`) **در این مخزن وجود ندارند**؛ آن‌ها فقط در deploymentِ سرور هستند، پس
جست‌وجوی محلی هرگز نمی‌توانست آن‌ها را ببیند. اشتباه این بود که این شکافِ «مخزن در برابر
سرور» صریحاً اعلام نشد و به‌جایش نتیجه‌ی قطعیِ «بی‌استفاده» گرفته شد.

### وضعیت فعلی (اعمال‌شده)
- `@sentry/nextjs` = **`10.75.3`** (exact، بدون caret) در `dependencies`. peerDependency آن
  صراحتاً `next` را تا `^16.0.0-0` پشتیبانی می‌کند (سازگار با `next@16.2.12`).
- `@sentry/cli@2.58.6` یک اسکریپتِ `postinstall` دارد؛ ورودیِ `"@sentry/cli@2.58.6": true`
  به `allowScripts` افزوده شد (هم‌الگو با ۵ ورودیِ موجود).
- در نسخه‌ی ۲.۵۸.۶، باینریِ sentry-cli از راهِ **وابستگیِ اختیاریِ پلتفرمی** می‌آید (نه دانلودِ
  postinstall). lockfile هر ۸ باینریِ پلتفرم را ثبت کرده — از جمله `@sentry/cli-linux-x64`
  (os=linux) — پس `npm install` روی سرورِ لینوکسی باینریِ درست را خودکار می‌گیرد.
- راستی‌آزمایی: پاک‌کردنِ `tsconfig.tsbuildinfo` → `npx tsc --noEmit` سبز → `npm run build`
  با **EXIT 0** (`✓ Compiled successfully` / `Finished TypeScript` بدون خطا / `15/15` static).

> **باقی‌مانده (خارج از این تغییر):** خودِ پکیج نصب و buildپذیر است، اما در این مخزن
> **wire نشده** (نه `withSentryConfig`، نه DSN، نه فایل‌های `sentry.*.config.ts`). اگر
> deploymentِ سرور آن فایل‌های config را دارد، بهتر است در همین مخزن هم commit شوند تا
> واگراییِ «مخزن در برابر سرور» تکرار نشود. این فایل‌ها این‌جا ساخته نشدند چون محتوای
> واقعی‌شان (DSN/گزینه‌ها) این‌جا در دسترس نیست و ساختنِ حدسیِ آن‌ها = داده‌ی جعلی.

## کشفِ حین کار — `postinstall: prisma generate` (رفعِ حیاتیِ نصب‌ازصفر)

قدمِ راستی‌آزماییِ «`rm -rf node_modules` + نصبِ تازه» یک باگِ نهفته‌ی جدا را لو داد:
پروژه هیچ اسکریپت `postinstall` نداشت، پس روی نصبِ از صفر **Prisma Client تولید
نمی‌شد** (`Cannot find module '.prisma/client/default'`). بدون کلاینتِ تولیدشده، تایپِ
`@/lib/prisma` فرومی‌پاشد و Build در مرحله‌ی type-check می‌شکند
(`admin-articles/page.tsx:160: Parameter 'a' implicitly has an 'any' type`).

> نکته: یک `tsc --noEmit`ِ اولیه به‌اشتباه سبز شد چون `incremental:true` از یک
> `tsconfig.tsbuildinfo`ِ کهنه (مربوط به قبل از پاک‌سازی) استفاده کرد. کش پاک شد و
> بررسیِ نهایی صادقانه تکرار شد.

رفع (کاملاً درونِ `package.json`، بدون دست‌زدن به کد):

```json
"scripts": { "postinstall": "prisma generate" }
```

این دقیقاً همان سناریوی «نصب از صفر» که تسک مدرکش را خواسته بود مقاوم می‌کند.

## تغییرات (فقط زیرساخت — هیچ فایل کدی دست نخورد)

- `package.json` — ۷ وابستگیِ زمان‌اجرا + ۳ تایپِ dev با Pin دقیق + اسکریپت `postinstall`.
- `package-lock.json` — با نصبِ معمولیِ `--save` و سپس نصبِ کاملِ از صفر بازتولید شد.

## راستی‌آزمایی نهایی — نصب از صفر (مدرک قطعی)

مراحلِ اجراشده:

1. `rm -rf node_modules` (تأیید: پوشه حذف شد).
2. `npm install` **بدون هیچ Flagی** → `added 570 packages`؛ `postinstall` خودکار اجرا شد:
   `✔ Generated Prisma Client (v7.9.1)`.
3. حذفِ کش‌های کهنه‌ی tsc (`tsconfig.tsbuildinfo`, `.next/cache/.tsbuildinfo`).
4. `npx tsc --noEmit` → **بدون خطا** (EXIT 0).
5. `npm run build` → **موفق** (EXIT 0):
   `✓ Compiled successfully` → `Finished TypeScript` (بدون خطا) →
   `✓ Generating static pages (15/15)` → ۸۲ مسیر build شد.
6. بررسیِ نهاییِ `npm ls --depth=0` → **`EXTRANEOUS_COUNT=0`** (باگ دیگر نمی‌تواند فعال شود).

خروجیِ کاملِ Build در فایلِ `build-output.txt` (داخلِ همین بسته) ضمیمه است.

## قاعده برای آینده

هر پکیجی که در کد import می‌شود باید در `package.json` اعلام شود — هرگز به resolveِ
ترانزیتیوی تکیه نکنید. برای اطمینان، importهای پروژه را دوره‌ای با `dependencies`
مقایسه کنید تا هیچ `extraneous`‌ای دوباره شکل نگیرد.
