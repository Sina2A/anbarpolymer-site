'use server'

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { logAudit } from '@/lib/logger'
import { revalidatePath } from 'next/cache'

// ==================== ساخت هشدار قیمت ====================
//
// نکته‌ی طراحی: این هشدار به هیچ موتور قیمت‌گذاری/بنچمارک وصل نیست.
// مبنای مقایسه فقط قیمت واقعیِ ثبت‌شده در سیستم است: WarehouseStock.priceRial
// (ریال/کیلو) که کارشناس وارد می‌کنه. targetPriceToman تومان/کیلوئه، پس
// مقایسه همیشه با تقسیم priceRial بر ۱۰ انجام می‌شه.

export async function createPriceAlertAction(formData: FormData) {
  const user = await getCurrentUser()

  const gradeId = String(formData.get('gradeId') || '').trim()
  const targetPriceToman = parseFloat(String(formData.get('targetPriceToman') || ''))

  if (!gradeId) throw new Error('گرید مشخص نیست.')
  if (!targetPriceToman || targetPriceToman <= 0) throw new Error('سقف قیمت باید بیشتر از صفر باشه.')

  const grade = await prisma.grade.findUnique({
    where: { id: gradeId },
    select: { id: true, code: true, isActive: true },
  })
  if (!grade) throw new Error('گرید انتخاب‌شده وجود نداره.')
  if (!grade.isActive) throw new Error('این گرید فعال نیست.')

  // جلوگیری از هشدار تکراری روی همون گرید (فقط هشدارهای فعال)
  const existing = await prisma.priceAlert.findFirst({
    where: { userId: user.id, gradeId: grade.id, status: 'active' },
    select: { id: true },
  })
  if (existing) throw new Error('برای این گرید یه هشدار فعال داری. اول اون رو لغو کن.')

  await prisma.priceAlert.create({
    data: {
      userId: user.id,
      gradeId: grade.id,
      targetPriceToman,
      status: 'active',
    },
  })

  await logAudit('price-alert', `هشدار قیمت ${grade.code} — سقف ${targetPriceToman} تومان/کیلو`, user.id, {
    gradeId: grade.id,
    targetPriceToman,
  })

  revalidatePath('/price-alerts')
}

// ==================== لغو هشدار ====================

export async function cancelPriceAlertAction(alertId: string) {
  const user = await getCurrentUser()

  if (!alertId) throw new Error('شناسه‌ی هشدار مشخص نیست.')

  const alert = await prisma.priceAlert.findUnique({
    where: { id: alertId },
    select: { id: true, userId: true, status: true, grade: { select: { code: true } } },
  })
  if (!alert) throw new Error('هشدار پیدا نشد.')
  if (alert.userId !== user.id) throw new Error('فقط سازنده‌ی هشدار می‌تونه لغوش کنه.')
  if (alert.status !== 'active') throw new Error('این هشدار فعال نیست.')

  await prisma.priceAlert.update({
    where: { id: alertId },
    data: { status: 'cancelled' },
  })

  await logAudit('price-alert', `هشدار قیمت ${alert.grade.code} لغو شد`, user.id, { alertId })

  revalidatePath('/price-alerts')
}

// ==================== بررسی و فعال‌سازی هشدارها ====================
//
// این تابع رو بعد از هر بروزرسانی موجودی/قیمت انبار صدا بزن (یا از یه job
// دوره‌ای). برای هر گرید، کمترین قیمت موجود در انبارها رو پیدا می‌کنه و
// هشدارهای فعالی که سقف‌شون رسیده رو triggered می‌کنه.
//
// اطلاع‌رسانی: فقط داخل سایت (لیست «هشدارهای فعال‌شده») — پیامک/ایمیل نداریم.

export async function checkPriceAlerts(gradeId?: string) {
  const activeAlerts = await prisma.priceAlert.findMany({
    where: { status: 'active', ...(gradeId ? { gradeId } : {}) },
    select: { id: true, gradeId: true, targetPriceToman: true, userId: true },
  })

  if (activeAlerts.length === 0) return { checked: 0, triggered: 0 }

  const gradeIds = [...new Set(activeAlerts.map((a) => a.gradeId))]

  // کمترین قیمت واقعیِ هر گرید در انبارهایی که موجودی دارن
  const stocks = await prisma.warehouseStock.findMany({
    where: { gradeId: { in: gradeIds }, quantityTon: { gt: 0 } },
    select: { gradeId: true, priceRial: true },
  })

  const minPriceRial = new Map<string, number>()
  for (const s of stocks) {
    const current = minPriceRial.get(s.gradeId)
    if (current === undefined || s.priceRial < current) minPriceRial.set(s.gradeId, s.priceRial)
  }

  let triggered = 0

  for (const alert of activeAlerts) {
    const rial = minPriceRial.get(alert.gradeId)
    if (rial === undefined) continue

    const toman = rial / 10
    if (toman > alert.targetPriceToman) continue

    await prisma.priceAlert.update({
      where: { id: alert.id },
      data: { status: 'triggered', triggeredAt: new Date(), triggeredPrice: rial },
    })
    triggered++
  }

  if (triggered > 0) revalidatePath('/price-alerts')

  return { checked: activeAlerts.length, triggered }
}
