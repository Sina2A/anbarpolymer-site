'use client'

// فرم فیلتر بازار — فقط state باز/بسته‌ی شیتِ موبایل اینجاست.
// خودِ فیلدها (سرچ، چیپ‌ها، سلکت‌ها) server-render می‌شن و به‌صورت children
// پاس داده می‌شن؛ فرم همچنان GET ساده است و بدون JS هم کار می‌کنه.
// دسکتاپ: پنل فیلتر درجا نمایش داده می‌شه و دکمه‌ی باز/بستن مخفیه (CSS صفحه).
// موبایل (≤899px): پنل به bottom sheet تبدیل می‌شه — z-index همان .mobile-sheet
// (scrim=41، sheet=42) تا روی نوار پایین (40) و زیر هدر sticky (50) بنشیند.

import { createContext, useContext, useEffect, useState } from 'react'
import { SlidersHorizontal, X } from 'lucide-react'

const SheetCtx = createContext<{ open: boolean; setOpen: (v: boolean) => void }>({
  open: false,
  setOpen: () => {},
})

export default function MarketFilterForm({
  action,
  children,
}: {
  action: string
  children: React.ReactNode
}) {
  const [open, setOpen] = useState(false)

  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false)
    }
    const prevOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    window.addEventListener('keydown', onKey)
    return () => {
      document.body.style.overflow = prevOverflow
      window.removeEventListener('keydown', onKey)
    }
  }, [open])

  return (
    <SheetCtx.Provider value={{ open, setOpen }}>
      <form method="GET" action={action} className={`mk-filter${open ? ' is-open' : ''}`}>
        {children}
        <button
          type="button"
          className="mk-scrim"
          aria-label="بستن فیلترها"
          tabIndex={-1}
          onClick={() => setOpen(false)}
        />
      </form>
    </SheetCtx.Provider>
  )
}

/** دکمه‌ی «فیلترها (n)» کنار سرچ — فقط روی موبایل دیده می‌شه. */
export function MarketFilterToggle({ activeCount }: { activeCount: number }) {
  const { open, setOpen } = useContext(SheetCtx)
  return (
    <button
      type="button"
      className="mk-filter-toggle"
      aria-expanded={open}
      aria-controls="mk-panel"
      onClick={() => setOpen(true)}
    >
      <SlidersHorizontal size={16} strokeWidth={2} aria-hidden />
      فیلترها
      {activeCount > 0 && <span className="mk-badge">{activeCount.toLocaleString('fa-IR')}</span>}
    </button>
  )
}

/** دکمه‌ی بستن داخل سربرگ شیت. */
export function MarketFilterClose() {
  const { setOpen } = useContext(SheetCtx)
  return (
    <button type="button" className="mk-sheet-close" aria-label="بستن" onClick={() => setOpen(false)}>
      <X size={18} strokeWidth={2} aria-hidden />
    </button>
  )
}
