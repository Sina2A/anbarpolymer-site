'use client'

import { useState } from 'react'
import { createPortal } from 'react-dom'
import { colors, radius, fontSize } from '@/lib/styles/tokens'
import { PurchaseRequestDialog } from '@/components/PurchaseRequestDetailModal'
import TrustCardModal from '@/components/TrustCardModal'

type Props = {
  request: any
  isLoggedIn: boolean
}

// ستون‌های تب تقاضا — دقیقاً مطابق market-table-preview.html.
// نکته‌ی minmax(0, Xfr) مثل Supply — برای جلوگیری از Grid Blowout.
export const DEMAND_TABLE_COLUMNS = 'minmax(0,1fr) minmax(0,.8fr) minmax(0,1fr) minmax(0,.8fr) minmax(0,.7fr) minmax(0,.7fr) minmax(0,.8fr) minmax(0,1.3fr)'

export default function DemandTableRow({ request, isLoggedIn }: Props) {
  const [open, setOpen] = useState(false)
  const [trustOpen, setTrustOpen] = useState(false)

  const expiresLabel = (() => {
    if (!request.expiresAt) return '—'
    const d = new Date(request.expiresAt)
    const diff = Math.ceil((d.getTime() - Date.now()) / (24 * 3600 * 1000))
    if (diff <= 0) return 'منقضی'
    if (diff === 1) return '۱ روز'
    return `${diff.toLocaleString('fa-IR')} روز`
  })()

  return (
    <>
      <div className="market-row-hover mk-row" style={rowStyle} onClick={() => setOpen(true)}>
        <div className="mk-cell-grade" style={gradeCellStyle}>
          <span style={gradeCodeStyle}>{request.grade.code}</span>
          <span style={gradeNameStyle}>
            {request.grade.producer} ({request.grade.category})
          </span>
        </div>

        <div data-label="مقدار موردنیاز" style={cellStyle}>{request.quantityTon} تن</div>

        <div data-label="سقف قیمت" style={priceCellStyle}>
          {request.maxPriceToman ? (
            <>
              <span style={priceNumStyle}>{request.maxPriceToman.toLocaleString('fa-IR')}</span>
              <span style={priceUnitStyle}>تومان/کیلو</span>
            </>
          ) : (
            <span style={cellStyle}>اعلام نشده</span>
          )}
        </div>

        <div data-label="استان تحویل" style={cellStyle}>{request.province || 'مهم نیست'}</div>
        <div data-label="انقضا" style={cellStyle}>{expiresLabel}</div>

        <div className="mk-cell-status" style={cellStyle}>
          <span style={{ ...badgeStyle, background: colors.darkGreenBg, color: colors.darkGreenText }}>باز</span>
        </div>

        <div data-label="ثبت" style={monoCellStyle}>{new Date(request.createdAt).toLocaleDateString('fa-IR')}</div>

        <div className="mk-actions" style={actionsStyle} onClick={(e) => e.stopPropagation()}>
          <button
            onClick={() => setTrustOpen(true)}
            type="button"
            className="mk-press mk-info"
            style={iconBtnStyle}
            title="فرآیند این درخواست"
            aria-label="فرآیند این درخواست"
          >
            i
          </button>
          {isLoggedIn ? (
            <a href={`/new-listing?request=${request.id}`} className="mk-press mk-action" style={actionBtnStyle}>پیشنهاد فروش</a>
          ) : (
            <a href="/login" className="mk-press mk-action" style={actionBtnStyle}>ورود برای پاسخ</a>
          )}
        </div>
      </div>

      {open &&
        createPortal(
          <PurchaseRequestDialog request={request} isLoggedIn={isLoggedIn} onClose={() => setOpen(false)} />,
          document.body,
        )}
      {trustOpen && <TrustCardModal variant="demand" onClose={() => setTrustOpen(false)} />}
    </>
  )
}

const rowStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: DEMAND_TABLE_COLUMNS,
  gap: 10,
  alignItems: 'center',
  background: colors.bgCard,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
  padding: '11px 16px',
  marginBottom: 8,
  fontSize: fontSize.sm,
  cursor: 'pointer',
  transition: 'border-color .15s, box-shadow .15s',
}
const gradeCellStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 1,
  minWidth: 0,
  lineHeight: 1.5,
}
const gradeCodeStyle: React.CSSProperties = {
  fontFamily: 'monospace',
  fontWeight: 800,
  fontSize: 13,
  color: colors.navy,
  whiteSpace: 'nowrap',
}
const gradeNameStyle: React.CSSProperties = {
  fontSize: fontSize.xs,
  color: colors.textMuted,
  whiteSpace: 'nowrap',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
}
const cellStyle: React.CSSProperties = {
  minWidth: 0,
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  whiteSpace: 'nowrap',
}
const monoCellStyle: React.CSSProperties = {
  ...cellStyle,
  direction: 'ltr',
  textAlign: 'right',
  fontFamily: 'monospace',
  color: colors.textMuted,
  fontSize: fontSize.xs,
  unicodeBidi: 'plaintext',
}
const badgeStyle: React.CSSProperties = {
  display: 'inline-block',
  fontSize: 10,
  fontWeight: 700,
  padding: '3px 9px',
  borderRadius: 999,
  whiteSpace: 'nowrap',
}
const priceCellStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 1,
  minWidth: 0,
}
const priceNumStyle: React.CSSProperties = {
  fontFamily: 'monospace',
  direction: 'ltr',
  textAlign: 'right',
  fontWeight: 800,
  color: colors.orange,
  whiteSpace: 'nowrap',
  unicodeBidi: 'plaintext',
}
const priceUnitStyle: React.CSSProperties = {
  fontSize: 9,
  color: colors.textMuted,
  whiteSpace: 'nowrap',
}
const actionsStyle: React.CSSProperties = {
  display: 'flex',
  gap: 6,
  alignItems: 'center',
  justifyContent: 'flex-start',
  flexShrink: 0,
  whiteSpace: 'nowrap',
}
// دکمه‌ی «i» — هم‌شکلِ دکمه‌ی i صفحه‌ی موجودی انبار (warehouses/[id]):
// دایره‌ی ۳۰×۳۰، حرف ساده‌ی «i» با فونت Arial (نه گلیف ⓘ که در Vazirmatn نامرکز می‌شه).
// بازخورد فقط هنگام کلیک (کلاس mk-press/mk-info در CSS صفحه‌ی بازار) — بدون هاور ماوس.
const iconBtnStyle: React.CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  width: 30,
  height: 30,
  borderRadius: 999,
  border: `1px solid ${colors.borderStrong}`,
  background: colors.bgCard,
  color: colors.navy,
  fontSize: fontSize.md,
  fontWeight: 700,
  fontStyle: 'normal',
  fontFamily: 'Arial, Helvetica, sans-serif',
  lineHeight: 1,
  cursor: 'pointer',
  flexShrink: 0,
  padding: 0,
}
const actionBtnStyle: React.CSSProperties = {
  background: colors.navy,
  color: '#fff',
  border: 'none',
  borderRadius: radius.sm,
  padding: '7px 14px',
  fontSize: fontSize.xs,
  fontWeight: 700,
  textDecoration: 'none',
  whiteSpace: 'nowrap',
}
