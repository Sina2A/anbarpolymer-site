import prisma from '@/lib/prisma'
import { getSurfaceHome } from '@/lib/surfaceHome'
import { getCurrentUserOrNull } from '@/lib/currentUser'
import SupplyTableRow, { SUPPLY_TABLE_COLUMNS } from '@/components/SupplyTableRow'
import DemandTableRow, { DEMAND_TABLE_COLUMNS } from '@/components/DemandTableRow'
import CurrencyTicker from '@/components/CurrencyTicker'
import PublicHeader from '@/components/PublicHeader'
import Footer from '@/components/Footer'
import MarketFilterForm, { MarketFilterToggle, MarketFilterClose } from '@/components/MarketFilterForm'
import { Search, SearchX, X } from 'lucide-react'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'

export const dynamic = 'force-dynamic'

const POLYMER_FAMILY_OPTIONS = ['PP', 'HDPE', 'LDPE', 'LLDPE', 'PVC', 'PET', 'PS', 'EPS', 'ABS', 'سایر']

function one(v: string | string[] | undefined): string | undefined {
  if (Array.isArray(v)) return v[0]
  return v
}

export default async function MarketPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>
}) {
  const sp = await searchParams
  const q = one(sp.q)?.trim() || ''
  const family = one(sp.family)?.trim() || ''
  const category = one(sp.category)?.trim() || ''
  const applicationType = one(sp.applicationType)?.trim() || ''
  const producer = one(sp.producer)?.trim() || ''
  const province = one(sp.province)?.trim() || ''
  // بازار دوطرفه: تب «عرضه» (آگهی فروشنده‌ها) و تب «تقاضا» (درخواست خرید خریدارها)
  const view = one(sp.view)?.trim() === 'demand' ? 'demand' : 'supply'

  // ── Check auth/KYC level ──
  const user = await getCurrentUserOrNull()
  let kycLevel = 0
  if (user) {
    const comp = await prisma.company.findUnique({
      where: { userId: user.id },
      select: { kyc: { select: { level: true } } },
    })
    kycLevel = comp?.kyc?.level ?? 0
  }

  // ── Build where (تب عرضه) ──
  const where: Record<string, unknown> = { validityStatus: 'active' }

  if (q) {
    ;(where as any).OR = [
      { grade: { code: { contains: q, mode: 'insensitive' } } },
      { grade: { producer: { contains: q, mode: 'insensitive' } } },
      { grade: { category: { contains: q, mode: 'insensitive' } } },
    ]
  }
  if (family) where.grade = { ...((where.grade as any) || {}), polymerFamily: family }
  if (category) where.grade = { ...((where.grade as any) || {}), category }
  if (applicationType) where.grade = { ...((where.grade as any) || {}), applicationType }
  if (producer) where.grade = { ...((where.grade as any) || {}), producer }
  if (province) where.province = province

  // ── Query ──
  // NOTE: do NOT include `user` here — the full listing is passed to the
  // <ListingDetailModal> client component and would serialize User.passwordHash
  // (and phone/email) into the public page payload. The modal never uses it.
  const listings = await prisma.materialListing.findMany({
    where: where as any,
    include: { grade: true },
    orderBy: { createdAt: 'desc' },
  })

  // ── Filter options ──
  const [allCategories, allApplicationTypes, allProducers, allProvinces] = await Promise.all([
    prisma.grade.findMany({
      where: { isActive: true },
      distinct: ['category'],
      select: { category: true },
      orderBy: { category: 'asc' },
    }),
    prisma.grade.findMany({
      where: { isActive: true, applicationType: { not: null } },
      distinct: ['applicationType'],
      select: { applicationType: true },
      orderBy: { applicationType: 'asc' },
    }),
    prisma.grade.findMany({
      where: { isActive: true },
      distinct: ['producer'],
      select: { producer: true },
      orderBy: { producer: 'asc' },
    }),
    prisma.materialListing.findMany({
      where: { validityStatus: 'active' },
      distinct: ['province'],
      select: { province: true },
      orderBy: { province: 'asc' },
    }),
  ])

  const categories = allCategories.map((r) => r.category)
  const applicationTypes = allApplicationTypes.map((r) => r.applicationType).filter((v): v is string => !!v)
  const producers = allProducers.map((r) => r.producer)
  const provinces = allProvinces.map((r) => r.province)

  // ── تب تقاضا: درخواست‌های خرید باز — حالا با همان فیلترهای تب عرضه ──
  // شمارش همیشه اجرا می‌شه (عددِ روی تب)، لیست کامل فقط وقتی تب تقاضا فعاله.
  // «باز» یعنی status=open و منقضی‌نشده — انقضا تنبل حساب می‌شه، مثل
  // /purchase-requests. درخواست با ساخته‌شدن آگهی بسته نمی‌شه، پس چند
  // فروشنده می‌تونن روی یک درخواست رقابت کنن.
  // فیلترها عین تب عرضه‌اند: q روی کد/تولیدکننده/دسته‌ی گرید، بقیه فیلترها روی
  // grade و province روی خودِ درخواست. چون شرط انقضا خودش OR داره، همه‌ی
  // شرط‌ها داخل AND جمع می‌شن تا OR روی هم نوشته نشه — otherwise the expiry
  // OR would be silently overwritten by the search OR.
  // نکته‌ی امنیتی: include: { user } ممنوعه — این صفحه عمومیه و User شامل
  // passwordHash/phone/email می‌شه؛ همون قاعده‌ی کوئری آگهی‌ها.
  const demandAnd: Record<string, unknown>[] = [
    { OR: [{ expiresAt: null }, { expiresAt: { gte: new Date() } }] },
  ]
  if (q) {
    demandAnd.push({
      OR: [
        { grade: { code: { contains: q, mode: 'insensitive' } } },
        { grade: { producer: { contains: q, mode: 'insensitive' } } },
        { grade: { category: { contains: q, mode: 'insensitive' } } },
      ],
    })
  }
  if (family) demandAnd.push({ grade: { polymerFamily: family } })
  if (category) demandAnd.push({ grade: { category } })
  if (applicationType) demandAnd.push({ grade: { applicationType } })
  if (producer) demandAnd.push({ grade: { producer } })
  const openRequestWhere: Record<string, unknown> = { status: 'open', AND: demandAnd }
  if (province) openRequestWhere.province = province
  const demandCount = await prisma.purchaseRequest.count({ where: openRequestWhere as any })
  const demandRequests =
    view === 'demand'
      ? await prisma.purchaseRequest.findMany({
          where: openRequestWhere as any,
          orderBy: { createdAt: 'desc' },
          include: {
            grade: { select: { code: true, producer: true, category: true, applicationType: true } },
            _count: { select: { listings: true } },
          },
        })
      : []

  // ── وضعیت فیلترها ──
  const filterValues = { q, family, category, applicationType, producer, province }
  type FilterKey = keyof typeof filterValues
  const hasFilters = Object.values(filterValues).some(Boolean)
  // فقط فیلترهای داخل شیت (سلکت‌ها) روی نشانِ دکمه‌ی «فیلترها» شمرده می‌شن؛
  // سرچ و چیپ خانواده بیرون شیت‌اند و خودشون دیده می‌شن.
  const sheetFilterCount = [category, applicationType, producer, province].filter(Boolean).length

  // لینک /market با فیلترهای فعلی + override — تب فعال همیشه حفظ می‌شه.
  function marketHref(overrides: Partial<Record<FilterKey, string>> = {}): string {
    const params = new URLSearchParams()
    if (view === 'demand') params.set('view', 'demand')
    const merged = { ...filterValues, ...overrides }
    for (const k of Object.keys(merged) as FilterKey[]) {
      if (merged[k]) params.set(k, merged[k] as string)
    }
    const qs = params.toString()
    return qs ? `/market?${qs}` : '/market'
  }
  const clearHref = view === 'demand' ? '/market?view=demand' : '/market'

  const activeFilters: { key: FilterKey; label: string }[] = []
  if (q) activeFilters.push({ key: 'q', label: `جستجو: «${q}»` })
  if (family) activeFilters.push({ key: 'family', label: family })
  if (category) activeFilters.push({ key: 'category', label: `دسته: ${category}` })
  if (applicationType) activeFilters.push({ key: 'applicationType', label: `کاربرد: ${applicationType}` })
  if (producer) activeFilters.push({ key: 'producer', label: `تولیدکننده: ${producer}` })
  if (province) activeFilters.push({ key: 'province', label: `استان: ${province}` })

  const resultCount = view === 'supply' ? listings.length : demandCount

  // ── شمارش بدون فیلتر — فقط وقتی فیلتر نتیجه رو صفر کرده، تا empty state
  // بتونه بگه «بدون فیلتر n مورد هست» (به‌جای اینکه بازار خالی به نظر بیاد).
  let unfilteredCount = 0
  if (hasFilters && resultCount === 0) {
    unfilteredCount =
      view === 'supply'
        ? await prisma.materialListing.count({ where: { validityStatus: 'active' } })
        : await prisma.purchaseRequest.count({
            where: { status: 'open', OR: [{ expiresAt: null }, { expiresAt: { gte: new Date() } }] } as any,
          })
  }

  // ── فرم فیلتر مشترک هر دو تب ──
  // GET form submits *replace* the action URL's query string, so the hidden
  // `view` input is what actually keeps the demand tab active after submit —
  // the `?view=demand` in the action alone would be dropped. Same for `family`:
  // the chips are links, so without the hidden input submitting the form would
  // silently drop the selected family.
  const filterForm = (
    <MarketFilterForm action={view === 'demand' ? '/market?view=demand' : '/market'}>
      {view === 'demand' && <input type="hidden" name="view" value="demand" />}
      {family && <input type="hidden" name="family" value={family} />}

      <div className="mk-search-row">
        <div className="mk-search">
          <Search size={16} strokeWidth={2} className="mk-search-icon" aria-hidden />
          <input
            name="q"
            type="search"
            defaultValue={q}
            placeholder="جستجو: کد گرید، تولیدکننده، دسته…"
            aria-label="جستجو"
            className="mk-input"
          />
        </div>
        <MarketFilterToggle activeCount={sheetFilterCount} />
      </div>

      {/* Quick chips — toggle: کلیک روی چیپ فعال، خانواده رو برمی‌داره؛ بقیه‌ی فیلترها و تب حفظ می‌شن */}
      <div className="mk-chips" role="list" aria-label="خانواده‌ی پلیمر">
        {POLYMER_FAMILY_OPTIONS.map((f) => (
          <a
            key={f}
            role="listitem"
            href={marketHref({ family: family === f ? '' : f })}
            className={`mk-chip${family === f ? ' is-active' : ''}`}
            aria-current={family === f ? 'true' : undefined}
          >
            {f}
          </a>
        ))}
      </div>

      <div className="mk-panel" id="mk-panel" role="group" aria-label="فیلترها">
        <div className="mk-sheet-head">
          <div className="mk-sheet-handle" />
          <div className="mk-sheet-title">
            <span>فیلترها</span>
            <MarketFilterClose />
          </div>
        </div>

        <label className="mk-field">
          <span className="mk-label">دسته</span>
          <select name="category" defaultValue={category} className="mk-select">
            <option value="">همه‌ی دسته‌ها</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </label>
        <label className="mk-field">
          <span className="mk-label">کاربرد</span>
          <select name="applicationType" defaultValue={applicationType} className="mk-select">
            <option value="">همه‌ی کاربردها</option>
            {applicationTypes.map((a) => (
              <option key={a} value={a}>
                {a}
              </option>
            ))}
          </select>
        </label>
        <label className="mk-field">
          <span className="mk-label">تولیدکننده</span>
          <select name="producer" defaultValue={producer} className="mk-select">
            <option value="">همه‌ی تولیدکنندگان</option>
            {producers.map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>
        </label>
        <label className="mk-field">
          <span className="mk-label">{view === 'demand' ? 'استان تحویل' : 'استان محل بار'}</span>
          <select name="province" defaultValue={province} className="mk-select">
            <option value="">همه‌ی استان‌ها</option>
            {provinces.map((pr) => (
              <option key={pr} value={pr}>
                {pr}
              </option>
            ))}
          </select>
        </label>

        <div className="mk-sheet-foot">
          <button type="submit" className="btn btn-sm btn-cyan mk-apply mk-press mk-btn">
            اعمال فیلتر
          </button>
          {hasFilters && (
            <a href={clearHref} className="btn btn-sm btn-outline mk-clear-mobile mk-press mk-btn">
              پاک کردن همه
            </a>
          )}
        </div>
      </div>
    </MarketFilterForm>
  )

  // ── نوار فیلترهای فعال — هر چیپ با × فقط همون فیلتر رو برمی‌داره ──
  const activeFilterBar = hasFilters ? (
    <div className="mk-active" aria-label="فیلترهای فعال">
      <span className="mk-active-count">
        {resultCount.toLocaleString('fa-IR')} {view === 'supply' ? 'آگهی' : 'درخواست'}
      </span>
      {activeFilters.map((f) => (
        <a key={f.key} href={marketHref({ [f.key]: '' })} className="mk-active-chip" title="حذف این فیلتر">
          <span>{f.label}</span>
          <X size={13} strokeWidth={2.4} aria-hidden />
        </a>
      ))}
      <a href={clearHref} className="mk-active-clear">
        حذف همه
      </a>
    </div>
  ) : null

  // ── empty state — به‌جای کادر خالی، راه بعدی رو نشون می‌ده ──
  const noun = view === 'supply' ? 'آگهی' : 'درخواست خرید'
  const emptyState = (
    <div className="mk-empty">
      <div className="mk-empty-icon">
        <SearchX size={26} strokeWidth={1.8} aria-hidden />
      </div>
      {hasFilters ? (
        <>
          <div className="mk-empty-title">با این فیلترها نتیجه‌ای پیدا نشد</div>
          <div className="mk-empty-text">
            {unfilteredCount > 0
              ? `بدون فیلتر، ${unfilteredCount.toLocaleString('fa-IR')} ${noun} ${view === 'supply' ? 'فعال' : 'باز'} در بازار هست. یکی از فیلترهای بالا رو بردار یا همه رو پاک کن.`
              : `در حال حاضر هیچ ${noun} ${view === 'supply' ? 'فعالی' : 'بازی'} در بازار ثبت نشده.`}
          </div>
        </>
      ) : (
        <>
          <div className="mk-empty-title">
            {view === 'supply' ? 'فعلاً آگهی فعالی در بازار نیست' : 'فعلاً درخواست خرید بازی ثبت نشده'}
          </div>
          <div className="mk-empty-text">
            {view === 'supply'
              ? 'نیازت رو به‌صورت درخواست خرید ثبت کن تا فروشنده‌ها بهت پیشنهاد بدن، یا برای گرید موردنظرت هشدار قیمت بساز.'
              : 'اگه بار داری، آگهی فروشت رو ثبت کن تا خریدارها ببیننش — یا خودت نیازت رو اعلام کن.'}
          </div>
        </>
      )}
      <div className="mk-empty-actions">
        {hasFilters && unfilteredCount > 0 && (
          <a href={clearHref} className="btn btn-sm btn-cyan mk-press mk-btn">
            حذف همه‌ی فیلترها
          </a>
        )}
        {view === 'supply' ? (
          <>
            <a href="/purchase-requests?new=1" className={`btn btn-sm mk-press mk-btn ${hasFilters && unfilteredCount > 0 ? 'btn-outline' : 'btn-cyan'}`}>
              ثبت درخواست خرید
            </a>
            <a href="/price-alerts" className="btn btn-sm btn-outline mk-press mk-btn">
              ساخت هشدار قیمت
            </a>
          </>
        ) : (
          <>
            <a href="/new-listing" className={`btn btn-sm mk-press mk-btn ${hasFilters && unfilteredCount > 0 ? 'btn-outline' : 'btn-cyan'}`}>
              ثبت آگهی فروش
            </a>
            <a href="/purchase-requests?new=1" className="btn btn-sm btn-outline mk-press mk-btn">
              ثبت درخواست خرید
            </a>
          </>
        )}
      </div>
    </div>
  )

  return (
    <>
      <CurrencyTicker />
      <PublicHeader homeHref={getSurfaceHome()} activePage="/market" isLoggedIn={!!user} />

      <style>{MARKET_FILTER_CSS}</style>
      <section>
        <div className="wrap">
          <div className="eyebrow">خرید و فروش مواد اولیه</div>
          <div className="sec-title">بازار صنعتی پلیمر</div>
          <div className="sec-sub" style={{ marginBottom: spacing.lg }}>
            {view === 'supply' ? (
              <>
                آگهی‌های فروش مواد اولیه پلیمری از تولیدکنندگان و فروشندگان سراسر کشور —{' '}
                <b style={{ color: colors.orange }}>{listings.length.toLocaleString('fa-IR')} آگهی فعال</b>
              </>
            ) : (
              <>
                نیازِ خریدها که خریدارها اعلام کرده‌ن — اگه بار داری، می‌تونی روی همون‌جا آگهی بذاری —{' '}
                <b style={{ color: colors.orange }}>{demandCount.toLocaleString('fa-IR')} درخواست باز</b>
              </>
            )}
          </div>

          {/* ── تب‌های بازار دوطرفه ── */}
          <div style={tabRowStyle}>
            <a href="/market" style={view === 'supply' ? tabActiveStyle : tabStyle}>
              عرضه‌ی فروشنده‌ها ({listings.length.toLocaleString('fa-IR')})
            </a>
            <a href="/market?view=demand" style={view === 'demand' ? tabActiveStyle : tabStyle}>
              تقاضای خریدارها ({demandCount.toLocaleString('fa-IR')})
            </a>
          </div>

          {/* ── Guest CTA ── */}
          {!user && (
            <div style={guestBanner}>
              برای مشاهده‌ی جزئیات کامل، قیمت و خرید،{' '}
              <a href="/signup" style={{ color: colors.orange, fontWeight: 700, textDecoration: 'underline' }}>
                عضو شوید ←
              </a>
            </div>
          )}

          {view === 'supply' ? (
            <>
              {/* ── Filters (همان فرم مشترک) + نوار فیلترهای فعال ── */}
              {filterForm}
              {activeFilterBar}

              {/* ── جدول فشرده‌ی عرضه: هدر + ردیف‌ها؛ روی موبایل اسکرول افقی ── */}
              {listings.length === 0 ? (
                emptyState
              ) : (
                <div style={tableScrollStyle}>
                  <div style={supplyTableStyle}>
                    <div style={{ ...headRowStyle, gridTemplateColumns: SUPPLY_TABLE_COLUMNS } as React.CSSProperties}>
                      <div style={headCell}>گرید</div>
                      <div style={headCell}>وضعیت</div>
                      <div style={headCell}>قیمت</div>
                      <div style={headCell}>مقدار</div>
                      <div style={headCell}>محل بار</div>
                      <div style={headCell}>مبدأ</div>
                      <div style={headCell}>MFI</div>
                      <div style={headCell}>کاربرد</div>
                      <div style={headCell}>ثبت</div>
                      <div />
                    </div>
                    {listings.map((listing) => (
                      <SupplyTableRow key={listing.id} listing={listing} kycLevel={kycLevel} isGuest={!user} />
                    ))}
                  </div>
                </div>
              )}
            </>
          ) : (
            <>
              {/* ── Filters (همان فرم مشترک) + نوار فیلترهای فعال ── */}
              {filterForm}
              {activeFilterBar}

              {/* ── جدول فشرده‌ی تقاضا: هدر + ردیف‌ها؛ روی موبایل اسکرول افقی ── */}
              {demandRequests.length === 0 ? (
                emptyState
              ) : (
                <div style={tableScrollStyle}>
                  <div style={demandTableStyle}>
                    <div style={{ ...headRowStyle, gridTemplateColumns: DEMAND_TABLE_COLUMNS } as React.CSSProperties}>
                      <div style={headCell}>گرید</div>
                      <div style={headCell}>مقدار موردنیاز</div>
                      <div style={headCell}>سقف قیمت</div>
                      <div style={headCell}>استان</div>
                      <div style={headCell}>انقضا</div>
                      <div style={headCell}>وضعیت</div>
                      <div style={headCell}>ثبت</div>
                      <div />
                    </div>
                    {demandRequests.map((req) => (
                      <DemandTableRow key={req.id} request={req} isLoggedIn={!!user} />
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </section>

      <Footer homeHref={getSurfaceHome()} />
    </>
  )
}

// ── Styles ──
const guestBanner: React.CSSProperties = {
  background: colors.warningBg,
  color: colors.warningText,
  borderRadius: radius.md,
  padding: '10px 16px',
  fontSize: fontSize.base,
  fontWeight: 600,
  marginBottom: 20,
  textAlign: 'center',
}
const tabRowStyle: React.CSSProperties = {
  display: 'flex',
  gap: spacing.sm,
  marginBottom: 20,
  borderBottom: `2px solid ${colors.borderSubtle}`,
}
const tabStyle: React.CSSProperties = {
  padding: '10px 18px',
  fontSize: fontSize.base,
  fontWeight: 600,
  color: colors.textMuted,
  textDecoration: 'none',
  borderBottom: '2px solid transparent',
  marginBottom: -2,
  cursor: 'pointer',
}
const tabActiveStyle: React.CSSProperties = {
  ...tabStyle,
  color: colors.navy,
  fontWeight: 800,
  borderBottom: `2px solid ${colors.navy}`,
}
// جدول عرضه: ستون‌هایی با ترکیبی از serif/Sans و حفاظت از wrap کردن
const tableScrollStyle: React.CSSProperties = {
  overflowX: 'auto',
  WebkitOverflowScrolling: 'touch',
  marginBottom: spacing.lg,
}
const supplyTableStyle: React.CSSProperties = {
  minWidth: 760,
}
const demandTableStyle: React.CSSProperties = {
  minWidth: 680,
}
const headRowStyle: React.CSSProperties = {
  display: 'grid',
  gap: 10,
  alignItems: 'center',
  background: colors.navy,
  borderRadius: radius.md,
  padding: '11px 16px',
  marginBottom: 10,
}
const headCell: React.CSSProperties = {
  fontSize: fontSize.xs,
  fontWeight: 700,
  color: '#fff',
  letterSpacing: '0.02em',
  whiteSpace: 'nowrap',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
}

// ── فرم فیلتر، نوار فیلترهای فعال و empty state ──
// CSS محلی صفحه (نه globals.css) چون media query با استایل inline ممکن نیست و
// نمی‌خواهیم با بسته‌های دیگری که globals.css را جایگزین می‌کنند تداخل کند.
// breakpoint = breakpoints.mobile - 1 (همان 899px ناوبری موبایل).
const MARKET_FILTER_CSS = `
.mk-filter{display:flex;flex-direction:column;gap:12px;margin-bottom:14px;padding:14px;background:${colors.bgCard};border:1px solid ${colors.borderSubtle};border-radius:${radius.lg}px;box-shadow:0 1px 4px rgba(27,30,36,0.05)}
.mk-search-row{display:flex;gap:8px;align-items:stretch}
.mk-search{position:relative;flex:1;min-width:0}
.mk-search-icon{position:absolute;right:12px;top:50%;transform:translateY(-50%);color:${colors.textMuted};pointer-events:none}
.mk-input,.mk-select{width:100%;box-sizing:border-box;border:1px solid ${colors.borderStrong};border-radius:${radius.md}px;background:${colors.bgCard};color:${colors.textPrimary};font-family:inherit;font-size:${fontSize.base}px;transition:border-color .15s,box-shadow .15s}
.mk-input{padding:11px 38px 11px 12px}
.mk-select{padding:10px 12px;cursor:pointer}
.mk-input:focus,.mk-select:focus{outline:none;border-color:${colors.navy};box-shadow:0 0 0 3px ${colors.bgActiveTint}}
.mk-filter-toggle{display:none;align-items:center;gap:6px;flex-shrink:0;padding:0 14px;border:1px solid ${colors.borderStrong};border-radius:${radius.md}px;background:${colors.bgCard};color:${colors.textPrimary};font-family:inherit;font-size:${fontSize.sm}px;font-weight:700;cursor:pointer}
.mk-badge{display:inline-flex;align-items:center;justify-content:center;min-width:18px;height:18px;padding:0 5px;border-radius:999px;background:${colors.orange};color:#fff;font-size:11px;font-weight:800}
.mk-chips{display:flex;flex-wrap:wrap;gap:6px}
.mk-chip{display:inline-flex;align-items:center;padding:5px 13px;border-radius:999px;border:1px solid ${colors.borderSubtle};background:${colors.neutralBg};color:${colors.neutralText};font-size:${fontSize.sm}px;font-weight:500;text-decoration:none;white-space:nowrap;transition:background .15s,border-color .15s,color .15s}
.mk-chip:hover{border-color:${colors.borderStrong};background:${colors.bgCard}}
.mk-chip.is-active{background:${colors.orangeBg};border-color:${colors.orange};color:${colors.orangeText};font-weight:700}
.mk-panel{display:grid;grid-template-columns:repeat(4,minmax(0,1fr)) auto;gap:10px;align-items:end}
.mk-field{display:flex;flex-direction:column;gap:4px;min-width:0}
.mk-label{display:none;font-size:${fontSize.xs}px;font-weight:700;color:${colors.textSecondary}}
.mk-sheet-head,.mk-clear-mobile,.mk-scrim{display:none}
.mk-sheet-foot{display:contents}
.mk-apply{height:41px;padding:0 22px;white-space:nowrap}
.mk-active{display:flex;flex-wrap:wrap;align-items:center;gap:6px;margin-bottom:16px}
.mk-active-count{font-size:${fontSize.sm}px;font-weight:800;color:${colors.textPrimary};margin-left:6px}
.mk-active-chip{display:inline-flex;align-items:center;gap:6px;padding:5px 8px 5px 11px;border-radius:999px;background:${colors.infoBg};color:${colors.navy};font-size:${fontSize.sm}px;font-weight:600;text-decoration:none;max-width:100%}
.mk-active-chip span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.mk-active-chip:hover{background:#d3dcfb}
.mk-active-clear{font-size:${fontSize.sm}px;font-weight:700;color:${colors.orange};text-decoration:none;padding:5px 6px}
.mk-active-clear:hover{text-decoration:underline}
/* ── بازخورد فقط هنگام کلیک (نه هاور ماوس): دکمه‌های عملیات ردیف، «i» و دکمه‌های صفحه ──
   استایل پایه inline است، پس حالت فشرده !important لازم دارد. هاورِ سراسریِ .btn-outline
   هم داخل بازار خنثی می‌شود تا فقط کلیک بازخورد بدهد. */
.mk-press{transition:transform .08s ease,background-color .08s ease,box-shadow .08s ease,border-color .08s ease;-webkit-tap-highlight-color:transparent;user-select:none;cursor:pointer}
.mk-press:focus{outline:none}
.mk-press:focus-visible{outline:2px solid ${colors.navy};outline-offset:2px}
.mk-action:active{background:${colors.orange} !important;transform:scale(.95);box-shadow:inset 0 2px 5px rgba(0,0,0,.22)}
.mk-info:active{background:${colors.infoBg} !important;border-color:${colors.navy} !important;transform:scale(.9)}
.mk-btn.btn-outline:hover{border-color:${colors.navy};color:var(--ink)}
.mk-btn.btn-cyan:active{background:${colors.orange};transform:scale(.97);box-shadow:inset 0 2px 5px rgba(0,0,0,.28)}
.mk-btn.btn-outline:active{background:${colors.bgActiveTint};transform:scale(.97)}
.mk-empty{display:flex;flex-direction:column;align-items:center;text-align:center;gap:8px;padding:40px 20px;border:1px dashed ${colors.borderStrong};border-radius:${radius.lg}px;background:${colors.bgCard};margin-bottom:${spacing.lg}px}
.mk-empty-icon{display:flex;align-items:center;justify-content:center;width:56px;height:56px;border-radius:50%;background:${colors.neutralBg};color:${colors.textSecondary};margin-bottom:4px}
.mk-empty-title{font-size:${fontSize.lg}px;font-weight:800;color:${colors.textPrimary}}
.mk-empty-text{font-size:${fontSize.md}px;line-height:1.9;color:${colors.textSecondary};max-width:460px}
.mk-empty-actions{display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin-top:8px}
@media (max-width:1100px) and (min-width:900px){
  .mk-panel{grid-template-columns:repeat(2,minmax(0,1fr))}
  .mk-sheet-foot{display:flex;grid-column:1/-1;justify-content:flex-start}
}
@media (max-width:899px){
  .mk-filter{padding:0;background:transparent;border:none;box-shadow:none;gap:10px}
  .mk-filter-toggle{display:inline-flex}
  .mk-chips{flex-wrap:nowrap;overflow-x:auto;scrollbar-width:none;-webkit-overflow-scrolling:touch;padding-bottom:2px}
  .mk-chips::-webkit-scrollbar{display:none}
  .mk-chip{padding:7px 14px}
  .mk-label{display:block}
  .mk-select{padding:12px}
  .mk-panel{display:none;position:fixed;right:0;left:0;bottom:0;z-index:42;grid-template-columns:1fr;gap:14px;align-items:stretch;max-height:85vh;overflow-y:auto;padding:0 16px;background:${colors.bgCard};border-radius:18px 18px 0 0;box-shadow:0 -8px 32px rgba(0,0,0,0.18)}
  .mk-filter.is-open .mk-panel{display:grid}
  .mk-filter.is-open .mk-scrim{display:block;position:fixed;inset:0;z-index:41;background:rgba(10,18,40,0.5);border:none;padding:0;cursor:pointer}
  .mk-sheet-head{display:block;position:sticky;top:0;background:${colors.bgCard};margin:0 -16px;padding:0 16px;border-bottom:1px solid ${colors.borderSubtle};z-index:1}
  .mk-sheet-handle{width:36px;height:4px;border-radius:999px;background:${colors.borderSubtle};margin:10px auto 4px}
  .mk-sheet-title{display:flex;align-items:center;justify-content:space-between;padding:6px 0 10px;font-size:${fontSize.md}px;font-weight:800;color:${colors.textPrimary}}
  .mk-sheet-close{display:inline-flex;align-items:center;justify-content:center;width:34px;height:34px;border:none;border-radius:${radius.md}px;background:${colors.neutralBg};color:${colors.neutralText};cursor:pointer}
  .mk-sheet-foot{display:flex;gap:8px;position:sticky;bottom:0;background:${colors.bgCard};margin:0 -16px;padding:12px 16px calc(12px + env(safe-area-inset-bottom));border-top:1px solid ${colors.borderSubtle}}
  .mk-apply{flex:1;height:46px;font-size:${fontSize.md}px}
  .mk-clear-mobile{display:inline-flex;height:46px;box-sizing:border-box}
  .mk-active{flex-wrap:nowrap;overflow-x:auto;scrollbar-width:none;padding-bottom:2px}
  .mk-active::-webkit-scrollbar{display:none}
  .mk-active-chip,.mk-active-clear,.mk-active-count{flex-shrink:0}
  /* ستون عملیات (i + دکمه) در اسکرول افقی جدول، سمت چپ چسبان می‌ماند تا همیشه در دسترس باشد */
  .mk-actions{position:sticky;left:0;z-index:1;min-width:max-content;background:${colors.bgCard};padding:4px 0 4px 2px;margin:-4px 0;box-shadow:10px 0 10px -10px rgba(23,32,51,.28)}
  .mk-empty{padding:32px 16px}
  .mk-empty-actions .btn{flex:1 1 140px}
}
`
