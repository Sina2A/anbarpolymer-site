import prisma from './prisma'
import { calculateBusinessHoursDeadline } from './businessHours'
import { logStatusEvent } from './statusEvents'

const RESTRICTION_HOURS = 24 // این یکی جدا از قوانین معامله‌ست (محدودیت حساب، نه مهلت معامله)، فعلاً ثابت می‌مونه

// مقادیر پیش‌فرض — دقیقاً همون چیزی که تا امروز توی کد ثابت بود. اگه هیچ‌وقت
// کارشناسی از پنل تنظیمش نکنه، رفتار سایت هیچ فرقی نمی‌کنه.
const DEFAULT_RULES = {
  sellerFeeHours: 24,
  buyerPaymentHours: 72,
  discrepancyReportHours: 4,
  fundReleaseHours: 8,
  driverSilenceDays: 5,
  proformaConfirmHours: 8,
}

export type DealRuleValues = typeof DEFAULT_RULES

/** خواندن مقادیر فعلی قوانین — اگه هنوز هیچ‌کس تنظیمی نساخته، پیش‌فرض‌ها برمی‌گردن. */
export async function getDealRuleSettings(): Promise<DealRuleValues> {
  const row = await prisma.dealRuleSettings.findUnique({ where: { id: 'singleton' } })
  if (!row) return DEFAULT_RULES
  return {
    sellerFeeHours: row.sellerFeeHours,
    buyerPaymentHours: row.buyerPaymentHours,
    discrepancyReportHours: row.discrepancyReportHours,
    fundReleaseHours: row.fundReleaseHours,
    driverSilenceDays: row.driverSilenceDays,
    proformaConfirmHours: row.proformaConfirmHours,
  }
}

export async function updateDealRuleSettings(values: DealRuleValues, updatedById: string) {
  await prisma.dealRuleSettings.upsert({
    where: { id: 'singleton' },
    update: { ...values, updatedById },
    create: { id: 'singleton', ...values, updatedById },
  })
}

/**
 * این تابع رو باید هر جا صفحه‌ی مرتبط لود می‌شه صدا زد (بازار صنعتی، پنل کاربری، پنل ادمین).
 * چون هنوز job scheduler/cron جدا نداریم، به‌جاش هر بار که یکی از این صفحات باز می‌شه،
 * این تابع خودش چک می‌کنه آیا مهلتی گذشته یا نه — یه الگوی ساده و رایج برای MVP،
 * بدون نیاز به زیرساخت جداگانه.
 */
export async function enforceDealDeadlines() {
  const rules = await getDealRuleSettings()
  const sellerExpired = await enforceSellerFeeDeadlines()
  const buyerExpired = await enforceBuyerPaymentDeadlines()
  const discrepancyWindowClosed = await enforceDiscrepancyWindowClose()
  const driverSilenceFlagged = await enforceDriverSilenceEscalation(rules)
  return {
    cancelledCount: sellerExpired + buyerExpired,
    qualityAutoAcceptedCount: discrepancyWindowClosed,
    driverSilenceFlaggedCount: driverSilenceFlagged,
  }
}

/**
 * فروشنده کارمزد رو سر وقت نداده → آگهی به‌جای بازگشت فوری به بازار، می‌ره
 * تو حالت «نیازمند بررسی مجدد» (needs_reverification) — چون ممکنه موجودی
 * فروشنده واقعاً عوض شده باشه. کارشناس باید دستی تایید کنه.
 * توجه: طول خودِ مهلت (feeDeadline) قبلاً توی startSellerFeeDeadline با
 * مقدار وقتِ آن لحظه محاسبه و ذخیره شده — این تابع فقط چک می‌کنه گذشته یا نه.
 */
async function enforceSellerFeeDeadlines() {
  const now = new Date()
  const overdue = await prisma.materialListing.findMany({
    where: {
      feeStatus: 'unpaid',
      feeDeadline: { lt: now },
      validityStatus: 'reserved',
    },
  })

  for (const listing of overdue) {
    await prisma.materialListing.update({
      where: { id: listing.id },
      data: { validityStatus: 'needs_reverification', feeDeadline: null },
    })

    await prisma.user.update({
      where: { id: listing.userId },
      data: {
        restrictedUntil: new Date(now.getTime() + RESTRICTION_HOURS * 60 * 60 * 1000),
        restrictionReason: 'کارمزد فروش را ظرف مهلت مقرر پرداخت نکرد',
      },
    })

    await prisma.deal.updateMany({
      where: { materialListingId: listing.id, status: { in: ['draft', 'confirmed'] } },
      data: { status: 'cancelled' },
    })
  }

  return overdue.length
}

/**
 * خریدار بعد از تایید، پرداخت کامل رو تکمیل نکرده → رزرو کنسل، آگهی آزاد می‌شه.
 */
async function enforceBuyerPaymentDeadlines() {
  const now = new Date()
  const overdue = await prisma.deal.findMany({
    where: {
      status: 'confirmed',
      escrowStatus: 'pending',
      buyerConfirmDeadline: { lt: now },
    },
    include: { materialListing: true },
  })

  for (const deal of overdue) {
    await prisma.deal.update({
      where: { id: deal.id },
      data: { status: 'cancelled' },
    })

    if (deal.materialListingId) {
      await prisma.materialListing.update({
        where: { id: deal.materialListingId },
        data: { validityStatus: 'active' },
      })
    }

    await prisma.user.update({
      where: { id: deal.buyerId },
      data: {
        restrictedUntil: new Date(now.getTime() + RESTRICTION_HOURS * 60 * 60 * 1000),
        restrictionReason: 'رزرو را تایید کرد ولی پرداخت را ظرف مهلت مقرر تکمیل نکرد',
      },
    })
  }

  return overdue.length
}

/**
 * وقتی راننده «تایید تخلیه» رو ثبت می‌کنه، این رو صدا بزن. از همین لحظه دو
 * تایمر مستقل شروع می‌شه — طول هردو از تنظیمات فعلی (قابل‌تغییر توسط
 * کارشناس) خونده می‌شه، نه عدد ثابت.
 */
export async function startPostUnloadingClocks(dealId: string, unloadingConfirmedAt: Date) {
  const rules = await getDealRuleSettings()
  const [discrepancyDeadline, releaseDeadline] = await Promise.all([
    calculateBusinessHoursDeadline(unloadingConfirmedAt, rules.discrepancyReportHours),
    calculateBusinessHoursDeadline(unloadingConfirmedAt, rules.fundReleaseHours),
  ])
  await prisma.deal.update({
    where: { id: dealId },
    data: {
      status: 'delivered',
      discrepancyReportDeadline: discrepancyDeadline,
      fundReleaseDeadline: releaseDeadline,
    },
  })
  return { discrepancyDeadline, releaseDeadline }
}

/**
 * پایان مهلت گزارش مغایرت: اگه خریدار هیچ مغایرتی ثبت نکرده باشه، سیستم
 * خودش auto_no_discrepancy رو ثبت می‌کنه.
 */
async function enforceDiscrepancyWindowClose() {
  const now = new Date()
  const overdue = await prisma.deal.findMany({
    where: {
      discrepancyReportDeadline: { lt: now },
      status: 'delivered',
      qualityAutoAccepted: false,
    },
    include: { confirmations: true },
  })

  let count = 0
  for (const deal of overdue) {
    const alreadyReported = deal.confirmations.some((c) => c.type === 'buyer_confirm')
    if (alreadyReported) {
      await prisma.deal.update({ where: { id: deal.id }, data: { qualityAutoAccepted: true } })
      continue
    }

    await prisma.dealConfirmation.create({
      data: {
        dealId: deal.id,
        type: 'buyer_confirm',
        finalVerdict: 'auto_no_discrepancy',
        checklistJson: '{}',
      },
    })
    await prisma.deal.update({
      where: { id: deal.id },
      data: { qualityAutoAccepted: true },
    })
    count++
  }
  return count
}

/**
 * اگه راننده بعد از «تایید بارگیری» تا آستانه‌ی تنظیم‌شده (پیش‌فرض ۵ روز
 * تقویمی) هیچ رویداد دیگه‌ای ثبت نکنه، این پرچم می‌خوره.
 */
async function enforceDriverSilenceEscalation(rules: DealRuleValues) {
  const now = new Date()
  const cutoff = new Date(now.getTime() - rules.driverSilenceDays * 24 * 60 * 60 * 1000)

  const inTransitDeals = await prisma.deal.findMany({
    where: { status: 'in_transit', driverSilenceFlaggedAt: null },
    include: { confirmations: { orderBy: { confirmedAt: 'desc' } } },
  })

  let count = 0
  for (const deal of inTransitDeals) {
    const lastEvent = deal.confirmations[0]
    if (lastEvent && lastEvent.confirmedAt < cutoff) {
      await prisma.deal.update({
        where: { id: deal.id },
        data: { driverSilenceFlaggedAt: now },
      })
      count++
    }
  }
  return count
}

/** برای چک‌کردن قبل از اجازه دادن به ثبت آگهی/رزرو جدید */
export async function isUserRestricted(userId: string) {
  const user = await prisma.user.findUnique({ where: { id: userId } })
  if (!user?.restrictedUntil) return { restricted: false as const }
  if (user.restrictedUntil < new Date()) return { restricted: false as const }
  return { restricted: true as const, until: user.restrictedUntil, reason: user.restrictionReason }
}

/** موقع تایید ادمین روی یه رزرو، این رو صدا بزن تا مهلت کارمزد فروشنده شروع بشه */
export async function startSellerFeeDeadline(materialListingId: string) {
  const rules = await getDealRuleSettings()
  const deadline = await calculateBusinessHoursDeadline(new Date(), rules.sellerFeeHours)
  await prisma.materialListing.update({
    where: { id: materialListingId },
    data: { validityStatus: 'reserved', feeDeadline: deadline },
  })
  return deadline
}

/** موقع تایید کارمزد فروشنده، این رو صدا بزن تا مهلت پرداخت کامل خریدار شروع بشه */
export async function startBuyerPaymentDeadline(dealId: string) {
  const rules = await getDealRuleSettings()
  const deadline = await calculateBusinessHoursDeadline(new Date(), rules.buyerPaymentHours)
  await prisma.deal.update({
    where: { id: dealId },
    data: { status: 'confirmed', buyerConfirmDeadline: deadline },
  })
  return deadline
}

/** موقع ثبت قیمت نهایی سفارش توسط کارشناس فروش — مهلت تایید پیش‌فاکتور توسط مشتری شروع می‌شه */
export async function startProformaDeadline(orderId: string) {
  const rules = await getDealRuleSettings()
  const deadline = await calculateBusinessHoursDeadline(new Date(), rules.proformaConfirmHours)
  await prisma.order.update({
    where: { id: orderId },
    data: { status: 'priced', proformaDeadline: deadline },
  })
  return deadline
}

/**
 * مهلت تایید پیش‌فاکتور گذشته و مشتری هنوز تایید نکرده → سفارش خودکار باطل
 * می‌شه (status=rejected با توضیح متمایز در StatusEvent) و موجودی قفل‌شده‌ی
 * هر قلم به انبار برمی‌گرده — همون تراکنشی که rejectOrder دستی انجام می‌ده.
 * مثل بقیه‌ی enforceها، به‌جای cron موقع لود صفحه‌های /proformas صدا زده می‌شه.
 */
export async function enforceProformaDeadlines() {
  const now = new Date()
  const overdue = await prisma.order.findMany({
    where: { status: 'priced', proformaDeadline: { lt: now } },
    include: { items: true },
  })

  for (const order of overdue) {
    const itemsWithWarehouse = order.items.filter((item) => item.warehouseId)
    await prisma.$transaction([
      ...itemsWithWarehouse.map((item) =>
        prisma.warehouseStock.update({
          where: { id: item.warehouseId as string },
          data: { quantityTon: { increment: item.quantity } },
        })
      ),
      prisma.order.update({ where: { id: order.id }, data: { status: 'rejected' } }),
    ])

    await logStatusEvent({
      recordType: 'Order',
      recordId: order.id,
      newStageKey: 'rejected',
      note: 'مهلت تایید پیش‌فاکتور گذشت — سفارش خودکار باطل شد و موجودی به انبار برگشت',
    })
  }

  return overdue.length
}
