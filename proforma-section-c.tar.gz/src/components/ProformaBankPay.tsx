'use client'

import { useState } from 'react'
import PaymentMethodModal from '@/components/PaymentMethodModal'

/**
 * کارت «پرداخت بانکی» صفحه‌ی جزئیات پیش‌فاکتور — دکمه‌ی «انتخاب» داره و بعد از
 * کلیک، فرم آپلود رسید + پنل اطلاعات واریز رو همین‌جا به‌صورت inline باز می‌کنه
 * (بدون popup). از همون PaymentMethodModal با variant="inline" استفاده می‌کنه.
 */
export default function ProformaBankPay({
  orderId,
  amountLabel,
  purposeLabel,
  disabled,
  disabledHint,
}: {
  orderId: string
  amountLabel: string
  purposeLabel: string
  /** وقتی سفارش هنوز به مرحله‌ی پرداخت نرسیده */
  disabled?: boolean
  disabledHint?: string
}) {
  const [open, setOpen] = useState(false)

  return (
    <div>
      {disabled ? (
        <button type="button" disabled style={disabledBtn} title={disabledHint}>
          انتخاب
        </button>
      ) : (
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          style={open ? activeBtn : selectBtn}
        >
          {open ? 'بستن ✕' : 'انتخاب'}
        </button>
      )}

      {!disabled && (
        <PaymentMethodModal
          variant="inline"
          open={open}
          onClose={() => setOpen(false)}
          entityType="order"
          entityId={orderId}
          amountLabel={amountLabel}
          purposeLabel={purposeLabel}
        />
      )}
    </div>
  )
}

const selectBtn: React.CSSProperties = {
  padding: '9px 22px',
  background: '#e65716',
  color: '#fff',
  border: 'none',
  borderRadius: 8,
  fontWeight: 700,
  fontSize: 13,
  cursor: 'pointer',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
}
const activeBtn: React.CSSProperties = {
  ...selectBtn,
  background: '#fff',
  color: '#e65716',
  border: '1.5px solid #e65716',
}
const disabledBtn: React.CSSProperties = {
  ...selectBtn,
  background: '#e8e4db',
  color: '#9199a3',
  cursor: 'not-allowed',
}
