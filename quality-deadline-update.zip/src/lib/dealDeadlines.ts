import prisma from './prisma'
import { calculateHolidayAdjustedDeadline } from './holidays'

const RESTRICTION_HOURS = 24
const SELLER_FEE_DEADLINE_HOURS = 24
const BUYER_PAYMENT_DEADLINE_HOURS = 24
const QUALITY_CONFIRM_HOURS = 72 // از لحظه‌ی بارگیری، غیر از جمعه‌ها/تعطیلات رسمی

/**
 * این تابع رو باید هر جا صفحه‌ی مرتبط لود می‌شه صدا زد (بازار صنعتی، پنل کاربری، پنل ادمین).
 * چون هنوز job scheduler/cron جدا نداریم، به‌جاش هر بار که یکی از این صفحات باز می‌شه،
 * این تابع خودش چک می‌کنه آیا مهلتی گذشته یا نه — یه الگوی ساده و رایج برای MVP،
 * بدون نیاز به زیرساخت جداگانه.
 *
 * خروجی یه شیء تفکیک‌شده‌ست (نه فقط یه عدد کلی) چون پیام «قطعی خودکار بار» با
 * پیام «رزرو/پرداخت لغو شد» از نظر کاربر و ادمین کاملاً متفاوته و نباید قاطی بشه.
 */
export async function enforceDealDeadlines() {
  const sellerExpired = await enforceSellerFeeDeadlines()
  const buyerExpired = await enforceBuyerPaymentDeadlines()
  const qualityAutoAccepted = await enforceQualityConfirmDeadlines()
  return {
    cancelledCount: sellerExpired + buyerExpired,
    qualityAutoAcceptedCount: qualityAutoAccepted,
  }
}

/**
 * فروشنده کارمزد رو سر وقت نداده → آگهی دوباره آزاد می‌شه (چراغ سبز)،
 * فروشنده ۲۴ ساعت محدود می‌شه.
 */
async function enforceSellerFeeDeadlines() {
  const now = new Date()
  const overdue = await prisma.materialListing.findMany({
    where: {
      feeStatus: 'unpaid',
      feeDeadline: { lt: now },
      validityStatus: 'reserved',
    },
  })

  for (const listing of overdue) {
    await prisma.materialListing.update({
      where: { id: listing.id },
      data: { validityStatus: 'active', feeDeadline: null },
    })

    await prisma.user.update({
      where: { id: listing.userId },
      data: {
        restrictedUntil: new Date(now.getTime() + RESTRICTION_HOURS * 60 * 60 * 1000),
        restrictionReason: 'کارمزد فروش را ظرف مهلت مقرر پرداخت نکرد',
      },
    })

    // هر Deal مرتبط با این آگهی که هنوز باز بود، لغو می‌شه
    await prisma.deal.updateMany({
      where: { materialListingId: listing.id, status: { in: ['draft', 'confirmed'] } },
      data: { status: 'cancelled' },
    })
  }

  return overdue.length
}

/**
 * خریدار بعد از تایید، پرداخت کامل رو تکمیل نکرده → همون اتفاق برای خریدار می‌افته.
 */
async function enforceBuyerPaymentDeadlines() {
  const now = new Date()
  const overdue = await prisma.deal.findMany({
    where: {
      status: 'confirmed',
      escrowStatus: 'pending',
      buyerConfirmDeadline: { lt: now },
    },
    include: { materialListing: true },
  })

  for (const deal of overdue) {
    await prisma.deal.update({
      where: { id: deal.id },
      data: { status: 'cancelled' },
    })

    if (deal.materialListingId) {
      await prisma.materialListing.update({
        where: { id: deal.materialListingId },
        data: { validityStatus: 'active' },
      })
    }

    await prisma.user.update({
      where: { id: deal.buyerId },
      data: {
        restrictedUntil: new Date(now.getTime() + RESTRICTION_HOURS * 60 * 60 * 1000),
        restrictionReason: 'رزرو را تایید کرد ولی پرداخت را ظرف مهلت مقرر تکمیل نکرد',
      },
    })
  }

  return overdue.length
}

/**
 * وقتی راننده «تایید بارگیری» رو ثبت می‌کنه، این رو صدا بزن. مهلت خریدار برای
 * بررسی/تایید/اعتراض بار از همون لحظه شروع می‌شه (نه از تخلیه) — تصمیم آگاهانه‌ی
 * سینا، برای اینکه کل چرخه‌ی معامله یه سقف زمانی ثابت داشته باشه.
 */
export async function startQualityConfirmDeadline(dealId: string, loadingConfirmedAt: Date) {
  const deadline = await calculateHolidayAdjustedDeadline(loadingConfirmedAt, QUALITY_CONFIRM_HOURS)
  await prisma.deal.update({
    where: { id: dealId },
    data: { qualityConfirmDeadline: deadline },
  })
  return deadline
}

/**
 * اگه خریدار تا مهلت qualityConfirmDeadline هیچ تاییدیه‌ای ثبت نکرده باشه،
 * سیستم خودش یه DealConfirmation از نوع buyer_confirm با finalVerdict مخصوصِ
 * 'auto_accepted_timeout' می‌سازه — عمداً جدا از 'full_accept' (که یعنی خریدار
 * خودش با اراده تایید کرده)، چون این فرق برای هر بررسی حقوقی/اختلاف بعدی مهمه.
 *
 * بعد از این لحظه، دیگه مسیر رسیدگی داخلی به اختلاف (که به شواهد لحظه‌ی تخلیه
 * وصله) عملاً بسته یا بسیار محدود می‌شه — چون راننده رفته، مدارک اون لحظه
 * دیگه قابل جمع‌آوری نیست. این دقیقاً چیزیه که باید قبل از این مهلت به خریدار
 * هشدار داده بشه (نگاه کن به بنر توی صفحه‌ی deal-confirm).
 */
async function enforceQualityConfirmDeadlines() {
  const now = new Date()
  const overdue = await prisma.deal.findMany({
    where: {
      qualityConfirmDeadline: { lt: now },
      status: { in: ['in_transit', 'delivered'] },
    },
    include: { confirmations: true },
  })

  let count = 0
  for (const deal of overdue) {
    const alreadyConfirmed = deal.confirmations.some((c) => c.type === 'buyer_confirm')
    if (alreadyConfirmed) continue // محافظ race condition — شاید همین الان خریدار خودش ثبت کرده

    await prisma.dealConfirmation.create({
      data: {
        dealId: deal.id,
        type: 'buyer_confirm',
        finalVerdict: 'auto_accepted_timeout',
        checklistJson: '{}',
      },
    })
    await prisma.deal.update({
      where: { id: deal.id },
      data: { status: 'settled', qualityAutoAccepted: true },
    })
    count++
  }
  return count
}

/** برای چک‌کردن قبل از اجازه دادن به ثبت آگهی/رزرو جدید */
export async function isUserRestricted(userId: string) {
  const user = await prisma.user.findUnique({ where: { id: userId } })
  if (!user?.restrictedUntil) return { restricted: false as const }
  if (user.restrictedUntil < new Date()) return { restricted: false as const }
  return { restricted: true as const, until: user.restrictedUntil, reason: user.restrictionReason }
}

/** موقع تایید ادمین روی یه رزرو، این رو صدا بزن تا مهلت کارمزد فروشنده شروع بشه */
export async function startSellerFeeDeadline(materialListingId: string) {
  const deadline = new Date(Date.now() + SELLER_FEE_DEADLINE_HOURS * 60 * 60 * 1000)
  await prisma.materialListing.update({
    where: { id: materialListingId },
    data: { validityStatus: 'reserved', feeDeadline: deadline },
  })
  return deadline
}

/** موقع تایید کارمزد فروشنده، این رو صدا بزن تا مهلت پرداخت کامل خریدار شروع بشه */
export async function startBuyerPaymentDeadline(dealId: string) {
  const deadline = new Date(Date.now() + BUYER_PAYMENT_DEADLINE_HOURS * 60 * 60 * 1000)
  await prisma.deal.update({
    where: { id: dealId },
    data: { status: 'confirmed', buyerConfirmDeadline: deadline },
  })
  return deadline
}
