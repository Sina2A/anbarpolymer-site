import prisma from './prisma'

export const ADJUSTABLE_DEADLINE_FIELDS = ['buyerConfirmDeadline', 'qualityConfirmDeadline'] as const
export type AdjustableDeadlineField = (typeof ADJUSTABLE_DEADLINE_FIELDS)[number]

export const DEADLINE_FIELD_LABELS: Record<AdjustableDeadlineField, string> = {
  buyerConfirmDeadline: 'مهلت پرداخت کامل خریدار',
  qualityConfirmDeadline: 'مهلت بررسی/تایید کیفیت بار',
}

/**
 * تمدید یا کوتاه‌کردن دستی یه مهلت روی یه Deal مشخص — برای شرایط خاص
 * (مثلاً فروشنده تماس گرفته بار دیر می‌رسه). هر تغییر با دلیل اجباری و
 * شناسه‌ی کارشناس/مدیر ثبت می‌شه، نه فقط اعمال ساکت — چون این می‌تونه
 * بعداً توی رسیدگی به اختلاف اهمیت داشته باشه.
 *
 * hoursDelta می‌تونه منفی هم باشه (کوتاه‌کردن مهلت)، ولی این حالت باید با
 * احتیاط بیشتری استفاده بشه چون ممکنه حق خریدار/فروشنده رو زودتر از موعد
 * ببنده.
 */
export async function adjustDealDeadline(params: {
  dealId: string
  field: AdjustableDeadlineField
  hoursDelta: number
  reason: string
  adjustedById: string
}) {
  const { dealId, field, hoursDelta, reason, adjustedById } = params

  if (!ADJUSTABLE_DEADLINE_FIELDS.includes(field)) {
    throw new Error('فیلد مهلت نامعتبره.')
  }
  if (!reason || reason.trim().length < 3) {
    throw new Error('برای تغییر دستی مهلت، ذکر دلیل الزامیه.')
  }

  const deal = await prisma.deal.findUnique({ where: { id: dealId } })
  if (!deal) throw new Error('معامله پیدا نشد.')

  const previousValue = deal[field] as Date | null
  const base = previousValue ?? new Date() // اگه مهلتی هنوز فعال نبود، از الان حساب می‌شه
  const newValue = new Date(base.getTime() + hoursDelta * 60 * 60 * 1000)

  await prisma.$transaction([
    prisma.deal.update({ where: { id: dealId }, data: { [field]: newValue } }),
    prisma.deadlineAdjustment.create({
      data: {
        dealId,
        field,
        previousValue,
        newValue,
        hoursDelta,
        reason: reason.trim(),
        adjustedById,
      },
    }),
  ])

  return newValue
}

export async function getDeadlineAdjustments(dealId: string) {
  return prisma.deadlineAdjustment.findMany({
    where: { dealId },
    orderBy: { createdAt: 'asc' },
    include: { adjustedBy: true },
  })
}
