import prisma from './prisma'

/**
 * منطق این فایل: «۷۲ ساعت غیر از تعطیلات رسمی و عمومی» یعنی هر روز تقویمی
 * (نه بازه‌ی ساعتی دقیق) که جمعه یا توی جدول Holiday ثبت شده باشه، ۲۴ ساعت
 * کامل به مهلت اضافه می‌شه — انگار اون روز اصلاً نبوده.
 *
 * این یه ساده‌سازی عمدیه (نه محاسبه‌ی ساعت‌به‌ساعت کاری)، چون قانون کسب‌وکاری
 * که تعریف شده («۷۲ ساعت از بارگیری، غیر از روزهای تعطیل») درباره‌ی روز کامل
 * صحبت می‌کنه نه ساعت اداری. اگه بعداً قرار شد این متن دقیق قراردادی بشه،
 * وکیل باید عبارت رو تایید کنه؛ الگوریتم اینجا هرچی که تصمیم نهایی باشه راحت
 * قابل تنظیمه.
 */

const FRIDAY = 5 // JS: getDay() === 5 یعنی جمعه

function toDateKey(d: Date): string {
  return d.toISOString().slice(0, 10) // YYYY-MM-DD
}

function startOfDay(d: Date): Date {
  const copy = new Date(d)
  copy.setHours(0, 0, 0, 0)
  return copy
}

async function getHolidayDateKeys(): Promise<Set<string>> {
  const holidays = await prisma.holiday.findMany()
  return new Set(holidays.map((h) => toDateKey(h.date)))
}

function isNonWorkingDay(day: Date, holidayKeys: Set<string>): boolean {
  return day.getDay() === FRIDAY || holidayKeys.has(toDateKey(day))
}

/**
 * از `start`، `hours` ساعت جلو می‌ره؛ برای هر روز تقویمی که بین شروع و مهلت
 * جمعه یا تعطیل رسمی باشه، ۲۴ ساعت به مهلت اضافه می‌شه. چون اضافه‌کردن ممکنه
 * روزهای تعطیل جدیدی رو وارد بازه کنه، تا زمانی که دیگه چیزی تغییر نکنه تکرار
 * می‌شه (زنجیره‌ی چند تعطیلی پشت‌سرهم رو هم درست پوشش می‌ده).
 */
export async function calculateHolidayAdjustedDeadline(start: Date, hours: number): Promise<Date> {
  const holidayKeys = await getHolidayDateKeys()
  let deadline = new Date(start.getTime() + hours * 60 * 60 * 1000)

  let changed = true
  while (changed) {
    changed = false
    let cursor = startOfDay(start)
    const lastDay = startOfDay(deadline)

    while (cursor.getTime() <= lastDay.getTime()) {
      if (isNonWorkingDay(cursor, holidayKeys)) {
        deadline = new Date(deadline.getTime() + 24 * 60 * 60 * 1000)
        changed = true
      }
      cursor = new Date(cursor.getTime() + 24 * 60 * 60 * 1000)
    }
  }

  return deadline
}

// ==================== مدیریت تعطیلات (پنل ادمین) ====================

export async function listHolidays() {
  return prisma.holiday.findMany({ orderBy: { date: 'asc' } })
}

export async function addHoliday(dateStr: string, title: string) {
  const date = startOfDay(new Date(dateStr))
  return prisma.holiday.upsert({
    where: { date },
    update: { title: title || null },
    create: { date, title: title || null },
  })
}

export async function removeHoliday(id: string) {
  await prisma.holiday.delete({ where: { id } })
}
