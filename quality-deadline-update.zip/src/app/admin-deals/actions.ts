'use server'

import prisma from '@/lib/prisma'
import { revalidatePath } from 'next/cache'
import { addHoliday, removeHoliday } from '@/lib/holidays'
import { adjustDealDeadline, AdjustableDeadlineField } from '@/lib/deadlineAdjustments'

/**
 * این دو تابع هیچ تراکنش بانکی واقعی انجام نمی‌دن — فقط وضعیتی رو ثبت می‌کنن
 * که تیم حسابداری، بیرون از سایت، بین خودش و بانک انجام داده. طبق تصمیمی که
 * گرفته شد: «سایت قرار نیست به سیستم بانکی وصل بشه، این برای بخش حسابداریه.»
 */
export async function confirmFundsSecured(formData: FormData) {
  const dealId = String(formData.get('dealId'))
  const confirmedById = String(formData.get('confirmedById') || '')

  await prisma.deal.update({
    where: { id: dealId },
    data: {
      escrowStatus: 'secured_manual',
      escrowConfirmedById: confirmedById || null,
      escrowConfirmedAt: new Date(),
      status: 'payment_secured',
    },
  })
  revalidatePath('/admin-deals')
}

export async function confirmFundsReleased(formData: FormData) {
  const dealId = String(formData.get('dealId'))
  const confirmedById = String(formData.get('confirmedById') || '')

  await prisma.deal.update({
    where: { id: dealId },
    data: {
      escrowStatus: 'released_manual',
      escrowConfirmedById: confirmedById || null,
      escrowConfirmedAt: new Date(),
      status: 'settled',
    },
  })
  revalidatePath('/admin-deals')
}

export async function addHolidayAction(formData: FormData) {
  const date = String(formData.get('date') || '')
  const title = String(formData.get('title') || '')
  if (!date) return
  await addHoliday(date, title)
  revalidatePath('/admin-deals')
}

export async function removeHolidayAction(formData: FormData) {
  const id = String(formData.get('id') || '')
  if (!id) return
  await removeHoliday(id)
  revalidatePath('/admin-deals')
}

export async function adjustDeadlineAction(formData: FormData) {
  const dealId = String(formData.get('dealId') || '')
  const field = String(formData.get('field') || '') as AdjustableDeadlineField
  const hours = Number(formData.get('hours'))
  const reason = String(formData.get('reason') || '')
  const adjustedById = String(formData.get('adjustedById') || '')

  if (!dealId || !field || !Number.isFinite(hours) || !adjustedById) return

  await adjustDealDeadline({ dealId, field, hoursDelta: hours, reason, adjustedById })
  revalidatePath('/admin-deals')
}
