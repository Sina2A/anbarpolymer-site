import prisma from '@/lib/prisma'
import { getAllSectionAccess } from '@/lib/permissions'
import { getCurrentUser } from '@/lib/currentUser'
import { enforceDealDeadlines } from '@/lib/dealDeadlines'
import { listHolidays } from '@/lib/holidays'
import { DEADLINE_FIELD_LABELS } from '@/lib/deadlineAdjustments'
import AdminNav from '@/components/AdminNav'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'
import { confirmFundsSecured, confirmFundsReleased, addHolidayAction, removeHolidayAction, adjustDeadlineAction } from './actions'

export const dynamic = 'force-dynamic'

const STATUS_LABELS: Record<string, string> = {
  draft: 'پیش‌نویس', confirmed: 'تایید شد', payment_secured: 'وجه تضمین شد',
  loading: 'در حال بارگیری', in_transit: 'در مسیر ارسال', delivered: 'تحویل شد', settled: 'تسویه شد',
}
const CONFIRMATION_TYPE_LABELS: Record<string, string> = {
  loading: 'تایید بارگیری', unloading: 'تایید تخلیه', driver_confirm: 'تاییدیه راننده', buyer_confirm: 'تاییدیه خریدار',
}
const VERDICT_LABELS: Record<string, { label: string; color: string }> = {
  full_accept: { label: '✅ تایید کامل توسط خریدار', color: '#146c3a' },
  accept_with_discrepancy: { label: '⚠️ تایید با مغایرت توسط خریدار', color: '#92400e' },
  reject: { label: '❌ عدم تایید توسط خریدار', color: '#9b1c1c' },
  auto_accepted_timeout: { label: '🔴 تایید خودکار — خریدار ظرف مهلت اقدام نکرد', color: '#9b1c1c' },
}
const CHECKLIST_LABELS: Record<string, string> = {
  packagingIntact: 'بسته‌بندی سالم', quantityMatches: 'تعداد مطابق سفارش', palletsIntact: 'پالت‌ها سالم',
  productMatchesOrder: 'محصول مطابق سفارش', discrepancyObserved: 'مغایرت مشاهده شد',
  noTransitDamage: 'بدون آسیب حمل', productReceived: 'محصول دریافت شد', discrepancyExists: 'مغایرت وجود دارد',
}

export default async function AdminDealsPage() {
  const currentUser = await getCurrentUser()

  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)

  // چون هنوز cron جدا نداریم، هر بار این صفحه لود می‌شه، اول چک می‌کنه
  // آیا مهلت کارمزد فروشنده، پرداخت خریدار، یا بررسی کیفیت برای کسی گذشته —
  // اگه آره، خودکار لغو/تسویه + جریمه‌ی موقت (در مورد اولی) اعمال می‌شه.
  const { cancelledCount, qualityAutoAcceptedCount } = await enforceDealDeadlines()

  const deals = await prisma.deal.findMany({
    include: { buyer: true, confirmations: { orderBy: { confirmedAt: 'asc' } } },
    orderBy: { createdAt: 'desc' },
  })

  const holidays = isAdmin ? await listHolidays() : []

  const allAdjustments = await prisma.deadlineAdjustment.findMany({
    where: { dealId: { in: deals.map((d) => d.id) } },
    orderBy: { createdAt: 'asc' },
    include: { adjustedBy: true },
  })
  const adjustmentsByDeal = new Map<string, typeof allAdjustments>()
  for (const adj of allAdjustments) {
    const list = adjustmentsByDeal.get(adj.dealId) || []
    list.push(adj)
    adjustmentsByDeal.set(adj.dealId, list)
  }

  return (
    <div style={{ display: 'flex', gap: 24, padding: '32px 24px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', maxWidth: 1100, margin: '0 auto' }}>
      <AdminNav currentUserName={currentUser.companyName} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="deals" />

      <div style={{ flex: 1, minWidth: 0 }}>
        <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 8 }}>معاملات تجاری</h1>
        <p style={{ color: '#6f7680', fontSize: 13.5, marginBottom: 24, lineHeight: 1.9 }}>
          این جدا از سفارش‌های مستقیم فروشگاهه — اینجا یه کارخانه‌ی دیگه می‌فروشه، انبار پلیمر فقط واسط وضعیته. هیچ تراکنش بانکی از این صفحه انجام نمی‌شه؛ فقط ثبت وضعیتیه که حسابداری بیرون از سایت انجام داده.
        </p>

        {cancelledCount > 0 && (
          <div style={{ background: '#fef3c7', color: '#92400e', borderRadius: 8, padding: '10px 16px', fontSize: 12.5, fontWeight: 600, marginBottom: 12 }}>
            ⏱ {cancelledCount} مورد به‌خاطر گذشتن مهلت (کارمزد یا پرداخت)، همین الان خودکار لغو و آگهیش دوباره آزاد شد.
          </div>
        )}

        {qualityAutoAcceptedCount > 0 && (
          <div style={{ background: '#fde8e8', color: '#9b1c1c', borderRadius: 8, padding: '10px 16px', fontSize: 12.5, fontWeight: 600, marginBottom: 20 }}>
            🔴 {qualityAutoAcceptedCount} مورد به‌خاطر عدم اقدام خریدار ظرف مهلت، همین الان به‌صورت خودکار تایید و تسویه شد — نیاز به آزادسازی وجه دستی (پایین کارت هر معامله).
          </div>
        )}

        {isAdmin && (
          <details style={{ border: '1px solid #d8dde3', borderRadius: 10, padding: '10px 16px', marginBottom: 24, background: '#fafbfc' }}>
            <summary style={{ cursor: 'pointer', fontSize: 12.5, fontWeight: 700 }}>📅 مدیریت تعطیلات رسمی (برای محاسبه‌ی مهلت ۷۲ساعته‌ی خریدار)</summary>
            <p style={{ fontSize: 11.5, color: '#6f7680', margin: '10px 0' }}>جمعه‌ها خودکار حساب می‌شن، لازم نیست اضافه بشن. فقط تعطیلات رسمی/عمومی دیگه رو اینجا اضافه کن.</p>

            <form action={addHolidayAction} style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 14 }}>
              <input type="date" name="date" required style={holidayInputStyle} />
              <input type="text" name="title" placeholder="عنوان (اختیاری، مثلاً عید فطر)" style={{ ...holidayInputStyle, flex: 1, minWidth: 160 }} />
              <button type="submit" style={btnStyle('#1e357b')}>افزودن</button>
            </form>

            {holidays.length === 0 ? (
              <div style={{ fontSize: 11.5, color: '#9199a3' }}>هنوز هیچ تعطیلی ثبت نشده.</div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {holidays.map((h) => (
                  <div key={h.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: 12, borderBottom: '1px dashed #e5e7eb', paddingBottom: 6 }}>
                    <span>{new Date(h.date).toLocaleDateString('fa-IR')} {h.title && `— ${h.title}`}</span>
                    <form action={removeHolidayAction}>
                      <input type="hidden" name="id" value={h.id} />
                      <button type="submit" style={{ background: 'none', border: 'none', color: '#9b1c1c', fontSize: 11.5, cursor: 'pointer' }}>حذف</button>
                    </form>
                  </div>
                ))}
              </div>
            )}
          </details>
        )}

        {deals.length === 0 && (
          <div style={{ padding: 32, textAlign: 'center', color: '#9199a3', border: '1px dashed #d8dde3', borderRadius: 12 }}>هنوز هیچ معامله‌ای ثبت نشده.</div>
        )}

        {deals.map((deal) => (
          <div key={deal.id} style={cardStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, flexWrap: 'wrap', gap: 8 }}>
              <div>
                <b style={{ fontSize: 14 }}>#{deal.id.slice(0, 8)}</b>{' '}
                <span style={{ fontSize: 12.5, color: '#6f7680' }}>— {deal.buyer.companyName} — {deal.quantity}</span>
              </div>
              <span style={statusTag}>{STATUS_LABELS[deal.status] || deal.status}</span>
            </div>

            <div style={{ fontSize: 12.5, color: '#4f5560', marginBottom: 14 }}>
              قیمت توافقی: {deal.agreedPrice || '—'} &nbsp;|&nbsp; وضعیت وجه: <b style={escrowColor(deal.escrowStatus)}>{escrowLabel(deal.escrowStatus)}</b>
            </div>

            {/* ---------- تایم‌لاین رویدادها ---------- */}
            {deal.confirmations.length > 0 && (
              <div style={{ marginBottom: 14 }}>
                {deal.confirmations.map((c) => {
                  let checklist: Record<string, boolean> = {}
                  try { checklist = JSON.parse(c.checklistJson) } catch {}
                  return (
                    <div key={c.id} style={timelineRow}>
                      <div style={{ fontWeight: 700, fontSize: 12.5, marginBottom: 4 }}>{CONFIRMATION_TYPE_LABELS[c.type] || c.type}</div>
                      {c.finalVerdict && VERDICT_LABELS[c.finalVerdict] && (
                        <div style={{ ...metaLine, color: VERDICT_LABELS[c.finalVerdict].color, fontWeight: 700 }}>
                          {VERDICT_LABELS[c.finalVerdict].label}
                        </div>
                      )}
                      {c.driverName && <div style={metaLine}>راننده: {c.driverName} — {c.driverPhone} — پلاک {c.vehiclePlate}</div>}
                      {c.receiverName && <div style={metaLine}>تحویل‌گیرنده: {c.receiverName} ({c.receiverRole})</div>}
                      <div style={metaLine}>
                        {Object.entries(checklist).filter(([, v]) => v).map(([k]) => CHECKLIST_LABELS[k] || k).join(' · ') || 'بدون آیتم تیک‌خورده'}
                      </div>
                      {c.latitude && c.longitude && (
                        <div style={metaLine}>موقعیت ثبت‌شده: {c.latitude.toFixed(5)}, {c.longitude.toFixed(5)} (سیگنال کمکی، نه مدرک قطعی)</div>
                      )}
                      {c.photoUrl && (
                        <a href={c.photoUrl} target="_blank" rel="noreferrer" style={{ fontSize: 11.5, color: '#1e357b' }}>مشاهده‌ی عکس ↗</a>
                      )}
                      <div style={{ fontSize: 10.5, color: '#9199a3', marginTop: 4 }}>{new Date(c.confirmedAt).toLocaleString('fa-IR')}</div>
                    </div>
                  )
                })}
              </div>
            )}

            {/* ---------- مهلت‌های فعال + تنظیم دستی (فقط مدیر) ---------- */}
            {(deal.buyerConfirmDeadline || deal.qualityConfirmDeadline) && (
              <div style={{ marginBottom: 14, background: '#fafbfc', borderRadius: 8, padding: '10px 14px' }}>
                {deal.buyerConfirmDeadline && (
                  <div style={{ fontSize: 12, marginBottom: 4 }}>مهلت پرداخت کامل خریدار: <b>{new Date(deal.buyerConfirmDeadline).toLocaleString('fa-IR')}</b></div>
                )}
                {deal.qualityConfirmDeadline && (
                  <div style={{ fontSize: 12 }}>مهلت بررسی/تایید کیفیت بار: <b>{new Date(deal.qualityConfirmDeadline).toLocaleString('fa-IR')}</b></div>
                )}

                {(adjustmentsByDeal.get(deal.id) || []).length > 0 && (
                  <div style={{ marginTop: 8, borderTop: '1px dashed #e5e7eb', paddingTop: 8 }}>
                    {(adjustmentsByDeal.get(deal.id) || []).map((a) => (
                      <div key={a.id} style={{ fontSize: 11, color: '#6f7680', marginBottom: 3 }}>
                        🔧 {DEADLINE_FIELD_LABELS[a.field as keyof typeof DEADLINE_FIELD_LABELS] || a.field}{' '}
                        {a.hoursDelta > 0 ? `${a.hoursDelta} ساعت تمدید شد` : `${Math.abs(a.hoursDelta)} ساعت کوتاه شد`}{' '}
                        توسط {a.adjustedBy.companyName} — «{a.reason}» — {new Date(a.createdAt).toLocaleString('fa-IR')}
                      </div>
                    ))}
                  </div>
                )}

                {isAdmin && (
                  <form action={adjustDeadlineAction} style={{ display: 'flex', gap: 6, flexWrap: 'wrap', alignItems: 'center', marginTop: 10, borderTop: '1px dashed #e5e7eb', paddingTop: 10 }}>
                    <input type="hidden" name="dealId" value={deal.id} />
                    <input type="hidden" name="adjustedById" value={currentUser.id} />
                    <select name="field" style={holidayInputStyle} required>
                      {deal.buyerConfirmDeadline && <option value="buyerConfirmDeadline">مهلت پرداخت خریدار</option>}
                      {deal.qualityConfirmDeadline && <option value="qualityConfirmDeadline">مهلت تایید کیفیت</option>}
                    </select>
                    <input type="number" name="hours" placeholder="مثلاً 12 یا -6" required style={{ ...holidayInputStyle, width: 90 }} />
                    <input type="text" name="reason" placeholder="دلیل (اجباری)" required style={{ ...holidayInputStyle, flex: 1, minWidth: 140 }} />
                    <ConfirmSubmitButton
                      message="⚠️ این مهلت رو دستی تغییر می‌ده و توی تاریخچه ثبت می‌شه. مطمئنی؟"
                      style={btnStyle('#4f5560')}
                    >
                      اعمال تغییر
                    </ConfirmSubmitButton>
                  </form>
                )}
              </div>
            )}

            {/* ---------- دکمه‌های وضعیت وجه (دستی) ---------- */}
            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', borderTop: '1px dashed #e5e7eb', paddingTop: 12 }}>
              {deal.escrowStatus === 'pending' && (
                <form action={confirmFundsSecured}>
                  <input type="hidden" name="dealId" value={deal.id} />
                  <input type="hidden" name="confirmedById" value={currentUser.id} />
                  <ConfirmSubmitButton
                    message="⚠️ این یعنی حسابداری تایید می‌کنه وجه از خریدار واقعاً دریافت شده (بیرون از سایت). مطمئنی؟"
                    style={btnStyle('#1e357b')}
                  >
                    تایید دریافت وجه از خریدار
                  </ConfirmSubmitButton>
                </form>
              )}
              {deal.escrowStatus === 'secured_manual' && (
                <form action={confirmFundsReleased}>
                  <input type="hidden" name="dealId" value={deal.id} />
                  <input type="hidden" name="confirmedById" value={currentUser.id} />
                  <ConfirmSubmitButton
                    message="⚠️ این یعنی حسابداری تایید می‌کنه وجه واقعاً به فروشنده پرداخت شده (بیرون از سایت). مطمئنی؟"
                    style={btnStyle('#f6621b')}
                  >
                    تایید پرداخت به فروشنده
                  </ConfirmSubmitButton>
                </form>
              )}
              {deal.escrowStatus === 'released_manual' && (
                <span style={{ fontSize: 12, color: '#146c3a', fontWeight: 600 }}>✓ این معامله کامل تسویه شده</span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

function escrowLabel(status: string) {
  return status === 'pending' ? 'در انتظار' : status === 'secured_manual' ? 'نزد ما (تضمین‌شده)' : status === 'released_manual' ? 'به فروشنده پرداخت شد' : status
}
function escrowColor(status: string): React.CSSProperties {
  return { color: status === 'pending' ? '#92400e' : status === 'secured_manual' ? '#1e357b' : '#146c3a' }
}
function btnStyle(bg: string): React.CSSProperties {
  return { background: bg, color: '#fff', border: 'none', borderRadius: 8, padding: '9px 16px', fontSize: 12.5, fontWeight: 700, cursor: 'pointer' }
}

const holidayInputStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 8, padding: '8px 10px', fontSize: 12, fontFamily: 'inherit' }
const cardStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 12, padding: 20, marginBottom: 16, background: '#fff', boxShadow: '0 1px 4px rgba(27,30,36,.05)' }
const statusTag: React.CSSProperties = { fontSize: 11, fontWeight: 700, background: '#eef4fd', color: '#1e357b', borderRadius: 6, padding: '4px 12px' }
const timelineRow: React.CSSProperties = { borderRight: '2px solid #e5e7eb', paddingRight: 12, marginBottom: 10 }
const metaLine: React.CSSProperties = { fontSize: 11.5, color: '#6f7680', marginTop: 2 }
