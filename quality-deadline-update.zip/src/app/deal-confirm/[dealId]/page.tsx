import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { enforceDealDeadlines } from '@/lib/dealDeadlines'
import { submitBuyerConfirmation } from './actions'

export const dynamic = 'force-dynamic'

export default async function DealConfirmPage({ params }: { params: Promise<{ dealId: string }> }) {
  const { dealId } = await params
  const user = await getCurrentUser()

  // اگه مهلت این معامله (یا هر معامله‌ی دیگه‌ای) گذشته باشه، همینجا خودکار
  // قطعی می‌شه — قبل از اینکه بقیه‌ی صفحه رندر بشه، تا وضعیت همیشه به‌روز باشه.
  await enforceDealDeadlines()

  const deal = await prisma.deal.findUnique({
    where: { id: dealId },
    include: { confirmations: { orderBy: { confirmedAt: 'asc' } } },
  })

  if (!deal || deal.buyerId !== user.id) {
    return <div style={pageStyle}>این معامله پیدا نشد یا مال شما نیست.</div>
  }

  const buyerConfirmRecord = deal.confirmations.find((c) => c.type === 'buyer_confirm')
  const unloadingDone = deal.confirmations.some((c) => c.type === 'unloading')

  if (buyerConfirmRecord) {
    const wasAutoAccepted = buyerConfirmRecord.finalVerdict === 'auto_accepted_timeout'
    return (
      <div style={pageStyle}>
        <div style={cardStyle}>
          {wasAutoAccepted ? (
            <>
              <h1 style={{ fontSize: 17, fontWeight: 800, marginBottom: 8 }}>مهلت بررسی این بار به پایان رسیده</h1>
              <p style={{ fontSize: 13, color: '#4f5560', lineHeight: 1.9 }}>
                چون ظرف مهلت مقرر (طبق قرارداد) اقدامی ثبت نشد، این معامله به‌صورت خودکار تایید و تسویه شد.
                مسیر رسیدگی داخلی به اختلاف برای این معامله دیگر در دسترس نیست، چون شواهد لحظه‌ی تخلیه دیگر قابل جمع‌آوری نیستند.
                برای معاملات بعدی، لطفاً ظرف مهلت اعلام‌شده بار رو بررسی و تاییدیه رو ثبت کنید.
              </p>
            </>
          ) : (
            <h1 style={{ fontSize: 17, fontWeight: 800 }}>قبلاً تاییدیه‌ی این معامله رو ثبت کردی</h1>
          )}
        </div>
      </div>
    )
  }

  if (!unloadingDone) {
    return (
      <div style={pageStyle}>
        <div style={cardStyle}>
          <h1 style={{ fontSize: 17, fontWeight: 800 }}>هنوز تخلیه ثبت نشده</h1>
          <p style={{ fontSize: 13, color: '#4f5560' }}>وقتی راننده فرم تخلیه رو تکمیل کنه، می‌تونی اینجا تاییدیه‌ی نهایی رو ثبت کنی.</p>
        </div>
      </div>
    )
  }

  return (
    <div style={pageStyle}>
      <div style={cardStyle}>
        <h1 style={{ fontSize: 18, fontWeight: 800, marginBottom: 6 }}>تاییدیه‌ی نهایی تحویل بار</h1>
        <p style={{ fontSize: 13, color: '#6f7680', marginBottom: 14 }}>معامله #{deal.id.slice(0, 8)} — مقدار {deal.quantity}</p>

        <DeadlineBanner deadline={deal.qualityConfirmDeadline} />

        <form action={submitBuyerConfirmation} style={{ display: 'flex', flexDirection: 'column', gap: 12, marginTop: 16 }}>
          <input type="hidden" name="dealId" value={deal.id} />

          <label style={optionStyle}>
            <input type="radio" name="verdict" value="full_accept" defaultChecked />
            <span>✅ تایید کامل — کالا مطابق سفارش دریافت شد</span>
          </label>
          <label style={optionStyle}>
            <input type="radio" name="verdict" value="accept_with_discrepancy" />
            <span>⚠️ تایید با مغایرت — کالا دریافت شد ولی مشکلی داشت</span>
          </label>
          <label style={optionStyle}>
            <input type="radio" name="verdict" value="reject" />
            <span>❌ عدم تایید — کالا تحویل گرفته نشد</span>
          </label>

          <textarea name="note" placeholder="توضیح (اختیاری، مخصوصاً برای مغایرت یا رد)" rows={3} style={textareaStyle} />

          <button type="submit" style={submitBtnStyle}>ثبت تاییدیه</button>
        </form>
      </div>
    </div>
  )
}

/**
 * بنر پلکانی: هرچی به مهلت نزدیک‌تر بشیم، هشدار جدی‌تر می‌شه. عمداً به‌جای
 * «غیرممکن شدن اعتراض» می‌گه «مسیر رسیدگی داخلی بسته می‌شه» — چون این چیزیه
 * که واقعاً تحت کنترل ماست و می‌تونیم بهش متعهد بمونیم.
 */
function DeadlineBanner({ deadline }: { deadline: Date | null }) {
  if (!deadline) return null

  const msRemaining = new Date(deadline).getTime() - Date.now()
  const hoursRemaining = msRemaining / (60 * 60 * 1000)
  const deadlineLabel = new Date(deadline).toLocaleString('fa-IR')

  let style: React.CSSProperties = { background: '#eef4fd', color: '#1e357b' }
  let icon = 'ℹ️'
  if (hoursRemaining <= 6) {
    style = { background: '#fde8e8', color: '#9b1c1c' }
    icon = '🔴'
  } else if (hoursRemaining <= 24) {
    style = { background: '#fef3c7', color: '#92400e' }
    icon = '⏱'
  }

  return (
    <div style={{ ...style, borderRadius: 8, padding: '10px 14px', fontSize: 12.5, fontWeight: 600, lineHeight: 1.9 }}>
      {icon} تا <b>{deadlineLabel}</b> فرصت دارید بار رو بررسی و تایید یا اعتراض کنید. اگه تا اون موقع اقدامی ثبت نشه،
      طبق قرارداد، تایید به‌صورت خودکار انجام و وجه تسویه می‌شه — و مسیر رسیدگی داخلی به اختلاف برای این معامله دیگه در دسترس نخواهد بود.
    </div>
  )
}

const pageStyle: React.CSSProperties = { minHeight: '100vh', background: '#faf8f4', padding: '32px 20px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl' }
const cardStyle: React.CSSProperties = { maxWidth: 480, margin: '0 auto', background: '#fff', border: '1px solid #d8dde3', borderRadius: 14, padding: '24px 20px' }
const optionStyle: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 10, fontSize: 13, padding: '12px 14px', border: '1px solid #eceff3', borderRadius: 9, cursor: 'pointer' }
const textareaStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 9, padding: '10px 12px', fontSize: 13, fontFamily: 'inherit', resize: 'vertical' }
const submitBtnStyle: React.CSSProperties = { background: '#f6621b', color: '#fff', border: 'none', borderRadius: 9, padding: '13px 0', fontSize: 14.5, fontWeight: 800, cursor: 'pointer' }
