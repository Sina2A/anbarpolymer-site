import { test } from 'node:test'
import assert from 'node:assert/strict'
import type { ComponentProps } from 'react'
import { renderToStaticMarkup } from 'react-dom/server'
import DealPartyCard from '../../src/components/DealPartyCard'
import { colors } from '../../src/lib/styles/tokens'

/**
 * تستِ رندر برای DealPartyCard (کارتِ خریدار/فروشنده در /admin-deals).
 * کامپوننت صرفاً نمایشی است: هویت، KYC و فال‌بکِ آدرس را صفحه‌ی سرور حل می‌کند و فقط
 * رشته‌ی آماده می‌گیرد. این تست قرارداد نمایشیِ فعلی (PARTY_THEMES) را قفل می‌کند: رنگ/عنوان
 * هر نقش، حداقل ارتفاعِ مشترک، برچسب‌ها، فال‌بک‌ها، RTL و اسلاتِ children که فرم‌های اکشن داخلش
 * رندر می‌شوند.
 *
 * اجرا: npx tsx --test tests/unit/dealPartyCard.test.tsx
 * (glob معمولِ tests/unit/*.test.ts فایل‌های .tsx را نمی‌گیرد.)
 */

type Props = ComponentProps<typeof DealPartyCard>

// U+200C (ZWNJ) is built from its code point so an editor cannot silently strip an invisible literal.
const ZWNJ = String.fromCharCode(0x200c)
const REQUESTER = `درخواست${ZWNJ}دهنده`
const ACCEPTOR = `قبول${ZWNJ}کننده`
const VERIFIED = `تایید${ZWNJ}شده ✓`

// Role-chip palette per PARTY_THEMES: buyer uses the info tokens, seller a fixed orange pair.
const BUYER_CHIP = { bg: colors.infoBg, text: colors.infoText }
const SELLER_CHIP = { bg: '#ffedd5', text: '#9a3412' }

/** Exact markup of one chip (component's chipStyle: 10px / 600 / pill, 2px 8px padding). */
const chipHtml = (bg: string, text: string, label: string, extra = '') =>
  `<span style="display:inline-flex;align-items:center;gap:4px;font-size:10px;font-weight:600;background:${bg};color:${text};border-radius:999px;padding:2px 8px${extra}">${label}</span>`

const full: Props = {
  role: 'buyer',
  companyName: 'شرکت نمونه',
  economicCode: '411123456789',
  address: 'تهران، خیابان ولیعصر',
  verified: true,
}

const render = (over: Partial<Props> = {}) => renderToStaticMarkup(<DealPartyCard {...full} {...over} />)

test('نقش خریدار: آبی، عنوان خریدار، --party-line آبی و حداقل ارتفاع ۴۲۰', () => {
  const html = render({ role: 'buyer' })
  assert.match(html, /اطلاعات خریدار/)
  assert.match(html, /--party-line:#dbeafe;background:#f0f6ff;border-top:4px solid #1e357b/)
  assert.match(html, /min-height:420px/)
  assert.doesNotMatch(html, /اطلاعات فروشنده/)
})

test('نقش فروشنده: نارنجی، عنوان فروشنده، --party-line نارنجی و همان حداقل ارتفاع ۴۲۰', () => {
  const html = render({ role: 'seller' })
  assert.match(html, /اطلاعات فروشنده/)
  assert.match(html, /--party-line:#fed7aa;background:#fff7ed;border-top:4px solid #ea580c/)
  assert.match(html, /min-height:420px/)
  assert.doesNotMatch(html, /min-height:520px/)
  assert.doesNotMatch(html, /اطلاعات خریدار/)
})

test('برچسب نقش: خریدار با توکن‌های info و فروشنده با جفت‌رنگ نارنجی', () => {
  assert.ok(render({ role: 'buyer' }).includes(chipHtml(BUYER_CHIP.bg, BUYER_CHIP.text, 'خریدار')))
  assert.ok(render({ role: 'seller' }).includes(chipHtml(SELLER_CHIP.bg, SELLER_CHIP.text, 'فروشنده')))
})

test('RTL: ریشه‌ی کارت dir=rtl دارد', () => {
  assert.match(render(), /^<div dir="rtl" /)
  assert.match(render({ role: 'seller' }), /^<div dir="rtl" /)
})

test('احراز هویت: verified بر متن «تایید‌شده ✓» یا «تایید نشده» حاکم است', () => {
  const ok = render({ verified: true })
  assert.ok(ok.includes(VERIFIED))
  assert.doesNotMatch(ok, /تایید نشده/)
  const no = render({ verified: false })
  assert.match(no, /تایید نشده/)
  assert.ok(!no.includes(VERIFIED))
})

test('فال‌بک‌ها: کد اقتصادی/آدرس خالی یا فقط فاصله، و نامِ شرکتِ خالی', () => {
  const empty = render({ economicCode: null, address: null, companyName: undefined })
  assert.match(empty, /— — کد اقتصادی ثبت نشده/)
  assert.match(empty, /آدرس ثبت نشده/)
  assert.match(empty, /نام شرکت:<\/span><span[^>]*>—<\/span>/)
  assert.match(render({ address: '   ' }), /آدرس ثبت نشده/)

  const filled = render()
  assert.doesNotMatch(filled, /ثبت نشده/)
  assert.match(filled, /شرکت نمونه/)
  assert.match(filled, /411123456789/)
  assert.match(filled, /تهران، خیابان ولیعصر/)
})

test('برچسب دوم: درخواست‌دهنده بنفش، هر برچسب دیگر سبز، و بدون برچسب چیزی رندر نمی‌شود', () => {
  const margin = ';margin-right:4px'
  assert.ok(render({ secondaryLabel: REQUESTER }).includes(chipHtml(colors.purpleBg, colors.purpleText, REQUESTER, margin)))
  assert.ok(render({ secondaryLabel: ACCEPTOR }).includes(chipHtml(colors.successBg, colors.successText, ACCEPTOR, margin)))
  // Same rule on the seller card: the secondary chip depends on the label, not the role.
  assert.ok(render({ role: 'seller', secondaryLabel: REQUESTER }).includes(chipHtml(colors.purpleBg, colors.purpleText, REQUESTER, margin)))
  for (const none of [null, undefined]) {
    const html = render({ secondaryLabel: none })
    assert.ok(!html.includes(REQUESTER))
    assert.ok(!html.includes(ACCEPTOR))
  }
})

test('اسلات children: بعد از ردیف‌های هویت و مستقیماً فرزندِ فلکسِ کارت (برای marginTop:auto فوتر)', () => {
  const html = render({ children: <p>SLOT-A</p> })
  assert.ok(html.indexOf('SLOT-A') > html.indexOf('وضعیت احراز هویت'))
  assert.match(html, /<p>SLOT-A<\/p><\/div>$/)
})
