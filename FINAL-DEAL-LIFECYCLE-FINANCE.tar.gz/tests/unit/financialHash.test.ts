import { test } from 'node:test'
import assert from 'node:assert/strict'
import {
  GENESIS_HASH,
  HASH_VERSION,
  FinancialHashError,
  sha256Hex,
  canonicalValue,
  computeIdempotencyKey,
  genesisIdempotencyKey,
  computeRecordHash,
  verifyChain,
} from '../../src/lib/financialHash'
import type { ChainRecord, HashableRecord } from '../../src/lib/financialHash'

/**
 * تست زنجیره‌ی Hash تاریخچه‌ی مالی (src/lib/financialHash.ts): تعیینی‌بودن hash، تغییر hash
 * با تغییر هر فیلد، کلید Idempotency، و verifyChain که دست‌کاری، حذف و جابه‌جایی رکورد را
 * پیدا می‌کنه. این ماژول Prisma ندارد، پس بدون دیتابیس تست می‌شه. (رفتار تریگرهای
 * append-only دیتابیس فقط روی یک دیتابیس آزمایشی قابل‌تسته، نه اینجا.)
 *
 * اجرا: npx tsx --test tests/unit/financialHash.test.ts
 */

const T0 = new Date('2026-10-02T08:30:00.000Z')

function makeRecord(prev: ChainRecord | null, over: Partial<HashableRecord> = {}): ChainRecord {
  const seq = prev ? prev.seq + 1 : 1
  const base: HashableRecord = {
    seq,
    entityType: 'Order',
    entityId: 'order_1',
    fieldName: 'finalPrice',
    oldValue: null,
    newValue: '12500',
    changedBy: 'user_admin',
    changedAt: new Date(T0.getTime() + (seq - 1) * 1000),
    idempotencyKey: `key-${seq}`,
    previousRecordHash: prev ? prev.recordHash : GENESIS_HASH,
    ...over,
  }
  return { ...base, recordHash: computeRecordHash(base), hashVersion: HASH_VERSION }
}

/** زنجیره‌ی سالم سه‌رکوردی روی یک فیلد: null → 12500 → 13000 → 13500 */
function makeChain(): ChainRecord[] {
  const r1 = makeRecord(null, { oldValue: null, newValue: '12500' })
  const r2 = makeRecord(r1, { oldValue: '12500', newValue: '13000' })
  const r3 = makeRecord(r2, { oldValue: '13000', newValue: '13500' })
  return [r1, r2, r3]
}

// ── ثابت‌ها و sha256 ──────────────────────────────────────────────────────────

test('GENESIS_HASH: ۶۴ صفر؛ HASH_VERSION=1', () => {
  assert.equal(GENESIS_HASH.length, 64)
  assert.match(GENESIS_HASH, /^0{64}$/)
  assert.equal(HASH_VERSION, 1)
})

test('sha256Hex: بردار استانداردِ SHA-256("abc")', () => {
  assert.equal(sha256Hex('abc'), 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad')
})

test('sha256Hex: متن فارسی به‌صورت UTF-8 hash می‌شه (۶۴ هگز)', () => {
  assert.match(sha256Hex('قیمت نهایی'), /^[0-9a-f]{64}$/)
})

// ── canonicalValue ───────────────────────────────────────────────────────────

test('canonicalValue: null/undefined → null؛ اسکالرها → رشته‌ی کانونیک', () => {
  assert.equal(canonicalValue(null), null)
  assert.equal(canonicalValue(undefined), null)
  assert.equal(canonicalValue('x'), 'x')
  assert.equal(canonicalValue(''), '')
  assert.equal(canonicalValue(12500), '12500')
  assert.equal(canonicalValue(1.5), '1.5')
  assert.equal(canonicalValue(-0), '0')
  assert.equal(canonicalValue(true), 'true')
  assert.equal(canonicalValue(false), 'false')
  assert.equal(canonicalValue(BigInt(10)), '10') // بدون literal چون target=ES2017
  assert.equal(canonicalValue(T0), '2026-10-02T08:30:00.000Z')
})

test('canonicalValue: NaN، Infinity، تاریخ نامعتبر، شیء و NUL رد می‌شه', () => {
  assert.throws(() => canonicalValue(NaN), FinancialHashError)
  assert.throws(() => canonicalValue(Infinity), FinancialHashError)
  assert.throws(() => canonicalValue(new Date('invalid')), FinancialHashError)
  assert.throws(() => canonicalValue({} as unknown as string), FinancialHashError)
  assert.throws(() => canonicalValue('a\u0000b'), FinancialHashError)
})

// ── Idempotency ──────────────────────────────────────────────────────────────

const KEY_BASE = {
  entityType: 'Order',
  entityId: 'order_1',
  fieldName: 'finalPrice',
  newValue: 12500,
  formKey: 'form-abc',
}

test('computeIdempotencyKey: قطعی و ۶۴ هگز', () => {
  const a = computeIdempotencyKey(KEY_BASE)
  assert.match(a, /^[0-9a-f]{64}$/)
  assert.equal(computeIdempotencyKey({ ...KEY_BASE }), a)
})

test('computeIdempotencyKey: هر جزء کلید را عوض می‌کنه (موجودیت، فیلد، مقدار، فرم)', () => {
  const base = computeIdempotencyKey(KEY_BASE)
  const variants = [
    { ...KEY_BASE, entityType: 'Deal' },
    { ...KEY_BASE, entityId: 'order_2' },
    { ...KEY_BASE, fieldName: 'price' },
    { ...KEY_BASE, newValue: 12501 },
    { ...KEY_BASE, newValue: null },
    { ...KEY_BASE, formKey: 'form-xyz' },
  ]
  const keys = new Set([base, ...variants.map(computeIdempotencyKey)])
  assert.equal(keys.size, variants.length + 1)
})

test('computeIdempotencyKey: عدد و رشته‌ی هم‌ارز یک کلید می‌دن', () => {
  assert.equal(
    computeIdempotencyKey({ ...KEY_BASE, newValue: 12500 }),
    computeIdempotencyKey({ ...KEY_BASE, newValue: '12500' }),
  )
})

test('computeIdempotencyKey: مرز اجزا مبهم نیست (ab|c ≠ a|bc)', () => {
  const a = computeIdempotencyKey({ ...KEY_BASE, entityId: 'ab', fieldName: 'c' })
  const b = computeIdempotencyKey({ ...KEY_BASE, entityId: 'a', fieldName: 'bc' })
  assert.notEqual(a, b)
})

test('computeIdempotencyKey: formKey خالی یا حاوی NUL رد می‌شه', () => {
  assert.throws(() => computeIdempotencyKey({ ...KEY_BASE, formKey: '' }), FinancialHashError)
  assert.throws(() => computeIdempotencyKey({ ...KEY_BASE, formKey: 'a\u0000b' }), FinancialHashError)
  assert.throws(() => computeIdempotencyKey({ ...KEY_BASE, entityId: 'a\u0000b' }), FinancialHashError)
})

test('genesisIdempotencyKey: قالب قطعی برای هر فیلد', () => {
  assert.equal(genesisIdempotencyKey('Order', 'o1', 'finalPrice'), 'genesis:Order:o1:finalPrice')
})

// ── computeRecordHash ────────────────────────────────────────────────────────

test('computeRecordHash: قالب سریال‌سازی ثابته (جلوگیری از تغییر بی‌صدای فرمول)', () => {
  const [r1] = makeChain()
  const expected = sha256Hex(
    `["FFH1","Order","order_1",1,"finalPrice",null,"12500","user_admin","2026-10-02T08:30:00.000Z","key-1","${GENESIS_HASH}"]`,
  )
  assert.equal(r1.recordHash, expected)
})

test('computeRecordHash: قطعی و ۶۴ هگز', () => {
  const [r1] = makeChain()
  assert.match(r1.recordHash, /^[0-9a-f]{64}$/)
  assert.equal(computeRecordHash(r1), r1.recordHash)
})

test('computeRecordHash: تغییر هر فیلد hash را عوض می‌کنه', () => {
  const [, r2] = makeChain()
  const variants: Partial<HashableRecord>[] = [
    { seq: r2.seq + 1 },
    { entityType: 'Deal' },
    { entityId: 'order_2' },
    { fieldName: 'price' },
    { oldValue: '12501' },
    { oldValue: null },
    { newValue: '13001' },
    { newValue: null },
    { changedBy: 'user_other' },
    { changedBy: null },
    { changedAt: new Date(r2.changedAt.getTime() + 1) },
    { idempotencyKey: 'key-other' },
    { previousRecordHash: GENESIS_HASH },
  ]
  const hashes = new Set([r2.recordHash])
  for (const v of variants) hashes.add(computeRecordHash({ ...r2, ...v }))
  assert.equal(hashes.size, variants.length + 1)
})

test('computeRecordHash: null با رشته‌ی خالی فرق دارد', () => {
  const [r1] = makeChain()
  assert.notEqual(
    computeRecordHash({ ...r1, oldValue: null }),
    computeRecordHash({ ...r1, oldValue: '' }),
  )
})

test('computeRecordHash: seq، تاریخ، نسخه و NUL نامعتبر رد می‌شه', () => {
  const [r1] = makeChain()
  assert.throws(() => computeRecordHash({ ...r1, seq: 0 }), FinancialHashError)
  assert.throws(() => computeRecordHash({ ...r1, seq: 1.5 }), FinancialHashError)
  assert.throws(() => computeRecordHash({ ...r1, changedAt: new Date('invalid') }), FinancialHashError)
  assert.throws(() => computeRecordHash(r1, 2), FinancialHashError)
  assert.throws(() => computeRecordHash({ ...r1, newValue: 'a\u0000b' }), FinancialHashError)
})

// ── verifyChain: زنجیره‌ی سالم ────────────────────────────────────────────────

test('verifyChain: زنجیره‌ی خالی سالمه و tipHash ندارد', () => {
  assert.deepEqual(verifyChain([]), { ok: true, count: 0, tipHash: null })
})

test('verifyChain: زنجیره‌ی سالم → ok با count و tipHash', () => {
  const chain = makeChain()
  assert.deepEqual(verifyChain(chain), { ok: true, count: 3, tipHash: chain[2].recordHash })
})

test('verifyChain: ترتیب ورودی مهم نیست (بر اساس seq مرتب می‌شه)', () => {
  const [r1, r2, r3] = makeChain()
  assert.equal(verifyChain([r3, r1, r2]).ok, true)
})

test('verifyChain: چند فیلدِ درهم‌تنیده روی یک موجودیت سالمه', () => {
  const a1 = makeRecord(null, { fieldName: 'finalPrice', oldValue: null, newValue: '1' })
  const b1 = makeRecord(a1, { fieldName: 'status', oldValue: null, newValue: 'pending' })
  const a2 = makeRecord(b1, { fieldName: 'finalPrice', oldValue: '1', newValue: '2' })
  const b2 = makeRecord(a2, { fieldName: 'status', oldValue: 'pending', newValue: 'priced' })
  assert.equal(verifyChain([a1, b1, a2, b2]).ok, true)
})

// ── verifyChain: دست‌کاری‌ها ──────────────────────────────────────────────────

test('verifyChain: تغییر محتوای رکورد بدون بازمحاسبه‌ی hash → hash-mismatch', () => {
  const [r1, r2, r3] = makeChain()
  const result = verifyChain([r1, { ...r2, newValue: '99999' }, r3])
  assert.deepEqual(result.ok, false)
  if (!result.ok) {
    assert.equal(result.atSeq, 2)
    assert.equal(result.reason, 'hash-mismatch')
  }
})

test('verifyChain: تغییر changedAt حتی به‌اندازه‌ی ۱ میلی‌ثانیه شناسایی می‌شه', () => {
  const [r1, r2, r3] = makeChain()
  const result = verifyChain([r1, { ...r2, changedAt: new Date(r2.changedAt.getTime() + 1) }, r3])
  assert.equal(result.ok, false)
  if (!result.ok) assert.equal(result.reason, 'hash-mismatch')
})

test('verifyChain: رکورد بازنویسی‌شده با hash تازه، پیوند رکورد بعدی را می‌شکنه → broken-link', () => {
  const [r1, , r3] = makeChain()
  const forged2 = makeRecord(r1, { oldValue: '12500', newValue: '99999' })
  const result = verifyChain([r1, forged2, r3])
  assert.equal(result.ok, false)
  if (!result.ok) {
    assert.equal(result.atSeq, 3)
    assert.equal(result.reason, 'broken-link')
  }
})

test('verifyChain: بازنویسی دنباله با oldValue قبلی → old-value-mismatch', () => {
  const [r1, r2] = makeChain()
  const forged2 = makeRecord(r1, { oldValue: '12500', newValue: '99999' })
  // مهاجم hash رکورد ۳ را درست دوباره می‌سازه ولی oldValue قبلی (13000) را نگه می‌داره
  const forged3 = makeRecord(forged2, { oldValue: '13000', newValue: '13500' })
  const result = verifyChain([r1, forged2, forged3])
  assert.equal(result.ok, false)
  if (!result.ok) {
    assert.equal(result.atSeq, 3)
    assert.equal(result.reason, 'old-value-mismatch')
  }
  assert.ok(r2)
})

test('verifyChain: حذف رکورد وسط → seq-gap', () => {
  const [r1, , r3] = makeChain()
  const result = verifyChain([r1, r3])
  assert.equal(result.ok, false)
  if (!result.ok) {
    assert.equal(result.atSeq, 2)
    assert.equal(result.reason, 'seq-gap')
  }
})

test('verifyChain: حذف رکورد اول → seq-gap', () => {
  const [, r2, r3] = makeChain()
  const result = verifyChain([r2, r3])
  assert.equal(result.ok, false)
  if (!result.ok) {
    assert.equal(result.atSeq, 1)
    assert.equal(result.reason, 'seq-gap')
  }
})

test('verifyChain: seq تکراری → seq-duplicate', () => {
  const [r1, r2] = makeChain()
  const result = verifyChain([r1, r1, r2])
  assert.equal(result.ok, false)
  if (!result.ok) assert.equal(result.reason, 'seq-duplicate')
})

test('verifyChain: رکورد موجودیت دیگر → mixed-entity', () => {
  const [r1, r2] = makeChain()
  const alien = makeRecord(r1, { entityId: 'order_2', oldValue: '12500', newValue: '13000' })
  const result = verifyChain([r1, alien])
  assert.equal(result.ok, false)
  if (!result.ok) {
    assert.equal(result.atSeq, 2)
    assert.equal(result.reason, 'mixed-entity')
  }
  assert.ok(r2)
})

test('verifyChain: previousRecordHash اشتباه (با hash خودِ رکورد درست) → broken-link', () => {
  const [r1] = makeChain()
  const bad2 = makeRecord(r1, { oldValue: '12500', newValue: '13000', previousRecordHash: GENESIS_HASH })
  const result = verifyChain([r1, bad2])
  assert.equal(result.ok, false)
  if (!result.ok) {
    assert.equal(result.atSeq, 2)
    assert.equal(result.reason, 'broken-link')
  }
})

test('verifyChain: oldValue هر فیلد باید با newValue قبلیِ همان فیلد بخونه', () => {
  const a1 = makeRecord(null, { fieldName: 'finalPrice', oldValue: null, newValue: '1' })
  const b1 = makeRecord(a1, { fieldName: 'status', oldValue: null, newValue: 'pending' })
  const a2 = makeRecord(b1, { fieldName: 'finalPrice', oldValue: '999', newValue: '2' })
  const result = verifyChain([a1, b1, a2])
  assert.equal(result.ok, false)
  if (!result.ok) {
    assert.equal(result.atSeq, 3)
    assert.equal(result.reason, 'old-value-mismatch')
  }
})

test('verifyChain: hashVersion ناشناخته → unsupported-hash-version', () => {
  const [r1, r2] = makeChain()
  const result = verifyChain([r1, { ...r2, hashVersion: 2 }])
  assert.equal(result.ok, false)
  if (!result.ok) {
    assert.equal(result.atSeq, 2)
    assert.equal(result.reason, 'unsupported-hash-version')
  }
})

test('verifyChain: رکورد با NUL → invalid-record (نه crash)', () => {
  const [r1, r2] = makeChain()
  const result = verifyChain([r1, { ...r2, newValue: 'a\u0000b' }])
  assert.equal(result.ok, false)
  if (!result.ok) {
    assert.equal(result.atSeq, 2)
    assert.equal(result.reason, 'invalid-record')
  }
})

// ── محدودیت‌های صادقانه‌ی hash (دلیل وجود لنگر بیرونی) ─────────────────────────

test('محدودیت: حذف رکوردهای انتهایی زنجیره را verifyChain پیدا نمی‌کنه — فقط tipHash لنگرشده پیداش می‌کنه', () => {
  const chain = makeChain()
  const anchoredTip = chain[2].recordHash
  const truncated = verifyChain(chain.slice(0, 2))
  assert.equal(truncated.ok, true)
  if (truncated.ok) assert.notEqual(truncated.tipHash, anchoredTip)
})

test('محدودیت: بازنویسیِ کاملِ دنباله (با hashهای تازه) زنجیره‌ی معتبر می‌سازه — فقط tipHash لنگرشده پیداش می‌کنه', () => {
  const chain = makeChain()
  const anchoredTip = chain[2].recordHash

  const r1 = chain[0]
  const f2 = makeRecord(r1, { oldValue: '12500', newValue: '99999' })
  const f3 = makeRecord(f2, { oldValue: '99999', newValue: '13500' })
  const forged = verifyChain([r1, f2, f3])

  assert.equal(forged.ok, true)
  if (forged.ok) assert.notEqual(forged.tipHash, anchoredTip)
})
