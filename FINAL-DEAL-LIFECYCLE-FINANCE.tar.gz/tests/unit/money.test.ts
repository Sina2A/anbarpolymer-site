import { test } from 'node:test'
import assert from 'node:assert/strict'
import {
  KG_PER_TON,
  MAX_TOMAN,
  MoneyCalcError,
  MoneyInputError,
  tonToKg,
  tonToKgStrict,
  kgToTon,
  roundToman,
  lineTotalToman,
  summarizeDocument,
  summarizeOrderItems,
  trySummarizeOrderItems,
  summarizeDeal,
  trySummarizeDeal,
  dealApprovalAmountToman,
  formatToman,
  isBlankInput,
  parseMoneyInput,
  parseTomanInput,
  parseTonInput,
  parseKgInput,
  parseIntegerInput,
  parseDecimalInput,
  requireParsed,
  requireMoneyInput,
} from '../../src/lib/money'
import type { ParseResult } from '../../src/lib/money'
import * as money from '../../src/lib/money'

/**
 * تست موتور محاسبه‌ی مالی واحد (src/lib/money.ts): تبدیل تن↔کیلو، مبلغ ردیف، مالیات دستیِ
 * per-ردیف (خالی = ۰؛ هیچ درصد خودکاری وجود نداره)، جمع‌های سند (اقلام، مالیات، قابل پرداخت)
 * و تجزیه‌ی ورودی کاربر (رقم فارسی، هزارگان، رد NaN/منفی/صفر). این ماژول عمداً بدون import
 * است تا بدون دیتابیس و بدون Next تست بشه.
 *
 * اجرا: npx tsx --test tests/unit/money.test.ts
 */

function expectOk(result: ParseResult<number | null>, value: number | null) {
  assert.deepEqual(result, { ok: true, value })
}

function expectFail(result: ParseResult<number | null>, code: string) {
  assert.equal(result.ok, false, `انتظار شکست با کد ${code} بود`)
  if (!result.ok) {
    assert.equal(result.code, code)
    assert.ok(result.error.length > 0, 'پیام خطا نباید خالی باشه')
  }
}

// PRNG قطعی (mulberry32) برای تست‌های ویژگی‌محور؛ بدون وابستگی به Math.random
function mulberry32(seed: number) {
  let a = seed | 0
  return () => {
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

// ── ثابت‌ها ──────────────────────────────────────────────────────────────────

test('ثابت‌ها: ۱۰۰۰ کیلو در تن، سقف ۱e13، جمعِ دو مبلغ مجاز زیر 2^53', () => {
  assert.equal(KG_PER_TON, 1000)
  assert.equal(MAX_TOMAN, 1e13)
  assert.ok(MAX_TOMAN * 2 < Number.MAX_SAFE_INTEGER)
})

test('ثابت‌ها: هیچ نرخ یا تابعِ مالیاتِ خودکاری از ماژول export نمی‌شه (مالیات فقط دستیه)', () => {
  for (const removed of ['vatToman', 'VAT_PERCENT', 'VAT_RATE']) {
    assert.equal(removed in money, false, `${removed} نباید export بشه`)
  }
})

// ── وزن ──────────────────────────────────────────────────────────────────────

test('tonToKg: تن → کیلوی صحیح (ضرب ×۱۰۰۰ که قبلاً جا افتاده بود)', () => {
  assert.equal(tonToKg(1), 1000)
  assert.equal(tonToKg(2.5), 2500)
  assert.equal(tonToKg(0), 0)
  assert.equal(tonToKg(0.1 + 0.2), 300) // خطای float: 0.30000000000000004
})

test('tonToKg: مقدار نامعتبر MoneyCalcError می‌ده', () => {
  for (const bad of [NaN, Infinity, -Infinity, -1, -0.001]) {
    assert.throws(() => tonToKg(bad), MoneyCalcError)
  }
  assert.throws(() => tonToKg('1' as unknown as number), MoneyCalcError)
})

test('tonToKgStrict: فقط ۳ رقم اعشار و حداقل ۱ کیلو', () => {
  assert.equal(tonToKgStrict(1.234), 1234)
  assert.equal(tonToKgStrict(0.001), 1)
  assert.equal(tonToKgStrict(2.5), 2500)
  assert.equal(tonToKgStrict(0.1 + 0.2), 300)
})

test('tonToKgStrict: صفر، منفی، NaN، بیش از ۳ رقم اعشار و کمتر از ۱ کیلو رد می‌شن', () => {
  for (const bad of [0, -1, NaN, Infinity, 0.0004, 1.2345, 1e-9]) {
    assert.throws(() => tonToKgStrict(bad), MoneyCalcError, `باید رد می‌شد: ${bad}`)
  }
})

test('kgToTon: فقط برای نمایش', () => {
  assert.equal(kgToTon(2500), 2.5)
})

// ── مبلغ ─────────────────────────────────────────────────────────────────────

test('roundToman: قیمت قدیمیِ Float به تومان صحیح گرد می‌شه (half-up)', () => {
  assert.equal(roundToman(12500.4), 12500)
  assert.equal(roundToman(12500.5), 12501)
  assert.equal(roundToman(0), 0)
  assert.equal(roundToman(MAX_TOMAN), MAX_TOMAN)
})

test('roundToman: NaN، منفی، نامتناهی و بیش از سقف رد می‌شن', () => {
  for (const bad of [NaN, -1, Infinity, MAX_TOMAN + 1]) {
    assert.throws(() => roundToman(bad), MoneyCalcError)
  }
})

test('lineTotalToman: قیمت واحد (تومان/کیلو) × کیلوی صحیح', () => {
  assert.equal(lineTotalToman(12500, 1000), 12_500_000)
  assert.equal(lineTotalToman(0, 5), 0)
  assert.equal(lineTotalToman(5, 0), 0)
  assert.equal(lineTotalToman(MAX_TOMAN, 1), MAX_TOMAN)
})

test('lineTotalToman: غیرصحیح، منفی و بیش از سقف رد می‌شه', () => {
  assert.throws(() => lineTotalToman(1.5, 2), MoneyCalcError)
  assert.throws(() => lineTotalToman(-1, 2), MoneyCalcError)
  assert.throws(() => lineTotalToman(2, -1), MoneyCalcError)
  assert.throws(() => lineTotalToman(2, 1.5), MoneyCalcError)
  assert.throws(() => lineTotalToman(MAX_TOMAN, 2), MoneyCalcError)
})

// ── مالیات دستی: اعتبارسنجی و سقف‌ها ──────────────────────────────────────────────────────────────

test('مالیات دستی: مقدار نامعتبر (NaN، منفی، اعشاری، نامتناهی، بیش از سقف، غیرعدد) MoneyCalcError می‌ده', () => {
  for (const bad of [NaN, -1, -0.5, 1.5, Infinity, -Infinity, MAX_TOMAN + 1, '5' as unknown as number]) {
    assert.throws(
      () => summarizeDocument([{ unitPriceToman: 10, kg: 1, taxToman: bad }]),
      MoneyCalcError,
      `باید رد می‌شد: ${String(bad)}`,
    )
  }
})

test('مالیات دستی: سقف‌ها — خودِ سقف مجازه، یک تومان بیشتر رد می‌شه (ردیف، جمع مالیات، قابل پرداخت)', () => {
  // مالیات تک‌ردیف دقیقاً روی سقف: مجاز
  const taxAtCap = summarizeDocument([{ unitPriceToman: 0, kg: 0, taxToman: MAX_TOMAN }])
  assert.equal(taxAtCap.taxTotal, MAX_TOMAN)
  assert.equal(taxAtCap.grandTotal, MAX_TOMAN)
  // جمع اقلام + مالیات دقیقاً روی سقف: مجاز
  const grandAtCap = summarizeDocument([{ unitPriceToman: MAX_TOMAN - 5, kg: 1, taxToman: 5 }])
  assert.equal(grandAtCap.grandTotal, MAX_TOMAN)

  // مالیات یک ردیف بالای سقف
  assert.throws(() => summarizeDocument([{ unitPriceToman: 0, kg: 0, taxToman: MAX_TOMAN + 1 }]), MoneyCalcError)
  // هر ردیف مجازه ولی جمع مالیات‌ها از سقف می‌گذره
  assert.throws(
    () =>
      summarizeDocument([
        { unitPriceToman: 0, kg: 0, taxToman: MAX_TOMAN },
        { unitPriceToman: 0, kg: 0, taxToman: 1 },
      ]),
    (err: unknown) => err instanceof MoneyCalcError && err.message.includes('جمع مالیات'),
  )
  // جمع اقلام و جمع مالیات هرکدام مجازند ولی مبلغ قابل پرداخت از سقف می‌گذره
  assert.throws(
    () => summarizeDocument([{ unitPriceToman: MAX_TOMAN, kg: 1, taxToman: 1 }]),
    (err: unknown) => err instanceof MoneyCalcError && err.message.includes('قابل پرداخت'),
  )
})

// ── سند: ردیف‌ها + مالیات + جمع کل ───────────────────────────────────────────

test('summarizeDocument: سند خالی همه‌چیز صفره', () => {
  assert.deepEqual(summarizeDocument([]), { lines: [], itemsTotal: 0, taxTotal: 0, grandTotal: 0 })
})

test('summarizeDocument: یک ردیف بدون مالیات — 12,500 تومان/کیلو × 1000 کیلو', () => {
  const s = summarizeDocument([{ unitPriceToman: 12500, kg: 1000 }])
  assert.equal(s.itemsTotal, 12_500_000)
  assert.equal(s.taxTotal, 0)
  assert.equal(s.grandTotal, 12_500_000)
  assert.deepEqual(s.lines, [{ unitPriceToman: 12500, kg: 1000, lineTotal: 12_500_000, lineTax: 0 }])
})

test('summarizeDocument: یک ردیف با مالیات دستی', () => {
  const s = summarizeDocument([{ unitPriceToman: 12500, kg: 1000, taxToman: 1_000_000 }])
  assert.equal(s.itemsTotal, 12_500_000)
  assert.equal(s.taxTotal, 1_000_000)
  assert.equal(s.grandTotal, 13_500_000)
  assert.deepEqual(s.lines, [{ unitPriceToman: 12500, kg: 1000, lineTotal: 12_500_000, lineTax: 1_000_000 }])
})

test('summarizeDocument: مالیات دستیِ هر ردیف مستقله و جمع کل = Σ(مبلغ ردیف + مالیات همان ردیف)', () => {
  const s = summarizeDocument([
    { unitPriceToman: 46500, kg: 20000, taxToman: 8_000_000 }, // 930,000,000
    { unitPriceToman: 47000, kg: 5500, taxToman: 0 }, // 258,500,000 — مالیات صریحاً ۰
    { unitPriceToman: 1000, kg: 3, taxToman: 1 }, // 3,000 — مالیات به مبلغ ردیف وابسته نیست
    { unitPriceToman: 2000, kg: 10 }, // 20,000 — مالیات واردنشده
  ])
  assert.deepEqual(
    s.lines.map((l) => l.lineTotal),
    [930_000_000, 258_500_000, 3_000, 20_000],
  )
  assert.deepEqual(
    s.lines.map((l) => l.lineTax),
    [8_000_000, 0, 1, 0],
  )
  assert.equal(s.itemsTotal, 1_188_523_000)
  assert.equal(s.taxTotal, 8_000_001)
  assert.equal(s.grandTotal, 1_196_523_001)
})

test('summarizeDocument: مالیات null/undefined/غایب = ۰ و هیچ فیلدی NaN یا نامتناهی نمی‌شه', () => {
  const s = summarizeDocument([
    { unitPriceToman: 100, kg: 10, taxToman: null },
    { unitPriceToman: 200, kg: 5, taxToman: undefined },
    { unitPriceToman: 300, kg: 1 },
  ])
  assert.deepEqual(
    s.lines.map((l) => l.lineTax),
    [0, 0, 0],
  )
  assert.equal(s.itemsTotal, 2300)
  assert.equal(s.taxTotal, 0)
  assert.equal(s.grandTotal, 2300)
  const numbers = [s.itemsTotal, s.taxTotal, s.grandTotal, ...s.lines.flatMap((l) => [l.lineTotal, l.lineTax])]
  for (const n of numbers) assert.ok(Number.isFinite(n), `باید عدد متناهی باشه: ${n}`)
})

test('summarizeDocument: مالیات ۰ صریح همان خروجیِ مالیات غایب است', () => {
  const absent = summarizeDocument([
    { unitPriceToman: 12500, kg: 40 },
    { unitPriceToman: 900, kg: 7 },
  ])
  const zero = summarizeDocument([
    { unitPriceToman: 12500, kg: 40, taxToman: 0 },
    { unitPriceToman: 900, kg: 7, taxToman: 0 },
  ])
  assert.deepEqual(zero, absent)
})

test('summarizeDocument: مالیات -۰ به ۰ نرمال می‌شه (نه «-0» در جمع‌ها یا نمایش)', () => {
  const s = summarizeDocument([{ unitPriceToman: 1, kg: 1, taxToman: -0 }])
  assert.ok(Object.is(s.lines[0].lineTax, 0), 'lineTax باید +0 باشه')
  assert.ok(Object.is(s.taxTotal, 0), 'taxTotal باید +0 باشه')
  assert.equal(formatToman(s.lines[0].lineTax), '0')
})

test('ریگرسیون: هیچ مالیات خودکاری اضافه نمی‌شه — ردیف 100 تومان/کیلو × 1000 کیلو بدون مالیات', () => {
  const s = summarizeDocument([{ unitPriceToman: 100, kg: 1000 }])
  assert.equal(s.itemsTotal, 100_000)
  assert.equal(s.taxTotal, 0)
  assert.equal(s.grandTotal, 100_000)
  assert.equal(s.lines[0].lineTax, 0)
})

test('summarizeDocument: ترتیب ردیف‌ها همان ترتیب ورودیه', () => {
  const s = summarizeDocument([
    { unitPriceToman: 300, kg: 2 },
    { unitPriceToman: 100, kg: 1 },
    { unitPriceToman: 200, kg: 5 },
  ])
  assert.deepEqual(
    s.lines.map((l) => l.unitPriceToman),
    [300, 100, 200],
  )
})

test('summarizeDocument: هم‌ارزی‌ها روی ۲۰۰۰ سند شبه‌تصادفی (مالیات دستی؛ بعضی ردیف‌ها بدون مالیات)', () => {
  const rand = mulberry32(20261002)
  const int = (min: number, max: number) => min + Math.floor(rand() * (max - min + 1))
  for (let iter = 0; iter < 2000; iter++) {
    const n = int(1, 8)
    const inputs = Array.from({ length: n }, () => {
      // ۲ از ۶ ردیف: null/undefined؛ بقیه: مالیات دستیِ دلخواه (۰ هم ممکنه)
      const pick = int(0, 5)
      const taxToman = pick === 0 ? null : pick === 1 ? undefined : int(0, 9_999_999)
      return { unitPriceToman: int(0, 99999), kg: int(0, 5000), taxToman }
    })
    const s = summarizeDocument(inputs)

    assert.equal(s.lines.length, inputs.length)
    assert.equal(
      s.lines.reduce((a, l) => a + l.lineTotal, 0),
      s.itemsTotal,
    )
    assert.equal(
      s.lines.reduce((a, l) => a + l.lineTax, 0),
      s.taxTotal,
    )
    assert.equal(s.grandTotal, s.itemsTotal + s.taxTotal)
    assert.equal(
      s.lines.reduce((a, l) => a + l.lineTotal + l.lineTax, 0),
      s.grandTotal,
    )
    inputs.forEach((input, i) => {
      // مالیات هر ردیف دقیقاً همان ورودیِ دستیه (null/undefined = ۰)؛ هیچ چیزی محاسبه‌شده نیست
      assert.equal(s.lines[i].lineTax, input.taxToman ?? 0)
      assert.equal(s.lines[i].lineTotal, input.unitPriceToman * input.kg)
    })
  }
})

test('summarizeDocument: ردیف نامعتبر و جمع بیش از سقف رد می‌شه', () => {
  assert.throws(() => summarizeDocument([{ unitPriceToman: 1.5, kg: 1 }]), MoneyCalcError)
  assert.throws(() => summarizeDocument([{ unitPriceToman: 1, kg: -1 }]), MoneyCalcError)
  assert.throws(
    () =>
      summarizeDocument([
        { unitPriceToman: MAX_TOMAN, kg: 1 },
        { unitPriceToman: 1, kg: 1 },
      ]),
    MoneyCalcError,
  )
})

// ── سفارش ────────────────────────────────────────────────────────────────────

test('summarizeOrderItems: قیمت مرجع 100 تومان/کیلو × 2 تن → جمع 200,000؛ بدون مالیات، چیزی اضافه نمی‌شه', () => {
  const s = summarizeOrderItems([{ price: 100, finalPrice: null, quantity: 2, taxAmount: null }])
  assert.equal(s.lines[0].kg, 2000)
  assert.equal(s.itemsTotal, 200_000)
  assert.equal(s.taxTotal, 0)
  assert.equal(s.grandTotal, 200_000)
})

test('summarizeOrderItems: مالیات دستیِ هر ردیف در جمع کل می‌شینه و null = ۰', () => {
  const s = summarizeOrderItems([
    { price: 100, finalPrice: null, quantity: 2, taxAmount: 12_345 },
    { price: 100, finalPrice: null, quantity: 1, taxAmount: null },
  ])
  assert.deepEqual(
    s.lines.map((l) => l.lineTax),
    [12_345, 0],
  )
  assert.equal(s.itemsTotal, 300_000)
  assert.equal(s.taxTotal, 12_345)
  assert.equal(s.grandTotal, 312_345)
})

test('summarizeOrderItems: finalPrice بر price مقدمه (با ?? نه ||)', () => {
  assert.equal(summarizeOrderItems([{ price: 100, finalPrice: 150, quantity: 1, taxAmount: null }]).itemsTotal, 150_000)
  assert.equal(summarizeOrderItems([{ price: 100, finalPrice: undefined, quantity: 1, taxAmount: null }]).itemsTotal, 100_000)
  // finalPrice=0 همان صفر حساب می‌شه (همان رفتار قدیمیِ ??)
  assert.equal(summarizeOrderItems([{ price: 100, finalPrice: 0, quantity: 1, taxAmount: null }]).itemsTotal, 0)
})

test('summarizeOrderItems: مالیات به قیمت وابسته نیست؛ با finalPrice یا price همان مالیات دستی می‌شینه', () => {
  const withFinal = summarizeOrderItems([{ price: 100, finalPrice: 150, quantity: 1, taxAmount: 7_000 }])
  const withoutFinal = summarizeOrderItems([{ price: 100, finalPrice: null, quantity: 1, taxAmount: 7_000 }])
  assert.equal(withFinal.itemsTotal, 150_000)
  assert.equal(withoutFinal.itemsTotal, 100_000)
  assert.equal(withFinal.taxTotal, 7_000)
  assert.equal(withoutFinal.taxTotal, 7_000)
  assert.equal(withFinal.grandTotal, 157_000)
  assert.equal(withoutFinal.grandTotal, 107_000)
})

test('summarizeOrderItems: قیمت اعشاریِ قدیمی در مرز به تومان صحیح گرد می‌شه', () => {
  assert.equal(summarizeOrderItems([{ price: 100.4, quantity: 1, taxAmount: null }]).lines[0].unitPriceToman, 100)
  assert.equal(summarizeOrderItems([{ price: 100.5, quantity: 1, taxAmount: null }]).lines[0].unitPriceToman, 101)
})

test('summarizeOrderItems: دو قلم واقعی با تن اعشاری و مالیات دستیِ per-ردیف', () => {
  const s = summarizeOrderItems([
    { price: 45000, finalPrice: 46500, quantity: 20, taxAmount: 8_000_000 }, // 46,500 × 20,000 kg
    { price: 47000, finalPrice: null, quantity: 5.5, taxAmount: null }, // 47,000 × 5,500 kg، بدون مالیات
  ])
  assert.equal(s.lines[0].lineTotal, 930_000_000)
  assert.equal(s.lines[1].lineTotal, 258_500_000)
  assert.deepEqual(
    s.lines.map((l) => l.lineTax),
    [8_000_000, 0],
  )
  assert.equal(s.itemsTotal, 1_188_500_000)
  assert.equal(s.taxTotal, 8_000_000)
  assert.equal(s.grandTotal, 1_196_500_000)
})

test('summarizeOrderItems: داده‌ی خراب MoneyCalcError می‌ده', () => {
  assert.throws(() => summarizeOrderItems([{ price: NaN, quantity: 1, taxAmount: null }]), MoneyCalcError)
  assert.throws(() => summarizeOrderItems([{ price: 100, quantity: -1, taxAmount: null }]), MoneyCalcError)
  assert.throws(() => summarizeOrderItems([{ price: -5, quantity: 1, taxAmount: null }]), MoneyCalcError)
})

test('summarizeOrderItems: مالیات ذخیره‌شده‌ی خراب (منفی، اعشاری، NaN، بیش از سقف) MoneyCalcError می‌ده، نه ۰', () => {
  for (const bad of [-5, 1.5, NaN, Infinity, MAX_TOMAN + 1]) {
    assert.throws(
      () => summarizeOrderItems([{ price: 100, quantity: 1, taxAmount: bad }]),
      MoneyCalcError,
      `باید رد می‌شد: ${bad}`,
    )
  }
})

test('trySummarizeOrderItems: داده‌ی خراب → null (نه عدد ساختگی)، داده‌ی سالم → خلاصه', () => {
  assert.equal(trySummarizeOrderItems([{ price: NaN, quantity: 1, taxAmount: null }]), null)
  assert.equal(trySummarizeOrderItems([{ price: 100, quantity: 2, taxAmount: null }])?.grandTotal, 200_000)
})

test('trySummarizeOrderItems: مالیات ذخیره‌شده‌ی خراب → null (نه ۰ بی‌صدا)؛ مالیات سالم → خلاصه', () => {
  assert.equal(trySummarizeOrderItems([{ price: 100, quantity: 2, taxAmount: -5 }]), null)
  for (const bad of [1.5, NaN, Infinity, MAX_TOMAN + 1]) {
    assert.equal(trySummarizeOrderItems([{ price: 100, quantity: 2, taxAmount: bad }]), null, `باید null می‌شد: ${bad}`)
  }
  assert.equal(trySummarizeOrderItems([{ price: 100, quantity: 2, taxAmount: 5_000 }])?.grandTotal, 205_000)
})

// ── نمایش ────────────────────────────────────────────────────────────────────

test('formatToman: en-US با جداکننده‌ی کاما؛ fa-IR خطا نمی‌ده', () => {
  assert.equal(formatToman(12_500_000), '12,500,000')
  assert.equal(formatToman(0), '0')
  assert.ok(formatToman(1250, 'fa-IR').length > 0)
})

// ── isBlankInput ─────────────────────────────────────────────────────────────

test('isBlankInput: خالی، فاصله و نویسه‌ی نامرئی خالی حساب می‌شن؛ صفر خالی نیست', () => {
  for (const blank of [null, undefined, '', '   ', '‌', '‏', '   ']) {
    assert.equal(isBlankInput(blank), true)
  }
  for (const notBlank of ['0', 'a', 0, {}, []]) {
    assert.equal(isBlankInput(notBlank), false)
  }
})

// ── parseMoneyInput: پذیرفته‌ها ───────────────────────────────────────────────

test('parseMoneyInput: رقم لاتین، هزارگان و ارقام فارسی/عربی پذیرفته می‌شن', () => {
  expectOk(parseMoneyInput('12500'), 12500)
  expectOk(parseMoneyInput('12,500'), 12500)
  expectOk(parseMoneyInput('۱۲٬۵۰۰'), 12500) // رقم فارسی + جداکننده‌ی عربی
  expectOk(parseMoneyInput('۱۲،۵۰۰'), 12500) // ویرگول فارسی
  expectOk(parseMoneyInput('١٢٥٠٠'), 12500) // رقم عربی-هندی
  expectOk(parseMoneyInput('۱۲۵۰۰'), 12500)
  expectOk(parseMoneyInput('1,234,567'), 1_234_567)
  expectOk(parseMoneyInput('999'), 999)
})

test('parseMoneyInput: فاصله و نویسه‌های نامرئی نادیده گرفته می‌شن', () => {
  expectOk(parseMoneyInput('  12 500  '), 12500)
  expectOk(parseMoneyInput('12‌500'), 12500) // نیم‌فاصله
  expectOk(parseMoneyInput('12 500'), 12500) // NBSP
  expectOk(parseMoneyInput('‏12500'), 12500) // RLM
  expectOk(parseMoneyInput('﻿12500'), 12500) // BOM
})

test('parseMoneyInput: صفرهای ابتدایی در عدد ساده مجازه ولی در گروه اول هزارگان نه', () => {
  expectOk(parseMoneyInput('0012'), 12)
  expectFail(parseMoneyInput('0,500'), 'format')
})

test('parseMoneyInput: ورودی number (نه رشته) هم کار می‌کنه', () => {
  expectOk(parseMoneyInput(12500), 12500)
  expectFail(parseMoneyInput(12500.5), 'not-integer')
  expectFail(parseMoneyInput(-5), 'negative')
  expectFail(parseMoneyInput(0), 'zero')
  expectFail(parseMoneyInput(NaN), 'format')
  expectFail(parseMoneyInput(Infinity), 'format')
  expectFail(parseMoneyInput(1e21), 'format')
})

// ── parseMoneyInput: ردشده‌ها ─────────────────────────────────────────────────

test('parseMoneyInput: هزارگان نامعتبر و اعشارِ کاما رد می‌شه (1,5 اعشار نیست)', () => {
  for (const bad of ['1,5', '1,2345', '1,234,56', ',500', '1,,500', '12,34', '1,00']) {
    expectFail(parseMoneyInput(bad), 'format')
  }
})

test('parseMoneyInput: نماد علمی، hex، Infinity، NaN، علامت و متن رد می‌شن', () => {
  for (const bad of ['1e5', '1E5', '0x10', 'Infinity', 'NaN', '--5', '+5', '5.', '.5', 'abc', '12abc', '1 e5', '٫5']) {
    expectFail(parseMoneyInput(bad), 'format')
  }
})

test('parseMoneyInput: کاراکتر NUL و ورودی بیش از ۶۴ نویسه رد می‌شه', () => {
  expectFail(parseMoneyInput('12\u0000500'), 'format')
  expectFail(parseMoneyInput('1'.repeat(65)), 'format')
})

test('parseMoneyInput: هر نقطه‌ی اعشار در حالت صحیح رد می‌شه (حتی 12.000)', () => {
  expectFail(parseMoneyInput('12.500'), 'not-integer')
  expectFail(parseMoneyInput('12.000'), 'not-integer')
  expectFail(parseMoneyInput('1,000.5'), 'not-integer')
})

test('parseMoneyInput: صفر، منفی و خالی', () => {
  expectFail(parseMoneyInput('0'), 'zero')
  expectFail(parseMoneyInput('۰'), 'zero')
  expectFail(parseMoneyInput('٠'), 'zero')
  expectFail(parseMoneyInput('-0'), 'zero')
  expectFail(parseMoneyInput('-5'), 'negative')
  expectFail(parseMoneyInput('−5'), 'negative') // علامت منفی یونیکد U+2212
  expectFail(parseMoneyInput(''), 'empty')
  expectFail(parseMoneyInput('   '), 'empty')
  expectFail(parseMoneyInput(null), 'empty')
  expectFail(parseMoneyInput(undefined), 'empty')
})

test('parseMoneyInput: نوع‌های غیررشته‌ای و غیرعددی رد می‌شن', () => {
  expectFail(parseMoneyInput({}), 'format')
  expectFail(parseMoneyInput([]), 'format')
  expectFail(parseMoneyInput(true), 'format')
})

test('parseMoneyInput: سقف MAX_TOMAN شاملِ خودِ سقفه', () => {
  expectOk(parseMoneyInput('10000000000000'), MAX_TOMAN)
  expectOk(parseMoneyInput('10,000,000,000,000'), MAX_TOMAN)
  expectFail(parseMoneyInput('10000000000001'), 'range')
  expectFail(parseMoneyInput('12345678901234567890'), 'range') // بالاتر از عدد صحیح امن
  expectFail(parseMoneyInput('1'.repeat(64)), 'range')
})

// ── parseMoneyInput: گزینه‌ها ─────────────────────────────────────────────────

test('parseMoneyInput: optional — خالی null می‌شه ولی مقدار نامعتبر همچنان خطاست', () => {
  expectOk(parseMoneyInput('', { optional: true }), null)
  expectOk(parseMoneyInput('  ', { optional: true }), null)
  expectOk(parseMoneyInput(null, { optional: true }), null)
  expectOk(parseMoneyInput('12,500', { optional: true }), 12500)
  expectFail(parseMoneyInput('abc', { optional: true }), 'format')
  expectFail(parseMoneyInput('0', { optional: true }), 'zero')
})

test('parseMoneyInput: allowZero و allowNegative', () => {
  expectOk(parseMoneyInput('0', { allowZero: true }), 0)
  expectOk(parseMoneyInput('-0', { allowZero: true }), 0)
  expectOk(parseMoneyInput('-5', { allowNegative: true }), -5)
  expectOk(parseMoneyInput('−5', { allowNegative: true }), -5)
  expectFail(parseMoneyInput('-5', { allowZero: true }), 'negative')
})

test('parseTomanInput: ورودی مالیات دستی { optional, allowZero } — خالی null، ۰ مجاز، منفی/اعشاری/بیش از سقف رد', () => {
  const tax = { label: 'مالیات', optional: true, allowZero: true } as const
  // خالی → null (واردنشده؛ در موتور ۰ حساب می‌شه)، نه خطا
  expectOk(parseTomanInput('', tax), null)
  expectOk(parseTomanInput('   ', tax), null)
  expectOk(parseTomanInput(null, tax), null)
  // صفر صریح مجازه و با خالی فرق داره (۰، نه null)
  expectOk(parseTomanInput('0', tax), 0)
  expectOk(parseTomanInput('٠', tax), 0)
  expectOk(parseTomanInput('۰', tax), 0)
  expectOk(parseTomanInput('-0', tax), 0)
  // ارقام فارسی و هزارگان
  expectOk(parseTomanInput('۵,۰۰۰', tax), 5000)
  expectOk(parseTomanInput('۵٬۰۰۰', tax), 5000)
  expectOk(parseTomanInput('1,250,000', tax), 1_250_000)
  expectOk(parseTomanInput(String(MAX_TOMAN), tax), MAX_TOMAN)
  // نامعتبر
  expectFail(parseTomanInput('-1', tax), 'negative')
  expectFail(parseTomanInput('1.5', tax), 'not-integer')
  expectFail(parseTomanInput('abc', tax), 'format')
  expectFail(parseTomanInput(String(MAX_TOMAN + 1), tax), 'range')
})

test('parseMoneyInput: max سفارشی', () => {
  expectOk(parseMoneyInput('100', { max: 100 }), 100)
  expectFail(parseMoneyInput('101', { max: 100 }), 'range')
})

test('parseMoneyInput: integerOnly=false با maxDecimals', () => {
  expectOk(parseMoneyInput('12.5', { integerOnly: false }), 12.5)
  expectOk(parseMoneyInput('12.50', { integerOnly: false }), 12.5)
  expectOk(parseMoneyInput('۱۲٫۵', { integerOnly: false }), 12.5)
  expectOk(parseMoneyInput('1,000.55', { integerOnly: false }), 1000.55)
  expectFail(parseMoneyInput('12.567', { integerOnly: false }), 'decimals')
  expectOk(parseMoneyInput('12.567', { integerOnly: false, maxDecimals: 3 }), 12.567)
})

test('parseMoneyInput: برچسب فیلد در پیام خطا می‌آد', () => {
  const r = parseMoneyInput('', { label: 'سقف قیمت' })
  assert.equal(r.ok, false)
  if (!r.ok) assert.ok(r.error.includes('سقف قیمت'))
})

test('parseTomanInput: هم‌نام parseMoneyInput', () => {
  assert.equal(parseTomanInput, parseMoneyInput)
})

// ── parseTonInput / parseKgInput / parseIntegerInput / parseDecimalInput ─────

test('parseTonInput: تا ۳ رقم اعشار (= کیلوی صحیح)، سقف پیش‌فرض ۱e6', () => {
  expectOk(parseTonInput('1.234'), 1.234)
  expectOk(parseTonInput('2'), 2)
  expectOk(parseTonInput('۲٫۵'), 2.5)
  expectOk(parseTonInput('1,000.5'), 1000.5)
  expectFail(parseTonInput('1.2345'), 'decimals')
  expectFail(parseTonInput('0'), 'zero')
  expectFail(parseTonInput('-1'), 'negative')
  expectFail(parseTonInput('1,5'), 'format')
  expectFail(parseTonInput(''), 'empty')
  expectOk(parseTonInput('1000000'), 1_000_000)
  expectFail(parseTonInput('1000001'), 'range')
  expectOk(parseTonInput('', { optional: true }), null)
})

test('parseKgInput: فقط صحیح، سقف ۱e9', () => {
  expectOk(parseKgInput('1000'), 1000)
  expectOk(parseKgInput('1,000'), 1000)
  expectFail(parseKgInput('12.5'), 'not-integer')
  expectOk(parseKgInput('1000000000'), 1e9)
  expectFail(parseKgInput('1000000001'), 'range')
  expectFail(parseKgInput('0'), 'zero')
})

test('parseIntegerInput: صحیح عمومی', () => {
  expectOk(parseIntegerInput('365'), 365)
  expectFail(parseIntegerInput('0'), 'zero')
  expectOk(parseIntegerInput('0', { allowZero: true }), 0)
  expectFail(parseIntegerInput('1.5'), 'not-integer')
  expectOk(parseIntegerInput('۳۶۵'), 365)
})

test('parseDecimalInput: اعشاری عمومی با حداکثر ۴ رقم', () => {
  expectOk(parseDecimalInput('12.3456'), 12.3456)
  expectOk(parseDecimalInput('0.5'), 0.5)
  expectFail(parseDecimalInput('12.34567'), 'decimals')
  expectFail(parseDecimalInput('1.234', { maxDecimals: 2 }), 'decimals')
  expectOk(parseDecimalInput('-1.5', { allowNegative: true }), -1.5)
  expectFail(parseDecimalInput('.5'), 'format')
})

// ── requireParsed / requireMoneyInput ────────────────────────────────────────

test('requireMoneyInput: مقدار معتبر را برمی‌گردونه', () => {
  assert.equal(requireMoneyInput('۱۲٬۵۰۰'), 12500)
  assert.equal(requireParsed(parseTonInput('2.5')), 2.5)
})

test('requireMoneyInput: ورودی نامعتبر MoneyInputError با کد و پیام فارسی پرتاب می‌کنه', () => {
  assert.throws(
    () => requireMoneyInput('abc', { label: 'سقف قیمت' }),
    (err: unknown) =>
      err instanceof MoneyInputError && err.code === 'format' && err.message.includes('سقف قیمت'),
  )
  assert.throws(
    () => requireMoneyInput('0'),
    (err: unknown) => err instanceof MoneyInputError && err.code === 'zero',
  )
})

// ── summarizeDeal: جمع کل معامله (فقط سمت خریدار) ────────────────────────────

const isCalcError = (err: unknown) => err instanceof MoneyCalcError

test('summarizeDeal: کالا + بیمه + مالیات خریدار ± تعدیل‌ها، با اعداد مشخص', () => {
  const s = summarizeDeal({
    unitPriceToman: 12500,
    weightKg: 2000,
    insuranceToman: 300_000,
    buyerTaxToman: 2_250_000,
    adjustments: [
      { amountToman: 1_000_000, direction: 'increase' },
      { amountToman: 400_000, direction: 'decrease' },
    ],
  })
  assert.equal(s.goodsTotal, 25_000_000)
  assert.equal(s.insurance, 300_000)
  assert.equal(s.buyerTax, 2_250_000)
  assert.equal(s.adjustmentsNet, 600_000)
  assert.equal(s.computedTotal, 25_000_000 + 300_000 + 2_250_000 + 600_000)
  assert.equal(s.displayTotal, s.computedTotal)
  assert.equal(s.overridden, false)
  assert.equal(s.difference, null)
})

test('summarizeDeal: کارمزد معامله و مالیات فروشنده در ورودی/خروجی/جمع نیستن', () => {
  const withExtra = summarizeDeal({
    unitPriceToman: 100,
    weightKg: 10,
    // فیلدهای فروشنده/کارمزد عمداً داده می‌شن؛ باید هیچ اثری نداشته باشن.
    ...({ dealFeeToman: 999_999, sellerTaxToman: 888_888 } as object),
  })
  assert.equal(withExtra.computedTotal, 1000)
  assert.deepEqual(Object.keys(withExtra).sort(), [
    'adjustmentsNet',
    'buyerTax',
    'computedTotal',
    'difference',
    'displayTotal',
    'goodsTotal',
    'insurance',
    'overridden',
  ])
})

test('summarizeDeal: قیمت یا وزن ثبت‌نشده ⇒ جمع null (نه عدد ساختگی)', () => {
  for (const input of [
    { unitPriceToman: null, weightKg: 1000 },
    { unitPriceToman: 100, weightKg: null },
    { unitPriceToman: null, weightKg: null },
  ]) {
    const s = summarizeDeal({ ...input, insuranceToman: 500, buyerTaxToman: 700 })
    assert.equal(s.goodsTotal, null)
    assert.equal(s.computedTotal, null)
    assert.equal(s.displayTotal, null)
    assert.equal(s.difference, null)
    // بیمه و مالیات خودشون عدد می‌مونن (نمایش جداگانه)؛ فقط جمع کل غیرقابل‌محاسبه‌ست.
    assert.equal(s.insurance, 500)
    assert.equal(s.buyerTax, 700)
  }
})

test('summarizeDeal: null/undefined/غایب = ۰ و هیچ NaN ای در خروجی نیست', () => {
  const variants = [
    { unitPriceToman: 10, weightKg: 5 },
    { unitPriceToman: 10, weightKg: 5, insuranceToman: null, buyerTaxToman: null },
    { unitPriceToman: 10, weightKg: 5, insuranceToman: undefined, buyerTaxToman: undefined, adjustments: [] },
    { unitPriceToman: 10, weightKg: 5, insuranceToman: 0, buyerTaxToman: 0, overrideToman: null },
  ]
  for (const v of variants) {
    const s = summarizeDeal(v)
    assert.equal(s.computedTotal, 50)
    for (const value of Object.values(s)) {
      if (typeof value === 'number') assert.equal(Number.isNaN(value), false)
    }
  }
})

test('summarizeDeal: قیمت واحد ذخیره‌شده‌ی اعشاری مرزی گرد می‌شه (half-up) و بعد ضرب', () => {
  assert.equal(summarizeDeal({ unitPriceToman: 100.4, weightKg: 10 }).goodsTotal, 1000)
  assert.equal(summarizeDeal({ unitPriceToman: 100.5, weightKg: 10 }).goodsTotal, 1010)
  assert.equal(summarizeDeal({ unitPriceToman: 0, weightKg: 10 }).goodsTotal, 0)
})

test('summarizeDeal: تعدیل‌ها — فقط افزایش، فقط کاهش، و ترتیبِ بی‌اثر', () => {
  const base = { unitPriceToman: 1000, weightKg: 1000 }
  const inc = { amountToman: 300, direction: 'increase' as const }
  const dec = { amountToman: 100, direction: 'decrease' as const }
  assert.equal(summarizeDeal({ ...base, adjustments: [inc] }).computedTotal, 1_000_300)
  assert.equal(summarizeDeal({ ...base, adjustments: [dec] }).computedTotal, 999_900)
  const a = summarizeDeal({ ...base, adjustments: [inc, dec, dec] })
  const b = summarizeDeal({ ...base, adjustments: [dec, inc, dec] })
  assert.deepEqual(a, b)
  assert.equal(a.adjustmentsNet, 100)
})

test('summarizeDeal: جمع تعدیل‌ها می‌تونه منفی باشه ولی جمع کل نه', () => {
  const base = { unitPriceToman: 1, weightKg: 100 }
  const s = summarizeDeal({ ...base, adjustments: [{ amountToman: 60, direction: 'decrease' }] })
  assert.equal(s.adjustmentsNet, -60)
  assert.equal(s.computedTotal, 40)
  assert.equal(
    summarizeDeal({ ...base, adjustments: [{ amountToman: 100, direction: 'decrease' }] }).computedTotal,
    0,
  )
  assert.throws(
    () => summarizeDeal({ ...base, adjustments: [{ amountToman: 101, direction: 'decrease' }] }),
    isCalcError,
  )
})

test('summarizeDeal: override جایگزین نمایش می‌شه، تعدیل‌ها روش اثر ندارن، اختلاف محاسبه می‌شه', () => {
  const input = {
    unitPriceToman: 1000,
    weightKg: 1000,
    adjustments: [{ amountToman: 500, direction: 'increase' as const }],
  }
  assert.equal(summarizeDeal(input).computedTotal, 1_000_500)
  const s = summarizeDeal({ ...input, overrideToman: 1_200_000 })
  assert.equal(s.computedTotal, 1_000_500)
  assert.equal(s.displayTotal, 1_200_000)
  assert.equal(s.overridden, true)
  assert.equal(s.difference, 199_500)
  // با یک تعدیل دیگه، computedTotal عوض می‌شه ولی عدد نمایشی ثابت می‌مونه.
  const s2 = summarizeDeal({
    ...input,
    adjustments: [...input.adjustments, { amountToman: 50, direction: 'increase' }],
    overrideToman: 1_200_000,
  })
  assert.equal(s2.displayTotal, 1_200_000)
  assert.equal(s2.difference, 1_200_000 - 1_000_550)
  // اختلاف می‌تونه منفی باشه.
  assert.equal(summarizeDeal({ ...input, overrideToman: 900_000 }).difference, -100_500)
})

test('summarizeDeal: override وقتی جمع محاسبه‌شده نیست — نمایش override، اختلاف null', () => {
  const s = summarizeDeal({ unitPriceToman: 100, weightKg: null, overrideToman: 5000 })
  assert.equal(s.computedTotal, null)
  assert.equal(s.displayTotal, 5000)
  assert.equal(s.overridden, true)
  assert.equal(s.difference, null)
})

test('summarizeDeal: ورودی نامعتبر (NaN، منفی، اعشاری، Infinity، بیش از سقف) MoneyCalcError می‌ده', () => {
  const ok = { unitPriceToman: 10, weightKg: 10 }
  const bad = [Number.NaN, -1, 1.5, Number.POSITIVE_INFINITY, MAX_TOMAN + 1]
  for (const value of bad) {
    assert.throws(() => summarizeDeal({ ...ok, insuranceToman: value }), isCalcError, `insurance=${value}`)
    assert.throws(() => summarizeDeal({ ...ok, buyerTaxToman: value }), isCalcError, `buyerTax=${value}`)
    assert.throws(() => summarizeDeal({ ...ok, overrideToman: value }), isCalcError, `override=${value}`)
    assert.throws(
      () => summarizeDeal({ ...ok, adjustments: [{ amountToman: value, direction: 'increase' }] }),
      isCalcError,
      `adjustment=${value}`,
    )
  }
  assert.throws(() => summarizeDeal({ unitPriceToman: -1, weightKg: 10 }), isCalcError)
  assert.throws(() => summarizeDeal({ unitPriceToman: Number.NaN, weightKg: 10 }), isCalcError)
  assert.throws(() => summarizeDeal({ unitPriceToman: 10, weightKg: -5 }), isCalcError)
  assert.throws(() => summarizeDeal({ unitPriceToman: 10, weightKg: 1.5 }), isCalcError)
  assert.throws(() => summarizeDeal({ unitPriceToman: 10, weightKg: Number.NaN }), isCalcError)
})

test('summarizeDeal: ردیف تعدیلِ صفر یا جهت نامعتبر رد می‌شه', () => {
  const ok = { unitPriceToman: 10, weightKg: 10 }
  assert.throws(() => summarizeDeal({ ...ok, adjustments: [{ amountToman: 0, direction: 'increase' }] }), isCalcError)
  assert.throws(
    () => summarizeDeal({ ...ok, adjustments: [{ amountToman: 5, direction: 'sideways' as never }] }),
    isCalcError,
  )
})

test('summarizeDeal: سقف روی کالا، تعدیل‌ها و جمع کل اعمال می‌شه', () => {
  // کالا
  assert.throws(() => summarizeDeal({ unitPriceToman: MAX_TOMAN, weightKg: 2 }), isCalcError)
  // جمع افزایش‌ها از سقف رد می‌شه حتی اگه هر ردیف تنها مجاز باشه
  assert.throws(
    () =>
      summarizeDeal({
        unitPriceToman: 1,
        weightKg: 1,
        adjustments: [
          { amountToman: MAX_TOMAN, direction: 'increase' },
          { amountToman: 1, direction: 'increase' },
        ],
      }),
    isCalcError,
  )
  // جمع کل: کالا در سقف + ۱ تومان بیمه
  assert.throws(() => summarizeDeal({ unitPriceToman: MAX_TOMAN, weightKg: 1, insuranceToman: 1 }), isCalcError)
  // دقیقاً روی سقف مجازه
  assert.equal(summarizeDeal({ unitPriceToman: MAX_TOMAN, weightKg: 1 }).computedTotal, MAX_TOMAN)
})

test('summarizeDeal: کاهش‌های بزرگ می‌تونن افزایش‌های بزرگ رو خنثی کنن (بدون سرریز کاذب)', () => {
  const s = summarizeDeal({
    unitPriceToman: 1,
    weightKg: 10,
    adjustments: [
      { amountToman: MAX_TOMAN, direction: 'increase' },
      { amountToman: MAX_TOMAN, direction: 'decrease' },
    ],
  })
  assert.equal(s.adjustmentsNet, 0)
  assert.equal(s.computedTotal, 10)
})

test('summarizeDeal: جزءها همیشه با جمع کل می‌خونن (۲۰۰۰ ورودی تصادفیِ قطعی)', () => {
  const rand = mulberry32(20261004)
  const int = (max: number) => Math.floor(rand() * (max + 1))
  for (let i = 0; i < 2000; i++) {
    const adjustments = Array.from({ length: int(4) }, () => ({
      amountToman: 1 + int(50_000),
      direction: (rand() < 0.5 ? 'increase' : 'decrease') as 'increase' | 'decrease',
    }))
    const input = {
      unitPriceToman: int(2_000_000),
      weightKg: int(40_000),
      insuranceToman: rand() < 0.3 ? null : int(5_000_000),
      buyerTaxToman: rand() < 0.3 ? null : int(5_000_000),
      adjustments,
    }
    const goods = input.unitPriceToman * input.weightKg
    const net = adjustments.reduce((a, x) => a + (x.direction === 'increase' ? x.amountToman : -x.amountToman), 0)
    const expected = goods + (input.insuranceToman ?? 0) + (input.buyerTaxToman ?? 0) + net
    if (expected < 0) {
      // تنها خطای مجاز: جمع کل منفی (کاهش بزرگ‌تر از جمع)
      assert.throws(() => summarizeDeal(input), isCalcError)
      continue
    }
    const s = summarizeDeal(input)
    assert.equal(s.goodsTotal, goods)
    assert.equal(s.adjustmentsNet, net)
    assert.equal(s.computedTotal, expected)
    assert.ok(Number.isSafeInteger(expected))
  }
})

test('trySummarizeDeal: داده‌ی خراب ⇒ null؛ داده‌ی سالم ⇒ همان summarizeDeal', () => {
  const ok = { unitPriceToman: 10, weightKg: 10, buyerTaxToman: 5 }
  assert.deepEqual(trySummarizeDeal(ok), summarizeDeal(ok))
  assert.equal(trySummarizeDeal({ ...ok, insuranceToman: -1 }), null)
  assert.equal(trySummarizeDeal({ unitPriceToman: Number.NaN, weightKg: 10 }), null)
})

// ── مبلغ تایید معامله (سقف تایید روی «جمع کالا»، نه قیمت واحد) ─────────────────

test('dealApprovalAmountToman: 12,500 تومان/کیلو × 1000 کیلو = 12,500,000', () => {
  assert.equal(dealApprovalAmountToman({ agreedPrice: 12500, weightKg: 1000, listedTon: null }), 12_500_000)
})

test('dealApprovalAmountToman: بدون weightKg، وزن از تنِ آگهی می‌آد (۲٫۵ تن → ۲۵۰۰ کیلو)', () => {
  assert.equal(dealApprovalAmountToman({ agreedPrice: 100, weightKg: null, listedTon: 2.5 }), 250_000)
  assert.equal(dealApprovalAmountToman({ agreedPrice: 100, weightKg: undefined, listedTon: 2.5 }), 250_000)
})

test('dealApprovalAmountToman: weightKg ثبت‌شده بر تنِ آگهی مقدمه', () => {
  assert.equal(dealApprovalAmountToman({ agreedPrice: 100, weightKg: 500, listedTon: 2.5 }), 50_000)
})

test('dealApprovalAmountToman: قیمت ثبت‌نشده ⇒ null (حتی بدون وزن)', () => {
  assert.equal(dealApprovalAmountToman({ agreedPrice: null, weightKg: 1000, listedTon: 1 }), null)
  assert.equal(dealApprovalAmountToman({ agreedPrice: undefined, weightKg: null, listedTon: null }), null)
})

test('dealApprovalAmountToman: قیمت صفر ⇒ ۰ (بدون نیاز به وزن)', () => {
  assert.equal(dealApprovalAmountToman({ agreedPrice: 0, weightKg: null, listedTon: null }), 0)
  assert.equal(dealApprovalAmountToman({ agreedPrice: 0, weightKg: 1000, listedTon: null }), 0)
})

test('dealApprovalAmountToman: قیمت هست ولی وزن از هیچ منبعی نیست ⇒ MoneyCalcError (fail-closed)', () => {
  assert.throws(
    () => dealApprovalAmountToman({ agreedPrice: 100, weightKg: null, listedTon: null }),
    MoneyCalcError,
  )
  assert.throws(
    () => dealApprovalAmountToman({ agreedPrice: 100, weightKg: undefined, listedTon: undefined }),
    MoneyCalcError,
  )
})

test('dealApprovalAmountToman: وزنِ صفر یا کمتر از ۱ کیلو «وزنِ نبود» حساب می‌شه، نه مبلغِ صفر', () => {
  assert.throws(() => dealApprovalAmountToman({ agreedPrice: 100, weightKg: 0, listedTon: 5 }), MoneyCalcError)
  assert.throws(() => dealApprovalAmountToman({ agreedPrice: 100, weightKg: null, listedTon: 0 }), MoneyCalcError)
  assert.throws(() => dealApprovalAmountToman({ agreedPrice: 100, weightKg: null, listedTon: 0.0004 }), MoneyCalcError)
})

test('dealApprovalAmountToman: ورودی نامعتبر (NaN، منفی، اعشاری، Infinity) MoneyCalcError می‌ده', () => {
  const bad = [Number.NaN, -1, Number.POSITIVE_INFINITY]
  for (const agreedPrice of bad) {
    assert.throws(() => dealApprovalAmountToman({ agreedPrice, weightKg: 10, listedTon: null }), MoneyCalcError)
  }
  for (const weightKg of [...bad, 1.5]) {
    assert.throws(() => dealApprovalAmountToman({ agreedPrice: 10, weightKg, listedTon: null }), MoneyCalcError)
  }
  for (const listedTon of bad) {
    assert.throws(() => dealApprovalAmountToman({ agreedPrice: 10, weightKg: null, listedTon }), MoneyCalcError)
  }
})

test('dealApprovalAmountToman: سقف MAX_TOMAN — خودِ سقف مجازه، یک تومان بیشتر و قیمتِ بیش از سقف رد می‌شه', () => {
  assert.equal(dealApprovalAmountToman({ agreedPrice: MAX_TOMAN, weightKg: 1, listedTon: null }), MAX_TOMAN)
  assert.throws(() => dealApprovalAmountToman({ agreedPrice: MAX_TOMAN, weightKg: 2, listedTon: null }), MoneyCalcError)
  assert.throws(() => dealApprovalAmountToman({ agreedPrice: MAX_TOMAN + 1, weightKg: 1, listedTon: null }), MoneyCalcError)
})

test('ریگرسیون C9: 50,000 تومان/کیلو × ۵ تن = 250,000,000 — نه قیمت واحد 50,000', () => {
  const total = dealApprovalAmountToman({ agreedPrice: 50_000, weightKg: null, listedTon: 5 })
  assert.equal(total, 250_000_000)
  assert.notEqual(total, 50_000)
})
