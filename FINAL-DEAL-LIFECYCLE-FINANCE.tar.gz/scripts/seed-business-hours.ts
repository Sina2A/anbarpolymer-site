/**
 * پر کردن جدول WeeklyBusinessHour (ساعت کاریِ هفتگی) — لازم برای محاسبه‌ی مهلت‌های ساعت‌کاری.
 *
 * چرا لازمه: موتور مهلت (src/lib/businessHours.ts) روزِ بدون ردیف را «بسته» حساب می‌کنه. جدول خالی یعنی هیچ
 * روزی باز نیست و هر محاسبه‌ی مهلت بعد از ۴۰۰ تکرار با خطای بلند شکست می‌خوره. پس این seed باید قبل از deployِ
 * نسخه‌ای که این رفتار را دارد، روی هر دیتابیس اجرا شده باشد.
 *
 * اجرا (از ریشه‌ی پروژه؛ DATABASE_URL از .env خوانده می‌شه و هرگز چاپ نمی‌شه، فقط host و نام دیتابیس):
 *   npx tsx scripts/seed-business-hours.ts status                              (فقط‌خواندنی)
 *   npx tsx scripts/seed-business-hours.ts seed [--apply] [--allow-remote]
 *
 * الگوی پیش‌فرض (شماره‌ی روز مثل getDay(): ۰=یکشنبه … ۶=شنبه):
 *   باز، ۰۸:۰۰ تا ۱۷:۰۰: شنبه(۶)، یکشنبه(۰)، دوشنبه(۱)، سه‌شنبه(۲)، چهارشنبه(۳)
 *   بسته: پنجشنبه(۴)، جمعه(۵)
 *
 * ایمنی:
 *  - seed پیش‌فرض dry-run است (هیچ اتصالی به دیتابیس نمی‌گیره) و فقط با --apply می‌نویسه.
 *  - host غیرمحلی فقط با --allow-remote. عمداً مانع NODE_ENV=production نیست (این seed برای production هم لازمه).
 *  - فقط ردیف‌های «موجود‌نبوده» ساخته می‌شن؛ ردیفی که ادمین از پنل تنظیم کرده هرگز عوض نمی‌شه.
 *  - status فقط می‌شمره و می‌خونه: تعداد WeeklyBusinessHour و Holiday و وضعیت هر روز.
 *
 * این فایل عمداً Prisma client خودش را می‌سازه و هیچ فایل 'use server' یا src/lib/prisma.ts را import نمی‌کنه.
 */
import { config } from 'dotenv'
import { PrismaClient } from '@prisma/client'
import { PrismaPg } from '@prisma/adapter-pg'

config({ quiet: true })

type DayRow = { dayOfWeek: number; label: string; isOpen: boolean; openTime: string; closeTime: string }

const OPEN_TIME = '08:00'
const CLOSE_TIME = '17:00'
const OPEN_DAYS = new Set([6, 0, 1, 2, 3])
// ترتیب برچسب‌ها = شماره‌ی روز (۰=یکشنبه … ۶=شنبه)، هم‌ترتیب با DAY_LABELS_FA در src/lib/businessHours.ts
const DAY_LABELS = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه']

const PLAN: DayRow[] = DAY_LABELS.map((label, dayOfWeek) => ({
  dayOfWeek,
  label,
  isOpen: OPEN_DAYS.has(dayOfWeek),
  openTime: OPEN_TIME,
  closeTime: CLOSE_TIME,
}))

const USAGE = [
  'استفاده:',
  '  npx tsx scripts/seed-business-hours.ts status',
  '  npx tsx scripts/seed-business-hours.ts seed [--apply] [--allow-remote]',
].join('\n')

/** فقط host و نام دیتابیس (بدون کاربر/رمز). null یعنی DATABASE_URL قابل‌خواندن نیست. */
function describeTarget(connectionString: string): { label: string; isLocal: boolean } | null {
  try {
    const url = new URL(connectionString)
    const isLocal = ['localhost', '127.0.0.1', '::1', '[::1]'].includes(url.hostname)
    return { label: `${url.hostname}${url.pathname}`, isLocal }
  } catch {
    return null
  }
}

function describeDay(row: { isOpen: boolean; openTime: string; closeTime: string }): string {
  return row.isOpen ? `باز ${row.openTime}–${row.closeTime}` : 'بسته'
}

async function runStatus(prisma: PrismaClient): Promise<void> {
  const [weekly, holidayCount] = await Promise.all([
    prisma.weeklyBusinessHour.findMany({ orderBy: { dayOfWeek: 'asc' } }),
    prisma.holiday.count(),
  ])
  const byDay = new Map(weekly.map((r) => [r.dayOfWeek, r]))
  console.log(`WeeklyBusinessHour: ${weekly.length} ردیف از ۷ | Holiday: ${holidayCount} ردیف`)
  for (const day of PLAN) {
    const row = byDay.get(day.dayOfWeek)
    console.log(`  ${day.dayOfWeek} ${day.label}: ${row ? describeDay(row) : 'ردیف ندارد ← بسته حساب می‌شود'}`)
  }
  const openCount = weekly.filter((r) => r.isOpen).length
  if (openCount === 0) {
    console.log('هشدار: هیچ روز بازی نیست؛ محاسبه‌ی مهلت ساعت‌کاری خطای بلند می‌دهد. seed را با --apply اجرا کنید.')
  }
}

async function runSeed(prisma: PrismaClient): Promise<void> {
  const existing = await prisma.weeklyBusinessHour.findMany({ select: { dayOfWeek: true } })
  const have = new Set(existing.map((r) => r.dayOfWeek))
  const missing = PLAN.filter((d) => !have.has(d.dayOfWeek))
  if (missing.length === 0) {
    console.log('هر ۷ ردیف از قبل هست؛ چیزی ساخته نشد و هیچ ردیفی تغییر نکرد.')
    return
  }
  // skipDuplicates: اگر بین خواندن و نوشتن ردیفی ساخته شد، به‌جای خطا نادیده گرفته می‌شود.
  const result = await prisma.weeklyBusinessHour.createMany({
    data: missing.map(({ dayOfWeek, isOpen, openTime, closeTime }) => ({ dayOfWeek, isOpen, openTime, closeTime })),
    skipDuplicates: true,
  })
  console.log(`${result.count} ردیف ساخته شد:`)
  for (const d of missing) console.log(`  ${d.dayOfWeek} ${d.label}: ${describeDay(d)}`)
  if (existing.length > 0) console.log(`${existing.length} ردیف موجود دست‌نخورده ماند.`)
}

async function main(): Promise<void> {
  const args = process.argv.slice(2)
  const command = args[0]
  const flags = args.slice(1)
  const allowedFlags = command === 'seed' ? ['--apply', '--allow-remote'] : []
  if ((command !== 'status' && command !== 'seed') || flags.some((f) => !allowedFlags.includes(f))) {
    console.error(USAGE)
    process.exitCode = 1
    return
  }
  const apply = flags.includes('--apply')

  if (command === 'seed' && !apply) {
    console.log('dry-run: seed این ردیف‌ها را (فقط برای روزهای بدون ردیف) می‌ساخت. برای اجرا --apply.')
    for (const d of PLAN) console.log(`  ${d.dayOfWeek} ${d.label}: ${describeDay(d)}`)
    return
  }

  const connectionString = process.env.DATABASE_URL
  if (!connectionString) {
    console.error('DATABASE_URL تنظیم نشده (در .env یا محیط).')
    process.exitCode = 1
    return
  }
  const target = describeTarget(connectionString)
  if (!target) {
    console.error('DATABASE_URL قابل‌خواندن نیست.')
    process.exitCode = 1
    return
  }
  if (command === 'seed' && !target.isLocal && !flags.includes('--allow-remote')) {
    console.error(`هدف ${target.label} محلی نیست. برای نوشتن روی دیتابیس راه‌دور --allow-remote را اضافه کنید.`)
    process.exitCode = 1
    return
  }
  console.log(`هدف: ${target.label}`)

  const prisma = new PrismaClient({ adapter: new PrismaPg({ connectionString }) })
  try {
    if (command === 'seed') await runSeed(prisma)
    else await runStatus(prisma)
  } finally {
    await prisma.$disconnect()
  }
}

main().catch((error: unknown) => {
  const code = (error as { code?: unknown } | null)?.code
  console.error('خطا:', typeof code === 'string' ? `کد ${code}` : error instanceof Error ? error.message : String(error))
  process.exitCode = 1
})
