/**
 * Seed داده‌ی تست برای سناریوهای دستی چرخه‌ی معامله (۳، ۴ و ۵) — فقط برای دیتابیس تست/توسعه.
 *
 * اجرا (از ریشه‌ی پروژه؛ DATABASE_URL از .env خوانده می‌شه و هرگز چاپ نمی‌شه، فقط host و نام دیتابیس):
 *   npx tsx scripts/seed-deal-lifecycle.ts seed [3|4|5|all] [--apply] [--allow-remote]
 *   npx tsx scripts/seed-deal-lifecycle.ts verify [3|4|5|all]
 *   npx tsx scripts/seed-deal-lifecycle.ts cleanup [--apply] [--allow-remote]
 *
 * سناریو ۳ (ساعت کارمزد آگهی): آگهی reserved با کارمزد پرداخت‌نشده و feeDeadline گذشته + یک Deal پیش‌نویس.
 *   بعد از اجرای مهلت‌ها (صفحه‌ی /admin-deals ← اجرای دستی، یا باز کردن بازار/پنل) انتظار می‌ره:
 *   آگهی ← needs_reverification، Deal ← cancelled، فروشنده محدود بشه.
 * سناریو ۴ (لینک راننده): Deal در transport_pending با escrow=secured_manual و دو پرداخت تاییدشده + لینک راننده.
 *   با همان یک لینک: پذیرش ← بارگیری ← تخلیه. انتظار می‌ره لینک تا تخلیه زنده بمونه و فقط با تخلیه مصرف بشه.
 * سناریو ۵ (T0 کهنه + T1 زنده): آگهی reserved با feeDeadline گذشته (T0) + Deal در confirmed با sellerFeeDeadline آینده (T1).
 *   بعد از اجرای مهلت‌ها انتظار می‌ره: Deal لغو نشه، فروشنده محدود نشه، آگهی reserved بمونه و فقط feeDeadline آگهی پاک بشه.
 *   فروشنده‌ی این سناریو جدا از سناریو ۳ است تا محدودسازیِ سناریو ۳ نتیجه‌ی این یکی را قاطی نکند.
 *
 * ایمنی:
 *  - seed و cleanup پیش‌فرض dry-run‌اند (هیچ اتصالی به دیتابیس نمی‌گیرن) و فقط با --apply می‌نویسن.
 *  - وقتی NODE_ENV=production باشه هر دستور نوشتن رد می‌شه. host غیرمحلی هم فقط با --allow-remote.
 *  - همه‌ی رکوردها با پیشوند id «seed-lc-» ساخته می‌شن؛ cleanup فقط همین پیشوند را پاک می‌کنه.
 *  - کاربرها passwordHash غیرقابل‌ورود دارن و phone/email ندارن (پیامکی به شماره‌ی واقعی نمی‌ره).
 *  - ستون‌های مالی (Deal.agreedPrice، DealPayment.amount، ...) عمداً null می‌مونن تا تاریخچه‌ی مالی
 *    (financial-history verify) دچار drift نشه.
 *  - اجرای دوباره‌ی seed همان سناریو را از نو می‌سازه (ریست)، حتی بعد از تست.
 *
 * این فایل عمداً Prisma client خودش را می‌سازه و هیچ فایل 'use server' یا src/lib/prisma.ts را import نمی‌کنه.
 */
import { config } from 'dotenv'
import crypto from 'crypto'
import { PrismaClient, type Prisma } from '@prisma/client'
import { PrismaPg } from '@prisma/adapter-pg'

config({ quiet: true })

const PREFIX = 'seed-lc-'
const ID = {
  seller: `${PREFIX}seller`,
  seller5: `${PREFIX}seller5`,
  buyer: `${PREFIX}buyer`,
  company: `${PREFIX}transport`,
  grade: `${PREFIX}grade`,
  s3: { listing: `${PREFIX}s3-listing`, deal: `${PREFIX}s3-deal` },
  s4: { listing: `${PREFIX}s4-listing`, deal: `${PREFIX}s4-deal`, link: `${PREFIX}s4-link` },
  s5: { listing: `${PREFIX}s5-listing`, deal: `${PREFIX}s5-deal` },
} as const

type Scenario = '3' | '4' | '5'
const COMMANDS = ['seed', 'verify', 'cleanup']
const SCENARIO_ARGS = ['3', '4', '5', 'all']

const USAGE = [
  'استفاده:',
  '  npx tsx scripts/seed-deal-lifecycle.ts seed [3|4|5|all] [--apply] [--allow-remote]',
  '  npx tsx scripts/seed-deal-lifecycle.ts verify [3|4|5|all]',
  '  npx tsx scripts/seed-deal-lifecycle.ts cleanup [--apply] [--allow-remote]',
].join('\n')

const HOUR_MS = 60 * 60 * 1000

function scenarioList(arg: string | undefined): Scenario[] {
  if (arg === '3') return ['3']
  if (arg === '4') return ['4']
  if (arg === '5') return ['5']
  return ['3', '4', '5']
}

/** فقط host و نام دیتابیس (بدون کاربر/رمز). null یعنی DATABASE_URL قابل‌خواندن نیست. */
function describeTarget(connectionString: string): { label: string; isLocal: boolean } | null {
  try {
    const url = new URL(connectionString)
    const isLocal = ['localhost', '127.0.0.1', '::1', '[::1]'].includes(url.hostname)
    return { label: `${url.hostname}${url.pathname}`, isLocal }
  } catch {
    return null
  }
}

/** خطای Prisma را بدون جزئیات کوئری چاپ می‌کنه (فقط کد). */
function errorCode(error: unknown): string {
  const code = (error as { code?: unknown } | null)?.code
  return typeof code === 'string' ? code : 'unknown'
}

/** کاربرها، شرکت حمل و گرید مشترک بین سناریوها. فروشنده‌ی محدودشده در اجرای قبلی آزاد می‌شه. */
async function ensureBase(tx: Prisma.TransactionClient): Promise<void> {
  await tx.grade.upsert({
    where: { id: ID.grade },
    update: {},
    create: { id: ID.grade, code: 'SEED-LC', producer: '[SEED] تست', category: '[SEED] تست' },
  })
  const users = [
    { id: ID.seller, username: 'seed_lc_seller', companyName: '[SEED] فروشنده‌ی تست' },
    { id: ID.seller5, username: 'seed_lc_seller5', companyName: '[SEED] فروشنده‌ی سناریو ۵' },
    { id: ID.buyer, username: 'seed_lc_buyer', companyName: '[SEED] خریدار تست' },
  ]
  for (const u of users) {
    await tx.user.upsert({
      where: { id: u.id },
      update: { restrictedUntil: null, restrictionReason: null },
      // passwordHash بدون «:» هیچ‌وقت با verifyPassword (src/lib/auth.ts) مطابقت نمی‌کنه ⇒ ورود ممکن نیست.
      create: { ...u, passwordHash: '!seed-no-login', role: 'buyer' },
    })
  }
  await tx.transportCompany.upsert({
    where: { id: ID.company },
    update: {},
    create: { id: ID.company, name: '[SEED] شرکت حمل تست' },
  })
}

/** رکوردهای یک سناریو را پاک می‌کنه (Deal ← وابسته‌ها ← آگهی). deleteMany است، پس برای رکورد نبوده خطا نمی‌ده. */
async function deleteScenarioRecords(tx: Prisma.TransactionClient, dealIds: string[], listingIds: string[]) {
  await tx.dealConfirmation.deleteMany({ where: { dealId: { in: dealIds } } })
  await tx.driverAccessLink.deleteMany({ where: { dealId: { in: dealIds } } })
  await tx.dealPayment.deleteMany({ where: { dealId: { in: dealIds } } })
  await tx.dealDriverAssignment.deleteMany({ where: { dealId: { in: dealIds } } })
  await tx.deal.deleteMany({ where: { id: { in: dealIds } } })
  await tx.materialListing.deleteMany({ where: { id: { in: listingIds } } })
}

function listingData(
  id: string,
  extra: Pick<Prisma.MaterialListingUncheckedCreateInput, 'feeDeadline'>,
  userId: string = ID.seller
) {
  return {
    id,
    userId,
    gradeId: ID.grade,
    quantityTon: 10,
    province: 'تهران',
    city: 'تهران',
    packagingType: 'seed',
    packagingQuality: 'seed',
    materialQuality: 'seed',
    askingPriceToman: 0,
    validityStatus: 'reserved',
    feeStatus: 'unpaid',
    weighbridgeTicketUrl: '/seed/none',
    weighbridgeNetWeightKg: 10000,
    weighbridgeDate: new Date(),
    ...extra,
  }
}

async function seedScenario3(tx: Prisma.TransactionClient): Promise<string[]> {
  await deleteScenarioRecords(tx, [ID.s3.deal], [ID.s3.listing])
  await tx.materialListing.create({
    data: listingData(ID.s3.listing, { feeDeadline: new Date(Date.now() - HOUR_MS) }),
  })
  await tx.deal.create({
    data: {
      id: ID.s3.deal,
      buyerId: ID.buyer,
      sellerId: ID.seller,
      requesterId: ID.seller,
      acceptorId: ID.buyer,
      tradeDirection: 'SELL',
      materialListingId: ID.s3.listing,
      quantity: '10 تن',
      status: 'draft',
      payments: {
        create: [
          { kind: 'BUYER_GOODS', status: 'PENDING' },
          { kind: 'SELLER_FEE', status: 'PENDING' },
        ],
      },
    },
  })
  return [
    'سناریو ۳: آگهی reserved با feeDeadline یک ساعت پیش + Deal پیش‌نویس با SELLER_FEE در انتظار.',
    '  اجرا: /admin-deals ← «اجرای دستی» مهلت‌ها (یا باز کردن بازار/پنل).',
    '  انتظار: آگهی needs_reverification، Deal cancelled، فروشنده محدود. بعد: verify 3',
  ]
}

async function seedScenario4(tx: Prisma.TransactionClient): Promise<string[]> {
  await deleteScenarioRecords(tx, [ID.s4.deal], [ID.s4.listing])
  await tx.materialListing.create({ data: listingData(ID.s4.listing, { feeDeadline: null }) })
  const token = crypto.randomBytes(24).toString('hex')
  const now = new Date()
  await tx.deal.create({
    data: {
      id: ID.s4.deal,
      buyerId: ID.buyer,
      sellerId: ID.seller,
      requesterId: ID.seller,
      acceptorId: ID.buyer,
      tradeDirection: 'SELL',
      materialListingId: ID.s4.listing,
      transportCompanyId: ID.company,
      quantity: '10 تن',
      status: 'transport_pending',
      escrowStatus: 'secured_manual',
      escrowConfirmedAt: now,
      payments: {
        create: [
          { kind: 'BUYER_GOODS', status: 'APPROVED', reviewedAt: now },
          { kind: 'SELLER_FEE', status: 'APPROVED', reviewedAt: now },
        ],
      },
    },
  })
  await tx.driverAccessLink.create({
    data: { id: ID.s4.link, dealId: ID.s4.deal, token, phone: '00000000000', expiresAt: new Date(Date.now() + 48 * HOUR_MS) },
  })
  return [
    'سناریو ۴: Deal در transport_pending، escrow=secured_manual، هر دو پرداخت APPROVED، لینک راننده ۴۸ساعته.',
    `  لینک سفر (به origin سایت بچسبانید؛ فقط برای همین Deal تستی معتبر است): /driver/t/${token}`,
    '  مراحل: پذیرش در همان صفحه ← بارگیری در /driver/<token> ← تخلیه با همان لینک. بعد: verify 4',
    '  انتظار: بعد از پذیرش و بعد از بارگیری لینک مصرف نشود؛ فقط بعد از تخلیه مصرف شود؛ Deal ← delivered.',
  ]
}

async function seedScenario5(tx: Prisma.TransactionClient): Promise<string[]> {
  await deleteScenarioRecords(tx, [ID.s5.deal], [ID.s5.listing])
  // T0 (آگهی) یک ساعت پیش پر شده؛ T1 (Deal) ۲۴ ساعت دیگر. کارمزد هنوز تایید نشده، پس فقط ساعتِ کهنه‌ی آگهی باید پاک شود.
  await tx.materialListing.create({
    data: listingData(ID.s5.listing, { feeDeadline: new Date(Date.now() - HOUR_MS) }, ID.seller5),
  })
  await tx.deal.create({
    data: {
      id: ID.s5.deal,
      buyerId: ID.buyer,
      sellerId: ID.seller5,
      requesterId: ID.seller5,
      acceptorId: ID.buyer,
      tradeDirection: 'SELL',
      materialListingId: ID.s5.listing,
      quantity: '10 تن',
      status: 'confirmed',
      sellerFeeDeadline: new Date(Date.now() + 24 * HOUR_MS),
      buyerConfirmDeadline: new Date(Date.now() + 48 * HOUR_MS),
      payments: {
        create: [
          { kind: 'BUYER_GOODS', status: 'PENDING' },
          { kind: 'SELLER_FEE', status: 'PENDING' },
        ],
      },
    },
  })
  return [
    'سناریو ۵: آگهی reserved با feeDeadline (T0) یک ساعت پیش + Deal confirmed با sellerFeeDeadline (T1) ۲۴ ساعت دیگر.',
    '  اجرا: /admin-deals ← «اجرای دستی» مهلت‌ها (یا باز کردن بازار/پنل).',
    '  انتظار: Deal هنوز confirmed، فروشنده‌ی این سناریو محدود نشده، آگهی reserved، feeDeadline آگهی پاک. بعد: verify 5',
  ]
}

async function runSeed(prisma: PrismaClient, scenarios: Scenario[]): Promise<void> {
  const notes: string[] = []
  const seeders: Record<Scenario, (tx: Prisma.TransactionClient) => Promise<string[]>> = {
    '3': seedScenario3,
    '4': seedScenario4,
    '5': seedScenario5,
  }
  await prisma.$transaction(async (tx) => {
    await ensureBase(tx)
    for (const s of scenarios) {
      notes.push(...(await seeders[s](tx)))
    }
  })
  console.log('✓ ساخته شد:')
  for (const line of notes) console.log(line)
}

function check(label: string, ok: boolean): boolean {
  console.log(`  ${ok ? '✓' : '✗'} ${label}`)
  return ok
}

async function verifyScenario3(prisma: PrismaClient): Promise<boolean> {
  console.log('سناریو ۳:')
  const listing = await prisma.materialListing.findUnique({ where: { id: ID.s3.listing } })
  const deal = await prisma.deal.findUnique({ where: { id: ID.s3.deal }, select: { status: true } })
  const seller = await prisma.user.findUnique({ where: { id: ID.seller }, select: { restrictedUntil: true } })
  if (!listing || !deal) {
    console.log('  ✗ رکوردهای سناریو نیست — اول seed 3 --apply')
    return false
  }
  const results = [
    check(`آگهی needs_reverification (فعلی: ${listing.validityStatus})`, listing.validityStatus === 'needs_reverification'),
    check('feeDeadline آگهی پاک شده', listing.feeDeadline === null),
    check(`Deal cancelled (فعلی: ${deal.status})`, deal.status === 'cancelled'),
    check('فروشنده محدود شده', !!seller?.restrictedUntil && seller.restrictedUntil > new Date()),
  ]
  return results.every(Boolean)
}

async function verifyScenario4(prisma: PrismaClient): Promise<boolean> {
  console.log('سناریو ۴:')
  const deal = await prisma.deal.findUnique({
    where: { id: ID.s4.deal },
    select: { status: true, confirmations: { select: { type: true } } },
  })
  const link = await prisma.driverAccessLink.findUnique({ where: { id: ID.s4.link } })
  if (!deal || !link) {
    console.log('  ✗ رکوردهای سناریو نیست — اول seed 4 --apply')
    return false
  }
  const types = new Set(deal.confirmations.map((c) => c.type))
  const daysLeft = ((link.expiresAt.getTime() - Date.now()) / (24 * HOUR_MS)).toFixed(1)
  console.log(`  وضعیت Deal: ${deal.status} | لینک: ${link.usedAt ? 'مصرف‌شده' : 'زنده'}، انقضا ${daysLeft} روز دیگر`)
  const results = [
    check('پذیرش ثبت شده (driver_accepted)', types.has('driver_accepted')),
    check('بارگیری ثبت شده (loading)', types.has('loading')),
    check('تخلیه ثبت شده (unloading)', types.has('unloading')),
    check(`Deal delivered (فعلی: ${deal.status})`, deal.status === 'delivered'),
    // لینک فقط با تخلیه مصرف می‌شه: مصرف‌شدن بدون تخلیه یعنی باگ.
    check('لینک فقط بعد از تخلیه مصرف شده', link.usedAt ? types.has('unloading') : true),
    check('لینک بعد از تخلیه مصرف‌شده است', types.has('unloading') ? link.usedAt !== null : true),
  ]
  return results.every(Boolean)
}

async function verifyScenario5(prisma: PrismaClient): Promise<boolean> {
  console.log('سناریو ۵:')
  const listing = await prisma.materialListing.findUnique({ where: { id: ID.s5.listing } })
  const deal = await prisma.deal.findUnique({ where: { id: ID.s5.deal }, select: { status: true, sellerFeeDeadline: true } })
  const seller = await prisma.user.findUnique({ where: { id: ID.seller5 }, select: { restrictedUntil: true } })
  if (!listing || !deal) {
    console.log('  ✗ رکوردهای سناریو نیست — اول seed 5 --apply')
    return false
  }
  const results = [
    check(`Deal هنوز confirmed (فعلی: ${deal.status})`, deal.status === 'confirmed'),
    check('T1 (sellerFeeDeadline) دست‌نخورده', deal.sellerFeeDeadline !== null),
    check(`آگهی هنوز reserved (فعلی: ${listing.validityStatus})`, listing.validityStatus === 'reserved'),
    check('feeDeadline آگهی (T0 کهنه) پاک شده — یعنی مهلت‌ها اجرا شده‌اند', listing.feeDeadline === null),
    check('فروشنده‌ی سناریو ۵ محدود نشده', !seller?.restrictedUntil || seller.restrictedUntil <= new Date()),
  ]
  return results.every(Boolean)
}

async function runVerify(prisma: PrismaClient, scenarios: Scenario[]): Promise<boolean> {
  let ok = true
  const verifiers: Record<Scenario, (p: PrismaClient) => Promise<boolean>> = {
    '3': verifyScenario3,
    '4': verifyScenario4,
    '5': verifyScenario5,
  }
  for (const s of scenarios) {
    const passed = await verifiers[s](prisma)
    if (!passed) ok = false
  }
  return ok
}

async function runCleanup(prisma: PrismaClient): Promise<void> {
  const deals = await prisma.deal.findMany({ where: { id: { startsWith: PREFIX } }, select: { id: true } })
  const dealIds = deals.map((d) => d.id)
  const where = { id: { startsWith: PREFIX } }
  // هر مرحله جدا: مرحله‌ای که رکورد وابسته‌ی غیر-seed دارد (مثلاً لاگ یا تعدیل دفتر) مسدود و گزارش می‌شه.
  const steps: Array<[string, () => Promise<{ count: number }>]> = [
    ['Deal و وابسته‌ها', async () => {
      await prisma.$transaction(async (tx) => {
        await tx.dealConfirmation.deleteMany({ where: { dealId: { in: dealIds } } })
        await tx.driverAccessLink.deleteMany({ where: { dealId: { in: dealIds } } })
        await tx.dealPayment.deleteMany({ where: { dealId: { in: dealIds } } })
        await tx.dealDriverAssignment.deleteMany({ where: { dealId: { in: dealIds } } })
      })
      return prisma.deal.deleteMany({ where: { id: { in: dealIds } } })
    }],
    ['آگهی‌ها', () => prisma.materialListing.deleteMany({ where })],
    ['شرکت حمل', () => prisma.transportCompany.deleteMany({ where })],
    ['کاربران', () => prisma.user.deleteMany({ where })],
    ['گرید', () => prisma.grade.deleteMany({ where })],
  ]
  let blocked = 0
  for (const [label, run] of steps) {
    try {
      const { count } = await run()
      console.log(`✓ ${label}: ${count} رکورد پاک شد`)
    } catch (error) {
      blocked++
      console.log(`✗ ${label}: مسدود (کد ${errorCode(error)}) — رکورد وابسته‌ی غیر-seed دارد؛ دستی بررسی کنید`)
    }
  }
  if (blocked) process.exitCode = 1
}

async function runCleanupDryRun(): Promise<void> {
  console.log(`dry-run: cleanup همه‌ی رکوردهای با id پیشوند «${PREFIX}» را (Deal، آگهی، شرکت حمل، کاربر، گرید) پاک می‌کرد. برای اجرا --apply.`)
}

async function main(): Promise<void> {
  const args = process.argv.slice(2)
  const command = args[0]
  const rest = args.slice(1)
  const flags = rest.filter((a) => a.startsWith('--'))
  const positional = rest.filter((a) => !a.startsWith('--'))

  const writes = command === 'seed' || command === 'cleanup'
  const allowedFlags = writes ? ['--apply', '--allow-remote'] : []
  const maxPositional = command === 'cleanup' ? 0 : 1
  if (
    !command ||
    !COMMANDS.includes(command) ||
    flags.some((f) => !allowedFlags.includes(f)) ||
    positional.length > maxPositional ||
    (positional[0] !== undefined && !SCENARIO_ARGS.includes(positional[0]))
  ) {
    console.error(USAGE)
    process.exitCode = 1
    return
  }
  const apply = flags.includes('--apply')
  const scenarios = scenarioList(positional[0])

  if (writes && !apply) {
    if (command === 'cleanup') await runCleanupDryRun()
    else {
      console.log(`dry-run: seed سناریو ${scenarios.join(' و ')} را می‌ساخت (بعد از ریست همان سناریو). برای اجرا --apply.`)
    }
    return
  }

  const connectionString = process.env.DATABASE_URL
  if (!connectionString) {
    console.error('DATABASE_URL تنظیم نشده (در .env یا محیط).')
    process.exitCode = 1
    return
  }
  const target = describeTarget(connectionString)
  if (!target) {
    console.error('DATABASE_URL قابل‌خواندن نیست.')
    process.exitCode = 1
    return
  }
  if (writes) {
    if (process.env.NODE_ENV === 'production') {
      console.error('NODE_ENV=production: نوشتن seed/cleanup در محیط production ممنوع است.')
      process.exitCode = 1
      return
    }
    if (!target.isLocal && !flags.includes('--allow-remote')) {
      console.error(`هدف ${target.label} محلی نیست. اگر این یک دیتابیس تست است، --allow-remote را اضافه کنید.`)
      process.exitCode = 1
      return
    }
  }
  console.log(`هدف: ${target.label}`)

  const prisma = new PrismaClient({ adapter: new PrismaPg({ connectionString }) })
  try {
    if (command === 'seed') {
      await runSeed(prisma, scenarios)
    } else if (command === 'verify') {
      const ok = await runVerify(prisma, scenarios)
      if (!ok) process.exitCode = 1
    } else {
      await runCleanup(prisma)
    }
  } finally {
    await prisma.$disconnect()
  }
}

main().catch((error: unknown) => {
  console.error('خطا:', error instanceof Error ? error.message : String(error))
  process.exitCode = 1
})
