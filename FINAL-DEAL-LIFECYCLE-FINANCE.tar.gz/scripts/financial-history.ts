/**
 * ابزار خط فرمان برای تاریخچه‌ی مالی غیرقابل‌حذف (جدول FinancialFieldHistory).
 *
 * اجرا (از ریشه‌ی پروژه؛ DATABASE_URL از .env خوانده می‌شه و هرگز چاپ نمی‌شه):
 *   npx tsx scripts/financial-history.ts verify [entityType [entityId]]
 *   npx tsx scripts/financial-history.ts genesis [--apply]
 *   npx tsx scripts/financial-history.ts anchor > anchor-YYYY-MM-DD.txt
 *
 * verify  : (۱) زنجیره‌ی hash هر موجودیت را بازمحاسبه می‌کنه (حذف/ویرایش/جابه‌جایی رکورد = شکست)؛
 *           (۲) مقدار فعلی ستون‌های Tier B را با آخرین رکورد تاریخچه مقایسه می‌کنه (drift)، چون ساده‌ترین
 *           راه دست‌کاری ویرایش مستقیم ستون با SQL است، نه ویرایش تاریخچه.
 *           هر شکست یا drift = خروج با کد ۱. ستون مقداردار بدون تاریخچه در (۲) مقایسه نمی‌شه و جدا هشدار می‌گیره (تا genesis)؛
 *           فیلتر نوع/شناسه که هیچ زنجیره‌ای پیدا نکنه هم شکست حساب می‌شه، چون چیزی تأیید نشده.
 * genesis : برای ستون‌های Tier B که مقدار دارن ولی تاریخچه ندارن یک رکورد «شروع» می‌سازه.
 *           پیش‌فرض dry-run است؛ جدول append-only است و نوشتن برگشت‌پذیر نیست، پس فقط با --apply می‌نویسه.
 * anchor  : از «سرِ» هر زنجیره (tipHash) یک خلاصه می‌سازه که باید «بیرون از سرور» نگهداری بشه.
 *           کسی که به دیتابیس دسترسی داره می‌تونه ته زنجیره را ببره، یا کل ته را با hash تازه بازنویسی کنه و
 *           verify هم باز موفق می‌شه؛ فقط مقایسه با anchor بیرونی این را می‌گیره (فعلاً دستی، با diff).
 *
 * این فایل عمداً Prisma client خودش را می‌سازه و هیچ فایل 'use server' یا src/lib/prisma.ts را import نمی‌کنه.
 */
import { config } from 'dotenv'
import { PrismaClient, type Prisma } from '@prisma/client'
import { PrismaPg } from '@prisma/adapter-pg'
import {
  FinancialHashError,
  canonicalValue,
  sha256Hex,
  verifyChain,
  type ChainRecord,
  type ChainVerification,
  type FinancialScalar,
} from '../src/lib/financialHash'
import { ensureGenesisRecord } from '../src/lib/financialHistory'

config({ quiet: true })

const HISTORY_PAGE_SIZE = 2000
const ROW_PAGE_SIZE = 500
const MAX_PRINTED = 100

const USAGE = [
  'استفاده:',
  '  npx tsx scripts/financial-history.ts verify [entityType [entityId]]',
  '  npx tsx scripts/financial-history.ts genesis [--apply]',
  '  npx tsx scripts/financial-history.ts anchor',
].join('\n')

type Db = Prisma.TransactionClient
type FieldValues = Record<string, FinancialScalar>
interface EntityRow {
  id: string
  values: FieldValues
}

/**
 * فیلدهای Tier B: ستون‌های موجودِ جدول اصلی که کنار تاریخچه نگه داشته می‌شن (dual-write).
 * entityType و fieldName باید دقیقاً همان رشته‌هایی باشن که اکشن‌ها به appendFinancialRecord می‌دن.
 */
interface TierBEntity {
  entityType: string
  fields: readonly string[]
  /** یک صفحه از ردیف‌ها به ترتیب id؛ onlyId فقط همان یک ردیف را می‌ده. */
  page(db: Db, afterId: string | null, take: number, onlyId?: string): Promise<EntityRow[]>
}

function idFilter(afterId: string | null, onlyId?: string): { id?: string | { gt: string } } {
  if (onlyId) return { id: onlyId }
  if (afterId) return { id: { gt: afterId } }
  return {}
}

const TIER_B: readonly TierBEntity[] = [
  {
    entityType: 'OrderItem',
    // taxAmount = مالیاتِ دستیِ per-ردیف (null = واردنشده؛ genesis ستون‌های null رو رد می‌کنه)
    fields: ['finalPrice', 'taxAmount'],
    async page(db, afterId, take, onlyId) {
      const rows = await db.orderItem.findMany({
        where: idFilter(afterId, onlyId),
        select: { id: true, finalPrice: true, taxAmount: true },
        orderBy: { id: 'asc' },
        take,
      })
      return rows.map((r) => ({ id: r.id, values: { finalPrice: r.finalPrice, taxAmount: r.taxAmount } }))
    },
  },
  {
    entityType: 'Order',
    fields: ['paymentReceiptStatus', 'paymentReceiptUrl'],
    async page(db, afterId, take, onlyId) {
      const rows = await db.order.findMany({
        where: idFilter(afterId, onlyId),
        select: { id: true, paymentReceiptStatus: true, paymentReceiptUrl: true },
        orderBy: { id: 'asc' },
        take,
      })
      return rows.map((r) => ({
        id: r.id,
        values: { paymentReceiptStatus: r.paymentReceiptStatus, paymentReceiptUrl: r.paymentReceiptUrl },
      }))
    },
  },
  {
    entityType: 'WarehouseStock',
    fields: ['priceRial'],
    async page(db, afterId, take, onlyId) {
      const rows = await db.warehouseStock.findMany({
        where: idFilter(afterId, onlyId),
        select: { id: true, priceRial: true },
        orderBy: { id: 'asc' },
        take,
      })
      return rows.map((r) => ({ id: r.id, values: { priceRial: r.priceRial } }))
    },
  },
  {
    entityType: 'Deal',
    // weightKg … totalOverrideToman = فیلدهای حسابداری دستی (admin-deals/actions.ts)؛ null = واردنشده، genesis ستون‌های null را رد می‌کند.
    // fundReleaseFrozen و manualReversalRequired بولین‌اند (پیش‌فرض false، نه null): genesis برای هر Deal یک رکورد false می‌سازد.
    fields: [
      'agreedPrice',
      'escrowStatus',
      'paymentInstructionsText',
      'sellerPaymentInstructionsText',
      'paymentReceiptUrl',
      'weightKg',
      'dealFeeToman',
      'cargoInsuranceToman',
      'buyerTaxToman',
      'sellerTaxToman',
      'paidToman',
      'totalOverrideToman',
      'fundReleaseFrozen',
      'manualReversalRequired',
    ],
    async page(db, afterId, take, onlyId) {
      const rows = await db.deal.findMany({
        where: idFilter(afterId, onlyId),
        select: {
          id: true,
          agreedPrice: true,
          escrowStatus: true,
          paymentInstructionsText: true,
          sellerPaymentInstructionsText: true,
          paymentReceiptUrl: true,
          weightKg: true,
          dealFeeToman: true,
          cargoInsuranceToman: true,
          buyerTaxToman: true,
          sellerTaxToman: true,
          paidToman: true,
          totalOverrideToman: true,
          fundReleaseFrozen: true,
          manualReversalRequired: true,
        },
        orderBy: { id: 'asc' },
        take,
      })
      return rows.map((r) => ({
        id: r.id,
        values: {
          agreedPrice: r.agreedPrice,
          escrowStatus: r.escrowStatus,
          paymentInstructionsText: r.paymentInstructionsText,
          sellerPaymentInstructionsText: r.sellerPaymentInstructionsText,
          paymentReceiptUrl: r.paymentReceiptUrl,
          weightKg: r.weightKg,
          dealFeeToman: r.dealFeeToman,
          cargoInsuranceToman: r.cargoInsuranceToman,
          buyerTaxToman: r.buyerTaxToman,
          sellerTaxToman: r.sellerTaxToman,
          paidToman: r.paidToman,
          totalOverrideToman: r.totalOverrideToman,
          fundReleaseFrozen: r.fundReleaseFrozen,
          manualReversalRequired: r.manualReversalRequired,
        },
      }))
    },
  },
  {
    // ردیف‌های تعدیل جمع کل معامله: رکوردهای ساخت (Tier A) + isDeleted با readColumn؛ ستون‌ها همیشه با سرِ تاریخچه برابرند.
    entityType: 'DealLedgerAdjustment',
    fields: ['amountToman', 'direction', 'description', 'isDeleted'],
    async page(db, afterId, take, onlyId) {
      const rows = await db.dealLedgerAdjustment.findMany({
        where: idFilter(afterId, onlyId),
        select: { id: true, amountToman: true, direction: true, description: true, isDeleted: true },
        orderBy: { id: 'asc' },
        take,
      })
      return rows.map((r) => ({
        id: r.id,
        values: {
          amountToman: r.amountToman,
          direction: r.direction,
          description: r.description,
          isDeleted: r.isDeleted,
        },
      }))
    },
  },
  {
    entityType: 'DealPayment',
    fields: ['amount', 'status', 'receiptUrl'],
    async page(db, afterId, take, onlyId) {
      const rows = await db.dealPayment.findMany({
        where: idFilter(afterId, onlyId),
        select: { id: true, amount: true, status: true, receiptUrl: true },
        orderBy: { id: 'asc' },
        take,
      })
      return rows.map((r) => ({
        id: r.id,
        values: { amount: r.amount, status: r.status, receiptUrl: r.receiptUrl },
      }))
    },
  },
]

function byField<T>(fields: readonly string[], make: () => T): Record<string, T> {
  const out: Record<string, T> = {}
  for (const field of fields) out[field] = make()
  return out
}

/** مقدار فعلی ستون‌های Tier B یک ردیف (یا null اگه ردیف دیگه وجود نداره). */
async function readRowValues(entity: TierBEntity, db: Db, id: string): Promise<FieldValues | null> {
  const rows = await entity.page(db, null, 1, id)
  return rows.length > 0 ? rows[0].values : null
}

/** آخرین newValue ثبت‌شده‌ی هر فیلد برای ردیف‌های یک صفحه: entityId ← (fieldName ← newValue). */
async function loadHistoryHeads(
  db: Db,
  entity: TierBEntity,
  ids: string[],
): Promise<Map<string, Map<string, string | null>>> {
  const heads = new Map<string, Map<string, string | null>>()
  if (ids.length === 0) return heads

  const records = await db.financialFieldHistory.findMany({
    where: { entityType: entity.entityType, entityId: { in: ids }, fieldName: { in: [...entity.fields] } },
    select: { entityId: true, fieldName: true, newValue: true },
    orderBy: [{ entityId: 'asc' }, { seq: 'asc' }],
  })
  for (const record of records) {
    let fields = heads.get(record.entityId)
    if (!fields) {
      fields = new Map<string, string | null>()
      heads.set(record.entityId, fields)
    }
    // seq صعودیه؛ پس آخرین نوشتن برای هر فیلد همان «سر» (مقدار فعلی طبق تاریخچه) است.
    fields.set(record.fieldName, record.newValue)
  }
  return heads
}

/** نمایش امن یک مقدار در خروجی: متن بلند (مثل دستور پرداخت) چاپ نمی‌شه، فقط طول و اثرانگشتش. */
function describeValue(value: string | null): string {
  if (value === null) return 'null'
  if (value.length <= 24) return JSON.stringify(value)
  return `«متن ${value.length} حرفی، sha256=${sha256Hex(value).slice(0, 12)}»`
}

// ── زنجیره‌ها ───────────────────────────────────────────────────────────────────

interface ChainCursor {
  entityType: string
  entityId: string
  seq: number
}
interface ChainGroup {
  entityType: string
  entityId: string
  records: ChainRecord[]
}

/**
 * همه‌ی رکوردها را صفحه‌به‌صفحه (keyset روی (entityType, entityId, seq)) می‌خونه و هر زنجیره‌ی کامل
 * (همه‌ی رکوردهای یک موجودیت) را یک‌بار به onChain می‌ده. زنجیره‌ی نیمه‌کاره بین صفحه‌ها منتقل می‌شه.
 */
async function forEachChain(
  db: Db,
  filter: { entityType?: string; entityId?: string },
  onChain: (entityType: string, entityId: string, records: ChainRecord[]) => void,
): Promise<void> {
  let cursor: ChainCursor | null = null
  let group: ChainGroup | null = null

  for (;;) {
    const where: Prisma.FinancialFieldHistoryWhereInput = {}
    if (filter.entityType) where.entityType = filter.entityType
    if (filter.entityId) where.entityId = filter.entityId
    if (cursor) {
      where.OR = [
        { entityType: { gt: cursor.entityType } },
        { entityType: cursor.entityType, entityId: { gt: cursor.entityId } },
        { entityType: cursor.entityType, entityId: cursor.entityId, seq: { gt: cursor.seq } },
      ]
    }

    const page: ChainRecord[] = await db.financialFieldHistory.findMany({
      where,
      orderBy: [{ entityType: 'asc' }, { entityId: 'asc' }, { seq: 'asc' }],
      take: HISTORY_PAGE_SIZE,
    })

    for (const record of page) {
      // مقایسه‌ی تاپلی (نه رشته‌ی چسبیده) تا دو موجودیت متفاوت هرگز یکی حساب نشن.
      if (group && (group.entityType !== record.entityType || group.entityId !== record.entityId)) {
        onChain(group.entityType, group.entityId, group.records)
        group = null
      }
      if (!group) group = { entityType: record.entityType, entityId: record.entityId, records: [] }
      group.records.push(record)
    }

    if (page.length < HISTORY_PAGE_SIZE) break
    const last = page[page.length - 1]
    cursor = { entityType: last.entityType, entityId: last.entityId, seq: last.seq }
  }

  if (group) onChain(group.entityType, group.entityId, group.records)
}

function formatFailure(
  entityType: string,
  entityId: string,
  failure: Extract<ChainVerification, { ok: false }>,
): string {
  return `✗ ${entityType}/${entityId} — seq ${failure.atSeq} — ${failure.reason}: ${failure.detail}`
}

// ── verify ──────────────────────────────────────────────────────────────────────

interface DriftFinding {
  entityType: string
  entityId: string
  fieldName: string
  historyValue: string | null
  columnValue: string | null
}
interface DriftStats {
  checked: number
  noHistory: number
  /** بخشی از noHistory که ستونش مقدار داره: هیچ پایه‌ای برای مقایسه نیست (تا genesis اجرا نشه). */
  unbaselined: number
  drift: number
}

/** مقدار کانونیک یک ستون؛ مقدار نامعتبر (NaN، Infinity، NUL) crash نمی‌کنه و برچسب جدا می‌گیره تا ردیفش گزارش بشه. */
const INVALID_COLUMN_VALUE = '[invalid]'
function safeCanonical(value: FinancialScalar): string | null {
  try {
    return canonicalValue(value)
  } catch (error) {
    if (error instanceof FinancialHashError) return INVALID_COLUMN_VALUE
    throw error
  }
}

/** مقدار فعلی ستون‌های یک entity را با آخرین رکورد تاریخچه‌ی همان فیلد مقایسه می‌کنه. */
async function checkDrift(
  db: Db,
  entity: TierBEntity,
  onlyId: string | undefined,
): Promise<{ findings: DriftFinding[]; stats: Record<string, DriftStats> }> {
  const findings: DriftFinding[] = []
  const stats = byField<DriftStats>(entity.fields, () => ({ checked: 0, noHistory: 0, unbaselined: 0, drift: 0 }))

  let afterId: string | null = null
  for (;;) {
    const rows = await entity.page(db, afterId, ROW_PAGE_SIZE, onlyId)
    if (rows.length === 0) break

    const heads = await loadHistoryHeads(
      db,
      entity,
      rows.map((r) => r.id),
    )
    for (const row of rows) {
      const headByField = heads.get(row.id)
      for (const field of entity.fields) {
        const stat = stats[field]
        const columnValue = safeCanonical(row.values[field])
        if (!headByField || !headByField.has(field)) {
          stat.noHistory += 1
          // ستون مقداردار بدون تاریخچه: پایه‌ای برای مقایسه نیست، پس دست‌کاری مستقیمش با SQL پیدا نمی‌شه.
          if (columnValue !== null) stat.unbaselined += 1
          continue
        }
        stat.checked += 1
        const historyValue = headByField.get(field) ?? null
        if (historyValue !== columnValue) {
          stat.drift += 1
          findings.push({ entityType: entity.entityType, entityId: row.id, fieldName: field, historyValue, columnValue })
        }
      }
    }

    if (onlyId || rows.length < ROW_PAGE_SIZE) break
    afterId = rows[rows.length - 1].id
  }
  return { findings, stats }
}

/** @returns true اگه همه‌ی زنجیره‌ها سالم باشن و هیچ drift‌ای نباشه */
async function runVerify(db: Db, entityType?: string, entityId?: string): Promise<boolean> {
  console.log('── ۱) صحت زنجیره‌ی hash ──')
  let chains = 0
  let records = 0
  const failures: string[] = []
  await forEachChain(db, { entityType, entityId }, (type, id, chain) => {
    chains += 1
    records += chain.length
    const result = verifyChain(chain)
    if (!result.ok) failures.push(formatFailure(type, id, result))
  })
  console.log(`زنجیره‌ی بررسی‌شده: ${chains} | رکورد: ${records} | زنجیره‌ی خراب: ${failures.length}`)
  for (const line of failures.slice(0, MAX_PRINTED)) console.log(line)
  if (failures.length > MAX_PRINTED) console.log(`… و ${failures.length - MAX_PRINTED} زنجیره‌ی خراب دیگر`)

  console.log('')
  console.log('── ۲) انطباق مقدار فعلی ستون با آخرین رکورد تاریخچه (drift) ──')
  // با فیلتر نوع/شناسه، صفر زنجیره یعنی چیزی تأیید نشده (غلط تایپی یا ردیف بدون تاریخچه)؛ موفقیت حساب نمی‌شه.
  const nothingMatched = (entityType !== undefined || entityId !== undefined) && chains === 0
  const entities = TIER_B.filter((e) => !entityType || e.entityType === entityType)
  if (entities.length === 0) console.log('برای این نوع موجودیت فیلد Tier B تعریف نشده؛ مقایسه‌ای انجام نشد.')

  let driftCount = 0
  let unbaselinedTotal = 0
  const driftLines: string[] = []
  for (const entity of entities) {
    const { findings, stats } = await checkDrift(db, entity, entityId)
    for (const field of entity.fields) {
      const s = stats[field]
      console.log(`${entity.entityType}.${field}: بررسی‌شده ${s.checked} | بدون تاریخچه (ردشده) ${s.noHistory} (مقداردار: ${s.unbaselined}) | drift ${s.drift}`)
    }
    driftCount += findings.length
    unbaselinedTotal += entity.fields.reduce((sum, field) => sum + stats[field].unbaselined, 0)
    for (const f of findings) {
      driftLines.push(
        `✗ ${f.entityType}/${f.entityId}.${f.fieldName} — تاریخچه: ${describeValue(f.historyValue)} | ستون: ${describeValue(f.columnValue)}`,
      )
    }
  }
  for (const line of driftLines.slice(0, MAX_PRINTED)) console.log(line)
  if (driftLines.length > MAX_PRINTED) console.log(`… و ${driftLines.length - MAX_PRINTED} drift دیگر`)

  const ok = failures.length === 0 && driftCount === 0 && !nothingMatched
  console.log('')
  if (nothingMatched) {
    console.log('نتیجه: ناموفق — با این فیلتر هیچ زنجیره‌ای پیدا نشد (ردیف تاریخچه ندارد، یا نوع/شناسه اشتباهه)؛ چیزی تأیید نشد.')
  } else if (ok) {
    console.log('نتیجه: زنجیره‌ها سالم‌اند و هر ستونی که تاریخچه دارد با آخرین رکوردش یکی است.')
    if (unbaselinedTotal > 0) {
      console.log(
        `هشدار: ${unbaselinedTotal} ستون مقداردار هنوز تاریخچه ندارن و بررسی نشدن (دست‌کاری مستقیم‌شون با SQL پیدا نمی‌شه). برای ساخت پایه: genesis (اول dry-run، بعد --apply).`,
      )
    }
    console.log('توجه: حذف رکوردهای انتهایی زنجیره فقط با مقایسه‌ی anchor بیرونی پیدا می‌شه (دستور anchor).')
  } else {
    console.log(`نتیجه: ناموفق — ${failures.length} زنجیره‌ی خراب، ${driftCount} drift.`)
  }
  return ok
}

// ── genesis ─────────────────────────────────────────────────────────────────────

interface GenesisStats {
  candidates: number
  hasHistory: number
  nullColumn: number
  created: number
}

async function runGenesis(prisma: PrismaClient, apply: boolean): Promise<void> {
  console.log(
    apply
      ? 'حالت: --apply (رکوردهای شروع نوشته می‌شن؛ جدول append-only است و برگشتی نداره)'
      : 'حالت: dry-run (چیزی نوشته نمی‌شه؛ برای نوشتن --apply بده)',
  )

  let totalCandidates = 0
  let totalCreated = 0
  for (const entity of TIER_B) {
    const stats = byField<GenesisStats>(entity.fields, () => ({
      candidates: 0,
      hasHistory: 0,
      nullColumn: 0,
      created: 0,
    }))

    let afterId: string | null = null
    for (;;) {
      const rows = await entity.page(prisma, afterId, ROW_PAGE_SIZE)
      if (rows.length === 0) break

      const heads = await loadHistoryHeads(
        prisma,
        entity,
        rows.map((r) => r.id),
      )
      for (const row of rows) {
        const headByField = heads.get(row.id)
        const pending: string[] = []
        for (const field of entity.fields) {
          if (headByField && headByField.has(field)) {
            stats[field].hasHistory += 1
          } else if (canonicalValue(row.values[field]) === null) {
            stats[field].nullColumn += 1
          } else {
            stats[field].candidates += 1
            pending.push(field)
          }
        }
        if (!apply || pending.length === 0) continue

        // یک تراکنش برای هر ردیف؛ ensureGenesisRecord خودش قفل می‌گیره و «بعد از قفل» ستون را می‌خونه.
        const createdFields = await prisma.$transaction(async (tx) => {
          const done: string[] = []
          for (const field of pending) {
            const created = await ensureGenesisRecord(tx, {
              entityType: entity.entityType,
              entityId: row.id,
              fieldName: field,
              readColumn: async () => {
                const values = await readRowValues(entity, tx, row.id)
                return values ? values[field] : null
              },
            })
            if (created) done.push(field)
          }
          return done
        })
        for (const field of createdFields) stats[field].created += 1
      }

      if (rows.length < ROW_PAGE_SIZE) break
      afterId = rows[rows.length - 1].id
    }

    for (const field of entity.fields) {
      const s = stats[field]
      totalCandidates += s.candidates
      totalCreated += s.created
      console.log(
        `${entity.entityType}.${field}: نامزد ${s.candidates} | قبلاً تاریخچه داشته ${s.hasHistory} | ستون خالی ${s.nullColumn} | ساخته‌شده ${s.created}`,
      )
    }
  }

  console.log('')
  if (apply) {
    console.log(`جمع: ${totalCreated} رکورد شروع ساخته شد. حالا verify را اجرا کن.`)
  } else {
    console.log(`جمع: ${totalCandidates} رکورد شروع ساخته می‌شه. برای نوشتن: genesis --apply`)
  }
}

// ── anchor ──────────────────────────────────────────────────────────────────────

/**
 * خروجی روی stdout فقط داده‌ی anchor است (قابل redirect به فایل)؛ پیام‌های تشخیصی روی stderr می‌رن.
 * هر خط: entityType ⇥ entityId ⇥ تعداد رکورد ⇥ tipHash. digest نهایی از خط‌های مرتب‌شده ساخته می‌شه
 * (مرتب‌سازی در JS، تا به collation دیتابیس بستگی نداشته باشه).
 * @returns false اگه زنجیره‌ی خراب پیدا شد (anchor برای دیتای خراب معنی نداره، چاپ نمی‌شه)
 */
async function runAnchor(db: Db): Promise<boolean> {
  const lines: string[] = []
  const failures: string[] = []
  let records = 0

  await forEachChain(db, {}, (entityType, entityId, chain) => {
    const result = verifyChain(chain)
    if (!result.ok) {
      failures.push(formatFailure(entityType, entityId, result))
      return
    }
    records += result.count
    lines.push([entityType, entityId, String(result.count), result.tipHash ?? ''].join('\t'))
  })

  if (failures.length > 0) {
    console.error(`anchor ساخته نشد: ${failures.length} زنجیره‌ی خراب.`)
    for (const line of failures.slice(0, MAX_PRINTED)) console.error(line)
    console.error('اول verify را اجرا و مشکل را بررسی کن.')
    return false
  }

  lines.sort()
  const digest = sha256Hex(lines.join('\n'))
  if (lines.length > 0) process.stdout.write(`${lines.join('\n')}\n`)
  process.stdout.write(`# generatedAt=${new Date().toISOString()}\n`)
  process.stdout.write(`# chains=${lines.length} records=${records}\n`)
  process.stdout.write(`# digest=${digest}\n`)
  if (lines.length === 0) console.error('هنوز هیچ رکوردی در تاریخچه نیست.')
  return true
}

// ── main ────────────────────────────────────────────────────────────────────────

const COMMANDS = ['verify', 'genesis', 'anchor']

async function main(): Promise<void> {
  const args = process.argv.slice(2)
  const command = args[0]
  const rest = args.slice(1)
  const flags = rest.filter((a) => a.startsWith('--'))
  const positional = rest.filter((a) => !a.startsWith('--'))

  const allowedFlags = command === 'genesis' ? ['--apply'] : []
  const maxPositional = command === 'verify' ? 2 : 0
  if (
    !command ||
    !COMMANDS.includes(command) ||
    flags.some((f) => !allowedFlags.includes(f)) ||
    positional.length > maxPositional
  ) {
    console.error(USAGE)
    process.exitCode = 1
    return
  }

  const connectionString = process.env.DATABASE_URL
  if (!connectionString) {
    console.error('DATABASE_URL تنظیم نشده (در .env یا محیط).')
    process.exitCode = 1
    return
  }

  const prisma = new PrismaClient({ adapter: new PrismaPg({ connectionString }) })
  try {
    if (command === 'verify') {
      const ok = await runVerify(prisma, positional[0], positional[1])
      if (!ok) process.exitCode = 1
    } else if (command === 'genesis') {
      await runGenesis(prisma, flags.includes('--apply'))
    } else {
      const ok = await runAnchor(prisma)
      if (!ok) process.exitCode = 1
    }
  } finally {
    await prisma.$disconnect()
  }
}

main().catch((error: unknown) => {
  console.error('خطا:', error instanceof Error ? error.message : String(error))
  process.exitCode = 1
})
