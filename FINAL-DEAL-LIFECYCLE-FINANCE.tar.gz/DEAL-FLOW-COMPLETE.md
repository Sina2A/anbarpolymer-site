# DEAL-FLOW-COMPLETE — مستند کامل جریان معامله

**تاریخ تهیه:** ۲۰۲۶-۱۰-۰۲
**مخاطب:** هر کسی که کد نمی‌خونه (مدیر، کارشناس، حسابداری)

---

## ۰) راهنمای خواندن این سند

این سند از خواندنِ مستقیمِ کد نوشته شده، نه از روی مستندات قبلی. مستندات قبلی هم بررسی شدند و هرجا با کد فرق داشتند، در جدول بخش ۱۰ آمده.

**سه برچسب در این سند استفاده می‌شه:**

| برچسب | معنی |
|---|---|
| *(بدون برچسب)* | از روی کد خونده شده و قطعی است |
| **[خواندن کد، اجرا نشده]** | نتیجه‌ی خواندن کد است؛ به‌دلیل نبودِ دیتابیسِ در دسترس، روی سرور واقعی تست نشده |
| **[نامشخص، نیاز به بررسی بیشتر]** | در کد جوابی پیدا نشد یا به داده‌ی واقعی دیتابیس بستگی داره |

**هشدار:** دو فایل `src/app/admin-deals/actions.ts` و `src/app/admin-deals/page.tsx` حین این بررسی توسط شخص دیگری ویرایش شدند (ساعت ۰۴:۰۸ روز ۲۰۲۶-۱۰-۰۲، سخت‌گیری دسترسی). شماره‌خط‌های این سند مربوط به وضعیت ساعت ۰۴:۳۸ همان روز است.

**یک نکته‌ی کلی:** این سایت **هیچ پولی جابه‌جا نمی‌کند**. تمام پرداخت‌ها بیرون از سایت انجام می‌شود و سایت فقط «رسید» و «تأیید حسابداری» را ثبت می‌کند.

---

## ۱) خلاصه‌ی یک‌صفحه‌ای

1. یک کاربر در بازار یا **آگهی فروش** می‌بیند (SELL) یا **درخواست خرید** می‌گذارد (BUY). طرف مقابل پیشنهاد می‌دهد/درخواست را می‌پذیرد و یک **معامله (Deal)** با وضعیت `draft` ساخته می‌شود.
2. **فروشنده** باید آن پیش‌نویس را **قبول یا رد** کند. قبول → `confirmed` (یا اگر قیمت بالا باشد `awaiting_approval` که فقط مدیر می‌تواند تأیید کند).
3. از لحظه‌ی `confirmed` **دو ساعت هم‌زمان** شروع می‌شود: کارمزد فروشنده (۲۴ ساعت کاری) و پرداخت خریدار (۷۲ ساعت کاری). هر دو رسید آپلود و توسط ادمین تأیید می‌شوند.
4. وقتی **هر دو** پرداخت تأیید شد → `transport_pending`.
5. راننده فرم **بارگیری** را پر می‌کند → `in_transit`. فرم **تخلیه** → `delivered`.
6. بعد از تخلیه، خریدار ۴ ساعت کاری فرصت دارد **مغایرت** گزارش کند. اگر گزارش نکند، سیستم خودکار تأیید می‌کند.
7. آزادسازی پول **کاملاً دستی** است: حسابداری بیرون از سایت پول را می‌دهد، بعد ادمین دکمه‌ی «این معامله کامل تسویه شده» را می‌زند → `settled`.
8. هر لحظه قبل از `transport_pending` هر دو طرف می‌توانند **لغو** کنند. نتیجه‌ی لغو بسته به اینکه «درخواست‌دهنده» بوده یا «پذیرنده» کاملاً متفاوت است (بخش ۵).
9. یک **صف رزرو** وجود دارد: اگر چند نفر روی یک مورد صف باشند، با لغو/رد/اتمام مهلت نفر اول، نفر بعدی ۱ ساعت فرصت پذیرش می‌گیرد (بخش ۶).

---

## ۲) نقش‌ها

### ۲-۱) چهار نقش هر معامله

هر Deal چهار شناسه دارد:

| فیلد | معنی |
|---|---|
| `buyerId` | خریدار واقعی بار |
| `sellerId` | فروشنده‌ی واقعی بار |
| `requesterId` | **درخواست‌دهنده** — کسی که مورد را در بازار گذاشته |
| `acceptorId` | **پذیرنده** — کسی که به آن مورد پیشنهاد داده |

این چهار نقش در دو جهت بازار **جابه‌جا می‌شوند**. این مهم‌ترین نکته‌ی کل سیستم است:

| جهت | چه اتفاقی افتاده | requester | acceptor |
|---|---|---|---|
| **SELL** | فروشنده آگهی گذاشته، خریدار رویش کلیک کرده | **فروشنده** (صاحب آگهی) | **خریدار** |
| **BUY** | خریدار درخواست خرید گذاشته، فروشنده پذیرفته | **خریدار** (صاحب درخواست) | **فروشنده** |

منبع: `src/app/market/actions.ts:116-120` (SELL) و `:201-203` (BUY).

**نتیجه‌ی عملی:** هرکجا در این سند «پذیرنده» یا «درخواست‌دهنده» خواندید، بدانید که در SELL و BUY آدم‌های متفاوتی هستند.

### ۲-۲) معامله‌های قدیمی (fallback)

معامله‌های ساخته‌شده قبل از این نسخه `requesterId`/`acceptorId` ندارند. کد در آن حالت از `tradeDirection` حدس می‌زند:

- `dir = tradeDirection || 'SELL'`
- `requesterId ?? (dir==='SELL' ? sellerId : buyerId)`
- `acceptorId ?? (dir==='SELL' ? buyerId : sellerId)`

منبع: `src/app/my-deals/actions.ts:185-187`.

### ۲-۳) تشخیص «فروشنده»

```ts
// src/lib/dealRoles.ts:26
resolveSellerId(deal) = deal.sellerId ?? deal.materialListing?.userId ?? null
```

`isDealSeller` اگر فروشنده پیدا نشود `false` برمی‌گرداند. یعنی در معامله‌های قدیمیِ بدون `sellerId` و بدون آگهی، **هیچ‌کس نمی‌تواند پیش‌نویس را قبول کند**.

### ۲-۴) چه کسی چه کاری می‌تواند بکند

| کار | چه کسی | منبع |
|---|---|---|
| قبول پیش‌نویس (`draft` → `confirmed`) | فقط **فروشنده** | `my-deals/actions.ts:29` |
| رد پیش‌نویس | فقط **فروشنده** | `my-deals/actions.ts:53` |
| لغو معامله | هر دو طرف (در وضعیت‌های مجاز) | `my-deals/actions.ts:172` |
| آپلود رسید `BUYER_GOODS` | فقط `deal.buyerId` | `my-deals/actions.ts:88` |
| آپلود رسید `SELLER_FEE` | فقط `deal.sellerId` (بدون fallback) | `my-deals/actions.ts:88` |
| گزارش مغایرت | فقط **خریدار** | `my-deals/actions.ts:138` |
| تأیید/رد پرداخت | ادمین یا staff | `admin-deals/actions.ts:281`, `:353` |
| تأیید قیمت (`awaiting_approval` → `confirmed`) | **فقط ادمین** | `admin-deals/actions.ts:252` |
| آزادسازی وجه (`settled`) | ادمین یا staff با دسترسی `deals` در سطح edit/full | `admin-deals/actions.ts:57` |
| بررسی درخواست خرید (`needs_review`) | ادمین یا staff | `admin-deals/actions.ts:447` |
| حل اختلاف (Dispute) | ادمین یا کاربر با دسترسی بخش `disputes` | `admin-disputes/actions.ts:15`, `:32` |
| فرم بارگیری/تخلیه | راننده با لینک توکن‌دار (بدون حساب کاربری) | `driver/[token]/actions.ts:34` |
| پذیرش/رد سفر | راننده با لینک توکن‌دار | `driver/t/[token]/actions.ts` |
| تعیین شرکت حمل / راننده | ادمین یا staff با دسترسی لجستیک | `admin-logistics/actions.ts:162`, `:193` |

### ۲-۵) محدودیت ۲۴ ساعته (جریمه)

`User.restrictedUntil` کاربر را محدود می‌کند. تابع `isUserRestricted` (`dealDeadlines.ts:331`) فقط تا وقتی `restrictedUntil >= now` باشد `true` می‌دهد.

**جاهایی که واقعاً چک می‌شود** (grep تأیید شده):

- ساخت آگهی: `api/material-listings/route.ts:82` و `new-listing/page.tsx:55`
- پیشنهاد روی آگهی (خریدار/پذیرنده): `market/actions.ts:65`
- پذیرش درخواست خرید (فروشنده/پذیرنده): `market/actions.ts:165`
- ورود به صف رزرو: `market/actions.ts:258`

**جاهایی که چک نمی‌شود** — یعنی کاربر محدود هم می‌تواند این کارها را بکند:

- قبول پیش‌نویس (`acceptDealOfferAction`)
- لغو معامله (`cancelDealAction`)
- آپلود رسید پرداخت
- کل جریان راننده

**[نامشخص، نیاز به بررسی بیشتر]** آیا ساختِ درخواستِ خرید محدودیت را چک می‌کند.

**دو روش نوشتنِ متفاوتِ محدودیت:**

- `restrictUser` (`dealDeadlines.ts:444-459`) بزرگ‌ترین مقدارِ بین `restrictedUntil` فعلی و مقدار جدید را می‌گذارد → **کوتاه نمی‌کند**.
- دو جای دیگر مستقیم `prisma.user.update` می‌زنند و **رونویسی** می‌کنند: `:166` (فروشنده‌ی legacy) و `:206` (خریدار). این یعنی یک محدودیت طولانی‌تر می‌تواند کوتاه شود.

### ۲-۶) تأیید دوباره‌ی فروشنده در جهت BUY [خواندن کد، اجرا نشده]

در جهت BUY، فروشنده یک بار با `acceptPurchaseRequestAction` پذیرفته. ولی معامله `draft` ساخته می‌شود و **همان فروشنده باید دوباره** در `/my-deals` → «پیشنهادهای دریافتی» دکمه‌ی قبول را بزند تا `confirmed` شود و مهلت‌ها شروع شوند. تا آن لحظه خریدار در صفحه‌ی خودش پیام «تا زمانی که فروشنده این معامله را تأیید نکند، امکان پرداخت بهای بار وجود ندارد» را می‌بیند.

---

## ۳) وضعیت‌ها (status)

`Deal.status` در دیتابیس یک رشته است، نه enum (`schema.prisma:376`، مقدار پیش‌فرض `draft`).

### ۳-۱) زنجیره‌ی واقعی که کد می‌نویسد

```
draft
  └─(فروشنده قبول کند)→ awaiting_approval  یا  confirmed
        awaiting_approval └─(فقط ادمین)→ confirmed
        confirmed └─(هر دو پرداخت تأیید شود)→ transport_pending
transport_pending └─(راننده فرم بارگیری)→ in_transit
in_transit └─(راننده فرم تخلیه)→ delivered
delivered └─(ادمین آزادسازی وجه)→ settled
```

**وضعیت‌های پایانی:** `cancelled` (لغو)، `void` (باطل با رد پرداخت).

### ۳-۲) جدول وضعیت‌ها

| وضعیت | معنی فارسی | چه کسی/چه چیزی می‌نویسد |
|---|---|---|
| `draft` | پیش‌نویس؛ فروشنده هنوز تصمیم نگرفته | ساخت معامله (`market/actions.ts:124`, `:207`) |
| `awaiting_approval` | قیمت نیاز به تأیید مدیر دارد | `startBuyerPaymentDeadline` (`dealDeadlines.ts:486`) |
| `confirmed` | تأیید شده؛ ساعت پرداخت‌ها شروع شده | `startBuyerPaymentDeadline` یا `approveDealAction` |
| `transport_pending` | هر دو پرداخت تأیید؛ منتظر بارگیری | `approvePaymentAction` (`admin-deals/actions.ts:319`) |
| `in_transit` | بار زده شده، در راه | `submitDealConfirmation` (`driver/[token]/actions.ts:108`) |
| `delivered` | تخلیه شده | `startPostUnloadingClocks` (`dealDeadlines.ts:221`) |
| `settled` | کامل تسویه شده | `confirmFundsReleased` (`admin-deals/actions.ts:57`) |
| `cancelled` | لغو شده | `cancelDealAction`، `rejectDealOfferAction`، enforcerهای مهلت |
| `void` | باطل شده با رد پرداخت | `rejectPaymentAction` |

### ۳-۳) وضعیت‌هایی که **هیچ‌وقت نوشته نمی‌شوند**

`seller_fee_paid`، `payment_secured`، `loading`، `rejected`

این چهار مقدار در برچسب‌ها، فیلترها و نوار پیشرفت صفحه‌ها ظاهر می‌شوند (`admin-deals/page.tsx:19-23`، `dashboard/page.tsx:269-271`، `transport-panel/page.tsx:9`) ولی هیچ کدی آن‌ها را نمی‌نویسد. یعنی آن بخش‌های رابط کاربری عملاً هرگز فعال نمی‌شوند. **`schema.prisma:376-379` و `NOTES-DEAL-FLOW-FIXES-2.md:13` هنوز همین زنجیره‌ی قدیمی را مستند کرده‌اند.**

### ۳-۴) دو فیلد وضعیتِ دیگر

**`Deal.escrowStatus`** (`schema.prisma:401`):

```
pending ──(تأیید پرداخت BUYER_GOODS)──→ secured_manual ──(ادمین آزاد کند)──→ released_manual
```

**`DealPayment.status`** (`schema.prisma:457`) — برای هر معامله **دو ردیف** ساخته می‌شود:

| `kind` | پرداخت‌کننده | مبلغ |
|---|---|---|
| `BUYER_GOODS` | `deal.buyerId` | `agreedPrice` |
| `SELLER_FEE` | `deal.sellerId` | `null` (مبلغ را کارشناس اعلام می‌کند) |

```
PENDING ──(آپلود رسید)──→ SUBMITTED ──┬─(تأیید ادمین)─→ APPROVED
                                      └─(رد ادمین)────→ REJECTED
```

**نکته‌ی مهم:** شرط عبور به `transport_pending` این است که **هر دو ردیف** `APPROVED` باشند — نه `Deal.status`. منبع: `admin-deals/actions.ts:305-322`.

**نکته‌ی دوم:** تأیید پرداخت **نیازی به رسید ندارد**. گارد `PENDING|SUBMITTED → APPROVED` است؛ یعنی ادمین می‌تواند بدون رسید تأیید کند.

---

## ۴) تمام تغییر وضعیت‌ها

### ۴-۱) دستی

| # | از | به | چه کسی | کدام اکشن | از کدام صفحه |
|---|---|---|---|---|---|
| ۱ | — | `draft` | خریدار (روی آگهی) | `createDealFromListingAction` | `/market` |
| ۲ | — | `draft` | فروشنده (روی درخواست خرید) | `acceptPurchaseRequestAction` | `/market` |
| ۳ | `draft` | `confirmed` یا `awaiting_approval` | فروشنده | `acceptDealOfferAction` | `/my-deals` → پیشنهادهای دریافتی |
| ۴ | `draft` | `cancelled` | فروشنده | `rejectDealOfferAction` | `/my-deals` |
| ۵ | `awaiting_approval` | `confirmed` | **فقط ادمین** | `approveDealAction` | `/admin-deals` |
| ۶ | هر پرداخت | `APPROVED` (+ `transport_pending` اگر هر دو) | ادمین/staff | `approvePaymentAction` | `/admin-deals` |
| ۷ | هر پرداخت | `REJECTED` و معامله `void` | ادمین/staff | `rejectPaymentAction` | `/admin-deals` |
| ۸ | `PENDING`/`SUBMITTED` | `SUBMITTED` | خریدار/فروشنده | `uploadDealPaymentReceiptAction` | `/my-deals/[id]` |
| ۹ | `transport_pending` | `in_transit` | راننده | `submitDealConfirmation` (فرم بارگیری) | `/driver/[token]` |
| ۱۰ | `in_transit` | `delivered` | راننده | `submitDealConfirmation` (فرم تخلیه) | `/driver/[token]` |
| ۱۱ | هر وضعیت جز void/cancelled/settled | `settled` | ادمین/داشتن دسترسی edit | `confirmFundsReleased` | `/admin-deals` |
| ۱۲ | مجازها | `cancelled` | هر یک از دو طرف | `cancelDealAction` | `/my-deals/[id]` |
| ۱۳ | `needs_review` | `open`/`closed` | ادمین/staff | `reviewPurchaseRequestAction` | `/admin-deals` |

**دسترسی‌ها یکدست نیستند:**
- `approveDealAction` → فقط `role === 'admin'`، خطای ساده‌ی `Error`.
- `approvePaymentAction` / `rejectPaymentAction` / `reviewPurchaseRequestAction` → هر کاربر `staff`، **بدون بررسی دسترسی بخش**.
- `confirmFundsReleased` / `adjustDeadlineAction` → `requireDealsEditAccess` (ادمین یا staff با دسترسی `deals` سطح edit/full).

### ۴-۲) خودکار

**دو روش اجرا وجود دارد:**

1. **Lazy** — تابع `enforceDealDeadlines()` موقع باز شدن این صفحه‌ها اجرا می‌شود: `/admin-deals`، `/my-deals`، `/my-deals/[id]`، `/deal-confirm/[dealId]`. و `enforceProformaDeadlines()` روی `/proformas` و `/proformas/[id]`.
2. **زمان‌بند/دستی** — `POST /api/enforce-deadlines` (با هدر `Authorization: Bearer $DEADLINE_CRON_SECRET`؛ اگر secret تنظیم نشده باشد ۵۰۳ و اگر اشتباه باشد ۴۰۱) و دکمه‌ی دستی ادمین. این مسیر `runDeadlineEnforcement` را صدا می‌زند که **چهار کار** می‌کند: مهلت معامله‌ها + مهلت پیش‌فاکتور + هشدار قیمت + **انقضای claim صف رزرو**.

**مهم:** انقضای claim صف رزرو **فقط** با cron/دستی اتفاق می‌افتد، نه lazy.

**جدول enforcerها** (ترتیب اجرا همان ترتیب جدول است):

| enforcer | شرط | نتیجه | جریمه |
|---|---|---|---|
| `enforceSellerFeeDeadlines` (legacy، سطح آگهی) | آگهی با `feeStatus='unpaid'`، `validityStatus='reserved'`، `feeDeadline < now` | آگهی → `needs_reverification`؛ معامله‌های `draft`/`confirmed` آن آگهی → `cancelled` (**بدون آزادسازی صف**). **رد می‌شود (فقط ساعتِ آگهی پاک می‌شود)** اگر معامله‌ی آگهی از مرحله‌ی کارمزد گذشته، `SELLER_FEE` تأییدشده دارد، یا `confirmed` است و `sellerFeeDeadline` (T1) دارد؛ پیش‌نویس‌ها هم‌چنان با این ساعت منقضی می‌شوند | فروشنده ۲۴ ساعت (با `restrictUser`) |
| `enforceBuyerPaymentDeadlines` | `status='confirmed'` و `escrowStatus='pending'` و `buyerConfirmDeadline < now` | معامله → `cancelled` + **آزادسازی صف** | خریدار ۲۴ ساعت (رونویسی) |
| `enforceDealSellerFeeDeadlines` | `status='confirmed'` و `sellerFeeDeadline < now` و `SELLER_FEE` تأییدنشده (شرط در گاردِ اتمیکِ لغو هم هست) | معامله → `cancelled` + **آزادسازی صف** | فروشنده ۲۴ ساعت (با `restrictUser`) |
| `enforceDiscrepancyWindowClose` | `status='delivered'` و `discrepancyReportDeadline < now` و `qualityAutoAccepted=false` | `qualityAutoAccepted=true` + ساخت تأییدیه‌ی `auto_no_discrepancy`. **وضعیت `delivered` می‌ماند** | ندارد |
| `enforceDriverSilenceEscalation` | `status='in_transit'` و پرچم null و آخرین تأییدیه قدیمی‌تر از `driverSilenceDays` | `driverSilenceFlaggedAt` + پیامک به شرکت حمل | ندارد |
| `enforceReservationQueueClaims` | ورودی `notified` با `claimExpiresAt < now` | ورودی → `expired` + `releaseItemInTx` | ندارد |
| `enforceProformaDeadlines` | پیش‌فاکتور `priced` گذشته از مهلت | `rejected` + بازگشت موجودی | ندارد |

**مدت‌های پیش‌فرض** (از تک‌ردیف `DealRuleSettings`، قابل تغییر از `/admin-deals`):

| تنظیم | پیش‌فرض |
|---|---|
| `sellerFeeHours` | ۲۴ ساعت کاری |
| `buyerPaymentHours` | ۷۲ ساعت کاری |
| `discrepancyReportHours` | ۴ ساعت کاری |
| `fundReleaseHours` | ۸ ساعت کاری |
| `driverLinkValidDays` | ۵ روز تقویمی (اعتبار لینک راننده؛ بعد از پذیرش و بعد از بارگیری از همان لحظه تمدید می‌شود) |
| `driverSilenceDays` | ۵ روز تقویمی |
| `proformaConfirmHours` | ۸ ساعت کاری |
| `RESTRICTION_HOURS` | ۲۴ ساعت تقویمی (**ثابت، غیرقابل تنظیم**) |
| گزینه‌های جریمه‌ی رد پرداخت | ۰٫۵ / ۱ / ۳ / ۲۴ / ۷۲ ساعت (پیش‌فرض ۲۴) |

**«ساعت کاری» یعنی چه؟**
موتور محاسبه در `src/lib/businessHours.ts` است و تقویم تهران (`src/lib/tehranClock.ts`).

- یک ردیف `Holiday` تاریخ‌دار بر همه‌چیز اولویت دارد.
- `WeeklyBusinessHour` برای هر روز هفته تنظیم می‌شود.
- **اگر روزی تنظیم نشده باشد، پیش‌فرض «باز ۰۸:۰۰–۱۷:۰۰» در نظر گرفته می‌شود** (`businessHours.ts:53-54`) — جمعه هم باز حساب می‌شود. فقط در **رابط کاربری**ِ تنظیمات، جمعه‌ی ذخیره‌نشده بسته نمایش داده می‌شود (`:136`). یعنی تا وقتی ادمین تقویم را ذخیره نکند، مهلت‌ها روی تقویم ۷ روزه حساب می‌شوند.
- با پیش‌فرض ۹ ساعت/روز: ۲۴ ساعت کاری ≈ ۲⅔ روز باز، ۷۲ ساعت کاری ≈ ۸ روز باز. **این حساب به تقویم ذخیره‌شده بستگی دارد.**
- شاخص روز: `tehranClock.ts:30-32` → `Sun=0 … Fri=5, Sat=6`. با `DAY_LABELS_FA` سازگار است.

**قانون مهم: هیچ آزادسازیِ خودکارِ وجهی وجود ندارد.** `fundReleaseDeadline` فقط پرچم نمایشی `fundReleaseDue`/`isFlagged` می‌سازد (`admin-deals/page.tsx:464-465`). دکمه‌ی آزادسازی دستی است. برخلاف چیزی که `schema.prisma:387-388` قول داده.

**چیزی که خودکار لغو نمی‌شود:** `draft` و `awaiting_approval` هیچ enforcer‌ای ندارند. یک معامله‌ی BUY می‌تواند تا ابد `draft` بماند. `draft`های SELL فقط با enforcer سطحِ آگهی (ردیف اول جدول) گرفته می‌شوند.

---

## ۵) مسیرهای لغو

### ۵-۱) لغو توسط یکی از دو طرف (`cancelDealAction`)

**وضعیت‌های مجاز** (`my-deals/actions.ts:22`):

```ts
CANCELABLE_STATUSES = ['draft', 'awaiting_approval', 'confirmed', 'seller_fee_paid']
```

**`transport_pending` مجاز نیست** — با اینکه کامنت کنارش نوشته «قبل از بارگیری». یعنی از لحظه‌ای که هر دو پرداخت تأیید شد، هیچ‌یک از دو طرف نمی‌توانند لغو کنند؛ فقط مسیر «رد پرداخت توسط ادمین» باقی می‌ماند.

**هیچ‌کدام از چهار مسیر جریمه ندارند** (هیچ `restrictUser` در این تابع نیست).

چهار حالت:

| # | جهت | نقش | وضعیت Deal | وضعیت مورد | صف |
|---|---|---|---|---|---|
| ۱ | SELL | **درخواست‌دهنده** (فروشنده/صاحب آگهی) | `cancelled` | آگهی → `needs_reverification` (پنهان) | **متوقف** — کسی اطلاع نمی‌گیرد |
| ۲ | SELL | **پذیرنده** (خریدار) | `cancelled` | `releaseItemInTx` | نفر بعدی صف ۱ ساعت فرصت می‌گیرد؛ اگر صف خالی بود آگهی → `active` |
| ۳ | BUY | **درخواست‌دهنده** (خریدار/صاحب درخواست) | `cancelled` | درخواست → `needs_review` (پنهان) | **متوقف** — نیاز به بررسی ادمین |
| ۴ | BUY | **پذیرنده** (فروشنده) | `cancelled` | `releaseItemInTx` | نفر بعدی صف ۱ ساعت فرصت می‌گیرد؛ اگر صف خالی بود درخواست → `open` |

همه در یک `$transaction` با `updateMany` گاردشده انجام می‌شود (claim-then-act) تا در شرایط همزمانی دوبار لغو نشود. `notifyPromoted` بعد از commit صدا زده می‌شود.

**[نامشخص، نیاز به بررسی بیشتر]** مسیر بازگرداندن آگهی SELL از `needs_reverification` به بازار. برای BUY مسیر مشخص است (`reviewPurchaseRequestAction`) ولی برای SELL چیزی جز `updateListingStatusAction` پیدا نشد.

### ۵-۲) رد پیش‌نویس توسط فروشنده (`rejectDealOfferAction`)

فقط در `draft` و فقط فروشنده. معامله → `cancelled` و `releaseItemInTx` (یعنی نفر بعدی صف یا بازگشت به بازار). **بدون جریمه و بدون پنهان‌سازی.**

**تناقض رفتاری:** همان آدم (فروشنده‌ی SELL که درخواست‌دهنده است) اگر `draft` را **رد** کند، آگهی مستقیم به بازار/صف برمی‌گردد. ولی اگر بعداً (در `confirmed`) **لغو** کند، آگهی `needs_reverification` می‌شود و می‌خوابد تا ادمین نگاه کند. یک نقش، دو نتیجه‌ی کاملاً متفاوت، فقط بسته به زمان.

### ۵-۳) لغو خودکار (اتمام مهلت)

- `enforceBuyerPaymentDeadlines` و `enforceDealSellerFeeDeadlines` → `cancelGuardedDealAndRelease` → معامله `cancelled` + **`releaseItemInTx`** (نفر بعدی صف) + جریمه‌ی ۲۴ ساعته.
- `enforceSellerFeeDeadlines` (legacy، سطح آگهی) → معامله‌های `draft`/`confirmed` آن آگهی مستقیم `cancelled` می‌شوند، **بدون آزادسازی صف**. صف آن مورد می‌خوابد.

### ۵-۴) باطل شدن با رد پرداخت (`rejectPaymentAction`)

معامله → `void` (نه `cancelled`). دو شاخه:

| پرداخت‌کننده ردشده | نتیجه |
|---|---|
| **درخواست‌دهنده** | BUY: درخواست → `closed`؛ SELL: آگهی → `cancelled`؛ + `closeRunInTx` (کل صف آن مورد `expired`). **بدون جریمه** |
| **پذیرنده** | `releaseItemInTx` (نفر بعدی صف) + **جریمه‌ی `acceptorId`** |

اگر معامله از قبل `void`/`cancelled` باشد، شاخه‌ی `already_dead` می‌خورد و وضعیت عوض نمی‌شود.
**`escrowStatus` برگردانده نمی‌شود** — اگر `secured_manual` بوده، همان می‌ماند.

---

## ۶) صف رزرو

منبع: `src/lib/reservationQueue.ts`.

### ۶-۱) وضعیت یک ورودی صف

`schema.prisma:998`: `waiting | notified | accepted | declined | expired`

- ورودی‌های «زنده»: `LIVE_ENTRY_STATUSES = ['waiting','notified']` (`:65`)
- `CLAIM_TTL_MS = 3600000` → **۱ ساعت** (`:48`)
- هر مورد یک `queueRunId` (نسل) دارد؛ `closeRunInTx` تمام ورودی‌های زنده را `expired` می‌کند (`:537-547`).

### ۶-۲) وضعیت خودِ مورد

| جهت | وضعیت فعال | بقیه |
|---|---|---|
| SELL (آگهی) | `active` | `reserved`, `needs_reverification`, `completed`, `cancelled` |
| BUY (درخواست خرید) | `open` | `reserved`, `needs_review`, `closed`, `expired` |

`ITEM_ACTIVE_STATUS = {SELL:'active', BUY:'open'}` (`:57`).

### ۶-۳) ورود به صف (`enterQueue`) — چه وقت رد می‌شود

به‌ترتیب:

| پیام خطا | شرط |
|---|---|
| «این مورد دیگر موجود نیست.» | مورد پیدا نشد |
| «این مورد هم‌اکنون در دسترس است؛ می‌توانید مستقیم پیشنهاد دهید.» | مورد `active`/`open` است |
| «این مورد دیگر قابل رزرو نیست.» | مورد `reserved` نیست |
| «نمی‌توانید برای موردِ خودتان در صف رزرو قرار بگیرید.» | شما صاحب مورد هستید |
| «شما هم‌اکنون طرفِ معامله‌ی جاریِ این مورد هستید.» | معامله‌ای با وضعیت جز `cancelled`/`rejected` که شما یکی از چهار نقشش هستید |
| «این مورد فروخته شده است.» | معامله‌ی `settled` وجود دارد |

**`void` در لیست استثنا نیست** — یعنی معامله‌ی باطل‌شده هم طرفینش را از ورود به صف همان مورد بلاک می‌کند. **[خواندن کد، اجرا نشده]**

اگر ورودی زنده داشته باشید همان برگردانده می‌شود، وگرنه یک ورودی `waiting` ساخته می‌شود. FIFO بر اساس `enteredAt`.

### ۶-۴) خروج از صف (`leaveQueue`)

`waiting`/`notified` → `declined` + `declinedAt`. اگر `notified` بوده، `advanceQueue` صدا زده می‌شود (نفر بعدی).

### ۶-۵) آزادسازی (`releaseItemInTx`) — قلب صف

مراحل به‌ترتیب (`:395-460`):

1. اگر یک ورودی `notified` زنده با claim **منقضی‌نشده** وجود دارد → **هیچ کاری نمی‌کند** (no-op).
2. گاردِ فراخوانیِ کهنه: اگر `from==='reserved'` ولی مورد دیگر `reserved` نیست، خارج می‌شود.
3. تا **۳ تلاش** برای بالا بردن قدیمی‌ترین ورودی `waiting` از run جاری.
4. اگر وضعیت فعلی `reserved` نیست، اول از حالت پنهان به `reserved` برمی‌گرداند.
5. اگر SELL باشد، `materialListing.feeDeadline = null` (`:437-439`) — **فقط داخل این حلقه‌ی ارتقا**.
6. ارتقا: `notifiedAt`، `claimExpiresAt = now + 1h`، `notificationTransactionId`.
7. اگر کسی در صف نباشد → `setItemStatus(current → active/open)` (`:458`) و `{finished:true, returnedToPool}`. **این مسیر `feeDeadline` را پاک نمی‌کند.**

### ۶-۶) چه وقت معامله‌ی لغوشده وارد صف می‌شود

`releaseItemInTx` در این حالت‌ها صدا زده می‌شود:

- لغو توسط **پذیرنده** (مسیرهای ۲ و ۴ از بخش ۵-۱)
- رد پیش‌نویس توسط فروشنده (`rejectDealOfferAction`)
- لغو خودکارِ اتمام مهلت (`cancelGuardedDealAndRelease` — خریدار یا فروشنده)
- شاخه‌ی پذیرنده در `rejectPaymentAction`
- تأیید ادمین روی مورد BUY در `needs_review` (`reviewPurchaseRequestAction`)
- جاروی انقضای claim (`enforceReservationQueueClaims` — فقط cron/دستی)

و **نمی‌شود** در این حالت‌ها:

- لغو توسط **درخواست‌دهنده** (مورد پنهان می‌شود، صف می‌خوابد)
- شاخه‌ی درخواست‌دهنده در `rejectPaymentAction` (مورد `closed`/`cancelled` + `closeRunInTx`)
- enforcer سطح آگهی legacy (لغو بدون آزادسازی)
- `confirmFundsReleased` — اینجا `closeRunInTx` صدا زده می‌شود و مورد `reserved` می‌ماند یعنی «فروخته شد»

سایر فراخوان‌های `closeRunInTx`: `admin-deals/actions.ts:94,400,472`، `admin-material-listings/actions.ts:94`، `market/actions.ts:107,193`، `purchase-requests/actions.ts:103`.

### ۶-۷) `resolveHoldAccess`

`market/actions.ts:30-52` → `'free'` (مورد آزاد است) یا `'claim'` (مورد `reserved` است ولی شما claim معتبر دارید که در همان تراکنش مصرف می‌شود).

### ۶-۸) اعلان‌ها

Novu فقط وقتی فعال است که هر سه متغیر `NOVU_SECRET_KEY` و `NOTIFICATION_PROVIDER=novu` و `NOVU_API_URL` تنظیم شده باشند. وگرنه stub است و فقط لاگ می‌زند.

**[نامشخص، نیاز به بررسی بیشتر]** آیا این سه در پروداکشن تنظیم شده‌اند.

---

## ۷) مسیرهای پرداخت

### ۷-۱) دو مسیر موازی

هر معامله **دو پرداخت مستقل** دارد. هیچ وابستگی ترتیبی بینشان در کد نیست.

**مسیر خریدار (`BUYER_GOODS`):**

1. معامله `draft` است. در رابط کاربری کارت پرداخت خریدار نشان داده **نمی‌شود** (`sellerHasDecided = status !== 'draft'`).
2. فروشنده قبول می‌کند → `confirmed` (یا `awaiting_approval` → ادمین تأیید → `confirmed`). `buyerConfirmDeadline` با ۷۲ ساعت کاری شروع می‌شود.
3. خریدار `/my-deals/[id]` → دکمه‌ی پرداخت → `DealPaymentModal`. مبلغ ردیف `BUYER_GOODS` نمایش داده می‌شود به‌همراه «راهنمای پرداخت (اعلامِ کارشناس)».
4. پرداخت بیرون از سایت. آپلود رسید → `uploadDealPaymentReceiptAction`.
5. گارد `receiptUrl: null` → `receiptUrl`, `submittedAt`, `status='SUBMITTED'`. اگر قبلاً رسید دارد: «رسید این پرداخت قبلاً ثبت شده.»
6. ادمین در `/admin-deals` تأیید می‌کند → `APPROVED` و `escrowStatus: 'pending' → 'secured_manual'`.
7. اگر **هر دو** ردیف `APPROVED` باشند و `Deal.status` در `['draft','awaiting_approval','confirmed']` باشد → `transport_pending` و `sellerFeeDeadline`/`buyerConfirmDeadline` پاک می‌شوند.

**مسیر فروشنده (`SELLER_FEE`):**

1. مبلغ ردیف `null` است. کارشناس مبلغ را اعلام می‌کند.
2. کارت پرداخت فروشنده **گیت `sellerHasDecided` ندارد** — فروشنده می‌تواند زودتر آپلود کند.
3. همان مراحل آپلود → `SUBMITTED` → تأیید ادمین → `APPROVED`.

**متن راهنمای پرداخت:** دو فیلد جداست. `updateDealPaymentInstructionsAction` (متن خریدار) و `updateSellerPaymentInstructionsAction` (متن فروشنده) در `/admin-deals` پشت یک `<details>` با عنوان «✏️ ویرایش دستور پرداخت». **هر طرف فقط متن خودش را می‌بیند.** اگر متن فروشنده خالی باشد، فروشنده **هیچ راهنمایی نمی‌بیند**. (کامنت‌های `schema.prisma:407-408` و `migration.sql:5` که می‌گویند «به متن خریدار برمی‌گردد» قدیمی‌اند.)

### ۷-۲) رد پرداخت

بخش ۵-۴ را ببینید. خلاصه: معامله → `void`، و اگر ردشده «پذیرنده» باشد جریمه می‌گیرد. متن تأیید در UI: «⚠️ رد این پرداخت معامله رو باطل می‌کنه…».

### ۷-۳) دو مسیر آپلود رسید وجود دارد

| مسیر | چه چیزی می‌نویسد | چه کسی صدا می‌زند |
|---|---|---|
| `uploadDealPaymentReceiptAction` (server action) | ردیف `DealPayment` (`receiptUrl`, `SUBMITTED`) | `DealPaymentModal.tsx` |
| `POST /api/payment-receipt` (مسیر قدیمی) | فیلد `Deal.paymentReceiptUrl` / `Order.paymentReceiptUrl` | `PaymentMethodModal.tsx:102` |

مسیر دوم **هیچ بررسی مالکیت، طرف معامله یا وضعیت ندارد**: فقط `getCurrentUserOrNull()` لازم است، بعد `entityType` (`'deal'` یا `'order'`) و `entityId` را از فرم می‌گیرد و مستقیم آپدیت می‌کند. یعنی **هر کاربر واردشده می‌تواند `paymentReceiptUrl` معامله یا سفارش دیگری را بازنویسی کند.** ضمناً ردیف `DealPayment` را لمس نمی‌کند، پس چنین رسیدی هرگز `SUBMITTED` نمی‌شود و در جدول بررسی ادمین ظاهر نمی‌شود. **[خواندن کد، اجرا نشده]**

**[نامشخص، نیاز به بررسی بیشتر]** کدام صفحه‌ها `PaymentMethodModal` را رندر می‌کنند.

**ذخیره‌سازی رسید:** `public/uploads/receipts/<32-hex>.<ext>` — یعنی **زیر پوشه‌ی public و با URL مستقیم قابل دریافت** اگر کسی آدرسش را بداند (نام تصادفی ۱۲۸ بیتی است). پسوندهای مجاز `jpg|jpeg|png|pdf` **فقط از روی نام فایل** گرفته می‌شوند؛ هیچ بررسی محتوایی نیست. سقف ۵ مگابایت.

### ۷-۴) دور زدن تأیید قیمت [خواندن کد، اجرا نشده]

`approvePaymentAction` وضعیت Deal را چک نمی‌کند (فقط وضعیت ردیف را)، و گیت UI آپلود رسید خریدار `status !== 'draft'` است. نتیجه: در `awaiting_approval` هم می‌توان رسید آپلود کرد و تأیید کرد، و معامله بدون اینکه مدیر قیمت را تأیید کرده باشد (`approveDealAction`) به `transport_pending` می‌رود.

---

## ۸) جریان حمل و نقل و راننده

### ۸-۱) ساخت لینک

`assignDriverAction` (`admin-logistics/actions.ts:193-268`):

- فقط `void`/`cancelled` را بلاک می‌کند.
- شرکت حمل، راننده‌ی فعالِ همان شرکت و اینکه راننده الان راننده‌ی فعال نباشد را چک می‌کند.
- در یک `$transaction`: انتساب قبلی `replacedAt` می‌گیرد، انتساب جدید، `deal.driverId`، و یک `DriverAccessLink` با **۴۸ ساعت** اعتبار.
- پیامک (که فعلاً stub است).
- **لینک‌های قبلی باطل نمی‌شوند.**

`regenerateDriverLinkAction` (`:117-156`) — «ساخت دوباره‌ی لینک»:

- **هیچ بررسی وضعیت Deal ندارد.**
- شماره را از آخرین `DealConfirmation` با `driverPhone` یا آخرین `DriverAccessLink.phone` می‌گیرد؛ اگر هیچ‌کدام نبود: «شماره‌ی تماس راننده برای این معامله موجود نیست — اول باید یه تأییدیه یا لینک قبلی داشته باشه.»
- توکن `crypto.randomBytes(24)`، اعتبار ۴۸ ساعت، پیامک با آدرس `/driver/t/${token}`.

`validateDriverToken` فقط سه چیز را رد می‌کند: ناشناخته، **استفاده‌شده**، منقضی.

### ۸-۲) دو صفحه‌ی راننده

- `/driver/t/[token]` — پذیرش/رد سفر.
  - پذیرش: `driver_accepted` + شماره + مختصات، **`markDriverLinkUsed(token)`** (`:53`)، پاک کردن `driverSilenceFlaggedAt`، پیامک، redirect به `?accepted=1`.
  - رد: `driver_rejected` (دلیل در `checklistJson`)، **لینک مصرف نمی‌شود** (`:93`)، پیامک، redirect به `?rejected=1`.
  - دکمه‌ی «رفتن به فرم بارگیری/تخلیه» به `/driver/${token}` لینک می‌دهد (`:133`).
- `/driver/[token]` — فرم بارگیری/تخلیه.
  - `formType='loading'` فقط برای `confirmed || payment_secured`؛ `'unloading'` برای `in_transit`.
  - وگرنه: «الان کاری برای ثبت نیست» + «وضعیت فعلی این معامله («{deal.status}») نیازی به فرم بارگیری یا تخلیه نداره.»

### ۸-۳) دو مشکل جدی [خواندن کد، اجرا نشده]

**الف) فرم بارگیری برای `transport_pending` وجود ندارد.**
`transport_pending` دقیقاً همان وضعیتی است که بارگیری باید آنجا اتفاق بیفتد، ولی `driver/[token]/page.tsx:24` فقط `confirmed` و `payment_secured` را قبول می‌کند و `payment_secured` هیچ‌وقت نوشته نمی‌شود. در جریان عادی v2، راننده با «الان کاری برای ثبت نیست» و وضعیت خام روبه‌رو می‌شود. تنها حالتی که کار می‌کند این است که وضعیت هنوز `confirmed` باشد و پرداخت خریدار تأیید شده باشد (چون `submitDealConfirmation` برای بارگیری **فقط** `escrowStatus === 'secured_manual'` را چک می‌کند، `:47-52`). v2 عمداً این صفحه را دست نزده (`NOTES-DEAL-FLOW-V2.md:126`، `NOTES-DRIVER-LINK-SMS-DASHBOARD.md:60`).

**ب) لینک بعد از پذیرش مصرف می‌شود و بنر هرگز دیده نمی‌شود.**
بعد از زدن «پذیرش»، `markDriverLinkUsed` اجرا می‌شود و redirect به `?accepted=1` می‌رود — ولی همان صفحه دوباره `validateDriverToken` را صدا می‌زند و «دسترسی ممکن نیست — این لینک قبلاً استفاده شده.» نشان می‌دهد. بنر موفقیت هرگز نمایش داده نمی‌شود و دکمه‌ی رفتن به فرم بارگیری هم با همان توکنِ مصرف‌شده کار نمی‌کند. ثبت فرم بارگیری هم لینک را مصرف می‌کند، پس برای تخلیه ادمین باید «ساخت دوباره‌ی لینک» را بزند. **هیچ بازسازی خودکاری وجود ندارد.**

`/driver/[token]/done` یک صفحه‌ی ثابتِ «✓ ثبت شد، متشکریم» است و هیچ توکنی را اعتبارسنجی نمی‌کند.

### ۸-۴) ناسازگاری فیلتر وضعیت‌ها

| فایل | وضعیت‌های فعال |
|---|---|
| `admin-logistics/page.tsx:62` | شامل `transport_pending` ✔ |
| `api/driver-location/route.ts:9` | شامل `transport_pending` ✔ |
| `transport-panel/page.tsx:9` و `transport-panel/current/page.tsx:8` | **`transport_pending` ندارد** ✘ |

`ACTIVE_STATUSES = ['payment_secured','loading','in_transit']` — که دوتایش هرگز نوشته نمی‌شوند. پس پنل شرکت حمل معامله‌های در انتظار بارگیری را نشان نمی‌دهد. **[خواندن کد، اجرا نشده]**

### ۸-۵) پیامک

`sendSms` (`src/lib/sms.ts:35-53`) به `sendViaStub` می‌رسد و فقط لاگ می‌زند: `[SMS STUB — سرویس واقعی وصل نشده]`. سوییچ provider فقط کد Kavenegarِ کامنت‌شده دارد. `queueSms` هم مستقیم `sendSms` را صدا می‌زند و `enforcePendingSmsQueue` صفر برمی‌گرداند. کامنت‌های «در صف ۶۰ دقیقه‌ای» (`admin-logistics/actions.ts:147,261`، `driver/t/[token]/actions.ts:63`) آرزویی‌اند.

**[نامشخص، نیاز به بررسی بیشتر]** آیا در پروداکشن provider واقعی تنظیم شده.

---

## ۹) مغایرت و اختلاف

### ۹-۱) گزارش مغایرت

`reportDiscrepancyAction` (`my-deals/actions.ts:138`) → فقط خریدار. **هیچ بررسی وضعیت یا پنجره‌ی زمانی سمت سرور ندارد**؛ فقط UI گیت می‌گذارد (`my-deals/[id]/page.tsx:94-98`: `delivered` و `discrepancyReportDeadline` در آینده و `qualityAutoAccepted === false`).

`submitDiscrepancyReport` (`lib/disputes.ts:25-71`):

1. یک `DealConfirmation` از نوع `buyer_confirm` با `discrepancy_severe` یا `discrepancy_minor` می‌سازد.
2. `deal.update({qualityAutoAccepted: true, fundReleaseFrozen: isSevere})` — **رونویسی**، پس یک گزارش minorِ بعدی می‌تواند freeze یک گزارش severe را پاک کند.
3. اگر severe باشد، یک `Dispute{status:'open'}` هم می‌سازد.

| حساس (severe) | جزئی (minor) |
|---|---|
| کسری وزن بیش از ۵۰ کیلوگرم | کسری وزن کمتر از ۱ کیلوگرم |
| بسته‌بندی ناقص یا اشتباه | باز بودن shrink-wrap |
| عدم تطابق گرید/محصول | شکستگی جزئی پالت |
| تقلب مشهود | خیسی ناشی از باران |

### ۹-۲) معنی واقعی `qualityAutoAccepted`

`schema.prisma:393` می‌گوید «مغایرتی گزارش نشده». ولی `submitDiscrepancyReport` هم وقتی گزارش **ثبت می‌شود** آن را `true` می‌گذارد. پس معنی واقعی‌اش «پنجره‌ی مغایرت رسیدگی شد» است، نه «مغایرتی نبود».

### ۹-۳) `fundReleaseFrozen` فقط نمایشی است

- **تنها نویسنده:** `lib/disputes.ts:55`
- **تنها خواننده‌ها:** `admin-deals/page.tsx:464`, `:465`, `:548` — همه نمایشی

`admin-deals/actions.ts` هیچ ارجاعی به آن ندارد. یعنی **هرگز جلوی `confirmFundsReleased` را نمی‌گیرد** و **هیچ چیز هم پاک‌ش نمی‌کند** جز یک گزارش minorِ بعدی. **[خواندن کد، اجرا نشده]**

### ۹-۴) حل اختلاف

مسیر زنده: `admin-disputes/actions.ts:resolveDisputeAction` (`:32-49`).

```ts
await prisma.dispute.update({ where: { id: disputeId },
  data: { status, resolution, resolvedById, resolvedAt } })
```

- دسترسی: ادمین، یا کاربر با دسترسی بخش `disputes` در سطح edit/full.
- `status` **مستقیم از فرم گرفته می‌شود، بدون هیچ لیست مجاز**.
- **فقط ردیف Dispute را آپدیت می‌کند** — نه Deal، نه `fundReleaseFrozen`.

پس تمام اثرهای سمت معامله (آزادسازی، بازپرداخت، رفع freeze) کاملاً دستی و بیرون از سایت است.

`exportDisputeEvidenceAction` (`:51-278`) یک صفحه‌ی HTML چاپ‌پذیر راست‌به‌چپ می‌سازد: طرفین، جزئیات معامله، تایم‌لاین تأییدیه‌ها، عکس‌ها، اختلاف‌ها و لاگ‌های سیستمی که شناسه‌ی معامله را دارند + دکمه‌ی «چاپ / ذخیره به PDF». قیمت را «تومان/کیلوگرم» برچسب می‌زند.

`resolveDispute` در `lib/disputes.ts:77-92` **هیچ فراخوانی ندارد** (کد مرده). `Dispute.status` پیش‌فرض `open` (`schema.prisma:631`: `open | resolved | rejected`).

**[نامشخص، نیاز به بررسی بیشتر]** صفحه‌ی `admin-disputes/page.tsx` دقیقاً چه چیزی نشان می‌دهد.

---

## ۱۰) جدول تناقض‌ها: «مستند می‌گفت X، کد واقعی Y می‌کند»

| # | مستند می‌گفت | کد واقعی | منبع | وضعیت |
|---|---|---|---|---|
| ۱ | پول فروشنده **فقط بعد از تأیید بارگیری واقعی** آزاد می‌شود | `confirmFundsReleased` فقط `escrowStatus==='secured_manual'` و وضعیت ∉ void/cancelled/settled را چک می‌کند؛ دکمه هم با همان شرط ظاهر می‌شود. آزادسازی در `confirmed`/`transport_pending` و **قبل از بارگیری** ممکن است. یک فرایند انسانی است، نه اجبار سیستمی. نیمه‌ی «سایت پول جابه‌جا نمی‌کند» درست است | `HANDOFF.md:108` / `admin-deals/actions.ts:74-86`, `page.tsx:757` | تأییدشده |
| ۲ | معامله‌های BUY در `draft` می‌مانند و مستقیم به `transport_pending` می‌روند؛ `awaiting_approval`/`confirmed` آرتیفکت legacy است | `acceptDealOfferAction` هر `draft` با `isDealSeller` را به `confirmed`/`awaiting_approval` می‌برد و `my-deals/page.tsx:44-48` draftهای BUY را به فروشنده نشان می‌دهد. BUY **به `confirmed` می‌رسد** و فقط آنجا `sellerFeeDeadline` می‌گیرد. خودِ V2 هم این اکشن را در `:101` لیست کرده | `NOTES-DEAL-FLOW-V2.md:161-177` / `my-deals/actions.ts:29`, `dealDeadlines.ts:473` | تأییدشده |
| ۳ | cron نداریم؛ اجرا فقط lazy روی `/admin-deals` | چهار صفحه lazy صدا می‌زنند، **به‌علاوه** `POST /api/enforce-deadlines` و دکمه‌ی دستی که `runDeadlineEnforcement` را اجرا می‌کنند (و فقط آن مسیر انقضای صف، مهلت پیش‌فاکتور و هشدار قیمت را اجرا می‌کند) | `HANDOFF.md:158` / `dealDeadlines.ts:357`, `NOTES-DEAL-DEADLINE-SCHEDULER.md` | تأییدشده |
| ۴ | هر دو طرف **متقارن** ۲۴ ساعت محدود می‌شوند | مسیر فروشنده `restrictUser` (بیشینه‌ی فعلی و جدید). مسیر خریدار `user.update` مستقیم و **رونویسی** → می‌تواند محدودیت طولانی‌تر را کوتاه کند. مسیر legacy فروشنده هم رونویسی است | `HANDOFF.md:114` / `dealDeadlines.ts:444-459`, `:206`, `:166` | تأییدشده |
| ۵ | بعد از `fundReleaseDeadline` **پرداخت خودکار** انجام می‌شود | مهلت فقط پرچم نمایشی `fundReleaseDue`/`isFlagged` می‌سازد؛ آزادسازی دستی است | `schema.prisma:387-388` / `admin-deals/page.tsx:464-465` | تأییدشده |
| ۶ | (ضمنی) اختلاف که حل شود معامله تعیین تکلیف می‌شود | `resolveDisputeAction` فقط ردیف Dispute را آپدیت می‌کند؛ `fundReleaseFrozen` نه مانع آزادسازی است نه هیچ‌جا پاک می‌شود | `admin-disputes/actions.ts:32-49` / `admin-deals/page.tsx:464,465,548` | تأییدشده |
| ۷ | `deliveryConfirmDeadline` و `Deal.approvalLevel` فیلدهای فعال‌اند | **مرده‌اند** — هیچ‌جا نوشته یا خوانده نمی‌شوند. `startBuyerPaymentDeadline` مقدار `approvalLevel` را حساب و دور می‌ریزد. ستون ادمین همیشه `—` است | `schema.prisma:369`, `:374` | تأییدشده |
| ۸ | `feeDeadline` «از لحظه‌ای که خریدار پیدا شد و ادمین قیمت را تأیید کرد» شروع می‌شود | `feeDeadline` **موقع ساخت معامله توسط خریدار** گذاشته می‌شود (`market/actions.ts:138`)، و enforcer سطح آگهی اول اجرا می‌شود و هنوز زنده است. `feeStatus` هرگز نوشته نمی‌شود (همیشه `unpaid`). هیچ‌چیز موقع تأیید کارمزد پاکش نمی‌کند | `schema.prisma:918` / `dealDeadlines.ts:142-179` | تأییدشده — اصلاح شد: ساعتِ آگهی روی معامله‌ی `confirmed` دارای T1 اعمال نمی‌شود |
| ۹ | دو ساعت **پشت سر هم**‌اند (اول کارمزد فروشنده، بعد پرداخت خریدار) | از `confirmed` **موازی** اجرا می‌شوند. ضمناً `enforceDealSellerFeeDeadlines` چک نمی‌کند `SELLER_FEE` تأیید شده باشد → فروشنده‌ای که پرداخته ولی تأییدش دیر شده هم لغو و جریمه می‌شود | `schema.prisma:382` / `dealDeadlines.ts:107-133,185-214` | خواندن کد، اجرا نشده — بخش «لغو/جریمه‌ی فروشنده‌ی دارای `SELLER_FEE` تأییدشده» اصلاح شد؛ موازی‌بودنِ T1 و مهلت خریدار همان است |
| ۱۰ | راننده در `transport_pending` بارگیری را ثبت می‌کند | فرم بارگیری فقط برای `confirmed`/`payment_secured` رندر می‌شود؛ `transport_pending` فرم ندارد و `payment_secured` هرگز نوشته نمی‌شود | `NOTES-DEAL-FLOW-V2.md:126` / `driver/[token]/page.tsx:24` | خواندن کد، اجرا نشده |
| ۱۱ | بعد از پذیرش راننده، بنر موفقیت و دکمه‌ی فرم بارگیری کار می‌کنند | لینک موقع پذیرش مصرف می‌شود؛ صفحه‌ی مقصد دوباره توکن را اعتبارسنجی می‌کند و «قبلاً استفاده شده» می‌دهد | `NOTES-DRIVER-LINK-SMS-DASHBOARD.md:56` / `driver/t/[token]/actions.ts:53`, `driverAccess.ts:29` | خواندن کد، اجرا نشده |
| ۱۲ | پنل شرکت حمل همه‌ی معامله‌های فعال را نشان می‌دهد | `transport-panel` فقط `['payment_secured','loading','in_transit']` را می‌گیرد که `transport_pending` ندارد و دوتایش هرگز نوشته نمی‌شوند | `transport-panel/page.tsx:9` / در برابر `admin-logistics/page.tsx:62` | خواندن کد، اجرا نشده |
| ۱۳ | زنجیره‌ی وضعیت: `draft → confirmed → seller_fee_paid → payment_secured → transport_pending → loading → in_transit → delivered → settled` | فقط `draft, awaiting_approval, confirmed, transport_pending, in_transit, delivered, settled, cancelled, void` نوشته می‌شوند. `seller_fee_paid, payment_secured, loading, rejected` هرگز | `schema.prisma:376-379`, `NOTES-DEAL-FLOW-FIXES-2.md:13` | تأییدشده |
| ۱۴ | آپلود رسید فقط در وضعیت مجاز ممکن است | `uploadDealPaymentReceiptAction` **هیچ بررسی وضعیت Deal ندارد**؛ گیت UI فقط `status !== 'draft'` است که برای `cancelled`/`void`/`settled` هم true است. `approvePaymentAction` هم وضعیت Deal را چک نمی‌کند | `my-deals/actions.ts:88`, `my-deals/[id]/page.tsx:81-83` | خواندن کد، اجرا نشده |
| ۱۵ | گزارش مغایرت فقط در پنجره‌ی زمانی ممکن است | سمت سرور هیچ گیت وضعیت/پنجره‌ای ندارد؛ فقط UI جلوی آن را می‌گیرد | `my-deals/actions.ts:138` / `my-deals/[id]/page.tsx:94-98` | تأییدشده |
| ۱۶ | طرفین معامله‌ی باطل‌شده می‌توانند دوباره وارد صف شوند | `enterQueue` فقط `cancelled`/`rejected` را استثنا کرده؛ `void` طرفینش را بلاک می‌کند و `settled` همه را | `reservationQueue.ts:210-218` | خواندن کد، اجرا نشده |
| ۱۷ | پیامک در صف ۶۰ دقیقه‌ای می‌رود | `queueSms` مستقیم `sendSms` را صدا می‌زند و آن فقط لاگ `[SMS STUB — سرویس واقعی وصل نشده]` می‌زند | کامنت‌های `admin-logistics/actions.ts:147,261` / `sms.ts:35-53` | تأییدشده |
| ۱۸ | مقدار وضعیت `'needs_approval'` است | کد `'awaiting_approval'` می‌نویسد. ضمناً اگر `agreedPrice` صفر یا null باشد کلاً بررسی تأیید رد می‌شود | `priceEngine.ts:21-23` / `dealDeadlines.ts:486` | تأییدشده |
| ۱۹ | کامنت‌ها: `startSellerFeeDeadline` «موقع تأیید ادمین روی یک رزرو» و `startBuyerPaymentDeadline` «موقع تأیید کارمزد فروشنده» | اولی **موقع ساخت معامله توسط خریدار** صدا زده می‌شود، دومی **موقع قبول پیش‌نویس توسط فروشنده** (یا `approveDealAction`) | `dealDeadlines.ts:461`, `:472` | تأییدشده |
| ۲۰ | دسترسی‌های `/admin-deals` یکدست است | `approveDealAction` فقط ادمین با `Error` ساده؛ سه اکشن پرداخت/درخواست **هر staff** بدون بررسی بخش؛ دو اکشن دیگر `requireDealsEditAccess` | `admin-deals/actions.ts:27,34,252,281,353,447` | تأییدشده |
| ۲۱ | فروشنده معامله‌هایش را در `/my-deals` می‌بیند | لیست اصلی **فقط** `buyerId === user.id` است. معامله‌های غیرdraft فروشنده در لیست نیستند (فقط با URL مستقیم). `receivedOffers` فقط draftها را می‌آورد | `my-deals/page.tsx:37-48` | تأییدشده |
| ۲۲ | `draft` یعنی «در انتظار تأیید کارشناس» | گیت واقعی **تصمیم فروشنده** است، نه کارشناس | `my-deals/[id]/page.tsx:25,164` | تأییدشده |
| ۲۳ | کارشناس می‌تواند همه‌ی مهلت‌ها را اصلاح کند | فقط `buyerConfirmDeadline`, `discrepancyReportDeadline`, `fundReleaseDeadline`. **`sellerFeeDeadline` ندارد** | `admin-deals/page.tsx:740-750` | تأییدشده |
| ۲۴ | پول پرداخت تأییدشده در صورت لغو برمی‌گردد | هیچ کدی بازپرداخت نمی‌کند؛ کل بخش پول بیرون از سایت است | کل `admin-deals/actions.ts` | تأییدشده |
| ۲۵ | `awaiting_approval` یک گیت واقعی تأیید قیمت است | `approvePaymentAction` آن را می‌پذیرد و آپلود رسید هم در آن وضعیت ممکن است → هر دو پرداخت `APPROVED` و معامله `transport_pending` بدون اینکه مدیر قیمت را تأیید کند. تأیید پرداخت هم رسید نمی‌خواهد | `admin-deals/actions.ts:281-334` | خواندن کد، اجرا نشده |
| ۲۶ | رد پرداخت فقط برای رسیدهای بررسی‌نشده و معامله‌های فعال | `rejectPaymentAction` ردیف `APPROVED` را هم می‌پذیرد و هر وضعیتی جز `void`/`cancelled` را `void` می‌کند — شامل `delivered` و `settled`. در شاخه‌ی پذیرنده `releaseItemInTx` هم صدا می‌زند که می‌تواند یک موردِ **فروخته‌شده** را دوباره به صف/بازار برگرداند. UI فقط برای `PENDING|SUBMITTED` دکمه‌ی رد نشان می‌دهد | `admin-deals/actions.ts:353-436` | خواندن کد، اجرا نشده |
| ۲۷ | معامله‌های بی‌پاسخ خودکار منقضی می‌شوند | هیچ enforcer‌ای `draft` یا `awaiting_approval` را منقضی نمی‌کند. draftِ BUY می‌تواند تا ابد بماند | `dealDeadlines.ts:54-66` | تأییدشده |
| ۲۸ | «قبل از بارگیری» قابل لغو است | `CANCELABLE_STATUSES` شامل `transport_pending` نیست؛ از آن لحظه هیچ طرفی نمی‌تواند لغو کند | `my-deals/actions.ts:21-22` | تأییدشده |
| ۲۹ | همه‌ی وضعیت‌ها برچسب فارسی دارند | `STATUS_LABELS` در `/admin-deals` **`cancelled` ندارد** → کارت ادمین رشته‌ی انگلیسی خام نشان می‌دهد. `reviewablePayments` هم فقط معامله‌های `confirmed` را می‌آورد، پس رسیدهای `draft`/`awaiting_approval` فقط از کارت طرفین قابل بررسی‌اند | `admin-deals/page.tsx:19-23,505,104-110` | تأییدشده |
| ۳۰ | `qualityAutoAccepted=true` یعنی مغایرتی گزارش نشده | هنگام ثبت گزارش مغایرت هم `true` می‌شود؛ معنی واقعی «پنجره رسیدگی شد» است | `schema.prisma:393` / `lib/disputes.ts:54` | تأییدشده |
| ۳۲ | جمعه تعطیل است | فقط در **نمایش** تنظیمات (`listWeeklyBusinessHours:136`). موتور محاسبه هر روزِ تنظیم‌نشده — از جمله جمعه — را **باز ۰۸:۰۰–۱۷:۰۰** حساب می‌کند (`:53-54`). تا وقتی ادمین تقویم را ذخیره نکند، مهلت‌ها روی تقویم ۷ روزه‌اند | `businessHours.ts` | خواندن کد، اجرا نشده |
| ۳۳ | پذیرش درخواست خرید توسط فروشنده معامله را نهایی می‌کند | معامله `draft` ساخته می‌شود و همان فروشنده باید **دوباره** در `/my-deals` قبول کند؛ هم‌زمان خریدار draft را در لیست اصلی خود می‌بیند | `market/actions.ts:201-207`, `my-deals/actions.ts:29` | خواندن کد، اجرا نشده |
| ۳۴ | رفتار لغو/رد یکسان است | ردِ `draft` توسط فروشنده‌ی SELL → مورد مستقیم به صف/بازار، بدون جریمه و بدون بررسی. لغوِ بعدیِ همان شخص → `needs_reverification` و خوابیدن تا بررسی ادمین | `my-deals/actions.ts:53`, `:172` | تأییدشده |
| ۳۵ | `resolveDispute` اختلاف را حل می‌کند | آن تابع در `lib/disputes.ts:77-92` **هیچ فراخوانی ندارد**. مسیر زنده `resolveDisputeAction` است و `status` را بدون لیست مجاز از فرم می‌گیرد و هیچ اثری روی Deal ندارد | `lib/disputes.ts` / `admin-disputes/actions.ts:32` | تأییدشده |
| ۳۶ | کاربر محدود نمی‌تواند کاری در معامله بکند | محدودیت فقط در ساخت آگهی، پیشنهاد روی آگهی، پذیرش درخواست خرید و ورود به صف چک می‌شود. **نه** در قبول پیش‌نویس، لغو، آپلود رسید و جریان راننده | `market/actions.ts:65,165,258` / `my-deals/actions.ts` | تأییدشده |
| ۳۷ | وضعیت‌های درخواست خرید: `open | reserved | closed | expired` | کد `needs_review` هم می‌نویسد (`cancelDealAction:210`, `reviewPurchaseRequestAction`, `reservationQueue.ts`) | `schema.prisma:957` | تأییدشده |
| ۳۸ | با جایگزینی راننده، لینک قبلی از کار می‌افتد | نه `assignDriverAction` نه `regenerateDriverLinkAction` لینک‌های قبلی را باطل می‌کنند. `validateDriverToken` فقط ناشناخته/استفاده‌شده/منقضی را رد می‌کند → لینک راننده‌ی جایگزین‌شده تا استفاده یا ۴۸ ساعت معتبر می‌ماند | `admin-logistics/actions.ts:117,193` | خواندن کد، اجرا نشده |
| ۳۹ | `/api/payment-receipt` یک مسیر قدیمیِ کنارگذاشته‌شده است | هنوز `PaymentMethodModal.tsx:102` صدایش می‌زند و **هیچ بررسی مالکیت/طرف/وضعیت ندارد**: هر کاربر واردشده می‌تواند `paymentReceiptUrl` معامله یا سفارش دیگری را بازنویسی کند. ضمناً ردیف `DealPayment` را آپدیت نمی‌کند، پس رسید در جدول بررسی ادمین دیده نمی‌شود | `api/payment-receipt/route.ts`, `lib/paymentReceipt.ts` | خواندن کد، اجرا نشده |
| ۴۰ | متن راهنمای پرداخت فروشنده به متن خریدار برمی‌گردد | هر طرف فقط متن خودش را می‌بیند. اگر `sellerPaymentInstructionsText` خالی باشد فروشنده **هیچ راهنمایی نمی‌بیند**. کامنت‌های `schema.prisma:407-408` و `migration.sql:5` قدیمی‌اند | `NOTES-SELLER-PAYMENT-NOVU-JS.md` / `my-deals/[id]/page.tsx` | تأییدشده |
| ۴۱ | مهاجرت دیتابیس v2 انجام شده | `DEPLOY-README-DEAL-FLOW-V2.md` صریحاً می‌گوید در فاز کد migrate/`db push` اجرا نشده و `to_regclass('"DealPayment"')` باید غیرتهی باشد. هیچ سندی اثبات نمی‌کند روی پروداکشن اعمال شده | `DEPLOY-README-DEAL-FLOW-V2.md` | نامشخص |

**یادداشت (تناقض نیست):** ردیف ۳۱ از فهرست اولیه یک یادداشت بود نه تناقض — `admin-deals/actions.ts` و `page.tsx` حین بررسی ویرایش شدند و شماره‌خط‌ها از وضعیت ۰۴:۳۸ است.

---

## ۱۱) فهرست «نامشخص، نیاز به بررسی بیشتر»

این موارد در کد پاسخ قطعی ندارند یا به داده‌ی واقعی/سرور بستگی دارند:

1. **نصب cron در پروداکشن.** فقط `scripts/enforce_deadlines.py` مقدار `*/15 * * * *` را مستند کرده؛ اثبات نصب نیست.
2. **provider پیامک واقعی در پروداکشن.** کد فقط stub نشان می‌دهد و به `SMS_PROVIDER` بستگی دارد.
3. **تنظیم بودن Novu** (`NOVU_SECRET_KEY`, `NOTIFICATION_PROVIDER=novu`, `NOVU_API_URL`).
4. **معنی واحد `agreedPrice`.** صفحه‌ها قیمت را «تومان/کیلوگرم» و «تومان/کیلو» برچسب می‌زنند (`my-deals/page.tsx:92`, `:127`)، ولی مودال پرداخت `payment.amount` را «X تومان» نشان می‌دهد. کل مبلغ یا فی؟ مبهم است.
5. **وجود ردیف `approvalRule` برای entity = 'Deal' در دیتابیس واقعی.** این تعیین می‌کند `awaiting_approval` اصلاً در پروداکشن قابل رسیدن هست یا نه.
6. **مسیر بررسی ادمین برای آگهی SELL در `needs_reverification`** — چیزی جز `updateListingStatusAction` پیدا نشد.
7. **بازپرداخت.** هیچ کدی وجود ندارد.
8. **معامله‌های قدیمی بدون `sellerId`.** اکشن آپلود رسید فروشنده را رد می‌کند در حالی که UI دکمه را نشان می‌دهد.
9. **محتوای دقیق `admin-disputes/page.tsx`.** فقط فراخوانی `findMany` در `:50` دیده شد.
10. **آیا ساخت درخواست خرید `isUserRestricted` را چک می‌کند.**
11. **کدام صفحه‌ها `PaymentMethodModal` را رندر می‌کنند** (و در نتیجه از `/api/payment-receipt` استفاده می‌کنند).
12. **اعمال‌شده بودن مهاجرت v2 روی پروداکشن** (`DealPayment` و ستون‌های نقش).
13. **محتوای `NOTES-TRANSPORT-SHIPMENTS-PAGES.md` و `DESIGN_SYSTEM_SPEC_FA.md`.** این دو خوانده نشدند (هرکدام ۲ برخورد با کلیدواژه‌های وضعیت معامله دارند).
14. **تأیید زمان‌اجرا (runtime) همه‌ی موارد برچسب‌خورده به «خواندن کد، اجرا نشده».** در این بررسی هیچ دیتابیسی در دسترس نبود.

---

## ۱۲) فهرست مرجع فایل‌ها

| فایل | نقش |
|---|---|
| `src/lib/dealRoles.ts` | نگاشت چهار نقش، `resolveSellerId`, `isDealSeller` |
| `src/lib/dealDeadlines.ts` | همه‌ی enforcerها، `restrictUser`, `runDeadlineEnforcement` |
| `src/lib/reservationQueue.ts` | صف رزرو، `releaseItemInTx`, `enterQueue`, `leaveQueue` |
| `src/lib/businessHours.ts` | موتور ساعت کاری |
| `src/lib/tehranClock.ts` | ساعت تهران، نگاشت شاخص روز هفته |
| `src/lib/disputes.ts` | `submitDiscrepancyReport` (+ `resolveDispute` مرده) |
| `src/lib/paymentReceipt.ts` | ذخیره و اتصال رسید |
| `src/lib/sms.ts`, `src/lib/smsQueue.ts` | پیامک (stub) |
| `src/lib/driverAccess.ts` | توکن راننده، `LINK_VALID_HOURS=48` |
| `src/lib/priceEngine.ts` | `evaluateApprovalRequirement` |
| `src/app/market/actions.ts` | ساخت معامله (SELL/BUY)، ورود/خروج صف |
| `src/app/my-deals/actions.ts` | قبول/رد/لغو/رسید/مغایرت (سمت کاربر) |
| `src/app/admin-deals/actions.ts` | تأیید قیمت، تأیید/رد پرداخت، آزادسازی وجه، قوانین |
| `src/app/admin-disputes/actions.ts` | حل اختلاف، خروجی شواهد |
| `src/app/admin-logistics/actions.ts` | شرکت حمل، راننده، لینک |
| `src/app/driver/[token]/actions.ts` | فرم بارگیری/تخلیه |
| `src/app/driver/t/[token]/actions.ts` | پذیرش/رد سفر |
| `src/app/api/enforce-deadlines/route.ts` | endpoint زمان‌بند |
| `src/app/api/payment-receipt/route.ts` | مسیر قدیمی آپلود رسید |
| `prisma/schema.prisma` | مدل‌ها (`Deal:357`, `DealPayment:452`, `Order:799`) |
