'use server'

import prisma from '@/lib/prisma'
import {
  validateDriverToken,
  markDriverLinkUsed,
  extendDriverLinkForTrip,
  driverFormTypeForStatus,
  bothPaymentsApproved,
  DRIVER_LOADING_STATUSES,
  DRIVER_REQUIRED_PAYMENT_KINDS,
} from '@/lib/driverAccess'
import { startPostUnloadingClocks, getDealRuleSettings } from '@/lib/dealDeadlines'
import { queueSms } from '@/lib/smsQueue'
import fs from 'fs/promises'
import path from 'path'
import crypto from 'crypto'
import { redirect } from 'next/navigation'

const UPLOAD_ROOT = path.join(process.cwd(), 'public', 'uploads', 'deals')

/**
 * ذخیره‌ی عکس روی دیسک محلی سرور (نه فضای ابری) — چون هنوز فاز Storage
 * واقعی نساختیم. برای همین حجم فعلی کاملاً کافیه؛ وقتی حجم بار زیاد شد،
 * این تابع باید با یه سرویس ابری جایگزین بشه (فقط همین یه تابع، بقیه‌ی
 * کد دست‌نخورده می‌مونه چون همه‌جا فقط از photoUrl استفاده می‌کنن).
 */
async function savePhotoToLocalDisk(dealId: string, file: File): Promise<string> {
  const dealDir = path.join(UPLOAD_ROOT, dealId)
  await fs.mkdir(dealDir, { recursive: true })

  const ext = (file.name.split('.').pop() || 'jpg').toLowerCase().replace(/[^a-z0-9]/g, '') || 'jpg'
  const fileName = `${Date.now()}-${crypto.randomBytes(4).toString('hex')}.${ext}`
  const filePath = path.join(dealDir, fileName)

  const buffer = Buffer.from(await file.arrayBuffer())
  await fs.writeFile(filePath, buffer)

  return `/uploads/deals/${dealId}/${fileName}`
}

/**
 * ثبت بارگیری یا تخلیه توسط راننده. یک لینک برای کل مسیر است (پذیرش ← بارگیری ← تخلیه):
 * بعد از بارگیری لینک زنده می‌ماند (انقضا جلو می‌رود) و فقط با تخلیه مصرف می‌شود.
 */
export async function submitDealConfirmation(formData: FormData) {
  const token = String(formData.get('token') || '')
  const type = String(formData.get('type') || '') // loading | unloading
  if (type !== 'loading' && type !== 'unloading') {
    throw new Error('نوع ثبت نامعتبر است.')
  }

  const { valid, link } = await validateDriverToken(token)
  if (!valid || !link) {
    throw new Error('لینک نامعتبر یا منقضی‌شده — فرم ثبت نشد.')
  }

  const dealId = link.dealId

  // نوعِ فرم باید با وضعیتِ فعلیِ معامله بخواند: بارگیری فقط قبل از حرکت، تخلیه فقط در مسیر.
  // (قبلاً type بی‌چک پذیرفته می‌شد و مثلاً تخلیه روی معامله‌ی بارگیری‌نشده هم ثبت می‌شد.)
  const deal = await prisma.deal.findUnique({
    where: { id: dealId },
    select: { status: true, escrowStatus: true, payments: { select: { kind: true, status: true } } },
  })
  if (!deal) throw new Error('معامله پیدا نشد.')
  if (driverFormTypeForStatus(deal.status) !== type) {
    throw new Error('وضعیت فعلی معامله ثبت این مرحله را اجازه نمی‌دهد (ممکن است قبلاً ثبت شده باشد).')
  }

  // دروازه‌ی بارگیری: تا وقتی حسابداری پرداخت خریدار رو تایید نکرده،
  // بارگیری اصلاً نباید شروع بشه — طبق تصمیم صریح سینا.
  if (type === 'loading' && deal.escrowStatus !== 'secured_manual') {
    throw new Error('پرداخت خریدار هنوز توسط حسابداری تایید نشده — بارگیری قابل ثبت نیست.')
  }
  // فاز ۳: هر دو پرداخت (وجه کالا و کارمزد فروشنده) باید APPROVED باشند، نه فقط وجه خریدار.
  if (type === 'loading' && !bothPaymentsApproved(deal.payments)) {
    throw new Error('هر دو پرداخت (وجه کالا و کارمزد) هنوز تایید نشده‌اند — بارگیری قابل ثبت نیست.')
  }

  const driverName = String(formData.get('driverName') || '').trim()
  const driverPhone = String(formData.get('driverPhone') || '').trim()
  const vehiclePlate = String(formData.get('vehiclePlate') || '').trim()
  const vehicleType = String(formData.get('vehicleType') || '')
  const receiverName = String(formData.get('receiverName') || '').trim()
  const receiverRole = String(formData.get('receiverRole') || '')

  const latitude = formData.get('latitude') ? parseFloat(String(formData.get('latitude'))) : null
  const longitude = formData.get('longitude') ? parseFloat(String(formData.get('longitude'))) : null
  const gpsAccuracy = formData.get('gpsAccuracy') ? parseFloat(String(formData.get('gpsAccuracy'))) : null

  // چک‌لیست: هر آیتمی که توی فرم تیک خورده، از formData میاد (checkbox های هم‌نام)
  const checklistItems = formData.getAll('checklist') as string[]
  const checklistJson = JSON.stringify(checklistItems.reduce((acc, key) => ({ ...acc, [key]: true }), {}))

  let photoUrl: string | null = null
  const photoFile = formData.get('photo') as File | null
  if (photoFile && photoFile.size > 0) {
    photoUrl = await savePhotoToLocalDisk(dealId, photoFile)
  }

  const confirmedAt = new Date()

  const confirmationData = {
    dealId,
    type,
    confirmedAt,
    driverName: driverName || null,
    driverPhone: driverPhone || null,
    vehiclePlate: vehiclePlate || null,
    vehicleType: vehicleType || null,
    receiverName: receiverName || null,
    receiverRole: receiverRole || null,
    checklistJson,
    photoUrl,
    latitude,
    longitude,
    gpsAccuracy,
  }

  // آپدیت وضعیت کلی معامله متناسب با نوع رویداد.
  // توجه: تایم‌لاین خودِ Deal همین رکوردهای DealConfirmation هستن (هرکدوم با
  // زمان دقیق) — نیازی به دوباره‌نویسی توی StatusEvent نیست، چون آن سیستم
  // برای Order/MaterialListing/SupportTicket طراحی شده، نه Deal.
  if (type === 'loading') {
    // گذار به in_transit و ثبتِ رکورد بارگیری اتمیک‌اند و گذار گاردِ وضعیت دارد: ثبتِ دوباره
    // (دابل‌کلیک، دو تب) یا تغییرِ هم‌زمانِ وضعیت توسط ادمین، رکورد بارگیریِ دوم نمی‌سازد.
    await prisma.$transaction(async (tx) => {
      const moved = await tx.deal.updateMany({
        where: {
          id: dealId,
          status: { in: DRIVER_LOADING_STATUSES },
          escrowStatus: 'secured_manual',
          // همان گیتِ پیش‌بررسی، اتمیک: هر دو ردیفِ پرداخت APPROVED.
          AND: DRIVER_REQUIRED_PAYMENT_KINDS.map((kind) => ({ payments: { some: { kind, status: 'APPROVED' } } })),
        },
        data: { status: 'in_transit' },
      })
      if (moved.count !== 1) {
        throw new Error('وضعیت معامله هم‌زمان تغییر کرد یا بارگیری قبلاً ثبت شده — دوباره بررسی کنید.')
      }
      await tx.dealConfirmation.create({ data: confirmationData })
    })

    // نقطه‌ی ۵ پلن: بارگیری تایید شد → اطلاع به خریدار (شماره از User.phone، فقط اگه موجود باشه)
    const loadedDeal = await prisma.deal.findUnique({
      where: { id: dealId },
      select: { buyer: { select: { phone: true } } },
    })
    if (loadedDeal?.buyer?.phone) {
      await queueSms({ dealId, phone: loadedDeal.buyer.phone, message: `محموله‌ی ${dealId.slice(0, 8)} بارگیری شد و در مسیر تحویل است — انبارپلیمر` })
    }

    // لینک برای تخلیه لازمه — مصرف نمی‌شه و انقضاش جلو می‌ره.
    const rules = await getDealRuleSettings()
    await extendDriverLinkForTrip(token, rules.driverLinkValidDays)

    redirect(`/driver/${token}/done?stage=loading`)
  }

  await prisma.dealConfirmation.create({ data: confirmationData })

  // با تایید تخلیه، دو تایمر مستقل (گزارش مغایرت ۴ساعته + واریز وجه ۸ساعته)
  // شروع می‌شه — بار پیش‌فرض «بدون مغایرت» فرض می‌شه، نیازی به تایید فعال
  // خریدار نیست، فقط امکان گزارش مشکل در همون بازه.
  // توجه: وضعیت «delivered» رو startPostUnloadingClocks خودش ست می‌کنه.
  await startPostUnloadingClocks(dealId, confirmedAt)

  // نقطه‌ی ۶ پلن: تحویل شد (startPostUnloadingClocks وضعیت delivered را ست کرد) → اطلاع به دو طرف
  const deliveredDeal = await prisma.deal.findUnique({
    where: { id: dealId },
    select: {
      buyer: { select: { phone: true } },
      transportCompany: { select: { contactPhone: true } },
    },
  })
  const deliveryMessage = `تحویل محموله‌ی ${dealId.slice(0, 8)} ثبت شد — انبارپلیمر`
  if (deliveredDeal?.buyer?.phone) {
    await queueSms({ dealId, phone: deliveredDeal.buyer.phone, message: deliveryMessage })
  }
  if (deliveredDeal?.transportCompany?.contactPhone) {
    await queueSms({ dealId, phone: deliveredDeal.transportCompany.contactPhone, message: deliveryMessage })
  }

  // تخلیه آخرین مرحله‌ی مسیر است: فقط اینجا لینک مصرف می‌شود.
  await markDriverLinkUsed(token)

  redirect(`/driver/${token}/done`)
}
