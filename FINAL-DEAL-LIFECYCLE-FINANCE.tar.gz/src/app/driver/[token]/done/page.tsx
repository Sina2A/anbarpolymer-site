import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'

export default async function DriverDonePage({
  params,
  searchParams,
}: {
  params: Promise<{ token: string }>
  searchParams: Promise<Record<string, string | string[] | undefined>>
}) {
  const { token } = await params
  const sp = await searchParams
  // بعد از بارگیری مسیر تمام نشده: همان لینک برای تایید تخلیه لازم است.
  const afterLoading = sp.stage === 'loading'

  return (
    <div style={{ minHeight: '100vh', background: colors.bgPage, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: spacing.lg, fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl' }}>
      <div style={{ maxWidth: 400, textAlign: 'center', background: colors.bgCard, border: `1px solid ${colors.borderSubtle}`, borderRadius: 14, padding: `${spacing.xxl}px ${spacing.xl}px` }}>
        <div style={{ fontSize: 40, marginBottom: spacing.md }}>✓</div>
        <h1 style={{ fontSize: fontSize.lg, fontWeight: 800, color: colors.successText, marginBottom: spacing.sm }}>
          {afterLoading ? 'بارگیری ثبت شد' : 'ثبت شد، متشکریم'}
        </h1>
        {afterLoading ? (
          <>
            <p style={{ fontSize: fontSize.base, color: colors.neutralText, marginBottom: spacing.md }}>
              لینک پیامک‌شده را نگه دارید — هنگام تخلیه با همین لینک «تایید تخلیه» را ثبت کنید.
            </p>
            <a href={`/driver/t/${token}`} style={{ display: 'inline-block', background: colors.navy, color: '#fff', borderRadius: radius.md, padding: '8px 14px', fontSize: fontSize.sm, fontWeight: 700, textDecoration: 'none' }}>
              رفتن به صفحه‌ی سفر
            </a>
          </>
        ) : (
          <p style={{ fontSize: fontSize.base, color: colors.neutralText }}>فرم شما با موفقیت ثبت شد. می‌تونید این صفحه رو ببندید.</p>
        )}
      </div>
    </div>
  )
}
