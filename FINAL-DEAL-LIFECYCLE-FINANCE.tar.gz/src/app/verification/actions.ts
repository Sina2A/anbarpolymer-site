'use server'

import { getCurrentUser } from '@/lib/currentUser'
import { submitCompanyDocuments, submitProducerLicense } from '@/lib/kyc'
import { revalidatePath } from 'next/cache'
import prisma from '@/lib/prisma'
import { logAudit } from '@/lib/logger'
import { parseTonInput, requireParsed } from '@/lib/money'

/**
 * مقدار عددیِ فرم را به Float یا null تبدیل می‌کند (خالی/نامعتبر → null).
 * فقط برای مختصات (lat/lng)؛ وزن و مبلغ حتماً با parser واحد lib/money خونده بشه.
 */
function toFloatOrNull(v: FormDataEntryValue | null): number | null {
  const t = String(v ?? '').trim()
  if (!t) return null
  const n = Number(t)
  return Number.isFinite(n) ? n : null
}

export async function submitCompanyStepAction(formData: FormData) {
  const user = await getCurrentUser()

  await submitCompanyDocuments({
    userId: user.id,
    companyName: String(formData.get('companyName') || ''),
    legalType: String(formData.get('legalType') || 'factory'),
    nationalId: String(formData.get('nationalId') || ''),
    registrationNumber: String(formData.get('registrationNumber') || ''),
    province: String(formData.get('province') || ''),
    city: String(formData.get('city') || ''),
    address: String(formData.get('address') || ''),
    latitude: toFloatOrNull(formData.get('latitude')),
    longitude: toFloatOrNull(formData.get('longitude')),
  })

  revalidatePath('/verification')
}

export async function submitProducerStepAction(formData: FormData) {
  const user = await getCurrentUser()

  const licenseFile = formData.get('licenseFile') as File | null

  await submitProducerLicense({
    userId: user.id,
    productionLicenseNumber: String(formData.get('productionLicenseNumber') || ''),
    productionLicenseIsSetup: formData.get('productionLicenseIsSetup') === 'on',
    factoryAddress: String(formData.get('factoryAddress') || ''),
    factoryActivityType: String(formData.get('factoryActivityType') || ''),
    factoryProducts: String(formData.get('factoryProducts') || ''),
    factoryLatitude: toFloatOrNull(formData.get('factoryLatitude')),
    factoryLongitude: toFloatOrNull(formData.get('factoryLongitude')),
    licenseFile: licenseFile && licenseFile.size > 0 ? licenseFile : null,
  })

  revalidatePath('/verification')
}

/**
 * گام ۳ — پروفایل تجاری (BusinessProfile).
 * activityDomain و targetMarkets آرایه‌ای هستن → با formData.getAll خونده می‌شن، نه get.
 */
export async function submitBusinessProfileAction(formData: FormData) {
  const user = await getCurrentUser()

  // Company باید از قبل ساخته شده باشه (گام ۱)
  const company = await prisma.company.findUnique({ where: { userId: user.id } })
  if (!company) throw new Error('اول باید مدارک هویتی شرکت (گام ۱) رو تکمیل کنی.')

  // آرایه‌ها: getAll (چند چک‌باکس هم‌نام)
  const activityDomain = formData.getAll('activityDomain').map(String).filter(Boolean)
  const productsUsed = formData.getAll('productsUsed').map(String).filter(Boolean)
  const targetMarkets = formData.getAll('targetMarkets').map(String).filter(Boolean)

  // مقادیر ساده
  const role = String(formData.get('role') || 'seller')
  const purchaseCapacityTier = String(formData.get('purchaseCapacityTier') || '') || null
  // تن با parser واحد lib/money: ارقام فارسی/هزارگان پذیرفته؛ منفی، نامعتبر و بیش از ۳ رقم اعشار → خطای فارسی
  // (قبلاً «12abc» بی‌صدا ۱۲ می‌شد). خالی یا «۰» = اعلام‌نشده → null؛ همان رفتار قبلیِ `parseFloat(...) || null`.
  const monthlyConsumptionTon =
    requireParsed(
      parseTonInput(formData.get('monthlyConsumptionTon'), {
        label: 'مصرف ماهانه (تن)',
        allowZero: true,
        optional: true,
      }),
    ) || null
  const productionCapacityTonPerYear =
    requireParsed(
      parseTonInput(formData.get('productionCapacityTonPerYear'), {
        label: 'ظرفیت تولید سالانه (تن)',
        allowZero: true,
        optional: true,
        max: 1e8, // ظرفیت سالانه‌ی مجتمع‌های بزرگ از سقف پیش‌فرض ۱e۶ تن بیشتر می‌شه
      }),
    ) || null

  await prisma.businessProfile.upsert({
    where: { companyId: company.id },
    update: {
      role,
      activityDomain,
      productsUsed,
      purchaseCapacityTier,
      monthlyConsumptionTon,
      productionCapacityTonPerYear,
      targetMarkets,
    },
    create: {
      companyId: company.id,
      role,
      activityDomain,
      productsUsed,
      purchaseCapacityTier,
      monthlyConsumptionTon,
      productionCapacityTonPerYear,
      targetMarkets,
    },
  })

  await logAudit('business-profile', `پروفایل تجاری شرکت ${company.id.slice(0, 8)} ذخیره شد`, user.id, {
    companyId: company.id,
    activityDomain,
    purchaseCapacityTier,
  })

  revalidatePath('/verification')
}
