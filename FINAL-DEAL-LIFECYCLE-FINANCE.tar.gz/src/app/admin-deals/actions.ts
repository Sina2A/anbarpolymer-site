'use server'

import prisma from '@/lib/prisma'
import { revalidatePath } from 'next/cache'
import { addHoliday, removeHoliday, importHolidaysFromCsv } from '@/lib/holidays'
import { adjustDealDeadline, AdjustableDeadlineField } from '@/lib/deadlineAdjustments'
import { updateDealRuleSettings, restrictUser, PENALTY_HOURS_OPTIONS, runDeadlineEnforcement } from '@/lib/dealDeadlines'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import { AccessDeniedError } from '@/lib/errorCodes'
import { logAudit, logFinancialDrift } from '@/lib/logger'
import { FinancialDriftError, appendFinancialRecord, newFormKey } from '@/lib/financialHistory'
import { evaluateApprovalRequirement } from '@/lib/priceEngine'
import {
  MoneyCalcError,
  dealApprovalAmountToman,
  parseMoneyInput,
  parseTonInput,
  summarizeDeal,
  tonToKgStrict,
  type DealAdjustmentDirection,
  type DealSummaryInput,
} from '@/lib/money'
import type { Prisma } from '@prisma/client'
import {
  dealItemRef,
  releaseItemInTx,
  closeRunInTx,
  notifyPromoted,
  type PromoteResult,
  type ReservationItemType,
} from '@/lib/reservationQueue'
import { redirect } from 'next/navigation'

/**
 * گیت نقش مدیر برای تنظیمات سیستمی معاملات (تعطیلات) — اکشن‌های سرور endpoint عمومی‌ان،
 * پس چک باید داخل خود اکشن باشه (پنهان‌بودن UI مرز امنیتی نیست). private و export‌نشده،
 * تا اکشن عمومی نشه.
 */
async function requireDealsAdmin(message: string) {
  const user = await getCurrentUser()
  if (user.role !== 'admin') throw new AccessDeniedError('A-ROLE-DEALS', message)
  return user
}

/** عملیات مالی/مهلتِ معاملات: مدیر همیشه مجازه؛ کارشناس فقط با دسترسی «ویرایش» یا «کامل» بخش «معاملات». */
async function requireDealsEditAccess() {
  const user = await getCurrentUser()
  if (user.role === 'admin') return user
  const access = await getAllSectionAccess(user.id)
  if (access.deals !== 'edit' && access.deals !== 'full') {
    throw new AccessDeniedError(
      'A-SECTION-DEALS',
      'دسترسی ویرایش بخش معاملات رو نداری — از مدیر بخواه بهت بده.'
    )
  }
  return user
}

/**
 * اجرای تراکنشِ مالی (Tier B): هر تراکنشی که appendFinancialRecord داخلش صدا زده می‌شه از این رد می‌شه.
 * ناهمخوانیِ تاریخچه با ستون (FinancialDriftError) در لاگ سیستم ثبت می‌شه (category: financial، فقط شناسه‌ها،
 * نه مقدارها) و دوباره throw می‌شه تا کل تراکنش rollback بمونه؛ پیام خطا در production به کلاینت نمی‌رسه و
 * لاگ سیستم منبع حقیقته. timeout بلندتره چون هر رکورد تاریخچه قفل مشورتیِ همان موجودیت رو می‌گیره و ممکنه پشت
 * نوشتنِ هم‌زمانِ دیگه‌ای منتظر بمونه. private و export‌نشده، تا اکشن عمومی نشه.
 */
async function runFinancialTx<T>(
  userId: string,
  meta: Record<string, unknown>,
  work: (tx: Prisma.TransactionClient) => Promise<T>,
): Promise<T> {
  try {
    return await prisma.$transaction(work, { timeout: 20000, maxWait: 5000 })
  } catch (error) {
    if (error instanceof FinancialDriftError) await logFinancialDrift(error, userId, meta)
    throw error
  }
}

/**
 * نوشتن یکی از دو متنِ دستور پرداخت (Tier B): رکورد تاریخچه «قبل» از ستون و در همان تراکنش. متنِ خالی = null.
 * outcome برابر 'unchanged' (متن همان متن فعلیه، مثلاً دوبارکلیک) یعنی چیزی برای نوشتن نیست و بی‌صدا رد می‌شه.
 * field یک union بسته‌ی دو ستونه‌ست، پس فرمِ دست‌کاری‌شده نمی‌تونه ستون دیگه‌ای رو بنویسه.
 */
async function writeDealPaymentText(
  field: 'paymentInstructionsText' | 'sellerPaymentInstructionsText',
  dealId: string,
  value: string | null,
  userId: string,
): Promise<void> {
  await runFinancialTx(userId, { dealId }, async (tx) => {
    const record = await appendFinancialRecord(tx, {
      entityType: 'Deal',
      entityId: dealId,
      fieldName: field,
      newValue: value,
      changedBy: userId,
      formKey: newFormKey(),
      readColumn: async () => {
        const row = await tx.deal.findUnique({
          where: { id: dealId },
          select: { paymentInstructionsText: true, sellerPaymentInstructionsText: true },
        })
        if (!row) throw new Error('معامله پیدا نشد.')
        return row[field]
      },
    })
    if (record.outcome !== 'created') return

    await tx.deal.update({
      where: { id: dealId },
      data: field === 'paymentInstructionsText' ? { paymentInstructionsText: value } : { sellerPaymentInstructionsText: value },
    })
  })
}

/**
 * این تابع هیچ تراکنش بانکی واقعی انجام نمی‌ده — فقط وضعیتی رو ثبت می‌کنه که تیم
 * حسابداری، بیرون از سایت، بین خودش و بانک انجام داده. طبق تصمیمی که گرفته شد:
 * «سایت قرار نیست به سیستم بانکی وصل بشه، این برای بخش حسابداریه.»
 *
 * توجه (v2): confirmFundsSecured قدیمی که status را به 'payment_secured' می‌برد حذف شد —
 * همان تابع بود که تله‌ی ترتیب می‌ساخت (بعدش markSellerFeePaid با شرط status==='confirmed'
 * برای همیشه قفل می‌شد). تاییدِ پرداخت خریدار حالا از مسیر approvePaymentAction روی ردیفِ
 * DealPayment(kind:'BUYER_GOODS') انجام می‌شه؛ گیتِ عبور به حمل بر پایه‌ی دو ردیف است نه status.
 */
export async function confirmFundsReleased(formData: FormData) {
  // هویت تاییدکننده از session می‌آد، نه از فرم — وگرنه کلاینت می‌تونست هر id دلخواهی
  // رو توی escrowConfirmedById و لاگ ممیزی بنشونه.
  const user = await requireDealsEditAccess()
  const dealId = String(formData.get('dealId'))

  // گاردِ #1: آزادسازی وجه فقط وقتی مجاز است که همه‌ی این‌ها هم‌زمان برقرار باشد:
  //   (الف) وجه خریدار واقعاً نزد ما تضمین شده (escrowStatus==='secured_manual')؛
  //   (ب) بار تحویل شده (status==='delivered') — نه void/cancelled/settled و نه مرحله‌ی قبل از تحویل؛
  //   (پ) آزادسازی فریز نیست (fundReleaseFrozen===false) — مغایرتِ «حساس» ثبت نشده یا مدیر به نفع فروشنده حل کرده؛
  //   (ت) پنجره‌ی مغایرت بسته شده (qualityAutoAccepted===true) — یا با انقضای discrepancyReportDeadline
  //       (enforceDiscrepancyWindowClose) یا با گزارشِ خودِ خریدار؛ تا وقتی false است خریدار هنوز می‌تواند گزارش دهد؛
  //   (ث) هیچ Dispute بازی (status:'open') روی همین معامله نیست.
  // «گزارشِ ثبت‌نشده» عمداً شرط جایگزین نیست: بدون بسته‌شدن پنجره، سکوتِ خریدار به‌معنای تایید نیست.
  // بدون این شرط‌ها، اگر رد یک پرداخت معامله را void کرده باشد، زدنِ همین دکمه void را به settled برمی‌گرداند و
  // وجهی را که نباید آزاد می‌شد «آزادشده» ثبت می‌کند. شرط داخل updateMany اتمیک است؛ count===0 یعنی
  // حالت غیرمجاز → نه تغییری اعمال می‌شود و نه لاگِ آزادسازیِ کاذب ثبت می‌گردد. همین شرط idempotent هم هست
  // (روی معامله‌ی از قبل released_manual دوباره اجرا نمی‌شود).
  //
  // تسویه = مورد (آگهی/درخواست) فروخته شده؛ وضعیتِ خودِ مورد 'reserved' می‌ماند، پس اگر کسی در
  // صفِ رزرو منتظر مانده باشد برای همیشه منتظر می‌ماند. صفِ مورد هم در همان تراکنشِ تسویه بسته می‌شود.
  // شرطِ گارد بین پیش‌بررسی و نوشتنِ اتمیک مشترکه. آینه‌ی UI: admin-deals/page.tsx (releaseBlockers).
  const guard = {
    id: dealId,
    escrowStatus: 'secured_manual',
    status: 'delivered',
    fundReleaseFrozen: false,
    qualityAutoAccepted: true,
    disputes: { none: { status: 'open' } },
  }
  const notAllowed =
    'آزادسازی وجه مجاز نیست: برای آزادسازی باید وجه تضمین‌شده باشد، معامله «تحویل‌شده» باشد، پنجره‌ی مغایرت بسته شده باشد، ' +
    'آزادسازی فریز نباشد و اختلاف بازی روی معامله نمانده باشد.'
  const settled = await runFinancialTx(user.id, { dealId }, async (tx) => {
    // پیش‌بررسیِ همان گارد، تا در حالت غیرمجاز هیچ رکورد تاریخچه‌ای ساخته نشه (همان مسیر قدیمیِ count===0).
    if (!(await tx.deal.findFirst({ where: guard, select: { id: true } }))) return false

    // escrowStatus فیلد مالی (Tier B)ه: رکورد تاریخچه «قبل» از نوشتن ستون و در همین تراکنش می‌آد. هر کلیک
    // رویداد تازه‌ایه (formKey تصادفی)؛ ضد دوبارکلیک خودِ گارده: بعد از اولین کلیک ستون دیگه secured_manual
    // نیست و رکورد دوم 'unchanged' برمی‌گرده.
    const record = await appendFinancialRecord(tx, {
      entityType: 'Deal',
      entityId: dealId,
      fieldName: 'escrowStatus',
      newValue: 'released_manual',
      changedBy: user.id,
      formKey: newFormKey(),
      readColumn: async () => {
        const row = await tx.deal.findUnique({ where: { id: dealId }, select: { escrowStatus: true } })
        return row?.escrowStatus ?? null
      },
    })
    if (record.outcome !== 'created') throw new Error(notAllowed)

    const released = await tx.deal.updateMany({
      where: guard,
      data: {
        escrowStatus: 'released_manual',
        escrowConfirmedById: user.id,
        escrowConfirmedAt: new Date(),
        status: 'settled',
      },
    })
    // تغییر هم‌زمان بین پیش‌بررسی و این نوشتن: باید throw کنیم (نه return) تا رکورد تاریخچه rollback بشه؛
    // با return تراکنش commit می‌شد و تاریخچه از ستون جدا می‌افتاد (drift).
    if (released.count !== 1) throw new Error(notAllowed)

    const deal = await tx.deal.findUnique({
      where: { id: dealId },
      select: { tradeDirection: true, materialListingId: true, purchaseRequestId: true },
    })
    const ref = deal ? dealItemRef(deal) : null
    if (ref) await closeRunInTx(tx, ref.itemType, ref.itemId)
    return true
  })
  if (!settled) throw new Error(notAllowed)
  await logAudit('deal', `آزادسازی وجه معامله ${dealId.slice(0, 8)}`, user.id, { dealId, action: 'funds_released' })
  revalidatePath('/admin-deals')
}

export async function addHolidayAction(formData: FormData) {
  await requireDealsAdmin('فقط نقش مدیر مجاز به ثبت تعطیلی رسمیه.')
  const date = String(formData.get('date') || '')
  const title = String(formData.get('title') || '')
  if (!date) return
  await addHoliday(date, title)
  revalidatePath('/admin-deals')
}

export async function removeHolidayAction(formData: FormData) {
  await requireDealsAdmin('فقط نقش مدیر مجاز به حذف تعطیلی رسمیه.')
  const id = String(formData.get('id') || '')
  if (!id) return
  await removeHoliday(id)
  revalidatePath('/admin-deals')
}

export async function adjustDeadlineAction(formData: FormData) {
  // adjustedById از session — قبلاً از فرم می‌اومد و هر کسی می‌تونست به‌نام دیگری مهلت رو دستکاری کنه.
  const user = await requireDealsEditAccess()
  const dealId = String(formData.get('dealId') || '')
  const field = String(formData.get('field') || '') as AdjustableDeadlineField
  const hours = Number(formData.get('hours'))
  const reason = String(formData.get('reason') || '')

  if (!dealId || !field || !Number.isFinite(hours)) return

  await adjustDealDeadline({ dealId, field, hoursDelta: hours, reason, adjustedById: user.id })
  revalidatePath('/admin-deals')
}

export async function importHolidaysAction(formData: FormData) {
  await requireDealsAdmin('فقط نقش مدیر مجاز به درون‌ریزی تعطیلات رسمیه.')
  const file = formData.get('csvFile') as File | null
  if (!file || file.size === 0) return

  const csvText = await file.text()
  const { addedCount, skippedLines } = await importHolidaysFromCsv(csvText)

  revalidatePath('/admin-deals')
  redirect(`/admin-deals?imported=${addedCount}&skipped=${skippedLines}`)
}

// توجه: تنظیم ساعات کاری هفتگی (upsertWeeklyHourAction) از اینجا به
// src/app/admin-users/actions.ts منتقل شد — چون سینا خواست این تنظیم کنار
// بقیه‌ی مدیریت کاربران/دسترسی‌ها باشه، نه توی صفحه‌ی معاملات.

/**
 * تنظیم طول مهلت‌های معامله — فقط مدیر (چک سمت سرور، مستقل از UI)، چون این
 * روی محاسبه‌ی مهلت مالی همه‌ی معاملات بعدی اثر می‌ذاره.
 */
export async function updateDealRulesAction(formData: FormData) {
  const currentUser = await getCurrentUser()
  if (currentUser.role !== 'admin') {
    throw new AccessDeniedError('A-ROLE-DEALS', 'فقط نقش مدیر مجاز به تغییر قوانین معامله‌ست.')
  }

  const clampInt = (raw: FormDataEntryValue | null, fallback: number) => {
    const n = Math.round(Number(raw))
    if (!Number.isFinite(n) || n < 1) return fallback
    return Math.min(999, n)
  }

  await updateDealRuleSettings(
    {
      sellerFeeHours: clampInt(formData.get('sellerFeeHours'), 24),
      buyerPaymentHours: clampInt(formData.get('buyerPaymentHours'), 72),
      discrepancyReportHours: clampInt(formData.get('discrepancyReportHours'), 4),
      fundReleaseHours: clampInt(formData.get('fundReleaseHours'), 8),
      driverLinkValidDays: clampInt(formData.get('driverLinkValidDays'), 5),
      driverSilenceDays: clampInt(formData.get('driverSilenceDays'), 5),
      proformaConfirmHours: clampInt(formData.get('proformaConfirmHours'), 8),
    },
    currentUser.id
  )
  revalidatePath('/admin-deals')
}

/**
 * اجرای دستیِ زمان‌بندِ مهلت‌ها — دکمه‌ی «اجرای همین الان» توی کارتِ تنظیمات، برای تست/کنترل.
 * فقط مدیر (چک سمت سرور، مستقل از UI). همون تیکِ خودکار رو صدا می‌زنه ولی با trigger='manual'
 * تا اجراهای دستی توی لیستِ نمایشیِ «۳ اجرای آخرِ خودکار» قاطی نشن. runDeadlineEnforcement
 * خودش نتیجه رو توی SystemLog ثبت می‌کنه.
 */
export async function runDeadlineEnforcementNowAction() {
  const currentUser = await getCurrentUser()
  if (currentUser.role !== 'admin') {
    throw new AccessDeniedError('A-ROLE-DEALS', 'فقط نقش مدیر مجاز به اجرای دستی زمان‌بند است.')
  }

  const result = await runDeadlineEnforcement('manual')
  await logAudit('deal', `اجرای دستی زمان‌بند مهلت‌ها — ${result.summary}`, currentUser.id, {
    action: 'deadline_enforcement_manual',
    ...result,
  })
  revalidatePath('/admin-deals')
}

/**
 * دستور پرداختِ اختصاصیِ یک معامله — متن آزادِ کارشناس حسابداری برای خریدار
 * (شماره‌حساب یا پیام «تماس بگیرید»، هر فرمتی). عیناً توی پاپ‌آپ پرداختِ خریدار
 * (DealPaymentModal) بالای گزینه‌ها نشون داده می‌شه. فقط نقش‌های پنل (admin/staff).
 */
export async function updateDealPaymentInstructionsAction(formData: FormData) {
  const currentUser = await getCurrentUser()
  if (currentUser.role !== 'admin' && currentUser.role !== 'staff') {
    throw new AccessDeniedError('A-ROLE-DEALS', 'فقط کاربران پنل (مدیر یا کارشناس) مجاز به ثبت دستور پرداختند.')
  }

  const dealId = String(formData.get('dealId') || '')
  if (!dealId) return
  const text = String(formData.get('paymentInstructionsText') || '').trim()

  await writeDealPaymentText('paymentInstructionsText', dealId, text || null, currentUser.id)
  await logAudit('deal', `ثبت/ویرایش دستور پرداخت معامله ${dealId.slice(0, 8)}`, currentUser.id, { dealId, action: 'payment_instructions_updated' })
  revalidatePath('/admin-deals')
}

/**
 * دستور پرداختِ فروشنده — متن آزادِ کارشناس حسابداری برای پرداختِ کارمزدِ فروشنده (SELLER_FEE)،
 * کاملاً مستقل از متنِ خریدار (updateDealPaymentInstructionsAction). عیناً توی پاپ‌آپ پرداختِ
 * کارمزدِ فروشنده (DealPaymentModal) نشون داده می‌شه. عمداً اکشنِ جدا، نه پارامترِ «کدوم فیلد»:
 * هر اکشن دقیقاً یک ستون می‌نویسه و فرمِ دست‌کاری‌شده نمی‌تونه ستونِ طرفِ مقابل رو بنویسه.
 * فقط نقش‌های پنل (admin/staff).
 */
export async function updateSellerPaymentInstructionsAction(formData: FormData) {
  const currentUser = await getCurrentUser()
  if (currentUser.role !== 'admin' && currentUser.role !== 'staff') {
    throw new AccessDeniedError('A-ROLE-DEALS', 'فقط کاربران پنل (مدیر یا کارشناس) مجاز به ثبت دستور پرداختند.')
  }

  const dealId = String(formData.get('dealId') || '')
  if (!dealId) return
  const text = String(formData.get('sellerPaymentInstructionsText') || '').trim()

  await writeDealPaymentText('sellerPaymentInstructionsText', dealId, text || null, currentUser.id)
  await logAudit('deal', `ثبت/ویرایش دستور پرداخت فروشنده‌ی معامله ${dealId.slice(0, 8)}`, currentUser.id, { dealId, action: 'seller_payment_instructions_updated' })
  revalidatePath('/admin-deals')
}

/**
 * تایید معامله توسط مدیر — بعد از این، مهلت پرداخت خریدار شروع می‌شه.
 * معامله‌ی بدون قیمت (null/۰) تایید نمی‌شه (Q12: «admin» فقط جایگزینِ موقتِ نبودِ قیمت بود و سقفِ واقعی نیست).
 * سطح تایید همیشه از روی همان جمع کالایی که مدیر می‌بینه (قیمت × وزن، C9) دوباره حساب و هم‌زمان با status ذخیره
 * می‌شه؛ این سطح سقفِ ویرایش‌های بعدی قیمت/وزن (assertWithinApprovedLevel) است. نوشتن compare-and-set است:
 * اگه status/قیمت/وزن بین خواندن و نوشتن عوض شده باشه، خطای هم‌زمانی می‌ده.
 */
export async function approveDealAction(dealId: string) {
  const currentUser = await getCurrentUser()
  if (currentUser.role !== 'admin') throw new Error('فقط مدیر می‌تونه معامله رو تایید کنه.')

  const deal = await prisma.deal.findUnique({
    where: { id: dealId },
    include: { materialListing: { select: { quantityTon: true } }, purchaseRequest: { select: { quantityTon: true } } },
  })
  if (!deal) throw new Error('معامله پیدا نشد.')
  if (deal.status !== 'awaiting_approval') throw new Error('فقط معاملات در انتظار تایید قابل تصویبن.')

  let amount: number | null
  try {
    amount = dealApprovalAmountToman({
      agreedPrice: deal.agreedPrice,
      weightKg: deal.weightKg,
      listedTon: deal.materialListing?.quantityTon ?? deal.purchaseRequest?.quantityTon,
    })
  } catch (error) {
    if (error instanceof MoneyCalcError) throw new Error(error.message)
    throw error
  }
  if (amount === null || amount === 0) throw new Error('اول قیمت را وارد کن.')
  const approvalLevel = await evaluateApprovalRequirement('Deal', amount)

  const approved = await prisma.deal.updateMany({
    where: { id: dealId, status: 'awaiting_approval', agreedPrice: deal.agreedPrice, weightKg: deal.weightKg },
    data: { status: 'confirmed', approvalLevel },
  })
  if (approved.count !== 1) throw new Error('معامله هم‌زمان تغییر کرد؛ صفحه رو دوباره باز کن و دوباره امتحان کن.')

  // مهلت پرداخت خریدار شروع بشه — skipApprovalCheck=true چون همین الان مدیر
  // تاییدش کرد؛ بدون این پرچم، تابع دوباره ارزیابی می‌کنه و status رو برمی‌گردونه
  // به awaiting_approval (حلقه‌ی منطقی)
  const { startBuyerPaymentDeadline } = await import('@/lib/dealDeadlines')
  await startBuyerPaymentDeadline(dealId, true)

  await logAudit('deal', `تایید معامله ${dealId.slice(0, 8)} توسط مدیر`, currentUser.id, { dealId, action: 'deal_approved' })
  revalidatePath('/admin-deals')
}

/**
 * تایید یک پرداخت (v2) — جای markSellerFeePaidAction را می‌گیرد. هر ردیف DealPayment
 * (BUYER_GOODS یا SELLER_FEE) مستقل از دیگری تایید می‌شود (ترتیبِ دو پرداخت مهم نیست)، ولی خودِ تایید فقط وقتی
 * مجاز است که معامله confirmed باشد، یعنی مدیر معامله (قیمتِ نهایی) را تایید کرده باشد: یک‌بار پیش‌بررسی بیرون از
 * تراکنش، و بار دیگر داخل تراکنش (خواندنِ وضعیت قبل از هر رکورد تاریخچه + شرطِ اتمیکِ deal.status در updateMany).
 * وقتی هر دو ردیف APPROVED شدند، فاز معامله به transport_pending می‌رود. فقط کاربران پنل (مدیر یا کارشناس).
 */
export async function approvePaymentAction(formData: FormData) {
  const currentUser = await getCurrentUser()
  if (currentUser.role !== 'admin' && currentUser.role !== 'staff') {
    throw new AccessDeniedError('A-ROLE-DEALS', 'فقط کاربران پنل (مدیر یا کارشناس) مجاز به تایید پرداختند.')
  }

  const dealId = String(formData.get('dealId') || '')
  const kind = String(formData.get('kind') || '')
  if (!dealId) return
  if (kind !== 'BUYER_GOODS' && kind !== 'SELLER_FEE') throw new Error('نوع پرداخت نامعتبر است.')

  const notReviewable = 'این پرداخت پیدا نشد یا قبلاً بررسی شده است.'
  const concurrentChange = 'وضعیت وجه هم‌زمان توسط کاربر دیگری تغییر کرد — صفحه رو تازه کن.'
  const dealNotApprovable = (status: string | undefined) =>
    status === 'awaiting_approval'
      ? 'تایید پرداخت بعد از تایید معامله توسط مدیر ممکن است؛ این معامله هنوز در انتظار تایید مدیر است.'
      : 'در وضعیت جاری معامله امکان تایید پرداخت وجود ندارد (فقط معامله‌ی «تایید شد»).'

  // پیش‌بررسیِ بیرون از تراکنش: پیامِ زودهنگام و بدون باز کردنِ تراکنشِ مالی. گیتِ اصلی داخل تراکنش است.
  const dealRow = await prisma.deal.findUnique({ where: { id: dealId }, select: { status: true } })
  if (!dealRow) throw new Error('معامله پیدا نشد.')
  if (dealRow.status !== 'confirmed') throw new Error(dealNotApprovable(dealRow.status))

  const result = await runFinancialTx(currentUser.id, { dealId, kind }, async (tx) => {
    // گیتِ داخل تراکنش: وضعیت قبل از هر رکورد تاریخچه خوانده می‌شود تا در حالت غیرمجاز چیزی نوشته نشود.
    const dealInTx = await tx.deal.findUnique({ where: { id: dealId }, select: { status: true } })
    if (!dealInTx || dealInTx.status !== 'confirmed') throw new Error(dealNotApprovable(dealInTx?.status))

    // فقط از PENDING/SUBMITTED می‌شود APPROVED کرد. entityIdِ تاریخچه شناسه‌ی ردیف DealPayment است.
    const payment = await tx.dealPayment.findUnique({
      where: { dealId_kind: { dealId, kind } },
      select: { id: true, status: true, receiptUrl: true },
    })
    if (!payment || !['PENDING', 'SUBMITTED'].includes(payment.status)) throw new Error(notReviewable)
    // #25: بدون رسیدِ ثبت‌شده هیچ پرداختی تایید نمی‌شود (قبلاً ردیفِ PENDING بدون فیش هم قابل تایید بود).
    // قبل از appendFinancialRecord تا در حالت غیرمجاز هیچ رکورد تاریخچه‌ای ساخته نشود.
    if (!payment.receiptUrl) throw new Error('برای این پرداخت هنوز رسیدی ثبت نشده؛ بدون رسید قابل تایید نیست.')

    // status فیلد مالی (Tier B)ه: رکورد تاریخچه «قبل» از نوشتن ستون و در همین تراکنش. outcome غیر از 'created'
    // یعنی تاییدکننده‌ی هم‌زمانِ دیگه‌ای زودتر رسیده — همان خطای «قبلاً بررسی شده».
    const approval = await appendFinancialRecord(tx, {
      entityType: 'DealPayment',
      entityId: payment.id,
      fieldName: 'status',
      newValue: 'APPROVED',
      changedBy: currentUser.id,
      formKey: newFormKey(),
      readColumn: async () => {
        const row = await tx.dealPayment.findUnique({ where: { id: payment.id }, select: { status: true } })
        return row?.status ?? null
      },
    })
    if (approval.outcome !== 'created') throw new Error(notReviewable)

    // شرطِ deal.status در همین updateMany: اگر بین خواندنِ بالا و این نوشتن معامله confirmed نماند (مثلاً هم‌زمان
    // void شد)، count=0 می‌شود و throw کل تراکنش را برمی‌گرداند.
    const reviewed = await tx.dealPayment.updateMany({
      where: { id: payment.id, status: { in: ['PENDING', 'SUBMITTED'] }, deal: { status: 'confirmed' } },
      data: { status: 'APPROVED', reviewedById: currentUser.id, reviewedAt: new Date() },
    })
    // throw (نه return) تا رکورد تاریخچه‌ی بالا هم rollback بشه.
    if (reviewed.count !== 1) throw new Error(notReviewable)

    // تاییدِ وجه کالای خریدار = وجه نزد ما تضمین شد (جایگزینِ confirmFundsSecuredِ حذف‌شده).
    // فقط از pending جلو می‌رود تا idempotent باشد و released_manual را برنگرداند. همین گیتِ
    // دکمه‌ی «تایید پرداخت به فروشنده» را باز می‌کند که تنها مسیرِ رسیدن به settled است.
    if (kind === 'BUYER_GOODS') {
      const deal = await tx.deal.findUnique({ where: { id: dealId }, select: { escrowStatus: true } })
      if (deal?.escrowStatus === 'pending') {
        const escrow = await appendFinancialRecord(tx, {
          entityType: 'Deal',
          entityId: dealId,
          fieldName: 'escrowStatus',
          newValue: 'secured_manual',
          changedBy: currentUser.id,
          formKey: newFormKey(),
          readColumn: async () => {
            const row = await tx.deal.findUnique({ where: { id: dealId }, select: { escrowStatus: true } })
            return row?.escrowStatus ?? null
          },
        })
        if (escrow.outcome !== 'created') throw new Error(concurrentChange)
        const secured = await tx.deal.updateMany({
          where: { id: dealId, escrowStatus: 'pending' },
          data: { escrowStatus: 'secured_manual' },
        })
        // throw (نه return) تا رکوردهای تاریخچه rollback بشن؛ این مسیر فقط با تغییر هم‌زمانِ وضعیت وجه پیش می‌آد.
        if (secured.count !== 1) throw new Error(concurrentChange)
      }
    }

    // گیتِ عبور به حمل: مقایسه‌ی وضعیت دو ردیف، نه enumِ status.
    const payments = await tx.dealPayment.findMany({ where: { dealId } })
    const bothApproved = payments.length >= 2 && payments.every((p) => p.status === 'APPROVED')
    let transitioned = false
    if (bothApproved) {
      // #25: فقط از 'confirmed' (قیمتِ نهایی و تاییدشده‌ی مدیر). قبلاً draft/awaiting_approval هم به حمل می‌رفتند
      // و تاییدِ مدیر دور زده می‌شد. گیتِ بالا تضمین می‌کند اینجا confirmed است؛ شرطِ status در updateMany فقط برای
      // هم‌زمانی است (count!==1 ⇒ throw تا تایید و رکوردهای تاریخچه rollback شوند).
      const moved = await tx.deal.updateMany({
        where: { id: dealId, status: 'confirmed' },
        data: { status: 'transport_pending', sellerFeeDeadline: null, buyerConfirmDeadline: null },
      })
      if (moved.count !== 1) throw new Error(concurrentChange)
      transitioned = true
    }
    return { transitioned }
  })

  await logAudit('deal', `تایید پرداخت ${kind} معامله ${dealId.slice(0, 8)}`, currentUser.id, {
    dealId,
    kind,
    action: 'payment_approved',
    transportPending: result.transitioned,
  })
  revalidatePath('/admin-deals')
}

/**
 * رد یک پرداخت (v2) — جای rejectDealPaymentAction را می‌گیرد. منطق ابطال §۵ بر پایه‌ی
 * نقشِ ایجاد Match فردِ پرداخت‌ردشده است، نه نقش تجاری‌اش:
 *   • اگر Requester بود ⇒ Deal→void + توقف origin + حذف از بازار + بستنِ صفِ رزرو (بدون جریمه).
 *   • اگر Acceptor بود ⇒ Deal→void + release origin از مسیر صفِ رزرو (نفر بعدیِ صف مطلع می‌شود،
 *     و فقط اگر صفی نباشد origin به بازار برمی‌گردد) + جریمه‌ی acceptor با طول انتخابی.
 * void‌کردن + تغییر origin + پیشرویِ صف اتمیک است؛ اعلانِ صف و جریمه بعد از commit اعمال می‌شود
 * (restrictUser روی prismaِ سراسری کار می‌کند نه tx، پس بیرون از تراکنش می‌ماند تا اتمیک‌بودنِ
 * هسته حفظ شود). فقط کاربران پنل (مدیر یا کارشناس).
 *
 * فاز ۳ (#26):
 *   • رد فقط در وضعیتِ معامله‌ی draft/awaiting_approval/confirmed/transport_pending مجاز است؛ گیت «قبل» از
 *     نوشتنِ رکورد تاریخچه‌ی REJECTED می‌آید. معاملاتِ void/cancelled/in_transit/delivered/settled قابل‌رد نیستند.
 *   • escrowStatus خودکار برنمی‌گردد. اگر معامله void می‌شود در حالی‌که وجه خریدار نزد ماست
 *     (escrowStatus==='secured_manual' و ردیف BUYER_GOODS قبلاً APPROVED بوده — چه خودِ BUYER_GOODS رد شود چه
 *     SELLER_FEE)، Deal.manualReversalRequired=true و manualReversalAt ثبت می‌شود تا مدیر وجه را دستی برگرداند و
 *     با markManualReversalDone پرچم را پاک کند. manualReversalRequired فیلد مالی (Tier B) است: رکوردِ تاریخچه در
 *     همین تراکنش و قبل از نوشتنِ ستون.
 *   • معیارِ «قربانی» (فقط ثبت‌شده، بدون منطق/گزارش): معاملهٔ void که بارگیری/تخلیه‌اش ثبت شده یا وجهش آزاد شده و
 *     مورد (آگهی/درخواست) آن بعداً دوباره رزرو شده باشد.
 */
type RejectPaymentOutcome = {
  branch: 'requester' | 'acceptor'
  penalizedUserId: string | null
  /** نتیجه‌ی آزادسازیِ queue-aware (فقط شاخه‌ی acceptor) — اعلانش بعد از commit فرستاده می‌شود. */
  release: { itemType: ReservationItemType; itemId: string; promote: PromoteResult } | null
}

/** وضعیت‌هایی از معامله که ردِ پرداخت در آن‌ها مجاز است (#26). */
const REJECTABLE_DEAL_STATUSES = ['draft', 'awaiting_approval', 'confirmed', 'transport_pending']

export async function rejectPaymentAction(formData: FormData) {
  const currentUser = await getCurrentUser()
  if (currentUser.role !== 'admin' && currentUser.role !== 'staff') {
    throw new AccessDeniedError('A-ROLE-DEALS', 'فقط کاربران پنل (مدیر یا کارشناس) مجاز به رد پرداختند.')
  }

  const dealId = String(formData.get('dealId') || '')
  const kind = String(formData.get('kind') || '')
  const reason = String(formData.get('reason') || '').trim()
  if (!dealId) return
  if (kind !== 'BUYER_GOODS' && kind !== 'SELLER_FEE') throw new Error('نوع پرداخت نامعتبر است.')

  const penaltyRaw = Number(formData.get('penaltyHours'))
  const penaltyHours = (PENALTY_HOURS_OPTIONS as readonly number[]).includes(penaltyRaw) ? penaltyRaw : 24

  const notRejectable = 'این پرداخت پیدا نشد یا قبلاً رد شده است.'
  const dealNotRejectable =
    'رد پرداخت فقط وقتی معامله در وضعیت پیش‌نویس، در انتظار تایید، تاییدشده یا در انتظار حمل است مجاز است.'
  const concurrentChange = 'وضعیت معامله هم‌زمان توسط کاربر دیگری تغییر کرد — صفحه رو تازه کن.'
  const outcome = await runFinancialTx(currentUser.id, { dealId, kind }, async (tx): Promise<RejectPaymentOutcome> => {
    // فقط از PENDING/SUBMITTED/APPROVED می‌شود REJECTED کرد. entityIdِ تاریخچه شناسه‌ی ردیف DealPayment است.
    const payment = await tx.dealPayment.findUnique({
      where: { dealId_kind: { dealId, kind } },
      select: { id: true, status: true },
    })
    if (!payment || !['PENDING', 'SUBMITTED', 'APPROVED'].includes(payment.status)) throw new Error(notRejectable)

    // #26: گیتِ وضعیتِ معامله «قبل» از نوشتنِ هر رکورد تاریخچه. (معامله‌ی از قبل void/cancelled هم اینجا رد می‌شود؛
    // دیگر مسیرِ «فقط ردیف را REJECTED کن» وجود ندارد.)
    const deal = await tx.deal.findUnique({ where: { id: dealId } })
    if (!deal) throw new Error('معامله پیدا نشد.')
    if (!REJECTABLE_DEAL_STATUSES.includes(deal.status)) throw new Error(dealNotRejectable)

    // آیا وجه خریدار قبلاً تایید شده؟ (برای خودِ BUYER_GOODS از ردیفِ همین رد؛ برای SELLER_FEE از ردیفِ هم‌نوعِ دیگر.)
    const buyerGoodsStatus =
      kind === 'BUYER_GOODS'
        ? payment.status
        : (
            await tx.dealPayment.findUnique({
              where: { dealId_kind: { dealId, kind: 'BUYER_GOODS' } },
              select: { status: true },
            })
          )?.status ?? null
    const reversalRequired = deal.escrowStatus === 'secured_manual' && buyerGoodsStatus === 'APPROVED'

    // status فیلد مالی (Tier B)ه: رکورد تاریخچه «قبل» از نوشتن ستون و در همین تراکنش.
    const rejection = await appendFinancialRecord(tx, {
      entityType: 'DealPayment',
      entityId: payment.id,
      fieldName: 'status',
      newValue: 'REJECTED',
      changedBy: currentUser.id,
      formKey: newFormKey(),
      readColumn: async () => {
        const row = await tx.dealPayment.findUnique({ where: { id: payment.id }, select: { status: true } })
        return row?.status ?? null
      },
    })
    if (rejection.outcome !== 'created') throw new Error(notRejectable)

    const rejected = await tx.dealPayment.updateMany({
      where: { id: payment.id, status: { in: ['PENDING', 'SUBMITTED', 'APPROVED'] } },
      data: { status: 'REJECTED', reviewedById: currentUser.id, reviewedAt: new Date(), rejectionReason: reason || null },
    })
    // throw (نه return) تا رکورد تاریخچه‌ی بالا هم rollback بشه.
    if (rejected.count !== 1) throw new Error(notRejectable)

    // نقش‌ها با fallback برای رکوردهای legacy/backfill (همان قانونِ لحظه‌ی Match).
    const dir = deal.tradeDirection || 'SELL'
    const payerId = kind === 'BUYER_GOODS' ? deal.buyerId : deal.sellerId
    const requesterId = deal.requesterId ?? (dir === 'SELL' ? deal.sellerId : deal.buyerId)
    const acceptorId = deal.acceptorId ?? (dir === 'SELL' ? deal.buyerId : deal.sellerId)
    const ref = dealItemRef(deal)

    // پرچمِ بازگشتِ دستیِ وجه (Tier B): رکورد تاریخچه «قبل» از نوشتنِ ستون و در همین تراکنش. 'unchanged' یعنی ستون
    // از قبل true بوده (پرچم و زمانش دست‌نخورده می‌ماند)؛ 'duplicate' نباید پیش بیاید → throw تا همه rollback شود.
    // escrowStatus عمداً برنمی‌گردد؛ مدیر وجه را دستی برمی‌گرداند و پرچم را با markManualReversalDone پاک می‌کند.
    let reversalData: { manualReversalRequired: true; manualReversalAt: Date } | null = null
    if (reversalRequired) {
      const flag = await appendFinancialRecord(tx, {
        entityType: 'Deal',
        entityId: dealId,
        fieldName: 'manualReversalRequired',
        newValue: true,
        changedBy: currentUser.id,
        formKey: newFormKey(),
        readColumn: async () => {
          const row = await tx.deal.findUnique({ where: { id: dealId }, select: { manualReversalRequired: true } })
          return row?.manualReversalRequired ?? null
        },
      })
      if (flag.outcome === 'duplicate') throw new Error(concurrentChange)
      if (flag.outcome === 'created') reversalData = { manualReversalRequired: true, manualReversalAt: new Date() }
    }

    // void اتمیک با همان گیتِ وضعیت و همان escrowStatusی که بالا خواندیم؛ تغییر هم‌زمان → count!==1 → throw (rollback).
    const voided = await tx.deal.updateMany({
      where: { id: dealId, status: { in: REJECTABLE_DEAL_STATUSES }, escrowStatus: deal.escrowStatus },
      data: { status: 'void', ...(reversalData ?? {}) },
    })
    if (voided.count !== 1) throw new Error(concurrentChange)

    const payerIsRequester = payerId != null && payerId === requesterId
    if (payerIsRequester) {
      // توقف origin + حذف از بازار (مالکِ درخواست خودش نکول کرده).
      if (dir === 'BUY' && deal.purchaseRequestId) {
        await tx.purchaseRequest.update({ where: { id: deal.purchaseRequestId }, data: { status: 'closed' } })
      } else if (deal.materialListingId) {
        await tx.materialListing.update({ where: { id: deal.materialListingId }, data: { validityStatus: 'cancelled' } })
      }
      // origin برای همیشه از بازار رفته → صفِ رزرویِ آن هم بسته می‌شود (کسی مطلع نمی‌شود).
      if (ref) await closeRunInTx(tx, ref.itemType, ref.itemId)
      return { branch: 'requester', penalizedUserId: null, release: null }
    }

    // release origin از مسیر صفِ رزرو: نفر بعدیِ صف مطلع می‌شود (origin reserved می‌ماند) و فقط
    // اگر صفی نباشد به مالک اصلی (بی‌گناه) برمی‌گردد تا دوباره در بازار قابل‌مچ شود.
    // اعلانِ صف و جریمه بعد از commit.
    const promote = ref ? await releaseItemInTx(tx, ref.itemType, ref.itemId) : null
    return {
      branch: 'acceptor',
      penalizedUserId: acceptorId,
      release: ref && promote ? { itemType: ref.itemType, itemId: ref.itemId, promote } : null,
    }
  })

  // اعلانِ نفر بعدیِ صف — اول از همه و بیرون از تراکنش (شبکه‌ای است و هیچ‌وقت throw نمی‌کند)؛
  // قبل از جریمه می‌آید تا خطای احتمالیِ restrictUser مانعِ رسیدنِ اعلان نشود.
  if (outcome.release) {
    await notifyPromoted(outcome.release.itemType, outcome.release.itemId, outcome.release.promote)
  }

  // جریمه بیرون از تراکنش (restrictUser از prismaِ سراسری استفاده می‌کند).
  if (outcome.branch === 'acceptor' && outcome.penalizedUserId) {
    await restrictUser(outcome.penalizedUserId, penaltyHours, reason || 'رد پرداخت در معامله')
  }

  await logAudit('deal', `رد پرداخت ${kind} معامله ${dealId.slice(0, 8)}`, currentUser.id, {
    dealId,
    kind,
    action: 'payment_rejected',
    branch: outcome.branch,
    penalizedUserId: outcome.penalizedUserId,
    penaltyHours: outcome.branch === 'acceptor' ? penaltyHours : null,
    reason: reason || null,
  })
  revalidatePath('/admin-deals')
}

/**
 * «بازگشت انجام شد» (#26): پس از آن‌که وجهِ تضمین‌شده‌ی خریدارِ یک معامله‌ی باطل‌شده دستی (بیرون از سایت) به او
 * برگشت، پرچمِ Deal.manualReversalRequired را پاک می‌کند. این تابع هیچ تراکنشِ بانکی انجام نمی‌دهد و escrowStatus را
 * تغییر نمی‌دهد؛ manualReversalAt هم به‌عنوان زمانِ ایجادِ نیاز دست‌نخورده می‌ماند. manualReversalRequired فیلد
 * مالی (Tier B) است: رکورد تاریخچه «قبل» از نوشتنِ ستون و در همین تراکنش؛ بدون پرچمِ فعال → خطا (idempotent).
 */
export async function markManualReversalDone(formData: FormData) {
  const user = await requireDealsEditAccess()
  const dealId = String(formData.get('dealId') || '')
  if (!dealId) return

  const notAllowed = 'برای این معامله بازگشتِ دستیِ وجه در انتظار نیست (قبلاً ثبت شده یا لازم نبوده).'
  await runFinancialTx(user.id, { dealId }, async (tx) => {
    const guard = { id: dealId, manualReversalRequired: true }
    if (!(await tx.deal.findFirst({ where: guard, select: { id: true } }))) throw new Error(notAllowed)

    const record = await appendFinancialRecord(tx, {
      entityType: 'Deal',
      entityId: dealId,
      fieldName: 'manualReversalRequired',
      newValue: false,
      changedBy: user.id,
      formKey: newFormKey(),
      readColumn: async () => {
        const row = await tx.deal.findUnique({ where: { id: dealId }, select: { manualReversalRequired: true } })
        return row?.manualReversalRequired ?? null
      },
    })
    if (record.outcome !== 'created') throw new Error(notAllowed)

    const cleared = await tx.deal.updateMany({ where: guard, data: { manualReversalRequired: false } })
    // throw (نه return) تا رکورد تاریخچه‌ی بالا هم rollback بشه.
    if (cleared.count !== 1) throw new Error(notAllowed)
  })

  await logAudit('deal', `ثبت بازگشت دستی وجه معامله ${dealId.slice(0, 8)}`, user.id, {
    dealId,
    action: 'manual_reversal_done',
  })
  revalidatePath('/admin-deals')
}

/**
 * بازبینیِ دستیِ یک «درخواست خرید» که پس از لغوِ معامله توسط ثبت‌کننده‌اش به حالت
 * میانیِ 'needs_review' رفته (قرینه‌ی سمتِ عرضه: needs_reverification در آگهی). دو تصمیم:
 *   • approve ⇒ از مسیر صفِ رزرو منتشر می‌شود: اگر کسی در صف منتظر باشد درخواست 'reserved'
 *     می‌ماند و نفر اولِ صف مطلع می‌شود؛ وگرنه status → 'open' و دوباره در بازار (دمَند) است.
 *   • reject  ⇒ status → 'closed': خارج از بازار می‌ماند (وضعیت پایانی) و صفِ رزروِ آن بسته می‌شود.
 * شرط status:'needs_review' داخل UPDATE اتمیک/idempotent است (بدون تغییر → خطا).
 * فقط کاربران پنل (مدیر یا کارشناس) — مستقل از UI.
 */
export async function reviewPurchaseRequestAction(formData: FormData) {
  const currentUser = await getCurrentUser()
  if (currentUser.role !== 'admin' && currentUser.role !== 'staff') {
    throw new AccessDeniedError('A-ROLE-DEALS', 'فقط کاربران پنل (مدیر یا کارشناس) مجاز به بازبینی درخواست خریدند.')
  }

  const requestId = String(formData.get('requestId') || '')
  const decision = String(formData.get('decision') || '')
  if (!requestId) return
  if (decision !== 'approve' && decision !== 'reject') throw new Error('تصمیم نامعتبر.')

  const ALREADY_REVIEWED = 'این درخواست پیدا نشد یا قبلاً بازبینی شده است.'
  const reviewed = await prisma.$transaction(async (tx) => {
    if (decision === 'approve') {
      // releaseItemInTx(from:'needs_review') تغییرِ وضعیت را شرطی (needs_review → reserved|open) انجام می‌دهد؛
      // نه نفر مطلع‌شده و نه بازگشت به pool یعنی درخواست دیگر needs_review نبوده (قبلاً بازبینی شده).
      const res = await releaseItemInTx(tx, 'BUY', requestId, 'needs_review')
      if (!res.promoted && !res.returnedToPool) throw new Error(ALREADY_REVIEWED)
      return { to: res.promoted ? 'reserved' : 'open', promote: res }
    }
    const closed = await tx.purchaseRequest.updateMany({
      where: { id: requestId, status: 'needs_review' },
      data: { status: 'closed' },
    })
    if (closed.count === 0) throw new Error(ALREADY_REVIEWED)
    await closeRunInTx(tx, 'BUY', requestId)
    return { to: 'closed', promote: null }
  })
  if (reviewed.promote) await notifyPromoted('BUY', requestId, reviewed.promote)

  await logAudit('deal', `بازبینی درخواست خرید ${requestId.slice(0, 8)} — ${decision === 'approve' ? 'انتشار مجدد' : 'بستن'}`, currentUser.id, {
    requestId,
    action: 'purchase_request_reviewed',
    decision,
    to: reviewed.to,
  })
  revalidatePath('/admin-deals')
}

// ================================================================ حسابداری معامله

/**
 * وضعیت فرم‌های حسابداری معامله (useActionState). خطای ورودی «مقدار برگشتی»ه، نه exception؛ مقدارهای تایپ‌شده
 * با کلید نام فیلد برمی‌گردن، چون React بعد از هر اکشن فیلدهای کنترل‌نشده را reset می‌کنه. موفقیت = null.
 */
export type DealAccountingFormState = {
  error: string | null
  values?: Record<string, string>
} | null

/**
 * خطای قابل‌نمایش در فرم‌های حسابداری: داخل تراکنش throw می‌شه تا همه‌چیز rollback بشه و
 * runAccountingTx اون رو به «مقدار برگشتی» تبدیل می‌کنه. private، چون از فایل 'use server' فقط تابع async export می‌شه.
 */
class DealAccountingError extends Error {}

const ACCOUNTING_FORM_KEY_ERROR = 'کلید فرم نامعتبره — صفحه رو دوباره باز کن.'
const ACCOUNTING_DRIFT_ERROR = 'ناهمخوانی در تاریخچه‌ی مالی این معامله پیدا شد؛ ذخیره متوقف شد. به مدیر سیستم اطلاع بده.'

/**
 * فیلدهای حسابداریِ قابل‌ویرایش با برچسب پیام خطا. union بسته: فرمِ دست‌کاری‌شده نمی‌تونه ستون دیگه‌ای رو بنویسه.
 * همه‌شون Float? روی Deal و Tier B (تاریخچه + ستون)ن. فقط weightKg، cargoInsuranceToman و buyerTaxToman توی جمع کل می‌رن
 * (کارمزد و مالیات فروشنده عمداً نه — پول دو طرفِ جدا)؛ summaryWithAccountingField همین رو اعمال می‌کنه.
 */
const ACCOUNTING_FIELD_LABELS = {
  weightKg: 'وزن (تن)',
  dealFeeToman: 'کارمزد معامله (تومان)',
  cargoInsuranceToman: 'بیمه‌ی بار (تومان)',
  buyerTaxToman: 'مالیات خریدار (تومان)',
  sellerTaxToman: 'مالیات فروشنده (تومان)',
  paidToman: 'مبلغ پرداخت‌شده (تومان)',
} as const
type AccountingFieldName = keyof typeof ACCOUNTING_FIELD_LABELS

function isAccountingField(value: string): value is AccountingFieldName {
  return Object.prototype.hasOwnProperty.call(ACCOUNTING_FIELD_LABELS, value)
}

function formText(formData: FormData, name: string): string {
  const value = formData.get(name)
  return typeof value === 'string' ? value : ''
}

/**
 * ورودیِ یک فیلد حسابداری → مقدار ستون. وزن به «تن» (حداکثر ۳ رقم اعشار) تایپ می‌شه و به کیلوی صحیح تبدیل
 * می‌شه؛ بقیه تومانِ صحیح. خالی = null (واردنشده = ۰ در جمع)، صفر صریح مجاز. هیچ مقداری از جای دیگه پر نمی‌شه.
 */
function parseAccountingValue(
  field: AccountingFieldName,
  raw: unknown,
): { ok: true; value: number | null } | { ok: false; error: string } {
  const label = ACCOUNTING_FIELD_LABELS[field]
  if (field === 'weightKg') {
    const ton = parseTonInput(raw, { label, optional: true })
    if (!ton.ok) return { ok: false, error: ton.error }
    if (ton.value === null) return { ok: true, value: null }
    try {
      return { ok: true, value: tonToKgStrict(ton.value) }
    } catch (error) {
      if (error instanceof MoneyCalcError) return { ok: false, error: error.message }
      throw error
    }
  }
  const money = parseMoneyInput(raw, { label, optional: true, allowZero: true })
  if (!money.ok) return { ok: false, error: money.error }
  return { ok: true, value: money.value }
}

/**
 * قفل مشورتیِ تراکنشیِ «دفتر» یک معامله: همه‌ی ویرایش‌های حسابداریِ همین معامله پشت‌سرهم می‌شن، پس اعتبارسنجیِ
 * جمع کل (بعد از قفل) همیشه روی وضعیتِ commit‌شده‌ی آخرین ویرایش انجام می‌شه و دو ویرایشِ هم‌زمان نمی‌تونن هر
 * کدوم جدا معتبر و با‌هم نامعتبر باشن. همیشه «قبل» از قفل زنجیره‌ی تاریخچه (appendFinancialRecord) گرفته می‌شه تا
 * ترتیب قفل‌ها ثابت و بدون deadlock بمونه. با پایان تراکنش آزاد می‌شه.
 */
async function lockDealLedger(tx: Prisma.TransactionClient, dealId: string): Promise<void> {
  const lockKey = `deal-ledger:${dealId}`
  await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${lockKey}))`
}

/**
 * ستون‌هایی که اکشن‌های حسابداری می‌خونن/می‌نویسن + پرداخت‌ها (برای گارد قیمت) + تعدیل‌های فعال (برای جمع) +
 * سطح تاییدِ ثبت‌شده و وزنِ آگهی/درخواست (برای سقف تایید، approvalCeilingAfterEdit). مبنای وزن در سقف تایید
 * فقط quantityTon آگهی/درخواسته، نه متنِ Deal.quantity.
 */
async function loadDealLedger(tx: Prisma.TransactionClient, dealId: string) {
  const deal = await tx.deal.findUnique({
    where: { id: dealId },
    select: {
      status: true,
      escrowStatus: true,
      approvalLevel: true,
      materialListing: { select: { quantityTon: true } },
      purchaseRequest: { select: { quantityTon: true } },
      agreedPrice: true,
      weightKg: true,
      dealFeeToman: true,
      cargoInsuranceToman: true,
      buyerTaxToman: true,
      sellerTaxToman: true,
      paidToman: true,
      totalOverrideToman: true,
      payments: { select: { status: true } },
      ledgerAdjustments: { where: { isDeleted: false }, select: { id: true, amountToman: true, direction: true } },
    },
  })
  if (!deal) throw new DealAccountingError('معامله پیدا نشد.')
  return deal
}
type DealLedger = Awaited<ReturnType<typeof loadDealLedger>>

/** ورودیِ موتور جمع کل (money.ts) از ستون‌های ذخیره‌شده. excludeAdjustmentId برای «اگه این تعدیل حذف بشه». */
function baseSummaryInput(deal: DealLedger, excludeAdjustmentId?: string): DealSummaryInput {
  return {
    unitPriceToman: deal.agreedPrice,
    weightKg: deal.weightKg,
    insuranceToman: deal.cargoInsuranceToman,
    buyerTaxToman: deal.buyerTaxToman,
    overrideToman: deal.totalOverrideToman,
    adjustments: deal.ledgerAdjustments
      .filter((adjustment) => adjustment.id !== excludeAdjustmentId)
      .map((adjustment) => ({
        amountToman: adjustment.amountToman,
        direction: adjustment.direction as DealAdjustmentDirection,
      })),
  }
}

/** ورودیِ جمع کل «بعد از تغییر این فیلد»؛ null یعنی این فیلد توی جمع کل نیست و اعتبارسنجی لازم نداره. */
function summaryWithAccountingField(
  input: DealSummaryInput,
  field: AccountingFieldName,
  value: number | null,
): DealSummaryInput | null {
  switch (field) {
    case 'weightKg':
      return { ...input, weightKg: value }
    case 'cargoInsuranceToman':
      return { ...input, insuranceToman: value }
    case 'buyerTaxToman':
      return { ...input, buyerTaxToman: value }
    default:
      return null
  }
}

/** جمعِ حاصل از تغییر باید قابل‌محاسبه باشه (منفی، بیش از سقف یا داده‌ی نامعتبر = رد، قبل از هر نوشتن). */
function assertSummaryValid(input: DealSummaryInput): void {
  try {
    summarizeDeal(input)
  } catch (error) {
    if (error instanceof MoneyCalcError) throw new DealAccountingError(error.message)
    throw error
  }
}

/**
 * گارد ویرایش قیمت واحد (agreedPrice): دلیلِ قفل یا null. به‌روز نگه داشتن با نمایش صفحه (admin-deals/page.tsx،
 * agreedPriceLockReason) با خودته: اون کپیِ «نمایشی»ه و این‌جا مرجعِ امنیتیه (از فایل 'use server' نمی‌شه export کرد).
 * قفل: معامله‌ی void/cancelled/settled، وجهِ آزادشده (released_manual)، یا هر DealPayment با وضعیت SUBMITTED/APPROVED.
 */
function agreedPriceLockReason(deal: {
  status: string
  escrowStatus: string
  payments: readonly { status: string }[]
}): string | null {
  if (['void', 'cancelled', 'settled'].includes(deal.status)) {
    return 'قیمت معامله‌ی لغو/باطل/تسویه‌شده قابل تغییر نیست.'
  }
  if (deal.escrowStatus === 'released_manual') return 'وجه این معامله آزاد شده؛ قیمت قابل تغییر نیست.'
  if (deal.payments.some((payment) => payment.status === 'SUBMITTED' || payment.status === 'APPROVED')) {
    return 'برای این معامله پرداخت ثبت یا تایید شده؛ قیمت قابل تغییر نیست.'
  }
  return null
}

/**
 * قفلِ «انتظار تایید» (C9): معامله‌ی awaiting_approval با قیمتِ مثبت برای همان مبلغی که ادمین می‌بینه تایید می‌شه؛
 * تا تایید یا لغو، نه قیمت واحد و نه وزن تغییر نمی‌کنن. معامله‌ی بدونِ قیمت (null/۰) که برای تاییدِ ادمین نگه داشته شده
 * قفل نیست، چون ادمین باید بتونه همون‌جا قیمت/وزن رو وارد کنه. کپیِ «نمایشی»: admin-deals/page.tsx (approvalHoldLockReason).
 */
function approvalHoldLockReason(deal: { status: string; agreedPrice: number | null }): string | null {
  if (deal.status === 'awaiting_approval' && (deal.agreedPrice ?? 0) > 0) {
    return 'معامله در انتظار تاییده؛ اول تایید یا لغو کن.'
  }
  return null
}

/**
 * ترتیب سطح تایید: auto < supervisor < manager < admin. همان hierarchy داخل evaluateApprovalRequirement
 * (priceEngine.ts)ـه؛ از اون فایل 'use server' نمی‌شه export کرد، پس این‌جا کپی شده و با عوض‌شدنِ اون ترتیب باید عوض بشه.
 */
const APPROVAL_LEVELS = {
  auto: { rank: 0, label: 'بدون نیاز به تایید' },
  supervisor: { rank: 1, label: 'سرپرست' },
  manager: { rank: 2, label: 'مدیر' },
  admin: { rank: 3, label: 'ادمین' },
} as const

/** null = خودکار (همان قرارداد ستون Deal.approvalLevel). سطح ناشناخته = داده‌ی خراب = رد (fail closed). */
function approvalLevelInfo(level: string | null): { rank: number; label: string } {
  if (level === null) return APPROVAL_LEVELS.auto
  if (!Object.prototype.hasOwnProperty.call(APPROVAL_LEVELS, level)) {
    throw new DealAccountingError('سطح تاییدِ ثبت‌شده‌ی معامله نامعتبره؛ به مدیر سیستم اطلاع بده.')
  }
  return APPROVAL_LEVELS[level as keyof typeof APPROVAL_LEVELS]
}

const APPROVAL_CONCURRENT_ERROR = 'معامله هم‌زمان تغییر کرد؛ صفحه رو دوباره باز کن و دوباره امتحان کن.'

/** تغییری که می‌خوایم روی قیمت/وزن اعمال کنیم؛ کلیدِ غایب = بدون تغییر، weightKg: null = پاک‌کردن. */
type DealApprovalEdit = { agreedPrice?: number; weightKg?: number | null }
type ApprovalCeiling = { amount: number | null; requiredLevel: string | null }

/**
 * مبلغ مبنای تایید (جمع کالا = قیمت واحد × وزن؛ بدون بیمه/مالیات/تعدیل) «بعد از» ویرایش. null = قیمت واردنشده.
 * وزنِ نامشخص/خراب با قیمتِ مثبت خطای فارسیه (MoneyCalcError → DealAccountingError)، نه رد‌شدنِ بی‌صدا.
 */
function approvalAmountAfterEdit(deal: DealLedger, edit: DealApprovalEdit): number | null {
  try {
    return dealApprovalAmountToman({
      agreedPrice: edit.agreedPrice !== undefined ? edit.agreedPrice : deal.agreedPrice,
      weightKg: edit.weightKg !== undefined ? edit.weightKg : deal.weightKg,
      listedTon: deal.materialListing?.quantityTon ?? deal.purchaseRequest?.quantityTon,
    })
  } catch (error) {
    if (error instanceof MoneyCalcError) throw new DealAccountingError(error.message)
    throw error
  }
}

/**
 * «بیرون از تراکنش»: مبلغ بعد از ویرایش و سطحِ تاییدِ لازم برای آن از موتور تایید. موتور یک خواندنِ جدا از دیتابیسه؛
 * عمداً داخل تراکنشِ مالی صدا زده نمی‌شه تا هم‌زمان با نگه‌داشتنِ یک اتصال، اتصال دوم نخواد. null = پیش‌نویس (هنوز از
 * دروازه‌ی تایید نگذشته؛ startBuyerPaymentDeadline مبلغ نهایی رو می‌سنجه). ممکنه DealAccountingError پرت کنه.
 */
async function approvalCeilingAfterEdit(deal: DealLedger, edit: DealApprovalEdit): Promise<ApprovalCeiling | null> {
  if (deal.status === 'draft') return null
  const amount = approvalAmountAfterEdit(deal, edit)
  const requiredLevel = amount === null ? null : await evaluateApprovalRequirement('Deal', amount)
  return { amount, requiredLevel }
}

/**
 * «داخل تراکنش و زیر قفل دفتر»: ویرایشی که سطح تاییدِ لازم رو از سطحِ ثبت‌شده‌ی معامله (Deal.approvalLevel) بالاتر
 * ببره رد می‌شه (رد، نه برگرداندن وضعیت: برگرداندن مهلت‌ها رو دست می‌زد). معامله بین خواندنِ بیرونی و قفل عوض شده باشه
 * (وضعیت یا مبلغ) = خطای هم‌زمانی، چون سطحِ لازم روی مبلغِ قبلی سنجیده شده.
 */
function assertWithinApprovedLevel(deal: DealLedger, edit: DealApprovalEdit, ceiling: ApprovalCeiling | null): void {
  if ((deal.status === 'draft') !== (ceiling === null)) throw new DealAccountingError(APPROVAL_CONCURRENT_ERROR)
  if (ceiling === null) return
  if (approvalAmountAfterEdit(deal, edit) !== ceiling.amount) throw new DealAccountingError(APPROVAL_CONCURRENT_ERROR)

  const stored = approvalLevelInfo(deal.approvalLevel)
  const required = approvalLevelInfo(ceiling.requiredLevel)
  if (required.rank > stored.rank) {
    throw new DealAccountingError(
      `با این تغییر مبلغ معامله به سطح تاییدِ «${required.label}» می‌رسه، ولی سطحِ تاییدِ ثبت‌شده‌ی این معامله «${stored.label}»ه؛ ` +
        'ویرایش رد شد. اگه لازمه، معامله رو لغو کن و دوباره ثبت کن.',
    )
  }
}

type ApprovalPrecheck =
  | { ok: true; ceiling: ApprovalCeiling | null }
  | { ok: false; state: NonNullable<DealAccountingFormState> }

/**
 * پیش‌بررسیِ بدون قفل و بیرون از تراکنش برای ویرایشِ قیمت/وزن: قفل‌ها (lockReason) و سقفِ تایید. در حالتِ قفل‌شده یا
 * ردشده تراکنش ساخته نمی‌شه؛ مرجعِ نهاییِ هر دو همان چکِ داخل تراکنشه (assertWithinApprovedLevel).
 */
async function precheckApprovalEdit(
  dealId: string,
  edit: DealApprovalEdit,
  values: Record<string, string>,
  lockReason: (deal: DealLedger) => string | null,
): Promise<ApprovalPrecheck> {
  try {
    const current = await loadDealLedger(prisma, dealId)
    const lock = lockReason(current)
    if (lock) return { ok: false, state: { error: lock, values } }
    return { ok: true, ceiling: await approvalCeilingAfterEdit(current, edit) }
  } catch (error) {
    if (error instanceof DealAccountingError) return { ok: false, state: { error: error.message, values } }
    throw error
  }
}

type AccountingTxResult<T> =
  | { ok: true; value: T }
  | { ok: false; state: NonNullable<DealAccountingFormState> }

/**
 * تراکنشِ مالیِ فرم‌های حسابداری: خطای قابل‌نمایش (DealAccountingError) و ناهمخوانی تاریخچه به «مقدار برگشتی» با
 * مقدارهای تایپ‌شده تبدیل می‌شن؛ هر خطای دیگه rethrow می‌شه. لاگ drift را runFinancialTx می‌نویسه.
 */
async function runAccountingTx<T>(
  userId: string,
  meta: Record<string, unknown>,
  values: Record<string, string>,
  work: (tx: Prisma.TransactionClient) => Promise<T>,
): Promise<AccountingTxResult<T>> {
  try {
    return { ok: true, value: await runFinancialTx(userId, meta, work) }
  } catch (error) {
    if (error instanceof DealAccountingError) return { ok: false, state: { error: error.message, values } }
    if (error instanceof FinancialDriftError) return { ok: false, state: { error: ACCOUNTING_DRIFT_ERROR, values } }
    throw error
  }
}

/**
 * ثبتِ مستقلِ یکی از فیلدهای حسابداری (وزن، کارمزد، بیمه، مالیات خریدار/فروشنده، مبلغ پرداخت‌شده). همه دستی‌ان؛
 * هیچ مقداری از آگهی/درخواست یا فرمول پر نمی‌شه. رکورد تاریخچه «قبل» از ستون و در همان تراکنش می‌آد (Tier B)؛
 * ستون فقط وقتی نوشته می‌شه که رکورد 'created' باشه (دوبارکلیک/بدون‌تغییر = بی‌صدا رد). فیلدهای داخل جمع کل
 * قبل از نوشتن با موتور money.ts اعتبارسنجی می‌شن.
 */
export async function setDealAccountingFieldAction(
  _prevState: DealAccountingFormState,
  formData: FormData,
): Promise<DealAccountingFormState> {
  const user = await requireDealsEditAccess()
  const dealId = formText(formData, 'dealId')
  const field = formText(formData, 'field')
  const formKey = formText(formData, 'formKey')
  const values = { value: formText(formData, 'value') }

  if (!dealId || !isAccountingField(field)) throw new Error('معامله یا فیلد نامعتبره.')
  if (!formKey) return { error: ACCOUNTING_FORM_KEY_ERROR, values }

  const parsed = parseAccountingValue(field, formData.get('value'))
  if (!parsed.ok) return { error: parsed.error, values }
  const newValue = parsed.value

  // وزن مبنای سقف تاییده (C9)؛ فقط برای همین فیلد قفلِ «انتظار تایید» و سقف سطح تایید بیرون از تراکنش سنجیده می‌شه.
  const isWeight = field === 'weightKg'
  let ceiling: ApprovalCeiling | null = null
  if (isWeight) {
    const precheck = await precheckApprovalEdit(dealId, { weightKg: newValue }, values, approvalHoldLockReason)
    if (!precheck.ok) return precheck.state
    ceiling = precheck.ceiling
  }

  const result = await runAccountingTx(user.id, { dealId, field }, values, async (tx) => {
    await lockDealLedger(tx, dealId)
    const deal = await loadDealLedger(tx, dealId)

    if (isWeight) {
      const lock = approvalHoldLockReason(deal)
      if (lock) throw new DealAccountingError(lock)
      assertWithinApprovedLevel(deal, { weightKg: newValue }, ceiling)
    }

    const candidate = summaryWithAccountingField(baseSummaryInput(deal), field, newValue)
    if (candidate) assertSummaryValid(candidate)

    const record = await appendFinancialRecord(tx, {
      entityType: 'Deal',
      entityId: dealId,
      fieldName: field,
      newValue,
      changedBy: user.id,
      formKey,
      // ستون زیر قفل دفتر خونده شده؛ همه‌ی نویسنده‌های این ستون‌ها از همین اکشن‌ها و همین قفل رد می‌شن.
      readColumn: async () => deal[field],
    })
    if (record.outcome !== 'created') return false

    const data: Prisma.DealUpdateInput = {}
    data[field] = newValue
    await tx.deal.update({ where: { id: dealId }, data })
    return true
  })
  if (!result.ok) return result.state

  if (result.value) {
    await logAudit('deal', `ثبت ${ACCOUNTING_FIELD_LABELS[field]} معامله ${dealId.slice(0, 8)}`, user.id, {
      dealId,
      field,
      cleared: newValue === null,
      action: 'accounting_field_set',
    })
  }
  revalidatePath('/admin-deals')
  return null
}

/**
 * ویرایش قیمت واحد معامله (agreedPrice، تومان بر کیلو) توسط ادمین؛ الزامی است و پاک نمی‌شه. گارد (agreedPriceLockReason +
 * approvalHoldLockReason) و سقفِ سطح تایید (assertWithinApprovedLevel، C9) هم بیرون و هم داخل تراکنش چک می‌شه.
 * DealPayment.amount خودکار عوض نمی‌شه (UI هشدار می‌ده). این ستون از قبل Tier B
 * بود (ساخت معامله در market/actions)، پس همان زنجیره‌ی تاریخچه ادامه پیدا می‌کنه.
 */
export async function setDealAgreedPriceAction(
  _prevState: DealAccountingFormState,
  formData: FormData,
): Promise<DealAccountingFormState> {
  const user = await requireDealsEditAccess()
  const dealId = formText(formData, 'dealId')
  const formKey = formText(formData, 'formKey')
  const values = { value: formText(formData, 'value') }

  if (!dealId) throw new Error('معامله نامعتبره.')
  if (!formKey) return { error: ACCOUNTING_FORM_KEY_ERROR, values }

  const parsed = parseMoneyInput(formData.get('value'), { label: 'قیمت واحد (تومان/کیلو)' })
  if (!parsed.ok) return { error: parsed.error, values }
  const price = parsed.value

  // پیش‌بررسیِ بدون قفل: در حالتِ قفل‌شده یا ردشده تراکنش و قفل مشورتی ساخته نمی‌شه. مرجعِ نهایی همان چکِ داخل تراکنشه.
  const precheck = await precheckApprovalEdit(
    dealId,
    { agreedPrice: price },
    values,
    (deal) => agreedPriceLockReason(deal) ?? approvalHoldLockReason(deal),
  )
  if (!precheck.ok) return precheck.state
  const ceiling = precheck.ceiling

  const result = await runAccountingTx(user.id, { dealId, field: 'agreedPrice' }, values, async (tx) => {
    await lockDealLedger(tx, dealId)
    const deal = await loadDealLedger(tx, dealId)

    const lock = agreedPriceLockReason(deal) ?? approvalHoldLockReason(deal)
    if (lock) throw new DealAccountingError(lock)
    assertWithinApprovedLevel(deal, { agreedPrice: price }, ceiling)
    assertSummaryValid({ ...baseSummaryInput(deal), unitPriceToman: price })

    const record = await appendFinancialRecord(tx, {
      entityType: 'Deal',
      entityId: dealId,
      fieldName: 'agreedPrice',
      newValue: price,
      changedBy: user.id,
      formKey,
      readColumn: async () => deal.agreedPrice,
    })
    if (record.outcome !== 'created') return false

    await tx.deal.update({ where: { id: dealId }, data: { agreedPrice: price } })
    return true
  })
  if (!result.ok) return result.state

  if (result.value) {
    await logAudit('deal', `ویرایش قیمت واحد معامله ${dealId.slice(0, 8)}`, user.id, {
      dealId,
      action: 'agreed_price_set',
    })
  }
  revalidatePath('/admin-deals')
  return null
}

/**
 * جمع کل دستی (override) یک معامله. intent=clear مقدار رو پاک می‌کنه (برمی‌گرده به جمع محاسبه‌شده)؛ مقدار خالی
 * بدون clear خطاست، تا کلیکِ اشتباه override رو پاک نکنه. هر دو مسیر در تاریخچه ثبت می‌شن (Tier B).
 */
export async function setDealTotalOverrideAction(
  _prevState: DealAccountingFormState,
  formData: FormData,
): Promise<DealAccountingFormState> {
  const user = await requireDealsEditAccess()
  const dealId = formText(formData, 'dealId')
  const formKey = formText(formData, 'formKey')
  const clear = formText(formData, 'intent') === 'clear'
  const values = { value: formText(formData, 'value') }

  if (!dealId) throw new Error('معامله نامعتبره.')
  if (!formKey) return { error: ACCOUNTING_FORM_KEY_ERROR, values }

  let newValue: number | null = null
  if (!clear) {
    const parsed = parseMoneyInput(formData.get('value'), { label: 'جمع کل دستی (تومان)' })
    if (!parsed.ok) return { error: parsed.error, values }
    newValue = parsed.value
  }

  const result = await runAccountingTx(user.id, { dealId, field: 'totalOverrideToman' }, values, async (tx) => {
    await lockDealLedger(tx, dealId)
    const deal = await loadDealLedger(tx, dealId)
    assertSummaryValid({ ...baseSummaryInput(deal), overrideToman: newValue })

    const record = await appendFinancialRecord(tx, {
      entityType: 'Deal',
      entityId: dealId,
      fieldName: 'totalOverrideToman',
      newValue,
      changedBy: user.id,
      formKey,
      readColumn: async () => deal.totalOverrideToman,
    })
    if (record.outcome !== 'created') return false

    await tx.deal.update({ where: { id: dealId }, data: { totalOverrideToman: newValue } })
    return true
  })
  if (!result.ok) return result.state

  if (result.value) {
    await logAudit('deal', `${clear ? 'حذف' : 'ثبت'} جمع کل دستی معامله ${dealId.slice(0, 8)}`, user.id, {
      dealId,
      cleared: clear,
      action: 'total_override_set',
    })
  }
  revalidatePath('/admin-deals')
  return null
}

/**
 * افزودن یک ردیف تعدیل (افزایش/کاهش با شرح الزامی) به جمع کل معامله. مبلغ همیشه مثبته و جهتش در direction‌ه.
 * ردیف و رکوردهای ساختِ تاریخچه (مبلغ، جهت، شرح، isDeleted=false) در یک تراکنش‌ان. ضد دوبارکلیک: formKey ستونِ
 * یکتای ردیفه و زیر قفل دفتر چک می‌شه (ارسال دوباره‌ی همان فرم بی‌صدا رد می‌شه).
 */
export async function addDealAdjustmentAction(
  _prevState: DealAccountingFormState,
  formData: FormData,
): Promise<DealAccountingFormState> {
  const user = await requireDealsEditAccess()
  const dealId = formText(formData, 'dealId')
  const formKey = formText(formData, 'formKey')
  const values = {
    direction: formText(formData, 'direction'),
    amount: formText(formData, 'amount'),
    description: formText(formData, 'description'),
  }

  if (!dealId) throw new Error('معامله نامعتبره.')
  if (!formKey) return { error: ACCOUNTING_FORM_KEY_ERROR, values }

  if (values.direction !== 'increase' && values.direction !== 'decrease') {
    return { error: 'جهت تعدیل رو انتخاب کن (افزایش یا کاهش).', values }
  }
  const direction: DealAdjustmentDirection = values.direction
  const parsed = parseMoneyInput(formData.get('amount'), { label: 'مبلغ تعدیل (تومان)' })
  if (!parsed.ok) return { error: parsed.error, values }
  const amountToman = parsed.value
  const description = values.description.trim()
  if (description.length === 0) return { error: 'شرح تعدیل الزامیه.', values }
  if (description.length > 200) return { error: 'شرح تعدیل حداکثر ۲۰۰ نویسه می‌تونه باشه.', values }

  const result = await runAccountingTx(user.id, { dealId, entity: 'DealLedgerAdjustment' }, values, async (tx) => {
    await lockDealLedger(tx, dealId)
    const deal = await loadDealLedger(tx, dealId)

    const existing = await tx.dealLedgerAdjustment.findUnique({ where: { formKey }, select: { dealId: true } })
    if (existing) {
      if (existing.dealId !== dealId) throw new DealAccountingError(ACCOUNTING_FORM_KEY_ERROR)
      return false // همین فرم قبلاً ثبت شده (دوبارکلیک)
    }

    const base = baseSummaryInput(deal)
    assertSummaryValid({ ...base, adjustments: [...(base.adjustments ?? []), { amountToman, direction }] })

    const created = await tx.dealLedgerAdjustment.create({
      data: { dealId, amountToman, direction, description, formKey, createdById: user.id },
      select: { id: true },
    })
    // رکوردهای ساخت (Tier A): ردیف همین الان با همین مقدارها ساخته شد، پس readColumn نمی‌خواد.
    const initial = [
      ['amountToman', amountToman],
      ['direction', direction],
      ['description', description],
      ['isDeleted', false],
    ] as const
    for (const [fieldName, newValue] of initial) {
      await appendFinancialRecord(tx, {
        entityType: 'DealLedgerAdjustment',
        entityId: created.id,
        fieldName,
        newValue,
        changedBy: user.id,
        formKey,
      })
    }
    return true
  })
  if (!result.ok) return result.state

  if (result.value) {
    await logAudit('deal', `افزودن تعدیل به معامله ${dealId.slice(0, 8)}`, user.id, {
      dealId,
      direction,
      action: 'ledger_adjustment_added',
    })
  }
  revalidatePath('/admin-deals')
  return null
}

/**
 * حذفِ نرم یک ردیف تعدیل (isDeleted=true؛ ردیف و تاریخچه‌اش می‌مونن). حذف یک «کاهش» جمع رو بالا می‌بره و حذف یک
 * «افزایش» ممکنه جمع رو منفی کنه، پس جمعِ بعد از حذف هم قبل از نوشتن اعتبارسنجی می‌شه. ردیفِ از قبل حذف‌شده بی‌صدا رد می‌شه.
 */
export async function deleteDealAdjustmentAction(
  _prevState: DealAccountingFormState,
  formData: FormData,
): Promise<DealAccountingFormState> {
  const user = await requireDealsEditAccess()
  const adjustmentId = formText(formData, 'adjustmentId')
  const formKey = formText(formData, 'formKey')

  if (!adjustmentId) throw new Error('تعدیل نامعتبره.')
  if (!formKey) return { error: ACCOUNTING_FORM_KEY_ERROR, values: {} }

  const result = await runAccountingTx(user.id, { adjustmentId }, {}, async (tx) => {
    // معامله‌ی ردیف قبل از قفل معلوم می‌شه (dealId هیچ‌وقت عوض نمی‌شه)؛ بعد از قفل، ردیف دوباره خونده می‌شه.
    const probe = await tx.dealLedgerAdjustment.findUnique({ where: { id: adjustmentId }, select: { dealId: true } })
    if (!probe) throw new DealAccountingError('تعدیل پیدا نشد.')
    const dealId = probe.dealId

    await lockDealLedger(tx, dealId)
    const adjustment = await tx.dealLedgerAdjustment.findUnique({
      where: { id: adjustmentId },
      select: { isDeleted: true },
    })
    if (!adjustment) throw new DealAccountingError('تعدیل پیدا نشد.')
    if (adjustment.isDeleted) return { dealId, deleted: false }

    const deal = await loadDealLedger(tx, dealId)
    assertSummaryValid(baseSummaryInput(deal, adjustmentId))

    const record = await appendFinancialRecord(tx, {
      entityType: 'DealLedgerAdjustment',
      entityId: adjustmentId,
      fieldName: 'isDeleted',
      newValue: true,
      changedBy: user.id,
      formKey,
      readColumn: async () => adjustment.isDeleted,
    })
    if (record.outcome !== 'created') return { dealId, deleted: false }

    await tx.dealLedgerAdjustment.update({
      where: { id: adjustmentId },
      data: { isDeleted: true, deletedAt: new Date(), deletedById: user.id },
    })
    return { dealId, deleted: true }
  })
  if (!result.ok) return result.state

  if (result.value.deleted) {
    await logAudit('deal', `حذف تعدیل معامله ${result.value.dealId.slice(0, 8)}`, user.id, {
      dealId: result.value.dealId,
      adjustmentId,
      action: 'ledger_adjustment_deleted',
    })
  }
  revalidatePath('/admin-deals')
  return null
}
