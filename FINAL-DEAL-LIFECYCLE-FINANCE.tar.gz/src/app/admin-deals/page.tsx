import prisma from '@/lib/prisma'
import { getAllSectionAccess } from '@/lib/permissions'
import { getCurrentUser } from '@/lib/currentUser'
import { enforceDealDeadlines, getDealRuleSettings, getRecentDeadlineRuns, PENALTY_HOURS_OPTIONS } from '@/lib/dealDeadlines'
import { listHolidays } from '@/lib/holidays'
import { getServerClockDriftMs } from '@/lib/onlineTime'
import { tehranJalaliDisplay, tehranClockDisplay } from '@/lib/tehranClock'
import { DEADLINE_FIELD_LABELS } from '@/lib/deadlineAdjustments'
import AdminNav from '@/components/AdminNav'
import DealPartyCard, { DealPartyFieldRow as FieldRow } from '@/components/DealPartyCard'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'
import RefundPolicyHint from '@/components/RefundPolicyHint'
import { confirmFundsReleased, addHolidayAction, removeHolidayAction, adjustDeadlineAction, importHolidaysAction, updateDealRulesAction, runDeadlineEnforcementNowAction, updateDealPaymentInstructionsAction, updateSellerPaymentInstructionsAction, approveDealAction, approvePaymentAction, rejectPaymentAction, markManualReversalDone, reviewPurchaseRequestAction } from './actions'
import { pageStyle, pageWrapStyle, contentStyle, h1Style, subTitleStyle, cardStyle, tableStyle, theadRowStyle, thStyle, tdStyle, badgeStyle, btnPrimaryStyle, btnSecondaryStyle, btnDangerStyle, btnSmallStyle, inputStyle, selectStyle, labelStyle, emptyStateStyle } from '@/lib/styles/shared'
import { getSurfaceHome } from '@/lib/surfaceHome'
import { newFormKey } from '@/lib/financialHistory'
import { kgToTon, trySummarizeDeal, type DealAdjustmentDirection } from '@/lib/money'
import { DealAdjustmentAddForm, DealAdjustmentDeleteForm, DealAgreedPriceForm, DealFieldForm, DealTotalOverrideForm } from './DealAccountingForms'

export const dynamic = 'force-dynamic'

const STATUS_LABELS: Record<string, string> = {
  draft: 'پیش‌نویس', confirmed: 'تایید شد', awaiting_approval: 'در انتظار تایید مدیر', payment_secured: 'وجه تضمین شد',
  transport_pending: 'در انتظار حمل', void: 'باطل شد',
  loading: 'در حال بارگیری', in_transit: 'در مسیر ارسال', delivered: 'تحویل شد', settled: 'تسویه شد',
}
const PAYMENT_KIND_LABELS: Record<string, string> = {
  BUYER_GOODS: 'وجه کالا (خریدار)', SELLER_FEE: 'کارمزد فروشنده',
}
const PENALTY_LABELS: Record<number, string> = {
  0.5: '۳۰ دقیقه', 1: '۱ ساعت', 3: '۳ ساعت', 24: '۲۴ ساعت', 72: '۷۲ ساعت',
}
const CONFIRMATION_TYPE_LABELS: Record<string, string> = {
  loading: 'تایید بارگیری', unloading: 'تایید تخلیه', driver_confirm: 'تاییدیه راننده', buyer_confirm: 'تاییدیه خریدار',
}
const VERDICT_LABELS: Record<string, { label: string; color: string }> = {
  auto_no_discrepancy: { label: '✅ بدون مغایرت (خودکار)', color: '#146c3a' },
  discrepancy_minor: { label: '⚠️ مغایرت جزئی — فقط ثبت شد', color: '#92400e' },
  discrepancy_severe: { label: '🔴 مغایرت حساس — واریز متوقف شد', color: '#9b1c1c' },
}
const CHECKLIST_LABELS: Record<string, string> = {
  packagingIntact: 'بسته‌بندی سالم', quantityMatches: 'تعداد مطابق سفارش', palletsIntact: 'پالت‌ها سالم',
  productMatchesOrder: 'محصول مطابق سفارش', discrepancyObserved: 'مغایرت مشاهده شد',
  noTransitDamage: 'بدون آسیب حمل', productReceived: 'محصول دریافت شد', discrepancyExists: 'مغایرت وجود دارد',
}

export default async function AdminDealsPage({ searchParams }: { searchParams: Promise<{ imported?: string; skipped?: string }> }) {
  const currentUser = await getCurrentUser()
  const sp = await searchParams
  const importResult = sp.imported !== undefined ? { added: Number(sp.imported) || 0, skipped: Number(sp.skipped) || 0 } : null

  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)
  // هم‌راستا با گیت سمت سرور (requireDealsEditAccess): مدیر همیشه؛ کارشناس فقط با «ویرایش/کامل»
  const canEditDeals = isAdmin || myAccess?.deals === 'edit' || myAccess?.deals === 'full'

  // چون هنوز cron جدا نداریم، هر بار این صفحه لود می‌شه، اول چک می‌کنه
  // آیا مهلت کارمزد فروشنده، پرداخت خریدار، یا بررسی کیفیت برای کسی گذشته —
  // اگه آره، خودکار لغو/تسویه + جریمه‌ی موقت (در مورد اولی) اعمال می‌شه.
  const { cancelledCount, qualityAutoAcceptedCount } = await enforceDealDeadlines()

  const deals = await prisma.deal.findMany({
    include: {
      buyer: { include: { company: { include: { kyc: true } } } },
      seller: { include: { company: { include: { kyc: true } } } },
      // grade با select صریح (نه grade:true) — فقط ۴ فیلدی که این صفحه رندر می‌کنه.
      // این کوئری رو در برابر ناهم‌ترازیِ کلاینتِ Prisma با دیتابیس مصون می‌کنه: با grade:true
      // کلاینت همه‌ی ستون‌های اسکالرِ Grade رو SELECT می‌کرد و اگه کلاینتِ دیپلوی‌شده کهنه بود
      // (ستونِ حذف‌شده‌ی Grade.packagingType رو هنوز می‌شناخت) کلِ مسیر با P2022 کرش می‌کرد.
      materialListing: { include: { grade: { select: { code: true, producer: true, category: true, imageUrl: true } }, user: { include: { company: { include: { kyc: true } } } } } },
      purchaseRequest: { include: { grade: { select: { code: true, producer: true, category: true, imageUrl: true } } } },
      confirmations: { orderBy: { confirmedAt: 'asc' } },
      payments: true,
      // فقط برای گیتِ دکمه‌ی آزادسازی (releaseBlockers): آیا اختلافِ بازی روی معامله هست؟
      disputes: { where: { status: 'open' }, select: { id: true } },
      ledgerAdjustments: { where: { isDeleted: false }, orderBy: { createdAt: 'asc' } },
    },
    orderBy: { createdAt: 'desc' },
  })

  const holidays = isAdmin ? await listHolidays() : []
  const dealRules = isAdmin ? await getDealRuleSettings() : null
  const recentDeadlineRuns = isAdmin ? await getRecentDeadlineRuns(3) : []
  // هشدار «مدتی‌ست اجرا نشده»: cron هر ۱۵ دقیقه است، پس فاصله‌ی بیش از ۴۵ دقیقه یعنی
  // حداقل ۳ تیکِ پشت‌سرهم از دست رفته — نشانه‌ی خوابیدنِ cron/سرویس. اگر هیچ اجرایی ثبت نشده
  // هشدار نمی‌دهیم (پیامِ «هنوز اجرا نشده»ی جداگانه پوشش می‌دهد).
  const lastAutoRunAt = recentDeadlineRuns[0]?.createdAt ?? null
  const minutesSinceLastRun = lastAutoRunAt
    ? Math.floor((Date.now() - new Date(lastAutoRunAt).getTime()) / 60000)
    : null
  const deadlineSchedulerStale = minutesSinceLastRun !== null && minutesSinceLastRun > 45
  const clockDriftMs = isAdmin ? await getServerClockDriftMs() : null

  const allAdjustments = await prisma.deadlineAdjustment.findMany({
    where: { dealId: { in: deals.map((d) => d.id) } },
    orderBy: { createdAt: 'asc' },
    include: { adjustedBy: true },
  })
  const adjustmentsByDeal = new Map<string, typeof allAdjustments>()
  for (const adj of allAdjustments) {
    const list = adjustmentsByDeal.get(adj.dealId) || []
    list.push(adj)
    adjustmentsByDeal.set(adj.dealId, list)
  }

  // صف‌های اقدام مدیر/کارشناس — از همون لیست deals فیلتر می‌شن (کوئری اضافه نمی‌زنیم)
  const awaitingApprovalDeals = deals.filter((d) => d.status === 'awaiting_approval')
  // صف واحدِ بررسی پرداخت (v2): ردیف‌های DealPayment مستقل، نه وضعیتِ معامله. فقط معاملاتِ
  // «تاییدشده» (قیمت‌شان نهایی شده) و پرداخت‌های هنوز بررسی‌نشده (PENDING/SUBMITTED) نمایش داده می‌شوند.
  const reviewablePayments = deals
    .filter((d) => d.status === 'confirmed')
    .flatMap((d) =>
      d.payments
        .filter((p) => p.status === 'PENDING' || p.status === 'SUBMITTED')
        .map((p) => ({ deal: d, payment: p }))
    )

  // صفِ بازبینیِ درخواست‌های خرید (قرینه‌ی سمتِ عرضه): وقتی ثبت‌کننده‌ی یک درخواست، معامله‌ی
  // ساخته‌شده از آن را لغو می‌کند، درخواست به 'needs_review' می‌رود و تا تایید دستی از بازار
  // پنهان می‌ماند. کوئریِ مجزا چون این درخواست‌ها لزوماً دیگر معامله‌ی زنده‌ای ندارند — مثل
  // بقیه‌ی صف‌ها بدون‌شرط اجرا می‌شود (این صفحه گیتِ سخت جدا ندارد). grade با select صریح
  // (هم‌ترازی کلاینت/دیتابیس)؛ user فقط companyName (سطح ادمین، include:{user} اینجا مجاز است).
  const needsReviewRequests = await prisma.purchaseRequest.findMany({
    where: { status: 'needs_review' },
    include: {
      grade: { select: { code: true, producer: true, category: true } },
      user: { select: { companyName: true } },
    },
    orderBy: { createdAt: 'desc' },
  })

  return (
    <div style={pageStyle}>
      <div style={pageWrapStyle}>
        <AdminNav currentUserName={currentUser.companyName} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="deals" homeHref={getSurfaceHome()} />

        <div style={contentStyle}>
          <h1 style={h1Style}>معاملات تجاری</h1>
          <p style={subTitleStyle}>
            این جدا از سفارش‌های مستقیم فروشگاهه — اینجا یه کارخانه‌ی دیگه می‌فروشه، انبار پلیمر فقط واسط وضعیته. هیچ تراکنش بانکی از این صفحه انجام نمی‌شه؛ فقط ثبت وضعیتیه که حسابداری بیرون از سایت انجام داده.
          </p>

          {cancelledCount > 0 && (
            <div style={{ background: '#fef3c7', color: '#92400e', borderRadius: 8, padding: '10px 16px', fontSize: 12.5, fontWeight: 600, marginBottom: 12 }}>
              ⏱ {cancelledCount} مورد به‌خاطر گذشتن مهلت (کارمزد یا پرداخت)، همین الان خودکار لغو و آگهیش دوباره آزاد شد.
            </div>
          )}

          {qualityAutoAcceptedCount > 0 && (
            <div style={{ background: '#fde8e8', color: '#9b1c1c', borderRadius: 8, padding: '10px 16px', fontSize: 12.5, fontWeight: 600, marginBottom: 20 }}>
              🔴 {qualityAutoAcceptedCount} مورد به‌خاطر عدم اقدام خریدار ظرف مهلت، همین الان به‌صورت خودکار تایید و تسویه شد — نیاز به آزادسازی وجه دستی (پایین کارت هر معامله).
            </div>
          )}

          {isAdmin && clockDriftMs !== null && Math.abs(clockDriftMs) > 5 * 60 * 1000 && (
            <div style={{ background: '#fef3c7', color: '#92400e', borderRadius: 8, padding: '8px 16px', fontSize: 11.5, fontWeight: 600, marginBottom: 12 }}>
              🕐 ساعت سرور با ساعت آنلاین حدود {Math.round(Math.abs(clockDriftMs) / 60000)} دقیقه اختلاف داره — این می‌تونه محاسبه‌ی مهلت‌ها رو کمی نادقیق کنه. بهتره تنظیمات ساعت/منطقه‌زمانی سرور (Asia/Tehran) رو چک کنی.
            </div>
          )}

          {isAdmin && (
            <div style={{ ...cardStyle, marginBottom: 24, background: '#fafbfc' }}>
              <h3 style={{ fontSize: 14, fontWeight: 800, marginBottom: 6 }}>⏱ زمان‌بندی و مهلت‌های معامله</h3>
              <p style={{ fontSize: 11.5, color: '#6f7680', marginBottom: 14, lineHeight: 1.9 }}>
                این بخش دو تنظیم کاملاً جداست: <b>«تقویم کاری»</b> مشخص می‌کنه چه روزهایی سایت اصلاً کار حساب می‌شه (برای محاسبه‌ی دقیق مهلت‌ها، نه روز تقویمی خام)،
                و <b>«طول مهلت‌ها»</b> مشخص می‌کنه هر مرحله از معامله چند ساعت/روز کاری فرصت داره. هردو روی محاسبه‌ی مهلت هر معامله اثر می‌ذارن — تقویم می‌گه «کِی»، طول مهلت می‌گه «چقدر».
              </p>

              {/* سطر تاییدِ چشمیِ ساعتِ تهران — پایه‌ی همه‌ی محاسبات مهلت (تبدیلِ آفلاینِ Asia/Tehran، نه ساعتِ UTCِ سرور) */}
              <div style={{ fontSize: 12, fontWeight: 700, color: '#146c3a', background: '#eaf7ee', border: '1px solid #b8e0c4', borderRadius: 8, padding: '8px 14px', marginBottom: 14 }}>
                🕒 الان به وقت تهران: {tehranJalaliDisplay(new Date())} — ساعت {tehranClockDisplay(new Date())}
              </div>

              <details style={{ border: '1px solid #e5e7eb', borderRadius: 10, padding: '10px 16px', marginBottom: 12, background: '#fff' }}>
                <summary style={{ cursor: 'pointer', fontSize: 12.5, fontWeight: 700 }}>📅 تقویم کاری — تعطیلات رسمی</summary>
                <p style={{ fontSize: 11.5, color: '#6f7680', margin: '10px 0' }}>
                  این‌جا فقط تعیین می‌کنه <b>«چه روزهایی سایت تعطیله»</b> — روی محاسبه‌ی همه‌ی مهلت‌های زیر اثر می‌ذاره (نه فقط یکی).
                  جمعه‌ها خودکار حساب می‌شن، لازم نیست اضافه بشن. فقط تعطیلات رسمی/عمومی دیگه رو اینجا اضافه کن.
                </p>

                {importResult && (
                  <div style={{ background: '#eaf6ee', color: '#146c3a', borderRadius: 8, padding: '8px 12px', fontSize: 12, marginBottom: 12, fontWeight: 600 }}>
                    ✓ {importResult.added} تعطیلی از فایل اضافه شد.
                    {importResult.skipped > 0 && ` (${importResult.skipped} خط قابل‌خوندن نبود و رد شد.)`}
                  </div>
                )}

                <form action={addHolidayAction} style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 14 }}>
                  <input type="date" name="date" required style={holidayInputStyle} />
                  <input type="text" name="title" placeholder="عنوان (اختیاری، مثلاً عید فطر)" style={{ ...holidayInputStyle, flex: 1, minWidth: 160 }} />
                  <button type="submit" style={btnPrimaryStyle}>افزودن</button>
                </form>

                <form action={importHolidaysAction} style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center', marginBottom: 16, borderTop: '1px dashed #e5e7eb', paddingTop: 12 }}>
                  <input type="file" name="csvFile" accept=".csv,text/csv" required style={{ fontSize: 11.5 }} />
                  <button type="submit" style={btnSecondaryStyle}>وارد کردن فایل CSV</button>
                  <span style={{ fontSize: 10.5, color: '#9199a3', width: '100%' }}>
                    فرمت هر خط: <code>تاریخ,عنوان</code> — تاریخ می‌تونه شمسی («۱۴۰۵/۰۱/۰۱») یا میلادی باشه، عنوان اختیاریه.
                  </span>
                </form>

                {holidays.length === 0 ? (
                  <div style={{ fontSize: 11.5, color: '#9199a3' }}>هنوز هیچ تعطیلی ثبت نشده.</div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                    {holidays.map((h) => (
                      <div key={h.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: 12, borderBottom: '1px dashed #e5e7eb', paddingBottom: 6 }}>
                        <span>{new Date(h.date).toLocaleDateString('fa-IR')} {h.title && `— ${h.title}`}</span>
                        <form action={removeHolidayAction}>
                          <input type="hidden" name="id" value={h.id} />
                          <button type="submit" style={{ background: 'none', border: 'none', color: '#9b1c1c', fontSize: 11.5, cursor: 'pointer' }}>حذف</button>
                        </form>
                      </div>
                    ))}
                  </div>
                )}
              </details>

              <div style={{ fontSize: 11, color: '#9199a3', margin: '10px 0' }}>
                🕐 ساعات کاری هفتگی (روزهای عادی هفته، نه تعطیلات خاص) توی صفحه‌ی <a href="/admin-users" style={{ color: '#1e357b', fontWeight: 700 }}>مدیریت کاربران و دسترسی‌ها</a> تنظیم می‌شه.
              </div>

              {dealRules && (<>
                <details open style={{ border: '1px solid #e5e7eb', borderRadius: 10, padding: '10px 16px', background: '#fff' }}>
                  <summary style={{ cursor: 'pointer', fontSize: 12.5, fontWeight: 700 }}>⏳ طول مهلت‌ها — چند ساعت/روز فرصت هر مرحله باشه</summary>
                  <p style={{ fontSize: 11.5, color: '#6f7680', margin: '10px 0 14px' }}>
                    این‌جا تعیین می‌کنه <b>«چقدر»</b> فرصت هر مرحله باشه — واحدها ساعتِ کاری (طبق تقویم بالا)، به‌جز سکوت راننده که تقویمیه.
                    تغییر هرکدوم، فقط روی معاملات بعدی اثر می‌ذاره؛ معاملات در جریان با همون مهلتی که موقع شروعشون محاسبه شده ادامه پیدا می‌کنن.
                  </p>
                  <form action={updateDealRulesAction} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                    <RuleRow name="sellerFeeHours" label="مهلت پرداخت کارمزد فروشنده" unit="ساعت کاری" defaultValue={dealRules.sellerFeeHours}
                      hint="از لحظه‌ای که ادمین رزرو رو تایید می‌کنه، فروشنده چند ساعت کاری وقت داره کارمزد رو بپردازه؟ بعد از این مهلت، آگهی به‌جای بازگشت خودکار، می‌ره تو حالت «نیازمند بررسی مجدد»." />
                    <RuleRow name="buyerPaymentHours" label="مهلت پرداخت کامل خریدار" unit="ساعت کاری" defaultValue={dealRules.buyerPaymentHours}
                      hint="از لحظه‌ای که فروشنده کارمزدش رو پرداخت می‌کنه، خریدار چند ساعت کاری وقت داره باقی مبلغ رو کامل بپردازه؟" />
                    <RuleRow name="discrepancyReportHours" label="مهلت گزارش مغایرت خریدار" unit="ساعت کاری" defaultValue={dealRules.discrepancyReportHours}
                      hint="از لحظه‌ی تخلیه‌ی بار، خریدار چند ساعت کاری وقت داره اگه مشکلی توی بار دید، گزارش کنه؟ بعدش خودکار «بدون مغایرت» ثبت می‌شه." />
                    <RuleRow name="fundReleaseHours" label="مهلت آماده‌شدن واریز وجه" unit="ساعت کاری" defaultValue={dealRules.fundReleaseHours}
                      hint="از لحظه‌ی تخلیه‌ی بار، بعد از چند ساعت کاری وجه فروشنده آماده‌ی آزادسازی می‌شه؟ (به‌شرطی که مغایرت حساسی گزارش نشده باشه — آزادسازی واقعی همیشه با کلیک دستی مدیره)" />
                    <RuleRow name="driverLinkValidDays" label="مدت اعتبار لینک راننده" unit="روز تقویمی" defaultValue={dealRules.driverLinkValidDays}
                      hint="لینک پیامکی راننده (پذیرش ← بارگیری ← تخلیه) بعد از پذیرش سفر و دوباره بعد از ثبت بارگیری، از همان لحظه این‌قدر روز دیگر معتبر می‌ماند و فقط با تایید تخلیه مصرف می‌شود. اگر مسیر طولانی‌تر از این باشد، لینک وسط راه منقضی می‌شود و ادمین باید لینک تازه بسازد. تغییر فقط روی مراحل بعدی اثر می‌گذارد؛ لینک‌هایی که قبلاً تمدید شده‌اند همان انقضا را نگه می‌دارند." />
                    <RuleRow name="driverSilenceDays" label="آستانه‌ی هشدار سکوت راننده" unit="روز تقویمی" defaultValue={dealRules.driverSilenceDays}
                      hint="بعد از بارگیری، اگه راننده چند روز تقویمی (نه کاری، چون جاده تعطیلی نمی‌شناسه) هیچ رویدادی ثبت نکنه، پرچم هشدار قرمز فسفری بخوره؟" />
                    <RuleRow name="proformaConfirmHours" label="مهلت تایید پیش‌فاکتور توسط مشتری" unit="ساعت کاری" defaultValue={dealRules.proformaConfirmHours}
                      hint="از لحظه‌ای که کارشناس فروش قیمت نهایی سفارش رو ثبت می‌کنه، مشتری چند ساعت کاری وقت داره پیش‌فاکتور رو تایید کنه؟ بعد از این مهلت، سفارش خودکار باطل می‌شه و موجودی به انبار برمی‌گرده." />

                    <input type="hidden" name="updatedById" value={currentUser.id} />
                    <ConfirmSubmitButton
                      message="این تغییر روی همه‌ی معاملات بعدی اثر می‌ذاره. مطمئنی؟"
                      style={{ ...btnPrimaryStyle, alignSelf: 'flex-start', padding: '8px 22px', marginTop: 4 }}
                    >
                      ذخیره‌ی تغییرات
                    </ConfirmSubmitButton>
                  </form>
                </details>

                <details open style={{ border: '1px solid #e5e7eb', borderRadius: 10, padding: '10px 16px', background: '#fff', marginTop: 12 }}>
                  <summary style={{ cursor: 'pointer', fontSize: 12.5, fontWeight: 700 }}>🔁 اجرای خودکار مهلت‌ها — وضعیت و اجرای دستی</summary>
                  <p style={{ fontSize: 11.5, color: '#6f7680', margin: '10px 0 14px' }}>
                    قوانین مهلت باید مستقل از بازدید صفحه‌ها، خودکار روی سرور اجرا بشن (cron هر ۱۵ دقیقه، Endpointِ محافظت‌شده).
                    این‌جا فقط <b>مانیتور</b> می‌کنی که سیستم زنده‌ست و آخرین‌بار کِی خودش اجرا شده؛ فاصله‌ی زمانی قابل‌تنظیم نیست.
                  </p>

                  {/* هشدار خوابیدنِ زمان‌بند: بیش از ۴۵ دقیقه (۳ تیکِ ۱۵دقیقه‌ای) اجرا نشده */}
                  {deadlineSchedulerStale && (
                    <div style={{ border: '1px solid #f0b4b4', background: '#fdecec', color: '#8a1f1f', borderRadius: 10, padding: '10px 14px', margin: '0 0 14px', fontSize: 12, lineHeight: 1.8 }}>
                      <b>⚠️ زمان‌بند بیش از ۴۵ دقیقه اجرا نشده.</b> آخرین اجرای خودکار{' '}
                      {minutesSinceLastRun!.toLocaleString('fa-IR')} دقیقه پیش بوده — cron هر ۱۵ دقیقه باید اجرا بشه،
                      پس دست‌کم ۳ تیک از دست رفته. احتمالاً cron یا سرویس روی سرور خوابیده؛ لطفاً بررسی کن.
                    </div>
                  )}

                  {/* بخش خودکار — فقط نمایشی، بدون فیلد ورودی (هم‌شکلِ RuleRow: عنوانِ ۷۰۰ + توضیحِ کم‌رنگ) */}
                  <div style={{ borderBottom: '1px dashed #eceff3', paddingBottom: 10 }}>
                    <div style={{ fontSize: 12.5, fontWeight: 700 }}>۳ اجرای خودکار آخر</div>
                    {recentDeadlineRuns.length === 0 ? (
                      <div style={{ fontSize: 10.5, color: '#9199a3', marginTop: 4, lineHeight: 1.7 }}>
                        هنوز هیچ اجرای خودکاری ثبت نشده — اگه cron روی سرور تنظیم شده، بعد از اولین اجرا این‌جا نمایش داده می‌شه.
                      </div>
                    ) : (
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 8 }}>
                        {recentDeadlineRuns.map((run) => (
                          <div key={run.id} style={{ fontSize: 12, display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'baseline' }}>
                            <span style={{ fontWeight: 700, color: '#146c3a', whiteSpace: 'nowrap' }}>
                              {tehranJalaliDisplay(run.createdAt)} - {tehranClockDisplay(run.createdAt)}
                            </span>
                            <span style={{ color: '#6f7680' }}>— {run.message}</span>
                          </div>
                        ))}
                      </div>
                    )}
                    <div style={{ fontSize: 10.5, color: '#9199a3', marginTop: 4, lineHeight: 1.7 }}>
                      فقط اجراهای خودکار (cron) این‌جا فهرست می‌شن؛ اجرای دستیِ زیر توی این لیست نمیاد.
                    </div>
                  </div>

                  {/* بخش دستی — دکمه‌ی اجرای فوری با همون استایلِ «ذخیره‌ی تغییرات» */}
                  <form action={runDeadlineEnforcementNowAction} style={{ marginTop: 12 }}>
                    <div style={{ fontSize: 12.5, fontWeight: 700 }}>اجرای دستی (برای تست)</div>
                    <div style={{ fontSize: 10.5, color: '#9199a3', margin: '4px 0 10px', lineHeight: 1.7 }}>
                      همین الان یک‌بار همه‌ی قوانین مهلت رو اجرا می‌کنه — مستقل از چرخه‌ی خودکار. برای وقتی که می‌خوای بدون صبر تا cronِ بعدی، نتیجه رو ببینی.
                    </div>
                    <ConfirmSubmitButton
                      message="زمان‌بندِ مهلت‌ها همین الان اجرا بشه؟ ممکنه معامله‌های سررسیدشده رو باطل/تسویه کنه."
                      style={{ ...btnPrimaryStyle, alignSelf: 'flex-start', padding: '8px 22px' }}
                    >
                      اجرای همین الان
                    </ConfirmSubmitButton>
                  </form>
                </details>
              </>)}
            </div>
          )}

          {/* ---------- صف: در انتظار تایید ---------- */}
          <div style={{ ...cardStyle, marginBottom: 20 }}>
            <h3 style={{ fontSize: 14, fontWeight: 800, marginBottom: 4 }}>در انتظار تایید</h3>
            <p style={{ fontSize: 11.5, color: '#6f7680', marginBottom: 12 }}>معاملاتی که منتظر تایید مدیر هستن؛ با تایید، مهلت پرداخت خریدار شروع می‌شه.</p>
            {awaitingApprovalDeals.length === 0 ? (
              <div style={emptyStateStyle}>موردی در انتظار تایید نیست.</div>
            ) : (
              <table style={tableStyle}>
                <thead>
                  <tr style={theadRowStyle}>
                    <th style={thStyle}>شناسه</th>
                    <th style={thStyle}>خریدار</th>
                    <th style={thStyle}>مقدار</th>
                    <th style={thStyle}>سطح تایید</th>
                    <th style={thStyle}>اقدام</th>
                  </tr>
                </thead>
                <tbody>
                  {awaitingApprovalDeals.map((deal) => (
                    <tr key={deal.id}>
                      <td style={tdStyle}>#{deal.id.slice(0, 8)}</td>
                      <td style={tdStyle}>{deal.buyer.companyName}</td>
                      <td style={tdStyle}>{deal.quantity}</td>
                      <td style={tdStyle}>{deal.approvalLevel || '—'}</td>
                      <td style={tdStyle}>
                        {/* گیت UI هم‌راستا با approveDealAction (فقط مدیر)؛ برای غیرمدیر دلیل نشون داده می‌شه، نه خطای عمومیِ بعد از کلیک */}
                        {!isAdmin ? (
                          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
                            <ConfirmSubmitButton message="این معامله تایید بشه و مهلت پرداخت خریدار شروع بشه؟" style={{ ...btnPrimaryStyle, ...btnSmallStyle }} disabled title="فقط مدیر می‌تونه معامله رو تایید کنه.">
                              تایید
                            </ConfirmSubmitButton>
                            <span style={{ fontSize: 11, color: '#b45309', fontWeight: 600 }}>فقط مدیر می‌تونه معامله رو تایید کنه.</span>
                          </span>
                        ) : !((deal.agreedPrice ?? 0) > 0) ? (
                          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
                            <ConfirmSubmitButton message="این معامله تایید بشه و مهلت پرداخت خریدار شروع بشه؟" style={{ ...btnPrimaryStyle, ...btnSmallStyle }} disabled title="اول قیمت را وارد کن">
                              تایید
                            </ConfirmSubmitButton>
                            <span style={{ fontSize: 11, color: '#b45309', fontWeight: 600 }}>اول قیمت را وارد کن</span>
                          </span>
                        ) : (
                          <form action={approveDealAction.bind(null, deal.id)}>
                            <ConfirmSubmitButton message="این معامله تایید بشه و مهلت پرداخت خریدار شروع بشه؟" style={{ ...btnPrimaryStyle, ...btnSmallStyle }}>
                              تایید
                            </ConfirmSubmitButton>
                          </form>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {/* ---------- صف واحد: بررسی پرداخت‌ها (بدون ترتیب) ---------- */}
          <div style={{ ...cardStyle, marginBottom: 20 }}>
            <h3 style={{ fontSize: 14, fontWeight: 800, marginBottom: 4 }}>بررسی پرداخت‌ها</h3>
            <p style={{ fontSize: 11.5, color: '#6f7680', marginBottom: 12 }}>
              هر پرداخت مستقل بررسی می‌شه؛ ترتیب مهم نیست. با تایید هر دو پرداخت (وجه کالا و کارمزد فروشنده)، معامله خودکار به مرحله‌ی حمل می‌ره.
            </p>
            {reviewablePayments.length === 0 ? (
              <div style={emptyStateStyle}>پرداختی در انتظار بررسی نیست.</div>
            ) : (
              <table style={tableStyle}>
                <thead>
                  <tr style={theadRowStyle}>
                    <th style={thStyle}>شناسه</th>
                    <th style={thStyle}>خریدار</th>
                    <th style={thStyle}>نوع پرداخت</th>
                    <th style={thStyle}>مبلغ</th>
                    <th style={thStyle}>فیش</th>
                    <th style={thStyle}>اقدام</th>
                  </tr>
                </thead>
                <tbody>
                  {reviewablePayments.map(({ deal, payment }) => (
                    <tr key={payment.id}>
                      <td style={tdStyle}>#{deal.id.slice(0, 8)}</td>
                      <td style={tdStyle}>{deal.buyer.companyName}</td>
                      <td style={tdStyle}>{PAYMENT_KIND_LABELS[payment.kind] || payment.kind}</td>
                      <td style={tdStyle}>{payment.amount != null ? `${payment.amount.toLocaleString('fa-IR')} تومان` : '—'}</td>
                      <td style={tdStyle}>
                        {payment.receiptUrl ? (
                          <a href={payment.receiptUrl} target="_blank" rel="noreferrer" style={{ fontSize: 11.5, color: '#1e357b', fontWeight: 700 }}>مشاهده‌ی فیش ↗</a>
                        ) : '—'}
                      </td>
                      <td style={tdStyle}>
                        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'flex-start' }}>
                          {/* #25: بدون رسیدِ ثبت‌شده، و تا وقتی معامله confirmed نیست، تایید ممکن نیست (سرور هم رد می‌کند) */}
                          {payment.receiptUrl && deal.status === 'confirmed' ? (
                            <form action={approvePaymentAction}>
                              <input type="hidden" name="dealId" value={deal.id} />
                              <input type="hidden" name="kind" value={payment.kind} />
                              <ConfirmSubmitButton message={`تایید می‌کنی «${PAYMENT_KIND_LABELS[payment.kind] || payment.kind}» دریافت شده؟`} style={{ ...btnPrimaryStyle, ...btnSmallStyle }}>
                                تایید
                              </ConfirmSubmitButton>
                            </form>
                          ) : (
                            <span style={{ fontSize: 11, color: '#92400e', fontWeight: 600, alignSelf: 'center' }}>
                              {payment.receiptUrl ? 'منتظر تایید معامله' : 'منتظر ثبت رسید'}
                            </span>
                          )}
                          <form action={rejectPaymentAction} style={{ display: 'flex', gap: 6, flexWrap: 'wrap', alignItems: 'center' }}>
                            <input type="hidden" name="dealId" value={deal.id} />
                            <input type="hidden" name="kind" value={payment.kind} />
                            <input name="reason" placeholder="دلیل رد" style={{ ...inputStyle, width: 120, fontSize: 11 }} />
                            <select name="penaltyHours" defaultValue="24" style={{ ...selectStyle, width: 96, fontSize: 11 }}>
                              {PENALTY_HOURS_OPTIONS.map((h) => (
                                <option key={h} value={h}>{PENALTY_LABELS[h] || `${h} ساعت`}</option>
                              ))}
                            </select>
                            <ConfirmSubmitButton message="⚠️ رد این پرداخت معامله رو باطل می‌کنه. اگه پرداخت‌کننده «پذیرنده»ی معامله باشه، جریمه‌ی موقت هم اعمال می‌شه. مطمئنی؟" style={{ ...btnDangerStyle, ...btnSmallStyle }}>
                              رد
                            </ConfirmSubmitButton>
                          </form>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {/* ---------- صف: بازبینی درخواست‌های خرید (لغو توسط ثبت‌کننده) ---------- */}
          <div style={{ ...cardStyle, marginBottom: 20 }}>
            <h3 style={{ fontSize: 14, fontWeight: 800, marginBottom: 4 }}>بازبینی درخواست‌های خرید</h3>
            <p style={{ fontSize: 11.5, color: '#6f7680', marginBottom: 12 }}>
              درخواست‌هایی که ثبت‌کننده‌شان معامله را لغو کرده و منتظر تایید دستی برای انتشار مجدد در بازارند. با «تایید و انتشار مجدد» دوباره در بازار دیده می‌شوند؛ با «بستن» خارج از بازار می‌مانند.
            </p>
            {needsReviewRequests.length === 0 ? (
              <div style={emptyStateStyle}>درخواستی در انتظار بازبینی نیست.</div>
            ) : (
              <table style={tableStyle}>
                <thead>
                  <tr style={theadRowStyle}>
                    <th style={thStyle}>شناسه</th>
                    <th style={thStyle}>درخواست‌دهنده</th>
                    <th style={thStyle}>کد گرید</th>
                    <th style={thStyle}>مقدار (تن)</th>
                    <th style={thStyle}>اقدام</th>
                  </tr>
                </thead>
                <tbody>
                  {needsReviewRequests.map((req) => (
                    <tr key={req.id}>
                      <td style={tdStyle}>#{req.id.slice(0, 8)}</td>
                      <td style={tdStyle}>{req.user.companyName}</td>
                      <td style={{ ...tdStyle, fontFamily: 'monospace', fontWeight: 700 }}>{req.grade?.code || '—'}</td>
                      <td style={tdStyle}>{req.quantityTon.toLocaleString('fa-IR')}</td>
                      <td style={tdStyle}>
                        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'flex-start' }}>
                          <form action={reviewPurchaseRequestAction}>
                            <input type="hidden" name="requestId" value={req.id} />
                            <input type="hidden" name="decision" value="approve" />
                            <ConfirmSubmitButton message="این درخواست دوباره در بازار منتشر بشه؟" style={{ ...btnPrimaryStyle, ...btnSmallStyle }}>
                              تایید و انتشار مجدد
                            </ConfirmSubmitButton>
                          </form>
                          <form action={reviewPurchaseRequestAction}>
                            <input type="hidden" name="requestId" value={req.id} />
                            <input type="hidden" name="decision" value="reject" />
                            <ConfirmSubmitButton message="این درخواست بسته بشه و از بازار خارج بمونه؟" style={{ ...btnDangerStyle, ...btnSmallStyle }}>
                              بستن
                            </ConfirmSubmitButton>
                          </form>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {deals.length === 0 && (
            <div style={emptyStateStyle}>هنوز هیچ معامله‌ای ثبت نشده.</div>
          )}

          {deals.map((deal) => {
            const now = Date.now()
            const fundReleaseDue = !!deal.fundReleaseDeadline && new Date(deal.fundReleaseDeadline).getTime() < now && !deal.fundReleaseFrozen && deal.escrowStatus !== 'released_manual'
            const isFlagged = fundReleaseDue || !!deal.driverSilenceFlaggedAt || deal.fundReleaseFrozen
            // آینه‌ی گاردِ سمت سرور در confirmFundsReleased (actions.ts) — تنها منبع حقیقت سرور است؛ اینجا فقط برای
            // نشان‌دادن «چرا دکمه غیرفعال است». اگر شرطی در گارد عوض شد، اینجا هم عوض شود.
            const releaseBlockers: string[] = []
            if (deal.status !== 'delivered') releaseBlockers.push(`معامله «تحویل‌شده» نیست (وضعیت فعلی: ${STATUS_LABELS[deal.status] || deal.status})`)
            if (!deal.qualityAutoAccepted) {
              releaseBlockers.push(
                deal.discrepancyReportDeadline
                  ? `پنجره‌ی مغایرت هنوز بسته نشده (مهلت گزارش خریدار تا ${new Date(deal.discrepancyReportDeadline).toLocaleString('fa-IR')})`
                  : 'پنجره‌ی مغایرت هنوز شروع/بسته نشده (تحویل ثبت نشده)',
              )
            }
            if (deal.fundReleaseFrozen) releaseBlockers.push('آزادسازی فریز است (مغایرت حساس ثبت شده)')
            if (deal.disputes.length > 0) releaseBlockers.push('اختلاف بازی روی این معامله هست (بخش اختلافات)')
            // ——— 12-field honesty resolution ———
            const grade = (deal as any).materialListing?.grade ?? (deal as any).purchaseRequest?.grade ?? null
            const buyerCompany: any = (deal as any).buyer?.company ?? null
            const sellerUser: any = (deal as any).seller ?? (deal as any).materialListing?.user ?? null
            const sellerCompany: any = sellerUser?.company ?? null
            const sellerUserId: string | null = (deal as any).sellerId ?? (deal as any).materialListing?.userId ?? null
            const buyerKyc: any = buyerCompany?.kyc ?? null
            const sellerKyc: any = sellerCompany?.kyc ?? null
            const kycBadgeOk = (k: any) => k && k.badge !== 'none' && (k.level ?? 0) >= 1
            const buyerPayment = deal.payments.find((p: any) => p.kind === 'BUYER_GOODS') ?? null
            const sellerPayment = deal.payments.find((p: any) => p.kind === 'SELLER_FEE') ?? null
            const loadingConf: any = (deal.confirmations as any[]).find((c: any) => c.type === 'loading') ?? null
            const unloadingConf: any = (deal.confirmations as any[]).find((c: any) => c.type === 'unloading') ?? null
            // ——— supplement: second badge ———
            const hasRoleIds = !!(deal as any).tradeDirection && !!(deal as any).requesterId && !!(deal as any).acceptorId
            const buyerSecondLabel: string | null = !hasRoleIds ? null : (deal as any).requesterId === (deal as any).buyerId ? 'درخواست‌دهنده' : (deal as any).acceptorId === (deal as any).buyerId ? 'قبول‌کننده' : null
            const sellerSecondLabel: string | null = !hasRoleIds || !sellerUserId ? null : (deal as any).requesterId === sellerUserId ? 'درخواست‌دهنده' : (deal as any).acceptorId === sellerUserId ? 'قبول‌کننده' : null
            const dealStatusPhase = (() => {
              const s = deal.status
              if (['void','cancelled'].includes(s)) return 0
              if (['draft','awaiting_approval','confirmed'].includes(s)) return 1
              if (['seller_fee_paid','payment_secured','transport_pending','loading','in_transit'].includes(s)) return 2
              if (s === 'delivered') return 3
              if (s === 'settled' || (deal as any).escrowStatus === 'released_manual') return 4
              return 1
            })()
            const payPhase = (p: any) => {
              if (!p) return 0
              if (p.status === 'APPROVED') return 3
              if (p.status === 'SUBMITTED' || p.receiptUrl) return 2
              return 1
            }
            return (
            <details key={deal.id} style={isFlagged ? { ...cardStyle, border: '15px solid #ff2d55' } : cardStyle}>
              <summary style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8, cursor: 'pointer', listStyle: 'none' as any }}>
                <div>
                  <b style={{ fontSize: 14 }}>#{deal.id.slice(0, 8)}</b>{' '}
                  <span style={{ fontSize: 12.5, color: '#6f7680' }}>— {deal.buyer.companyName} — {deal.quantity}</span>
                </div>
                <span style={badgeStyle('info')}>{STATUS_LABELS[deal.status] || deal.status}</span>
              </summary>

              {/* ——— هدر غنی داخل آکوردئون (تصویر + نام محصول + کد + قیمت + تایم‌لاین ۴ مرحله) ——— */}
              <div style={{ display: 'flex', gap: 14, alignItems: 'center', flexWrap: 'wrap', margin: '14px 0 10px', padding: '10px 12px', background: '#fafbfc', borderRadius: 10, border: '1px solid #e5e7eb' }}>
                {grade?.imageUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={grade.imageUrl} alt={grade.code} style={{ width: 56, height: 56, borderRadius: 8, objectFit: 'cover', border: '1px solid #e5e7eb', flexShrink: 0 }} />
                ) : (
                  <div style={{ width: 56, height: 56, borderRadius: 8, background: '#f1f2f5', border: '1px dashed #d8dde3', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9, color: '#9199a3', textAlign: 'center', flexShrink: 0 }}>تصویر<br/>ثبت نشده</div>
                )}
                <div style={{ flex: 1, minWidth: 160 }}>
                  <div style={{ fontSize: 13, fontWeight: 800 }}>{grade ? grade.code : '—'}</div>
                  <div style={{ fontSize: 11.5, color: '#6f7680' }}>{grade ? `${grade.producer}${grade.category ? ` · ${grade.category}` : ''}` : 'نامشخص'}</div>
                  <div style={{ fontSize: 11, color: '#4f5560', marginTop: 2 }}>قیمت توافقی: {deal.agreedPrice != null ? `${deal.agreedPrice.toLocaleString('fa-IR')} تومان/کیلو` : '—'} &nbsp;|&nbsp; <span style={escrowColor(deal.escrowStatus)}>{escrowLabel(deal.escrowStatus)}</span> <RefundPolicyHint /></div>
                </div>
                {/* خط‌زمانی ۴ مرحله */}
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
                  {[
                    { n: 1, label: 'ثبت' },
                    { n: 2, label: 'در حال انجام' },
                    { n: 3, label: 'تسویه' },
                    { n: 4, label: 'تکمیل' },
                  ].map((step, idx) => {
                    const active = dealStatusPhase >= step.n
                    const isVoid = dealStatusPhase === 0
                    return (
                      <span key={step.n} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <span style={{ width: 22, height: 22, borderRadius: 999, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 800, background: isVoid ? '#f1f2f5' : active ? '#1e357b' : '#e5e7eb', color: isVoid ? '#9199a3' : active ? '#fff' : '#9199a3' }}>{step.n}</span>
                        <span style={{ fontSize: 10, color: isVoid ? '#9199a3' : active ? '#1e357b' : '#9199a3', fontWeight: active && !isVoid ? 700 : 400 }}>{step.label}</span>
                        {idx < 3 && <span style={{ width: 14, height: 2, background: isVoid ? '#e5e7eb' : dealStatusPhase > step.n ? '#1e357b' : '#e5e7eb', borderRadius: 1 }} />}
                      </span>
                    )
                  })}
                  {dealStatusPhase === 0 && <span style={{ fontSize: 10, color: '#9b1c1c', fontWeight: 700, marginRight: 6 }}>باطل شد</span>}
                </div>
              </div>

              {deal.driverSilenceFlaggedAt && (
                <div style={{ background: '#fde8e8', color: '#9b1c1c', borderRadius: 8, padding: '8px 12px', fontSize: 12, fontWeight: 700, marginBottom: 10 }}>
                  🔴 راننده از لحظه‌ی بارگیری تا ۵ روز هیچ رویدادی ثبت نکرده — نیازمند پیگیری فوری کارشناس حمل‌ونقل.
                </div>
              )}
              {deal.fundReleaseFrozen && (
                <div style={{ background: '#fde8e8', color: '#9b1c1c', borderRadius: 8, padding: '8px 12px', fontSize: 12, fontWeight: 700, marginBottom: 10 }}>
                  🔴 مغایرت حساس گزارش شده — واریز وجه متوقف شد، منتظر تصمیم مدیر (بخش اختلافات).
                </div>
              )}
              {deal.manualReversalRequired && (
                <div style={{ background: '#fde8e8', color: '#9b1c1c', borderRadius: 8, padding: '8px 12px', fontSize: 12, fontWeight: 700, marginBottom: 10, display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
                  <span style={{ flex: 1, minWidth: 220, lineHeight: 1.9 }}>
                    🔴 پرداخت ردشد/معامله باطل شد، ولی وجه خریدار نزد ماست (تضمین‌شده) و خودکار برنگشته
                    {deal.manualReversalAt ? ` (از ${new Date(deal.manualReversalAt).toLocaleString('fa-IR')})` : ''} — وجه را دستی به خریدار برگردانید و بعد «بازگشت انجام شد» را بزنید.
                  </span>
                  {canEditDeals && (
                    <form action={markManualReversalDone}>
                      <input type="hidden" name="dealId" value={deal.id} />
                      <ConfirmSubmitButton message="⚠️ این یعنی وجه خریدار واقعاً (بیرون از سایت) به او برگردانده شده و پرچم هشدار پاک می‌شود. مطمئنی؟" style={btnDangerStyle}>بازگشت انجام شد</ConfirmSubmitButton>
                    </form>
                  )}
                </div>
              )}
              {fundReleaseDue && releaseBlockers.length === 0 && (
                <div style={{ background: '#eaf3de', color: '#27500a', borderRadius: 8, padding: '8px 12px', fontSize: 12, fontWeight: 700, marginBottom: 10 }}>
                  ✓ مهلت ۸ساعته‌ی واریز به پایان رسیده و مغایرت حساسی گزارش نشده — آماده‌ی آزادسازی وجه فروشنده.
                </div>
              )}

              {/* ——— دو ستون: آبی خریدار / نارنجی فروشنده ——— */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 300px), 1fr))', gap: 16 }}>
                {/* ستون آبی — خریدار */}
                <DealPartyCard
                  role="buyer"
                  secondaryLabel={buyerSecondLabel}
                  companyName={deal.buyer.companyName}
                  economicCode={buyerCompany?.economicCode || null}
                  address={[buyerCompany?.province, buyerCompany?.city, buyerCompany?.address].filter(Boolean).join('، ') || null}
                  verified={!!kycBadgeOk(buyerKyc)}
                >
                  {/* تایم‌لاین پرداخت خریدار */}
                  <div style={{ background: '#fff', borderRadius: 8, padding: '8px 10px', border: '1px solid var(--party-line)' }}>
                    <div style={{ fontSize: 11, fontWeight: 700, marginBottom: 6 }}>وضعیت پرداخت خریدار</div>
                    <PayTimeline phase={payPhase(buyerPayment)} labels={['در انتظار', 'ثبت شد', 'تایید شد', 'تسویه']} escrowReleased={(deal as any).escrowStatus === 'released_manual'} />
                    {!buyerPayment && <div style={{ fontSize: 11, color: '#9199a3' }}>—</div>}
                    {buyerPayment && <div style={{ fontSize: 11, color: '#6f7680', marginTop: 4 }}>{PAYMENT_KIND_LABELS[buyerPayment.kind] || buyerPayment.kind} · {buyerPayment.status}{buyerPayment.receiptUrl ? ' · فیش دارد' : ''}</div>}
                  </div>
                  {/* اطلاعات پرداخت — متن آزاد (❌ جدا نیست) */}
                  <div style={{ background: '#fff', borderRadius: 8, padding: '8px 10px', border: '1px solid var(--party-line)' }}>
                    <div style={{ fontSize: 11, fontWeight: 700, marginBottom: 4 }}>اطلاعات پرداخت {deal.paymentInstructionsText ? <span style={payInstrSetTag}>ثبت شده</span> : <span style={payInstrEmptyTag}>خالی</span>}</div>
                    {deal.paymentInstructionsText ? (
                      <div style={{ fontSize: 11.5, whiteSpace: 'pre-wrap' as const, wordBreak: 'break-word' as const, background: '#fafbfc', borderRadius: 6, padding: '6px 8px', border: '1px solid #e5e7eb' }}>{deal.paymentInstructionsText}</div>
                    ) : (
                      <div style={{ fontSize: 11, color: '#9199a3' }}>خالی — کارشناس هنوز دستوری ثبت نکرده</div>
                    )}
                  </div>
                  {/* فرم دستور پرداخت — جابجا شده به ستون آبی */}
                  <details style={{ ...payInstrBox, marginBottom: 0, background: '#fff' }}>
                    <summary style={{ cursor: 'pointer', fontSize: 11.5, fontWeight: 700 }}>✏️ ویرایش دستور پرداخت</summary>
                    <p style={{ fontSize: 10.5, color: '#6f7680', margin: '8px 0', lineHeight: 1.8 }}>این متن عیناً توی صفحه‌ی معامله‌ی خریدار نشون داده می‌شه.</p>
                    <form action={updateDealPaymentInstructionsAction}>
                      <input type="hidden" name="dealId" value={deal.id} />
                      <textarea name="paymentInstructionsText" rows={3} defaultValue={deal.paymentInstructionsText || ''} placeholder="شماره‌حساب / شبا / یا «تماس بگیرید»" style={payInstrTextarea} />
                      <ConfirmSubmitButton message="این متن برای خریدارِ همین معامله نمایش داده می‌شه. ذخیره بشه؟" style={{ ...btnPrimaryStyle, marginTop: 8, padding: '6px 14px', fontSize: 11.5 }}>ذخیره‌ی دستور پرداخت</ConfirmSubmitButton>
                    </form>
                  </details>
                  {/* اطلاعات تخلیه */}
                  <div style={{ background: '#fff', borderRadius: 8, padding: '8px 10px', border: '1px solid var(--party-line)' }}>
                    <div style={{ fontSize: 11, fontWeight: 700, marginBottom: 4 }}>اطلاعات تخلیه بار</div>
                    <FieldRow label="مسئول تخلیه" value={unloadingConf?.receiverName ? `${unloadingConf.receiverName}${unloadingConf.receiverRole ? ` (${unloadingConf.receiverRole})` : ''}` : deal.buyer.companyName} small />
                    <FieldRow label="آدرس تخلیه" value={[buyerCompany?.province, buyerCompany?.city, buyerCompany?.address].filter(Boolean).join('، ') || (deal as any).purchaseRequest?.province || null} fallback="ثبت نشده" small />
                    <FieldRow label="تماس تخلیه" value={(deal as any).buyer?.phone || buyerCompany?.companyPhone || null} fallback="—" small />
                  </div>
                  {/* اقدام بعدی خریدار */}
                  <div style={{ marginTop: 'auto', paddingTop: 8, borderTop: '1px dashed var(--party-line)' }}>
                    <div style={{ fontSize: 11, fontWeight: 700, marginBottom: 6 }}>اقدام بعدی — خریدار</div>
                    {buyerPayment && (buyerPayment.status === 'PENDING' || buyerPayment.status === 'SUBMITTED') ? (
                      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                        {buyerPayment.receiptUrl && deal.status === 'confirmed' ? (
                          <form action={approvePaymentAction}>
                            <input type="hidden" name="dealId" value={deal.id} />
                            <input type="hidden" name="kind" value="BUYER_GOODS" />
                            <ConfirmSubmitButton message={`تایید می‌کنی «${PAYMENT_KIND_LABELS['BUYER_GOODS']}» دریافت شده؟`} style={{ ...btnPrimaryStyle, ...btnSmallStyle }}>تایید پرداخت خریدار</ConfirmSubmitButton>
                          </form>
                        ) : (
                          <span style={{ fontSize: 11, color: '#92400e', fontWeight: 600, alignSelf: 'center' }}>
                            {buyerPayment.receiptUrl ? 'منتظر تایید معامله' : 'منتظر ثبت رسید'}
                          </span>
                        )}
                        <form action={rejectPaymentAction} style={{ display: 'flex', gap: 4, flexWrap: 'wrap', alignItems: 'center' }}>
                          <input type="hidden" name="dealId" value={deal.id} />
                          <input type="hidden" name="kind" value="BUYER_GOODS" />
                          <input name="reason" placeholder="دلیل رد" style={{ ...inputStyle, width: 90, fontSize: 11, padding: '5px 8px' }} />
                          <select name="penaltyHours" defaultValue="24" style={{ ...selectStyle, width: 80, fontSize: 11, padding: '5px 6px' }}>
                            {PENALTY_HOURS_OPTIONS.map((h: number) => (<option key={h} value={h}>{(PENALTY_LABELS as any)[h] || `${h} ساعت`}</option>))}
                          </select>
                          <ConfirmSubmitButton message="⚠️ رد این پرداخت معامله رو باطل می‌کنه. مطمئنی؟" style={{ ...btnDangerStyle, ...btnSmallStyle }}>رد</ConfirmSubmitButton>
                        </form>
                      </div>
                    ) : deal.status === 'awaiting_approval' ? (
                      !((deal.agreedPrice ?? 0) > 0) ? (
                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
                          <ConfirmSubmitButton message="این معامله تایید بشه و مهلت پرداخت خریدار شروع بشه؟" style={{ ...btnPrimaryStyle, ...btnSmallStyle }} disabled title="اول قیمت را وارد کن">تایید معامله</ConfirmSubmitButton>
                          <span style={{ fontSize: 11, color: '#b45309', fontWeight: 600 }}>اول قیمت را وارد کن</span>
                        </span>
                      ) : (
                        <form action={approveDealAction.bind(null, deal.id)}>
                          <ConfirmSubmitButton message="این معامله تایید بشه و مهلت پرداخت خریدار شروع بشه؟" style={{ ...btnPrimaryStyle, ...btnSmallStyle }}>تایید معامله</ConfirmSubmitButton>
                        </form>
                      )
                    ) : (
                      <span style={{ fontSize: 11, color: '#9199a3' }}>اقدامی باقی نمانده</span>
                    )}
                  </div>
                </DealPartyCard>

                {/* ستون نارنجی — فروشنده (بلندتر) */}
                <DealPartyCard
                  role="seller"
                  secondaryLabel={sellerSecondLabel}
                  companyName={sellerUser?.companyName || sellerCompany?.companyName || '—'}
                  economicCode={sellerCompany?.economicCode || null}
                  address={sellerKyc?.factoryAddress || [sellerCompany?.province, sellerCompany?.city, sellerCompany?.address].filter(Boolean).join('، ') || [(deal as any).materialListing?.province, (deal as any).materialListing?.city].filter(Boolean).join('، ') || null}
                  verified={!!kycBadgeOk(sellerKyc)}
                >
                  <div style={{ background: '#fff', borderRadius: 8, padding: '8px 10px', border: '1px solid var(--party-line)' }}>
                    <div style={{ fontSize: 11, fontWeight: 700, marginBottom: 6 }}>وضعیت پرداخت فروشنده</div>
                    <PayTimeline phase={payPhase(sellerPayment)} labels={['در انتظار', 'ثبت شد', 'تایید شد', 'تسویه']} escrowReleased={(deal as any).escrowStatus === 'released_manual'} />
                    {!sellerPayment && <div style={{ fontSize: 11, color: '#9199a3' }}>—</div>}
                    {sellerPayment && <div style={{ fontSize: 11, color: '#6f7680', marginTop: 4 }}>{PAYMENT_KIND_LABELS[sellerPayment.kind] || sellerPayment.kind} · {sellerPayment.status}{sellerPayment.receiptUrl ? ' · فیش دارد' : ''}</div>}
                  </div>
                  <div style={{ background: '#fff', borderRadius: 8, padding: '8px 10px', border: '1px solid var(--party-line)' }}>
                    <div style={{ fontSize: 11, fontWeight: 700, marginBottom: 4 }}>اطلاعات پرداخت {deal.sellerPaymentInstructionsText ? <span style={payInstrSetTag}>ثبت شده</span> : <span style={payInstrEmptyTag}>خالی</span>}</div>
                    {deal.sellerPaymentInstructionsText ? (
                      <div style={{ fontSize: 11.5, whiteSpace: 'pre-wrap' as const, wordBreak: 'break-word' as const, background: '#fafbfc', borderRadius: 6, padding: '6px 8px', border: '1px solid #e5e7eb' }}>{deal.sellerPaymentInstructionsText}</div>
                    ) : (
                      <div style={{ fontSize: 11, color: '#9199a3' }}>خالی — کارشناس هنوز دستوری ثبت نکرده</div>
                    )}
                  </div>
                  {/* فرم دستور پرداخت فروشنده — فیلدِ مستقل از خریدار */}
                  <details style={{ ...payInstrBox, marginBottom: 0, background: '#fff' }}>
                    <summary style={{ cursor: 'pointer', fontSize: 11.5, fontWeight: 700 }}>✏️ ویرایش دستور پرداخت</summary>
                    <p style={{ fontSize: 10.5, color: '#6f7680', margin: '8px 0', lineHeight: 1.8 }}>این متن عیناً توی صفحه‌ی معامله‌ی فروشنده نشون داده می‌شه.</p>
                    <form action={updateSellerPaymentInstructionsAction}>
                      <input type="hidden" name="dealId" value={deal.id} />
                      <textarea name="sellerPaymentInstructionsText" rows={3} defaultValue={deal.sellerPaymentInstructionsText || ''} placeholder="شماره‌حساب / شبا / یا «تماس بگیرید»" style={payInstrTextarea} />
                      <ConfirmSubmitButton message="این متن برای فروشنده‌ی همین معامله نمایش داده می‌شه. ذخیره بشه؟" style={{ ...btnPrimaryStyle, marginTop: 8, padding: '6px 14px', fontSize: 11.5 }}>ذخیره‌ی دستور پرداخت</ConfirmSubmitButton>
                    </form>
                  </details>
                  {/* اطلاعات بارگیری */}
                  <div style={{ background: '#fff', borderRadius: 8, padding: '8px 10px', border: '1px solid var(--party-line)' }}>
                    <div style={{ fontSize: 11, fontWeight: 700, marginBottom: 4 }}>اطلاعات بارگیری</div>
                    <FieldRow label="مسئول بارگیری" value={loadingConf?.driverName || sellerUser?.companyName || sellerCompany?.companyName || null} fallback="—" small />
                    <FieldRow label="آدرس بارگیری" value={sellerKyc?.factoryAddress || [sellerCompany?.province, sellerCompany?.city, sellerCompany?.address].filter(Boolean).join('، ') || [(deal as any).materialListing?.province, (deal as any).materialListing?.city].filter(Boolean).join('، ') || null} fallback="ثبت نشده" small />
                    <FieldRow label="تماس بارگیری" value={loadingConf?.driverPhone || sellerUser?.phone || sellerCompany?.companyPhone || null} fallback="—" small />
                    {loadingConf?.vehiclePlate && <FieldRow label="پلاک" value={loadingConf.vehiclePlate} small />}
                  </div>
                  {/* اقدام بعدی فروشنده */}
                  <div style={{ marginTop: 'auto', paddingTop: 8, borderTop: '1px dashed var(--party-line)' }}>
                    <div style={{ fontSize: 11, fontWeight: 700, marginBottom: 6 }}>اقدام بعدی — فروشنده</div>
                    {sellerPayment && (sellerPayment.status === 'PENDING' || sellerPayment.status === 'SUBMITTED') ? (
                      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                        {sellerPayment.receiptUrl && deal.status === 'confirmed' ? (
                          <form action={approvePaymentAction}>
                            <input type="hidden" name="dealId" value={deal.id} />
                            <input type="hidden" name="kind" value="SELLER_FEE" />
                            <ConfirmSubmitButton message={`تایید می‌کنی «${PAYMENT_KIND_LABELS['SELLER_FEE']}» دریافت شده؟`} style={{ ...btnPrimaryStyle, ...btnSmallStyle }}>تایید کارمزد فروشنده</ConfirmSubmitButton>
                          </form>
                        ) : (
                          <span style={{ fontSize: 11, color: '#92400e', fontWeight: 600, alignSelf: 'center' }}>
                            {sellerPayment.receiptUrl ? 'منتظر تایید معامله' : 'منتظر ثبت رسید'}
                          </span>
                        )}
                        <form action={rejectPaymentAction} style={{ display: 'flex', gap: 4, flexWrap: 'wrap', alignItems: 'center' }}>
                          <input type="hidden" name="dealId" value={deal.id} />
                          <input type="hidden" name="kind" value="SELLER_FEE" />
                          <input name="reason" placeholder="دلیل رد" style={{ ...inputStyle, width: 90, fontSize: 11, padding: '5px 8px' }} />
                          <select name="penaltyHours" defaultValue="24" style={{ ...selectStyle, width: 80, fontSize: 11, padding: '5px 6px' }}>
                            {PENALTY_HOURS_OPTIONS.map((h: number) => (<option key={h} value={h}>{(PENALTY_LABELS as any)[h] || `${h} ساعت`}</option>))}
                          </select>
                          <ConfirmSubmitButton message="⚠️ رد این پرداخت معامله رو باطل می‌کنه. مطمئنی؟" style={{ ...btnDangerStyle, ...btnSmallStyle }}>رد</ConfirmSubmitButton>
                        </form>
                      </div>
                    ) : (
                      <span style={{ fontSize: 11, color: '#9199a3' }}>اقدامی باقی نمانده</span>
                    )}
                  </div>
                </DealPartyCard>
              </div>

              {/* ——— حسابداری معامله: جمع کل خریدار + فرم‌های ثبت (فرم‌ها فقط با دسترسی ویرایش) ——— */}
              <DealAccountingBlock deal={deal} canEdit={canEditDeals} />

              {/* ——— فوتر مشترک: تایم‌لاین confirmations + مهلت‌ها ——— */}
              {deal.confirmations.length > 0 && (
                <div style={{ marginTop: 14 }}>
                  {deal.confirmations.map((c: any) => {
                    let checklist: Record<string, boolean> = {}
                    try { checklist = JSON.parse(c.checklistJson) } catch {}
                    return (
                      <div key={c.id} style={timelineRow}>
                        <div style={{ fontWeight: 700, fontSize: 12.5, marginBottom: 4 }}>{(CONFIRMATION_TYPE_LABELS as any)[c.type] || c.type}</div>
                        {c.finalVerdict && (VERDICT_LABELS as any)[c.finalVerdict] && (
                          <div style={{ ...metaLine, color: (VERDICT_LABELS as any)[c.finalVerdict].color, fontWeight: 700 }}>{(VERDICT_LABELS as any)[c.finalVerdict].label}</div>
                        )}
                        {c.driverName && <div style={metaLine}>راننده: {c.driverName} — {c.driverPhone} — پلاک {c.vehiclePlate}</div>}
                        {c.receiverName && <div style={metaLine}>تحویل‌گیرنده: {c.receiverName} ({c.receiverRole})</div>}
                        <div style={metaLine}>{Object.entries(checklist).filter(([, v]) => v).map(([k]) => (CHECKLIST_LABELS as any)[k] || k).join(' · ') || 'بدون آیتم تیک‌خورده'}</div>
                        {c.latitude && c.longitude && <div style={metaLine}>موقعیت ثبت‌شده: {c.latitude.toFixed(5)}, {c.longitude.toFixed(5)} (سیگنال کمکی، نه مدرک قطعی)</div>}
                        {c.photoUrl && <a href={c.photoUrl} target="_blank" rel="noreferrer" style={{ fontSize: 11.5, color: '#1e357b' }}>مشاهده‌ی عکس ↗</a>}
                        <div style={{ fontSize: 10.5, color: '#9199a3', marginTop: 4 }}>{new Date(c.confirmedAt).toLocaleString('fa-IR')}</div>
                      </div>
                    )
                  })}
                </div>
              )}

              {(deal.buyerConfirmDeadline || deal.discrepancyReportDeadline || deal.fundReleaseDeadline) && (
                <div style={{ marginTop: 12, background: '#fafbfc', borderRadius: 8, padding: '10px 14px' }}>
                  {deal.buyerConfirmDeadline && <div style={{ fontSize: 12, marginBottom: 4 }}>مهلت پرداخت کامل خریدار: <b>{new Date(deal.buyerConfirmDeadline).toLocaleString('fa-IR')}</b></div>}
                  {deal.discrepancyReportDeadline && <div style={{ fontSize: 12, marginBottom: 4 }}>مهلت گزارش مغایرت: <b>{new Date(deal.discrepancyReportDeadline).toLocaleString('fa-IR')}</b></div>}
                  {deal.fundReleaseDeadline && <div style={{ fontSize: 12 }}>مهلت واریز وجه: <b>{new Date(deal.fundReleaseDeadline).toLocaleString('fa-IR')}</b></div>}
                  {(adjustmentsByDeal.get(deal.id) || []).length > 0 && (
                    <div style={{ marginTop: 8, borderTop: '1px dashed #e5e7eb', paddingTop: 8 }}>
                      {(adjustmentsByDeal.get(deal.id) || []).map((a) => (
                        <div key={a.id} style={{ fontSize: 11, color: '#6f7680', marginBottom: 3 }}>
                          🔧 {(DEADLINE_FIELD_LABELS as any)[a.field] || a.field} {a.hoursDelta > 0 ? `${a.hoursDelta} ساعت تمدید شد` : `${Math.abs(a.hoursDelta)} ساعت کوتاه شد`} توسط {a.adjustedBy.companyName} — «{a.reason}» — {new Date(a.createdAt).toLocaleString('fa-IR')}
                        </div>
                      ))}
                    </div>
                  )}
                  {isAdmin && (
                    <form action={adjustDeadlineAction} style={{ display: 'flex', gap: 6, flexWrap: 'wrap', alignItems: 'center', marginTop: 10, borderTop: '1px dashed #e5e7eb', paddingTop: 10 }}>
                      <input type="hidden" name="dealId" value={deal.id} />
                      <select name="field" style={holidayInputStyle} required>
                        {deal.buyerConfirmDeadline && <option value="buyerConfirmDeadline">مهلت پرداخت خریدار</option>}
                        {deal.discrepancyReportDeadline && <option value="discrepancyReportDeadline">مهلت گزارش مغایرت</option>}
                        {deal.fundReleaseDeadline && <option value="fundReleaseDeadline">مهلت واریز وجه</option>}
                      </select>
                      <input type="number" name="hours" placeholder="مثلاً 12 یا -6" required style={{ ...holidayInputStyle, width: 90 }} />
                      <input type="text" name="reason" placeholder="دلیل (اجباری)" required style={{ ...holidayInputStyle, flex: 1, minWidth: 140 }} />
                      <ConfirmSubmitButton message="⚠️ این مهلت رو دستی تغییر می‌ده و توی تاریخچه ثبت می‌شه. مطمئنی؟" style={btnSecondaryStyle}>اعمال تغییر</ConfirmSubmitButton>
                    </form>
                  )}
                </div>
              )}

              {/* ——— آزادسازی وجه (فوتر) ——— */}
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', borderTop: '1px dashed #e5e7eb', paddingTop: 12, marginTop: 12 }}>
                {deal.escrowStatus === 'secured_manual' && (!canEditDeals ? (
                  <span style={{ fontSize: 11.5, color: '#9199a3' }}>فقط مشاهده</span>
                ) : releaseBlockers.length > 0 ? (
                  <div style={{ background: '#fef3c7', color: '#92400e', borderRadius: 8, padding: '8px 12px', fontSize: 11.5, fontWeight: 600, lineHeight: 1.9 }}>
                    <div style={{ fontWeight: 800 }}>⛔ آزادسازی وجه هنوز ممکن نیست:</div>
                    {releaseBlockers.map((reason) => (
                      <div key={reason}>• {reason}</div>
                    ))}
                  </div>
                ) : (
                  <form action={confirmFundsReleased}>
                    <input type="hidden" name="dealId" value={deal.id} />
                    <ConfirmSubmitButton message="⚠️ این یعنی حسابداری تایید می‌کنه وجه واقعاً به فروشنده پرداخت شده (بیرون از سایت). مطمئنی؟" style={btnDangerStyle}>تایید پرداخت به فروشنده</ConfirmSubmitButton>
                  </form>
                ))}
                {deal.escrowStatus === 'released_manual' && <span style={{ fontSize: 12, color: '#146c3a', fontWeight: 600 }}>✓ این معامله کامل تسویه شده</span>}
              </div>
            </details>
            )
          })}
        </div>
      </div>
    </div>
  )
}

function PayTimeline({ phase, labels, escrowReleased }: { phase: number; labels: string[]; escrowReleased: boolean }) {
  const maxPhase = escrowReleased ? 4 : 3
  const effectivePhase = escrowReleased ? 4 : phase
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 4, flexWrap: 'wrap' }}>
      {labels.map((label, idx) => {
        const step = idx + 1
        const done = effectivePhase >= step
        const isLast = idx === labels.length - 1
        const lastDone = escrowReleased || done
        const showDone = isLast ? lastDone : done
        return (
          <span key={label} style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <span style={{ width: 18, height: 18, borderRadius: 999, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: 9, fontWeight: 800, background: showDone ? '#1e357b' : '#e5e7eb', color: showDone ? '#fff' : '#9199a3' }}>{step}</span>
            <span style={{ fontSize: 9.5, color: showDone ? '#1e357b' : '#9199a3', fontWeight: showDone ? 700 : 400 }}>{label}</span>
            {idx < labels.length - 1 && <span style={{ width: 10, height: 2, background: effectivePhase > step ? '#1e357b' : '#e5e7eb', borderRadius: 1 }} />}
          </span>
        )
      })}
      {phase === 0 && <span style={{ fontSize: 9.5, color: '#9199a3' }}> — بدون پرداخت</span>}
    </div>
  )
}

function RuleRow({ name, label, unit, defaultValue, hint }: { name: string; label: string; unit: string; defaultValue: number; hint: string }) {
  return (
    <div style={{ borderBottom: '1px dashed #eceff3', paddingBottom: 10 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 12.5 }}>
        <span style={{ width: 210, fontWeight: 700 }}>{label}</span>
        <input type="number" name={name} min={1} max={999} defaultValue={defaultValue} style={{ ...holidayInputStyle, width: 70, padding: '5px 8px' }} />
        <span style={{ color: '#9199a3' }}>{unit}</span>
      </div>
      <div style={{ fontSize: 10.5, color: '#9199a3', marginTop: 4, lineHeight: 1.7 }}>{hint}</div>
    </div>
  )
}

function escrowLabel(status: string) {
  return status === 'pending' ? 'در انتظار' : status === 'secured_manual' ? 'نزد ما (تضمین‌شده)' : status === 'released_manual' ? 'به فروشنده پرداخت شد' : status
}
function escrowColor(status: string): React.CSSProperties {
  return { color: status === 'pending' ? '#92400e' : status === 'secured_manual' ? '#1e357b' : '#146c3a' }
}

const holidayInputStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 8, padding: '8px 10px', fontSize: 12, fontFamily: 'inherit' }
const timelineRow: React.CSSProperties = { borderRight: '2px solid #e5e7eb', paddingRight: 12, marginBottom: 10 }
const metaLine: React.CSSProperties = { fontSize: 11.5, color: '#6f7680', marginTop: 2 }
const payInstrBox: React.CSSProperties = { border: '1px solid #e5e7eb', borderRadius: 10, padding: '10px 14px', marginBottom: 14, background: '#fcfcfd' }
const payInstrSetTag: React.CSSProperties = { fontSize: 9.5, fontWeight: 700, background: '#eaf3de', color: '#146c3a', borderRadius: 20, padding: '2px 8px', marginRight: 8 }
const payInstrEmptyTag: React.CSSProperties = { fontSize: 9.5, fontWeight: 700, background: '#fef3c7', color: '#92400e', borderRadius: 20, padding: '2px 8px', marginRight: 8 }
const payInstrTextarea: React.CSSProperties = { width: '100%', border: '1px solid #d8dde3', borderRadius: 8, padding: '9px 12px', fontSize: 12.5, fontFamily: 'inherit', lineHeight: 1.9, direction: 'rtl', resize: 'vertical', boxSizing: 'border-box' }

// ——— حسابداری معامله: جمع کل خریدار + فرم‌های ثبت (فرم‌ها فقط با دسترسی ویرایش) ———

/** فقط فیلدهایی از Deal (و رابطه‌هایش) که بلوک حسابداری می‌خونه. */
interface AccountingDeal {
  id: string
  status: string
  escrowStatus: string
  agreedPrice: number | null
  weightKg: number | null
  dealFeeToman: number | null
  cargoInsuranceToman: number | null
  buyerTaxToman: number | null
  sellerTaxToman: number | null
  paidToman: number | null
  totalOverrideToman: number | null
  payments: { status: string }[]
  ledgerAdjustments: { id: string; amountToman: number; direction: string; description: string }[]
  materialListing: { askingPriceToman: number; quantityTon: number } | null
  purchaseRequest: { maxPriceToman: number | null; quantityTon: number } | null
}

/**
 * دلیلِ قفلِ ویرایش قیمت واحد یا null — فقط برای «نمایش» هشدار و غیرفعال‌کردن فرم. مرجعِ امنیتی agreedPriceLockReason
 * در actions.ts است (همان شرط‌ها و همان پیام‌ها)؛ هر تغییری باید در هر دو انجام شود (فایل 'use server' نمی‌تونه export کنه).
 */
function agreedPriceLockReason(deal: Pick<AccountingDeal, 'status' | 'escrowStatus' | 'payments'>): string | null {
  if (['void', 'cancelled', 'settled'].includes(deal.status)) return 'قیمت معامله‌ی لغو/باطل/تسویه‌شده قابل تغییر نیست.'
  if (deal.escrowStatus === 'released_manual') return 'وجه این معامله آزاد شده؛ قیمت قابل تغییر نیست.'
  if (deal.payments.some((p) => p.status === 'SUBMITTED' || p.status === 'APPROVED')) return 'برای این معامله پرداخت ثبت یا تایید شده؛ قیمت قابل تغییر نیست.'
  return null
}

/**
 * قفلِ «انتظار تایید» (C9) — کپیِ نمایشیِ approvalHoldLockReason در actions.ts (همان شرط و همان پیام؛ هر دو با هم عوض می‌شن).
 * فقط وقتی قیمت مثبته؛ معامله‌ی بدون قیمت که برای تاییدِ ادمین نگه داشته شده باید بتونه قیمت/وزن بگیره.
 */
function approvalHoldLockReason(deal: Pick<AccountingDeal, 'status' | 'agreedPrice'>): string | null {
  return deal.status === 'awaiting_approval' && (deal.agreedPrice ?? 0) > 0 ? 'معامله در انتظار تاییده؛ اول تایید یا لغو کن.' : null
}

const faNumber = (value: number) => value.toLocaleString('fa-IR')
const tomanText = (value: number) => `${faNumber(value)} تومان`
const signedTomanText = (value: number) => `${value > 0 ? '+' : ''}${tomanText(value)}`
const inputValue = (value: number | null) => (value === null ? '' : String(value))

function AcctRow({ label, value, strong, muted }: { label: string; value: string; strong?: boolean; muted?: boolean }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, fontWeight: strong ? 800 : 400, color: muted ? '#9199a3' : strong ? '#1f2933' : '#4f5560', borderTop: strong ? '1px solid #e5e7eb' : undefined, paddingTop: strong ? 6 : 0 }}>
      <span>{label}</span>
      <span>{value}</span>
    </div>
  )
}

/**
 * بلوک حسابداری یک معامله در /admin-deals. جمع کل «فقط سمت خریدار» است (کالا + بیمه + مالیات خریدار ± تعدیل‌ها)؛
 * کارمزد و مالیات فروشنده ثبت می‌شن ولی در این عدد نمی‌آن. قیمت یا وزن ثبت‌نشده = «—» (عددی ساخته نمی‌شه).
 * همه‌ی مقدارها دستی‌ان؛ placeholderها پیشنهادی‌ان و هیچ‌وقت ثبت نمی‌شن.
 */
function DealAccountingBlock({ deal, canEdit }: { deal: AccountingDeal; canEdit: boolean }) {
  const summary = trySummarizeDeal({
    unitPriceToman: deal.agreedPrice,
    weightKg: deal.weightKg,
    insuranceToman: deal.cargoInsuranceToman,
    buyerTaxToman: deal.buyerTaxToman,
    overrideToman: deal.totalOverrideToman,
    adjustments: deal.ledgerAdjustments.map((a) => ({ amountToman: a.amountToman, direction: a.direction as DealAdjustmentDirection })),
  })
  const holdLockReason = approvalHoldLockReason(deal)
  const lockReason = agreedPriceLockReason(deal) ?? holdLockReason
  const suggestedTon = deal.materialListing?.quantityTon ?? deal.purchaseRequest?.quantityTon ?? null
  const requestCeiling = deal.purchaseRequest?.maxPriceToman ?? null
  const reference = deal.materialListing
    ? { label: 'قیمت اعلامی آگهی', value: deal.materialListing.askingPriceToman }
    : requestCeiling !== null
      ? { label: 'سقف قیمت درخواست خرید', value: requestCeiling }
      : null

  const missing: string[] = []
  if (deal.agreedPrice === null) missing.push('قیمت واحد را وارد کنید')
  if (deal.weightKg === null) missing.push('وزن را وارد کنید')

  const newKey = () => (canEdit ? newFormKey() : '')
  const keyPrice = newKey()
  const keyWeight = newKey()
  const keyInsurance = newKey()
  const keyBuyerTax = newKey()
  const keySellerTax = newKey()
  const keyFee = newKey()
  const keyPaid = newKey()
  const keyOverride = newKey()
  const keyOverrideClear = newKey()
  const keyAddAdjustment = newKey()

  return (
    <details style={{ ...payInstrBox, marginTop: 14, marginBottom: 0 }}>
      <summary style={{ cursor: 'pointer', fontSize: 12.5, fontWeight: 700 }}>
        💰 حسابداری معامله — جمع کل خریدار: {summary?.displayTotal != null ? tomanText(summary.displayTotal) : '—'}
        {summary?.overridden && <span style={payInstrEmptyTag}>دستی</span>}
      </summary>

      <div style={{ marginTop: 10, display: 'grid', gap: 6, fontSize: 12 }}>
        <AcctRow label="قیمت واحد" value={deal.agreedPrice !== null ? `${faNumber(deal.agreedPrice)} تومان/کیلو` : '—'} />
        <AcctRow label="وزن" value={deal.weightKg !== null ? `${kgToTon(deal.weightKg).toLocaleString('fa-IR', { maximumFractionDigits: 3 })} تن` : '—'} />
        {summary ? (
          <>
            <AcctRow label="جمع کالا (قیمت × وزن)" value={summary.goodsTotal !== null ? tomanText(summary.goodsTotal) : '—'} />
            <AcctRow label="بیمه‌ی بار" value={tomanText(summary.insurance)} />
            <AcctRow label="مالیات خریدار" value={tomanText(summary.buyerTax)} />
            <AcctRow label="جمع تعدیل‌ها" value={signedTomanText(summary.adjustmentsNet)} />
            <AcctRow label="جمع کل محاسبه‌شده" value={summary.computedTotal !== null ? tomanText(summary.computedTotal) : '—'} strong />
            {summary.computedTotal === null && missing.length > 0 && (
              <div style={{ fontSize: 11, color: '#92400e' }}>{missing.join('، ')}</div>
            )}
            {summary.overridden && summary.displayTotal !== null && (
              <div style={{ background: '#fef3c7', color: '#92400e', borderRadius: 8, padding: '6px 10px', fontSize: 11.5, fontWeight: 700 }}>
                جمع کل دستی: {tomanText(summary.displayTotal)} — محاسبه‌شده: {summary.computedTotal !== null ? tomanText(summary.computedTotal) : '—'}
                {summary.difference !== null && <>، اختلاف: {signedTomanText(summary.difference)}</>}
                <div style={{ fontWeight: 400, marginTop: 2 }}>تا وقتی جمع دستی ثبت است، تعدیل‌ها در عدد نمایش‌داده‌شده اثری ندارند.</div>
              </div>
            )}
            <AcctRow label="جمع کل خریدار (نمایش‌داده‌شده)" value={summary.displayTotal !== null ? tomanText(summary.displayTotal) : '—'} strong />
          </>
        ) : (
          <div style={{ background: '#fde8e8', color: '#9b1c1c', borderRadius: 8, padding: '6px 10px', fontSize: 11.5, fontWeight: 700 }}>
            داده‌ی مالیِ این معامله نامعتبر است (مقدار منفی/غیرصحیح یا بیش از سقف)؛ جمع کل محاسبه نشد — بررسی کن.
          </div>
        )}
        <AcctRow label="کارمزد معامله (در جمع کل خریدار نیست)" value={deal.dealFeeToman !== null ? tomanText(deal.dealFeeToman) : '—'} muted />
        <AcctRow label="مالیات فروشنده (در جمع کل خریدار نیست)" value={deal.sellerTaxToman !== null ? tomanText(deal.sellerTaxToman) : '—'} muted />
        <AcctRow label="مبلغ پرداخت‌شده (جدا از ردیف‌های پرداخت)" value={deal.paidToman !== null ? tomanText(deal.paidToman) : '—'} muted />
      </div>

      <div style={{ marginTop: 12 }}>
        <div style={{ fontSize: 11.5, fontWeight: 700, marginBottom: 6 }}>تعدیل‌ها</div>
        {deal.ledgerAdjustments.length === 0 ? (
          <div style={{ fontSize: 11, color: '#9199a3' }}>تعدیلی ثبت نشده.</div>
        ) : (
          deal.ledgerAdjustments.map((adj) => {
            const deleteKey = newKey()
            return (
              <div key={adj.id} style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', fontSize: 11.5, borderBottom: '1px dashed #eceff3', padding: '5px 0' }}>
                <span style={adj.direction === 'increase' ? payInstrSetTag : payInstrEmptyTag}>{adj.direction === 'increase' ? 'افزایش' : 'کاهش'}</span>
                <b>{tomanText(adj.amountToman)}</b>
                <span style={{ flex: 1, minWidth: 120, color: '#4f5560' }}>{adj.description}</span>
                {canEdit && <DealAdjustmentDeleteForm key={deleteKey} adjustmentId={adj.id} formKey={deleteKey} />}
              </div>
            )
          })
        )}
      </div>

      {canEdit ? (
        <div style={{ marginTop: 12, display: 'grid', gap: 10 }}>
          <div style={acctCell}>
            <DealAgreedPriceForm
              key={keyPrice}
              dealId={deal.id}
              formKey={keyPrice}
              initial={inputValue(deal.agreedPrice)}
              lockReason={lockReason}
              referenceHint={reference ? `${reference.label} (مرجع): ${faNumber(reference.value)} تومان/کیلو — فقط راهنما، خودکار ثبت نمی‌شود.` : null}
            />
          </div>
          <div style={acctCell}>
            <DealFieldForm
              key={keyWeight}
              dealId={deal.id}
              field="weightKg"
              label="وزن (تن)"
              formKey={keyWeight}
              initial={deal.weightKg !== null ? String(kgToTon(deal.weightKg)) : ''}
              placeholder={suggestedTon !== null ? String(suggestedTon) : 'تن'}
              lockReason={holdLockReason}
              hint={suggestedTon !== null ? `پیشنهاد (از آگهی/درخواست): ${faNumber(suggestedTon)} تن — فقط راهنما، خودکار ثبت نمی‌شود. حداکثر ۳ رقم اعشار.` : 'حداکثر ۳ رقم اعشار.'}
            />
          </div>
          <div style={acctCell}>
            <DealFieldForm key={keyInsurance} dealId={deal.id} field="cargoInsuranceToman" label="بیمه‌ی بار (تومان)" formKey={keyInsurance} initial={inputValue(deal.cargoInsuranceToman)} placeholder="0" hint="دستی؛ در جمع کل خریدار می‌آید. خالی = ۰." />
          </div>
          <div style={acctCell}>
            <DealFieldForm key={keyBuyerTax} dealId={deal.id} field="buyerTaxToman" label="مالیات خریدار (تومان)" formKey={keyBuyerTax} initial={inputValue(deal.buyerTaxToman)} placeholder="0" hint="دستی؛ در جمع کل خریدار می‌آید. خالی = ۰." />
          </div>
          <div style={acctCell}>
            <DealFieldForm key={keySellerTax} dealId={deal.id} field="sellerTaxToman" label="مالیات فروشنده (تومان)" formKey={keySellerTax} initial={inputValue(deal.sellerTaxToman)} placeholder="0" hint="دستی؛ در جمع کل خریدار نمی‌آید. خالی = ۰." />
          </div>
          <div style={acctCell}>
            <DealFieldForm key={keyFee} dealId={deal.id} field="dealFeeToman" label="کارمزد معامله (تومان)" formKey={keyFee} initial={inputValue(deal.dealFeeToman)} placeholder="0" hint="دستی؛ در جمع کل خریدار نمی‌آید. خالی = ۰." />
          </div>
          <div style={acctCell}>
            <DealFieldForm key={keyPaid} dealId={deal.id} field="paidToman" label="مبلغ پرداخت‌شده (تومان)" formKey={keyPaid} initial={inputValue(deal.paidToman)} placeholder="0" hint="جدا از ردیف‌های پرداخت (DealPayment)؛ در جمع کل نمی‌آید. خالی = ۰." />
          </div>
          <div style={acctCell}>
            <DealTotalOverrideForm
              key={keyOverride}
              dealId={deal.id}
              formKey={keyOverride}
              clearFormKey={keyOverrideClear}
              initial={inputValue(deal.totalOverrideToman)}
              computedPlaceholder={summary?.computedTotal != null ? String(summary.computedTotal) : 'جمع کل'}
              hasOverride={deal.totalOverrideToman !== null}
            />
          </div>
          <div style={acctCell}>
            <div style={{ fontSize: 11.5, fontWeight: 700, marginBottom: 6 }}>افزودن تعدیل</div>
            <DealAdjustmentAddForm key={keyAddAdjustment} dealId={deal.id} formKey={keyAddAdjustment} />
          </div>
        </div>
      ) : (
        <div style={{ marginTop: 10, fontSize: 11, color: '#9199a3' }}>برای ویرایش، دسترسی «ویرایش» بخش معاملات لازم است.</div>
      )}
    </details>
  )
}

const acctCell: React.CSSProperties = { background: '#fff', border: '1px solid #e5e7eb', borderRadius: 8, padding: '8px 10px' }
