'use client'

import { useActionState } from 'react'
import type { CSSProperties, ReactNode } from 'react'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'
import { btnDangerStyle, btnPrimaryStyle, btnSmallStyle, inputStyle } from '@/lib/styles/shared'
import { colors, fontSize, radius, spacing } from '@/lib/styles/tokens'
import {
  addDealAdjustmentAction,
  deleteDealAdjustmentAction,
  setDealAccountingFieldAction,
  setDealAgreedPriceAction,
  setDealTotalOverrideAction,
} from './actions'

/**
 * فرم‌های حسابداری معامله (فقط داخل /admin-deals). هر فرم مستقله و بدون رفرش صفحه ثبت می‌شه. خطای ورودی همین‌جا
 * نشون داده می‌شه و مقدارهای تایپ‌شده می‌مونن (React بعد از هر اکشن فیلدهای کنترل‌نشده را به defaultValue برمی‌گردونه).
 * ورودی‌های عددی type="text"ـن تا ارقام فارسی هم برسن؛ مرز اعتبارسنجی خود اکشنه.
 *
 * formKey (idempotency) روی سرور ساخته می‌شه؛ صفحه هم‌زمان به‌عنوان prop و React key می‌دهدش تا بعد از هر رندر
 * تازه (موفقیت)، فرم با state تمیز بالا بیاد. placeholderها ثابت یا «پیشنهادی»ن و هرگز به‌عنوان مقدار ثبت نمی‌شن.
 */

/** فیلدهای مستقل حسابداری؛ باید با ACCOUNTING_FIELD_LABELS در actions.ts یکی باشه (اکشن هر مقدار دیگه را رد می‌کنه). */
export type DealAccountingField =
  | 'weightKg'
  | 'dealFeeToman'
  | 'cargoInsuranceToman'
  | 'buyerTaxToman'
  | 'sellerTaxToman'
  | 'paidToman'

function ErrorBox({ error }: { error: string | null | undefined }) {
  if (!error) return null
  return (
    <div role="alert" aria-live="polite" style={errorStyle}>
      {error}
    </div>
  )
}

function SubmitButton({ pending, disabled, children }: { pending: boolean; disabled?: boolean; children: ReactNode }) {
  return (
    <button
      type="submit"
      disabled={pending || disabled}
      style={{ ...btnPrimaryStyle, ...btnSmallStyle, opacity: pending || disabled ? 0.65 : undefined }}
    >
      {pending ? 'در حال ذخیره…' : children}
    </button>
  )
}

/** ثبت مستقل یک فیلد حسابداری (وزن، کارمزد، بیمه، مالیات خریدار/فروشنده، مبلغ پرداخت‌شده). خالی = ثبت‌نشده (۰ در جمع). */
export function DealFieldForm(props: {
  dealId: string
  field: DealAccountingField
  label: string
  formKey: string
  /** مقدار فعلیِ ذخیره‌شده، به همان شکل که ادمین می‌تایپ می‌کنه (وزن: تن). */
  initial: string
  placeholder: string
  hint?: string
  /** دلیل قفل (فقط وزن، «انتظار تایید»)؛ ورودی و دکمه غیرفعال می‌شن. مرجع امنیتی خود اکشنه. */
  lockReason?: string | null
}) {
  const { dealId, field, label, formKey, initial, placeholder, hint, lockReason = null } = props
  const [state, formAction, pending] = useActionState(setDealAccountingFieldAction, null)
  const locked = lockReason !== null

  return (
    <form action={formAction} style={rowFormStyle}>
      <input type="hidden" name="dealId" value={dealId} />
      <input type="hidden" name="field" value={field} />
      <input type="hidden" name="formKey" value={formKey} />
      <label style={fieldLabelStyle}>
        {label}
        <input
          name="value"
          type="text"
          inputMode="decimal"
          dir="ltr"
          autoComplete="off"
          disabled={locked}
          defaultValue={state?.values?.value ?? initial}
          placeholder={placeholder}
          style={compactInputStyle}
        />
      </label>
      <SubmitButton pending={pending} disabled={locked}>
        ثبت
      </SubmitButton>
      {hint && <span style={hintStyle}>{hint}</span>}
      {locked && <div style={warningBoxStyle}>{lockReason}</div>}
      <ErrorBox error={state?.error} />
    </form>
  )
}

/**
 * ویرایش قیمت واحد (تومان/کیلو). الزامی و پاک‌نشدنی. lockReason (از page.tsx، کپیِ نمایشیِ گارد سرور) = ورودی و دکمه
 * غیرفعال؛ مرجع امنیتی خود اکشنه. referenceHint قیمت آگهی/درخواست را فقط به‌عنوان راهنما نشون می‌ده، نه مقدار پیش‌فرض.
 */
export function DealAgreedPriceForm(props: {
  dealId: string
  formKey: string
  initial: string
  lockReason: string | null
  referenceHint: string | null
}) {
  const { dealId, formKey, initial, lockReason, referenceHint } = props
  const [state, formAction, pending] = useActionState(setDealAgreedPriceAction, null)
  const locked = lockReason !== null

  return (
    <form action={formAction} style={rowFormStyle}>
      <input type="hidden" name="dealId" value={dealId} />
      <input type="hidden" name="formKey" value={formKey} />
      <label style={fieldLabelStyle}>
        قیمت واحد (تومان/کیلو)
        <input
          name="value"
          type="text"
          inputMode="decimal"
          dir="ltr"
          autoComplete="off"
          required
          disabled={locked}
          defaultValue={state?.values?.value ?? initial}
          style={compactInputStyle}
        />
      </label>
      <SubmitButton pending={pending} disabled={locked}>
        ثبت قیمت
      </SubmitButton>
      {referenceHint && <span style={hintStyle}>{referenceHint}</span>}
      {locked ? (
        <div style={warningBoxStyle}>{lockReason}</div>
      ) : (
        <div style={warningBoxStyle}>
          تغییر قیمت، مبلغ ردیف‌های پرداخت (DealPayment) را خودکار تغییر نمی‌دهد؛ در صورت نیاز جداگانه اصلاح کن.
        </div>
      )}
      <ErrorBox error={state?.error} />
    </form>
  )
}

/**
 * جمع کل دستی (override) + دکمه‌ی حذف آن. placeholder = جمع محاسبه‌شده (فقط پیشنهاد؛ مقدار ثبت نمی‌شه).
 * با وجود override، تعدیل‌ها عدد نمایش‌داده‌شده را تغییر نمی‌دهند. حذف override با فرم جدا (formKey جدا) انجام می‌شه.
 */
export function DealTotalOverrideForm(props: {
  dealId: string
  formKey: string
  clearFormKey: string
  initial: string
  computedPlaceholder: string
  hasOverride: boolean
}) {
  const { dealId, formKey, clearFormKey, initial, computedPlaceholder, hasOverride } = props
  const [state, formAction, pending] = useActionState(setDealTotalOverrideAction, null)
  const [clearState, clearAction] = useActionState(setDealTotalOverrideAction, null)

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: spacing.sm }}>
      <form action={formAction} style={rowFormStyle}>
        <input type="hidden" name="dealId" value={dealId} />
        <input type="hidden" name="formKey" value={formKey} />
        <label style={fieldLabelStyle}>
          جمع کل دستی (تومان)
          <input
            name="value"
            type="text"
            inputMode="decimal"
            dir="ltr"
            autoComplete="off"
            defaultValue={state?.values?.value ?? initial}
            placeholder={computedPlaceholder}
            style={compactInputStyle}
          />
        </label>
        <SubmitButton pending={pending}>ثبت جمع دستی</SubmitButton>
        <ErrorBox error={state?.error} />
      </form>
      {hasOverride && (
        <form action={clearAction} style={rowFormStyle}>
          <input type="hidden" name="dealId" value={dealId} />
          <input type="hidden" name="formKey" value={clearFormKey} />
          <input type="hidden" name="intent" value="clear" />
          <ConfirmSubmitButton
            message="جمع کل دستی حذف بشه و جمع محاسبه‌شده نمایش داده بشه؟"
            style={{ ...btnDangerStyle, ...btnSmallStyle }}
          >
            حذف جمع دستی
          </ConfirmSubmitButton>
          <ErrorBox error={clearState?.error} />
        </form>
      )}
    </div>
  )
}

/** افزودن یک ردیف تعدیل (افزایش/کاهش، مبلغ مثبت، شرح الزامی ≤۲۰۰ نویسه). */
export function DealAdjustmentAddForm(props: { dealId: string; formKey: string }) {
  const { dealId, formKey } = props
  const [state, formAction, pending] = useActionState(addDealAdjustmentAction, null)

  return (
    <form action={formAction} style={rowFormStyle}>
      <input type="hidden" name="dealId" value={dealId} />
      <input type="hidden" name="formKey" value={formKey} />
      <label style={{ ...fieldLabelStyle, flex: '0 1 120px', minWidth: 110 }}>
        جهت
        <select name="direction" required defaultValue={state?.values?.direction ?? ''} style={compactInputStyle}>
          <option value="">— انتخاب —</option>
          <option value="increase">افزایش</option>
          <option value="decrease">کاهش</option>
        </select>
      </label>
      <label style={fieldLabelStyle}>
        مبلغ تعدیل (تومان)
        <input
          name="amount"
          type="text"
          inputMode="decimal"
          dir="ltr"
          autoComplete="off"
          required
          defaultValue={state?.values?.amount ?? ''}
          style={compactInputStyle}
        />
      </label>
      <label style={{ ...fieldLabelStyle, flex: '2 1 220px' }}>
        شرح (الزامی)
        <input
          name="description"
          type="text"
          maxLength={200}
          autoComplete="off"
          required
          defaultValue={state?.values?.description ?? ''}
          style={compactInputStyle}
        />
      </label>
      <SubmitButton pending={pending}>افزودن تعدیل</SubmitButton>
      <ErrorBox error={state?.error} />
    </form>
  )
}

/** حذفِ نرمِ یک ردیف تعدیل (ردیف و تاریخچه‌اش می‌مونن؛ فقط از جمع خارج می‌شه). */
export function DealAdjustmentDeleteForm(props: { adjustmentId: string; formKey: string }) {
  const { adjustmentId, formKey } = props
  const [state, formAction] = useActionState(deleteDealAdjustmentAction, null)

  return (
    <form action={formAction} style={{ display: 'inline-flex', gap: spacing.xs, alignItems: 'center', flexWrap: 'wrap' }}>
      <input type="hidden" name="adjustmentId" value={adjustmentId} />
      <input type="hidden" name="formKey" value={formKey} />
      <ConfirmSubmitButton
        message="این تعدیل از جمع کل حذف بشه؟ (ردیف و تاریخچه‌اش در سابقه می‌مونه.)"
        style={{ ...btnDangerStyle, ...btnSmallStyle }}
      >
        حذف
      </ConfirmSubmitButton>
      <ErrorBox error={state?.error} />
    </form>
  )
}

const rowFormStyle: CSSProperties = {
  display: 'flex',
  flexWrap: 'wrap',
  gap: spacing.sm,
  alignItems: 'flex-end',
}
const fieldLabelStyle: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 4,
  fontSize: fontSize.xs,
  fontWeight: 700,
  color: colors.textSecondary,
  flex: '1 1 150px',
  minWidth: 130,
}
const compactInputStyle: CSSProperties = { ...inputStyle, padding: '6px 10px', fontSize: fontSize.sm }
const hintStyle: CSSProperties = { fontSize: fontSize.xs, color: colors.textMuted, width: '100%' }
const warningBoxStyle: CSSProperties = {
  width: '100%',
  background: colors.warningBg,
  color: colors.warningText,
  borderRadius: radius.md,
  padding: '6px 10px',
  fontSize: fontSize.xs,
  fontWeight: 600,
}
const errorStyle: CSSProperties = {
  width: '100%',
  background: colors.dangerBg,
  color: colors.dangerText,
  borderRadius: radius.md,
  padding: '7px 10px',
  fontSize: fontSize.xs,
}
