import { NextRequest, NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { getCurrentUserOrNull } from '@/lib/currentUser'
import { getSectionAccess } from '@/lib/permissions'
import {
  savePaymentReceipt,
  attachPaymentReceipt,
  checkOrderReceiptUpload,
  ReceiptNotReplaceableError,
} from '@/lib/paymentReceipt'

/**
 * آپلود رسید پرداختِ «سفارش» (Order). رسید معامله‌ی بازار (Deal) از این مسیر رد نمی‌شود:
 * آن مسیر با Server Action `uploadDealPaymentReceiptAction` (my-deals/actions.ts) انجام
 * می‌شود که طرفِ معامله (خریدار/فروشنده) را چک می‌کند و رسیدِ ثبت‌شده را بازنویسی نمی‌کند. شاخه‌ی قدیمیِ `deal` اینجا هیچ چکِ مالکیتی
 * نداشت (هر کاربرِ واردشده می‌توانست رسیدِ هر معامله را بنویسد) و هیچ UI به آن وصل نبود،
 * پس حذف شد.
 *
 * مجاز: صاحبِ سفارش، یا ادمین، یا کاربری که دسترسیِ ویرایشِ بخش «سفارش‌ها» یا «پرداخت‌ها»
 * دارد (ثبتِ رسید به‌جای مشتری؛ «کارمند»).
 * قانونِ جایگزینی (checkOrderReceiptUpload): رسیدِ ثبت‌نشده یا ردشده را همه‌ی مجازها می‌فرستند،
 * رسیدِ در انتظار بررسی را فقط کارمند/ادمین عوض می‌کند، رسیدِ تاییدشده را هیچ‌کس.
 */
async function getOrderReceiptUploaderRole(
  user: { id: string; role: string },
  orderUserId: string
): Promise<'staff' | 'owner' | null> {
  if (user.role === 'admin') return 'staff'
  const [orders, payments] = await Promise.all([
    getSectionAccess(user.id, 'orders'),
    getSectionAccess(user.id, 'payments'),
  ])
  if (orders === 'edit' || orders === 'full' || payments === 'edit' || payments === 'full') return 'staff'
  return user.id === orderUserId ? 'owner' : null
}

export async function POST(request: NextRequest) {
  const user = await getCurrentUserOrNull()
  if (!user) {
    return NextResponse.json({ error: 'ابتدا وارد شوید' }, { status: 401 })
  }

  let formData: FormData
  try {
    formData = await request.formData()
  } catch {
    return NextResponse.json({ error: 'درخواست نامعتبر است' }, { status: 400 })
  }

  const entityType = formData.get('entityType')
  const entityId = formData.get('entityId')
  const file = formData.get('receipt')

  if (entityType !== 'order') {
    return NextResponse.json({ error: 'نوع موجودیت نامعتبر است' }, { status: 400 })
  }
  if (!entityId || typeof entityId !== 'string') {
    return NextResponse.json({ error: 'شناسه‌ی موجودیت الزامی است' }, { status: 400 })
  }
  if (!(file instanceof File)) {
    return NextResponse.json({ error: 'فایل رسید الزامی است' }, { status: 400 })
  }

  // چکِ مالکیت قبل از ذخیره‌ی فایل: کاربرِ غیرمجاز نباید روی دیسک چیزی بنویسد.
  const order = await prisma.order.findUnique({
    where: { id: entityId },
    select: { userId: true, paymentReceiptUrl: true, paymentReceiptStatus: true },
  })
  if (!order) {
    return NextResponse.json({ error: 'سفارش پیدا نشد' }, { status: 404 })
  }
  const role = await getOrderReceiptUploaderRole(user, order.userId)
  if (!role) {
    return NextResponse.json({ error: 'اجازه‌ی ثبت رسید برای این سفارش را ندارید' }, { status: 403 })
  }
  // قانونِ جایگزینی هم قبل از ذخیره‌ی فایل (فایلِ ردشده روی دیسک نماند) و بعداً دوباره داخل تراکنش چک می‌شود.
  const canReplacePending = role === 'staff'
  const verdict = checkOrderReceiptUpload(order, canReplacePending)
  if (!verdict.ok) {
    return NextResponse.json({ error: verdict.reason }, { status: 409 })
  }

  let receiptUrl: string
  try {
    receiptUrl = await savePaymentReceipt(file)
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'خطا در ذخیره‌ی فایل'
    return NextResponse.json({ error: msg }, { status: 422 })
  }

  try {
    await attachPaymentReceipt(entityType, entityId, receiptUrl, user.id, { canReplacePending })
  } catch (err) {
    if (err instanceof ReceiptNotReplaceableError) {
      return NextResponse.json({ error: err.message }, { status: 409 })
    }
    return NextResponse.json({ error: 'خطا در ثبت اطلاعات' }, { status: 500 })
  }

  return NextResponse.json({ ok: true, receiptUrl })
}
