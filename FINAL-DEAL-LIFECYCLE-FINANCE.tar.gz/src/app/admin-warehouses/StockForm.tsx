'use client'

import { useActionState } from 'react'
import type { CSSProperties } from 'react'
import { btnPrimaryStyle, inputStyle } from '@/lib/styles/shared'
import { colors, fontSize, radius, spacing } from '@/lib/styles/tokens'
import { upsertStockAction } from './actions'

interface StockFormInitial {
  quantityTon: string
  priceRial: string
  batch: string
  packagingType: string
}

type StockFormProps = {
  warehouseId: string
  /**
   * کلید یک‌بارمصرف فرم (idempotency). روی سرور ساخته می‌شه و در یک input مخفی می‌آد؛ صفحه هم از همین
   * مقدار به‌عنوان key استفاده می‌کنه تا بعد از هر رندر تازه، فرم با state تمیز بالا بیاد.
   */
  formKey: string
  /** مقدار اولیه‌ی فیلدها (رشته، همان چیزی که کاربر می‌بینه). */
  initial: StockFormInitial
} & (
  | { mode: 'edit'; gradeId: string; heading: string }
  | { mode: 'add'; grades: { id: string; code: string; category: string }[] }
)

/**
 * فرم افزودن/ویرایش موجودی یک گرید در یک انبار (هر دو به upsertStockAction می‌رن). خطای ورودی همین‌جا
 * نشون داده می‌شه و مقدارهای تایپ‌شده می‌مونن (React بعد از هر اکشن فیلدهای کنترل‌نشده را به defaultValue
 * برمی‌گردونه). ورودی‌های عددی type="text"ـن تا ارقام فارسی هم برسن؛ مرز اعتبارسنجی خود اکشنه.
 */
export default function StockForm(props: StockFormProps) {
  const { warehouseId, formKey, initial } = props
  const [state, formAction, pending] = useActionState(upsertStockAction, null)

  const value = (name: keyof StockFormInitial) => state?.values?.[name] ?? initial[name]
  const star = props.mode === 'add' ? ' *' : ''

  const hidden = (
    <>
      <input type="hidden" name="warehouseId" value={warehouseId} />
      <input type="hidden" name="formKey" value={formKey} />
      {props.mode === 'edit' && <input type="hidden" name="gradeId" value={props.gradeId} />}
    </>
  )

  const errorBox = state?.error ? (
    <div role="alert" aria-live="polite" style={errorStyle}>
      {state.error}
    </div>
  ) : null

  const fields = (
    <>
      <label style={fieldLabelStyle}>
        {`مقدار (تن)${star}`}
        <input name="quantityTon" type="text" inputMode="decimal" dir="ltr" autoComplete="off" defaultValue={value('quantityTon')} required style={{ ...inputStyle, width: 110 }} />
      </label>
      <label style={fieldLabelStyle}>
        {`قیمت (تومان/کیلو)${star}`}
        <input name="priceRial" type="text" inputMode="decimal" dir="ltr" autoComplete="off" defaultValue={value('priceRial')} required style={{ ...inputStyle, width: 110 }} />
      </label>
      <label style={fieldLabelStyle}>
        بچ
        <input name="batch" defaultValue={value('batch')} style={{ ...inputStyle, width: 110 }} />
      </label>
      <label style={fieldLabelStyle}>
        نوع بسته‌بندی
        <input name="packagingType" defaultValue={value('packagingType')} placeholder="مثلاً کیسه ۲۵کیلویی" style={{ ...inputStyle, width: 150 }} />
      </label>
    </>
  )

  const submit = (
    <button type="submit" disabled={pending} style={{ ...btnPrimaryStyle, opacity: pending ? 0.65 : undefined }}>
      {pending ? 'در حال ذخیره…' : 'ذخیره'}
    </button>
  )

  if (props.mode === 'edit') {
    return (
      <form action={formAction} style={{ display: 'flex', flexWrap: 'wrap', gap: spacing.md, alignItems: 'flex-end' }}>
        {hidden}
        <div style={{ fontSize: fontSize.sm, fontWeight: 700, width: '100%' }}>{props.heading}</div>
        {errorBox}
        {fields}
        {submit}
        <a href="?" style={cancelLinkStyle}>لغو</a>
      </form>
    )
  }

  return (
    <form action={formAction} style={formCardStyle}>
      {hidden}
      {errorBox}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: spacing.md, alignItems: 'flex-end' }}>
        <label style={{ ...fieldLabelStyle, flex: '1 1 180px' }}>
          گرید *
          <select name="gradeId" required defaultValue={state?.values?.gradeId ?? ''} style={inputStyle}>
            <option value="">— انتخاب گرید —</option>
            {props.grades.map((g) => (
              <option key={g.id} value={g.id}>
                {g.code} ({g.category})
              </option>
            ))}
          </select>
        </label>
        {fields}
        {submit}
      </div>
    </form>
  )
}

const formCardStyle: CSSProperties = {
  background: colors.bgPage,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.md,
  padding: spacing.lg,
  marginTop: spacing.md,
}
const fieldLabelStyle: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 4,
  fontSize: fontSize.xs,
  fontWeight: 700,
  color: colors.textSecondary,
  flex: '1 1 180px',
  minWidth: 160,
}
const cancelLinkStyle: CSSProperties = {
  color: colors.textMuted,
  fontSize: fontSize.xs,
  marginInlineStart: spacing.xs,
}
const errorStyle: CSSProperties = {
  width: '100%',
  background: colors.dangerBg,
  color: colors.dangerText,
  borderRadius: radius.md,
  padding: '9px 12px',
  marginBottom: spacing.md,
  fontSize: fontSize.sm,
}
