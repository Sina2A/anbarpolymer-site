import prisma from '@/lib/prisma'
import { getSurfaceHome } from '@/lib/surfaceHome'
import { getCurrentUser } from '@/lib/currentUser'
import { isPriceStillValid } from '@/lib/pricing'
import { trySummarizeOrderItems, formatToman } from '@/lib/money'
import { getUserKycLevel } from '@/lib/kyc'
import KycStatusBanner from '@/components/KycStatusBanner'
import UserNav from '@/components/UserNav'
import PanelHeader from '@/components/PanelHeader'
import Footer from '@/components/Footer'
import PaymentMethodModal from '@/components/PaymentMethodModal'
import RefundPolicyHint from '@/components/RefundPolicyHint'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { cardStyle as sharedCardStyle, badgeStyle, btnSecondaryStyle, orderStatusBadgeStyle, getOrderStatusLabel, getOrderStatusNextAction, ORDER_STATUS_CONFIG } from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

const STATUS_LABELS: Record<string, string> = {
  pending: 'در حال ثبت اولیه',
  priced: 'در حال تعیین قیمت توسط کارشناس فروش',
  awaiting_approval: 'در انتظار تایید مدیر',
  buyer_confirmed: 'در انتظار تایید شما',
  ...Object.fromEntries(Object.entries(ORDER_STATUS_CONFIG).map(([k, v]) => [k, v.label])),
  rejected: 'رد شد',
}

export default async function MyOrdersPage() {
  const user = await getCurrentUser()
  const kycLevel = await getUserKycLevel(user.id)

  const orders = await prisma.order.findMany({
    where: { userId: user.id },
    include: { items: { include: { grade: true, warehouse: true } } },
    orderBy: { createdAt: 'desc' },
  })

  return (
    <>
      <PanelHeader homeHref={getSurfaceHome()} currentUserName={user.companyName} />
      <div style={pageStyle}>
        <div style={{ width: '100%', display: 'flex', gap: 24 }} className="admin-page-wrap">
          <UserNav currentUserName={user.companyName} activeSection="orders" />
          <div style={{ flex: 1, minWidth: 0 }}>
            <h1 style={{ fontSize: fontSize.xxl, fontWeight: 800, marginBottom: spacing.xs, color: colors.textPrimary }}>سفارش‌های من</h1>
            <p style={{ fontSize: fontSize.base, color: colors.textMuted, marginBottom: spacing.xl }}>لیست واقعی درخواست‌ها و سفارش‌های ثبت‌شده‌ی شما</p>

            <KycStatusBanner level={kycLevel} />

            {orders.length === 0 && (
              <div style={{ padding: spacing.xxl, textAlign: 'center', color: colors.textMuted, border: `1px dashed ${colors.borderStrong}`, borderRadius: radius.lg }}>
                هنوز هیچ درخواستی ثبت نکردی — از صفحه‌ی «استعلام قیمت» شروع کن.
              </div>
            )}

            {orders.map((order) => {
              // موتور واحد lib/money (قیمت تومان/کیلوگرم × کیلوگرم + مالیاتِ دستیِ هر ردیف) — همان مبلغ پیش‌فاکتور و پرداخت
              const summary = trySummarizeOrderItems(order.items)
              // تا کارشناس قیمت نهایی ثبت نکرده، مبالغ بر اساس قیمت مرجع‌ان
              const isReferenceOnly = order.items.every((it) => it.finalPrice == null)
              return (
                <div key={order.id} style={cardStyle}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.md }}>
                    <b style={{ fontSize: fontSize.md }}>سفارش #{order.id.slice(0, 8)}</b>
                    <span style={orderStatusBadgeStyle(order.status)}>{STATUS_LABELS[order.status] || order.status}</span>
                  </div>

                  {order.items.map((item) => {
                    const valid = isPriceStillValid(item.priceValidUntil)
                    return (
                      <div key={item.id} style={itemRowStyle}>
                        <div>
                          <b style={{ fontFamily: 'monospace', fontSize: fontSize.sm }}>{item.grade.code}</b>
                          <span style={{ fontSize: fontSize.xs, color: colors.textMuted, marginRight: spacing.sm }}>
                            {item.warehouse?.name} — {item.quantity} تن
                          </span>
                        </div>
                        <div style={{ textAlign: 'left' }}>
                          <div style={{ fontFamily: 'monospace', fontSize: fontSize.sm }}>{(item.finalPrice ?? item.price).toLocaleString('en-US')} تومان/کیلوگرم</div>
                          {!item.finalPrice && (
                            <div style={{ fontSize: 10, color: valid ? colors.successText : colors.dangerText, fontWeight: 700 }}>
                              {valid ? 'قیمت هنوز معتبره' : 'مهلت قیمت گذشته — منتظر تایید مجدد کارشناس'}
                            </div>
                          )}
                        </div>
                      </div>
                    )
                  })}

                  {summary ? (
                    <div style={{ fontSize: fontSize.sm, marginTop: spacing.sm, textAlign: 'left' }}>
                      {isReferenceOnly ? (
                        // هنوز قیمت‌گذاری نشده: مالیات هنوز وارد نشده، پس نه «مالیات ۰» و نه جمع کلِ گمراه‌کننده نشون داده می‌شه.
                        <>
                          <div>جمع مرجع: {formatToman(summary.itemsTotal)} تومان</div>
                          <div style={{ fontSize: fontSize.xs, color: colors.textMuted }}>
                            قیمت نهایی هنوز توسط کارشناس ثبت نشده — مبلغ بر اساس قیمت مرجع است و مالیات پس از قیمت‌گذاری مشخص می‌شود.
                          </div>
                        </>
                      ) : (
                        <>
                          <div>جمع اقلام: {formatToman(summary.itemsTotal)} تومان</div>
                          <div>جمع کل مالیات: {formatToman(summary.taxTotal)} تومان</div>
                          <div style={{ fontWeight: 700 }}>جمع کل قابل پرداخت: {formatToman(summary.grandTotal)} تومان</div>
                        </>
                      )}
                    </div>
                  ) : (
                    <div style={{ fontSize: fontSize.sm, fontWeight: 700, marginTop: spacing.sm, textAlign: 'left', color: colors.dangerText }}>
                      مبلغ این سفارش قابل محاسبه نیست — با پشتیبانی تماس بگیرید.
                    </div>
                  )}

                  {/* دکمه‌ی آپلود رسید — فقط برای سفارش‌هایی که در مرحله‌ی پرداخت هستن */}
                  {order.status === 'contracted' && (
                    <div style={{ marginTop: 12, display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                      <a href={`/proformas/${order.id}`} style={payLinkStyle}>پرداخت ↗</a>
                      {order.paymentReceiptUrl ? (
                        <span style={receiptSentTag}>✓ رسید پرداخت ارسال شد — در انتظار تایید</span>
                      ) : summary ? (
                        <PaymentMethodModal
                          entityType="order"
                          entityId={order.id}
                          amountLabel={`${formatToman(summary.grandTotal)} تومان`}
                          purposeLabel="پرداخت سفارش"
                        />
                      ) : null}
                      <RefundPolicyHint />
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      </div>
      <Footer homeHref={getSurfaceHome()} />
    </>
  )
}

const pageStyle: React.CSSProperties = { minHeight: '100vh', background: colors.bgCard, padding: `${spacing.xxl}px ${spacing.xl}px`, fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl' }
const cardStyle: React.CSSProperties = { ...sharedCardStyle, padding: 18, marginBottom: 14 }
const itemRowStyle: React.CSSProperties = { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: `1px solid ${colors.borderSubtle}` }
const receiptSentTag: React.CSSProperties = { display: 'inline-block', fontSize: fontSize.sm, fontWeight: 700, color: colors.successText, background: colors.successBg, padding: '6px 14px', borderRadius: radius.md }
const payLinkStyle: React.CSSProperties = { ...btnSecondaryStyle, display: 'inline-block', color: colors.navy, borderColor: colors.navy, fontWeight: 700, textDecoration: 'none' }
