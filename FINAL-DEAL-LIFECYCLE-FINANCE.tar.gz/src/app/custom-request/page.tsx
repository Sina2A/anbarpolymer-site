import prisma from '@/lib/prisma'
import { getSurfaceHome } from '@/lib/surfaceHome'
import { getCurrentUser } from '@/lib/currentUser'
import UserNav from '@/components/UserNav'
import PanelHeader from '@/components/PanelHeader'
import Footer from '@/components/Footer'
import { submitCustomRfqAction } from './actions'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { cardStyle as sharedCardStyle, badgeStyle, btnPrimaryStyle, inputStyle as sharedInputStyle, labelStyle as sharedLabelStyle, emptyStateStyle } from '@/lib/styles/shared'
import Pagination from '@/components/Pagination'

export const dynamic = 'force-dynamic'

type SearchParams = Promise<Record<string, string | string[] | undefined>>

function one(v: string | string[] | undefined): string | undefined {
  if (Array.isArray(v)) return v[0]
  return v
}

export default async function CustomRequestPage({ searchParams }: { searchParams: SearchParams }) {
  const user = await getCurrentUser()
  const sp = await searchParams
  const suggestedGrade = one(sp.grade) // از query param ?grade=CODE (دکمه‌ی grades/[code])

  // صفحه‌بندی لیست درخواست‌های قبلی — ۱۰/۲۰/۳۰، پیش‌فرض ۲۰ (پارامتر grade حفظ می‌شود)
  const perPageRaw = parseInt(one(sp.perPage) ?? '20', 10)
  const perPage = [10, 20, 30].includes(perPageRaw) ? perPageRaw : 20
  const total = await prisma.customRfq.count({ where: { userId: user.id } })
  const totalPages = Math.max(1, Math.ceil(total / perPage))
  const pageRaw = parseInt(one(sp.page) ?? '1', 10)
  const page = Math.min(Math.max(1, isNaN(pageRaw) ? 1 : pageRaw), totalPages)

  const buildPageHref = (p: number) =>
    `/custom-request?page=${p}&perPage=${perPage}${suggestedGrade ? `&grade=${encodeURIComponent(suggestedGrade)}` : ''}`

  // لیست درخواست‌های قبلی خودِ کاربر
  const myRfqs = await prisma.customRfq.findMany({
    where: { userId: user.id },
    orderBy: [{ createdAt: 'desc' }, { id: 'asc' }],
    skip: (page - 1) * perPage,
    take: perPage,
  })

  return (
    <>
      <PanelHeader homeHref={getSurfaceHome()} currentUserName={user.companyName} />
      <div style={pageStyle}>
        <div style={wrapStyle}>
          <UserNav currentUserName={user.companyName} activeSection="custom-request" />

          <div style={{ flex: 1, minWidth: 0 }}>
            <h1 style={titleStyle}>درخواست محصول غیرکاتالوگی (استعلام سفارشی)</h1>
            <p style={subStyle}>
              محصولی که می‌خوای توی کاتالوگ نیست؟ مشخصات فنی دقیقش رو نداری؟ اینجا بنویس —
              کارشناس ما بررسی می‌کنه و قیمت پیشنهادی می‌ده.
            </p>

            {/* ── فرم درخواست جدید ── */}
            <div style={cardStyle}>
              <b style={{ fontSize: fontSize.md, display: 'block', marginBottom: spacing.lg }}>ثبت درخواست جدید</b>
              <form action={submitCustomRfqAction}>
                <div style={{ marginBottom: 12 }}>
                  <div style={labelStyle}>نوع پلیمر</div>
                  <select name="polymerType" required style={inputStyle}>
                    <option value="">انتخاب کنید</option>
                    <option value="PP">پلی‌پروپیلن (PP)</option>
                    <option value="PE">پلی‌اتیلن (PE)</option>
                    <option value="PVC">پی‌وی‌سی (PVC)</option>
                    <option value="PET">پلی‌اتیلن ترفتالات (PET)</option>
                    <option value="PS">پلی‌استایرن (PS)</option>
                    <option value="ABS">ABS</option>
                    <option value="other">سایر</option>
                  </select>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
                  <div>
                    <div style={labelStyle}>MFI حداقل (اختیاری)</div>
                    <input
                      name="mfiRangeMin"
                      type="number"
                      step="0.1"
                      placeholder="مثلاً ۲"
                      style={inputStyle}
                    />
                  </div>
                  <div>
                    <div style={labelStyle}>MFI حداکثر (اختیاری)</div>
                    <input
                      name="mfiRangeMax"
                      type="number"
                      step="0.1"
                      placeholder="مثلاً ۸"
                      style={inputStyle}
                    />
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
                  <div>
                    <div style={labelStyle}>چگالی حداقل (اختیاری)</div>
                    <input
                      name="densityMin"
                      type="number"
                      step="0.001"
                      placeholder="مثلاً ۰.۹۰"
                      style={inputStyle}
                    />
                  </div>
                  <div>
                    <div style={labelStyle}>چگالی حداکثر (اختیاری)</div>
                    <input
                      name="densityMax"
                      type="number"
                      step="0.001"
                      placeholder="مثلاً ۰.۹۲"
                      style={inputStyle}
                    />
                  </div>
                </div>

                <div style={{ marginBottom: 12 }}>
                  <div style={labelStyle}>مقدار درخواستی (تن)</div>
                  <input
                    name="quantityTon"
                    type="text"
                    inputMode="decimal"
                    dir="ltr"
                    required
                    placeholder="مثلاً ۲۵"
                    style={inputStyle}
                  />
                </div>

                <div style={{ marginBottom: 14 }}>
                  <div style={labelStyle}>الزامات خاص (اختیاری)</div>
                  <textarea
                    name="requirements"
                    rows={4}
                    placeholder="مثلاً: باید FDA approved باشه، رنگ سفید شیری، برای تزریق..."
                    style={{ ...inputStyle, resize: 'vertical' }}
                  />
                </div>

                {suggestedGrade && (
                  <input type="hidden" name="suggestedGradeCode" value={suggestedGrade} />
                )}

                {suggestedGrade && (
                  <div style={infoBannerStyle}>
                    💡 این درخواست از صفحه‌ی گرید <b>{suggestedGrade}</b> شروع شده — کارشناس
                    گریدهای مشابه رو بررسی می‌کنه.
                  </div>
                )}

                <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                  <button type="submit" style={submitBtnStyle}>
                    ارسال درخواست
                  </button>
                </div>
              </form>
            </div>

            {/* ── لیست درخواست‌های قبلی ── */}
            <h2 style={{ fontSize: fontSize.lg, fontWeight: 700, margin: '28px 0 14px', color: colors.textPrimary }}>درخواست‌های قبلی من</h2>
            {total === 0 ? (
              <div style={emptyStyle}>هنوز درخواستی ثبت نکردی.</div>
            ) : (
              <div style={listContainerStyle}>
                <div style={{ marginBottom: spacing.md }}>
                  <Pagination page={page} totalPages={totalPages} buildPageHref={buildPageHref} />
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {myRfqs.map((rfq, i) => (
                  <div key={rfq.id} style={rfqCardStyle}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: spacing.sm }}>
                      <div>
                        <b style={{ fontSize: fontSize.base }}>{(page - 1) * perPage + i + 1}. {rfq.polymerType}</b>
                        {rfq.suggestedGradeCode && (
                          <span style={{ fontSize: fontSize.xs, color: colors.textMuted, marginRight: spacing.sm }}>
                            (پیشنهادی: {rfq.suggestedGradeCode})
                          </span>
                        )}
                      </div>
                      <span style={statusBadge(rfq.status)}>{translateStatus(rfq.status)}</span>
                    </div>

                    <div style={{ fontSize: fontSize.sm, color: colors.textSecondary, marginBottom: 6 }}>
                      مقدار: {rfq.quantityTon} تن
                      {rfq.mfiRangeMin != null && rfq.mfiRangeMax != null && (
                        <> · MFI: {rfq.mfiRangeMin}–{rfq.mfiRangeMax}</>
                      )}
                      {rfq.densityMin != null && rfq.densityMax != null && (
                        <> · چگالی: {rfq.densityMin}–{rfq.densityMax}</>
                      )}
                    </div>

                    {rfq.requirements && (
                      <div style={{ fontSize: fontSize.xs, color: colors.textMuted, marginBottom: 6 }}>
                        {rfq.requirements.slice(0, 120)}
                        {rfq.requirements.length > 120 && '...'}
                      </div>
                    )}

                    {rfq.expertResponse && (
                      <div style={expertResponseStyle}>
                        <b>پاسخ کارشناس:</b> {rfq.expertResponse}
                      </div>
                    )}

                    <div style={{ fontSize: fontSize.xs, color: colors.textMuted, marginTop: 6 }}>
                      ثبت‌شده: {new Date(rfq.createdAt).toLocaleDateString('fa-IR')}
                      {rfq.answeredAt && (
                        <> · پاسخ داده‌شده: {new Date(rfq.answeredAt).toLocaleDateString('fa-IR')}</>
                      )}
                    </div>
                  </div>
                ))}
                </div>

                {/* تعداد در صفحه — تغییر آن صفحه را به ۱ برمی‌گرداند */}
                <form method="get" action="/custom-request" className="per-page-row">
                  {suggestedGrade && <input type="hidden" name="grade" value={suggestedGrade} />}
                  <span>تعداد در صفحه:</span>
                  <select name="perPage" defaultValue={String(perPage)}>
                    <option value="10">۱۰</option>
                    <option value="20">۲۰</option>
                    <option value="30">۳۰</option>
                  </select>
                  <button type="submit" style={perPageBtnStyle}>اعمال</button>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>
      <Footer homeHref={getSurfaceHome()} />
    </>
  )
}

// ── ترجمه و رنگ وضعیت ──────────────────────────────────────────────────
function translateStatus(status: string): string {
  const map: Record<string, string> = { open: 'باز', answered: 'پاسخ‌داده‌شده', closed: 'بسته' }
  return map[status] ?? status
}

function statusBadge(status: string): React.CSSProperties {
  let kind: 'warning' | 'success' | 'neutral' = 'neutral'
  if (status === 'open') kind = 'warning'
  else if (status === 'answered') kind = 'success'
  else if (status === 'closed') kind = 'neutral'
  return badgeStyle(kind)
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: colors.bgCard,
  padding: `${spacing.xxl}px ${spacing.xl}px`,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const wrapStyle: React.CSSProperties = {
  width: '100%',
  display: 'flex',
  gap: spacing.xl,
}
const titleStyle: React.CSSProperties = {
  fontSize: fontSize.xxl,
  fontWeight: 800,
  marginBottom: spacing.sm,
  color: colors.textPrimary,
}
const subStyle: React.CSSProperties = {
  color: colors.textSecondary,
  fontSize: fontSize.md,
  marginBottom: 22,
  lineHeight: 1.9,
}
const cardStyle: React.CSSProperties = {
  ...sharedCardStyle,
  padding: 20,
  marginBottom: 0,
}
const labelStyle: React.CSSProperties = {
  ...sharedLabelStyle,
}
const inputStyle: React.CSSProperties = {
  ...sharedInputStyle,
}
const submitBtnStyle: React.CSSProperties = {
  ...btnPrimaryStyle,
  fontSize: fontSize.sm,
  fontWeight: 700,
}
const infoBannerStyle: React.CSSProperties = {
  background: colors.infoBg,
  color: colors.infoText,
  borderRadius: radius.md,
  padding: '10px 14px',
  fontSize: fontSize.sm,
  marginBottom: spacing.lg,
}
const emptyStyle: React.CSSProperties = {
  ...emptyStateStyle,
  padding: 32,
}
const rfqCardStyle: React.CSSProperties = {
  ...sharedCardStyle,
  padding: 16,
  marginBottom: 0,
}
const listContainerStyle: React.CSSProperties = {
  ...sharedCardStyle,
  padding: 16,
}
const perPageBtnStyle: React.CSSProperties = {
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.md,
  background: colors.bgCard,
  color: colors.textSecondary,
  fontSize: fontSize.xs,
  fontWeight: 600,
  padding: '4px 12px',
  cursor: 'pointer',
}
const expertResponseStyle: React.CSSProperties = {
  background: colors.successBg,
  color: colors.successText,
  borderRadius: radius.md,
  padding: '10px 12px',
  fontSize: fontSize.sm,
  marginTop: 8,
}
