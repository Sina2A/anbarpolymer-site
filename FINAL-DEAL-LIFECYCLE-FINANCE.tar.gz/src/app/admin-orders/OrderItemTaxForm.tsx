'use client'

import { useActionState } from 'react'
import type { CSSProperties } from 'react'
import { btnPrimaryStyle, inputStyle } from '@/lib/styles/shared'
import { colors, fontSize, radius, spacing } from '@/lib/styles/tokens'
import { setOrderItemTax } from './actions'

interface OrderItemTaxFormProps {
  orderItemId: string
  /**
   * کلید یک‌بارمصرف فرم (idempotency). روی سرور ساخته می‌شه و در یک input مخفی می‌آد؛ صفحه هم از همین
   * مقدار به‌عنوان key استفاده می‌کنه تا بعد از هر رندر تازه، فرم با state تمیز و مالیاتِ به‌روز بالا بیاد.
   */
  formKey: string
  /** مالیات فعلیِ قلم، همان چیزی که کارشناس می‌بینه. خالی = واردنشده (۰). */
  initial: string
  /** توصیف قلم برای aria-label (گرید و انبار). */
  heading: string
}

/**
 * فرم ثبتِ مستقلِ مالیاتِ «یک قلم» بعد از قیمت‌گذاری (A2). هر قلم فرمِ جدا داره، پس ذخیره‌ی یکی روی بقیه اثر
 * نداره. خطای ورودی/گارد همین‌جا نشون داده می‌شه و متن تایپ‌شده می‌مونه (React بعد از هر اکشن فیلدهای
 * کنترل‌نشده را به defaultValue برمی‌گردونه). ورودی type="text"ـه تا ارقام فارسی هم برسن؛ مرز اعتبارسنجی خود
 * اکشنه. placeholder فقط یه نمونه‌ی ثابته، نه مقدارِ محاسبه‌شده — هیچ نرخ خودکاری وجود نداره. خالی = بدون مالیات (۰).
 */
export default function OrderItemTaxForm({ orderItemId, formKey, initial, heading }: OrderItemTaxFormProps) {
  const [state, formAction, pending] = useActionState(setOrderItemTax, null)

  return (
    <form action={formAction} style={formStyle}>
      <input type="hidden" name="orderItemId" value={orderItemId} />
      <input type="hidden" name="formKey" value={formKey} />
      <input
        name="taxAmount"
        type="text"
        inputMode="decimal"
        dir="ltr"
        autoComplete="off"
        placeholder="0"
        aria-label={`مالیات ${heading}`}
        defaultValue={state?.values?.taxAmount ?? initial}
        style={{ ...inputStyle, width: 130 }}
      />
      <button type="submit" disabled={pending} style={{ ...btnPrimaryStyle, opacity: pending ? 0.65 : undefined }}>
        {pending ? 'در حال ذخیره…' : 'ذخیره مالیات'}
      </button>
      {state?.error && (
        <div role="alert" aria-live="polite" style={errorStyle}>
          {state.error}
        </div>
      )}
    </form>
  )
}

const formStyle: CSSProperties = {
  display: 'flex',
  flexWrap: 'wrap',
  gap: spacing.sm,
  alignItems: 'center',
}
const errorStyle: CSSProperties = {
  width: '100%',
  background: colors.dangerBg,
  color: colors.dangerText,
  borderRadius: radius.md,
  padding: '9px 12px',
  fontSize: fontSize.sm,
}
