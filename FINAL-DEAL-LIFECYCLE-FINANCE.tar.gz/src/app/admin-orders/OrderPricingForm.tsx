'use client'

import { useActionState } from 'react'
import type { CSSProperties, ReactNode } from 'react'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'
import { badgeStyle, tableStyle, theadRowStyle, thStyle, tdStyle } from '@/lib/styles/shared'
import { colors } from '@/lib/styles/tokens'
import { setOrderPricing } from './actions'

interface OrderPricingItem {
  id: string
  gradeCode: string
  warehouseName: string | null
  /** تن */
  quantity: number
  /** قیمت مرجع — تومان بر کیلوگرم */
  price: number
  /** آیا قیمت مرجع هنوز معتبره */
  valid: boolean
}

interface OrderPricingFormProps {
  orderId: string
  /**
   * کلید یک‌بارمصرف فرم (idempotency). روی سرور ساخته می‌شه و در یک input مخفی می‌آد، چون سایت روی HTTP
   * ساده‌ست و crypto.randomUUID مرورگر در دسترس نیست.
   */
  formKey: string
  canEdit: boolean
  items: OrderPricingItem[]
  /** سرآیند کارت (شناسه‌ی سفارش، شرکت، تاریخ) — سمت سرور رندر می‌شه. */
  children: ReactNode
}

/**
 * فرم قیمت‌گذاری یک سفارش در انتظار. خطای ورودی بدون رفتن به صفحه‌ی خطا همین‌جا نشون داده می‌شه و مقدارهای
 * تایپ‌شده می‌مونن (React بعد از هر اکشن فیلدهای کنترل‌نشده را به defaultValue برمی‌گردونه).
 * ورودی‌ها type="text"ـن تا ارقام فارسی هم برسن؛ مرز اعتبارسنجی خود اکشنه (lib/money → parseTomanInput).
 * هر قلم دو ورودی داره: قیمت نهایی (`finalPrice-<id>`) و مالیات دستی (`tax-<id>`)؛ کلید state.values
 * «نام کاملِ ورودی»ـه، نه شناسه‌ی قلم.
 */
export default function OrderPricingForm({ orderId, formKey, canEdit, items, children }: OrderPricingFormProps) {
  const [state, formAction] = useActionState(setOrderPricing, null)

  return (
    <form action={canEdit ? formAction : undefined} style={pendingCardStyle}>
      <input type="hidden" name="orderId" value={orderId} />
      <input type="hidden" name="formKey" value={formKey} />
      {children}

      <table style={tableStyle}>
        <thead>
          <tr style={theadRowStyle}>
            <th style={thStyle}>گرید</th>
            <th style={thStyle}>انبار</th>
            <th style={thStyle}>مقدار</th>
            <th style={thStyle}>قیمت مرجع</th>
            <th style={thStyle}>وضعیت اعتبار</th>
            <th style={thStyle}>قیمت نهایی</th>
            <th style={thStyle}>مالیات (دستی)</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => (
            <tr key={item.id} style={{ borderBottom: '1px solid #f1efe8' }}>
              <td style={tdStyle}><b style={{ fontFamily: 'monospace' }}>{item.gradeCode}</b></td>
              <td style={tdStyle}>{item.warehouseName}</td>
              <td style={tdStyle}>{item.quantity} تن</td>
              <td style={{ ...tdStyle, fontFamily: 'monospace' }}>{item.price.toLocaleString('en-US')}</td>
              <td style={tdStyle}>
                <span style={item.valid ? badgeStyle('success') : badgeStyle('danger')}>{item.valid ? 'معتبر' : 'منقضی — بررسی کن'}</span>
              </td>
              <td style={tdStyle}>
                {canEdit ? (
                  <input
                    name={`finalPrice-${item.id}`}
                    type="text"
                    inputMode="decimal"
                    dir="ltr"
                    autoComplete="off"
                    aria-label={`قیمت نهایی ${item.gradeCode}`}
                    defaultValue={state?.values?.[`finalPrice-${item.id}`] ?? String(Math.round(item.price))}
                    style={priceInputStyle}
                  />
                ) : (
                  '—'
                )}
              </td>
              <td style={tdStyle}>
                {canEdit ? (
                  // مالیات دستیِ کلِ همین قلم (تومان، نه بر کیلو). placeholder فقط یه نمونه‌ی ثابته، نه مقدار
                  // محاسبه‌شده — هیچ نرخ خودکاری وجود نداره. خالی = بدون مالیات (۰).
                  <input
                    name={`tax-${item.id}`}
                    type="text"
                    inputMode="decimal"
                    dir="ltr"
                    autoComplete="off"
                    placeholder="0"
                    aria-label={`مالیات ${item.gradeCode}`}
                    defaultValue={state?.values?.[`tax-${item.id}`] ?? ''}
                    style={priceInputStyle}
                  />
                ) : (
                  '—'
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {canEdit && (
        <>
          <p style={hintStyle}>قیمت‌ها تومان بر کیلوگرم‌ان (عدد صحیح؛ ارقام فارسی و جداکننده‌ی هزارگان مجازه). ورودی خالی = قیمت مرجع.</p>
          <p style={hintStyle}>
            مالیات هر ردیف رو خودت وارد کن (تومان، عدد صحیح؛ ارقام فارسی و جداکننده‌ی هزارگان مجازه). ورودی خالی = بدون مالیات (۰).
          </p>
        </>
      )}

      {state?.error && (
        <div role="alert" aria-live="polite" style={errorStyle}>
          {state.error}
        </div>
      )}

      {canEdit ? (
        <div style={{ display: 'flex', gap: 10 }}>
          <ConfirmSubmitButton
            message="قیمت‌های ثبت‌شده برای مشتری ارسال بشه؟"
            style={{ background: '#1e357b', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 18px', fontSize: 13, fontWeight: 700, cursor: 'pointer' }}
          >
            ثبت قیمت‌ها و ارسال به مشتری
          </ConfirmSubmitButton>
        </div>
      ) : (
        <span style={{ fontSize: 11.5, color: '#9199a3' }}>فقط مشاهده</span>
      )}
    </form>
  )
}

const pendingCardStyle: CSSProperties = { border: '1.5px solid #f6621b', borderRadius: 12, padding: 18, marginBottom: 10, background: '#fff', boxShadow: '0 1px 4px rgba(27,30,36,.05)' }
const priceInputStyle: CSSProperties = { width: 110, border: '1px solid #d8dde3', borderRadius: 6, padding: '6px 8px', fontSize: 12, fontFamily: 'monospace' }
const hintStyle: CSSProperties = { margin: '10px 0 12px', color: '#6f7680', fontSize: 11.5 }
const errorStyle: CSSProperties = { background: colors.dangerBg, color: colors.dangerText, borderRadius: 8, padding: '9px 12px', marginBottom: 12, fontSize: 13 }
