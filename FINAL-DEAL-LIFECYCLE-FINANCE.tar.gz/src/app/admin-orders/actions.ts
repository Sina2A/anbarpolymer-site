'use server'

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import { AccessDeniedError } from '@/lib/errorCodes'
import { logStatusEvent } from '@/lib/statusEvents'
import { logAudit, logFinancialDrift } from '@/lib/logger'
import { startProformaDeadline } from '@/lib/dealDeadlines'
import { issueInvoiceForOrder } from '@/lib/invoices'
import { evaluateApprovalRequirement } from '@/lib/priceEngine'
import { MoneyCalcError, formatToman, parseTomanInput, roundToman, summarizeOrderItems } from '@/lib/money'
import type { DocumentSummary } from '@/lib/money'
import type { Prisma } from '@prisma/client'
import { FinancialDriftError, appendFinancialRecord, newFormKey } from '@/lib/financialHistory'
import { revalidatePath } from 'next/cache'

/**
 * گیت‌های دسترسی — اکشن‌های سرور endpoint عمومی‌ان، پس چک باید داخل خود اکشن باشه
 * (پنهان‌بودن فرم/دکمه توی UI مرز امنیتی نیست). private و export‌نشده، تا اکشن عمومی نشن.
 * الگوی requireLogisticsEditAccess: مدیر همیشه مجازه؛ کارشناس فقط با «ویرایش» یا «کامل».
 */
async function requireOrdersEditAccess() {
  const user = await getCurrentUser()
  if (user.role === 'admin') return user
  const access = await getAllSectionAccess(user.id)
  if (access.orders !== 'edit' && access.orders !== 'full') {
    throw new AccessDeniedError(
      'A-SECTION-ORDERS',
      'دسترسی ویرایش بخش سفارش‌ها رو نداری — از مدیر بخواه بهت بده.'
    )
  }
  return user
}

async function requirePaymentsEditAccess() {
  const user = await getCurrentUser()
  if (user.role === 'admin') return user
  const access = await getAllSectionAccess(user.id)
  if (access.payments !== 'edit' && access.payments !== 'full') {
    throw new AccessDeniedError(
      'A-SECTION-PAYMENTS',
      'دسترسی ویرایش بخش تایید فیش‌های پرداخت رو نداری — از مدیر بخواه بهت بده.'
    )
  }
  return user
}

/**
 * فقط فیشِ آپلودشده و در انتظار بررسی قابل‌تایید/رده — همون شرطی که صف‌های /admin-orders
 * و /admin-payments برای نمایش دارن. بدون این چک، POST مستقیم می‌تونست روی سفارشِ بدون فیش
 * وضعیت paid بزنه یا فیشِ قبلاً تاییدشده رو پاک کنه.
 */
function assertReceiptPending(
  order: { paymentReceiptStatus: string | null; paymentReceiptUrl: string | null } | null
) {
  if (!order) throw new Error('سفارش پیدا نشد.')
  if (order.paymentReceiptStatus !== 'pending' || !order.paymentReceiptUrl) {
    throw new Error('فقط فیش‌های آپلودشده‌ی در انتظار بررسی قابل‌تایید یا ردن.')
  }
}

/**
 * وضعیت فرم قیمت‌گذاری (useActionState). خطای ورودی «مقدار برگشتی»ه، نه exception — توی production
 * پیام exception به کلاینت نمی‌رسه و کارشناس فقط یه صفحه‌ی خطای کلی می‌دید.
 */
export type OrderPricingState = {
  error: string | null
  /**
   * ورودی‌های تایپ‌شده با کلید «نام کاملِ ورودی» (`finalPrice-<id>` و `tax-<id>`)، نه فقط شناسه‌ی قلم:
   * هر قلم دو ورودی داره (قیمت و مالیات). React بعد از هر اکشن فرم را reset می‌کنه؛ بدون این،
   * با یک مقدارِ نامعتبر بقیه‌ی مقدارهای درستی که کارشناس زده بود هم پاک می‌شدن.
   */
  values?: Record<string, string>
} | null

/**
 * کارشناس فروش قیمت نهایی هر قلم رو ثبت می‌کنه — این قیمت جدا از price
 * (که فقط snapshot مرجعه) ذخیره می‌شه، تا سفارش وارد مرحله‌ی «priced» بشه
 * و مشتری بتونه توی /my-orders تاییدش کنه.
 *
 * مالیات «دستیِ per-ردیف»ه (OrderItem.taxAmount): کارشناس برای هر قلم مبلغ مالیاتِ کل همون قلم رو
 * به تومانِ صحیح تایپ می‌کنه؛ ورودی خالی = بدون مالیات (۰). هیچ‌جا نرخ خودکاری اعمال نمی‌شه.
 *
 * ترتیب: ۱) همه‌ی قیمت‌ها و مالیات‌ها قبل از هر نوشتن parse می‌شن (یک مقدار نامعتبر = هیچ قلمی ذخیره
 * نمی‌شه) ۲) مبلغ سفارش با موتور lib/money حساب می‌شه ۳) قیمت و مالیات هر قلم و رکورد تاریخچه‌شون در
 * یک تراکنش نوشته می‌شن ۴) وضعیت سفارش عوض می‌شه. formKey کلید یک‌بارمصرفِ فرمه (روی سرور ساخته می‌شه).
 */
export async function setOrderPricing(
  _prevState: OrderPricingState,
  formData: FormData,
): Promise<OrderPricingState> {
  const user = await requireOrdersEditAccess()
  const orderId = String(formData.get('orderId'))
  const formKey = String(formData.get('formKey') ?? '')
  if (!formKey) throw new Error('کلید فرم نامعتبره — صفحه رو دوباره باز کن.')

  const order = await prisma.order.findUnique({
    where: { id: orderId },
    include: { items: { include: { grade: { select: { code: true } }, warehouse: { select: { name: true } } } } },
  })
  if (!order) throw new Error('سفارش پیدا نشد.')
  // فقط سفارشِ در انتظار قیمت‌گذاری — بدون این شرط، POST مستقیم می‌تونست قیمتِ سفارش‌های
  // priced/paid/... رو دوباره بنویسه و مهلت پیش‌فاکتور رو از نو راه بندازه.
  if (order.status !== 'pending') throw new Error('فقط سفارش‌های در انتظار قیمت‌گذاری رو می‌شه قیمت‌گذاری کرد.')

  // ۱) parse همه‌ی قیمت‌ها (تومان بر کیلوگرمِ صحیح) و مالیات‌ها (تومانِ صحیحِ «کلِ قلم»، نه بر کیلو).
  // قیمتِ خالی = قیمت مرجع (گردشده به تومان)؛ ورودی ناخوانا خطاست، نه جایگزینی بی‌صدا با قیمت مرجع
  // (رفتار قبلی: parseFloat(... || item.price)). مالیاتِ خالی = null = «واردنشده» = ۰؛ «۰» صریح هم
  // مجازه، ولی منفی/اعشاری/بیش از سقف خطای فارسیه.
  // ۲) مبلغ سفارش (C2): جمع خالص و مالیات با موتور lib/money — ضرب در ۱۰۰۰ کیلو/تن همان‌جا انجام می‌شه.
  //
  // متن تایپ‌شده‌ی «همه‌ی» ورودی‌ها قبل از parse برداشته می‌شه تا خطا روی یک قلم، مقدار قلم‌های بعدی رو هم
  // از فرم پاک نکنه (کلید = نام کاملِ ورودی، چون هر قلم دو ورودی داره).
  const values: Record<string, string> = {}
  for (const item of order.items) {
    for (const name of [`finalPrice-${item.id}`, `tax-${item.id}`]) {
      const raw = formData.get(name)
      values[name] = typeof raw === 'string' ? raw : ''
    }
  }
  const prices: number[] = []
  const taxes: (number | null)[] = []
  let summary: DocumentSummary
  try {
    for (const item of order.items) {
      const where = `${item.grade.code}${item.warehouse ? ` (${item.warehouse.name})` : ''}`

      const parsedPrice = parseTomanInput(formData.get(`finalPrice-${item.id}`), {
        label: `قیمت نهایی ${where}`,
        optional: true,
      })
      if (!parsedPrice.ok) return { error: parsedPrice.error, values }
      prices.push(parsedPrice.value ?? roundToman(item.price))

      const parsedTax = parseTomanInput(formData.get(`tax-${item.id}`), {
        label: `مالیات ${where}`,
        optional: true,
        allowZero: true,
      })
      if (!parsedTax.ok) return { error: parsedTax.error, values }
      taxes.push(parsedTax.value)
    }
    summary = summarizeOrderItems(
      order.items.map((item, i) => ({
        price: item.price,
        finalPrice: prices[i],
        quantity: item.quantity,
        taxAmount: taxes[i],
      })),
    )
  } catch (error) {
    if (error instanceof MoneyCalcError) return { error: error.message, values }
    throw error
  }

  // آستانه‌ی تایید روی «جمع خالص» (تومان) سنجیده می‌شه، نه روی قیمت واحد و نه جمع با مالیات.
  const approvalLevel = await evaluateApprovalRequirement('Order', summary.itemsTotal)

  // ۳) قیمت و مالیات هر قلم + رکورد تاریخچه‌شون در یک تراکنش. appendFinancialRecord «قبل» از نوشتن ستون صدا
  // زده می‌شه؛ نتیجه‌ی duplicate (همین فرم قبلاً ثبت شده) یا unchanged (مقدار تازه همان مقدار فعلیه) یعنی
  // «همان فیلد» دست نمی‌خوره. ستونِ هر فیلد فقط از نتیجه‌ی «خودش» تصمیم می‌گیره: ممکنه قیمت عوض شده باشه و
  // مالیات نه (یا برعکس) — یک update مشترک با شرط واحد، فیلدِ بی‌رکورد رو هم می‌نوشت.
  try {
    await prisma.$transaction(
      async (tx) => {
        for (let i = 0; i < order.items.length; i++) {
          const item = order.items[i]
          const finalPrice = prices[i]
          const taxAmount = taxes[i]

          const priceResult = await appendFinancialRecord(tx, {
            entityType: 'OrderItem',
            entityId: item.id,
            fieldName: 'finalPrice',
            newValue: finalPrice,
            changedBy: user.id,
            formKey,
            readColumn: async () => {
              const row = await tx.orderItem.findUnique({ where: { id: item.id }, select: { finalPrice: true } })
              return row?.finalPrice ?? null
            },
          })
          // همان formKey برای مالیات هم درسته: کلید idempotency شامل fieldName هست و با قیمت تداخل نمی‌کنه.
          const taxResult = await appendFinancialRecord(tx, {
            entityType: 'OrderItem',
            entityId: item.id,
            fieldName: 'taxAmount',
            newValue: taxAmount,
            changedBy: user.id,
            formKey,
            readColumn: async () => {
              const row = await tx.orderItem.findUnique({ where: { id: item.id }, select: { taxAmount: true } })
              return row?.taxAmount ?? null
            },
          })

          const data: { finalPrice?: number; taxAmount?: number | null } = {}
          if (priceResult.outcome === 'created') data.finalPrice = finalPrice
          if (taxResult.outcome === 'created') data.taxAmount = taxAmount
          if (Object.keys(data).length > 0) {
            await tx.orderItem.update({ where: { id: item.id }, data })
          }
        }
      },
      { timeout: 20000, maxWait: 5000 },
    )
  } catch (error) {
    if (error instanceof FinancialDriftError) {
      await logFinancialDrift(error, user.id, { orderId })
      return {
        error: 'ناهمخوانی در تاریخچه‌ی مالی این سفارش پیدا شد؛ ثبت قیمت متوقف شد. به مدیر سیستم اطلاع بده.',
        values,
      }
    }
    throw error
  }

  // ۴) تغییر وضعیت سفارش (همان رفتار قبلی؛ بیرون از تراکنشِ قیمت‌ها)
  if (approvalLevel) {
    // نیاز به تایید — وضعیت awaiting_approval
    await prisma.order.update({
      where: { id: orderId },
      data: { status: 'awaiting_approval' },
    })

    await logStatusEvent({
      recordType: 'Order',
      recordId: orderId,
      newStageKey: 'awaiting_approval',
      performedById: user.id,
      note: `مبلغ خالص ${formatToman(summary.itemsTotal, 'fa-IR')} تومان (بدون مالیات) نیاز به تایید ${approvalLevel} دارد`,
    })
  } else {
    // خودکار تایید — مسیر قبلی
    await startProformaDeadline(orderId)

    await logStatusEvent({
      recordType: 'Order',
      recordId: orderId,
      newStageKey: 'priced',
      performedById: user.id,
      note: 'قیمت نهایی توسط کارشناس فروش ثبت شد',
    })
  }

  revalidatePath('/admin-orders')
  return { error: null }
}

/**
 * وضعیت فرم مالیاتِ یک قلم (useActionState). مثل OrderPricingState خطای ورودی «مقدار برگشتی»ه، نه exception،
 * و متن تایپ‌شده (کلید: taxAmount) برمی‌گرده تا بعد از reset فرمِ React از دست نره.
 */
export type OrderItemTaxState = {
  error: string | null
  values?: Record<string, string>
} | null

/** سفارش‌هایی که مالیاتِ قلم‌هاشون هنوز قابل‌ویرایشه: قیمت‌گذاری‌شده، ولی قبل از تایید مشتری/فیش/فاکتور. */
const TAX_EDITABLE_STATUSES = ['priced', 'awaiting_approval']

/**
 * خطای نگهبانِ ویرایش مالیات. «داخل» تراکنش پرتاب می‌شه تا رکورد تاریخچه‌ی همون تراکنش هم برگرده،
 * و بیرونِ تراکنش به «مقدار برگشتی» (پیام فارسی برای فرم) تبدیل می‌شه.
 */
class TaxEditRejected extends Error {}

type TaxEditContext = {
  gradeCode: string
  warehouseName: string | null
  order: {
    id: string
    status: string
    paymentReceiptUrl: string | null
    invoice: { id: string } | null
    items: { id: string; price: number; finalPrice: number | null; quantity: number; taxAmount: number | null }[]
  }
}

/** قلم + سفارشش + همه‌ی قلم‌های سفارش (برای دوباره‌حساب‌کردن جمع‌ها) — هم با prisma هم با tx قابل‌استفاده‌ست. */
async function loadTaxEditContext(
  db: Pick<Prisma.TransactionClient, 'orderItem'>,
  orderItemId: string,
): Promise<TaxEditContext | null> {
  const item = await db.orderItem.findUnique({
    where: { id: orderItemId },
    select: {
      grade: { select: { code: true } },
      warehouse: { select: { name: true } },
      order: {
        select: {
          id: true,
          status: true,
          paymentReceiptUrl: true,
          invoice: { select: { id: true } },
          items: { select: { id: true, price: true, finalPrice: true, quantity: true, taxAmount: true } },
        },
      },
    },
  })
  if (!item) return null
  return { gradeCode: item.grade.code, warehouseName: item.warehouse?.name ?? null, order: item.order }
}

/** null = ویرایش مجازه؛ وگرنه پیام فارسیِ دلیلِ بسته‌بودن. */
function taxEditBlockedReason(order: TaxEditContext['order']): string | null {
  if (!TAX_EDITABLE_STATUSES.includes(order.status)) {
    return 'مالیات فقط برای سفارشِ «قیمت‌گذاری‌شده» یا «در انتظار تایید مدیر» و قبل از تایید مشتری قابل‌ویرایشه. صفحه رو تازه کن.'
  }
  if (order.paymentReceiptUrl !== null) return 'برای این سفارش فیش پرداخت آپلود شده؛ مالیات دیگه قابل‌ویرایش نیست.'
  if (order.invoice) return 'برای این سفارش فاکتور صادر شده؛ مالیات دیگه قابل‌ویرایش نیست.'
  return null
}

/**
 * با مالیاتِ تازه‌ی این قلم، جمع‌های «کل سند» هم باید هنوز قابل‌محاسبه باشن (سقف مبلغ و ...). null = مشکلی نیست؛
 * وگرنه پیام فارسی. مالیاتی که جمع سند رو از کار بندازه (صفحه‌ها «—» نشون می‌دن و صدور فاکتور شکست می‌خوره) ذخیره نمی‌شه.
 */
function taxEditTotalsError(order: TaxEditContext['order'], orderItemId: string, taxAmount: number | null): string | null {
  try {
    summarizeOrderItems(order.items.map((it) => (it.id === orderItemId ? { ...it, taxAmount } : it)))
    return null
  } catch (error) {
    if (error instanceof MoneyCalcError) return error.message
    throw error
  }
}

/**
 * ویرایش مستقلِ مالیاتِ «یک قلم» بعد از قیمت‌گذاری (A2) — بدون ابطال پیش‌فاکتور و بدون دست‌زدن به قیمت.
 *
 * فقط وقتی مجازه که سفارش «priced» یا «awaiting_approval» باشه و هنوز فیشی آپلود نشده و فاکتوری صادر نشده؛
 * وگرنه مبلغی که مشتری دیده/پرداخت کرده یا روی سند رسمی ثبت شده زیر دستش عوض می‌شد. گارد سه‌بار اعمال می‌شه:
 * قبل از تراکنش (پیام روشن به کارشناس)، داخل تراکنش با داده‌ی تازه، و داخل WHEREِ خودِ نوشتنِ ستون (بررسی و
 * نوشتن یک دستور واحدن، پس بین‌شون پنجره‌ای نمی‌مونه).
 *
 * مالیات وضعیت سفارش، مهلت پیش‌فاکتور و آستانه‌ی تایید (روی جمع خالص) رو عوض نمی‌کنه. ورودی خالی = بدون مالیات.
 * formKey کلید یک‌بارمصرفِ فرمه (روی سرور ساخته می‌شه).
 */
export async function setOrderItemTax(
  _prevState: OrderItemTaxState,
  formData: FormData,
): Promise<OrderItemTaxState> {
  const user = await requireOrdersEditAccess()
  const orderItemId = String(formData.get('orderItemId') ?? '')
  const formKey = String(formData.get('formKey') ?? '')
  if (!orderItemId || !formKey) return { error: 'کلید فرم نامعتبره — صفحه رو دوباره باز کن.' }

  const raw = formData.get('taxAmount')
  const values = { taxAmount: typeof raw === 'string' ? raw : '' }

  const context = await loadTaxEditContext(prisma, orderItemId)
  if (!context) return { error: 'قلم سفارش پیدا نشد — صفحه رو تازه کن.', values }
  const blocked = taxEditBlockedReason(context.order)
  if (blocked) return { error: blocked, values }

  // parse قبل از هر نوشتن. خالی = null = «واردنشده» = ۰؛ «۰» صریح مجازه؛ منفی/اعشاری/بیش از سقف خطاست.
  const where = `${context.gradeCode}${context.warehouseName ? ` (${context.warehouseName})` : ''}`
  const parsed = parseTomanInput(raw, { label: `مالیات ${where}`, optional: true, allowZero: true })
  if (!parsed.ok) return { error: parsed.error, values }
  const taxAmount = parsed.value

  const totalsError = taxEditTotalsError(context.order, orderItemId, taxAmount)
  if (totalsError) return { error: totalsError, values }

  const orderId = context.order.id

  // رکورد تاریخچه «قبل» از نوشتن ستون و در همان تراکنش؛ duplicate (همین فرم قبلاً ثبت شده) یا unchanged
  // (مقدار تازه همان مقدار فعلیه) یعنی ستون دست نمی‌خوره و چیزی برای لاگ/ابطال کش نیست.
  let changed: boolean
  try {
    changed = await prisma.$transaction(
      async (tx) => {
        const fresh = await loadTaxEditContext(tx, orderItemId)
        if (!fresh) throw new TaxEditRejected('قلم سفارش پیدا نشد — صفحه رو تازه کن.')
        const freshBlocked = taxEditBlockedReason(fresh.order)
        if (freshBlocked) throw new TaxEditRejected(freshBlocked)
        const freshTotalsError = taxEditTotalsError(fresh.order, orderItemId, taxAmount)
        if (freshTotalsError) throw new TaxEditRejected(freshTotalsError)

        const record = await appendFinancialRecord(tx, {
          entityType: 'OrderItem',
          entityId: orderItemId,
          fieldName: 'taxAmount',
          newValue: taxAmount,
          changedBy: user.id,
          formKey,
          readColumn: async () => {
            const row = await tx.orderItem.findUnique({ where: { id: orderItemId }, select: { taxAmount: true } })
            return row?.taxAmount ?? null
          },
        })
        if (record.outcome !== 'created') return false

        // شرط گارد توی خودِ WHERE هم تکرار شده؛ count ≠ ۱ یعنی همین الان وضعیت/فیش/فاکتور عوض شده و
        // پرتاب‌کردن رکورد تاریخچه‌ی همین تراکنش رو هم برمی‌گردونه.
        const { count } = await tx.orderItem.updateMany({
          where: {
            id: orderItemId,
            order: { status: { in: TAX_EDITABLE_STATUSES }, paymentReceiptUrl: null, invoice: { is: null } },
          },
          data: { taxAmount },
        })
        if (count !== 1) {
          throw new TaxEditRejected('وضعیت سفارش همین الان عوض شد و مالیات دیگه قابل‌ویرایش نیست. صفحه رو تازه کن.')
        }
        return true
      },
      { timeout: 20000, maxWait: 5000 },
    )
  } catch (error) {
    if (error instanceof TaxEditRejected) return { error: error.message, values }
    if (error instanceof FinancialDriftError) {
      await logFinancialDrift(error, user.id, { orderId, orderItemId })
      return {
        error: 'ناهمخوانی در تاریخچه‌ی مالی این قلم پیدا شد؛ ثبت مالیات متوقف شد. به مدیر سیستم اطلاع بده.',
        values,
      }
    }
    throw error
  }

  if (changed) {
    await logAudit('order', `ویرایش مالیات قلم سفارش ${orderId.slice(0, 8)}`, user.id, {
      orderId,
      orderItemId,
      action: 'item_tax_updated',
      taxAmount,
    })

    revalidatePath('/admin-orders')
    revalidatePath('/proformas')
    revalidatePath('/my-orders')
    revalidatePath('/admin-payments')
    revalidatePath('/proformas/[id]', 'page')
  }
  return { error: null }
}

/**
 * رد سفارش — موجودی قفل‌شده باید برگرده به انبار، وگرنه برای همیشه
 * از دسترس خارج می‌مونه بدون این‌که واقعاً فروخته شده باشه.
 */
export async function rejectOrder(formData: FormData) {
  const user = await requireOrdersEditAccess()
  const orderId = String(formData.get('orderId'))

  const order = await prisma.order.findUnique({ where: { id: orderId }, include: { items: true } })
  if (!order) throw new Error('سفارش پیدا نشد.')
  if (order.status !== 'pending') throw new Error('فقط سفارش‌های در انتظار قیمت‌گذاری قابل‌رد کردنن.')

  const itemsWithWarehouse = order.items.filter((item) => item.warehouseId)

  await prisma.$transaction([
    ...itemsWithWarehouse.map((item) =>
      prisma.warehouseStock.updateMany({
        where: { warehouseId: item.warehouseId as string, gradeId: item.gradeId },
        data: { quantityTon: { increment: item.quantity } },
      })
    ),
    prisma.order.update({ where: { id: orderId }, data: { status: 'rejected' } }),
  ])

  await logStatusEvent({
    recordType: 'Order',
    recordId: orderId,
    newStageKey: 'rejected',
    performedById: user.id,
    note: 'سفارش توسط کارشناس رد شد — موجودی به انبار برگشت',
  })

  revalidatePath('/admin-orders')
}

/**
 * ابطال پیش‌فاکتور توسط کارشناس/ادمین — فارغ از مهلت.
 * موجودی قفل‌شده‌ی هر قلم به انبار برمی‌گرده (الگوی واحد rejectOrder/enforceProformaDeadlines).
 */
export async function cancelProformaAction(orderId: string) {
  const user = await requireOrdersEditAccess()

  const order = await prisma.order.findUnique({ where: { id: orderId }, include: { items: true } })
  if (!order) throw new Error('سفارش پیدا نشد.')
  if (!['priced', 'buyer_confirmed'].includes(order.status)) {
    throw new Error('فقط سفارش‌های در مرحله‌ی پیش‌فاکتور قابل ابطالن.')
  }

  const itemsWithWarehouse = order.items.filter((item) => item.warehouseId)

  await prisma.$transaction([
    ...itemsWithWarehouse.map((item) =>
      prisma.warehouseStock.updateMany({
        where: { warehouseId: item.warehouseId as string, gradeId: item.gradeId },
        data: { quantityTon: { increment: item.quantity } },
      })
    ),
    prisma.order.update({ where: { id: orderId }, data: { status: 'rejected' } }),
  ])

  await logStatusEvent({
    recordType: 'Order',
    recordId: orderId,
    newStageKey: 'rejected',
    performedById: user.id,
    note: 'پیش‌فاکتور توسط کارشناس/ادمین ابطال شد — موجودی به انبار برگشت',
  })

  revalidatePath('/admin-orders')
  revalidatePath('/proformas')
}

/**
 * تایید فیش پرداخت — وضعیت رسید از pending به approved تغییر می‌کنه و بلافاصله
 * فاکتور رسمی سفارش صادر می‌شه (شماره‌گذاری یکتا در lib/invoices).
 */
export async function approvePaymentReceiptAction(orderId: string) {
  const user = await requirePaymentsEditAccess()

  // تصمیم تکه ۱: تایید فیش = مسیر contracted → paid (همون اکشن، نه اکشن جدا)
  // paymentReceiptStatus جدا میمونه؛ Order.status هم همزمان به paid میره.
  const orderBefore = await prisma.order.findUnique({
    where: { id: orderId },
    select: { status: true, paymentReceiptStatus: true, paymentReceiptUrl: true },
  })
  assertReceiptPending(orderBefore)

  // وضعیت فیش + رکورد تاریخچه‌اش در یک تراکنش. وضعیت فیش چرخه‌ایه (pending → rejected → pending …)، پس
  // کلید ثابتِ «transition:<old>» در دور دوم تصادم می‌کرد؛ formKey تصادفیه و جلوی تاییدِ دوباره را شرطِ
  // paymentReceiptStatus = 'pending' توی updateMany می‌گیره (count باید ۱ باشه، وگرنه تراکنش برمی‌گرده).
  const alreadyReviewed = 'این فیش قبلاً بررسی شده — صفحه رو تازه کن.'
  try {
    await prisma.$transaction(async (tx) => {
      const record = await appendFinancialRecord(tx, {
        entityType: 'Order',
        entityId: orderId,
        fieldName: 'paymentReceiptStatus',
        newValue: 'approved',
        changedBy: user.id,
        formKey: newFormKey(),
        readColumn: async () => {
          const row = await tx.order.findUnique({ where: { id: orderId }, select: { paymentReceiptStatus: true } })
          return row?.paymentReceiptStatus ?? null
        },
      })
      if (record.outcome !== 'created') throw new Error(alreadyReviewed)

      const { count } = await tx.order.updateMany({
        where: { id: orderId, paymentReceiptStatus: 'pending' },
        data: {
          paymentReceiptStatus: 'approved',
          paymentReceiptReviewedById: user.id,
          paymentReceiptReviewedAt: new Date(),
          ...(orderBefore?.status === 'contracted' ? { status: 'paid' as const } : {}),
        },
      })
      if (count !== 1) throw new Error(alreadyReviewed)
    })
  } catch (error) {
    if (error instanceof FinancialDriftError) await logFinancialDrift(error, user.id, { orderId })
    throw error
  }

  // اگر سفارش در contracted بود، یک ستون Order.status هم به paid رفت
  if (orderBefore?.status === 'contracted') {
    await logStatusEvent({
      recordType: 'Order',
      recordId: orderId,
      newStageKey: 'paid',
      performedById: user.id,
      note: 'پرداخت تایید شد — سفارش وارد مرحله پرداخت شده شد (contracted → paid)',
    })
  }

  await logStatusEvent({
    recordType: 'Order',
    recordId: orderId,
    newStageKey: 'receipt_approved',
    performedById: user.id,
    note: 'فیش پرداخت توسط کارشناس مالی تایید شد',
  })

  await logAudit('payment', `تایید فیش پرداخت سفارش ${orderId.slice(0, 8)}`, user.id, { orderId, action: 'receipt_approved' })

  // صدور فاکتور عمداً بعد از ثبت تایید و توی try جدا اجرا می‌شه: اگه صدور
  // شکست بخوره، خودِ تایید فیش نباید برگرده — فقط لاگ می‌شه تا کارشناس مالی
  // ببینه و دوباره تلاش کنه (تایید دوباره همون فاکتور قبلی رو برمی‌گردونه،
  // چون issueInvoiceForOrder بر اساس orderId idempotent هست).
  try {
    const invoice = await issueInvoiceForOrder(orderId, user.id)
    await logAudit('invoice', `صدور فاکتور ${invoice.number} برای سفارش ${orderId.slice(0, 8)}`, user.id, {
      orderId,
      invoiceId: invoice.id,
      number: invoice.number,
      totalAmount: invoice.totalAmount,
    })
  } catch (e) {
    await logAudit('invoice', `صدور فاکتور برای سفارش ${orderId.slice(0, 8)} ناموفق بود`, user.id, {
      orderId,
      action: 'issue_failed',
      error: String(e),
    })
  }

  revalidatePath('/admin-orders')
  revalidatePath('/proformas')
}

/**
 * رد فیش پرداخت — خریدار باید رسید جدید آپلود کنه.
 */
export async function rejectPaymentReceiptAction(orderId: string) {
  const user = await requirePaymentsEditAccess()

  assertReceiptPending(
    await prisma.order.findUnique({
      where: { id: orderId },
      select: { paymentReceiptStatus: true, paymentReceiptUrl: true },
    })
  )

  // دو فیلد مالی هم‌زمان عوض می‌شن: وضعیت فیش و آدرس رسید (رسید قبلی باطل می‌شه). هر دو رکوردشون و
  // نوشتن ستون‌ها در یک تراکنشه؛ منطقِ formKey و شرطِ updateMany مثل approvePaymentReceiptAction.
  const alreadyReviewed = 'این فیش قبلاً بررسی شده — صفحه رو تازه کن.'
  try {
    await prisma.$transaction(async (tx) => {
      const formKey = newFormKey()
      const readReceipt = () =>
        tx.order.findUnique({
          where: { id: orderId },
          select: { paymentReceiptStatus: true, paymentReceiptUrl: true },
        })

      const statusRecord = await appendFinancialRecord(tx, {
        entityType: 'Order',
        entityId: orderId,
        fieldName: 'paymentReceiptStatus',
        newValue: 'rejected',
        changedBy: user.id,
        formKey,
        readColumn: async () => (await readReceipt())?.paymentReceiptStatus ?? null,
      })
      const urlRecord = await appendFinancialRecord(tx, {
        entityType: 'Order',
        entityId: orderId,
        fieldName: 'paymentReceiptUrl',
        newValue: null,
        changedBy: user.id,
        formKey,
        readColumn: async () => (await readReceipt())?.paymentReceiptUrl ?? null,
      })
      if (statusRecord.outcome !== 'created' || urlRecord.outcome !== 'created') throw new Error(alreadyReviewed)

      const { count } = await tx.order.updateMany({
        where: { id: orderId, paymentReceiptStatus: 'pending' },
        data: {
          paymentReceiptStatus: 'rejected',
          paymentReceiptReviewedById: user.id,
          paymentReceiptReviewedAt: new Date(),
          // رسید قبلی باطل می‌شه تا خریدار رسید جدید آپلود کنه
          paymentReceiptUrl: null,
          paymentReceiptUploadedAt: null,
        },
      })
      if (count !== 1) throw new Error(alreadyReviewed)
    })
  } catch (error) {
    if (error instanceof FinancialDriftError) await logFinancialDrift(error, user.id, { orderId })
    throw error
  }

  await logStatusEvent({
    recordType: 'Order',
    recordId: orderId,
    newStageKey: 'receipt_rejected',
    performedById: user.id,
    note: 'فیش پرداخت توسط کارشناس مالی رد شد — خریدار باید رسید جدید ارسال کنه',
  })

  await logAudit('payment', `رد فیش پرداخت سفارش ${orderId.slice(0, 8)}`, user.id, { orderId, action: 'receipt_rejected' })

  revalidatePath('/admin-orders')
  revalidatePath('/proformas')
}

/**
 * تایید سفارش توسط مدیر — بعد از این، مهلت پیش‌فاکتور شروع می‌شه.
 * گذار awaiting_approval → priced با updateMany شرطی «برنده‌ساز» است (مثل approveDealAction): فقط تاییدکننده‌ای که
 * count=1 بگیره مهلت پیش‌فاکتور رو شروع می‌کنه و رویداد وضعیت می‌نویسه؛ تایید هم‌زمانِ دوم خطای هم‌زمانی می‌گیره.
 */
export async function approveOrderAction(orderId: string) {
  const user = await getCurrentUser()
  if (user.role !== 'admin') throw new Error('فقط مدیر می‌تونه سفارش رو تایید کنه.')

  const order = await prisma.order.findUnique({ where: { id: orderId } })
  if (!order) throw new Error('سفارش پیدا نشد.')
  if (order.status !== 'awaiting_approval') throw new Error('فقط سفارش‌های در انتظار تایید قابل تصویبن.')

  const claimed = await prisma.order.updateMany({
    where: { id: orderId, status: 'awaiting_approval' },
    data: { status: 'priced' },
  })
  if (claimed.count !== 1) throw new Error('سفارش هم‌زمان تغییر کرد؛ صفحه رو دوباره باز کن و دوباره امتحان کن.')

  try {
    await startProformaDeadline(orderId)
  } catch (error) {
    // بین «priced» و ثبت مهلت، سفارش بدون مهلت می‌مونه و هیچ‌وقت منقضی نمی‌شه؛ پس به صف تایید برش می‌گردونیم
    // (فقط اگه هنوز همون حالتِ بدون مهلت باشه، تا تغییر هم‌زمانِ دیگری رو خراب نکنیم).
    await prisma.order.updateMany({
      where: { id: orderId, status: 'priced', proformaDeadline: null },
      data: { status: 'awaiting_approval' },
    })
    throw error
  }

  await logStatusEvent({
    recordType: 'Order',
    recordId: orderId,
    newStageKey: 'priced',
    performedById: user.id,
    note: 'سفارش توسط مدیر تایید شد',
  })

  await logAudit('order', `تایید سفارش ${orderId.slice(0, 8)} توسط مدیر`, user.id, { orderId })

  revalidatePath('/admin-orders')
  revalidatePath('/proformas')
}
