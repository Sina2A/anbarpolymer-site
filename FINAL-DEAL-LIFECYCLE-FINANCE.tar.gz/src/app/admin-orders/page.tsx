import Link from 'next/link'
import prisma from '@/lib/prisma'
import { getAllSectionAccess } from '@/lib/permissions'
import { getCurrentUser } from '@/lib/currentUser'
import type { AccessLevel } from '@/lib/sections'
import { isPriceStillValid } from '@/lib/pricing'
import { evaluateApprovalRequirement } from '@/lib/priceEngine'
import { tehranJalaliDisplay, tehranClockDisplay } from '@/lib/tehranClock'
import AdminNav, { PartialAccessBanner } from '@/components/AdminNav'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'
import RecordActionsMenu from '@/components/RecordActionsMenu'
import { rejectOrder, cancelProformaAction, approvePaymentReceiptAction, rejectPaymentReceiptAction, approveOrderAction } from './actions'
import OrderPricingForm from './OrderPricingForm'
import OrderItemTaxForm from './OrderItemTaxForm'
import { newFormKey } from '@/lib/financialHistory'
import { formatToman, trySummarizeOrderItems } from '@/lib/money'
import { pageStyle, pageWrapStyle, contentStyle, h1Style, subTitleStyle, cardStyle, orderStatusBadgeStyle, ORDER_STATUS_CONFIG, btnPrimaryStyle, btnSecondaryStyle, btnDangerStyle, btnSmallStyle, inputStyle, selectStyle, labelStyle, emptyStateStyle } from '@/lib/styles/shared'
import { getSurfaceHome } from '@/lib/surfaceHome'

export const dynamic = 'force-dynamic'

// وضعیت‌های «پیش‌فاکتور»: هم فیلتر لیست و هم شمارنده‌ی لینک «پیش‌فاکتورها» از همین یک فهرست می‌آن
const PROFORMA_STATUSES = ['priced', 'buyer_confirmed']

// سطح لازم‌ِ تایید (خروجی evaluateApprovalRequirement)؛ null = هیچ قانونی مطابق نیست
const APPROVAL_LEVEL_LABELS: Record<string, string> = { supervisor: 'سرپرست', manager: 'مدیر', admin: 'ادمین' }

const STATUS_LABELS: Record<string, string> = {
  pending: 'در انتظار قیمت‌گذاری',
  priced: 'قیمت ثبت شد — منتظر تایید مشتری',
  awaiting_approval: 'در انتظار تایید مدیر',
  buyer_confirmed: 'تایید شد توسط مشتری',
  ...Object.fromEntries(Object.entries(ORDER_STATUS_CONFIG).map(([k, v]) => [k, v.label])),
  rejected: 'رد شد',
}

function one(v: string | string[] | undefined): string | undefined {
  if (Array.isArray(v)) return v[0]
  return v
}

export default async function AdminOrdersPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>
}) {
  const sp = await searchParams
  const onlyProforma = one(sp.proforma) === '1'

  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)

  // «سفارش‌ها» (دیدن + قیمت‌گذاری/رد/ابطال) جدا از «تایید فیش‌های پرداخت» (تایید/رد فیش) —
  // هم‌راستا با گیت‌های سمت سرور توی actions.ts. UI فقط راحتیه؛ مرز امنیتی خود اکشن‌هان.
  const level: AccessLevel = isAdmin ? 'full' : ((myAccess?.orders as AccessLevel) ?? 'none')
  const hasAccess = level !== 'none'
  const canEdit = level === 'full' || level === 'edit'
  const paymentsLevel: AccessLevel = isAdmin ? 'full' : ((myAccess?.payments as AccessLevel) ?? 'none')
  const canReviewReceipts = paymentsLevel === 'full' || paymentsLevel === 'edit'

  // بی‌دسترسی یعنی هیچ داده‌ای لود نشه — کوئری سفارش‌ها بعد از این چک اجرا می‌شه
  if (!hasAccess) {
    return (
      <div style={pageStyle}>
        <div style={pageWrapStyle}>
          <AdminNav currentUserName={currentUser.companyName} currentUsername={currentUser.username} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="orders" homeHref={getSurfaceHome()} />

          <div style={contentStyle}>
            <h1 style={h1Style}>سفارش‌ها</h1>
            <div style={emptyStateStyle}>به بخش «سفارش‌ها» دسترسی نداری.</div>
          </div>
        </div>
      </div>
    )
  }

  // invoice: فقط برای دونستنِ «فاکتور صادر شده یا نه» (گارد ویرایش مالیات)، نه نمایش.
  // شمارنده‌های لینک‌های فیلتر مستقل از فیلتر فعلی‌ان: «همه» = همه‌ی سفارش‌ها، «پیش‌فاکتورها» = همون وضعیت‌های فیلتر.
  const [orders, totalCount, proformaCount] = await Promise.all([
    prisma.order.findMany({
      where: onlyProforma ? { status: { in: PROFORMA_STATUSES } } : undefined,
      include: { user: true, items: { include: { grade: true, warehouse: true } }, invoice: { select: { id: true } } },
      orderBy: { createdAt: 'desc' },
    }),
    prisma.order.count(),
    prisma.order.count({ where: { status: { in: PROFORMA_STATUSES } } }),
  ])

  const pendingOrders = orders.filter((o) => o.status === 'pending')
  const otherOrders = orders.filter((o) => o.status !== 'pending')

  // سفارش‌های در انتظار تایید: سطح لازم روی Order ذخیره نیست، پس همین‌جا و طبق قوانین فعلی از «جمع اقلام»
  // (خالص، بدون مالیات؛ همون مبنای setOrderPricing) محاسبه می‌شه. summary=null یعنی داده‌ی مبلغ خراب.
  const approvalInfo = new Map(
    await Promise.all(
      otherOrders
        .filter((o) => o.status === 'awaiting_approval')
        .map(async (o) => {
          const summary = trySummarizeOrderItems(o.items)
          const requiredLevel = summary ? await evaluateApprovalRequirement('Order', summary.itemsTotal) : null
          return [o.id, { summary, requiredLevel }] as const
        })
    )
  )

  return (
    <div style={pageStyle}>
      <div style={pageWrapStyle}>
        <AdminNav currentUserName={currentUser.companyName} currentUsername={currentUser.username} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="orders" homeHref={getSurfaceHome()} />

        <div style={contentStyle}>
          <h1 style={h1Style}>سفارش‌ها</h1>
          <p style={subTitleStyle}>سفارش‌های در انتظار قیمت‌گذاری بالای صفحه‌ن — بقیه پایین، به‌عنوان تاریخچه.</p>

          <PartialAccessBanner level={level} sectionLabel="سفارش‌ها" />

          {/* ================= بخش ۱: نیاز به اقدام فوری ================= */}
          <h2 style={sectionHeadStyle}>
            🔴 نیاز به قیمت‌گذاری
            <span style={countBadge}>{pendingOrders.length}</span>
          </h2>

          {pendingOrders.length === 0 && (
            <div style={emptyStateStyle}>هیچ سفارش در انتظاری نیست.</div>
          )}

          {pendingOrders.map((order) => (
            <OrderPricingForm
              key={order.id}
              orderId={order.id}
              formKey={newFormKey()}
              canEdit={canEdit}
              items={order.items.map((item) => ({
                id: item.id,
                gradeCode: item.grade.code,
                warehouseName: item.warehouse?.name ?? null,
                quantity: item.quantity,
                price: item.price,
                valid: isPriceStillValid(item.priceValidUntil),
              }))}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
                <div>
                  <b style={{ fontSize: 14.5 }}>سفارش #{order.id.slice(0, 8)}</b>
                  <span style={{ fontSize: 12, color: '#6f7680', marginRight: 10 }}>{order.user.companyName}</span>
                </div>
                <span style={{ fontSize: 11, color: '#9199a3' }}>{tehranJalaliDisplay(order.createdAt)}، ساعت {tehranClockDisplay(order.createdAt)}</span>
              </div>
            </OrderPricingForm>
          ))}

          {/* دکمه‌ی رد سفارش جدا، چون moment فرم دیگه‌ایه */}
          {canEdit && pendingOrders.map((order) => (
            <form key={`reject-${order.id}`} action={rejectOrder} style={{ marginTop: -10, marginBottom: 20 }}>
              <input type="hidden" name="orderId" value={order.id} />
              <ConfirmSubmitButton
                message={`⚠️ سفارش #${order.id.slice(0, 8)} رد بشه؟ موجودی قفل‌شده به انبار برمی‌گرده.`}
                style={{ background: 'transparent', color: '#dc2626', border: '1px solid #dc2626', borderRadius: 8, padding: '8px 16px', fontSize: 12, fontWeight: 700, cursor: 'pointer' }}
              >
                رد این سفارش
              </ConfirmSubmitButton>
            </form>
          ))}

          {/* ================= بخش ۲: تاریخچه ================= */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, alignItems: 'center', marginBottom: 12 }}>
            <Link
              href="/admin-orders"
              className={onlyProforma ? 'btn btn-sm btn-outline' : 'btn btn-sm'}
              aria-current={onlyProforma ? undefined : 'page'}
              style={{ whiteSpace: 'nowrap' }}
            >
              همه ({totalCount.toLocaleString('fa-IR')})
            </Link>
            <Link
              href="/admin-orders?proforma=1"
              className={onlyProforma ? 'btn btn-sm' : 'btn btn-sm btn-outline'}
              aria-current={onlyProforma ? 'page' : undefined}
              style={{ whiteSpace: 'nowrap' }}
            >
              پیش‌فاکتورها ({proformaCount.toLocaleString('fa-IR')})
            </Link>
          </div>

          <h2 style={{ ...sectionHeadStyle, marginTop: 36 }}>تاریخچه‌ی سفارش‌ها</h2>
          {otherOrders.length === 0 && <div style={emptyStateStyle}>هنوز سفارشی به این مرحله نرسیده.</div>}
          {otherOrders.map((order) => {
            const isProforma = order.status === 'priced' || order.status === 'buyer_confirmed'
            const receiptPending = !!order.paymentReceiptUrl && order.paymentReceiptStatus === 'pending'
            const shortId = order.id.slice(0, 8)

            // مالیات هر قلم تا قبل از تایید مشتری/فیش/فاکتور قابل‌ویرایشه (A2). همان شرطِ setOrderItemTax؛
            // UI فقط راحتیه و مرز امنیتی خود اکشنه. جمع‌ها با همون موتور lib/money (null = داده‌ی خراب → «—»).
            const taxEditable =
              canEdit &&
              (order.status === 'priced' || order.status === 'awaiting_approval') &&
              order.paymentReceiptUrl === null &&
              !order.invoice
            const taxSummary = taxEditable ? trySummarizeOrderItems(order.items) : null

            // تایید سفارشِ در انتظار تایید: فقط مدیر (همون شرطِ approveOrderAction)؛ برای بقیه به‌جای خطای عمومی دلیل نشون داده می‌شه.
            // جمع‌های خراب (summary=null) هم دکمه رو می‌بنده، چون مبلغِ تاییدشده قابل‌مشاهده نیست.
            const approval = approvalInfo.get(order.id)
            const approveBlockedReason = !approval
              ? null
              : !isAdmin
                ? 'فقط مدیر (ادمین) می‌تونه سفارش رو تایید کنه.'
                : !approval.summary
                  ? 'مبلغ سفارش قابل‌محاسبه نیست (داده‌ی ردیف‌ها نامعتبره)؛ تایید ممکن نیست.'
                  : null
            const approvalLevelText = !approval?.summary
              ? '—'
              : approval.requiredLevel
                ? (APPROVAL_LEVEL_LABELS[approval.requiredLevel] ?? approval.requiredLevel)
                : '— (طبق قوانین فعلی سطحی لازم نیست)'

            // دکمه‌های پراکنده‌ی قبلی (ابطال/تایید فیش/رد فیش) حالا توی یه منوی واحد جمع شدن.
            // هر اکشن به order.id همون سفارش bind می‌شه — فقط id به کلاینت می‌ره، نه کل آبجکت order.
            const menuActions = [
              ...(receiptPending && canReviewReceipts
                ? [
                    { label: 'تایید فیش', action: approvePaymentReceiptAction.bind(null, order.id), confirmMessage: `⚠️ فیش پرداخت سفارش #${shortId} تایید بشه؟` },
                    { label: 'رد فیش', action: rejectPaymentReceiptAction.bind(null, order.id), confirmMessage: `⚠️ فیش پرداخت سفارش #${shortId} رد بشه؟ خریدار باید فیش جدید آپلود کنه.`, danger: true },
                  ]
                : []),
              ...(isProforma && canEdit
                ? [
                    { label: 'ابطال پیش‌فاکتور', action: cancelProformaAction.bind(null, order.id), confirmMessage: `⚠️ پیش‌فاکتور سفارش #${shortId} ابطال بشه؟ موجودی قفل‌شده به انبار برمی‌گرده و این کار قابل‌بازگشت نیست.`, danger: true },
                  ]
                : []),
            ]

            return (
            <div key={order.id} style={historyCardStyle}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <b style={{ fontSize: 13.5 }}>#{shortId}</b>
                  <span style={{ fontSize: 11.5, color: '#6f7680', marginRight: 8 }}>{order.user.companyName}</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <span style={orderStatusBadgeStyle(order.status)}>{STATUS_LABELS[order.status] || order.status}</span>
                  <RecordActionsMenu extraActions={menuActions} />
                </div>
              </div>

              {isProforma && order.proformaDeadline && (() => {
                const deadline = new Date(order.proformaDeadline as unknown as string)
                const nowMs = Date.now()
                const remainingMs = deadline.getTime() - nowMs
                const isExpired = remainingMs <= 0
                const isUrgent = remainingMs > 0 && remainingMs < 24 * 60 * 60 * 1000
                return (
                  <div style={{ marginTop: 8, fontSize: 12, color: isUrgent ? '#b45309' : isExpired ? '#6f7680' : '#1b1e24' }}>
                    {/* ساعت سرور UTC است؛ نمایش باید به وقت تهران باشه (منطق منقضی/فوری روی لحظه‌ی مطلق بالاست و تغییری نکرده) */}
                    مهلت پیش‌فاکتور: {tehranJalaliDisplay(deadline)}، ساعت {tehranClockDisplay(deadline)}
                    {isExpired && <span style={{ marginRight: 6, fontWeight: 800, color: '#991b1b' }}>منقضی شده</span>}
                    {isUrgent && <span style={{ marginRight: 6, fontWeight: 800 }}>کمتر از ۲۴ ساعت باقی مانده</span>}
                  </div>
                )
              })()}

              {receiptPending && (
                <div style={{ marginTop: 12, borderTop: '1px dashed #e5e7eb', paddingTop: 12, background: '#fff4ee', borderRadius: 8, padding: '12px 14px' }}>
                  <div style={{ fontSize: 12, color: '#7a3a10', fontWeight: 700, marginBottom: 8 }}>
                    فیش پرداخت آپلود شده — در انتظار بررسی
                  </div>
                  <a href={order.paymentReceiptUrl as string} target="_blank" rel="noreferrer" style={{ fontSize: 12, color: '#1e357b', fontWeight: 700 }}>
                    مشاهده‌ی فیش آپلودی ↗
                  </a>
                  <div style={{ fontSize: 11, color: '#9199a3', marginTop: 8 }}>
                    {canReviewReceipts
                      ? 'تایید یا رد فیش از منوی اقدامات (کنار وضعیت، بالای کارت).'
                      : 'تایید یا رد فیش فقط با دسترسی بخش «تایید فیش‌های پرداخت» ممکنه.'}
                  </div>
                </div>
              )}

              {taxEditable && (
                <div style={taxBlockStyle}>
                  <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>مالیات هر ردیف (دستی)</div>
                  <div style={{ fontSize: 11, color: '#6f7680', marginBottom: 6 }}>
                    تا قبل از تایید مشتری و آپلود فیش قابل‌ویرایشه. مبلغ هر ردیف، تومانِ صحیحِ کلِ همون ردیفه (نه بر کیلو)؛
                    ورودی خالی = بدون مالیات (۰). قیمت‌ها و مهلت پیش‌فاکتور عوض نمی‌شن.
                  </div>

                  {order.items.map((item, index) => {
                    const where = `${item.grade.code}${item.warehouse ? ` (${item.warehouse.name})` : ''}`
                    const unitPrice = taxSummary?.lines[index]?.unitPriceToman
                    const itemFormKey = newFormKey()
                    return (
                      <div key={item.id} style={taxRowStyle}>
                        <div style={{ fontSize: 12.5, minWidth: 200 }}>
                          <b style={{ fontFamily: 'monospace' }}>{item.grade.code}</b>
                          {item.warehouse && <span style={{ color: '#6f7680' }}> ({item.warehouse.name})</span>}
                          <div style={{ fontSize: 11, color: '#6f7680', marginTop: 2 }}>
                            {item.quantity} تن · قیمت نهایی{' '}
                            {unitPrice === undefined ? '—' : `${formatToman(unitPrice, 'fa-IR')} تومان/کیلو`}
                          </div>
                        </div>
                        <OrderItemTaxForm
                          key={itemFormKey}
                          orderItemId={item.id}
                          formKey={itemFormKey}
                          initial={item.taxAmount === null ? '' : String(item.taxAmount)}
                          heading={where}
                        />
                      </div>
                    )
                  })}

                  <div style={taxSummaryStyle}>
                    {taxSummary ? (
                      <>
                        <span>جمع اقلام: <b>{formatToman(taxSummary.itemsTotal, 'fa-IR')}</b></span>
                        <span>جمع کل مالیات: <b>{formatToman(taxSummary.taxTotal, 'fa-IR')}</b></span>
                        <span>جمع کل قابل پرداخت: <b>{formatToman(taxSummary.grandTotal, 'fa-IR')}</b> تومان</span>
                      </>
                    ) : (
                      <span>جمع‌های سند قابل‌محاسبه نیستن — داده‌ی مبلغ این سفارش نامعتبره.</span>
                    )}
                  </div>
                </div>
              )}

              {approval && (
                <div style={taxBlockStyle}>
                  <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>تایید سفارش</div>
                  <div style={taxSummaryStyle}>
                    <span>سطح لازم (طبق قوانین فعلی): <b>{approvalLevelText}</b></span>
                    {approval.summary ? (
                      <>
                        <span>جمع اقلام (بدون مالیات؛ مبنای سطح تایید): <b>{formatToman(approval.summary.itemsTotal, 'fa-IR')}</b></span>
                        <span>جمع کل قابل پرداخت: <b>{formatToman(approval.summary.grandTotal, 'fa-IR')}</b> تومان</span>
                      </>
                    ) : (
                      <span>جمع‌های سفارش قابل‌محاسبه نیستن — داده‌ی مبلغ نامعتبره.</span>
                    )}
                  </div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 8, marginTop: 10 }}>
                    {approveBlockedReason ? (
                      <>
                        <ConfirmSubmitButton message="" style={{ ...btnPrimaryStyle, ...btnSmallStyle }} disabled title={approveBlockedReason}>
                          تایید سفارش
                        </ConfirmSubmitButton>
                        <span style={{ fontSize: 11, color: '#b45309', fontWeight: 600 }}>{approveBlockedReason}</span>
                      </>
                    ) : (
                      <form action={approveOrderAction.bind(null, order.id)}>
                        <ConfirmSubmitButton
                          message={`سفارش #${shortId} تایید بشه؟${approval.summary ? ` جمع کل قابل پرداخت ${formatToman(approval.summary.grandTotal, 'fa-IR')} تومان.` : ''} بعد از تایید، مهلت پیش‌فاکتور برای مشتری شروع می‌شه.`}
                          style={{ ...btnPrimaryStyle, ...btnSmallStyle }}
                        >
                          تایید سفارش
                        </ConfirmSubmitButton>
                      </form>
                    )}
                  </div>
                </div>
              )}
            </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

const sectionHeadStyle: React.CSSProperties = { fontSize: 15, fontWeight: 800, display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }
const countBadge: React.CSSProperties = { background: '#fee2e2', color: '#a8241a', fontSize: 11, fontWeight: 800, borderRadius: 20, padding: '2px 10px' }
const historyCardStyle: React.CSSProperties = { border: '1px solid #eceff3', borderRadius: 10, padding: '12px 16px', marginBottom: 8, background: '#fff' }
const taxBlockStyle: React.CSSProperties = { marginTop: 12, borderTop: '1px dashed #e5e7eb', paddingTop: 12 }
const taxRowStyle: React.CSSProperties = { display: 'flex', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: 10, padding: '8px 0', borderBottom: '1px solid #f1efe8' }
const taxSummaryStyle: React.CSSProperties = { display: 'flex', flexWrap: 'wrap', gap: 16, marginTop: 10, fontSize: 12, color: '#1b1e24' }
