import prisma from '@/lib/prisma'
import { getAllSectionAccess } from '@/lib/permissions'
import { getCurrentUser } from '@/lib/currentUser'
import type { AccessLevel } from '@/lib/sections'
import AdminNav, { PartialAccessBanner } from '@/components/AdminNav'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'
import { resolveDisputeAction } from './actions'
import {
  pageStyle,
  pageWrapStyle,
  contentStyle,
  h1Style,
  subTitleStyle,
  cardStyle,
  badgeStyle,
  btnPrimaryStyle,
  btnDangerStyle,
  selectStyle,
  emptyStateStyle,
} from '@/lib/styles/shared'
import { getSurfaceHome } from '@/lib/surfaceHome'

export const dynamic = 'force-dynamic'

export default async function AdminDisputesPage() {
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)

  // هم‌راستا با گیت سمت سرور: دیدن با هر سطحی از دسترسی «اختلاف‌ها» (گیتش همین صفحه‌ست، اکشنی برای دیدن نیست)؛ ثبت نتیجه (requireDisputesAdmin) فقط مدیر،
  // چون نتیجه روی آزادسازی وجه اثر می‌ذاره. UI فقط راحتیه؛ مرز امنیتی خود اکشن‌هان.
  const level: AccessLevel = isAdmin ? 'full' : ((myAccess?.disputes as AccessLevel) ?? 'none')
  const hasAccess = level !== 'none'
  const canResolve = isAdmin

  // بی‌دسترسی یعنی هیچ داده‌ای لود نشه — کوئری اختلاف‌ها بعد از این چک اجرا می‌شه
  if (!hasAccess) {
    return (
      <div style={pageStyle}>
        <div style={pageWrapStyle}>
          <AdminNav currentUserName={currentUser.companyName} currentUsername={currentUser.username} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="disputes" homeHref={getSurfaceHome()} />

          <div style={contentStyle}>
            <h1 style={h1Style}>رسیدگی به اختلاف</h1>
            <div style={emptyStateStyle}>به بخش «رسیدگی به اختلاف» دسترسی نداری.</div>
          </div>
        </div>
      </div>
    )
  }

  const disputes = await prisma.dispute.findMany({
    include: { deal: { include: { buyer: true } }, raisedBy: true },
    orderBy: { createdAt: 'desc' },
  })

  const openDisputes = disputes.filter((d) => d.status === 'open')
  const closedDisputes = disputes.filter((d) => d.status !== 'open')

  return (
    <div style={pageStyle}>
      <div style={pageWrapStyle}>
        <AdminNav currentUserName={currentUser.companyName} currentUsername={currentUser.username} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="disputes" homeHref={getSurfaceHome()} />

        <div style={contentStyle}>
          <h1 style={h1Style}>رسیدگی به اختلاف</h1>
          <p style={subTitleStyle}>
            هر بار خریدار تحویل بار رو «با مغایرت» یا «رد» تایید کنه، یه مورد اینجا خودکار باز می‌شه.
          </p>

          <PartialAccessBanner level={level} sectionLabel="رسیدگی به اختلاف" />

          <h2 style={sectionHeadStyle}>باز — نیاز به رسیدگی <span style={countBadge}>{openDisputes.length}</span></h2>
          {openDisputes.length === 0 && <div style={emptyStateStyle}>هیچ اختلاف بازی نیست.</div>}
          {openDisputes.map((d) => (
            <form key={d.id} action={canResolve ? resolveDisputeAction : undefined} style={cardStyle}>
              <input type="hidden" name="disputeId" value={d.id} />
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
                <b style={{ fontSize: 14 }}>معامله #{d.dealId.slice(0, 8)}</b>
                <span style={{ fontSize: 11, color: '#9199a3' }}>{new Date(d.createdAt).toLocaleDateString('fa-IR')}</span>
              </div>
              <div style={{ fontSize: 12.5, color: '#4f5560', marginBottom: 4 }}>خریدار: {d.deal.buyer.companyName}</div>
              <div style={{ fontSize: 13, fontWeight: 600, color: '#a8241a', marginBottom: 14 }}>دلیل: {d.reason}</div>

              {canResolve ? (
                <>
                  <label style={{ display: 'block', fontSize: 12, fontWeight: 600, color: '#4f5560', marginBottom: 6 }}>نتیجه‌ی رسیدگی</label>
                  {/* required نیست: دکمه‌ی «رد» نتیجه‌ی ثابت (به نفع فروشنده) داره و به انتخاب‌گر نیازی نداره؛ «ثبت نتیجه» بدون انتخاب را سرور رد می‌کنه. */}
                  <select name="outcome" defaultValue="" style={{ ...selectStyle, marginBottom: 10 }}>
                    <option value="" disabled>انتخاب کن…</option>
                    <option value="seller">به نفع فروشنده (فریز آزادسازی برداشته می‌شه)</option>
                    <option value="buyer">به نفع خریدار (وجه قفل می‌مونه؛ تصمیم بعدی دستیه)</option>
                  </select>
                  <textarea name="resolution" placeholder="توضیح نتیجه‌ی رسیدگی (الزامی)" rows={3} style={textareaStyle} required />

                  <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
                    <ConfirmSubmitButton message="نتیجه‌ی انتخاب‌شده برای این اختلاف ثبت بشه؟" style={btnPrimaryStyle} name="intent" value="resolve">
                      ثبت نتیجه
                    </ConfirmSubmitButton>
                    <ConfirmSubmitButton message="اختلاف رد بشه (به نفع فروشنده)؟ فریز آزادسازی برداشته می‌شه." style={btnDangerStyle} name="intent" value="reject">
                      رد (به نفع فروشنده)
                    </ConfirmSubmitButton>
                  </div>
                </>
              ) : (
                <span style={{ fontSize: 11.5, color: '#9199a3' }}>ثبت نتیجه فقط برای مدیر است — شما فقط مشاهده می‌کنید.</span>
              )}
            </form>
          ))}

          <h2 style={{ ...sectionHeadStyle, marginTop: 32 }}>تاریخچه</h2>
          {closedDisputes.length === 0 && <div style={emptyStateStyle}>هنوز موردی بسته نشده.</div>}
          {closedDisputes.map((d) => (
            <div key={d.id} style={cardStyle}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <b style={{ fontSize: 13 }}>#{d.dealId.slice(0, 8)}</b>
                <span style={statusTag}>{d.status === 'resolved' ? 'حل شد' : 'رد شد'}</span>
              </div>
              {d.resolution && <div style={{ fontSize: 12, color: '#4f5560', marginTop: 6 }}>{d.resolution}</div>}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

const sectionHeadStyle: React.CSSProperties = { fontSize: 15, fontWeight: 800, display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }
const countBadge: React.CSSProperties = { background: '#fee2e2', color: '#a8241a', fontSize: 11, fontWeight: 800, borderRadius: 20, padding: '2px 10px' }
const textareaStyle: React.CSSProperties = { width: '100%', border: '1px solid #d8dde3', borderRadius: 8, padding: '10px 12px', fontSize: 12.5, fontFamily: 'inherit', resize: 'vertical' }
const statusTag: React.CSSProperties = { ...badgeStyle('neutral') }
