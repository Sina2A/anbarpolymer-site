'use server'

import { revalidatePath } from 'next/cache'
import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { AccessDeniedError } from '@/lib/errorCodes'
import { logAudit, logFinancialDrift } from '@/lib/logger'
import { FinancialDriftError, appendFinancialRecord, newFormKey } from '@/lib/financialHistory'

/**
 * بستنِ اختلاف فقط برای مدیر (نه کارشناسِ «ویرایش»)، چون نتیجه‌ی آن مستقیم روی آزادسازی وجه اثر می‌ذاره
 * (برداشتن فریز، فیلد مالی Tier B). private و export‌نشده، تا اکشن عمومی نشه.
 */
async function requireDisputesAdmin() {
  const user = await getCurrentUser()
  if (user.role !== 'admin') {
    throw new AccessDeniedError('A-SECTION-DISPUTES', 'ثبت نتیجه‌ی اختلاف فقط برای مدیر مجازه.')
  }
  return user
}

/**
 * ثبت نتیجه‌ی یک اختلاف باز — فقط مدیر. سه مسیر:
 *   • intent=reject: «رد» = به نفع فروشنده؛ status='rejected'.
 *   • outcome=seller: به نفع فروشنده؛ status='resolved'.
 *   • outcome=buyer: به نفع خریدار؛ status='resolved'.
 * مدل Dispute ستونِ «نتیجه به نفع چه کسی» نداره، پس نتیجه به‌صورت پیشوند توی متن resolution ثبت می‌شه.
 *
 * به نفع فروشنده: اگه روی همین معامله اختلاف بازِ دیگری نمونده باشه، فریزِ آزادسازی
 * (Deal.fundReleaseFrozen، فیلد مالی Tier B) برداشته می‌شه — رکورد تاریخچه «قبل» از ستون و در همان تراکنش.
 * به نفع خریدار: فقط نتیجه ثبت می‌شه؛ فریز و قفل بودن وجه سر جاشه و معامله خودکار باطل نمی‌شه
 * (تصمیم بعدی، دستی و با مدیره).
 * بستنِ اختلاف با updateMany از 'open' اتمیکه؛ هر شکست (هم‌زمانی، ناهمخوانی تاریخچه) throw می‌شه (نه return)
 * تا کل تراکنش، از جمله رکورد تاریخچه، rollback بشه.
 */
export async function resolveDisputeAction(formData: FormData) {
  const currentUser = await requireDisputesAdmin()

  const disputeId = String(formData.get('disputeId') ?? '')
  const intent = String(formData.get('intent') ?? '')
  const outcomeRaw = String(formData.get('outcome') ?? '')
  const resolutionText = String(formData.get('resolution') ?? '').trim()

  if (!disputeId) throw new Error('شناسه‌ی اختلاف نامعتبره.')
  if (!resolutionText) throw new Error('توضیح نتیجه‌ی رسیدگی الزامیه.')

  let outcome: 'seller' | 'buyer'
  let status: 'resolved' | 'rejected'
  if (intent === 'reject') {
    outcome = 'seller' // رد = به نفع فروشنده؛ انتخاب‌گرِ نتیجه نادیده گرفته می‌شه
    status = 'rejected'
  } else if (outcomeRaw === 'seller' || outcomeRaw === 'buyer') {
    outcome = outcomeRaw
    status = 'resolved'
  } else {
    throw new Error('نتیجه‌ی رسیدگی (به نفع فروشنده یا خریدار) انتخاب نشده.')
  }

  const outcomeLabel = outcome === 'seller' ? 'به نفع فروشنده' : 'به نفع خریدار'
  const storedResolution = `[${status === 'rejected' ? 'رد — ' : ''}${outcomeLabel}] ${resolutionText}`

  let dealId = ''
  let freezeCleared = false
  try {
    await prisma.$transaction(
      async (tx) => {
        const dispute = await tx.dispute.findUnique({ where: { id: disputeId }, select: { dealId: true, status: true } })
        if (!dispute) throw new Error('اختلاف پیدا نشد.')
        if (dispute.status !== 'open') throw new Error('این اختلاف قبلاً بسته شده.')
        dealId = dispute.dealId

        const closed = await tx.dispute.updateMany({
          where: { id: disputeId, status: 'open' },
          data: { status, resolution: storedResolution, resolvedById: currentUser.id, resolvedAt: new Date() },
        })
        if (closed.count !== 1) throw new Error('هم‌زمان کس دیگه‌ای این اختلاف رو بست؛ صفحه رو تازه کن.')

        if (outcome !== 'seller') return

        // بعد از بسته‌شدنِ همین اختلاف: اگه اختلاف بازِ دیگری روی این معامله مونده، فریز سر جاشه.
        const stillOpen = await tx.dispute.count({ where: { dealId, status: 'open' } })
        if (stillOpen > 0) return

        const record = await appendFinancialRecord(tx, {
          entityType: 'Deal',
          entityId: dealId,
          fieldName: 'fundReleaseFrozen',
          newValue: false,
          changedBy: currentUser.id,
          formKey: newFormKey(),
          readColumn: async () => {
            const row = await tx.deal.findUnique({ where: { id: dealId }, select: { fundReleaseFrozen: true } })
            return row?.fundReleaseFrozen ?? null
          },
        })
        if (record.outcome === 'duplicate') throw new Error('این درخواست قبلاً ثبت شده؛ صفحه رو تازه کن.')
        if (record.outcome === 'unchanged') return // فریز از قبل برداشته بوده؛ چیزی برای نوشتن نیست

        // شرطِ none/open: اگه بین شمارش و این نوشتن اختلافِ بازِ تازه‌ای ثبت شده باشه، count=0 می‌شه و
        // throw کل تراکنش (با رکورد تاریخچه) رو برمی‌گردونه.
        const cleared = await tx.deal.updateMany({
          where: { id: dealId, fundReleaseFrozen: true, disputes: { none: { status: 'open' } } },
          data: { fundReleaseFrozen: false },
        })
        if (cleared.count !== 1) throw new Error('وضعیت معامله هم‌زمان عوض شد؛ صفحه رو تازه کن و دوباره تلاش کن.')
        freezeCleared = true
      },
      { timeout: 20000, maxWait: 5000 },
    )
  } catch (error) {
    if (error instanceof FinancialDriftError) await logFinancialDrift(error, currentUser.id, { disputeId, dealId })
    throw error
  }

  await logAudit('dispute', `نتیجه‌ی اختلاف معامله ${dealId.slice(0, 8)} ثبت شد (${outcomeLabel})`, currentUser.id, {
    disputeId,
    dealId,
    action: 'dispute_resolved',
    status,
    outcome,
    freezeCleared,
  })

  revalidatePath('/admin-disputes')
  revalidatePath('/admin-deals')
}
