/**
 * موتور محاسبه‌ی مالی واحد — تنها منبع حقیقت برای وزن، قیمت، مالیات، جمع کل و
 * تجزیه‌ی ورودی‌های عددی (پولی/وزنی) در کل سایت.
 *
 * قرارداد واحدها:
 *  - همه‌ی مبالغ «تومان» و عدد صحیح‌اند. قیمت واحد «تومان بر کیلوگرم» است.
 *    (نام ستون WarehouseStock.priceRial تاریخیه؛ مقدارش تومان بر کیلوگرمه.)
 *  - وزنِ محاسبه‌ی مبلغ همیشه «کیلوگرمِ صحیح» است. «تن» فقط در مرز ورودی/نمایش وجود داره
 *    (OrderItem.quantity و quantityTon تن‌اند).
 *
 * مالیات: عددی «دستی» و «per-ردیف»ـه که ادمین برای هر ردیف وارد می‌کنه؛ هیچ نرخ یا درصد
 * خودکاری وجود نداره. خالی/واردنشده (null) = ۰. جمع کل = Σ(مبلغ ردیف + مالیات همان ردیف).
 *
 * دقت: ضرب‌ها روی عدد صحیح انجام می‌شن و هر مبلغ (ردیف، جمع اقلام، جمع مالیات، جمع کل) بالاتر
 * از MAX_TOMAN رد می‌شه. هر حاصل‌ضربی که از 2^53 بزرگ‌تر بشه حتماً از MAX_TOMAN هم بزرگ‌تره و رد
 * می‌شه؛ پس هر مبلغِ پذیرفته‌شده دقیقه (BigInt لازم نیست).
 *
 * این فایل خالصه: بدون import و بدون 'use server'، قابل‌استفاده در کلاینت و سرور.
 */

// ── ثابت‌ها ──────────────────────────────────────────────────────────────────

export const KG_PER_TON = 1000

/**
 * سقف هر مبلغ تومانی (ردیف، جمع اقلام، جمع مالیات، جمع کل). جمعِ دو مبلغ مجاز ≤ 2e13 و زیر
 * 2^53 است، پس جمع‌ها دقیق می‌مونن.
 */
export const MAX_TOMAN = 1e13

// ── خطاها ────────────────────────────────────────────────────────────────────

export type MoneyParseCode =
  | 'empty'
  | 'format'
  | 'decimals'
  | 'not-integer'
  | 'zero'
  | 'negative'
  | 'range'

/** خطای ورودی کاربر (فقط برای نسخه‌ی throw-کننده: requireParsed / requireMoneyInput). */
export class MoneyInputError extends Error {
  readonly code: MoneyParseCode
  constructor(code: MoneyParseCode, message: string) {
    super(message)
    this.name = 'MoneyInputError'
    this.code = code
  }
}

/** داده‌ی نامعتبر در محاسبه (NaN، منفی، غیرصحیح، بیشتر از سقف). */
export class MoneyCalcError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'MoneyCalcError'
  }
}

// ── وزن ──────────────────────────────────────────────────────────────────────

/**
 * تن → کیلوگرمِ صحیح (گرد به نزدیک‌ترین کیلو). برای داده‌ی ذخیره‌شده‌ی قدیمی
 * (Float) که ممکنه اعشار بلند داشته باشه.
 */
export function tonToKg(ton: number): number {
  if (typeof ton !== 'number' || !Number.isFinite(ton) || ton < 0) {
    throw new MoneyCalcError('مقدار تن نامعتبره.')
  }
  const kg = Math.round(ton * KG_PER_TON)
  if (!Number.isSafeInteger(kg)) throw new MoneyCalcError('مقدار تن نامعتبره.')
  return kg
}

/**
 * تن → کیلوگرمِ صحیح، سخت‌گیرانه: فقط وقتی تن حداکثر ۳ رقم اعشار داشته باشه
 * (یعنی کیلوی صحیح) و حداقل ۱ کیلو باشه. برای ورودی تازه‌ی کاربر در اندپوینت‌های عمومی.
 */
export function tonToKgStrict(ton: number): number {
  if (typeof ton !== 'number' || !Number.isFinite(ton) || ton <= 0) {
    throw new MoneyCalcError('مقدار تن باید بیشتر از صفر باشه.')
  }
  const exact = ton * KG_PER_TON
  const kg = Math.round(exact)
  if (Math.abs(exact - kg) > 1e-6) {
    throw new MoneyCalcError('مقدار تن حداکثر ۳ رقم اعشار (کیلوی صحیح) می‌تونه داشته باشه.')
  }
  if (kg < 1 || !Number.isSafeInteger(kg)) {
    throw new MoneyCalcError('مقدار تن حداقل ۱ کیلوگرمه.')
  }
  return kg
}

/** کیلوگرم → تن. فقط برای نمایش؛ در هیچ محاسبه‌ی مبلغی استفاده نشه. */
export function kgToTon(kg: number): number {
  return kg / KG_PER_TON
}

// ── مبلغ ─────────────────────────────────────────────────────────────────────

function assertToman(value: number, what: string): void {
  if (!Number.isSafeInteger(value) || value < 0 || value > MAX_TOMAN) {
    throw new MoneyCalcError(`${what} نامعتبره.`)
  }
}

/**
 * گرد کردنِ «مرزی» قیمت واحدِ ذخیره‌شده (Float قدیمی) به تومانِ صحیح.
 * اختلاف حداکثر ۰٫۵ تومان بر کیلوگرمه. مقدار منفی/نامتناهی/بیش‌ازسقف خطاست.
 */
export function roundToman(value: number): number {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0) {
    throw new MoneyCalcError('قیمت واحد نامعتبره.')
  }
  const rounded = Math.round(value)
  if (rounded > MAX_TOMAN) throw new MoneyCalcError('قیمت واحد از سقف مجاز بیشتره.')
  return rounded
}

/** مبلغ یک ردیف = قیمت واحد (تومان/کیلو) × وزن (کیلوی صحیح)، به‌صورت عدد صحیح. */
export function lineTotalToman(unitPriceToman: number, kg: number): number {
  assertToman(unitPriceToman, 'قیمت واحد')
  if (!Number.isSafeInteger(kg) || kg < 0) throw new MoneyCalcError('وزن (کیلوگرم) نامعتبره.')
  const total = unitPriceToman * kg
  if (total > MAX_TOMAN) throw new MoneyCalcError('مبلغ ردیف از سقف مجاز بیشتره.')
  return total
}

/**
 * مالیات دستیِ یک ردیف → تومانِ صحیح. null/undefined (واردنشده) = ۰؛ هر مقدار دیگه باید عدد
 * صحیحِ ۰…MAX_TOMAN باشه، وگرنه MoneyCalcError (داده‌ی خراب بی‌صدا ۰ حساب نمی‌شه).
 * خصوصیه: فقط موتور سند ازش استفاده می‌کنه.
 */
function normalizeTaxToman(value: number | null | undefined): number {
  if (value === null || value === undefined) return 0
  assertToman(value, 'مالیات ردیف')
  return value === 0 ? 0 : value // -0 → 0 (وگرنه «-0» نمایش داده می‌شه)
}

// ── سند: ردیف‌ها + مالیات + جمع کل ───────────────────────────────────────────

export interface DocumentLineInput {
  /** تومان بر کیلوگرم (صحیح) */
  unitPriceToman: number
  /** کیلوگرمِ صحیح */
  kg: number
  /** مالیات دستیِ کل همین ردیف (تومانِ صحیح، نه تومان/کیلو). null/undefined/غایب = ۰. */
  taxToman?: number | null
}

export interface DocumentLine {
  unitPriceToman: number
  kg: number
  lineTotal: number
  /** مالیات دستیِ همین ردیف؛ همیشه عدد (واردنشده = ۰). */
  lineTax: number
}

export interface DocumentSummary {
  lines: DocumentLine[]
  /** جمع خالص (بدون مالیات) = Σ lineTotal */
  itemsTotal: number
  /** جمع کل مالیات = Σ lineTax (مالیات‌های دستیِ ردیف‌ها؛ هیچ درصد خودکاری وجود نداره) */
  taxTotal: number
  /** مبلغ قابل پرداخت = itemsTotal + taxTotal = Σ(lineTotal + lineTax) */
  grandTotal: number
}

/**
 * جمع‌بندی یک سند از ردیف‌های صحیح. ترتیب خروجی همان ترتیب ورودی است.
 * هر ردیف مالیات دستیِ خودش را دارد؛ مالیات واردنشده ۰ حساب می‌شه، نه خطا و نه NaN.
 */
export function summarizeDocument(inputs: readonly DocumentLineInput[]): DocumentSummary {
  const lines: DocumentLine[] = inputs.map((l) => ({
    unitPriceToman: l.unitPriceToman,
    kg: l.kg,
    lineTotal: lineTotalToman(l.unitPriceToman, l.kg),
    lineTax: normalizeTaxToman(l.taxToman),
  }))

  let itemsTotal = 0
  let taxTotal = 0
  for (const l of lines) {
    itemsTotal += l.lineTotal
    taxTotal += l.lineTax
  }
  if (itemsTotal > MAX_TOMAN) throw new MoneyCalcError('جمع مبلغ از سقف مجاز بیشتره.')
  if (taxTotal > MAX_TOMAN) throw new MoneyCalcError('جمع مالیات از سقف مجاز بیشتره.')

  const grandTotal = itemsTotal + taxTotal
  if (grandTotal > MAX_TOMAN) throw new MoneyCalcError('مبلغ قابل پرداخت از سقف مجاز بیشتره.')

  return { lines, itemsTotal, taxTotal, grandTotal }
}

/** حداقل فیلدهای OrderItem که موتور لازم داره. quantity «تن» است. */
export interface OrderItemPricing {
  price: number
  finalPrice?: number | null
  quantity: number
  /**
   * مالیات دستیِ کل همین ردیف (تومان). عمداً الزامی-ولی-nullable: کوئری‌ای که این ستون رو select
   * نکنه در tsc خطا می‌ده، به‌جای این‌که بی‌صدا مالیات ۰ حساب بشه. فقط null یعنی «واردنشده = ۰».
   */
  taxAmount: number | null
}

/**
 * جمع‌بندی ردیف‌های سفارش: قیمت واحد = finalPrice ?? price (گرد به تومان صحیح)،
 * وزن = quantity (تن) → کیلوگرم، مالیات = taxAmountِ دستیِ هر ردیف (null = ۰).
 * داده‌ی نامعتبر MoneyCalcError می‌ده.
 * برای مسیرهای تغییردهنده‌ی وضعیت (فاکتور، آستانه‌ی تایید) از همین نسخه استفاده کن.
 */
export function summarizeOrderItems(items: readonly OrderItemPricing[]): DocumentSummary {
  return summarizeDocument(
    items.map((it) => ({
      unitPriceToman: roundToman(it.finalPrice ?? it.price),
      kg: tonToKg(it.quantity),
      taxToman: it.taxAmount,
    })),
  )
}

/**
 * مثل summarizeOrderItems ولی برای صفحه‌های لیستی: با داده‌ی خراب null برمی‌گردونه
 * تا یک سفارش معیوب کل صفحه را نیندازه (UI باید «—» نشون بده، نه عدد ساختگی).
 */
export function trySummarizeOrderItems(items: readonly OrderItemPricing[]): DocumentSummary | null {
  try {
    return summarizeOrderItems(items)
  } catch (err) {
    if (err instanceof MoneyCalcError) return null
    throw err
  }
}

// ── معامله (Deal): جمع کل سمت خریدار ─────────────────────────────────────────

export type DealAdjustmentDirection = 'increase' | 'decrease'

export interface DealAdjustmentInput {
  /** مبلغ مثبت (تومانِ صحیح)؛ جهتش در direction است، نه در علامت. */
  amountToman: number
  direction: DealAdjustmentDirection
}

export interface DealSummaryInput {
  /** قیمت واحد (تومان/کیلو) از ستون ذخیره‌شده؛ مرزی به تومانِ صحیح گرد می‌شه. null = ثبت‌نشده. */
  unitPriceToman: number | null
  /** وزن (کیلوگرمِ صحیح). null = ثبت‌نشده. */
  weightKg: number | null
  /** بیمه‌ی بار (دستی). null/undefined/غایب = ۰. */
  insuranceToman?: number | null
  /** مالیات سمت خریدار (دستی). null/undefined/غایب = ۰. */
  buyerTaxToman?: number | null
  /** ردیف‌های تعدیلِ فعال (حذف‌نشده). */
  adjustments?: readonly DealAdjustmentInput[]
  /** جایگزین دستیِ جمع کل. null/undefined = بدون override. */
  overrideToman?: number | null
}

export interface DealSummary {
  /** قیمت × وزن؛ null اگه قیمت یا وزن ثبت نشده باشه. */
  goodsTotal: number | null
  insurance: number
  buyerTax: number
  /** Σ(افزایش) − Σ(کاهش)؛ می‌تونه منفی باشه. */
  adjustmentsNet: number
  /** کالا + بیمه + مالیات خریدار ± تعدیل‌ها؛ null اگه کالا محاسبه‌نشدنی باشه. */
  computedTotal: number | null
  /** جمعی که نمایش داده می‌شه: override ?? computedTotal. */
  displayTotal: number | null
  overridden: boolean
  /** override − computedTotal؛ فقط وقتی override هست و computedTotal هم محاسبه‌پذیره. */
  difference: number | null
}

/** مبلغ اختیاریِ دستی → تومانِ صحیح. null/undefined = ۰؛ هر مقدار دیگه باید صحیحِ ۰…MAX_TOMAN باشه. */
function optionalToman(value: number | null | undefined, what: string): number {
  if (value === null || value === undefined) return 0
  assertToman(value, what)
  return value === 0 ? 0 : value
}

/**
 * جمع کل یک معامله «فقط سمت خریدار»: کالا + بیمه‌ی بار + مالیات خریدار ± تعدیل‌ها.
 * کارمزد معامله و مالیات فروشنده عمداً در این عدد نمی‌آن (پول دو طرفِ جدا).
 * قیمت یا وزن ثبت‌نشده ⇒ کالا و جمع محاسبه‌شده null می‌شن (عدد ساختگی ساخته نمی‌شه)؛ بقیه‌ی null ها = ۰.
 * داده‌ی نامعتبر (NaN، منفی، غیرصحیح، بیش از سقف، جمع منفی) MoneyCalcError می‌ده.
 */
export function summarizeDeal(input: DealSummaryInput): DealSummary {
  const insurance = optionalToman(input.insuranceToman, 'بیمه‌ی بار')
  const buyerTax = optionalToman(input.buyerTaxToman, 'مالیات خریدار')

  // دو انباره‌ی یکنواخت (افزایش/کاهش): ترتیب ردیف‌ها روی نتیجه اثری نداره و سرریز زودتر گرفته می‌شه.
  let increases = 0
  let decreases = 0
  for (const adj of input.adjustments ?? []) {
    assertToman(adj.amountToman, 'مبلغ تعدیل')
    if (adj.amountToman === 0) throw new MoneyCalcError('مبلغ تعدیل باید بیشتر از صفر باشه.')
    if (adj.direction === 'increase') increases += adj.amountToman
    else if (adj.direction === 'decrease') decreases += adj.amountToman
    else throw new MoneyCalcError('جهت تعدیل نامعتبره.')
    if (increases > MAX_TOMAN || decreases > MAX_TOMAN) throw new MoneyCalcError('جمع تعدیل‌ها از سقف مجاز بیشتره.')
  }
  const adjustmentsNet = increases - decreases

  const override = input.overrideToman ?? null
  if (override !== null) assertToman(override, 'جمع کل دستی')

  const goodsTotal =
    input.unitPriceToman === null || input.weightKg === null
      ? null
      : lineTotalToman(roundToman(input.unitPriceToman), input.weightKg)

  let computedTotal: number | null = null
  if (goodsTotal !== null) {
    computedTotal = goodsTotal + insurance + buyerTax + adjustmentsNet
    if (computedTotal < 0) throw new MoneyCalcError('جمع کل منفی می‌شه.')
    if (computedTotal > MAX_TOMAN) throw new MoneyCalcError('جمع کل از سقف مجاز بیشتره.')
  }

  return {
    goodsTotal,
    insurance,
    buyerTax,
    adjustmentsNet,
    computedTotal,
    displayTotal: override ?? computedTotal,
    overridden: override !== null,
    difference: override !== null && computedTotal !== null ? override - computedTotal : null,
  }
}

/** مثل summarizeDeal ولی برای صفحه‌ی لیستی: با داده‌ی خراب null برمی‌گردونه (UI «—» نشون بده). */
export function trySummarizeDeal(input: DealSummaryInput): DealSummary | null {
  try {
    return summarizeDeal(input)
  } catch (err) {
    if (err instanceof MoneyCalcError) return null
    throw err
  }
}

export interface DealApprovalAmountInput {
  /** قیمت واحد توافقی (تومان/کیلو) از Deal.agreedPrice. null/undefined = ثبت‌نشده. */
  agreedPrice: number | null | undefined
  /** وزن ثبت‌شده‌ی ادمین (Deal.weightKg، کیلوی صحیح). اگه باشه بر listedTon مقدمه. */
  weightKg: number | null | undefined
  /** تنِ آگهی/درخواست (materialListing.quantityTon یا purchaseRequest.quantityTon)؛ فقط وقتی weightKg نیست. */
  listedTon: number | null | undefined
}

/**
 * مبلغی که باید با قواعد تاییدِ `Deal/amount` (evaluateApprovalRequirement) مقایسه بشه:
 * «جمع کالا» = قیمت واحد × وزن — نه قیمت واحد. بیمه، مالیات و تعدیل‌ها عمداً توش نیستن.
 *
 * - قیمت ثبت‌نشده (null/undefined) ⇒ null؛ تصمیمش با فراخوان است (عدد ساختگی ساخته نمی‌شه).
 * - قیمت صفر ⇒ ۰ (بدون نیاز به وزن؛ حاصل‌ضرب هر وزنی صفره).
 * - وزن: weightKg ثبت‌شده، وگرنه tonToKg(listedTon) (D20). وزنِ ثبت‌شده‌ی غیرصحیح یا کمتر از ۱ کیلو
 *   و تنِ نامعتبر/کمتر از ۱ کیلو داده‌ی خرابه و MoneyCalcError می‌ده؛ نبودنِ وزن از هر دو منبع هم
 *   همین‌طور (fail-closed: وگرنه سقف تایید با «وزنِ صفر» دور زده می‌شد).
 * - قیمت یا حاصل‌ضرب نامعتبر/بیش از MAX_TOMAN ⇒ MoneyCalcError.
 */
export function dealApprovalAmountToman(input: DealApprovalAmountInput): number | null {
  if (input.agreedPrice === null || input.agreedPrice === undefined) return null
  const unitPrice = roundToman(input.agreedPrice)
  if (unitPrice === 0) return 0

  let kg: number
  if (input.weightKg !== null && input.weightKg !== undefined) {
    if (!Number.isSafeInteger(input.weightKg) || input.weightKg < 1) {
      throw new MoneyCalcError('وزن ثبت‌شده‌ی معامله نامعتبره.')
    }
    kg = input.weightKg
  } else if (input.listedTon !== null && input.listedTon !== undefined) {
    kg = tonToKg(input.listedTon)
    if (kg < 1) throw new MoneyCalcError('وزن آگهی/درخواست نامعتبره.')
  } else {
    throw new MoneyCalcError('وزن معامله مشخص نیست.')
  }
  return lineTotalToman(unitPrice, kg)
}

// ── نمایش ────────────────────────────────────────────────────────────────────

export type MoneyLocale = 'en-US' | 'fa-IR'

/** فقط نمایش. هر صفحه لوکیل فعلی خودش را نگه می‌داره. */
export function formatToman(value: number, locale: MoneyLocale = 'en-US'): string {
  return value.toLocaleString(locale)
}

// ── تجزیه‌ی ورودی کاربر ──────────────────────────────────────────────────────

export type ParseResult<T> =
  | { ok: true; value: T }
  | { ok: false; code: MoneyParseCode; error: string }

export interface MoneyInputOptions {
  /** نام فیلد برای پیام خطا. */
  label?: string
  /** صفر مجاز باشه؟ پیش‌فرض: خیر. */
  allowZero?: boolean
  /** منفی مجاز باشه؟ پیش‌فرض: خیر. */
  allowNegative?: boolean
  /** فقط عدد صحیح؟ پیش‌فرض در parseMoneyInput: بله. */
  integerOnly?: boolean
  /** حداکثر رقم اعشار وقتی integerOnly=false. */
  maxDecimals?: number
  /** سقف مقدار مطلق. */
  max?: number
  /** ورودی خالی مجازه؟ (نتیجه: value = null) */
  optional?: boolean
}

export type NumberInputOptions = Omit<MoneyInputOptions, 'integerOnly' | 'maxDecimals'>
export type DecimalInputOptions = Omit<MoneyInputOptions, 'integerOnly'>
export type TonInputOptions = NumberInputOptions

interface ParseSpec {
  label: string
  integerOnly: boolean
  maxDecimals: number
  max: number
  allowZero: boolean
  allowNegative: boolean
  optional: boolean
}

// فاصله‌ی معمولی، NBSP، ZWNJ/ZWJ/ZWSP، علامت‌های جهت (RTL/LTR/embedding/isolate)، BOM
const INVISIBLE = /[\s\u200B-\u200F\u202A-\u202E\u2066-\u2069\u061C\uFEFF]/g
// هزارگان: گروه اول ۱ تا ۳ رقم (بدون صفر ابتدایی) و گروه‌های بعدی دقیقاً ۳ رقم
const GROUPED_NUMBER = /^[1-9]\d{0,2}(?:,\d{3})+(?:\.\d+)?$/
const PLAIN_NUMBER = /^\d+(?:\.\d+)?$/
const MAX_INPUT_LENGTH = 64

/** ورودی خالی یا فقط فاصله/نویسه‌ی نامرئی؟ (برای فیلدهای اختیاری) */
export function isBlankInput(raw: unknown): boolean {
  if (raw === null || raw === undefined) return true
  if (typeof raw !== 'string') return false
  return raw.replace(INVISIBLE, '') === ''
}

/**
 * رقم‌های فارسی/عربی → لاتین؛ حذف فاصله و نویسه‌های نامرئی؛ «٫» → نقطه‌ی اعشار؛
 * «،» «٬» → کاما (هزارگان)؛ «−» → «-».
 */
function normalizeNumericText(text: string): string {
  return text
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 0x06f0))
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x0660))
    .replace(INVISIBLE, '')
    .replace(/٫/g, '.')
    .replace(/[٬،]/g, ',')
    .replace(/−/g, '-')
}

function describeFailure(code: MoneyParseCode, spec: ParseSpec): string {
  const label = `«${spec.label}»`
  switch (code) {
    case 'empty':
      return `${label} الزامیه.`
    case 'format':
      return `${label} باید یه عدد معتبر باشه (فقط رقم؛ جداکننده‌ی هزارگان مثل 12,500 مجازه).`
    case 'decimals':
      return `${label} حداکثر ${spec.maxDecimals} رقم اعشار می‌تونه داشته باشه.`
    case 'not-integer':
      return `${label} باید عدد صحیح باشه (بدون اعشار).`
    case 'zero':
      return `${label} نمی‌تونه صفر باشه.`
    case 'negative':
      return `${label} نمی‌تونه منفی باشه.`
    case 'range':
      return `${label} خارج از محدوده‌ی مجازه (حداکثر ${spec.max.toLocaleString('en-US')}).`
  }
}

function parseNumericInput(raw: unknown, spec: ParseSpec): ParseResult<number | null> {
  const fail = (code: MoneyParseCode): ParseResult<never> => ({
    ok: false,
    code,
    error: describeFailure(code, spec),
  })

  if (isBlankInput(raw)) return spec.optional ? { ok: true, value: null } : fail('empty')

  let text: string
  if (typeof raw === 'string') text = raw
  else if (typeof raw === 'number' && Number.isFinite(raw)) text = String(raw)
  else return fail('format')

  text = normalizeNumericText(text)
  if (text.length > MAX_INPUT_LENGTH) return fail('format')

  const negative = text.startsWith('-')
  if (negative) text = text.slice(1)

  if (!GROUPED_NUMBER.test(text) && !PLAIN_NUMBER.test(text)) return fail('format')

  const [intDigits, fracDigits = ''] = text.replace(/,/g, '').split('.')
  if (spec.integerOnly) {
    // هر نقطه‌ی اعشار رد می‌شه (حتی «12.000»): ممکنه جداکننده‌ی هزارگانِ سبک اروپایی باشه
    if (text.includes('.')) return fail('not-integer')
  } else if (fracDigits.length > spec.maxDecimals) {
    return fail('decimals')
  }

  const value = Number(fracDigits ? `${intDigits}.${fracDigits}` : intDigits)
  if (!Number.isFinite(value)) return fail('range')
  if (spec.integerOnly && !Number.isSafeInteger(value)) return fail('range')

  if (value === 0) return spec.allowZero ? { ok: true, value: 0 } : fail('zero')
  if (negative && !spec.allowNegative) return fail('negative')
  if (value > spec.max) return fail('range')
  return { ok: true, value: negative ? -value : value }
}

/**
 * مبلغ تومانیِ صحیح. پیش‌فرض: رد NaN، منفی و صفر؛ رقم فارسی و هزارگانِ معتبر پذیرفته.
 * سقف پیش‌فرض MAX_TOMAN است.
 */
export function parseMoneyInput(
  raw: unknown,
  opts: MoneyInputOptions & { optional: true },
): ParseResult<number | null>
export function parseMoneyInput(
  raw: unknown,
  opts?: MoneyInputOptions & { optional?: false },
): ParseResult<number>
export function parseMoneyInput(raw: unknown, opts: MoneyInputOptions = {}): ParseResult<number | null> {
  return parseNumericInput(raw, {
    label: opts.label ?? 'مبلغ',
    integerOnly: opts.integerOnly ?? true,
    maxDecimals: opts.maxDecimals ?? 2,
    max: opts.max ?? MAX_TOMAN,
    allowZero: opts.allowZero ?? false,
    allowNegative: opts.allowNegative ?? false,
    optional: opts.optional ?? false,
  })
}

/** هم‌نام معنایی parseMoneyInput برای جاهایی که «تومان» صریح خوانده بشه. */
export const parseTomanInput = parseMoneyInput

/** وزن به «تن» با حداکثر ۳ رقم اعشار (= کیلوی صحیح). مقدار برگشتی تن است. */
export function parseTonInput(
  raw: unknown,
  opts: TonInputOptions & { optional: true },
): ParseResult<number | null>
export function parseTonInput(
  raw: unknown,
  opts?: TonInputOptions & { optional?: false },
): ParseResult<number>
export function parseTonInput(raw: unknown, opts: TonInputOptions = {}): ParseResult<number | null> {
  return parseNumericInput(raw, {
    label: opts.label ?? 'وزن (تن)',
    integerOnly: false,
    maxDecimals: 3,
    max: opts.max ?? 1e6,
    allowZero: opts.allowZero ?? false,
    allowNegative: opts.allowNegative ?? false,
    optional: opts.optional ?? false,
  })
}

/** وزن به «کیلوگرم» (عدد صحیح). */
export function parseKgInput(
  raw: unknown,
  opts: NumberInputOptions & { optional: true },
): ParseResult<number | null>
export function parseKgInput(
  raw: unknown,
  opts?: NumberInputOptions & { optional?: false },
): ParseResult<number>
export function parseKgInput(raw: unknown, opts: NumberInputOptions = {}): ParseResult<number | null> {
  return parseNumericInput(raw, {
    label: opts.label ?? 'وزن (کیلوگرم)',
    integerOnly: true,
    maxDecimals: 0,
    max: opts.max ?? 1e9,
    allowZero: opts.allowZero ?? false,
    allowNegative: opts.allowNegative ?? false,
    optional: opts.optional ?? false,
  })
}

/** عدد صحیح عمومی (روز، اولویت، …). */
export function parseIntegerInput(
  raw: unknown,
  opts: NumberInputOptions & { optional: true },
): ParseResult<number | null>
export function parseIntegerInput(
  raw: unknown,
  opts?: NumberInputOptions & { optional?: false },
): ParseResult<number>
export function parseIntegerInput(raw: unknown, opts: NumberInputOptions = {}): ParseResult<number | null> {
  return parseNumericInput(raw, {
    label: opts.label ?? 'مقدار',
    integerOnly: true,
    maxDecimals: 0,
    max: opts.max ?? 1e9,
    allowZero: opts.allowZero ?? false,
    allowNegative: opts.allowNegative ?? false,
    optional: opts.optional ?? false,
  })
}

/** عدد اعشاریِ عمومی (درصد، ضریب، دلار، …). پیش‌فرض حداکثر ۴ رقم اعشار و سقف 1e9. */
export function parseDecimalInput(
  raw: unknown,
  opts: DecimalInputOptions & { optional: true },
): ParseResult<number | null>
export function parseDecimalInput(
  raw: unknown,
  opts?: DecimalInputOptions & { optional?: false },
): ParseResult<number>
export function parseDecimalInput(raw: unknown, opts: DecimalInputOptions = {}): ParseResult<number | null> {
  return parseNumericInput(raw, {
    label: opts.label ?? 'مقدار',
    integerOnly: false,
    maxDecimals: opts.maxDecimals ?? 4,
    max: opts.max ?? 1e9,
    allowZero: opts.allowZero ?? false,
    allowNegative: opts.allowNegative ?? false,
    optional: opts.optional ?? false,
  })
}

/**
 * نسخه‌ی throw-کننده برای اکشن‌هایی که خطا را پرتاب می‌کنن. توجه: در production متن
 * Error به کلاینت نمی‌رسه؛ جاهایی که کاربر باید پیام ببینه خروجی ParseResult را برگردون.
 */
export function requireParsed<T>(result: ParseResult<T>): T {
  if (!result.ok) throw new MoneyInputError(result.code, result.error)
  return result.value
}

/** پوششِ throw-کننده برای parseMoneyInput. */
export function requireMoneyInput(raw: unknown, opts?: MoneyInputOptions & { optional?: false }): number {
  return requireParsed(parseMoneyInput(raw, opts))
}
