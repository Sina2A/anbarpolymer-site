/**
 * ثبت تاریخچه‌ی فیلدهای مالی در جدول append-only «FinancialFieldHistory» با زنجیره‌ی hash.
 *
 * قواعد استفاده:
 *  - فقط داخل prisma.$transaction(async tx => …) صدا زده بشه. قفل advisory از نوع «تراکنشی»ه و با
 *    پایان تراکنش آزاد می‌شه؛ بیرون از تراکنش هیچ محافظتی نمی‌ده.
 *  - appendFinancialRecord باید «قبل» از نوشتن ستون اصلی صدا زده بشه (readColumn مقدار قبلی را می‌خونه)،
 *    و نوشتن ستون در همان تراکنش باشه تا با هر خطا، تاریخچه و ستون با هم برگردن.
 *  - 'use server' ندارد و نباید داشته باشه؛ وگرنه appendFinancialRecord یک endpoint عمومی برای
 *    جعل تاریخچه می‌شد.
 *
 * دو دسته فیلد:
 *  - Tier A: ستون ندارد؛ مقدار فعلی = newValue آخرین رکورد تاریخچه.
 *  - Tier B: ستونِ موجود در جدول اصلی که به‌عنوان «کش» می‌مونه. با readColumn داده می‌شه. اگه تاریخچه‌ای
 *    برای فیلد نباشه، اول یک رکورد «شروع» (genesis) از مقدار فعلی ستون ساخته می‌شه؛ اگه باشه و با ستون
 *    نخونه (کسی ستون را بیرون از این مسیر عوض کرده)، FinancialDriftError پرتاب می‌شه و چیزی نوشته نمی‌شه.
 *
 * همزمانی: هر (entityType, entityId) یک زنجیره‌ست و نویسنده‌ها با pg_advisory_xact_lock پشت‌سرهم می‌شن؛
 * پس seq بدون حفره و previousRecordHash درست می‌مونه. unique index روی (entityType, entityId, seq) و
 * idempotencyKey فقط پشتیبانِ آخره: خطای دیتابیس تراکنش را abort می‌کنه، پس retry داخل همان تراکنش
 * ممکن نیست و باید از بیرون تکرار بشه.
 */
import { randomUUID } from 'node:crypto'
import type { FinancialFieldHistory, Prisma } from '@prisma/client'
import {
  GENESIS_HASH,
  HASH_VERSION,
  canonicalValue,
  computeIdempotencyKey,
  computeRecordHash,
  genesisIdempotencyKey,
} from './financialHash'
import type { FinancialScalar, HashableRecord } from './financialHash'

/** کلاینتی که فقط خواندن تاریخچه را لازم داره (PrismaClient یا tx). */
export type FinancialHistoryReader = Pick<Prisma.TransactionClient, 'financialFieldHistory'>

/** مقدار برای پیام خطا: متن بلند و حساس (مثل دستورالعمل پرداخت) کامل توی لاگ چاپ نشه. */
function preview(value: string | null): string {
  if (value === null) return 'null'
  return value.length > 40 ? `${value.slice(0, 40)}…` : value
}

/** ستونِ جدول اصلی با آخرین مقدار ثبت‌شده در تاریخچه نمی‌خونه. */
export class FinancialDriftError extends Error {
  readonly entityType: string
  readonly entityId: string
  readonly fieldName: string
  readonly historyValue: string | null
  readonly columnValue: string | null

  constructor(
    entityType: string,
    entityId: string,
    fieldName: string,
    historyValue: string | null,
    columnValue: string | null,
  ) {
    super(
      `ناهمخوانی تاریخچه‌ی مالی در ${entityType}#${entityId}.${fieldName}: ` +
        `آخرین مقدار ثبت‌شده «${preview(historyValue)}» ولی مقدار ستون «${preview(columnValue)}» است.`,
    )
    this.name = 'FinancialDriftError'
    this.entityType = entityType
    this.entityId = entityId
    this.fieldName = fieldName
    this.historyValue = historyValue
    this.columnValue = columnValue
  }
}

/**
 * کلید یک‌بارمصرف فرم. روی سرور ساخته می‌شه و در یک input مخفی می‌ره
 * (سایت روی HTTP ساده است و crypto.randomUUID مرورگر در دسترس نیست).
 */
export function newFormKey(): string {
  return randomUUID()
}

export interface AppendFinancialRecordInput {
  entityType: string
  entityId: string
  fieldName: string
  /** مقدار جدید؛ null یعنی «مقدار پاک شد». */
  newValue: FinancialScalar
  /** شناسه‌ی کاربر؛ برای رویداد سیستمی null. */
  changedBy: string | null
  /** کلید یک‌بارمصرف فرم، یا یک کلید یکتا برای هر رویداد سیستمی. */
  formKey: string
  /**
   * فقط Tier B: مقدار فعلیِ ستون جدول اصلی. «بعد» از گرفتن قفل صدا زده می‌شه تا کهنه نباشه.
   * نبودنش یعنی Tier A (مثل رکورد ساخت یک موجودیت تازه که هنوز تاریخچه‌ای نداره).
   */
  readColumn?: () => Promise<FinancialScalar>
}

export type AppendFinancialResult =
  | { outcome: 'created'; seq: number; recordHash: string }
  /** همین فرم (همین کلید) قبلاً ثبت شده؛ رکورد دوم ساخته نشد. */
  | { outcome: 'duplicate' }
  /** مقدار جدید با مقدار فعلی برابره؛ چیزی ساخته نشد. */
  | { outcome: 'unchanged' }

interface ChainTail {
  seq: number
  recordHash: string
}

interface NewRecordFields {
  entityType: string
  entityId: string
  fieldName: string
  oldValue: string | null
  newValue: string | null
  changedBy: string | null
  idempotencyKey: string
}

/** نویسنده‌های یک موجودیت را پشت‌سرهم می‌کنه تا seq و previousRecordHash نشکنه (تا پایان تراکنش). */
async function lockEntityChain(tx: Prisma.TransactionClient, entityType: string, entityId: string): Promise<void> {
  const lockKey = `ffh:${entityType}:${entityId}`
  // عمداً $executeRaw، نه $queryRaw: pg_advisory_xact_lock نوع void برمی‌گردونه و آداپتور pg در
  // queryRaw ستونِ با نوع ناشناخته را رد می‌کنه؛ executeRaw فقط تعداد ردیف را برمی‌گردونه.
  await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${lockKey}))`
}

async function readChainTail(db: FinancialHistoryReader, entityType: string, entityId: string): Promise<ChainTail> {
  const last = await db.financialFieldHistory.findFirst({
    where: { entityType, entityId },
    orderBy: { seq: 'desc' },
    select: { seq: true, recordHash: true },
  })
  return last ?? { seq: 0, recordHash: GENESIS_HASH }
}

async function insertRecord(
  tx: Prisma.TransactionClient,
  tail: ChainTail,
  fields: NewRecordFields,
): Promise<ChainTail> {
  const record: HashableRecord = {
    ...fields,
    seq: tail.seq + 1,
    changedAt: new Date(),
    previousRecordHash: tail.recordHash,
  }
  const recordHash = computeRecordHash(record)
  await tx.financialFieldHistory.create({
    data: { ...record, hashVersion: HASH_VERSION, recordHash },
  })
  return { seq: record.seq, recordHash }
}

/**
 * یک تغییرِ فیلد مالی را به زنجیره‌ی موجودیت اضافه می‌کنه.
 * ترتیب: قفل → idempotency → (genesis / drift) → unchanged → درج در seq+1.
 */
export async function appendFinancialRecord(
  tx: Prisma.TransactionClient,
  input: AppendFinancialRecordInput,
): Promise<AppendFinancialResult> {
  const { entityType, entityId, fieldName, changedBy } = input
  const newValue = canonicalValue(input.newValue)
  const idempotencyKey = computeIdempotencyKey({ entityType, entityId, fieldName, newValue, formKey: input.formKey })

  await lockEntityChain(tx, entityType, entityId)

  const sameKey = await tx.financialFieldHistory.findUnique({ where: { idempotencyKey }, select: { id: true } })
  if (sameKey) return { outcome: 'duplicate' }

  const latest = await tx.financialFieldHistory.findFirst({
    where: { entityType, entityId, fieldName },
    orderBy: { seq: 'desc' },
    select: { newValue: true },
  })
  // undefined = Tier A (ستون نداره)؛ null = ستون هست و خالیه.
  const columnValue = input.readColumn ? canonicalValue(await input.readColumn()) : undefined

  let currentValue: string | null = null
  let needsGenesis = false
  if (latest) {
    currentValue = latest.newValue
    if (columnValue !== undefined && columnValue !== currentValue) {
      throw new FinancialDriftError(entityType, entityId, fieldName, currentValue, columnValue)
    }
  } else if (columnValue !== undefined && columnValue !== null) {
    currentValue = columnValue
    needsGenesis = true
  }

  if (newValue === currentValue) return { outcome: 'unchanged' }

  let tail = await readChainTail(tx, entityType, entityId)
  if (needsGenesis) {
    tail = await insertRecord(tx, tail, {
      entityType,
      entityId,
      fieldName,
      oldValue: null,
      newValue: currentValue,
      changedBy: null,
      idempotencyKey: genesisIdempotencyKey(entityType, entityId, fieldName),
    })
  }
  const created = await insertRecord(tx, tail, {
    entityType,
    entityId,
    fieldName,
    oldValue: currentValue,
    newValue,
    changedBy,
    idempotencyKey,
  })
  return { outcome: 'created', seq: created.seq, recordHash: created.recordHash }
}

/**
 * رکورد «شروع» (genesis) برای فیلد Tier B که هنوز تاریخچه ندارد: عکسِ مقدار فعلی ستون، نه یک رویداد
 * واقعی (oldValue=null، changedBy=null). برای دستور genesis در scripts/financial-history.ts.
 * برای ستون خالی (null) چیزی نمی‌سازه چون «بدون تاریخچه» همان null است.
 * readColumn «بعد» از گرفتن قفل صدا زده می‌شه (مثل appendFinancialRecord) تا مقدار کهنه ثبت نشه.
 * @returns true اگه رکورد ساخته شد
 */
export async function ensureGenesisRecord(
  tx: Prisma.TransactionClient,
  input: { entityType: string; entityId: string; fieldName: string; readColumn: () => Promise<FinancialScalar> },
): Promise<boolean> {
  const { entityType, entityId, fieldName } = input

  await lockEntityChain(tx, entityType, entityId)
  const existing = await tx.financialFieldHistory.findFirst({
    where: { entityType, entityId, fieldName },
    select: { id: true },
  })
  if (existing) return false

  const value = canonicalValue(await input.readColumn())
  if (value === null) return false

  const tail = await readChainTail(tx, entityType, entityId)
  await insertRecord(tx, tail, {
    entityType,
    entityId,
    fieldName,
    oldValue: null,
    newValue: value,
    changedBy: null,
    idempotencyKey: genesisIdempotencyKey(entityType, entityId, fieldName),
  })
  return true
}

/** آخرین مقدار ثبت‌شده‌ی یک فیلد (Tier A)؛ بدون تاریخچه null. */
export async function getCurrentValue(
  db: FinancialHistoryReader,
  entityType: string,
  entityId: string,
  fieldName: string,
): Promise<string | null> {
  const latest = await db.financialFieldHistory.findFirst({
    where: { entityType, entityId, fieldName },
    orderBy: { seq: 'desc' },
    select: { newValue: true },
  })
  return latest?.newValue ?? null
}

/** تاریخچه‌ی یک موجودیت (یا فقط یک فیلدش) به ترتیب seq صعودی. */
export async function getHistory(
  db: FinancialHistoryReader,
  entityType: string,
  entityId: string,
  fieldName?: string,
): Promise<FinancialFieldHistory[]> {
  return db.financialFieldHistory.findMany({
    where: fieldName === undefined ? { entityType, entityId } : { entityType, entityId, fieldName },
    orderBy: { seq: 'asc' },
  })
}
