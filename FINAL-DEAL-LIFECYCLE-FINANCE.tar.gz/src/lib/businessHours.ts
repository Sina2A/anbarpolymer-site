import prisma from './prisma'
import { tehranDateKey, tehranDayOfWeek, tehranWallTimeToInstant } from './tehranClock'

/**
 * موتور محاسبه‌ی مهلت بر اساس «ساعت کاری» — نه روز تقویمی، نه ساعت تقویمی خام.
 *
 * اولویت‌بندی (طبق تصمیم صریح سینا):
 *   ۱. جدول Holiday — یه روز خاص با تاریخ مشخص، همیشه حرف آخر رو می‌زنه.
 *      اگه یه روز اونجا ثبت شده باشه (چه جمعه چه نه)، کل اون روز غیرکاریه.
 *   ۲. اگه روز توی Holiday نبود، جدول WeeklyBusinessHour (الگوی تکرارشونده‌ی
 *      هرهفته) تعیین می‌کنه اون روز از هفته اصلاً بازه یا نه، و از ساعت چند
 *      تا ساعت چند.
 *
 * محاسبه‌ی «N ساعت کاری از X» یعنی: از لحظه‌ی X شروع کن، فقط بازه‌های باز
 * (طبق قانون بالا) رو بشمار، و هروقت N ساعت واقعی سپری شد، همون لحظه مهلته.
 */

// dateKey/روزِ‌هفته/ساختِ مرزهای بازه به وقت تهران محاسبه می‌شوند (نه UTCِ سرور) —
// از tehranClock. این تنها نقطه‌ای بود که تبدیل instant→«ساعتِ دیواری» رخ می‌داد و
// روی سرورِ UTC ۳.۵ ساعت خطا داشت.
function dateKey(d: Date): string {
  return tehranDateKey(d)
}
function parseHM(hm: string): { h: number; m: number } {
  const [h, m] = hm.split(':').map((x) => parseInt(x, 10))
  return { h: h || 0, m: m || 0 }
}

type DaySchedule = { isOpen: boolean; openTime: string; closeTime: string }

async function loadCalendars() {
  const [holidays, weekly] = await Promise.all([
    prisma.holiday.findMany(),
    prisma.weeklyBusinessHour.findMany(),
  ])
  const holidaySet = new Set(holidays.map((h) => dateKey(h.date)))
  const weeklyMap = new Map<number, DaySchedule>()
  for (const w of weekly) {
    weeklyMap.set(w.dayOfWeek, { isOpen: w.isOpen, openTime: w.openTime, closeTime: w.closeTime })
  }
  return { holidaySet, weeklyMap }
}

/** برای یه روز مشخص، بازه‌ی بازبودنش رو برمی‌گردونه (یا null اگه کلاً تعطیله). */
function getDaySchedule(
  day: Date,
  holidaySet: Set<string>,
  weeklyMap: Map<number, DaySchedule>
): { start: Date; end: Date } | null {
  if (holidaySet.has(dateKey(day))) return null // اولویت با Holiday

  const schedule = weeklyMap.get(tehranDayOfWeek(day))
  // روزِ بدون ردیف در WeeklyBusinessHour «بسته» حساب می‌شه (تصمیم صریح)، نه باز. ردیف‌ها با
  // scripts/seed-business-hours.ts پر می‌شن؛ جدول خالی یعنی هیچ روزی باز نیست.
  if (!schedule || !schedule.isOpen) return null

  const { h: oh, m: om } = parseHM(schedule.openTime)
  const { h: ch, m: cm } = parseHM(schedule.closeTime)
  // مرزهای بازه به‌عنوان instant مطلقِ متناظر با «ساعتِ دیواریِ تهرانِ همان روز» ساخته می‌شوند
  // تا مقایسه با cursor/now (Date مطلق) درست باشد — نه setHours که روی UTCِ سرور می‌نشیند.
  const start = tehranWallTimeToInstant(day, oh, om)
  const end = tehranWallTimeToInstant(day, ch, cm)
  if (end <= start) return null // تنظیم نامعتبر — رفتار امن: بسته حساب کن
  return { start, end }
}

/**
 * از لحظه‌ی `start`، `hours` ساعتِ کاری واقعی جلو می‌ره و لحظه‌ی دقیق مهلت رو
 * برمی‌گردونه. اگه `start` خودش بیرون از ساعت کاری باشه (مثلاً نصف‌شب یا روز
 * تعطیل)، اول به نزدیک‌ترین لحظه‌ی باز بعدی می‌پره.
 */
export async function calculateBusinessHoursDeadline(start: Date, hours: number): Promise<Date> {
  const { holidaySet, weeklyMap } = await loadCalendars()

  let remainingMs = hours * 60 * 60 * 1000
  let cursor = new Date(start)
  // لنگرِ روز = ساعت ۰۰:۰۰ به وقتِ تهرانِ همان روز، به‌صورت instant مطلق. با UTC-midnightِ
  // setHours ممکن بود نزدیکِ مرزِ روز به روزِ تهرانیِ اشتباه بیفتد؛ این‌طور دقیق است.
  let cursorDay = tehranWallTimeToInstant(cursor, 0, 0)

  // محافظ ضد حلقه‌ی بی‌نهایت: اگه همه‌ی روزها بسته باشن (جدول WeeklyBusinessHour خالیه، یا همه‌ی
  // ردیف‌ها بسته‌ان) هیچ روز بازی پیدا نمی‌شه و باید خطای بلند بدیم، نه مهلتِ اشتباه.
  let safety = 0
  const SAFETY_LIMIT = 400 // بیشتر از یه سال روزانه، کافیه

  while (remainingMs > 0) {
    safety += 1
    if (safety > SAFETY_LIMIT) {
      throw new Error(
        `محاسبه‌ی مهلت ساعت‌کاری: در ${SAFETY_LIMIT} روز پیاپی هیچ روز بازی پیدا نشد. ` +
          'روزِ بدون ردیف در WeeklyBusinessHour بسته حساب می‌شود؛ اگر جدول خالی است scripts/seed-business-hours.ts را با --apply اجرا کنید، ' +
          'وگرنه ساعات هفتگی و تعطیلات را در پنل ادمین بررسی کنید.'
      )
    }

    const sched = getDaySchedule(cursorDay, holidaySet, weeklyMap)
    if (sched) {
      const windowStart = cursor > sched.start ? cursor : sched.start
      if (windowStart < sched.end) {
        const availableMs = sched.end.getTime() - windowStart.getTime()
        if (availableMs >= remainingMs) {
          cursor = new Date(windowStart.getTime() + remainingMs)
          remainingMs = 0
          break
        } else {
          remainingMs -= availableMs
        }
      }
    }

    // برو روز بعد، از اول روز
    cursorDay = new Date(cursorDay.getTime() + 24 * 60 * 60 * 1000)
    cursor = new Date(cursorDay)
  }

  return cursor
}

/** آیا همین الان توی بازه‌ی ساعت کاریه؟ (برای تصمیم‌های آنی، نه محاسبه‌ی مهلت) */
export async function isWithinBusinessHours(at: Date = new Date()): Promise<boolean> {
  const { holidaySet, weeklyMap } = await loadCalendars()
  const day = tehranWallTimeToInstant(at, 0, 0) // لنگرِ روز به وقت تهران
  const sched = getDaySchedule(day, holidaySet, weeklyMap)
  if (!sched) return false
  return at >= sched.start && at < sched.end
}

// ==================== مدیریت ساعات کاری هفتگی (فقط مدیر) ====================

const DAY_LABELS_FA = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه']

export async function listWeeklyBusinessHours() {
  const rows = await prisma.weeklyBusinessHour.findMany({ orderBy: { dayOfWeek: 'asc' } })
  const byDay = new Map(rows.map((r) => [r.dayOfWeek, r]))
  // روزِ بدون ردیف همان‌طور نمایش داده می‌شه که موتور مهلت رفتار می‌کنه: بسته (بدون ذخیره)؛
  // ساعت‌های ۰۸–۱۷ فقط مقدار اولیه‌ی فرم‌اند.
  return Array.from({ length: 7 }, (_, dayOfWeek) => {
    const existing = byDay.get(dayOfWeek)
    return {
      dayOfWeek,
      label: DAY_LABELS_FA[dayOfWeek],
      isOpen: existing?.isOpen ?? false,
      openTime: existing?.openTime ?? '08:00',
      closeTime: existing?.closeTime ?? '17:00',
    }
  })
}

export async function upsertWeeklyBusinessHour(dayOfWeek: number, isOpen: boolean, openTime: string, closeTime: string) {
  await prisma.weeklyBusinessHour.upsert({
    where: { dayOfWeek },
    update: { isOpen, openTime, closeTime },
    create: { dayOfWeek, isOpen, openTime, closeTime },
  })
}
