/**
 * زنجیره‌ی Hash (SHA-256) برای اثبات عدم‌دستکاریِ تاریخچه‌ی فیلدهای مالی.
 *
 * هر رکورد FinancialFieldHistory یک recordHash داره که «hash رکورد قبلیِ همان موجودیت» هم
 * جزو ورودیشه. تغییر، حذف یا جابه‌جایی هر رکورد زنجیره را می‌شکنه و verifyChain اولین نقطه‌ی
 * شکست را گزارش می‌ده. دامنه‌ی زنجیره: هر (entityType, entityId) یک زنجیره‌ی جدا.
 *
 * محدوده‌ی صداقت (باید صریح گفته بشه):
 *  - hash «اثبات تغییرنکردن» است، نه جلوگیری. جلوگیری با تریگر دیتابیس انجام می‌شه.
 *  - کسی که هم رکوردها و هم همه‌ی hashهای بعدی را بازنویسی کنه یا رکوردهای «انتهای» زنجیره را
 *    حذف کنه، فقط با «لنگر» بیرونی (دستور anchor در scripts/financial-history.ts) قابل‌کشفه.
 *
 * این فایل فقط node:crypto داره (بدون Prisma) تا بدون دیتابیس تست بشه. چون node:crypto را
 * وارد می‌کنه، هرگز نباید در کامپوننت کلاینتی import بشه. 'use server' هم نداره.
 */
import { createHash } from 'node:crypto'

/** نسخه‌ی الگوریتم hash؛ در ستون hashVersion ذخیره می‌شه تا تغییر آینده، رکوردهای قدیمی را نشکنه. */
export const HASH_VERSION = 1

/** previousRecordHash رکورد اول هر زنجیره. */
export const GENESIS_HASH = '0'.repeat(64)

export class FinancialHashError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'FinancialHashError'
  }
}

export function sha256Hex(text: string): string {
  return createHash('sha256').update(text, 'utf8').digest('hex')
}

/** نوع‌های اسکالری که می‌تونن به‌عنوان مقدار فیلد مالی ثبت بشن. */
export type FinancialScalar = string | number | boolean | bigint | Date | null | undefined

function assertNoNul(label: string, value: string): void {
  // Postgres کاراکتر NUL را در text نمی‌پذیره؛ زودتر و تمیز رد می‌کنیم تا hash با مقدار ذخیره‌شده یکی بمونه.
  if (value.includes('\u0000')) {
    throw new FinancialHashError(`${label} شامل کاراکتر NUL است.`)
  }
}

/**
 * مقدار اسکالر → رشته‌ی کانونیک (یا null). عدد: همان String(n) (و -0 → "0")؛
 * Date: ISO؛ شیء/آرایه مجاز نیست.
 */
export function canonicalValue(value: FinancialScalar): string | null {
  if (value === null || value === undefined) return null
  let out: string
  switch (typeof value) {
    case 'string':
      out = value
      break
    case 'number':
      if (!Number.isFinite(value)) throw new FinancialHashError('مقدار عددی نامعتبره.')
      out = Object.is(value, -0) ? '0' : String(value)
      break
    case 'boolean':
      out = value ? 'true' : 'false'
      break
    case 'bigint':
      out = value.toString()
      break
    default:
      if (value instanceof Date) {
        if (Number.isNaN(value.getTime())) throw new FinancialHashError('تاریخ نامعتبره.')
        out = value.toISOString()
      } else {
        throw new FinancialHashError('نوع مقدار پشتیبانی نمی‌شه.')
      }
  }
  assertNoNul('مقدار', out)
  return out
}

export interface IdempotencyKeyInput {
  entityType: string
  entityId: string
  fieldName: string
  newValue: FinancialScalar
  /** کلید یک‌بارمصرفِ فرم (یا کلید قطعیِ سیستمی مثل sys:<event>:<id>). */
  formKey: string
}

/**
 * کلید Idempotency = hash( موجودیت + فیلد + مقدار جدید + کلید فرم ).
 * ارسال دوباره‌ی همان فرم (دابل‌کلیک، رفرش، retry) کلید یکسان می‌ده و رکورد دوم نمی‌سازه؛
 * مقدار متفاوت یا فرم تازه کلید متفاوت می‌ده.
 */
export function computeIdempotencyKey(input: IdempotencyKeyInput): string {
  if (!input.formKey) throw new FinancialHashError('formKey الزامیه.')
  assertNoNul('formKey', input.formKey)
  assertNoNul('entityType', input.entityType)
  assertNoNul('entityId', input.entityId)
  assertNoNul('fieldName', input.fieldName)
  return sha256Hex(
    JSON.stringify([
      input.entityType,
      input.entityId,
      input.fieldName,
      canonicalValue(input.newValue),
      input.formKey,
    ]),
  )
}

/** کلید قطعیِ رکورد «شروع» (genesis) برای هر فیلد؛ تضمین می‌کنه برای هر فیلد حداکثر یک genesis وجود داره. */
export function genesisIdempotencyKey(entityType: string, entityId: string, fieldName: string): string {
  return `genesis:${entityType}:${entityId}:${fieldName}`
}

/** فیلدهایی که در recordHash شرکت می‌کنن (همه‌ی ستون‌ها به‌جز id و خودِ recordHash). */
export interface HashableRecord {
  seq: number
  entityType: string
  entityId: string
  fieldName: string
  oldValue: string | null
  newValue: string | null
  changedBy: string | null
  changedAt: Date
  idempotencyKey: string
  previousRecordHash: string
}

export interface ChainRecord extends HashableRecord {
  recordHash: string
  /** اگه نباشه HASH_VERSION فرض می‌شه. */
  hashVersion?: number
}

/**
 * hash رکورد. ورودی یک آرایه‌ی JSON با ترتیب ثابته (نه الحاق رشته‌ها) تا مرز فیلدها مبهم نشه
 * و «a|b» + «c» با «a» + «b|c» یکی حساب نشه.
 */
export function computeRecordHash(record: HashableRecord, version: number = HASH_VERSION): string {
  if (version !== HASH_VERSION) throw new FinancialHashError(`نسخه‌ی hash پشتیبانی نمی‌شه: ${version}`)
  if (!Number.isSafeInteger(record.seq) || record.seq < 1) throw new FinancialHashError('seq نامعتبره.')
  if (!(record.changedAt instanceof Date) || Number.isNaN(record.changedAt.getTime())) {
    throw new FinancialHashError('changedAt نامعتبره.')
  }
  const strings: [string, string | null][] = [
    ['entityType', record.entityType],
    ['entityId', record.entityId],
    ['fieldName', record.fieldName],
    ['oldValue', record.oldValue],
    ['newValue', record.newValue],
    ['changedBy', record.changedBy],
    ['idempotencyKey', record.idempotencyKey],
    ['previousRecordHash', record.previousRecordHash],
  ]
  for (const [label, value] of strings) {
    if (value !== null) assertNoNul(label, value)
  }
  return sha256Hex(
    JSON.stringify([
      `FFH${version}`,
      record.entityType,
      record.entityId,
      record.seq,
      record.fieldName,
      record.oldValue,
      record.newValue,
      record.changedBy,
      record.changedAt.toISOString(),
      record.idempotencyKey,
      record.previousRecordHash,
    ]),
  )
}

export type ChainFailureReason =
  | 'mixed-entity'
  | 'seq-gap'
  | 'seq-duplicate'
  | 'unsupported-hash-version'
  | 'broken-link'
  | 'invalid-record'
  | 'hash-mismatch'
  | 'old-value-mismatch'

export type ChainVerification =
  | {
      ok: true
      count: number
      /** recordHash آخرین رکورد (برای لنگر بیرونی)؛ برای زنجیره‌ی خالی null. */
      tipHash: string | null
    }
  | { ok: false; atSeq: number; reason: ChainFailureReason; detail: string }

/**
 * صحت یک زنجیره را (رکوردهای یک موجودیت) بررسی می‌کنه و «اولین» شکست را برمی‌گردونه:
 *  ۱. همه‌ی رکوردها مال یک موجودیت باشن؛
 *  ۲. seq از ۱ پیوسته باشه (حذف رکورد وسط → seq-gap)؛
 *  ۳. previousRecordHash هر رکورد برابر recordHash قبلی باشه (رکورد اول: GENESIS_HASH)؛
 *  ۴. recordHash بازمحاسبه‌شده با مقدار ذخیره‌شده یکی باشه (تغییر هر ستون → hash-mismatch)؛
 *  ۵. برای هر فیلد، oldValue برابر newValue آخرین رکورد همان فیلد باشه.
 * ترتیب ورودی مهم نیست؛ بر اساس seq مرتب می‌شه.
 */
export function verifyChain(records: readonly ChainRecord[]): ChainVerification {
  if (records.length === 0) return { ok: true, count: 0, tipHash: null }

  const ordered = records.slice().sort((a, b) => a.seq - b.seq)
  const { entityType, entityId } = ordered[0]

  let expectedSeq = 1
  let previousHash = GENESIS_HASH
  const lastNewValueByField = new Map<string, string | null>()

  for (const record of ordered) {
    const failure = (reason: ChainFailureReason, detail: string): ChainVerification => ({
      ok: false,
      atSeq: record.seq,
      reason,
      detail,
    })

    if (record.entityType !== entityType || record.entityId !== entityId) {
      return failure('mixed-entity', 'رکورد متعلق به موجودیت دیگری است.')
    }
    if (record.seq < expectedSeq) {
      return failure('seq-duplicate', `seq تکراری: ${record.seq}`)
    }
    if (record.seq > expectedSeq) {
      return {
        ok: false,
        atSeq: expectedSeq,
        reason: 'seq-gap',
        detail: `رکورد seq=${expectedSeq} وجود نداره (رکورد بعدی seq=${record.seq} است).`,
      }
    }
    if ((record.hashVersion ?? HASH_VERSION) !== HASH_VERSION) {
      return failure('unsupported-hash-version', `hashVersion=${record.hashVersion}`)
    }
    if (record.previousRecordHash !== previousHash) {
      return failure('broken-link', 'previousRecordHash با hash رکورد قبلی نمی‌خونه.')
    }

    let recomputed: string
    try {
      recomputed = computeRecordHash(record)
    } catch (err) {
      return failure('invalid-record', err instanceof Error ? err.message : 'رکورد نامعتبره.')
    }
    if (recomputed !== record.recordHash) {
      return failure('hash-mismatch', 'recordHash با محتوای رکورد نمی‌خونه (رکورد دست‌کاری شده).')
    }

    if (lastNewValueByField.has(record.fieldName)) {
      const previousNew = lastNewValueByField.get(record.fieldName) ?? null
      if (record.oldValue !== previousNew) {
        return failure('old-value-mismatch', `oldValue فیلد ${record.fieldName} با مقدار قبلی نمی‌خونه.`)
      }
    }
    lastNewValueByField.set(record.fieldName, record.newValue)

    previousHash = record.recordHash
    expectedSeq += 1
  }

  return { ok: true, count: ordered.length, tipHash: previousHash }
}
