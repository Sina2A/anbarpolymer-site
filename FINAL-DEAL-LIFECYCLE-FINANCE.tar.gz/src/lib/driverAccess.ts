import crypto from 'crypto'
import prisma from './prisma'

const LINK_VALID_HOURS = 48

/**
 * برای هر Deal که وارد مرحله‌ی بارگیری یا تخلیه می‌شه، این تابع صدا زده می‌شه.
 * یه توکن یک‌بارمصرف می‌سازه که فقط با همون لینک (نه با ساخت حساب) قابل‌دسترسیه.
 * ارسال واقعی پیامک هنوز جدا و نیاز به یه سرویس SMS داره — این فقط لینک رو می‌سازه.
 */
export async function createDriverAccessLink(dealId: string, phone: string) {
  const token = crypto.randomBytes(24).toString('hex')
  const expiresAt = new Date(Date.now() + LINK_VALID_HOURS * 60 * 60 * 1000)

  await prisma.driverAccessLink.create({
    data: { dealId, phone, token, expiresAt },
  })

  return token
}

export async function validateDriverToken(token: string) {
  const link = await prisma.driverAccessLink.findUnique({
    where: { token },
    // payments (فقط kind/status): برای گیتِ فرم بارگیری — هر دو پرداخت باید APPROVED باشند (bothPaymentsApproved).
    include: { deal: { include: { confirmations: true, payments: { select: { kind: true, status: true } } } } },
  })

  if (!link) return { valid: false, reason: 'لینک نامعتبره.' as const, link: null }
  if (link.usedAt) return { valid: false, reason: 'این لینک قبلاً استفاده شده.' as const, link: null }
  if (link.expiresAt < new Date()) return { valid: false, reason: 'این لینک منقضی شده.' as const, link: null }

  return { valid: true, reason: null, link }
}

export async function markDriverLinkUsed(token: string) {
  await prisma.driverAccessLink.update({
    where: { token },
    data: { usedAt: new Date() },
  })
}

/**
 * یک لینک برای کل مسیر راننده: پذیرش سفر ← بارگیری ← تخلیه. لینک فقط با «تایید تخلیه»
 * مصرف می‌شود (markDriverLinkUsed)، ولی مسیر می‌تواند چند روز طول بکشد و ۴۸ساعتِ اولیه
 * وسط راه تمام می‌شود. پس بعد از هر مرحله (پذیرش، بارگیری) انقضا از همین لحظه تا
 * `validDays` روز تقویمی جلو می‌رود. `validDays` از پنل ادمین می‌آید
 * (Deal rules → driverLinkValidDays) و عدد ثابت نیست؛ مستقل از آستانه‌ی هشدار سکوت راننده
 * (driverSilenceDays) است، تا تغییر یکی ناخواسته دیگری را عوض نکند. اگر لینک وسط راه
 * منقضی شود، ادمین لینک تازه می‌سازد (regenerateDriverLinkAction).
 * انقضا هیچ‌وقت عقب نمی‌رود: کمتر کردن تنظیم، لینکی که قبلاً بیشتر تمدید شده را کوتاه نمی‌کند.
 */
export async function extendDriverLinkForTrip(token: string, validDays: number) {
  const newExpiry = new Date(Date.now() + validDays * 24 * 60 * 60 * 1000)
  await prisma.driverAccessLink.updateMany({
    where: { token, usedAt: null, expiresAt: { lt: newExpiry } },
    data: { expiresAt: newExpiry },
  })
}

/**
 * وضعیت‌هایی که فرم بارگیری/تخلیه‌ی راننده در آن‌ها باز است — منبع واحد برای صفحه‌ی
 * /driver/[token] و Server Action ثبت (تا فرمِ نمایش‌داده‌شده و فرمِ قابل‌ثبت از هم جدا نشوند).
 * `confirmed` و `payment_secured` وضعیت‌های قدیمیِ مسیر بارگیری‌اند و برای سازگاری می‌مانند؛
 * مسیر فعلیِ بعد از تایید دو پرداخت `transport_pending` است.
 */
export const DRIVER_LOADING_STATUSES = ['transport_pending', 'confirmed', 'payment_secured']
export const DRIVER_UNLOADING_STATUSES = ['in_transit']

export type DriverFormType = 'loading' | 'unloading'

export function driverFormTypeForStatus(status: string): DriverFormType | null {
  if (DRIVER_LOADING_STATUSES.includes(status)) return 'loading'
  if (DRIVER_UNLOADING_STATUSES.includes(status)) return 'unloading'
  return null
}

/**
 * فرم بارگیری فقط وقتی باز است که هر دو پرداختِ معامله (وجه کالای خریدار و کارمزد فروشنده) توسط مدیر/کارشناس
 * APPROVED شده باشد. منبع واحد برای صفحه‌ی /driver/[token] (نمایش فرم) و Server Action ثبت (پیش‌بررسی و
 * شرطِ اتمیکِ updateMany) تا فرمِ نمایش‌داده‌شده و فرمِ قابل‌ثبت از هم جدا نشوند.
 */
export const DRIVER_REQUIRED_PAYMENT_KINDS = ['BUYER_GOODS', 'SELLER_FEE'] as const

export function bothPaymentsApproved(payments: ReadonlyArray<{ kind: string; status: string }>): boolean {
  return DRIVER_REQUIRED_PAYMENT_KINDS.every((kind) => payments.some((p) => p.kind === kind && p.status === 'APPROVED'))
}
