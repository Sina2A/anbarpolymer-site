import type { Prisma } from '@prisma/client'
import prisma from './prisma'
import { calculateBusinessHoursDeadline } from './businessHours'
import { logStatusEvent } from './statusEvents'
import { evaluateApprovalRequirement } from './priceEngine'
import { MoneyCalcError, dealApprovalAmountToman } from './money'
import { resolveSellerId } from './dealRoles'
import { queueSms } from './smsQueue'
import { logEvent } from './logger'
import { dealItemRef, releaseItemInTx, notifyPromoted, enforceReservationQueueClaims } from './reservationQueue'
import { checkPriceAlerts } from '@/app/price-alerts/actions'

const RESTRICTION_HOURS = 24 // این یکی جدا از قوانین معامله‌ست (محدودیت حساب، نه مهلت معامله)، فعلاً ثابت می‌مونه

// مقادیر پیش‌فرض — دقیقاً همون چیزی که تا امروز توی کد ثابت بود. اگه هیچ‌وقت
// کارشناسی از پنل تنظیمش نکنه، رفتار سایت هیچ فرقی نمی‌کنه.
const DEFAULT_RULES = {
  sellerFeeHours: 24,
  buyerPaymentHours: 72,
  discrepancyReportHours: 4,
  fundReleaseHours: 8,
  driverLinkValidDays: 5,
  driverSilenceDays: 5,
  proformaConfirmHours: 8,
}

export type DealRuleValues = typeof DEFAULT_RULES

/** خواندن مقادیر فعلی قوانین — اگه هنوز هیچ‌کس تنظیمی نساخته، پیش‌فرض‌ها برمی‌گردن. */
export async function getDealRuleSettings(): Promise<DealRuleValues> {
  const row = await prisma.dealRuleSettings.findUnique({ where: { id: 'singleton' } })
  if (!row) return DEFAULT_RULES
  return {
    sellerFeeHours: row.sellerFeeHours,
    buyerPaymentHours: row.buyerPaymentHours,
    discrepancyReportHours: row.discrepancyReportHours,
    fundReleaseHours: row.fundReleaseHours,
    driverLinkValidDays: row.driverLinkValidDays,
    driverSilenceDays: row.driverSilenceDays,
    proformaConfirmHours: row.proformaConfirmHours,
  }
}

export async function updateDealRuleSettings(values: DealRuleValues, updatedById: string) {
  await prisma.dealRuleSettings.upsert({
    where: { id: 'singleton' },
    update: { ...values, updatedById },
    create: { id: 'singleton', ...values, updatedById },
  })
}

/**
 * این تابع رو باید هر جا صفحه‌ی مرتبط لود می‌شه صدا زد (بازار صنعتی، پنل کاربری، پنل ادمین).
 * چون هنوز job scheduler/cron جدا نداریم، به‌جاش هر بار که یکی از این صفحات باز می‌شه،
 * این تابع خودش چک می‌کنه آیا مهلتی گذشته یا نه — یه الگوی ساده و رایج برای MVP،
 * بدون نیاز به زیرساخت جداگانه.
 */
export async function enforceDealDeadlines() {
  const rules = await getDealRuleSettings()
  const sellerExpired = await enforceSellerFeeDeadlines()
  const buyerExpired = await enforceBuyerPaymentDeadlines()
  const dealSellerExpired = await enforceDealSellerFeeDeadlines()
  const discrepancyWindowClosed = await enforceDiscrepancyWindowClose()
  const driverSilenceFlagged = await enforceDriverSilenceEscalation(rules)
  return {
    cancelledCount: sellerExpired + buyerExpired + dealSellerExpired,
    qualityAutoAcceptedCount: discrepancyWindowClosed,
    driverSilenceFlaggedCount: driverSilenceFlagged,
  }
}

/**
 * لغوِ اتمیکِ یک معامله + آزادسازیِ queue-aware موردِ رزروشده‌اش در «یک» تراکنش
 * (آگهی برای معامله‌ی SELL، درخواست خرید برای BUY). `guard` همان گاردِ وضعیتی است که
 * enforcer قبلاً روی updateMany داشت؛ false یعنی تیکِ موازی/تکراری زودتر پردازشش کرده
 * (count===0) و فراخوان باید از side-effectها (محدودسازی و ...) صرف‌نظر کند.
 * به‌جای برگرداندنِ مستقیمِ مورد به active/open، نفرِ بعدیِ صف مطلع می‌شود و فقط اگر صفی
 * نباشد مورد به بازار برمی‌گردد. اعلانِ صف بعد از commit فرستاده می‌شود.
 */
async function cancelGuardedDealAndRelease(
  deal: {
    id: string
    tradeDirection: string | null
    materialListingId: string | null
    purchaseRequestId: string | null
  },
  guard: Prisma.DealWhereInput,
): Promise<boolean> {
  const ref = dealItemRef(deal)
  const outcome = await prisma.$transaction(async (tx) => {
    const res = await tx.deal.updateMany({
      where: { id: deal.id, ...guard },
      data: { status: 'cancelled' },
    })
    if (res.count === 0) return { won: false as const }
    const promote = ref ? await releaseItemInTx(tx, ref.itemType, ref.itemId) : null
    return { won: true as const, promote }
  })
  if (!outcome.won) return false
  if (ref && outcome.promote) await notifyPromoted(ref.itemType, ref.itemId, outcome.promote)
  return true
}

/**
 * enforcement سطح معامله: هر Deal در وضعیت confirmed که مهلت پرداخت کارمزد فروشنده‌اش (sellerFeeDeadline)
 * گذشته باشد لغو می‌شود. مورد رزروشده‌اش (آگهی یا درخواست خرید) از مسیر صفِ رزرو آزاد می‌شود
 * (cancelGuardedDealAndRelease) و فروشنده‌اش به مدت RESTRICTION_HOURS محدود می‌شود؛
 * اگر معامله به هیچ موردی متصل نباشد فقط لغو می‌شود.
 * معامله‌ای که SELLER_FEE آن APPROVED است لغو و جریمه نمی‌شود: فروشنده کارمزد را پرداخته و مهلتِ باقی‌مانده
 * (sellerFeeDeadline) کهنه است؛ ادامه‌ی کار با مهلت پرداخت خریدار (enforceBuyerPaymentDeadlines) است.
 * این تابع با enforceSellerFeeDeadlines (که روی MaterialListing کار می‌کند) تفاوت دارد و آن را نقض نمی‌کند:
 * آن تابع آگهیِ دارای معامله‌ی confirmed با sellerFeeDeadline را رد می‌کند و پنجره‌ی این‌جا را کوتاه نمی‌کند.
 */
async function enforceDealSellerFeeDeadlines() {
  const now = new Date()
  // شرطِ «کارمزد تاییدنشده» هم در انتخاب و هم در گاردِ اتمیکِ لغو هست: تایید بین findMany و لغو هم جریمه نمی‌شود.
  const feeNotApproved: Prisma.DealWhereInput = { payments: { none: { kind: 'SELLER_FEE', status: 'APPROVED' } } }
  const overdue = await prisma.deal.findMany({
    where: {
      status: 'confirmed',
      sellerFeeDeadline: { not: null, lt: now },
      ...feeNotApproved,
    },
    include: { materialListing: true },
  })

  let count = 0
  for (const deal of overdue) {
    // گاردِ وضعیت (اتمیک): فقط اگر معامله هنوز دقیقاً confirmed است (و کارمزدش هنوز تایید نشده) لغو کن.
    // اگر یک تیکِ موازی/تکراری قبلاً همین را پردازش کرده باشد false برمی‌گردد و از side-effect صرف‌نظر می‌کنیم.
    const cancelled = await cancelGuardedDealAndRelease(deal, { status: 'confirmed', ...feeNotApproved })
    if (!cancelled) continue

    // فروشنده = snapshotِ sellerId با فالبک به آگهی (legacy) — این‌طور BUY هم پوشش داده می‌شود
    const sellerId = resolveSellerId(deal)
    if (sellerId) {
      await restrictUser(sellerId, RESTRICTION_HOURS, 'کارمزد فروش در مهلت مقرر پرداخت نشد')
    }
    count++
  }

  return count
}

/** وضعیت‌هایی که معامله از مرحله‌ی پرداخت کارمزد گذشته؛ ساعتِ سطحِ آگهی برایشان کهنه است. */
const FEE_CLOCK_SUPERSEDED_STATUSES = ['transport_pending', 'payment_secured', 'loading', 'in_transit', 'delivered', 'settled']
/** وضعیت‌های پیش از حمل؛ فقط وقتی SELLER_FEE تایید شده باشد ساعتِ آگهی کهنه حساب می‌شود. */
const FEE_CLOCK_PRE_TRANSPORT_STATUSES = ['draft', 'awaiting_approval', 'confirmed']

/**
 * فروشنده کارمزد رو سر وقت نداده → آگهی به‌جای بازگشت فوری به بازار، می‌ره
 * تو حالت «نیازمند بررسی مجدد» (needs_reverification) — چون ممکنه موجودی
 * فروشنده واقعاً عوض شده باشه. کارشناس باید دستی تایید کنه.
 * توجه: طول خودِ مهلت (feeDeadline) قبلاً توی startSellerFeeDeadline با
 * مقدار وقتِ آن لحظه محاسبه و ذخیره شده — این تابع فقط چک می‌کنه گذشته یا نه.
 *
 * feeStatus هیچ‌جا به paid نمی‌رسد (کارمزد در مدل v2 روی DealPayment/SELLER_FEE تایید می‌شود،
 * نه روی آگهی)، پس «unpaid + feeDeadline گذشته» به‌تنهایی نشانه‌ی تخلف نیست. قبل از اعمالِ
 * جریمه چک می‌کنیم کارمزدِ معامله‌ی همین آگهی قبلاً تایید نشده یا معامله از مرحله‌ی
 * کارمزد عبور نکرده باشد (FEE_CLOCK_SUPERSEDED_*)؛ در آن حالت ساعتِ آگهی کهنه است و فقط پاک
 * می‌شود.
 * ساعتِ آگهی (T0) موقع ساختِ پیش‌نویس شروع می‌شود، ولی ساعتِ کارمزد باید از «تایید» شروع شود: معامله‌ی
 * confirmed که ساعتِ سطحِ معامله‌اش (Deal.sellerFeeDeadline، T1) پر است زیرِ نظرِ enforceDealSellerFeeDeadlines
 * است و T0 پنجره‌ی آن را کوتاه نمی‌کند (ساعتِ آگهی فقط پاک می‌شود). پیش‌نویس (draft) و معامله‌ی confirmed بدون T1
 * هم‌چنان با T0 منقضی می‌شوند.
 * معامله‌ی awaiting_approval هم ساعتِ آگهی را کهنه می‌کند: فروشنده پیشنهاد را پذیرفته و معامله منتظر تایید ادمین است؛
 * تاخیرِ ادمین نباید فروشنده را جریمه کند و معامله را لغو کند. ساعتِ کارمزد (T1) بعد از تاییدِ ادمین از نو شروع
 * می‌شود (approveDealAction → startBuyerPaymentDeadline)، پس این‌جا فقط T0ی کهنه پاک می‌شود.
 * لغوِ معامله‌ها با flipِ آگهی اتمیک است و آگهی عمداً به صف نمی‌رود (مثل لغوِ
 * درخواست‌دهنده در cancelDealAction): در needs_reverification می‌ماند تا ادمین دستی تایید کند،
 * و همان‌جا releaseItemInTx(from='needs_reverification') نوبتِ نفر اولِ صف را باز می‌کند.
 */
async function enforceSellerFeeDeadlines() {
  const now = new Date()
  const overdue = await prisma.materialListing.findMany({
    where: {
      feeStatus: 'unpaid',
      feeDeadline: { lt: now },
      validityStatus: 'reserved',
    },
  })

  let count = 0
  for (const listing of overdue) {
    const outcome = await prisma.$transaction(async (tx) => {
      // ساعتِ آگهی کهنه است اگر معامله‌ی همین آگهی از مرحله‌ی کارمزد گذشته (transport_pending به بعد،
      // یا تسویه‌شده — آگهیِ فروخته‌شده reserved می‌ماند)، کارمزدش APPROVED است، در انتظار تاییدِ ادمین است
      // (awaiting_approval؛ ساعتِ کارمزد بعد از تایید شروع می‌شود)، یا confirmed است و ساعتِ سطحِ معامله (T1) دارد
      // (آن ساعت با enforceDealSellerFeeDeadlines اعمال می‌شود).
      const superseding = await tx.deal.findFirst({
        where: {
          materialListingId: listing.id,
          OR: [
            { status: { in: FEE_CLOCK_SUPERSEDED_STATUSES } },
            {
              status: { in: FEE_CLOCK_PRE_TRANSPORT_STATUSES },
              payments: { some: { kind: 'SELLER_FEE', status: 'APPROVED' } },
            },
            { status: 'awaiting_approval' },
            { status: 'confirmed', sellerFeeDeadline: { not: null } },
          ],
        },
        select: { id: true },
      })
      if (superseding) {
        // فقط ساعتِ کهنه پاک می‌شود؛ وضعیتِ آگهی، معامله و کاربر دست‌نخورده می‌ماند.
        await tx.materialListing.updateMany({
          where: { id: listing.id, feeDeadline: { lt: now } },
          data: { feeDeadline: null },
        })
        return 'stale' as const
      }

      // گاردِ وضعیت (اتمیک): فقط اگر آگهی هنوز دقیقاً در همان پیش‌شرط‌ها (unpaid + reserved +
      // مهلتِ گذشته) است. feeDeadline هم در شرط است تا آگهیِ تازه‌رزروشده (startSellerFeeDeadline
      // مهلتِ جدید گذاشته) با ردیفِ کهنه‌ی findMany پنهان نشود. count===0 یعنی تیکِ دیگری زودتر
      // پردازش کرده — رد شو تا کاربر دوباره محدود و معامله‌ها دوباره لغو نشوند.
      const flipped = await tx.materialListing.updateMany({
        where: { id: listing.id, feeStatus: 'unpaid', validityStatus: 'reserved', feeDeadline: { lt: now } },
        data: { validityStatus: 'needs_reverification', feeDeadline: null },
      })
      if (flipped.count === 0) return 'skipped' as const

      // لغوِ معامله‌های پیش از حمل در همان تراکنشِ flip (بدون releaseItemInTx — آگهی پنهان می‌ماند).
      await tx.deal.updateMany({
        where: { materialListingId: listing.id, status: { in: ['draft', 'confirmed'] } },
        data: { status: 'cancelled' },
      })
      return 'flipped' as const
    })
    if (outcome !== 'flipped') continue

    await restrictUser(listing.userId, RESTRICTION_HOURS, 'کارمزد فروش را ظرف مهلت مقرر پرداخت نکرد')
    count++
  }

  return count
}

/**
 * خریدار بعد از تایید، پرداخت کامل رو تکمیل نکرده → رزرو کنسل، مورد از مسیر صفِ رزرو آزاد می‌شه
 * (نفر بعدیِ صف مطلع می‌شه و فقط اگه صفی نباشه آگهی/درخواست به بازار برمی‌گرده).
 */
async function enforceBuyerPaymentDeadlines() {
  const now = new Date()
  const overdue = await prisma.deal.findMany({
    where: {
      status: 'confirmed',
      escrowStatus: 'pending',
      buyerConfirmDeadline: { lt: now },
    },
    include: { materialListing: true },
  })

  let count = 0
  for (const deal of overdue) {
    // گاردِ وضعیت (اتمیک): فقط اگر معامله هنوز confirmed و escrow در حالت pending است لغو کن.
    // false یعنی یک تیکِ دیگر زودتر پردازش کرده — از تکرار side-effectها صرف‌نظر می‌کنیم.
    const cancelled = await cancelGuardedDealAndRelease(deal, { status: 'confirmed', escrowStatus: 'pending' })
    if (!cancelled) continue

    await restrictUser(deal.buyerId, RESTRICTION_HOURS, 'رزرو را تایید کرد ولی پرداخت را ظرف مهلت مقرر تکمیل نکرد')
    count++
  }

  return count
}

/**
 * وقتی راننده «تایید تخلیه» رو ثبت می‌کنه، این رو صدا بزن. از همین لحظه دو
 * تایمر مستقل شروع می‌شه — طول هردو از تنظیمات فعلی (قابل‌تغییر توسط
 * کارشناس) خونده می‌شه، نه عدد ثابت.
 */
export async function startPostUnloadingClocks(dealId: string, unloadingConfirmedAt: Date) {
  const rules = await getDealRuleSettings()
  const [discrepancyDeadline, releaseDeadline] = await Promise.all([
    calculateBusinessHoursDeadline(unloadingConfirmedAt, rules.discrepancyReportHours),
    calculateBusinessHoursDeadline(unloadingConfirmedAt, rules.fundReleaseHours),
  ])
  await prisma.deal.update({
    where: { id: dealId },
    data: {
      status: 'delivered',
      discrepancyReportDeadline: discrepancyDeadline,
      fundReleaseDeadline: releaseDeadline,
    },
  })
  return { discrepancyDeadline, releaseDeadline }
}

/**
 * پایان مهلت گزارش مغایرت: اگه خریدار هیچ مغایرتی ثبت نکرده باشه، سیستم
 * خودش auto_no_discrepancy رو ثبت می‌کنه.
 */
async function enforceDiscrepancyWindowClose() {
  const now = new Date()
  const overdue = await prisma.deal.findMany({
    where: {
      discrepancyReportDeadline: { lt: now },
      status: 'delivered',
      qualityAutoAccepted: false,
    },
    include: { confirmations: true },
  })

  let count = 0
  for (const deal of overdue) {
    const alreadyReported = deal.confirmations.some((c) => c.type === 'buyer_confirm')
    if (alreadyReported) {
      // گاردِ وضعیت (اتمیک): فقط پرچمِ auto-accept را بزن؛ گزارشِ خریدار از قبل هست.
      await prisma.deal.updateMany({
        where: { id: deal.id, status: 'delivered', qualityAutoAccepted: false },
        data: { qualityAutoAccepted: true },
      })
      continue
    }

    // claim-then-act: اول اتمیک پرچم را بزن. فقط تیکِ برنده (count===1) گزارشِ خودکار می‌سازد،
    // تا دو تیکِ موازی دو DealConfirmation تکراری ثبت نکنند.
    const res = await prisma.deal.updateMany({
      where: { id: deal.id, status: 'delivered', qualityAutoAccepted: false },
      data: { qualityAutoAccepted: true },
    })
    if (res.count === 0) continue

    await prisma.dealConfirmation.create({
      data: {
        dealId: deal.id,
        type: 'buyer_confirm',
        finalVerdict: 'auto_no_discrepancy',
        checklistJson: '{}',
      },
    })
    count++
  }
  return count
}

/**
 * اگه راننده بعد از «تایید بارگیری» تا آستانه‌ی تنظیم‌شده (پیش‌فرض ۵ روز
 * تقویمی) هیچ رویداد دیگه‌ای ثبت نکنه، این پرچم می‌خوره.
 */
async function enforceDriverSilenceEscalation(rules: DealRuleValues) {
  const now = new Date()
  const cutoff = new Date(now.getTime() - rules.driverSilenceDays * 24 * 60 * 60 * 1000)

  const inTransitDeals = await prisma.deal.findMany({
    where: { status: 'in_transit', driverSilenceFlaggedAt: null },
    include: { confirmations: { orderBy: { confirmedAt: 'desc' } } },
  })

  let count = 0
  for (const deal of inTransitDeals) {
    const lastEvent = deal.confirmations[0]
    if (lastEvent && lastEvent.confirmedAt < cutoff) {
      // گاردِ وضعیت (اتمیک): فقط اگر هنوز in_transit و پرچم‌نخورده است پرچم بزن.
      // count===0 یعنی تیکِ دیگری زودتر پرچم زده — پیامکِ تکراری برای شرکت حمل نفرست.
      const res = await prisma.deal.updateMany({
        where: { id: deal.id, status: 'in_transit', driverSilenceFlaggedAt: null },
        data: { driverSilenceFlaggedAt: now },
      })
      if (res.count === 0) continue
      count++
      // نقطه‌ی ۴ پلن: سکوت راننده به حد نصاب رسید → اطلاع به شرکت حمل‌ونقل (در صف ۶۰دقیقه‌ای)
      if (deal.transportCompanyId) {
        const company = await prisma.transportCompany.findUnique({
          where: { id: deal.transportCompanyId },
          select: { contactPhone: true },
        })
        if (company?.contactPhone) {
          await queueSms({
            dealId: deal.id,
            phone: company.contactPhone,
            message: `هشدار سکوت راننده: محموله‌ی ${deal.id.slice(0, 8)} بیش از ${rules.driverSilenceDays} روز بدون رویداد مانده — لطفاً پیگیری کنید — انبارپلیمر`,
          })
        }
      }
    }
  }
  return count
}

/** برای چک‌کردن قبل از اجازه دادن به ثبت آگهی/رزرو جدید */
export async function isUserRestricted(userId: string) {
  const user = await prisma.user.findUnique({ where: { id: userId } })
  if (!user?.restrictedUntil) return { restricted: false as const }
  if (user.restrictedUntil < new Date()) return { restricted: false as const }
  return { restricted: true as const, until: user.restrictedUntil, reason: user.restrictionReason }
}

/**
 * طول‌های مجاز جریمه (به ساعت) که ادمین هنگام رد پرداخت انتخاب می‌کند — §۵ سند.
 * ۳۰ دقیقه = ۰٫۵ ساعت؛ بقیه مستقیماً ساعت‌اند.
 */
export const PENALTY_HOURS_OPTIONS = [0.5, 1, 3, 24, 72] as const

/**
 * دسته‌ی ثابتِ SystemLog که هر اجرای زمان‌بندِ مهلت‌ها زیرش ثبت می‌شه — بدون جدول جدید.
 * trigger توی ستونِ موجودِ path ذخیره می‌شه ('auto' برای cron، 'manual' برای دکمه‌ی ادمین)
 * تا بخشِ نمایشیِ مانیتور بتونه فقط اجراهای خودکار رو فیلتر کنه.
 */
const DEADLINE_SCHEDULER_CATEGORY = 'deadline_scheduler'

/**
 * یک تیکِ کاملِ زمان‌بند: هر دو دسته قانون مهلت رو اجرا می‌کنه (سطح معامله + پیش‌فاکتور)،
 * یه خلاصه‌ی فارسیِ خوانا از نتیجه می‌سازه، و اون رو توی SystemLog ثبت می‌کنه تا کارتِ
 * مانیتور توی /admin-deals «۳ اجرای آخر» رو نشون بده. هم از Endpointِ cron (trigger='auto')
 * و هم از دکمه‌ی «اجرای همین الان»ِ ادمین (trigger='manual') صدا زده می‌شه.
 */
export async function runDeadlineEnforcement(trigger: 'auto' | 'manual') {
  const dealResult = await enforceDealDeadlines()
  const proformaExpiredCount = await enforceProformaDeadlines()
  // بررسی هشدارهای قیمت هم بخشی از همین تیکِ خودکار است تا بدونِ بازکردنِ صفحه هم فعال شوند.
  const priceAlerts = await checkPriceAlerts()

  // صفِ رزرو: claimهای ۱ ساعته‌ی منقضی‌شده اعمال می‌شود (اعلانِ «نوبتت تمام شد»، نفر بعدی یا
  // برگشت به بازار). جدا و fail-safe است: خطای این زیرسیستم نباید نتیجه‌ی بقیه‌ی مهلت‌ها یا
  // لاگِ تیک را از بین ببرد. خطا زیر دسته‌ی reservation_queue ثبت می‌شود (نه deadline_scheduler)
  // تا در کارتِ «۳ اجرای آخر» مانیتور به‌عنوان یک اجرا ظاهر نشود.
  let queue = { expiredClaims: 0, advanced: 0, returnedToPool: 0 }
  try {
    queue = await enforceReservationQueueClaims()
  } catch (e) {
    await logEvent({
      level: 'error',
      category: 'reservation_queue',
      message: 'reservation queue sweep failed',
      meta: { trigger, error: e instanceof Error ? e.message : String(e) },
    })
  }

  const parts: string[] = []
  if (dealResult.cancelledCount > 0)
    parts.push(`${dealResult.cancelledCount.toLocaleString('fa-IR')} معامله باطل شد`)
  if (dealResult.qualityAutoAcceptedCount > 0)
    parts.push(`${dealResult.qualityAutoAcceptedCount.toLocaleString('fa-IR')} بررسی کیفیت خودکار تایید شد`)
  if (dealResult.driverSilenceFlaggedCount > 0)
    parts.push(`${dealResult.driverSilenceFlaggedCount.toLocaleString('fa-IR')} راننده پرچم سکوت خورد`)
  if (proformaExpiredCount > 0)
    parts.push(`${proformaExpiredCount.toLocaleString('fa-IR')} پیش‌فاکتور منقضی شد`)
  if (priceAlerts.triggered > 0)
    parts.push(`${priceAlerts.triggered.toLocaleString('fa-IR')} هشدار قیمت فعال شد`)
  if (queue.expiredClaims > 0)
    parts.push(`${queue.expiredClaims.toLocaleString('fa-IR')} نوبت صف رزرو منقضی شد`)
  const summary = parts.length > 0 ? parts.join('، ') : 'بدون تغییر — هیچ مهلتی سررسید نشده بود'

  await logEvent({
    level: 'info',
    category: DEADLINE_SCHEDULER_CATEGORY,
    message: summary,
    path: trigger,
    meta: {
      trigger,
      cancelledCount: dealResult.cancelledCount,
      qualityAutoAcceptedCount: dealResult.qualityAutoAcceptedCount,
      driverSilenceFlaggedCount: dealResult.driverSilenceFlaggedCount,
      proformaExpiredCount,
      priceAlertsChecked: priceAlerts.checked,
      priceAlertsTriggered: priceAlerts.triggered,
      reservationClaimsExpired: queue.expiredClaims,
      reservationQueueAdvanced: queue.advanced,
      reservationReturnedToPool: queue.returnedToPool,
    },
  })

  return {
    trigger,
    summary,
    ...dealResult,
    proformaExpiredCount,
    priceAlertsChecked: priceAlerts.checked,
    priceAlertsTriggered: priceAlerts.triggered,
    reservationClaimsExpired: queue.expiredClaims,
    reservationQueueAdvanced: queue.advanced,
    reservationReturnedToPool: queue.returnedToPool,
  }
}

/**
 * آخرین n اجرای *خودکار* زمان‌بند (path='auto') برای بخشِ نمایشیِ مانیتور. فقط خواندنی.
 */
export async function getRecentDeadlineRuns(n: number = 3) {
  return prisma.systemLog.findMany({
    where: { category: DEADLINE_SCHEDULER_CATEGORY, path: 'auto' },
    orderBy: { createdAt: 'desc' },
    take: n,
    select: { id: true, message: true, createdAt: true },
  })
}

/**
 * محدودسازی موقت کاربر — تعمیمِ الگوی تکراریِ restrictedUntil (که در enforcerهای این
 * فایل با ثابتِ RESTRICTION_HOURS به‌صورت درجا نوشته شده) به یک helper با طول دلخواه.
 * اگر کاربر همین حالا محدودیتِ فعالِ طولانی‌تری دارد، سقفِ دو مقدار گرفته می‌شود تا
 * جریمه‌ی جدید، محدودیتِ قبلیِ سنگین‌تر را کوتاه نکند.
 */
export async function restrictUser(userId: string, hours: number, reason: string) {
  const candidate = new Date(Date.now() + hours * 60 * 60 * 1000)
  const existing = await prisma.user.findUnique({
    where: { id: userId },
    select: { restrictedUntil: true },
  })
  const until =
    existing?.restrictedUntil && existing.restrictedUntil > candidate
      ? existing.restrictedUntil
      : candidate
  await prisma.user.update({
    where: { id: userId },
    data: { restrictedUntil: until, restrictionReason: reason },
  })
  return until
}

/** موقع تایید ادمین روی یه رزرو، این رو صدا بزن تا مهلت کارمزد فروشنده شروع بشه */
export async function startSellerFeeDeadline(materialListingId: string) {
  const rules = await getDealRuleSettings()
  const deadline = await calculateBusinessHoursDeadline(new Date(), rules.sellerFeeHours)
  await prisma.materialListing.update({
    where: { id: materialListingId },
    data: { validityStatus: 'reserved', feeDeadline: deadline },
  })
  return deadline
}

/** موقع تایید کارمزد فروشنده، این رو صدا بزن تا مهلت پرداخت کامل خریدار شروع بشه */
export async function startBuyerPaymentDeadline(dealId: string, skipApprovalCheck: boolean = false) {
  const rules = await getDealRuleSettings()

  // بارگیری Deal برای سنجش تایید؛ quantityTon آگهی/درخواست فقط وزنِ جایگزین (وقتی Deal.weightKg خالیه) است
  const deal = await prisma.deal.findUnique({
    where: { id: dealId },
    include: { materialListing: { select: { quantityTon: true } }, purchaseRequest: { select: { quantityTon: true } } },
  })
  if (!deal) throw new Error('معامله پیدا نشد.')

  let finalStatus = 'confirmed'
  let approvalLevel: string | null = null
  let approvalEvaluated = false

  if (!skipApprovalCheck) {
    // آستانه‌ی تایید روی «جمع کالا» (قیمت واحد × وزن) است، نه قیمت واحد (C9). قیمتِ واردنشده یا صفر را خودکار
    // confirmed نمی‌کنیم (Q12): برای تاییدِ ادمین نگه داشته می‌شه و سطحِ 'admin' ثبت می‌شه (غیرتهی، پس
    // buyerConfirmDeadline پایین هم null می‌مونه). قیمتِ مثبت با وزنِ نامشخص/خراب = خطا، نه رد‌شدنِ بی‌صدا.
    let amount: number | null
    try {
      amount = dealApprovalAmountToman({
        agreedPrice: deal.agreedPrice,
        weightKg: deal.weightKg,
        listedTon: deal.materialListing?.quantityTon ?? deal.purchaseRequest?.quantityTon,
      })
    } catch (error) {
      if (error instanceof MoneyCalcError) throw new Error(`${error.message} تا وزن مشخص نشه، تایید معامله ممکن نیست.`)
      throw error
    }
    approvalLevel = amount === null || amount === 0 ? 'admin' : await evaluateApprovalRequirement('Deal', amount)
    approvalEvaluated = true
    if (approvalLevel) {
      finalStatus = 'awaiting_approval'
    }
  }

  const deadline = await calculateBusinessHoursDeadline(new Date(), rules.buyerPaymentHours)
  // مهلت پرداخت کارمزد فروشنده فقط وقتی معامله به confirmed می‌رسد آغاز می‌شود؛
  // در حالت awaiting_approval null می‌ماند و بعداً (approveDealAction → startBuyerPaymentDeadline(..., true)) ست می‌شود
  const sellerFeeDeadline =
    finalStatus === 'confirmed'
      ? await calculateBusinessHoursDeadline(new Date(), rules.sellerFeeHours)
      : null
  await prisma.deal.update({
    where: { id: dealId },
    data: {
      status: finalStatus,
      buyerConfirmDeadline: approvalLevel ? null : deadline,
      sellerFeeDeadline,
      // سطح تایید فقط وقتی نوشته می‌شه که سنجش واقعاً اجرا شده؛ مسیر تاییدِ ادمین (skip=true) مقدارِ قبلی رو نگه می‌داره
      ...(approvalEvaluated ? { approvalLevel } : {}),
    },
  })
  return deadline
}

/** موقع ثبت قیمت نهایی سفارش توسط کارشناس فروش — مهلت تایید پیش‌فاکتور توسط مشتری شروع می‌شه */
export async function startProformaDeadline(orderId: string) {
  const rules = await getDealRuleSettings()
  const deadline = await calculateBusinessHoursDeadline(new Date(), rules.proformaConfirmHours)
  await prisma.order.update({
    where: { id: orderId },
    data: { status: 'priced', proformaDeadline: deadline },
  })
  return deadline
}

/**
 * مهلت تایید پیش‌فاکتور گذشته و مشتری هنوز تایید نکرده → سفارش خودکار باطل
 * می‌شه (status=rejected با توضیح متمایز در StatusEvent) و موجودی قفل‌شده‌ی
 * هر قلم به انبار برمی‌گرده — همون تراکنشی که rejectOrder دستی انجام می‌ده.
 * مثل بقیه‌ی enforceها، به‌جای cron موقع لود صفحه‌های /proformas صدا زده می‌شه.
 */
export async function enforceProformaDeadlines() {
  const now = new Date()
  const overdue = await prisma.order.findMany({
    where: { status: 'priced', proformaDeadline: { lt: now } },
    include: { items: true },
  })

  for (const order of overdue) {
    const itemsWithWarehouse = order.items.filter((item) => item.warehouseId)
    await prisma.$transaction([
      ...itemsWithWarehouse.map((item) =>
        prisma.warehouseStock.updateMany({
          where: { warehouseId: item.warehouseId as string, gradeId: item.gradeId },
          data: { quantityTon: { increment: item.quantity } },
        })
      ),
      prisma.order.update({ where: { id: order.id }, data: { status: 'rejected' } }),
    ])

    await logStatusEvent({
      recordType: 'Order',
      recordId: order.id,
      newStageKey: 'rejected',
      note: 'مهلت تایید پیش‌فاکتور گذشت — سفارش خودکار باطل شد و موجودی به انبار برگشت',
    })
  }

  return overdue.length
}
