import fs from 'fs/promises'
import path from 'path'
import crypto from 'crypto'
import prisma from '@/lib/prisma'
import { logAudit, logFinancialDrift } from '@/lib/logger'
import { FinancialDriftError, appendFinancialRecord, newFormKey } from '@/lib/financialHistory'

const UPLOAD_DIR = path.join(process.cwd(), 'public', 'uploads', 'receipts')

// اطمینان از وجود پوشه — اگه نبود خودکار می‌سازه
async function ensureUploadDir() {
  await fs.mkdir(UPLOAD_DIR, { recursive: true })
}

/**
 * ذخیره‌ی فیزیکی فایل رسید و برگرداندن URL نسبی
 * entityType: 'deal' | 'order'
 */
export async function savePaymentReceipt(
  file: File
): Promise<string> {
  await ensureUploadDir()

  const ext = file.name.split('.').pop()?.toLowerCase() ?? 'jpg'
  const allowed = ['jpg', 'jpeg', 'png', 'pdf']
  if (!allowed.includes(ext)) {
    throw new Error('فرمت فایل مجاز نیست — فقط JPG، PNG یا PDF')
  }

  const maxBytes = 5 * 1024 * 1024 // 5 MB
  if (file.size > maxBytes) {
    throw new Error('حجم فایل بیشتر از ۵ مگابایته')
  }

  const randomName = crypto.randomBytes(16).toString('hex')
  const fileName = `${randomName}.${ext}`
  const filePath = path.join(UPLOAD_DIR, fileName)

  const buffer = Buffer.from(await file.arrayBuffer())
  await fs.writeFile(filePath, buffer)

  return `/uploads/receipts/${fileName}`
}

/** رسیدِ سفارش در وضعیتِ فعلی قابل ثبت/جایگزینی نیست (تاییدشده، یا در انتظار بررسی برای غیرکارمند). */
export class ReceiptNotReplaceableError extends Error {}

export type OrderReceiptState = {
  paymentReceiptUrl: string | null
  paymentReceiptStatus: string | null
}

/**
 * قانونِ ثبت/جایگزینیِ رسیدِ «سفارش»:
 *  - رسیدِ ثبت‌نشده (URL خالی) یا ردشده: هر کسی که اجازه‌ی آپلود دارد می‌تواند رسید بفرستد.
 *  - در انتظار بررسی (pending؛ وضعیتِ خالیِ قدیمی هم همین حساب می‌شود): فقط کارمند/ادمین می‌تواند
 *    جایگزین کند (canReplacePending).
 *  - تاییدشده (approved): هیچ‌کس؛ فاکتور رسمی روی همان رسید صادر شده.
 * هم قبل از ذخیره‌ی فایل (route) و هم داخل تراکنشِ attachPaymentReceipt صدا زده می‌شود.
 */
export function checkOrderReceiptUpload(
  state: OrderReceiptState,
  canReplacePending: boolean
): { ok: true } | { ok: false; reason: string } {
  if (state.paymentReceiptStatus === 'approved') {
    return { ok: false, reason: 'رسید این سفارش قبلاً تایید شده و قابل تغییر نیست' }
  }
  if (!state.paymentReceiptUrl || state.paymentReceiptStatus === 'rejected') return { ok: true }
  if (canReplacePending) return { ok: true }
  return { ok: false, reason: 'رسید این سفارش قبلاً ارسال شده و در انتظار بررسی است' }
}

/**
 * ثبت URL رسید روی رکورد Deal یا Order + logAudit
 *
 * برای Order: قانونِ checkOrderReceiptUpload داخل تراکنش دوباره چک می‌شود، با ثبتِ رسید وضعیت
 * اتمیک به pending می‌رود (رکورد تاریخچه‌اش هم ثبت می‌شود) و فیلدهای بررسیِ قبلی پاک می‌شوند تا
 * رسیدِ تازه به صفِ تایید برسد. شرط‌شکنی → ReceiptNotReplaceableError.
 */
export async function attachPaymentReceipt(
  entityType: 'deal' | 'order',
  entityId: string,
  receiptUrl: string,
  performedByUserId: string,
  options: { canReplacePending?: boolean } = {}
): Promise<void> {
  const now = new Date()
  let replacedPending = false

  // آدرس رسید فیلد مالی (Tier B) است: رکورد تاریخچه «قبل» از نوشتن ستون و در همان تراکنش.
  // هر آپلود یک رویداد تازه است (فایل با نام تصادفی)، پس formKey تصادفی.
  try {
    await prisma.$transaction(async (tx) => {
      if (entityType === 'deal') {
        await appendFinancialRecord(tx, {
          entityType: 'Deal',
          entityId,
          fieldName: 'paymentReceiptUrl',
          newValue: receiptUrl,
          changedBy: performedByUserId,
          formKey: newFormKey(),
          readColumn: async () => {
            const row = await tx.deal.findUnique({ where: { id: entityId }, select: { paymentReceiptUrl: true } })
            return row?.paymentReceiptUrl ?? null
          },
        })
        await tx.deal.update({
          where: { id: entityId },
          data: {
            paymentReceiptUrl: receiptUrl,
            paymentReceiptUploadedAt: now,
          },
        })
      } else {
        const current = await tx.order.findUnique({
          where: { id: entityId },
          select: { paymentReceiptUrl: true, paymentReceiptStatus: true },
        })
        if (!current) throw new ReceiptNotReplaceableError('سفارش پیدا نشد')
        const verdict = checkOrderReceiptUpload(current, options.canReplacePending === true)
        if (!verdict.ok) throw new ReceiptNotReplaceableError(verdict.reason)
        replacedPending = !!current.paymentReceiptUrl && current.paymentReceiptStatus !== 'rejected'

        const formKey = newFormKey()
        await appendFinancialRecord(tx, {
          entityType: 'Order',
          entityId,
          fieldName: 'paymentReceiptUrl',
          newValue: receiptUrl,
          changedBy: performedByUserId,
          formKey,
          readColumn: async () => {
            const row = await tx.order.findUnique({ where: { id: entityId }, select: { paymentReceiptUrl: true } })
            return row?.paymentReceiptUrl ?? null
          },
        })
        // وضعیت فقط وقتی عوض می‌شود (rejected/خالی → pending) رکورد تاریخچه می‌گیرد؛ جایگزینیِ pending بی‌تغییر است.
        if (current.paymentReceiptStatus !== 'pending') {
          await appendFinancialRecord(tx, {
            entityType: 'Order',
            entityId,
            fieldName: 'paymentReceiptStatus',
            newValue: 'pending',
            changedBy: performedByUserId,
            formKey,
            readColumn: async () => {
              const row = await tx.order.findUnique({ where: { id: entityId }, select: { paymentReceiptStatus: true } })
              return row?.paymentReceiptStatus ?? null
            },
          })
        }
        // شرطِ وضعیت در updateMany: اگر بین خواندن و نوشتن (مثلاً تایید هم‌زمان) عوض شده باشد count=0 و تراکنش
        // (همراه رکوردهای تاریخچه) برمی‌گردد.
        const { count } = await tx.order.updateMany({
          where: { id: entityId, paymentReceiptStatus: current.paymentReceiptStatus },
          data: {
            paymentReceiptUrl: receiptUrl,
            paymentReceiptUploadedAt: now,
            paymentReceiptStatus: 'pending',
            paymentReceiptReviewedById: null,
            paymentReceiptReviewedAt: null,
          },
        })
        if (count !== 1) throw new ReceiptNotReplaceableError('وضعیت رسید هم‌زمان تغییر کرد — صفحه را تازه کنید')
      }
    })
  } catch (error) {
    if (error instanceof FinancialDriftError) {
      await logFinancialDrift(error, performedByUserId)
    }
    throw error
  }

  await logAudit(
    'payment',
    `رسید پرداخت آپلود شد — ${entityType} #${entityId}`,
    performedByUserId,
    replacedPending ? { receiptUrl, replacedPending } : { receiptUrl }
  )
}
