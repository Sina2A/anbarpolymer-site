import prisma from './prisma'
import { FinancialDriftError, appendFinancialRecord, newFormKey } from './financialHistory'
import { logFinancialDrift } from './logger'

/**
 * موارد مغایرت — طبقه‌بندی‌شده به دو سطح، طبق تصمیم صریح سینا:
 *   حساس: باید معامله متوقف و بررسی بشه (کسری وزن زیاد، بسته‌بندی خراب و...)
 *   جزئی: فقط ثبت می‌شه برای سابقه، ولی جلوی واریز خودکار رو نمی‌گیره
 * این لیست‌ها هم توی فرم خریدار و هم موقع تفسیر گزارش استفاده می‌شن.
 */
export const SEVERE_DISCREPANCY_ITEMS = [
  'کسری وزن بیش از ۵۰ کیلوگرم',
  'عدم بسته‌بندی کامل یا صحیح',
  'گرید یا نوع محصول با سفارش مطابقت ندارد',
  'شواهد آشکار تقلب یا جعل مدارک',
]

export const MINOR_DISCREPANCY_ITEMS = [
  'کسری وزن کمتر از ۱ کیلوگرم',
  'باز شدن شیرینک بسته‌بندی',
  'شکستگی جزئی پالت',
  'خیس‌شدگی سطحی ناشی از باران',
]

/** پیام رد گزارش مغایرت وقتی معامله «تحویل‌شده» نیست یا پنجره‌ی مغایرت قبلاً بسته شده (انقضا یا گزارشِ قبلی). */
export const DISCREPANCY_NOT_ALLOWED =
  'گزارش مغایرت فقط برای معامله‌ی «تحویل‌شده» و تا وقتی پنجره‌ی مغایرت بسته نشده ممکنه؛ این پنجره بسته شده یا قبلاً گزارشی ثبت شده.'

/**
 * خریدار توی پنجره‌ی ۴ساعته یه مغایرت گزارش کرده. اگه حتی یکی از موارد
 * انتخاب‌شده «حساس» باشه، کل گزارش حساس تلقی می‌شه: تایمر واریز فریز می‌شه
 * و یه Dispute واقعی باز می‌شه. اگه فقط موارد جزئی باشن، صرفاً ثبت می‌شه —
 * نه فریز، نه Dispute — چون این‌جور مشکلات جلوی جریان معامله رو نمی‌گیرن.
 *
 * `fundReleaseFrozen` فیلد مالیِ Tier B است: اینجا فقط `true` نوشته می‌شه (هرگز `false`؛ گزارش جزئی یا
 * گزارشِ دوم نباید فریزِ قبلی را بردارد) و آن هم با رکورد تاریخچه «قبل» از ستون و در همان تراکنشِ
 * ثبت گزارش/اختلاف. برداشتنِ فریز فقط با تصمیم مدیر در resolveDisputeAction است.
 *
 * گیت: فقط status==='delivered' و qualityAutoAccepted===false (پنجره‌ی باز) و با updateMany اتمیک (اولین نوشتنِ
 * تراکنش)، پس هر دو مسیرِ ثبت (my-deals و deal-confirm) و هر هم‌زمانی با انقضای پنجره پوشش داده می‌شن.
 */
export async function submitDiscrepancyReport(params: {
  dealId: string
  raisedById: string
  selectedItems: string[]
  note: string
}) {
  const { dealId, raisedById, selectedItems, note } = params
  const isSevere = selectedItems.some((item) => SEVERE_DISCREPANCY_ITEMS.includes(item))
  const severity = isSevere ? 'severe' : 'minor'

  try {
    await prisma.$transaction(
      async (tx) => {
        // گیتِ اتمیک (claim-then-act، مثل enforceDiscrepancyWindowClose): گزارش فقط برای معاملهٔ «تحویل‌شده» با پنجره‌ی
        // باز (qualityAutoAccepted===false) پذیرفته می‌شه و همین نوشتن پنجره را می‌بنده. دو گزارشِ هم‌زمان یا گزارشِ
        // هم‌زمان با انقضای پنجره: فقط یکی count===1 می‌گیره؛ بقیه قبل از هر رکوردی throw می‌کنن.
        const claimed = await tx.deal.updateMany({
          where: { id: dealId, status: 'delivered', qualityAutoAccepted: false },
          data: { qualityAutoAccepted: true }, // یعنی پنجره‌ی گزارش بسته شد (چه با خبر چه بی‌خبر)
        })
        if (claimed.count !== 1) throw new Error(DISCREPANCY_NOT_ALLOWED)

        await tx.dealConfirmation.create({
          data: {
            dealId,
            type: 'buyer_confirm',
            finalVerdict: isSevere ? 'discrepancy_severe' : 'discrepancy_minor',
            discrepancySeverity: severity,
            discrepancyItemsJson: JSON.stringify(selectedItems),
            discrepancyNote: note || null,
            checklistJson: '{}',
          },
        })

        if (isSevere) {
          // تاریخچه «قبل» از ستون. 'unchanged' (قبلاً فریز بوده) بی‌خطره؛ 'duplicate' با کلیدِ تازه نباید پیش بیاد.
          const record = await appendFinancialRecord(tx, {
            entityType: 'Deal',
            entityId: dealId,
            fieldName: 'fundReleaseFrozen',
            newValue: true,
            changedBy: raisedById,
            formKey: newFormKey(),
            readColumn: async () => {
              const row = await tx.deal.findUnique({ where: { id: dealId }, select: { fundReleaseFrozen: true } })
              return row?.fundReleaseFrozen ?? null
            },
          })
          if (record.outcome === 'duplicate') throw new Error('ثبت گزارش مغایرت تکراری بود؛ دوباره تلاش کن.')
          // فقط true (هرگز false نمی‌نویسیم؛ گزارش جزئی اصلاً به این ستون دست نمی‌زنه).
          await tx.deal.update({ where: { id: dealId }, data: { fundReleaseFrozen: true } })
        }

        if (isSevere) {
          await tx.dispute.create({
            data: {
              dealId,
              raisedById,
              reason: `مغایرت حساس گزارش‌شده توسط خریدار: ${selectedItems.join('، ')}${note ? ' — ' + note : ''}`,
              status: 'open',
            },
          })
        }
      },
      { timeout: 20000, maxWait: 5000 },
    )
  } catch (error) {
    if (error instanceof FinancialDriftError) await logFinancialDrift(error, raisedById, { dealId })
    throw error
  }

  return { severity }
}

// توجه: تابع قدیمی raiseDisputeIfNeeded (مربوط به مدل منسوخ‌شده‌ی «تایید
// فعال خریدار») از اینجا حذف شد — با submitDiscrepancyReport جایگزین شده و
// دیگه هیچ‌جای کد صداش نمی‌زد (تایید شده با grep قبل از حذف).
// تابع resolveDispute هم (که فریز را با یک update ساده و بیرون از تاریخچه‌ی مالی می‌نوشت و
// هیچ‌جا صدا زده نمی‌شد) حذف شد؛ تنها مسیر بستن اختلاف resolveDisputeAction در admin-disputes است.
