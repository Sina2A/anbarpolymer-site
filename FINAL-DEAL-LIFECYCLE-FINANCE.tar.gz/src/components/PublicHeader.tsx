'use client'

import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import { colors } from '@/lib/styles/tokens'
import type { CSSProperties } from 'react'
import { BrandCoin } from '@/components/BrandMark'
import GuestBottomNav from '@/components/mobile/GuestBottomNav'
import UserBottomNav from '@/components/mobile/UserBottomNav'
import MoreSheet from '@/components/mobile/MoreSheet'
import { GUEST_SHEET_ITEMS, USER_SHEET_ITEMS } from '@/lib/mobileNavItems'

const NAV_ITEMS = [
  { label: 'صفحه اصلی', href: '/' },
  { label: 'گریدها', href: '/grades' },
  { label: 'انبارها', href: '/warehouses' },
  { label: 'استعلام قیمت', href: '/rfq-public' },
  { label: 'بازار صنعتی', href: '/market' },
  { label: 'گزارش بازار', href: '/reports' },
  { label: 'خدمات سازمانی', href: '/services' },
  { label: 'درباره ما', href: '/about' },
  { label: 'تماس با ما', href: '/contact' },
]

export default function PublicHeader({
  activePage,
  isLoggedIn = false,
  homeHref = '/',
}: {
  activePage?: string
  isLoggedIn?: boolean
  homeHref?: string
}) {
  const [moreOpen, setMoreOpen] = useState(false)
  const navRefs = useRef<Record<string, HTMLAnchorElement | null>>({})
  const [indicator, setIndicator] = useState<{ left: number; width: number } | null>(null)

  const updateIndicator = () => {
    const activeEl = activePage ? navRefs.current[activePage] : null
    if (activeEl) {
      setIndicator({ left: activeEl.offsetLeft, width: activeEl.offsetWidth })
    } else {
      setIndicator(null)
    }
  }

  useLayoutEffect(() => {
    updateIndicator()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activePage])

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 900) setMoreOpen(false)
      updateIndicator()
    }
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <>
      <div style={topbarStyle}>
        <div style={topbarWrapStyle}>
          <span style={{ opacity: 0.85 }}>
            پشتیبانی فروش شنبه تا چهارشنبه ۸:۳۰ تا ۱۷:۳۰
          </span>
          <a href="tel:+982191234567" style={phoneStyle}>
            021-91234567
          </a>
        </div>
      </div>

      <header style={headerStyle}>
        <div style={wrapStyle}>
          <a href={homeHref} style={logoStyle}>
            <BrandCoin />
            انبار پلیمر
          </a>

          <nav style={navStyle} data-public-nav="true">
            {NAV_ITEMS.map((item) => (
              <a
                key={item.href}
                href={item.href}
                ref={(el) => { navRefs.current[item.href] = el }}
                style={{
                  ...navLinkStyle,
                  color: activePage === item.href ? '#ffffff' : 'rgba(255,255,255,0.78)',
                  fontWeight: activePage === item.href ? 700 : 600,
                }}
              >
                {item.label}
              </a>
            ))}
            {indicator && (
              <span
                data-nav-indicator="true"
                style={{
                  position: 'absolute',
                  bottom: -1,
                  left: indicator.left,
                  width: indicator.width,
                  height: 2,
                  background: colors.orange,
                  borderRadius: 2,
                  transition: 'left 0.3s ease, width 0.3s ease',
                }}
              />
            )}
          </nav>

          <div style={actionsStyle}>
            {isLoggedIn && (
              <a href="/inbox" style={acctBtnStyle} className="public-inbox-desktop">
                صندوق پیام‌ها
              </a>
            )}
            {isLoggedIn && (
              <a href="/inbox" aria-label="صندوق پیام‌ها" className="public-inbox-mobile">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M22 12h-6l-2 3h-4l-2-3H2" /><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z" /></svg>
              </a>
            )}
            <a
              href={isLoggedIn ? '/dashboard' : '/login'}
              style={acctBtnStyle}
            >
              {isLoggedIn ? 'پیشخوان' : 'ورود / ثبت‌نام'}
            </a>

            <button
              onClick={() => setMoreOpen(true)}
              style={hamburgerBtnStyle}
              data-public-hamburger="true"
              aria-label="منو"
            >
              ☰
            </button>
          </div>
        </div>

        {/* Mobile legacy dropdown removed → MoreSheet + BottomNav */}
      </header>
      <MoreSheet open={moreOpen} onClose={() => setMoreOpen(false)} title="بیشتر" items={isLoggedIn ? USER_SHEET_ITEMS : GUEST_SHEET_ITEMS} variant={isLoggedIn ? 'user' : 'guest'} />
      {isLoggedIn ? <UserBottomNav homeHref={homeHref} /> : <GuestBottomNav homeHref={homeHref} />}
    </>
  )
}

const topbarStyle: CSSProperties = {
  background: colors.navyDark,
  borderBottom: '1px solid rgba(255,255,255,0.15)',
  fontSize: 12.5,
  color: 'rgba(255,255,255,0.85)',
  fontFamily: 'var(--font-label)',
}

const headerStyle: CSSProperties = {
  position: 'sticky',
  top: 0,
  zIndex: 50,
  background: colors.navy,
  borderBottom: `1px solid ${colors.navyDark}`,
  boxShadow: '0 2px 10px rgba(30,53,123,0.25)',
}

// ──────────────────────────────────────────────────────────
// استایل‌ها
// ──────────────────────────────────────────────────────────
const wrapStyle: CSSProperties = {
  maxWidth: 1180,
  margin: '0 auto',
  padding: '0 24px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  height: 72,
  gap: 24,
}

const topbarWrapStyle: CSSProperties = {
  ...wrapStyle,
  height: 36,
}

const logoStyle: CSSProperties = {
  fontWeight: 800,
  fontSize: 19,
  letterSpacing: '-0.01em',
  display: 'flex',
  alignItems: 'center',
  gap: 8,
  color: '#ffffff',
  fontFamily: 'var(--font-heading)',
  textDecoration: 'none',
}

const navStyle: CSSProperties = {
  position: 'relative',
  display: 'flex',
  gap: 26,
  fontSize: 14,
  fontWeight: 600,
  fontFamily: 'var(--font-label)',
  paddingBottom: 4,
}

const navLinkStyle: CSSProperties = {
  color: 'rgba(255,255,255,0.78)',
  textDecoration: 'none',
  transition: 'color 0.15s',
}

const actionsStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 14,
}

const acctBtnStyle: CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  border: '1px solid rgba(255,255,255,0.55)',
  borderRadius: 8,
  padding: '0 16px',
  height: 36,
  fontSize: 14.5,
  fontWeight: 600,
  lineHeight: 1.2,
  fontFamily: 'inherit',
  boxSizing: 'border-box',
  color: '#ffffff',
  textDecoration: 'none',
}

const phoneStyle: CSSProperties = {
  color: '#ffffff',
  fontWeight: 600,
  fontFamily: 'monospace',
  direction: 'ltr',
  display: 'inline-block',
  textDecoration: 'none',
}

const hamburgerBtnStyle: CSSProperties = {
  display: 'none',
  background: 'transparent',
  border: '1px solid rgba(255,255,255,0.4)',
  borderRadius: 6,
  color: '#ffffff',
  fontSize: 18,
  padding: '4px 10px',
  cursor: 'pointer',
}

