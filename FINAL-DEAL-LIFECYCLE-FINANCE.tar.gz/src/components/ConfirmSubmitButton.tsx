'use client'

import { useFormStatus } from 'react-dom'

export default function ConfirmSubmitButton({
  message,
  children,
  style,
  className,
  name,
  value,
  disabled,
  title,
}: {
  message: string
  children: React.ReactNode
  style?: React.CSSProperties
  className?: string
  /** اختیاری: برای فرم‌های چنددکمه‌ای (دکمه‌ی فشرده‌شده name=value را همراه فرم می‌فرستد). */
  name?: string
  value?: string
  disabled?: boolean
  title?: string
}) {
  const { pending } = useFormStatus()
  const isDisabled = pending || !!disabled
  return (
    <button
      type="submit"
      name={name}
      value={value}
      style={{ ...style, opacity: isDisabled ? 0.6 : undefined, pointerEvents: isDisabled ? 'none' as const : undefined }}
      className={className}
      disabled={isDisabled}
      aria-busy={pending}
      title={title}
      onClick={(e) => {
        if (isDisabled) {
          e.preventDefault()
          return
        }
        if (!confirm(message)) {
          e.preventDefault()
        }
      }}
    >
      {pending ? 'در حال ارسال…' : children}
    </button>
  )
}
