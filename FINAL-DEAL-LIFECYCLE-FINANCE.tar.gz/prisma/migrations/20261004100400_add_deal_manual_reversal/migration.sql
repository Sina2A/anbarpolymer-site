-- AlterTable
ALTER TABLE "Deal" ADD COLUMN "manualReversalRequired" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN "manualReversalAt" TIMESTAMP(3);
