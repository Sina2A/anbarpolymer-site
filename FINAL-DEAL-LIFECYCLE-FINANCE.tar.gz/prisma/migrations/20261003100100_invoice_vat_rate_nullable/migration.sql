-- Invoice.vatRate دیگه نرخ ثابتِ ۰٫۰۹ نیست: مالیات دستیِ per-ردیفه و فاکتور جدید vatRate = NULL می‌نویسه.
-- فاکتورهای قبلی همون مقدار ثبت‌شده‌شون رو نگه می‌دارن (فقط default و NOT NULL برداشته می‌شه).
-- IF EXISTS: هیچ migration‌ای جدول Invoice رو نساخته (احتمالاً با db push ساخته شده).
ALTER TABLE IF EXISTS "Invoice" ALTER COLUMN "vatRate" DROP DEFAULT, ALTER COLUMN "vatRate" DROP NOT NULL;
