-- Grade.requiresBuyerVerification: when true, only buyers with KYC level >= 2 can create a PurchaseRequest
-- for this grade. Additive; existing rows default to false (no behavior change on deploy).
ALTER TABLE "Grade" ADD COLUMN "requiresBuyerVerification" BOOLEAN NOT NULL DEFAULT false;
