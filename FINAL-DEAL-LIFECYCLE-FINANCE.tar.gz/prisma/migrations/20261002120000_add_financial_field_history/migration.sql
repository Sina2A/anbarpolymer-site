-- Append-only financial field history with a per-entity SHA-256 hash chain.
-- Prevention layer: BEFORE UPDATE/DELETE/TRUNCATE triggers raise an exception, so rows can only be inserted.
-- Proof layer (outside SQL): src/lib/financialHash.ts + scripts/financial-history.ts verify the chain.
--
-- NOTE: this file contains hand-written trigger SQL. `prisma db push` does NOT apply it,
-- so deploy with `prisma migrate deploy`, then check that this returns 2 rows:
--   SELECT tgname FROM pg_trigger WHERE tgrelid = '"FinancialFieldHistory"'::regclass AND NOT tgisinternal;

-- CreateTable
CREATE TABLE "FinancialFieldHistory" (
    "id" TEXT NOT NULL,
    "seq" INTEGER NOT NULL,
    "entityType" TEXT NOT NULL,
    "entityId" TEXT NOT NULL,
    "fieldName" TEXT NOT NULL,
    "oldValue" TEXT,
    "newValue" TEXT,
    "changedBy" TEXT,
    "changedAt" TIMESTAMP(3) NOT NULL,
    "idempotencyKey" TEXT NOT NULL,
    "hashVersion" INTEGER NOT NULL DEFAULT 1,
    "previousRecordHash" TEXT NOT NULL,
    "recordHash" TEXT NOT NULL,

    CONSTRAINT "FinancialFieldHistory_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "FinancialFieldHistory_idempotencyKey_key" ON "FinancialFieldHistory"("idempotencyKey");

-- CreateIndex
CREATE UNIQUE INDEX "FinancialFieldHistory_entityType_entityId_seq_key" ON "FinancialFieldHistory"("entityType", "entityId", "seq");

-- CreateIndex
CREATE INDEX "FinancialFieldHistory_entityType_entityId_fieldName_seq_idx" ON "FinancialFieldHistory"("entityType", "entityId", "fieldName", "seq");

-- Append-only enforcement (not tracked by Prisma; see the NOTE above)
CREATE FUNCTION "ffh_block_mutation"() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'FinancialFieldHistory is append-only: % is not allowed', TG_OP;
END;
$$;

CREATE TRIGGER "ffh_no_update_delete" BEFORE UPDATE OR DELETE ON "FinancialFieldHistory"
  FOR EACH ROW EXECUTE PROCEDURE "ffh_block_mutation"();

CREATE TRIGGER "ffh_no_truncate" BEFORE TRUNCATE ON "FinancialFieldHistory"
  FOR EACH STATEMENT EXECUTE PROCEDURE "ffh_block_mutation"();
