-- Deal accounting fields (admin-only, all manual; NULL = not entered = 0). Additive and nullable: no backfill.
ALTER TABLE "Deal"
  ADD COLUMN "weightKg" DOUBLE PRECISION,
  ADD COLUMN "dealFeeToman" DOUBLE PRECISION,
  ADD COLUMN "cargoInsuranceToman" DOUBLE PRECISION,
  ADD COLUMN "buyerTaxToman" DOUBLE PRECISION,
  ADD COLUMN "sellerTaxToman" DOUBLE PRECISION,
  ADD COLUMN "paidToman" DOUBLE PRECISION,
  ADD COLUMN "totalOverrideToman" DOUBLE PRECISION;
