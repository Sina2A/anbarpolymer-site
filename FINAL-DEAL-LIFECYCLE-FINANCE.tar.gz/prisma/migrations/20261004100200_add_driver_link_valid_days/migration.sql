-- AlterTable
ALTER TABLE "DealRuleSettings" ADD COLUMN "driverLinkValidDays" INTEGER NOT NULL DEFAULT 5;
