-- مالیاتِ دستیِ per-ردیف: مبلغ مالیاتِ کل همین ردیف (تومانِ صحیح). null = واردنشده = ۰.
-- افزایشی و بدون default و بدون backfill؛ ردیف‌های موجود null می‌مانند (مالیات ۰).
ALTER TABLE "OrderItem" ADD COLUMN "taxAmount" DOUBLE PRECISION;
