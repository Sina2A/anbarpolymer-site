-- Deal ledger adjustment rows (admin-only; soft delete; formKey UNIQUE = double-submit idempotency).
CREATE TABLE "DealLedgerAdjustment" (
    "id" TEXT NOT NULL,
    "dealId" TEXT NOT NULL,
    "amountToman" DOUBLE PRECISION NOT NULL,
    "direction" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "formKey" TEXT NOT NULL,
    "createdById" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,
    "deletedAt" TIMESTAMP(3),
    "deletedById" TEXT,

    CONSTRAINT "DealLedgerAdjustment_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "DealLedgerAdjustment_formKey_key" ON "DealLedgerAdjustment"("formKey");

CREATE INDEX "DealLedgerAdjustment_dealId_idx" ON "DealLedgerAdjustment"("dealId");

ALTER TABLE "DealLedgerAdjustment" ADD CONSTRAINT "DealLedgerAdjustment_dealId_fkey" FOREIGN KEY ("dealId") REFERENCES "Deal"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
