// src/lib/mobileNavItems.ts
//
// منبع واحد آیتم‌های ناوبری موبایل — فقط توسط کامپوننت‌های کلاینتی import
// می‌شود (همه‌ی مصرف‌کننده‌ها 'use client' هستند). طبق قانون سطح‌ها، لینک
// «خانه» از طریق prop هدایت‌شده‌ی homeHref از والد Server می‌رسد — این فایل
// هرگز process.env.SURFACE یا getSurfaceHome را نمی‌خواند.
//
// آیکون‌ها فقط SVG واقعی از lucide-react هستند (بدون ایموجی).

import {
  Home,
  Store,
  BarChart3,
  Phone,
  Layers,
  FileSearch,
  Warehouse,
  Briefcase,
  Info,
  LogIn,
  LayoutDashboard,
  ShoppingCart,
  Package,
  Truck,
  User,
  ShieldCheck,
  FileText,
  List,
  PlusCircle,
  Sparkles,
  Bell,
  LifeBuoy,
  LogOut,
} from 'lucide-react'
import type { LucideIcon } from 'lucide-react'

export type MobileNavItem = {
  label: string
  href: string
  icon: LucideIcon
}

export type MobileSheetItem = MobileNavItem & {
  // آیتم خروج از حساب فرمِ اکشن است، نه لینک — برای بقیه‌ی آیتم‌ها true.
  isLogout?: boolean
}

/**
 * تشخیص تب فعال از pathname فعلی:
 * - «/» فقط وقتی فعال است که دقیقاً روی خانه باشیم (وگرنه هر صفحه‌ای فعال می‌شد).
 * - بقیه با تطابق دقیق یا پیشوندِ همراه با «/» فعال می‌شوند
 *   (مثلاً /my-deals/abc هم تب «معاملات و حمل» را فعال نگه می‌دارد).
 */
export function isActivePath(pathname: string | null, href: string): boolean {
  const path = pathname ?? ''
  if (href === '/') return path === '/'
  return path === href || path.startsWith(`${href}/`)
}

// ──────────────────────────────────────────────────────────
// ۱. مهمان (پورتال عمومی) — ۴ تب ثابت پایین + ۶ آیتم شیت «بیشتر»
// ──────────────────────────────────────────────────────────
export const GUEST_BOTTOM_TABS: MobileNavItem[] = [
  { label: 'خانه', href: '/', icon: Home },
  { label: 'بازار صنعتی', href: '/market', icon: Store },
  { label: 'گزارش بازار', href: '/reports', icon: BarChart3 },
  { label: 'تماس با ما', href: '/contact', icon: Phone },
]

export const GUEST_SHEET_ITEMS: MobileSheetItem[] = [
  { label: 'کاتالوگ گریدها', href: '/grades', icon: Layers },
  { label: 'استعلام قیمت', href: '/rfq-public', icon: FileSearch },
  { label: 'انبارها', href: '/warehouses', icon: Warehouse },
  { label: 'خدمات سازمانی', href: '/services', icon: Briefcase },
  { label: 'درباره ما', href: '/about', icon: Info },
  { label: 'ورود / ثبت‌نام', href: '/login', icon: LogIn },
]

// ──────────────────────────────────────────────────────────
// ۲. کاربر لاگین‌شده (خریدار/فروشنده) — ۵ تب پایین + ۱۴ آیتم شیت «بیشتر»
//    تب‌های پایین = همان ۴ تب مهمان + «پیشخوان» به‌عنوان تب دوم.
//    ۴ آیتم نوار قدیمی (حساب من، سفارش‌ها، بازار من، معاملات و حمل) به
//    ابتدای شیت «بیشتر» منتقل شده‌اند تا هیچ آیتمی گم نشود.
//    «بازار من» = /purchase-requests (اعلام نیاز خرید بازار)؛ «معاملات و
//    حمل» = /my-deals (لینک ثانویه /transport هم داخل شیت هست).
// ──────────────────────────────────────────────────────────
export const USER_BOTTOM_TABS: MobileNavItem[] = [
  { label: 'خانه', href: '/', icon: Home },
  { label: 'پیشخوان', href: '/dashboard', icon: LayoutDashboard },
  { label: 'بازار صنعتی', href: '/market', icon: Store },
  { label: 'گزارش بازار', href: '/reports', icon: BarChart3 },
  { label: 'تماس با ما', href: '/contact', icon: Phone },
]

export const USER_SHEET_ITEMS: MobileSheetItem[] = [
  { label: 'حساب من', href: '/account', icon: User },
  { label: 'سفارش‌ها', href: '/my-orders', icon: Package },
  { label: 'انبارها', href: '/warehouses', icon: Warehouse },
  { label: 'بازار من', href: '/purchase-requests', icon: ShoppingCart },
  { label: 'معاملات و حمل', href: '/my-deals', icon: Truck },
  { label: 'احراز هویت', href: '/verification', icon: ShieldCheck },
  { label: 'پیش‌فاکتورهای من', href: '/proformas', icon: FileText },
  { label: 'شبکه عرضه‌ی من', href: '/my-listings', icon: List },
  { label: 'ثبت آگهی جدید', href: '/new-listing', icon: PlusCircle },
  { label: 'استعلام قیمت', href: '/rfq', icon: FileSearch },
  { label: 'درخواست غیرکاتالوگی', href: '/custom-request', icon: Sparkles },
  { label: 'هشدار قیمت', href: '/price-alerts', icon: Bell },
  { label: 'گریدها', href: '/grades', icon: Layers },
  { label: 'حمل و نقل', href: '/transport', icon: Truck },
  { label: 'پشتیبانی', href: '/support', icon: LifeBuoy },
  { label: 'خروج از حساب', href: '#', icon: LogOut, isLogout: true },
]
