'use client'

// src/components/mobile/MoreSheet.tsx
//
// Bottom Sheet مشترک «بیشتر» — مهمان و کاربر لاگین‌شده؛ لیست آیتم‌ها به‌صورت
// prop می‌آید. variant='guest' (پیش‌فرض) لیست تختِ فعلی را عیناً رندر می‌کند؛
// variant='user' ساختار گروه‌بندی‌شده دارد: CTA بالا + ردیف چیپ افقی + سه گروه
// لیبل‌دار + سطر خروج جدا. ارتفاع شیت (.mobile-sheet در globals.css) دست‌نخورده
// است — محتوای بلندتر داخل همان max-height اسکرول می‌خورد.
//
// گروه‌بندی با lookup روی href انجام می‌شود (نه لیست جدا) و هر آیتمی که در
// هیچ گروهی نیفتد به گروه آخر (fallback) می‌رود تا هیچ آیتمی بی‌صدا گم نشود.

import { useEffect } from 'react'
import { X, LogOut, ChevronLeft } from 'lucide-react'
import { logoutAction } from '@/app/logout/actions'
import type { MobileSheetItem } from '@/lib/mobileNavItems'

// href آیتم CTA (تنها، برجسته، بالای شیت کاربر)
const USER_CTA_HREF = '/new-listing'
// href چیپ‌های میان‌بر (ردیف افقی اسکرول‌شونده)
const USER_CHIP_HREFS = ['/account', '/my-orders', '/purchase-requests', '/my-deals']
// سه گروه لیبل‌دار — ترتیب رندر به همین ترتیب است
const USER_GROUPS: { label: string; hrefs: string[] }[] = [
  { label: 'امور تجاری و اسناد', hrefs: ['/proformas', '/rfq', '/custom-request'] },
  { label: 'شبکه و اطلاع‌رسانی', hrefs: ['/my-listings', '/price-alerts', '/warehouses', '/grades'] },
  { label: 'پشتیبانی و حساب کاربری', hrefs: ['/verification', '/transport', '/support'] },
]

export default function MoreSheet({
  items,
  open,
  onClose,
  title,
  variant = 'guest',
}: {
  items: MobileSheetItem[]
  open: boolean
  onClose: () => void
  title: string
  variant?: 'guest' | 'user'
}) {
  // بستن با Escape — دسترس‌پذیری پایه
  useEffect(() => {
    if (!open) return
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [open, onClose])

  // قفل اسکرول بدنه وقتی شیت باز است
  useEffect(() => {
    if (!open) return
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      document.body.style.overflow = prev
    }
  }, [open])

  if (!open) return null

  // ---------- تفکیک آیتم‌ها برای variant='user' ----------
  const logoutItem = items.find((i) => i.isLogout)
  const ctaItem = items.find((i) => !i.isLogout && i.href === USER_CTA_HREF)
  const chipItems = items.filter((i) => !i.isLogout && i.href !== USER_CTA_HREF && USER_CHIP_HREFS.includes(i.href))
  const grouped = USER_GROUPS.map((g) => ({
    label: g.label,
    items: items.filter((i) => !i.isLogout && i.href !== USER_CTA_HREF && !USER_CHIP_HREFS.includes(i.href) && g.hrefs.includes(i.href)),
  }))
  const knownHrefs = new Set([USER_CTA_HREF, ...USER_CHIP_HREFS, ...USER_GROUPS.flatMap((g) => g.hrefs)])
  // fallback — آیتم‌های بدون گروه به گروه آخر می‌روند تا گم نشوند
  const fallbackItems = items.filter((i) => !i.isLogout && !knownHrefs.has(i.href))
  if (fallbackItems.length > 0 && grouped.length > 0) {
    grouped[grouped.length - 1] = {
      label: grouped[grouped.length - 1].label,
      items: [...grouped[grouped.length - 1].items, ...fallbackItems],
    }
  }

  const renderLogout = () =>
    logoutItem ? (
      <form action={logoutAction} className="mobile-sheet-form mobile-sheet-logout-wrap">
        <button type="submit" className="mobile-sheet-item mobile-sheet-item-logout">
          <LogOut size={18} strokeWidth={1.9} />
          <span>{logoutItem.label}</span>
        </button>
      </form>
    ) : null

  return (
    <>
      <button
        type="button"
        className="mobile-sheet-scrim open"
        aria-label="بستن منوی بیشتر"
        onClick={onClose}
      />
      <div className="mobile-sheet open" role="dialog" aria-modal="true" aria-label={title}>
        <div className="mobile-sheet-handle" aria-hidden="true" />
        <div className="mobile-sheet-head">
          <span className="mobile-sheet-title">{title}</span>
          <button
            type="button"
            className="mobile-sheet-close"
            aria-label="بستن"
            onClick={onClose}
          >
            <X size={18} strokeWidth={2.2} />
          </button>
        </div>

        {variant === 'user' ? (
          <nav className="mobile-sheet-list">
            {/* CTA — ثبت آگهی جدید */}
            {ctaItem && (
              <a href={ctaItem.href} className="mobile-sheet-cta" onClick={onClose}>
                {(() => {
                  const Icon = ctaItem.icon
                  return <Icon size={18} strokeWidth={1.9} />
                })()}
                <span>{ctaItem.label}</span>
              </a>
            )}

            {/* ردیف چیپ افقی */}
            {chipItems.length > 0 && (
              <div className="mobile-sheet-chips">
                {chipItems.map((item) => {
                  const Icon = item.icon
                  return (
                    <a key={item.label} href={item.href} className="mobile-sheet-chip" onClick={onClose}>
                      <Icon size={16} strokeWidth={1.9} />
                      <span>{item.label}</span>
                    </a>
                  )
                })}
              </div>
            )}

            {/* سه گروه لیبل‌دار */}
            {grouped.map((g) =>
              g.items.length === 0 ? null : (
                <div key={g.label} className="mobile-sheet-group">
                  <span className="mobile-sheet-group-label">{g.label}</span>
                  {g.items.map((item) => {
                    const Icon = item.icon
                    return (
                      <a key={item.label} href={item.href} className="mobile-sheet-item" onClick={onClose}>
                        <Icon size={18} strokeWidth={1.9} />
                        <span>{item.label}</span>
                        <ChevronLeft size={14} strokeWidth={1.8} className="mobile-sheet-chevron" />
                      </a>
                    )
                  })}
                </div>
              )
            )}

            {renderLogout()}
          </nav>
        ) : (
          <nav className="mobile-sheet-list">
            {items.map((item) => {
              const Icon = item.isLogout ? LogOut : item.icon
              if (item.isLogout) {
                return (
                  <form key={item.label} action={logoutAction} className="mobile-sheet-form">
                    <button type="submit" className="mobile-sheet-item mobile-sheet-item-logout">
                      <Icon size={18} strokeWidth={1.9} />
                      <span>{item.label}</span>
                    </button>
                  </form>
                )
              }
              return (
                <a
                  key={item.label}
                  href={item.href}
                  className="mobile-sheet-item"
                  onClick={onClose}
                >
                  <Icon size={18} strokeWidth={1.9} />
                  <span>{item.label}</span>
                </a>
              )
            })}
          </nav>
        )}
      </div>
    </>
  )
}
