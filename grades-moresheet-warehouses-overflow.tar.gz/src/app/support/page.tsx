import prisma from '@/lib/prisma'
import { getSurfaceHome } from '@/lib/surfaceHome'
import { getCurrentUser } from '@/lib/currentUser'
import UserNav from '@/components/UserNav'
import PanelHeader from '@/components/PanelHeader'
import Footer from '@/components/Footer'
import { createTicketAction } from './actions'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { cardStyle as sharedCardStyle, badgeStyle, btnPrimaryStyle, inputStyle as sharedInputStyle, labelStyle as sharedLabelStyle, emptyStateStyle } from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

export default async function SupportPage() {
  const user = await getCurrentUser()

  const tickets = await prisma.supportTicket.findMany({
    where: { userId: user.id },
    include: { _count: { select: { messages: true } } },
    orderBy: [{ updatedAt: 'desc' }, { id: 'asc' }],
  })

  return (
    <>
      <PanelHeader homeHref={getSurfaceHome()} currentUserName={user.companyName} />
      <div className="admin-page-wrap" style={{ display: 'flex', gap: spacing.xl, padding: `${spacing.xxl}px ${spacing.xl}px`, fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', width: '100%', background: colors.bgCard, minHeight: '100vh' }}>
        <UserNav currentUserName={user.companyName} activeSection="support" />

        <div style={{ flex: 1, minWidth: 0 }}>
          <h1 style={{ fontSize: fontSize.xxl, fontWeight: 800, marginBottom: spacing.sm, color: colors.textPrimary }}>پشتیبانی</h1>
          <p style={{ color: colors.textSecondary, fontSize: fontSize.md, marginBottom: 22, lineHeight: 1.9 }}>
            مشکل یا سوالت رو ثبت کن — کارشناس ما همین‌جا جواب می‌ده و می‌تونی گفتگو رو ادامه بدی.
          </p>

          {/* ── فرم تیکت جدید ── */}
          <div style={cardStyle}>
            <b style={{ fontSize: fontSize.md, display: 'block', marginBottom: spacing.lg }}>ثبت تیکت جدید</b>
            <form action={createTicketAction}>
              <div style={{ marginBottom: 12 }}>
                <div style={labelStyle}>موضوع</div>
                <input name="subject" required maxLength={120} placeholder="مثلاً: مشکل در تایید فیش پرداخت"
                  style={inputStyle} />
              </div>
              <div style={{ marginBottom: 14 }}>
                <div style={labelStyle}>شرح مشکل</div>
                <textarea name="detail" rows={5} required placeholder="توضیح بده چه اتفاقی افتاده…"
                  style={{ ...inputStyle, resize: 'vertical' }} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                <button type="submit" style={submitBtnStyle}>ثبت تیکت</button>
              </div>
            </form>
          </div>

          {/* ── لیست تیکت‌های من ── */}
          <h2 style={{ fontSize: fontSize.lg, fontWeight: 700, margin: '28px 0 14px', color: colors.textPrimary }}>تیکت‌های من</h2>
          {tickets.length === 0 ? (
            <div style={emptyStateStyle}>
              هنوز تیکتی ثبت نکردی.
            </div>
          ) : (
            <div className="scroll-panel" style={panelStyle}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {tickets.map((t, i) => (
                <a key={t.id} href={`/support/${t.id}`} style={{ textDecoration: 'none' }}>
                  <div style={{ ...cardStyle, padding: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: spacing.md }}>
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontSize: fontSize.md, fontWeight: 700, color: colors.navy, marginBottom: 4 }}>{i + 1}. {t.subject}</div>
                      <div style={{ fontSize: fontSize.xs, color: colors.textMuted }}>
                        {t._count.messages} پیام · آخرین بروزرسانی {new Date(t.updatedAt).toLocaleDateString('fa-IR')}
                      </div>
                    </div>
                    <span style={statusTagStyle(t.status)}>{translateStatus(t.status)}</span>
                  </div>
                </a>
              ))}
              </div>
            </div>
          )}
        </div>
      </div>
      <Footer homeHref={getSurfaceHome()} />
    </>
  )
}

// ── ترجمه و رنگ وضعیت ─────────────────────────────────────────────────
function translateStatus(status: string): string {
  const map: Record<string, string> = { open: 'باز', answered: 'پاسخ‌داده‌شده', closed: 'بسته' }
  return map[status] ?? status
}

function statusTagStyle(status: string): React.CSSProperties {
  let kind: 'warning' | 'success' | 'neutral' = 'neutral'
  if (status === 'open') kind = 'warning'
  else if (status === 'answered') kind = 'success'
  else if (status === 'closed') kind = 'neutral'
  return badgeStyle(kind)
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const cardStyle: React.CSSProperties = {
  ...sharedCardStyle, padding: 20, marginBottom: 0,
}
const inputStyle: React.CSSProperties = {
  ...sharedInputStyle,
}
const labelStyle: React.CSSProperties = {
  ...sharedLabelStyle,
}
const submitBtnStyle: React.CSSProperties = {
  ...btnPrimaryStyle,
  fontSize: fontSize.sm,
  fontWeight: 700,
}
const panelStyle: React.CSSProperties = {
  ...sharedCardStyle,
  padding: 16,
}
