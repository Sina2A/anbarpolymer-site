import prisma from '@/lib/prisma'
import { getSurfaceHome } from '@/lib/surfaceHome'
import PublicHeader from '@/components/PublicHeader'
import { getCurrentUserOrNull } from '@/lib/currentUser'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { inputStyle as sharedInputStyle, selectStyle as sharedSelectStyle, emptyStateStyle } from '@/lib/styles/shared'
import Footer from '@/components/Footer'
import MobileGradeCatalog, { type MobileGrade } from './MobileGradeCatalog'

export const dynamic = 'force-dynamic'

// نگاشت بسته: کاراکتر ورودیِ URL → فیلد دیتابیس
// برای اینکه فیلتر جدید اضافه کنیم، فقط یه سطر به URL_FIELDS و یه شاخه
// به whereBuilder زیر اضافه کن — بدون دست‌زدن به Prisma یا بقیه فایل.
const URL_FIELDS = {
  q: 'q',
  category: 'category',
  family: 'polymerFamily',
} as const

function one(v: string | string[] | undefined): string | undefined {
  if (Array.isArray(v)) return v[0]
  return v
}

export default async function GradesPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>
}) {
  const sp = await searchParams
  const user = await getCurrentUserOrNull()
  const q = one(sp.q)?.trim() || ''
  const category = one(sp.category)?.trim() || ''
  const family = one(sp.family)?.trim() || ''

  // ---------- ساخت where ----------
  const where: Record<string, unknown> = { isActive: true }

  if (q) {
    ;(where as Record<string, unknown>).OR = [
      { code: { contains: q, mode: 'insensitive' } },
      { producer: { contains: q, mode: 'insensitive' } },
      { category: { contains: q, mode: 'insensitive' } },
      { polymerFamily: { contains: q, mode: 'insensitive' } },
    ]
  }
  if (category) where.category = category
  if (family) where.polymerFamily = family

  // ---------- کوئری ----------
  const grades = await prisma.grade.findMany({
    where: where as never,
    orderBy: [{ producer: 'asc' }, { code: 'asc' }],
  })

  // گزینه‌های فیلتر — از distinct واقعی دیتابیس، نه هاردکد
  const [allCategories, allFamilies] = await Promise.all([
    prisma.grade.findMany({
      where: { isActive: true },
      distinct: ['category'],
      select: { category: true },
      orderBy: { category: 'asc' },
    }),
    prisma.grade.findMany({
      where: { isActive: true, polymerFamily: { not: null } },
      distinct: ['polymerFamily'],
      select: { polymerFamily: true },
      orderBy: { polymerFamily: 'asc' },
    }),
  ])

  const categories: string[] = allCategories.map((r) => r.category)
  const families: string[] = allFamilies
    .map((r) => r.polymerFamily)
    .filter((v): v is string => !!v)

  // نسخه‌ی موبایل — فقط فیلدهای اسکالر (سریالایزپذیر برای RSC → Client)
  const mobileGrades: MobileGrade[] = grades.map((g) => ({
    code: g.code,
    producer: g.producer,
    category: g.category,
    polymerFamily: g.polymerFamily,
    applicationType: g.applicationType,
    mfi: g.mfi,
    density: g.density,
    imageUrl: g.imageUrl,
  }))

  return (
    <>
      <PublicHeader homeHref={getSurfaceHome()} activePage="/grades" isLoggedIn={!!user} />

      <section>
        <div className="wrap">
          <div className="eyebrow">دیتاشیت و مقایسه گریدها</div>
          <div className="sec-title">مشخصات فنی گریدهای پلیمری</div>
          <div className="sec-sub" style={{ marginBottom: 20 }}>
            این صفحه فقط برای مقایسه‌ی فنی گریدهاست؛ برای قیمت و موجودی به صفحه‌ی استعلام قیمت مراجعه کنید. —{' '}
            <b style={{ color: colors.orange }}>{grades.length} گرید فعال</b>
          </div>

          <div className="grades-desktop">
          {/* ---------- فیلترها ---------- */}
          <form method="GET" action="/grades" style={filterFormStyle}>
            <input
              name="q"
              defaultValue={q}
              placeholder="جستجو: کد، تولیدکننده، دسته، خانواده پلیمری…"
              style={inputStyle}
            />
            <select name="category" defaultValue={category} style={selectStyle}>
              <option value="">همه‌ی دسته‌ها</option>
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
            <select name="family" defaultValue={family} style={selectStyle}>
              <option value="">همه‌ی خانواده‌ها</option>
              {families.map((f) => (
                <option key={f} value={f}>
                  {f}
                </option>
              ))}
            </select>
            <button type="submit" className="btn btn-sm" style={{ whiteSpace: 'nowrap' }}>
              اعمال فیلتر
            </button>
            {(q || category || family) && (
              <a href="/grades" className="btn btn-sm btn-outline" style={{ whiteSpace: 'nowrap' }}>
                پاک کردن
              </a>
            )}
          </form>

          {/* ---------- لیست گریدها ---------- */}
          {grades.length === 0 ? (
            <div style={emptyStyle}>هیچ گرید فعالی با این فیلتر یافت نشد.</div>
          ) : (
            <div style={gridStyle}>
              {grades.map((g) => (
                <a key={g.id} href={`/grades/${encodeURIComponent(g.code)}`} style={cardStyle}>
                  {/* عکس */}
                  <div style={thumbWrapStyle}>
                    {g.imageUrl ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={g.imageUrl} alt={g.code} style={thumbImgStyle} />
                    ) : (
                      <div style={thumbPlaceholderStyle}>بدون تصویر</div>
                    )}
                  </div>

                  {/* متن */}
                  <div style={{ padding: '12px 14px', flex: 1 }}>
                    <div style={codeStyle}>{g.code}</div>
                    <div style={producerStyle}>{g.producer}</div>
                    <div style={categoryStyle}>{g.category}</div>

                    <div style={specRowStyle}>
                      {g.mfi != null && (
                        <span style={specChipStyle}>
                          MFI {g.mfi} g/10min
                        </span>
                      )}
                      {g.density != null && (
                        <span style={specChipStyle}>
                          چگالی {g.density} g/cm³
                        </span>
                      )}
                    </div>

                    {g.applicationType && (
                      <div style={appTypeStyle}>{g.applicationType}</div>
                    )}
                  </div>

                  <div style={cardFootStyle}>مشاهده دیتاشیت ←</div>
                </a>
              ))}
            </div>
          )}
          </div>

          {/* ---------- نسخه‌ی موبایل (زیر 899px) ---------- */}
          <MobileGradeCatalog grades={mobileGrades} />
        </div>
      </section>

      <Footer homeHref={getSurfaceHome()} />
    </>
  )
}

// ---------- style objects (inline — هماهنگ با بقیه‌ی پروژه) ----------

const filterFormStyle: React.CSSProperties = {
  display: 'flex',
  flexWrap: 'wrap',
  gap: spacing.sm,
  marginBottom: 20,
  padding: spacing.md,
  background: colors.bgHover,
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
}

const inputStyle: React.CSSProperties = {
  flex: '1 1 200px',
  minWidth: 0,
  ...sharedInputStyle,
}

const selectStyle: React.CSSProperties = {
  ...sharedSelectStyle,
  minWidth: 140,
}

const gridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))',
  gap: spacing.lg,
}

const cardStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  border: `1px solid ${colors.borderSubtle}`,
  borderRadius: radius.lg,
  overflow: 'hidden',
  background: colors.bgCard,
  textDecoration: 'none',
  color: 'inherit',
  transition: 'box-shadow .15s',
}

const thumbWrapStyle: React.CSSProperties = {
  height: 150,
  background: colors.neutralBg,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  overflow: 'hidden',
}

const thumbImgStyle: React.CSSProperties = {
  width: '100%',
  height: '100%',
  objectFit: 'cover',
}

const thumbPlaceholderStyle: React.CSSProperties = {
  color: colors.textMuted,
  fontSize: fontSize.xs,
}

const codeStyle: React.CSSProperties = { fontSize: fontSize.md, fontWeight: 800, color: colors.textPrimary }
const producerStyle: React.CSSProperties = { fontSize: fontSize.xs, color: colors.textSecondary, marginTop: 2 }
const categoryStyle: React.CSSProperties = { fontSize: fontSize.xs, color: colors.textMuted, marginTop: 2 }

const specRowStyle: React.CSSProperties = {
  display: 'flex',
  flexWrap: 'wrap',
  gap: 6,
  marginTop: spacing.md,
}

const specChipStyle: React.CSSProperties = {
  fontSize: fontSize.xs,
  background: colors.neutralBg,
  color: colors.neutralText,
  borderRadius: radius.sm,
  padding: '3px 8px',
}

const appTypeStyle: React.CSSProperties = {
  marginTop: spacing.sm,
  fontSize: fontSize.xs,
  color: colors.orange,
  background: colors.warningBg,
  borderRadius: radius.sm,
  padding: '3px 8px',
  display: 'inline-block',
}

const cardFootStyle: React.CSSProperties = {
  padding: `${spacing.sm}px 14px`,
  borderTop: `1px solid ${colors.borderSubtle}`,
  fontSize: fontSize.xs,
  color: colors.orange,
  fontWeight: 700,
  textAlign: 'center',
}

const emptyStyle: React.CSSProperties = {
  ...emptyStateStyle,
  padding: 40,
  border: `1px dashed ${colors.borderStrong}`,
  borderRadius: radius.lg,
}
