'use client'

import { useMemo, useState } from 'react'
import { Search, X, ImageIcon } from 'lucide-react'
import { colors, fontSize } from '@/lib/styles/tokens'

// ۸ فیلد اسکالر — سریالایزپذیر برای RSC → Client
export type MobileGrade = {
  code: string
  producer: string
  category: string
  polymerFamily: string | null
  applicationType: string | null
  mfi: number | null
  density: number | null
  imageUrl: string | null
}

type SortKey = 'default' | 'mfi' | 'name'

export default function MobileGradeCatalog({ grades }: { grades: MobileGrade[] }) {
  const [query, setQuery] = useState('')
  const [family, setFamily] = useState('')
  const [sort, setSort] = useState<SortKey>('default')

  // خانواده‌های متمایز — مشتق از داده‌ی واقعی، نه هاردکد
  const families = useMemo(() => {
    const set = new Set<string>()
    for (const g of grades) if (g.polymerFamily) set.add(g.polymerFamily)
    return Array.from(set).sort()
  }, [grades])

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase()
    const out = grades.filter((g) => {
      const matchQuery =
        !q ||
        g.code.toLowerCase().includes(q) ||
        g.producer.toLowerCase().includes(q) ||
        g.category.toLowerCase().includes(q)
      const matchFamily = !family || g.polymerFamily === family
      return matchQuery && matchFamily
    })
    if (sort === 'mfi') {
      out.sort((a, b) => (a.mfi ?? Infinity) - (b.mfi ?? Infinity))
    } else if (sort === 'name') {
      out.sort((a, b) => a.code.localeCompare(b.code, 'fa'))
    }
    return out
  }, [grades, query, family, sort])

  const hasFilters = query.trim() !== '' || family !== '' || sort !== 'default'

  return (
    <div className="grades-mobile">
      {/* جستجو */}
      <div style={{ position: 'relative', marginBottom: 8 }}>
        <span
          style={{
            position: 'absolute',
            inset: '0 10px auto auto',
            height: 38,
            display: 'flex',
            alignItems: 'center',
            color: colors.textMuted,
            pointerEvents: 'none',
          }}
        >
          <Search size={14} strokeWidth={1.9} />
        </span>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="جستجوی گرید، پتروشیمی…"
          className="grades-mobile-search"
        />
      </div>

      {/* پیل‌های خانواده — اسکرول افقی */}
      <div className="grades-pill-row">
        <button
          type="button"
          className={`grades-pill${family === '' ? ' is-active' : ''}`}
          onClick={() => setFamily('')}
        >
          همه
        </button>
        {families.map((f) => (
          <button
            key={f}
            type="button"
            className={`grades-pill${family === f ? ' is-active' : ''}`}
            onClick={() => setFamily(f)}
          >
            {f}
          </button>
        ))}
      </div>

      {/* شمارنده + مرتب‌سازی */}
      <div className="grades-mobile-meta">
        <span>نمایش {visible.length} گرید</span>
        <select value={sort} onChange={(e) => setSort(e.target.value as SortKey)} className="grades-mobile-sort">
          <option value="default">مرتب‌سازی پیش‌فرض</option>
          <option value="mfi">MFI (کم به زیاد)</option>
          <option value="name">نام گرید (الف - ی)</option>
        </select>
      </div>

      {/* گرید دوستونه */}
      {visible.length === 0 ? (
        <div className="grades-mobile-empty">
          <span style={{ display: 'flex', justifyContent: 'center', marginBottom: 6, color: colors.orange }}>
            <X size={22} strokeWidth={1.9} />
          </span>
          <div style={{ fontWeight: 700, fontSize: fontSize.sm, color: colors.textPrimary, marginBottom: 8 }}>
            نتیجه‌ای یافت نشد
          </div>
          {hasFilters && (
            <button
              type="button"
              className="grades-mobile-reset"
              onClick={() => {
                setQuery('')
                setFamily('')
                setSort('default')
              }}
            >
              پاک کردن فیلترها
            </button>
          )}
        </div>
      ) : (
        <div className="grades-mobile-grid">
          {visible.map((g) => (
            <a key={g.code} href={`/grades/${encodeURIComponent(g.code)}`} className="grades-m-card">
              {/* تصویر — عکس واقعی یا placeholder آیکن */}
              <div className="grades-m-thumb">
                {g.imageUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={g.imageUrl} alt={g.code} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                ) : (
                  <span style={{ color: colors.textMuted }}>
                    <ImageIcon size={18} strokeWidth={1.6} />
                  </span>
                )}
              </div>

              <div style={{ padding: '8px 9px', flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 4, marginBottom: 4 }}>
                  {g.polymerFamily ? (
                    <span className="grades-m-family">{g.polymerFamily}</span>
                  ) : (
                    <span />
                  )}
                  <span className="grades-m-producer">{g.producer}</span>
                </div>
                <div className="grades-m-code">{g.code}</div>

                <div className="grades-m-specs">
                  <div className="grades-m-specrow">
                    <span className="grades-m-speclabel">MFI:</span>
                    <span className="grades-m-specval">{g.mfi != null ? g.mfi : '—'}</span>
                  </div>
                  <div className="grades-m-specrow">
                    <span className="grades-m-speclabel">چگالی:</span>
                    <span className="grades-m-specval">{g.density != null ? g.density : '—'}</span>
                  </div>
                </div>

                <div className="grades-m-foot">
                  <span className="grades-m-cat">{g.category}</span>
                  <span className="grades-m-more">جزئیات ←</span>
                </div>
              </div>
            </a>
          ))}
        </div>
      )}
    </div>
  )
}
