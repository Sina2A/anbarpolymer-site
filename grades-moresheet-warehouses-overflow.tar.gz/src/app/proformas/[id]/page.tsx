import prisma from '@/lib/prisma'
import { getSurfaceHome } from '@/lib/surfaceHome'
import { getCurrentUser } from '@/lib/currentUser'
import { notFound } from 'next/navigation'
import UserNav from '@/components/UserNav'
import PanelHeader from '@/components/PanelHeader'
import Footer from '@/components/Footer'
import ProformaBankPay from '@/components/ProformaBankPay'
import RefundPolicyHint from '@/components/RefundPolicyHint'
import { enforceProformaDeadlines } from '@/lib/dealDeadlines'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { cardStyle as sharedCardStyle, orderStatusBadgeStyle, getOrderStatusLabel, getOrderStatusNextAction } from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

/**
 * صفحه‌ی جزئیات پیش‌فاکتور — چیدمان طبق پروتوتایپ استاتیک تاییدشده:
 *   ۱. عنوان سفارش + گریدها
 *   ۲. کارت فایل پیش‌فاکتور (فعلاً دکمه‌ی غیرفعال — فیلد proformaPdfUrl روی Order وجود نداره)
 *   ۳. جدول اقلام با مالیات ۹٪
 *   ۴. خلاصه + کارت برجسته‌ی جمع کل
 *   ۵. نوار وضعیت
 *   ۶. دو کارت انتخاب روش پرداخت (بانکی فعال / آنلاین به‌زودی)
 *   ۷. برچسب‌های نتیجه‌ی بررسی فیش + شماره‌ی فاکتور رسمی پس از تایید مالی
 */

const VAT_RATE = 0.09

const STATUS_TEXT: Record<string, string> = {
  priced: 'قیمت ثبت شد — در انتظار تایید شما',
  buyer_confirmed: 'قیمت تایید شد — در حال تنظیم قرارداد',
  awaiting_approval: 'در انتظار تایید مدیر',
  contracted: getOrderStatusLabel('contracted'),
  paid: getOrderStatusLabel('paid'),
  loading: getOrderStatusLabel('loading'),
  in_transit: getOrderStatusLabel('in_transit'),
  delivered: getOrderStatusLabel('delivered'),
  rejected: 'سفارش باطل شد — مهلت تایید پیش‌فاکتور گذشت و موجودی به انبار برگشت',
}

/** مراحلی که کاربر هنوز می‌تونه پرداخت کنه (قبل از تایید مالی) */
const PAYABLE_STATUSES = ['priced', 'buyer_confirmed', 'contracted']

export default async function ProformaDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const user = await getCurrentUser()

  // مثل بقیه‌ی مهلت‌ها (بدون cron): قبل از نمایش، چک می‌شه آیا مهلت تایید این
  // پیش‌فاکتور گذشته — اگه آره، سفارش باطل و موجودی به انبار برمی‌گرده.
  await enforceProformaDeadlines()

  // فقط سفارش خودِ کاربر — در غیر این صورت 404 (نه 403، تا id دیگه‌ها لو نره)
  const order = await prisma.order.findFirst({
    where: { id, userId: user.id },
    include: { items: { include: { grade: true } }, invoice: true },
  })
  if (!order) notFound()

  const shortId = order.id.slice(0, 8)
  const gradeSummary = order.items.map((i) => i.grade.code).join(' + ')

  // محاسبات مالی — قیمت واحد = قیمت نهایی کارشناس (اگه ثبت شده) وگرنه snapshot مرجع
  const rows = order.items.map((item) => {
    const unitPrice = item.finalPrice ?? item.price
    const lineTotal = unitPrice * item.quantity
    const lineVat = lineTotal * VAT_RATE
    return { item, unitPrice, lineTotal, lineVat }
  })
  const itemsTotal = rows.reduce((s, r) => s + r.lineTotal, 0)
  const vatTotal = rows.reduce((s, r) => s + r.lineVat, 0)
  const grandTotal = itemsTotal + vatTotal

  const canPay = PAYABLE_STATUSES.includes(order.status)
  const paymentChosen = Boolean(order.paymentReceiptUrl)

  return (
    <>
    <PanelHeader homeHref={getSurfaceHome()} currentUserName={user.companyName} />
    <div style={pageStyle}>
      <div style={{ width: '100%', display: 'flex', gap: 24 }} className="admin-page-wrap">
        <UserNav currentUserName={user.companyName} activeSection="proformas" />
        <div style={{ flex: 1, minWidth: 0 }}>
          {/* ۱. عنوان */}
          <a href="/proformas" style={{ fontSize: fontSize.sm, color: colors.textMuted, textDecoration: 'none', display: 'inline-block', marginBottom: spacing.md }}>
            → بازگشت به لیست پیش‌فاکتورها
          </a>
          <h1 style={{ fontSize: fontSize.xxl, fontWeight: 800, marginBottom: spacing.xl, color: colors.textPrimary, wordBreak: 'break-word' }}>
            سفارش #{shortId} — <span style={{ fontFamily: 'monospace', fontSize: fontSize.lg }}>{gradeSummary}</span>
          </h1>

          {/* ۲. کارت فایل پیش‌فاکتور */}
          <div style={fileCard}>
            <div style={{ fontSize: 30 }}>📄</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: fontSize.md, fontWeight: 700, fontFamily: 'monospace' }}>
                پیش‌فاکتور_{shortId}.pdf
              </div>
              <div style={{ fontSize: fontSize.xs, color: colors.textMuted, marginTop: 3 }}>
                آپلودشده توسط تیم فروش — {new Date(order.createdAt).toLocaleDateString('fa-IR')}
              </div>
            </div>
            <button type="button" disabled style={disabledPdfBtn} title="فایل رسمی پس از اتصال آبجکت‌استوریج فعال می‌شود">
              مشاهده / دانلود (PDF یا چاپ)
            </button>
          </div>
          <div style={storageNote}>
            فایل رسمی امضاشده پس از اتصال آبجکت‌استوریج در همین‌جا جایگزین می‌شود.
          </div>

          {/* ۳. جدول اقلام */}
          <div style={whiteCard}>
            <div style={{ fontSize: fontSize.lg, fontWeight: 800, marginBottom: spacing.lg }}>اقلام پیش‌فاکتور</div>
            <div style={{ overflowX: 'auto', WebkitOverflowScrolling: 'touch' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ borderBottom: `1.5px solid ${colors.borderSubtle}` }}>
                  <th style={th}>گرید</th>
                  <th style={th}>مقدار</th>
                  <th style={th}>قیمت واحد</th>
                  <th style={th}>جمع</th>
                  <th style={th}>مالیات (۹٪)</th>
                </tr>
              </thead>
              <tbody>
                {rows.map(({ item, unitPrice, lineTotal, lineVat }) => (
                  <tr key={item.id} style={{ borderBottom: `1px solid ${colors.borderSubtle}` }}>
                    <td style={{ ...td, fontFamily: 'monospace', fontWeight: 700 }}>{item.grade.code}</td>
                    <td style={td}>{item.quantity} تن</td>
                    <td style={{ ...td, fontFamily: 'monospace' }}>{unitPrice.toLocaleString('en-US')}</td>
                    <td style={{ ...td, fontFamily: 'monospace' }}>{lineTotal.toLocaleString('en-US')}</td>
                    <td style={{ ...td, fontFamily: 'monospace' }}>{lineVat.toLocaleString('en-US')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            </div>

            {/* ۴. خلاصه */}
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 18 }}>
              <div style={{ minWidth: 280 }}>
                <SummaryRow label="جمع اقلام" value={`${itemsTotal.toLocaleString('en-US')} ریال`} />
                <SummaryRow label="مالیات بر ارزش‌افزوده (۹٪)" value={`${vatTotal.toLocaleString('en-US')} ریال`} />
              </div>
            </div>
          </div>

          {/* ۴. کارت برجسته‌ی جمع کل */}
          <div style={highlightCard}>
            <div style={{ fontSize: fontSize.base, fontWeight: 700, color: colors.warningText }}>جمع کل قابل پرداخت (با احتساب مالیات) <RefundPolicyHint /></div>
            <div style={{ fontSize: 26, fontWeight: 800, color: colors.warningText, marginTop: 6, fontFamily: 'monospace' }}>
              {grandTotal.toLocaleString('en-US')} ریال
            </div>
          </div>

          {/* ۵. نوار وضعیت */}
          <div style={statusBar}>
            وضعیت: {STATUS_TEXT[order.status] || getOrderStatusLabel(order.status) || order.status}
          </div>
          {getOrderStatusNextAction(order.status) && (
            <div style={{ marginTop: 8, fontSize: fontSize.sm, fontWeight: 700, color: colors.textMuted }}>
              اقدام بعدی: {getOrderStatusNextAction(order.status)}
            </div>
          )}

          {order.status === 'priced' && order.proformaDeadline && (
            <div style={{ marginTop: 10, fontSize: fontSize.sm, fontWeight: 700, color: colors.warningText }}>
              ⏳ مهلت تایید شما: {new Date(order.proformaDeadline).toLocaleString('fa-IR', { dateStyle: 'short', timeStyle: 'short' })} — بعد از این زمان، در صورت عدم تایید، سفارش خودکار باطل می‌شود.
            </div>
          )}

          {/* ۶. انتخاب روش پرداخت — دو کارت */}
          {(canPay || order.status === 'paid') && !paymentChosen && (
            <div style={{ display: 'flex', gap: spacing.lg, flexWrap: 'wrap', marginTop: 18 }}>
              {/* کارت راست: پرداخت بانکی */}
              <div style={{ ...payCard, flex: '1 1 300px', border: `1.5px solid ${colors.orange}` }}>
                <div style={{ fontSize: fontSize.lg, fontWeight: 800 }}>🏦 پرداخت بانکی</div>
                <div style={{ fontSize: fontSize.sm, color: colors.textMuted, margin: '6px 0 14px' }}>واریز و آپلود فیش</div>
                <ProformaBankPay
                  orderId={order.id}
                  amountLabel={`${grandTotal.toLocaleString('en-US')} ریال`}
                  purposeLabel={`پرداخت پیش‌فاکتور سفارش #${shortId}`}
                  disabled={!canPay}
                  disabledHint="پرداخت پس از عقد قرارداد فعال می‌شود"
                />
              </div>

              {/* کارت چپ: پرداخت آنلاین — به‌زودی */}
              <div style={{ ...payCard, flex: '1 1 300px' }}>
                <div style={{ fontSize: fontSize.lg, fontWeight: 800 }}>💳 پرداخت آنلاین</div>
                <div style={{ fontSize: fontSize.sm, color: colors.textMuted, margin: '6px 0 14px' }}>به‌زودی فعال می‌شود</div>
                <button type="button" disabled style={disabledBtn}>
                  غیرفعال
                </button>
              </div>
            </div>
          )}

          {/* وضعیت رسید پرداخت — پیام‌های متفاوت بر اساس نتیجه‌ی بررسی */}
          {order.paymentReceiptStatus === 'approved' && (
            <div style={{ marginTop: 18 }}>
              <div style={receiptApprovedTag}>
                ✓ فیش پرداخت تایید شد — پرداخت شما تأیید گردید
              </div>
              {/* فاکتور رسمی — با تایید فیش خودکار صادر می‌شه (lib/invoices)؛ مبالغ snapshot لحظه‌ی صدوره */}
              {order.invoice && (
                <div style={invoiceIssuedTag}>
                  🧾 فاکتور رسمی صادر شد — شماره:{' '}
                  <span style={{ fontFamily: 'monospace', fontWeight: 800, direction: 'ltr', display: 'inline-block' }}>
                    {order.invoice.number}
                  </span>
                  {' '}— تاریخ صدور: {new Date(order.invoice.issuedAt).toLocaleDateString('fa-IR')}
                </div>
              )}
            </div>
          )}
          {order.paymentReceiptStatus === 'rejected' && (
            <div style={{ marginTop: 18 }}>
              <div style={receiptRejectedTag}>
                ✗ فیش پرداخت رد شد — {order.paymentReceiptReviewedAt && `تاریخ بررسی: ${new Date(order.paymentReceiptReviewedAt).toLocaleDateString('fa-IR')} — `}
                لطفاً رسید صحیح را دوباره ارسال کنید
              </div>
            </div>
          )}
          {paymentChosen && !order.paymentReceiptStatus && (
            <div style={{ marginTop: 18 }}>
              <div style={receiptSentTag}>
                ✓ رسید پرداخت ارسال شد — در انتظار تایید کارشناس مالی
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
    <Footer homeHref={getSurfaceHome()} />
  </>
)
}

function SummaryRow({ label, value }: { label: string; value: string }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '7px 0', borderBottom: `1px solid ${colors.borderSubtle}`, fontSize: fontSize.base }}>
      <span style={{ color: colors.textSecondary }}>{label}</span>
      <span style={{ fontWeight: 700, fontFamily: 'monospace' }}>{value}</span>
    </div>
  )
}

const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: colors.bgCard,
  padding: `${spacing.xxl}px ${spacing.xl}px`,
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const whiteCard: React.CSSProperties = {
  ...sharedCardStyle,
  padding: 18,
  marginBottom: 14,
}
const fileCard: React.CSSProperties = {
  ...whiteCard,
  display: 'flex',
  alignItems: 'center',
  gap: spacing.lg,
  marginBottom: 0,
  flexWrap: 'wrap',
}
const storageNote: React.CSSProperties = {
  fontSize: fontSize.xs,
  color: colors.textMuted,
  marginTop: 6,
  marginBottom: 18,
}
const highlightCard: React.CSSProperties = {
  background: colors.warningBg,
  borderRadius: radius.lg,
  padding: '18px 22px',
  marginBottom: 14,
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  flexWrap: 'wrap',
  gap: 8,
}
const statusBar: React.CSSProperties = {
  background: colors.warningBg,
  borderRadius: radius.lg,
  padding: '12px 16px',
  fontSize: fontSize.md,
  fontWeight: 700,
  color: colors.warningText,
}
const payCard: React.CSSProperties = {
  ...sharedCardStyle,
  padding: 18,
  marginBottom: 0,
}
const th: React.CSSProperties = { textAlign: 'right', fontSize: fontSize.xs, color: colors.textSecondary, padding: '6px 8px', fontWeight: 700 }
const td: React.CSSProperties = { padding: '9px 8px', fontSize: fontSize.sm }
const disabledPdfBtn: React.CSSProperties = {
  padding: '9px 16px',
  background: colors.neutralBg,
  color: colors.textMuted,
  border: 'none',
  borderRadius: radius.md,
  fontWeight: 700,
  fontSize: fontSize.sm,
  cursor: 'not-allowed',
}
const disabledBtn: React.CSSProperties = {
  ...disabledPdfBtn,
  fontSize: fontSize.base,
}
const receiptSentTag: React.CSSProperties = {
  display: 'inline-block',
  fontSize: fontSize.sm,
  fontWeight: 700,
  color: colors.successText,
  background: colors.successBg,
  padding: '8px 16px',
  borderRadius: radius.md,
}
const receiptApprovedTag: React.CSSProperties = {
  ...receiptSentTag,
}
const invoiceIssuedTag: React.CSSProperties = {
  marginTop: 8,
  fontSize: fontSize.sm,
  fontWeight: 700,
  color: colors.infoText,
  background: colors.infoBg,
  padding: '8px 16px',
  borderRadius: radius.md,
}
const receiptRejectedTag: React.CSSProperties = {
  display: 'inline-block',
  fontSize: fontSize.sm,
  fontWeight: 700,
  color: colors.dangerText,
  background: colors.dangerBg,
  padding: '8px 16px',
  borderRadius: radius.md,
}
