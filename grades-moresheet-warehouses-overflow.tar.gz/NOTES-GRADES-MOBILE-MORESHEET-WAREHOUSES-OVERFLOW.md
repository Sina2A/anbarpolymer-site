# NOTES — موبایل /grades + بازطراحی MoreSheet کاربر + دکمه مهمان انبارها + رفع Overflow

تاریخ: ۲۰۲۶-۰۹-۲۷
Typecheck: `npx tsc --noEmit` → **TSC_EXIT=0** (بدون هیچ diagnostic)

---

## بخش ۱ — ریدیزاین موبایل `/grades` (فقط زیر 899px)

- کامپوننت جدید `src/app/grades/MobileGradeCatalog.tsx` (`'use client'`) — نوار جستجو + پیل‌های خانواده‌ی پلیمری (اسکرول افقی، اسکرول‌بار مخفی) + شمارنده/مرتب‌سازی + گرید دوستونه.
- داده از `src/app/grades/page.tsx` به‌صورت ۸ فیلد اسکالر سریالایزپذیر map می‌شود (`mobileGrades`, خط ۷۹). فرم فیلتر + گرید دسکتاپ داخل `<div className="grades-desktop">` (خط ۱۰۳)؛ `<MobileGradeCatalog>` در خط ۱۸۷.
- توگل: `.grades-mobile{display:none}` سراسری، و در `@media (max-width:899px)` → `.grades-desktop{display:none}` / `.grades-mobile{display:block}` (globals.css:2344-2347).
- خانواده‌ها با `useMemo` از داده‌ی واقعی مشتق می‌شوند (بدون هاردکد PE/PP/PET).
- مرتب‌سازی: `default` = ترتیب سرور دست‌نخورده / `mfi` = صعودی با nullها آخر (`?? Infinity`) / `name` = `localeCompare(code,'fa')`.
- تصویر: عکس واقعی `imageUrl` با `objectFit:cover`، وگرنه placeholder آیکن خاکستری. **هیچ عکس جعلی ساخته نشد.**
- گرید `repeat(2,minmax(0,1fr))` gap 8px + `minWidth:0` روی کارت‌ها و truncate روی همه‌ی متن‌ها → بدون Overflow در 320px.
- **دسکتاپ: صفر تغییر بصری** (مارک‌آپ دسکتاپ فقط داخل wrapper پیچیده شد، بدون تغییر ساختاری).

## بخش ۲ — بازطراحی MoreSheet کاربر لاگین‌شده (ارتفاع ثابت)

- `variant?: 'guest'|'user'` (پیش‌فرض `'guest'`). مهمان: رندر تختِ قبلی عیناً. کاربر: CTA بالا + ردیف چیپ افقی + سه گروه لیبل‌دار + سطر خروج جدا.
- گروه‌بندی با lookup روی href؛ آیتم‌های بدون گروه به گروه آخر (fallback) می‌روند تا هیچ آیتمی گم نشود.
- `src/lib/mobileNavItems.ts`: افزودن `{ label:'گریدها', href:'/grades', icon:Layers }` به `USER_SHEET_ITEMS` → ۱۶ آیتم (۱۵ لینک + ۱ خروج).
- فراخوان‌ها: `PublicHeader.tsx:134` (`variant={isLoggedIn?'user':'guest'}`)، `PanelHeader.tsx:66` (`variant="user"`).

### حساب‌رسی آیتم‌ها (شمارش واقعی) = **۱۶**
| ناحیه | آیتم‌ها | تعداد |
|---|---|---|
| CTA | `/new-listing` | ۱ |
| چیپ‌ها | `/account`, `/my-orders`, `/purchase-requests`, `/my-deals` | ۴ |
| گروه «امور تجاری و اسناد» | `/proformas`, `/rfq`, `/custom-request` | ۳ |
| گروه «شبکه و اطلاع‌رسانی» | `/my-listings`, `/price-alerts`, `/warehouses`, `/grades` | ۴ |
| گروه «پشتیبانی و حساب کاربری» | `/verification`, `/transport`, `/support` | ۳ |
| خروج | `logoutAction` | ۱ |
| **جمع** | | **۱۶** |

همه‌ی hrefها نگاشت شدند؛ `fallbackItems` خالی است (هیچ آیتمی گم نشد).

### ارتفاع شیت — برابری عددی before/after
- `.mobile-sheet{ … max-height:min(72vh,520px); overflow:auto … }` در globals.css:2279 **عیناً دست‌نخورده**.
- کلاس‌های جدید (`.mobile-sheet-cta/-chips/-chip/-group-label/-chevron/-logout-wrap`) صرفاً additive؛ به `.mobile-sheet` و `.mobile-sheet-item` دست زده نشد.
- **before = after = `min(72vh,520px)`**. محتوای بلندتر داخل همان ارتفاع اسکرول می‌خورد (رفتار `overflow:auto` موجود).

## بخش ۳ — دکمه مهمان `/warehouses`

- `:54` → `href={user ? `/warehouses/${w.id}` : '/login'}`.
- `:74-78` → متن شرطی؛ مهمان: «برای مشاهده موجودی این انبار به حساب کاربری خود وارد شوید.» (بدون فلش، `whiteSpace:'normal'`). لاگین‌شده: «مشاهده‌ی موجودی این انبار ←» (بدون تغییر).

## بخش ۴ — رفع Overflow افقی (per-page، نه فیک سراسری کور)

| صفحه | وضعیت اولیه | علت | فیک اعمال‌شده | نتیجه |
|---|---|---|---|---|
| `/reports/[id]` | **Overflow داشت** | گرید `280px minmax(0,1fr)` بدون override موبایل + img بدون max-width | کلاس `.report-article-shell/-card` + `@media≤899` تک‌ستونه و کاهش padding + `.article-content img{max-width:100%;height:auto}` + `overflow-wrap` | **تمیز** |
| `/proformas/[id]` | **Overflow داشت** | جدول ۵ستونه بدون والد اسکرول + h1 monospace نشکن + fileCard بدون wrap | جدول در `<div style={{overflowX:'auto'}}>` + `wordBreak:'break-word'` روی h1 + `flexWrap:'wrap'` روی fileCard | **تمیز** |
| `/price-alerts` | **Overflow داشت** | ردیف active-alert بدون `flexWrap` (:114) + root بدون `admin-page-wrap` | `flexWrap:'wrap'` روی :114 (هم‌تراز :161) + کلاس `admin-page-wrap` روی root | **تمیز** |
| `/rfq-public` (RfqCart) | **Overflow داشت** | `rowStyle`/`cartLineStyle` بدون wrap و بدون `minWidth:0` | `flexWrap:'wrap'` + `minWidth:0` روی هر دو استایل و فرزندان متنی | **تمیز** |
| `/support` | شکننده (پیشگیرانه) | root flex inline بدون `admin-page-wrap` | افزودن کلاس `admin-page-wrap` | **تمیز** |
| گارد سراسری | نبود | نبود گارد `overflow-x` روی html/body | `html,body{overflow-x:clip}` (globals.css:93) — **تور ایمنی، بعد از فیک‌های per-page** | **فعال** |

### صفحات بازبینی‌شده‌ی تمیز (بدون تغییر)
`/dashboard` — تمیز · `/warehouses` — تمیز · `/warehouses/[id]` — تمیز · `/proformas` (لیست) — تمیز · `/custom-request` — تمیز · `/my-listings` — تمیز · `/my-tasks` — تمیز · `/purchase-requests` — تمیز · `/grades` (دسکتاپ) — تمیز · صفحات جدولی market/admin — تمیز (`overflowX:'auto'` موجود).

---

## فایل‌های تغییریافته / جدید (۱۳)

| فایل | بخش | نوع |
|---|---|---|
| `src/app/grades/MobileGradeCatalog.tsx` | ۱ | جدید |
| `src/app/grades/page.tsx` | ۱ | ویرایش |
| `src/lib/mobileNavItems.ts` | ۲ | ویرایش |
| `src/components/mobile/MoreSheet.tsx` | ۲ | ویرایش |
| `src/components/PublicHeader.tsx` | ۲ | ویرایش |
| `src/components/PanelHeader.tsx` | ۲ | ویرایش |
| `src/app/globals.css` | ۱،۲،۴ | ویرایش |
| `src/app/warehouses/page.tsx` | ۳ | ویرایش |
| `src/app/reports/[id]/page.tsx` | ۴ | ویرایش |
| `src/app/proformas/[id]/page.tsx` | ۴ | ویرایش |
| `src/app/price-alerts/page.tsx` | ۴ | ویرایش |
| `src/app/support/page.tsx` | ۴ | ویرایش |
| `src/app/rfq/RfqCart.tsx` | ۴ | ویرایش |

## Verification
- `npx tsc --noEmit` → **TSC_EXIT=0**.
- شمارش آیتم‌های شیت کاربر = **۱۶** (نگاشت کامل href، بدون fallback).
- ارتفاع شیت before=after=`min(72vh,520px)` (بدون تغییر).
- Overflow: ۴ صفحه‌ی واقعی رفع شد + ۱ گارد سراسری + ۱ مورد پیشگیرانه؛ بقیه‌ی صفحات تمیز.

بدون commit/push.
