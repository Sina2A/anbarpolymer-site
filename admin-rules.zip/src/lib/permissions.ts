import prisma from './prisma'

// هر بخش از پنل ادمین که باید دسترسی جداگانه داشته باشه، به‌همراه مسیر صفحه‌ش.
// هر بخشی که هنوز صفحه‌ی واقعی نداره (چون هنوز به Next.js منتقل نشده)، href می‌گیره
// ولی خودِ صفحه بعداً اضافه می‌شه — نقشه‌ی راه فاز ۳.
export const SECTION_KEYS = [
  { key: 'orders', label: 'سفارش‌ها', href: '/admin-orders' },
  { key: 'pricing', label: 'مرکز قیمت‌گذاری (بنچمارک)', href: '/admin-pricing' },
  { key: 'warehouses', label: 'انبارها و موجودی', href: '/admin-warehouses' },
  { key: 'grades', label: 'گریدها و مشخصات فنی', href: '/grades' },
  { key: 'material-listings', label: 'شبکه عرضه مواد اولیه', href: '/admin-material-listings' },
  { key: 'payments', label: 'تایید فیش‌های پرداخت', href: '/admin-payments' },
  { key: 'logistics', label: 'حمل و نقل', href: '/admin-logistics' },
  { key: 'articles', label: 'مقالات و اخبار', href: '/admin-articles' },
  { key: 'documents', label: 'اسناد (TDS/MSDS)', href: '/admin-documents' },
  { key: 'support', label: 'پشتیبانی و تیکت‌ها', href: '/admin-support' },
  { key: 'buyers', label: 'خریداران', href: '/admin-buyers' },
  { key: 'users', label: 'مدیریت کاربران و دسترسی‌ها', href: '/admin-users' },
] as const

export type SectionKey = (typeof SECTION_KEYS)[number]['key']

export type AccessLevel = 'none' | 'view' | 'edit' | 'full'

/**
 * سطح دسترسی یک کاربر به یک بخش رو برمی‌گردونه.
 * نقش «مدیر» هم از همین جدول می‌خونه — هیچ نقشی خودکار full access نمی‌گیره،
 * طبق تصمیمی که گرفته شد (همه‌چیز دستی و صریح).
 */
export async function getSectionAccess(userId: string, section: SectionKey): Promise<AccessLevel> {
  const perm = await prisma.permission.findUnique({
    where: { userId_section: { userId, section } },
  })
  if (!perm || (!perm.canView && !perm.canEdit)) return 'none'
  if (perm.canView && perm.canEdit) return 'full'
  return perm.canView ? 'view' : 'edit'
}

export async function getAllSectionAccess(userId: string): Promise<Record<SectionKey, AccessLevel>> {
  const perms = await prisma.permission.findMany({ where: { userId } })
  const map = {} as Record<SectionKey, AccessLevel>
  for (const sec of SECTION_KEYS) {
    const perm = perms.find((p) => p.section === sec.key)
    if (!perm || (!perm.canView && !perm.canEdit)) map[sec.key] = 'none'
    else if (perm.canView && perm.canEdit) map[sec.key] = 'full'
    else map[sec.key] = perm.canView ? 'view' : 'edit'
  }
  return map
}

// ==================== قانون تک‌مدیر ====================

/**
 * فقط یک نفر می‌تونه هم‌زمان نقش «مدیر» داشته باشه.
 * قبل از هر create/update که می‌خواد role رو admin کنه، این رو صدا بزن.
 * اگه از قبل یه مدیرِ دیگه (با id متفاوت) وجود داشته باشه، پیام خطا برمی‌گردونه.
 */
export async function assertSingleAdmin(candidateUserId: string | null): Promise<string | null> {
  const existingAdmin = await prisma.user.findFirst({ where: { role: 'admin', isActive: true } })
  if (existingAdmin && existingAdmin.id !== candidateUserId) {
    return `همین الان «${existingAdmin.companyName}» نقش مدیر رو داره. طبق قانون سیستم، فقط یک نفر می‌تونه هم‌زمان مدیر باشه — اول باید نقش اون رو عوض کنی.`
  }
  return null
}

// بخش‌هایی که تغییرشون حساسه و باید قبل از اعمال، تاییدیه‌ی صریح بگیره
export const SENSITIVE_ACTIONS = new Set(['change-role', 'edit-user-info', 'deactivate-user', 'grant-admin-permission'])
