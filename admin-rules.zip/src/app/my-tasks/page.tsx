import prisma from '@/lib/prisma'
import { SECTION_KEYS, getAllSectionAccess } from '@/lib/permissions'
import { getCurrentUser } from '@/lib/currentUser'
import { isTerminalStage, getStageDef, RecordType } from '@/lib/workflow'
import AdminNav from '@/components/AdminNav'

export const dynamic = 'force-dynamic'

const RECORD_TYPE_LABELS: Record<RecordType, string> = {
  Order: 'سفارش',
  MaterialListing: 'درخواست فروش مواد اولیه',
  SupportTicket: 'تیکت پشتیبانی',
}

export default async function MyTasksPage({ searchParams }: { searchParams: Promise<{ userId?: string }> }) {
  const { userId: requestedUserId } = await searchParams
  const currentUser = await getCurrentUser(requestedUserId)

  if (!currentUser) {
    return (
      <div style={pageStyle}>
        <h1 style={{ fontSize: 22, fontWeight: 800 }}>کارهای منتظر من</h1>
        <p style={{ color: '#9199a3', marginTop: 12 }}>هنوز هیچ کارشناسی ثبت نشده.</p>
      </div>
    )
  }

  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)

  // مدیر روی همه‌ی بخش‌ها دسترسی edit داره (بدون نیاز به ردیف Permission)؛ کارشناس فقط طبق جدول دسترسی‌هاش
  const mySections = isAdmin
    ? new Set(SECTION_KEYS.map((s) => s.key))
    : new Set(Object.entries(myAccess || {}).filter(([, level]) => level === 'edit' || level === 'full').map(([key]) => key))

  const allEvents = await prisma.statusEvent.findMany({ orderBy: { createdAt: 'asc' } })
  const latestByRecord = new Map<string, (typeof allEvents)[number]>()
  for (const ev of allEvents) {
    latestByRecord.set(`${ev.recordType}:${ev.recordId}`, ev)
  }

  const myTasks = Array.from(latestByRecord.values()).filter((ev) => {
    const recordType = ev.recordType as RecordType
    if (isTerminalStage(recordType, ev.stageKey)) return false
    const stageDef = getStageDef(recordType, ev.stageKey)
    if (!stageDef?.responsibleSection) return false
    return mySections.has(stageDef.responsibleSection)
  })

  const bySection = new Map<string, typeof myTasks>()
  for (const task of myTasks) {
    const recordType = task.recordType as RecordType
    const stageDef = getStageDef(recordType, task.stageKey)
    const section = stageDef?.responsibleSection ?? 'other'
    if (!bySection.has(section)) bySection.set(section, [])
    bySection.get(section)!.push(task)
  }

  return (
    <div style={{ display: 'flex', gap: 24, padding: '32px 24px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', maxWidth: 1100, margin: '0 auto' }}>
      <AdminNav currentUserName={currentUser.companyName} isAdmin={isAdmin} accessMap={myAccess || {}} activeSection="tasks" />

      <div style={{ flex: 1, minWidth: 0 }}>
        <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 8 }}>کارهای منتظر من</h1>
        <p style={{ color: '#6f7680', fontSize: 13.5, marginBottom: 24, lineHeight: 1.9 }}>
          رکوردهایی که الان توی مرحله‌ای هستن که مسئولیتش با یکی از بخش‌های شماست.
        </p>

        {myTasks.length === 0 && (
          <div style={{ padding: 32, textAlign: 'center', color: '#9199a3', border: '1px dashed #d8dde3', borderRadius: 12 }}>
            هیچ کار منتظری نیست 🎉
          </div>
        )}

        {SECTION_KEYS.filter((sec) => bySection.has(sec.key)).map((sec) => (
          <div key={sec.key} style={cardStyle}>
            <h3 style={{ fontSize: 14.5, marginBottom: 14, display: 'flex', alignItems: 'center', gap: 8 }}>
              {sec.label}
              <span style={countTag}>{bySection.get(sec.key)!.length}</span>
            </h3>
            {bySection.get(sec.key)!.map((task) => (
              <div key={task.id} style={taskRow}>
                <div>
                  <span style={typeTag}>{RECORD_TYPE_LABELS[task.recordType as RecordType]}</span>
                  <span style={{ fontSize: 11.5, color: '#9199a3', fontFamily: 'monospace', marginRight: 8 }}>#{task.recordId.slice(0, 8)}</span>
                </div>
                <div style={{ fontSize: 13, fontWeight: 600, marginTop: 6 }}>{task.currentStage}</div>
                <div style={{ fontSize: 11.5, color: '#9199a3', marginTop: 4 }}>از {new Date(task.createdAt).toLocaleDateString('fa-IR')} منتظره</div>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  )
}

const pageStyle: React.CSSProperties = { padding: '32px 24px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl' }
const cardStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 12, padding: 20, marginBottom: 16, background: '#fff', boxShadow: '0 1px 4px rgba(27,30,36,.05)' }
const countTag: React.CSSProperties = { fontSize: 11, fontFamily: 'monospace', background: '#fff4ee', color: '#e65716', borderRadius: 5, padding: '1px 8px' }
const taskRow: React.CSSProperties = { borderTop: '1px solid #eceff3', padding: '12px 4px' }
const typeTag: React.CSSProperties = { fontSize: 10.5, fontWeight: 700, background: '#eef4fd', color: '#1e357b', borderRadius: 5, padding: '2px 9px' }
