'use client'

import { useState } from 'react'
import DealPaymentModal from '@/components/DealPaymentModal'

/**
 * کارت «پرداخت معامله» صفحه‌ی جزئیات my-deals/[id] — هم‌الگوی ProformaBankPay:
 * دکمه‌ی «انتخاب» داره و DealPaymentModal رو به‌صورت controlled باز می‌کنه
 * (open/onClose پاس می‌شه، پس دکمه‌ی trigger داخلیِ مودال رندر نمی‌شه).
 */
export default function DealBankPay({
  dealId,
  kind,
  amountLabel,
  purposeLabel,
  paymentInstructionsText,
  disabled,
  disabledHint,
}: {
  dealId: string
  /** نقشِ پرداخت: خریدار BUYER_GOODS، فروشنده SELLER_FEE — به مودال و از آن‌جا به Server Action پاس می‌شه */
  kind: 'BUYER_GOODS' | 'SELLER_FEE'
  amountLabel: string
  purposeLabel: string
  /** متن راهنمای پرداختِ ثبت‌شده توسط کارشناس حسابداری */
  paymentInstructionsText?: string
  /** وقتی معامله هنوز به مرحله‌ی پرداخت نرسیده */
  disabled?: boolean
  disabledHint?: string
}) {
  const [open, setOpen] = useState(false)

  return (
    <div>
      {disabled ? (
        <button type="button" disabled style={disabledBtn} title={disabledHint}>
          انتخاب
        </button>
      ) : (
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          style={open ? activeBtn : selectBtn}
        >
          {open ? 'بستن ✕' : 'انتخاب'}
        </button>
      )}

      {!disabled && (
        <DealPaymentModal
          dealId={dealId}
          kind={kind}
          amountLabel={amountLabel}
          purposeLabel={purposeLabel}
          paymentInstructionsText={paymentInstructionsText}
          open={open}
          onClose={() => setOpen(false)}
        />
      )}
    </div>
  )
}

const selectBtn: React.CSSProperties = {
  padding: '9px 22px',
  background: '#e65716',
  color: '#fff',
  border: 'none',
  borderRadius: 8,
  fontWeight: 700,
  fontSize: 13,
  cursor: 'pointer',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
}
const activeBtn: React.CSSProperties = {
  ...selectBtn,
  background: '#fff',
  color: '#e65716',
  border: '1.5px solid #e65716',
}
const disabledBtn: React.CSSProperties = {
  ...selectBtn,
  background: '#e8e4db',
  color: '#9199a3',
  cursor: 'not-allowed',
}
