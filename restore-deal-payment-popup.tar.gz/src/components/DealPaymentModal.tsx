'use client'

import { useState, useRef, type ChangeEvent, type CSSProperties } from 'react'
import { useRouter } from 'next/navigation'
import { colors, radius, fontSize } from '@/lib/styles/tokens'
import { uploadDealPaymentReceiptAction } from '@/app/my-deals/actions'

/**
 * پاپ‌آپ پرداختِ معامله‌ی Deal — سه گزینه (نه دو مثل نسخه‌ی Order):
 *   ۱) ثبت فیش از طریق صورتحساب اعلامی — آپلود رسید مستقیم به Server Action
 *      uploadDealPaymentReceiptAction (روی ردیف DealPayment می‌نویسه؛ مسیر مرده‌ی
 *      /api/payment-receipt دیگه صدا زده نمی‌شه).
 *   ۲) درگاه پرداخت آنلاین — غیرفعال («به‌زودی»)
 *   ۳) تماس مستقیم — دکمه‌ی چشمک‌زن با پس‌زمینه‌ی دقیقِ #780606
 * نقشِ پرداخت با prop `kind` تعیین می‌شه: خریدار BUYER_GOODS، فروشنده SELLER_FEE.
 * بالای هر سه گزینه، متن خامِ راهنمای کارشناس (deal.paymentInstructionsText) عیناً نمایش داده می‌شه.
 * کلیک روی «تماس مستقیم» فیلد آپلود فیش رو نمی‌بنده — هر دو می‌تونن هم‌زمان باز بمونن.
 */
type Props = {
  dealId: string
  kind: 'BUYER_GOODS' | 'SELLER_FEE'
  amountLabel: string
  purposeLabel: string
  paymentInstructionsText?: string | null
  triggerLabel?: string
  open?: boolean
  onClose?: () => void
  onSuccess?: () => void
}

export default function DealPaymentModal({
  dealId,
  kind,
  amountLabel,
  purposeLabel,
  paymentInstructionsText,
  triggerLabel = 'پرداخت این معامله',
  open: openProp,
  onClose: onCloseProp,
  onSuccess,
}: Props) {
  const router = useRouter()
  const [openInternal, setOpenInternal] = useState(false)
  const open = openProp !== undefined ? openProp : openInternal

  const [showReceipt, setShowReceipt] = useState(false)
  const [showContact, setShowContact] = useState(false)
  const [file, setFile] = useState<File | null>(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [done, setDone] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  function closeAll() {
    if (loading) return
    if (onCloseProp) onCloseProp()
    else setOpenInternal(false)
  }

  function openModal() {
    setError('')
    setDone(false)
    setFile(null)
    setShowReceipt(false)
    setShowContact(false)
    setOpenInternal(true)
  }

  function handleFileChange(e: ChangeEvent<HTMLInputElement>) {
    setError('')
    const f = e.target.files?.[0]
    if (!f) return
    const allowed = ['image/jpeg', 'image/png', 'application/pdf']
    if (!allowed.includes(f.type)) {
      setError('فرمت مجاز نیست — فقط JPG، PNG یا PDF')
      return
    }
    if (f.size > 5 * 1024 * 1024) {
      setError('حجم فایل بیشتر از ۵ مگابایته')
      return
    }
    setFile(f)
  }

  async function handleSubmit() {
    if (!file) {
      setError('لطفاً اول رسید پرداخت رو انتخاب کن')
      return
    }
    setLoading(true)
    setError('')
    try {
      const fd = new FormData()
      fd.append('dealId', dealId)
      fd.append('kind', kind)
      fd.append('receiptFile', file)
      // Server Action مستقیم (نه مسیر مرده‌ی /api/payment-receipt): در موفقیت بی‌صدا
      // برمی‌گرده و خودش revalidate می‌کنه؛ در خطا throw می‌کنه (مثل «قبلاً ثبت شده»).
      await uploadDealPaymentReceiptAction(fd)
      setDone(true)
      router.refresh()
      onSuccess?.()
    } catch (err) {
      // نکته: Next.js متنِ خطاهای throwشده‌ی Server Action رو در production ماسک می‌کنه
      // (digest عمومی)؛ پس متنِ دقیق فقط در dev دیده می‌شه، در prod فالبکِ عمومی.
      setError(err instanceof Error && err.message ? err.message : 'خطا در ثبت رسید — دوباره امتحان کن')
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      {openProp === undefined && (
        <button type="button" onClick={openModal} style={triggerBtn}>
          {triggerLabel}
        </button>
      )}

      {open && (
        <div style={overlay} onClick={closeAll}>
          <div style={dialog} onClick={(e) => e.stopPropagation()}>
            <style>{'@keyframes ap-contact-blink{0%,100%{opacity:1}50%{opacity:.4}}'}</style>

            <div style={dialogHeader}>
              <span style={{ fontWeight: 800, fontSize: 15, color: '#1b1e24' }}>{purposeLabel}</span>
              <button onClick={closeAll} style={closeBtn} disabled={loading} aria-label="بستن">✕</button>
            </div>

            <div style={amountBox}>
              <div style={{ fontSize: 12, color: '#6f7680', marginBottom: 4 }}>مبلغ قابل پرداخت</div>
              <div style={{ fontSize: 20, fontWeight: 800, color: '#1b1e24' }}>{amountLabel}</div>
            </div>

            {paymentInstructionsText && paymentInstructionsText.trim() && (
              <div style={instructionsBox}>
                <div style={instructionsTitle}>راهنمای پرداخت (اعلامِ کارشناس)</div>
                <div style={instructionsText}>{paymentInstructionsText}</div>
              </div>
            )}

            <p style={{ fontSize: fontSize.base, color: colors.neutralText, margin: '4px 0 12px' }}>روش پرداخت را انتخاب کنید:</p>

            {/* گزینه ۱ — ثبت فیش */}
            <button
              type="button"
              onClick={() => setShowReceipt((v) => !v)}
              style={{ ...methodBtn, ...(showReceipt ? methodBtnActive : null) }}
            >
              <span style={{ fontSize: 18, marginLeft: 10 }}>🧾</span>
              ثبت فیش از طریق صورتحساب اعلامی
              <span style={methodArrow}>{showReceipt ? '▲' : '▾'}</span>
            </button>
            {showReceipt &&
              (done ? (
                <div style={successBox}>
                  <div style={{ fontSize: 22, marginBottom: 6 }}>✅</div>
                  رسید ثبت شد — کارشناس حسابداری بررسی و تایید می‌کنه.
                </div>
              ) : (
                <div style={sectionBox}>
                  <div style={uploadArea} onClick={() => inputRef.current?.click()}>
                    {file ? (
                      <>
                        <div style={{ fontSize: fontSize.base, fontWeight: 700, color: '#146c3a' }}>✓ {file.name}</div>
                        <div style={{ fontSize: fontSize.xs, color: '#6f7680', marginTop: 4 }}>
                          {(file.size / 1024).toFixed(0)} کیلوبایت — کلیک کن تا عوض کنی
                        </div>
                      </>
                    ) : (
                      <>
                        <div style={{ fontSize: 24, marginBottom: 6 }}>📎</div>
                        <div style={{ fontSize: fontSize.base, color: '#6f7680' }}>کلیک کن و فایل رسید رو انتخاب کن</div>
                        <div style={{ fontSize: fontSize.xs, color: colors.textMuted, marginTop: 4 }}>JPG، PNG یا PDF — حداکثر ۵ مگابایت</div>
                      </>
                    )}
                    <input
                      ref={inputRef}
                      type="file"
                      accept="image/jpeg,image/png,application/pdf"
                      style={{ display: 'none' }}
                      onChange={handleFileChange}
                    />
                  </div>
                  {error && <div style={errorStyle}>{error}</div>}
                  <button
                    type="button"
                    onClick={handleSubmit}
                    disabled={loading}
                    style={{ ...submitBtn, opacity: loading ? 0.7 : 1, marginTop: 12 }}
                  >
                    {loading ? 'در حال ارسال…' : 'ثبت رسید'}
                  </button>
                </div>
              ))}
            {/* گزینه ۲ — درگاه آنلاین (غیرفعال) */}
            <button type="button" disabled style={methodBtnDisabled}>
              <span style={{ fontSize: 18, marginLeft: 10 }}>💳</span>
              درگاه پرداخت آنلاین
              <span style={soonTag}>به‌زودی</span>
            </button>

            {/* گزینه ۳ — تماس مستقیم (چشمک‌زن، پس‌زمینه #780606) */}
            <button type="button" onClick={() => setShowContact((v) => !v)} style={contactBtn}>
              <span style={{ fontSize: 18, marginLeft: 10 }}>📞</span>
              تماس مستقیم
              <span style={{ ...methodArrow, color: '#fff' }}>{showContact ? '▲' : '▾'}</span>
            </button>
            {showContact && (
              <div style={contactPanel}>
                برای هماهنگیِ مستقیمِ پرداخت، طبق «راهنمای پرداخت» بالا با کارشناس تماس بگیرید.
                این گزینه فیلد آپلود فیش را نمی‌بندد — می‌توانید هم‌زمان فیش هم ثبت کنید.
              </div>
            )}

            <button type="button" onClick={closeAll} style={cancelBtn} disabled={loading}>
              بستن
            </button>
          </div>
        </div>
      )}
    </>
  )
}
const triggerBtn: CSSProperties = {
  background: colors.orange, color: '#fff', border: 'none', borderRadius: radius.md,
  padding: '9px 18px', fontSize: fontSize.sm, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit',
}
const overlay: CSSProperties = {
  position: 'fixed', inset: 0, background: 'rgba(27,30,36,.5)', display: 'flex',
  alignItems: 'center', justifyContent: 'center', padding: 16, zIndex: 1000,
}
const dialog: CSSProperties = {
  background: colors.bgCard, borderRadius: radius.lg, padding: 20, width: '100%', maxWidth: 440,
  maxHeight: '90vh', overflowY: 'auto', fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl', boxShadow: '0 12px 40px rgba(27,30,36,.25)',
}
const dialogHeader: CSSProperties = {
  display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14,
}
const closeBtn: CSSProperties = {
  background: 'none', border: 'none', fontSize: 18, cursor: 'pointer', color: '#6f7680', lineHeight: 1,
}
const amountBox: CSSProperties = {
  background: '#faf8f4', border: `1px solid ${colors.borderSubtle}`, borderRadius: 10, padding: '12px 14px', marginBottom: 14,
}
const instructionsBox: CSSProperties = {
  background: '#eef4fd', border: '1px solid #c3d9f5', borderRadius: 10, padding: '10px 14px', marginBottom: 14,
}
const instructionsTitle: CSSProperties = {
  fontSize: fontSize.xs, fontWeight: 800, color: colors.navy, marginBottom: 6,
}
const instructionsText: CSSProperties = {
  fontSize: fontSize.base, lineHeight: 1.9, color: '#1b1e24', whiteSpace: 'pre-wrap', wordBreak: 'break-word',
}
const methodBtn: CSSProperties = {
  width: '100%', display: 'flex', alignItems: 'center', gap: 4, textAlign: 'right',
  background: colors.bgCard, border: `1px solid ${colors.borderStrong}`, borderRadius: radius.md, padding: '12px 14px',
  fontSize: fontSize.base, fontWeight: 700, color: '#1b1e24', cursor: 'pointer', marginBottom: 8, fontFamily: 'inherit',
}
const methodBtnActive: CSSProperties = { borderColor: '#f6621b', background: '#fff7f2' }
const methodBtnDisabled: CSSProperties = {
  ...methodBtn, color: colors.textMuted, cursor: 'not-allowed', background: colors.bgPage,
}
const methodArrow: CSSProperties = { marginRight: 'auto', fontSize: fontSize.xs, color: colors.textMuted }
const soonTag: CSSProperties = {
  marginRight: 'auto', fontSize: 10, fontWeight: 700, color: colors.warningText,
  background: '#fef3c7', borderRadius: 20, padding: '2px 10px',
}
const sectionBox: CSSProperties = {
  border: `1px solid ${colors.borderSubtle}`, borderRadius: radius.md, padding: 12, marginBottom: 8, background: '#fcfcfd',
}
const uploadArea: CSSProperties = {
  border: `1.5px dashed ${colors.borderStrong}`, borderRadius: radius.md, padding: '18px 12px',
  textAlign: 'center', cursor: 'pointer', background: colors.bgCard,
}
const errorStyle: CSSProperties = {
  color: colors.dangerText, background: colors.dangerBg, borderRadius: radius.sm, padding: '8px 10px', fontSize: 12, marginTop: 10,
}
const submitBtn: CSSProperties = {
  width: '100%', background: colors.orange, color: '#fff', border: 'none', borderRadius: radius.md,
  padding: '11px 0', fontSize: 13.5, fontWeight: 800, cursor: 'pointer', fontFamily: 'inherit',
}
const contactBtn: CSSProperties = {
  width: '100%', display: 'flex', alignItems: 'center', gap: 4, textAlign: 'right',
  background: '#780606', border: 'none', borderRadius: radius.md, padding: '12px 14px', fontSize: fontSize.base,
  fontWeight: 800, color: '#fff', cursor: 'pointer', marginBottom: 8, fontFamily: 'inherit',
  animation: 'ap-contact-blink 1.1s ease-in-out infinite',
}
const contactPanel: CSSProperties = {
  border: '1px solid #f3c0c0', background: '#fdecec', color: '#780606', borderRadius: radius.md,
  padding: '10px 14px', fontSize: fontSize.sm, lineHeight: 1.9, marginBottom: 8,
}
const cancelBtn: CSSProperties = {
  width: '100%', background: 'none', border: 'none', color: '#6f7680', fontSize: fontSize.sm,
  fontWeight: 700, cursor: 'pointer', padding: '8px 0', marginTop: 4, fontFamily: 'inherit',
}
const successBox: CSSProperties = {
  textAlign: 'center', color: '#146c3a', background: '#eaf3de', border: '1px solid #cfe3b6',
  borderRadius: radius.md, padding: '16px 12px', fontSize: fontSize.base, fontWeight: 700, marginBottom: 8,
}
