'use server'

// اکشن‌های پنل مدیریت آگهی‌های عرضه مواد اولیه:
//   updateListingStatusAction — تغییر وضعیت validityStatus یک آگهی
//
// وضعیت‌های مجاز:
//   active → reserved (توقف)  |  reserved → active (فعالسازی مجدد)
//   هر وضعیتی → cancelled (حذف به دلیل تخلف)

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import { AccessDeniedError } from '@/lib/errorCodes'
import { logAudit } from '@/lib/logger'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'

/** چک دسترسی نوشتن روی بخش «material-listings» */
async function requireListingEditAccess() {
  const user = await getCurrentUser()
  if (user.role === 'admin') return user
  const access = await getAllSectionAccess(user.id)
  if (access['material-listings'] !== 'edit' && access['material-listings'] !== 'full') {
    throw new AccessDeniedError(
      'A-SECTION-MATERIAL-LISTINGS',
      'دسترسی مدیریت آگهی‌ها رو نداری — از مدیر بخواه بهت بده.'
    )
  }
  return user
}

// ================================================================ تغییر وضعیت

const VALID_TRANSITIONS: Record<string, string> = {
  active: 'reserved',
  reserved: 'active',
}

export async function updateListingStatusAction(formData: FormData) {
  const user = await requireListingEditAccess()

  const id = formData.get('id') as string
  const action = formData.get('action') as string

  if (!id || !action) throw new Error('شناسه آگهی و نوع عملیات الزامی است.')

  const listing = await prisma.materialListing.findUnique({ where: { id } })
  if (!listing) throw new Error('آگهی یافت نشد.')

  let newStatus: string | null = null

  if (action === 'toggle') {
    const target = VALID_TRANSITIONS[listing.validityStatus]
    if (!target) {
      throw new Error(
        `وضعیت فعلی «${listing.validityStatus}» قابل تغییر نیست.`
      )
    }
    newStatus = target
  } else if (action === 'cancel') {
    newStatus = 'cancelled'
  } else {
    throw new Error('عملیات نامعتبر.')
  }

  await prisma.materialListing.update({
    where: { id },
    data: {
      validityStatus: newStatus,
      reviewedById: user.id,
      reviewedAt: new Date(),
    },
  })

  const actionLabel =
    action === 'toggle'
      ? `از «${listing.validityStatus}» به «${newStatus}» تغییر یافت`
      : `به «cancelled» تغییر یافت (حذف به دلیل تخلف)`

  await logAudit(
    'material-listings',
    `آگهی ${listing.gradeId} (${listing.id}): ${actionLabel}`,
    user.id,
    { listingId: id, from: listing.validityStatus, to: newStatus }
  )
  revalidatePath('/admin-material-listings')
  redirect('/admin-material-listings?updated=1')
}
