import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import type { AccessLevel } from '@/lib/sections'
import AdminNav, { PartialAccessBanner } from '@/components/AdminNav'
import { updateListingStatusAction } from './actions'

export const dynamic = 'force-dynamic'

export default async function AdminMaterialListingsPage({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>
}) {
  const params = await searchParams
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)

  const level: AccessLevel = isAdmin ? 'full' : ((myAccess?.['material-listings'] as AccessLevel) ?? 'none')
  const hasAccess = level !== 'none'
  const canEdit = level === 'edit' || level === 'full'

  const listings = hasAccess
    ? await prisma.materialListing.findMany({
        include: {
          grade: { select: { code: true, category: true, producer: true } },
          user: { select: { companyName: true } },
        },
        orderBy: { createdAt: 'desc' },
        take: 200,
      })
    : []

  const statusLabels: Record<string, string> = {
    active: 'آزاد',
    reserved: 'رزرو شده',
    needs_reverification: 'نیاز به بازبینی',
    completed: 'تکمیل شده',
    cancelled: 'لغو شده',
  }

  const statusColors: Record<string, { bg: string; fg: string }> = {
    active: { bg: '#d1fae5', fg: '#065f46' },
    reserved: { bg: '#fef3c7', fg: '#92400e' },
    needs_reverification: { bg: '#fde8e8', fg: '#9b1c1c' },
    completed: { bg: '#e0e7ff', fg: '#3730a3' },
    cancelled: { bg: '#f3f4f6', fg: '#4b5563' },
  }

  const feedback =
    typeof params.updated === 'string'
      ? 'وضعیت آگهی تغییر یافت.'
      : null

  return (
    <div
      className="admin-page-wrap"
      style={{
        display: 'flex',
        gap: 24,
        padding: '32px 24px',
        fontFamily: "'Vazirmatn', Tahoma, sans-serif",
        direction: 'rtl',
        maxWidth: 1400,
        margin: '0 auto',
      }}
    >
      <AdminNav
        currentUserName={currentUser.companyName}
        isAdmin={isAdmin}
        accessMap={myAccess || {}}
        activeSection="material-listings"
      />

      <div style={{ flex: 1, minWidth: 0 }}>
        <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>شبکه عرضه مواد اولیه</h1>
        <p style={{ fontSize: 13, color: '#9199a3', marginBottom: 24 }}>
          نمای مدیریتی آگهی‌های MaterialListing فروشندگان — {listings.length} آگهی
        </p>

        <PartialAccessBanner level={level} sectionLabel="شبکه عرضه مواد اولیه" />

        {!hasAccess && <div style={emptyBoxStyle}>به بخش «شبکه عرضه مواد اولیه» دسترسی نداری.</div>}

        {hasAccess && (
          <>
            {feedback && (
              <div style={feedbackStyle}>{feedback}</div>
            )}

            {listings.length === 0 ? (
              <div style={emptyBoxStyle}>هیچ آگهی‌ای ثبت نشده.</div>
            ) : (
              <div style={cardStyle}>
                <div style={tableWrapStyle}>
                  <table style={tableStyle}>
                    <thead>
                      <tr style={{ background: '#f7f8fa' }}>
                        <th style={thStyle}>تاریخ ثبت</th>
                        <th style={thStyle}>فروشنده</th>
                        <th style={thStyle}>کد گرید</th>
                        <th style={thStyle}>دسته</th>
                        <th style={thStyle}>تولیدکننده</th>
                        <th style={thStyle}>مقدار (تن)</th>
                        <th style={thStyle}>قیمت (تومان/کیلو)</th>
                        <th style={thStyle}>استان</th>
                        <th style={thStyle}>وضعیت</th>
                        <th style={thStyle}>مرحله‌ی اداری</th>
                        {canEdit && <th style={thStyle}>عملیات</th>}
                      </tr>
                    </thead>
                    <tbody>
                      {listings.map((listing) => {
                        const statusColor = statusColors[listing.validityStatus] || statusColors.active
                        const canToggle = listing.validityStatus === 'active' || listing.validityStatus === 'reserved'
                        const toggleLabel = listing.validityStatus === 'active' ? 'توقف' : 'فعالسازی'
                        return (
                          <tr key={listing.id} style={{ borderTop: '1px solid #eceff3' }}>
                            <td style={{ ...tdStyle, fontSize: 11.5, color: '#6f7680' }}>
                              {new Date(listing.createdAt).toLocaleDateString('fa-IR')}
                            </td>
                            <td style={tdStyle}>{listing.user.companyName}</td>
                            <td style={{ ...tdStyle, fontFamily: 'monospace', fontWeight: 700 }}>
                              {listing.grade.code}
                            </td>
                            <td style={tdStyle}>{listing.grade.category}</td>
                            <td style={tdStyle}>{listing.grade.producer}</td>
                            <td style={{ ...tdStyle, fontFamily: 'monospace', direction: 'ltr', textAlign: 'right' }}>
                              {listing.quantityTon.toLocaleString('en-US')}
                            </td>
                            <td style={{ ...tdStyle, fontFamily: 'monospace', direction: 'ltr', textAlign: 'right' }}>
                              {listing.askingPriceToman.toLocaleString('fa-IR')}
                            </td>
                            <td style={tdStyle}>{listing.province}</td>
                            <td style={tdStyle}>
                              <span
                                style={{
                                  fontSize: 10.5,
                                  fontWeight: 700,
                                  background: statusColor.bg,
                                  color: statusColor.fg,
                                  borderRadius: 6,
                                  padding: '3px 10px',
                                  display: 'inline-block',
                                }}
                              >
                                {statusLabels[listing.validityStatus] || listing.validityStatus}
                              </span>
                            </td>
                            <td style={{ ...tdStyle, fontSize: 11.5, color: '#6f7680' }}>
                              {listing.bureaucracyStage}
                            </td>
                            {canEdit && (
                              <td style={{ ...tdStyle, whiteSpace: 'nowrap' }}>
                                {canToggle && (
                                  <form action={updateListingStatusAction} style={{ display: 'inline' }}>
                                    <input type="hidden" name="id" value={listing.id} />
                                    <input type="hidden" name="action" value="toggle" />
                                    <button type="submit" style={toggleBtnStyle}>
                                      {toggleLabel}
                                    </button>
                                  </form>
                                )}
                                {listing.validityStatus !== 'cancelled' && listing.validityStatus !== 'completed' && (
                                  <form action={updateListingStatusAction} style={{ display: 'inline', marginLeft: 6 }}>
                                    <input type="hidden" name="id" value={listing.id} />
                                    <input type="hidden" name="action" value="cancel" />
                                    <button type="submit" style={cancelBtnStyle}>
                                      حذف به دلیل تخلف
                                    </button>
                                  </form>
                                )}
                              </td>
                            )}
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}

const emptyBoxStyle: React.CSSProperties = {
  padding: 24,
  textAlign: 'center',
  color: '#9199a3',
  border: '1px dashed #d8dde3',
  borderRadius: 12,
  fontSize: 12.5,
  marginBottom: 20,
}
const cardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 14,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
  marginBottom: 8,
}
const tableWrapStyle: React.CSSProperties = {
  overflowX: 'auto',
}
const tableStyle: React.CSSProperties = {
  width: '100%',
  borderCollapse: 'collapse',
  fontSize: 12.5,
}
const thStyle: React.CSSProperties = {
  textAlign: 'right',
  fontSize: 11,
  color: '#6f7680',
  padding: '8px 10px',
  fontWeight: 700,
}
const tdStyle: React.CSSProperties = { padding: '9px 10px', fontSize: 12.5 }
const feedbackStyle: React.CSSProperties = {
  padding: '10px 16px',
  background: '#e8f5e9',
  color: '#2e7d32',
  borderRadius: 8,
  fontSize: 13,
  marginBottom: 16,
}
const toggleBtnStyle: React.CSSProperties = {
  padding: '5px 12px',
  fontSize: 11,
  fontWeight: 700,
  background: '#1a73e8',
  color: '#fff',
  border: 'none',
  borderRadius: 5,
  cursor: 'pointer',
}
const cancelBtnStyle: React.CSSProperties = {
  padding: '5px 12px',
  fontSize: 11,
  fontWeight: 700,
  background: '#d32f2f',
  color: '#fff',
  border: 'none',
  borderRadius: 5,
  cursor: 'pointer',
}
