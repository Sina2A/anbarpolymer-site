import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import type { AccessLevel } from '@/lib/sections'
import AdminNav, { PartialAccessBanner } from '@/components/AdminNav'
import { toggleBuyerStatusAction, updateBuyerNoteAction } from './actions'

export const dynamic = 'force-dynamic'

export default async function AdminBuyersPage({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>
}) {
  const params = await searchParams
  const currentUser = await getCurrentUser()
  const isAdmin = currentUser.role === 'admin'
  const myAccess = isAdmin ? null : await getAllSectionAccess(currentUser.id)

  const level: AccessLevel = isAdmin ? 'full' : ((myAccess?.buyers as AccessLevel) ?? 'none')
  const hasAccess = level !== 'none'
  const canEdit = level === 'edit' || level === 'full'

  const buyers = hasAccess
    ? await prisma.user.findMany({
        where: { role: 'buyer' },
        include: {
          company: {
            select: {
              id: true,
              nationalId: true,
              registrationNumber: true,
              internalNote: true,
              kyc: { select: { level: true, verifiedAt: true } },
            },
          },
          _count: {
            select: {
              orders: true,
              purchaseRequests: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      })
    : []

  const feedback =
    typeof params.updated === 'string'
      ? 'وضعیت خریدار تغییر یافت.'
      : typeof params.note === 'string'
        ? 'یادداشت ذخیره شد.'
        : null

  return (
    <div
      className="admin-page-wrap"
      style={{
        display: 'flex',
        gap: 24,
        padding: '32px 24px',
        fontFamily: "'Vazirmatn', Tahoma, sans-serif",
        direction: 'rtl',
        maxWidth: 1300,
        margin: '0 auto',
      }}
    >
      <AdminNav
        currentUserName={currentUser.companyName}
        isAdmin={isAdmin}
        accessMap={myAccess || {}}
        activeSection="buyers"
      />

      <div style={{ flex: 1, minWidth: 0 }}>
        <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>مدیریت خریداران</h1>
        <p style={{ fontSize: 13, color: '#9199a3', marginBottom: 24 }}>
          نمای مدیریتی کاربران با نقش خریدار — {buyers.length} خریدار
        </p>

        <PartialAccessBanner level={level} sectionLabel="خریداران" />

        {!hasAccess && <div style={emptyBoxStyle}>به بخش «خریداران» دسترسی نداری.</div>}

        {hasAccess && (
          <>
            {feedback && (
              <div style={feedbackStyle}>{feedback}</div>
            )}

            {buyers.length === 0 ? (
              <div style={emptyBoxStyle}>هیچ خریداری ثبت نشده.</div>
            ) : (
              <div style={cardStyle}>
                <div style={tableWrapStyle}>
                  <table style={tableStyle}>
                    <thead>
                      <tr style={{ background: '#f7f8fa' }}>
                        <th style={thStyle}>نام شرکت</th>
                        <th style={thStyle}>شناسه ملی</th>
                        <th style={thStyle}>شماره ثبت</th>
                        <th style={thStyle}>وضعیت</th>
                        <th style={thStyle}>وضعیت KYC</th>
                        <th style={thStyle}>تاریخ تایید</th>
                        <th style={thStyle}>سفارش‌ها</th>
                        <th style={thStyle}>درخواست‌ها</th>
                        <th style={thStyle}>تاریخ عضویت</th>
                        {canEdit && <th style={thStyle}>عملیات</th>}
                      </tr>
                    </thead>
                    <tbody>
                      {buyers.map((buyer) => {
                        const kycLevel = buyer.company?.kyc?.level ?? 0
                        const kycVerifiedAt = buyer.company?.kyc?.verifiedAt

                        const kycBadge =
                          kycLevel === 0 ? (
                            <span style={kycBadgeStyle('#f3f4f6', '#6b7280')}>احراز نشده</span>
                          ) : kycLevel === 1 ? (
                            <span style={kycBadgeStyle('#fef3c7', '#92400e')}>سطح ۱</span>
                          ) : (
                            <span style={kycBadgeStyle('#d1fae5', '#065f46')}>سطح ۲</span>
                          )

                        const statusBadge = buyer.isActive ? (
                          <span style={statusBadgeStyle('#d1fae5', '#065f46')}>فعال</span>
                        ) : (
                          <span style={statusBadgeStyle('#fee2e2', '#991b1b')}>غیرفعال</span>
                        )

                        return (
                          <tr key={buyer.id} style={{ borderTop: '1px solid #eceff3' }}>
                            <td style={{ ...tdStyle, fontWeight: 700 }}>{buyer.companyName}</td>
                            <td style={{ ...tdStyle, fontFamily: 'monospace', direction: 'ltr', textAlign: 'right' }}>
                              {buyer.company?.nationalId || '—'}
                            </td>
                            <td style={{ ...tdStyle, fontFamily: 'monospace', direction: 'ltr', textAlign: 'right' }}>
                              {buyer.company?.registrationNumber || '—'}
                            </td>
                            <td style={tdStyle}>{statusBadge}</td>
                            <td style={tdStyle}>{kycBadge}</td>
                            <td style={{ ...tdStyle, fontSize: 11.5, color: '#6f7680' }}>
                              {kycVerifiedAt ? new Date(kycVerifiedAt).toLocaleDateString('fa-IR') : '—'}
                            </td>
                            <td style={{ ...tdStyle, fontFamily: 'monospace', textAlign: 'center' }}>
                              {buyer._count.orders}
                            </td>
                            <td style={{ ...tdStyle, fontFamily: 'monospace', textAlign: 'center' }}>
                              {buyer._count.purchaseRequests}
                            </td>
                            <td style={{ ...tdStyle, fontSize: 11.5, color: '#6f7680' }}>
                              {new Date(buyer.createdAt).toLocaleDateString('fa-IR')}
                            </td>
                            {canEdit && (
                              <td style={{ ...tdStyle, whiteSpace: 'nowrap' }}>
                                <form action={toggleBuyerStatusAction} style={{ display: 'inline' }}>
                                  <input type="hidden" name="id" value={buyer.id} />
                                  <button
                                    type="submit"
                                    style={{
                                      padding: '5px 12px',
                                      fontSize: 11,
                                      fontWeight: 700,
                                      background: buyer.isActive ? '#d32f2f' : '#1a73e8',
                                      color: '#fff',
                                      border: 'none',
                                      borderRadius: 5,
                                      cursor: 'pointer',
                                    }}
                                  >
                                    {buyer.isActive ? 'غیرفعال' : 'فعال‌سازی'}
                                  </button>
                                </form>
                                {buyer.company && (
                                  <form action={updateBuyerNoteAction} style={{ display: 'inline-flex', gap: 4, marginLeft: 8, alignItems: 'center' }}>
                                    <input type="hidden" name="id" value={buyer.id} />
                                    <input
                                      type="text"
                                      name="note"
                                      defaultValue={buyer.company.internalNote || ''}
                                      placeholder="یادداشت..."
                                      style={{
                                        width: 160,
                                        padding: '4px 8px',
                                        fontSize: 11,
                                        border: '1px solid #d8dde3',
                                        borderRadius: 5,
                                        direction: 'rtl',
                                      }}
                                    />
                                    <button
                                      type="submit"
                                      style={{
                                        padding: '5px 10px',
                                        fontSize: 11,
                                        fontWeight: 700,
                                        background: '#374151',
                                        color: '#fff',
                                        border: 'none',
                                        borderRadius: 5,
                                        cursor: 'pointer',
                                      }}
                                    >
                                      ذخیره
                                    </button>
                                  </form>
                                )}
                              </td>
                            )}
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}

const kycBadgeStyle = (bg: string, fg: string): React.CSSProperties => ({
  fontSize: 10.5,
  fontWeight: 700,
  background: bg,
  color: fg,
  borderRadius: 6,
  padding: '3px 10px',
  display: 'inline-block',
})

const statusBadgeStyle = (bg: string, fg: string): React.CSSProperties => ({
  fontSize: 10.5,
  fontWeight: 700,
  background: bg,
  color: fg,
  borderRadius: 6,
  padding: '3px 10px',
  display: 'inline-block',
})

const emptyBoxStyle: React.CSSProperties = {
  padding: 24,
  textAlign: 'center',
  color: '#9199a3',
  border: '1px dashed #d8dde3',
  borderRadius: 12,
  fontSize: 12.5,
  marginBottom: 20,
}
const cardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 14,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
  marginBottom: 8,
}
const tableWrapStyle: React.CSSProperties = {
  overflowX: 'auto',
}
const tableStyle: React.CSSProperties = {
  width: '100%',
  borderCollapse: 'collapse',
  fontSize: 12.5,
}
const thStyle: React.CSSProperties = {
  textAlign: 'right',
  fontSize: 11,
  color: '#6f7680',
  padding: '8px 10px',
  fontWeight: 700,
}
const tdStyle: React.CSSProperties = { padding: '9px 10px', fontSize: 12.5 }
const feedbackStyle: React.CSSProperties = {
  padding: '10px 16px',
  background: '#e8f5e9',
  color: '#2e7d32',
  borderRadius: 8,
  fontSize: 13,
  marginBottom: 16,
}
