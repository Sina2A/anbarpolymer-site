'use server'

// اکشن‌های پنل مدیریت خریداران:
//   toggleBuyerStatusAction — فعال/غیرفعال‌کردن حساب خریدار (User.isActive)
//   updateBuyerNoteAction — ذخیره‌ی یادداشت داخلی ادمین روی Company.internalNote

import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getAllSectionAccess } from '@/lib/permissions'
import { AccessDeniedError } from '@/lib/errorCodes'
import { logAudit } from '@/lib/logger'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'

/** چک دسترسی نوشتن روی بخش «buyers» */
async function requireBuyerEditAccess() {
  const user = await getCurrentUser()
  if (user.role === 'admin') return user
  const access = await getAllSectionAccess(user.id)
  if (access.buyers !== 'edit' && access.buyers !== 'full') {
    throw new AccessDeniedError(
      'A-SECTION-BUYERS',
      'دسترسی مدیریت خریداران رو نداری — از مدیر بخواه بهت بده.'
    )
  }
  return user
}

// ================================================================ فعال/غیرفعال

export async function toggleBuyerStatusAction(formData: FormData) {
  const user = await requireBuyerEditAccess()

  const id = formData.get('id') as string
  if (!id) throw new Error('شناسه کاربر نامعتبر.')

  const buyer = await prisma.user.findUnique({ where: { id } })
  if (!buyer) throw new Error('کاربر یافت نشد.')

  const newStatus = !buyer.isActive

  await prisma.user.update({
    where: { id },
    data: { isActive: newStatus },
  })

  await logAudit(
    'buyers',
    `حساب «${buyer.companyName}» ${newStatus ? 'فعال شد' : 'غیرفعال شد'}`,
    user.id,
    { userId: id, isActive: newStatus }
  )
  revalidatePath('/admin-buyers')
  redirect('/admin-buyers?updated=1')
}

// ================================================================ یادداشت داخلی

export async function updateBuyerNoteAction(formData: FormData) {
  const user = await requireBuyerEditAccess()

  const id = formData.get('id') as string
  const note = (formData.get('note') as string)?.trim() || null

  if (!id) throw new Error('شناسه کاربر نامعتبر.')

  const buyer = await prisma.user.findUnique({
    where: { id },
    include: { company: { select: { id: true } } },
  })
  if (!buyer) throw new Error('کاربر یافت نشد.')

  if (buyer.company) {
    await prisma.company.update({
      where: { id: buyer.company.id },
      data: { internalNote: note },
    })
  } else {
    // خریدار بدون شرکت — یادداشت روی خودِ User ذخیره نمی‌شه (فیلد نداره).
    // فقط لاگ می‌زنیم تا ادمین بدونه چرا ذخیره نشد.
    await logAudit(
      'buyers',
      `یادداشت برای «${buyer.companyName}» ذخیره نشد — شرکت ثبت نشده`,
      user.id,
      { userId: id }
    )
    throw new Error('این خریدار هنوز شرکت ثبت نکرده — یادداشت قابل ذخیره نیست.')
  }

  await logAudit(
    'buyers',
    `یادداشت داخلی «${buyer.companyName}» ${note ? 'ذخیره شد' : 'پاک شد'}`,
    user.id,
    { userId: id, noteLength: note?.length ?? 0 }
  )
  revalidatePath('/admin-buyers')
  redirect('/admin-buyers?note=1')
}