import CurrencyTicker from '@/components/CurrencyTicker'
import { submitContactAction } from './actions'

export const dynamic = 'force-dynamic'

type SearchParams = Promise<Record<string, string | string[] | undefined>>

function one(v: string | string[] | undefined): string | undefined {
  if (Array.isArray(v)) return v[0]
  return v
}

export default async function ContactPage({ searchParams }: { searchParams: SearchParams }) {
  const sp = await searchParams
  const justSent = one(sp.sent) === '1'

  return (
    <div style={pageStyle}>
      <CurrencyTicker />
      {/* هدر سایت */}
      <header style={headerStyle}>
        <div style={headerInner}>
          <a href="/" style={brandStyle}>
            <span style={brandIcon}>🏭</span>
            انبار پلیمر
          </a>
          <nav style={navStyle}>
            <a href="/market" style={navLinkStyle}>بازار مواد اولیه</a>
            <a href="/warehouses" style={navLinkStyle}>انبارها</a>
            <a href="/grades" style={navLinkStyle}>کاتالوگ گریدها</a>
            <a href="/login" style={navLoginStyle}>ورود</a>
          </nav>
        </div>
      </header>

      <main style={mainStyle}>
        <div style={heroStyle}>
          <h1 style={heroTitle}>تماس با ما</h1>
          <p style={heroSub}>
            سوالی درباره‌ی مواد اولیه، قیمت یا همکاری داری؟ فرم زیر رو پر کن — همکاران ما پیامت رو می‌بینن و از راهی که گذاشتی جواب می‌دن.
          </p>
        </div>

        {justSent && (
          <div style={successBanner}>
            ✅ پیامت رسید. ممنون! در صورت نیاز از راهی که گذاشتی باهات تماس می‌گیریم.
          </div>
        )}

        <section style={formCardStyle}>
          <form action={submitContactAction}>
            <div style={{ marginBottom: 14 }}>
              <div style={labelStyle}>نام و نام خانوادگی</div>
              <input name="name" required maxLength={80} placeholder="مثلاً: علی رضایی"
                style={inputStyle} />
            </div>
            <div style={{ marginBottom: 14 }}>
              <div style={labelStyle}>راه تماس <span style={hintInline}>(ایمیل یا شماره موبایل)</span></div>
              <input name="contact" required maxLength={120} placeholder="example@mail.com یا 09121234567"
                style={{ ...inputStyle, direction: 'ltr', textAlign: 'left' }} />
            </div>
            <div style={{ marginBottom: 16 }}>
              <div style={labelStyle}>متن پیام</div>
              <textarea name="body" rows={6} required maxLength={2000} placeholder="سوال یا پیامت رو اینجا بنویس…"
                style={{ ...inputStyle, resize: 'vertical' }} />
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
              <span style={hintStyle}>نیازی به ثبت‌نام نیست — پیامت مستقیم به تیم ما می‌رسه.</span>
              <button type="submit" style={submitBtnStyle}>ارسال پیام</button>
            </div>
          </form>
        </section>
      </main>

      {/* فوتر */}
      <footer style={footerStyle}>
        <div style={footerInner}>
          <span>© {new Date().getFullYear()} انبار پلیمر — تمامی حقوق محفوظ است.</span>
          <span style={footerLinks}>
            <a href="/" style={footerLink}>خانه</a>
            <span style={dot}>•</span>
            <a href="/market" style={footerLink}>بازار</a>
            <span style={dot}>•</span>
            <a href="/login" style={footerLink}>ورود</a>
          </span>
        </div>
      </footer>
    </div>
  )
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: '#faf8f4',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
  display: 'flex',
  flexDirection: 'column',
}
const headerStyle: React.CSSProperties = {
  background: '#fff',
  borderBottom: '1px solid #e5e7eb',
  padding: '14px 24px',
}
const headerInner: React.CSSProperties = {
  maxWidth: 1100,
  margin: '0 auto',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  gap: 16,
  flexWrap: 'wrap',
}
const brandStyle: React.CSSProperties = {
  fontSize: 16,
  fontWeight: 800,
  color: '#1e357b',
  textDecoration: 'none',
  display: 'flex',
  alignItems: 'center',
  gap: 8,
}
const brandIcon: React.CSSProperties = {
  fontSize: 22,
}
const navStyle: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 18,
  flexWrap: 'wrap',
}
const navLinkStyle: React.CSSProperties = {
  fontSize: 13,
  color: '#4f5560',
  textDecoration: 'none',
  fontWeight: 600,
}
const navLoginStyle: React.CSSProperties = {
  fontSize: 13,
  color: '#fff',
  background: '#1e357b',
  borderRadius: 8,
  padding: '7px 16px',
  textDecoration: 'none',
  fontWeight: 700,
}
const mainStyle: React.CSSProperties = {
  maxWidth: 1100,
  margin: '0 auto',
  padding: '32px 24px',
  flex: 1,
  width: '100%',
  boxSizing: 'border-box',
}
const heroStyle: React.CSSProperties = {
  marginBottom: 28,
}
const heroTitle: React.CSSProperties = {
  fontSize: 24,
  fontWeight: 800,
  color: '#1b1e24',
  marginBottom: 8,
}
const heroSub: React.CSSProperties = {
  fontSize: 13.5,
  color: '#6f7680',
  lineHeight: 1.7,
}
const successBanner: React.CSSProperties = {
  background: '#eaf3de',
  color: '#146c3a',
  borderRadius: 10,
  padding: '12px 16px',
  fontSize: 13,
  fontWeight: 600,
  marginBottom: 18,
  border: '1px solid #cfe3bd',
}
const formCardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 24,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
  maxWidth: 640,
}
const labelStyle: React.CSSProperties = {
  fontSize: 12.5,
  fontWeight: 700,
  color: '#4f5560',
  marginBottom: 5,
}
const hintInline: React.CSSProperties = {
  fontWeight: 400,
  color: '#9199a3',
  fontSize: 11,
}
const inputStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 8,
  padding: '10px 12px',
  fontSize: 13,
  fontFamily: 'inherit',
  width: '100%',
  boxSizing: 'border-box',
}
const hintStyle: React.CSSProperties = {
  fontSize: 11.5,
  color: '#9199a3',
}
const submitBtnStyle: React.CSSProperties = {
  background: '#1e357b',
  color: '#fff',
  border: 'none',
  borderRadius: 8,
  padding: '10px 28px',
  fontSize: 13.5,
  fontWeight: 700,
  cursor: 'pointer',
  fontFamily: 'inherit',
}
const footerStyle: React.CSSProperties = {
  background: '#fff',
  borderTop: '1px solid #e5e7eb',
  padding: '18px 24px',
  marginTop: 40,
}
const footerInner: React.CSSProperties = {
  maxWidth: 1100,
  margin: '0 auto',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  gap: 12,
  flexWrap: 'wrap',
  fontSize: 12,
  color: '#6f7680',
}
const footerLinks: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 8,
}
const footerLink: React.CSSProperties = {
  color: '#4f5560',
  textDecoration: 'none',
  fontWeight: 600,
}
const dot: React.CSSProperties = {
  color: '#d8dde3',
}
