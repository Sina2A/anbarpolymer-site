import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  timeout: 30_000,
  retries: 0,
  workers: 1,
  fullyParallel: false,
  reporter: [['list'], ['html', { open: 'never' }]],
  use: {
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
  },
  projects: [
    {
      name: 'setup-buyer',
      testMatch: /.*auth\/buyer\.setup\.ts/,
    },
    {
      name: 'setup-admin',
      testMatch: /.*auth\/admin\.setup\.ts/,
    },
    {
      name: 'buyer',
      dependencies: ['setup-buyer'],
      use: {
        ...devices['Desktop Chrome'],
        baseURL: 'http://185.164.73.143:3000',
        storageState: '.auth/buyer.json',
      },
      testIgnore: /.*auth\/.*/,
    },
    {
      name: 'admin',
      dependencies: ['setup-admin'],
      use: {
        ...devices['Desktop Chrome'],
        baseURL: 'http://185.164.73.143:3001',
        storageState: '.auth/admin.json',
      },
      testIgnore: /.*auth\/.*/,
    },
  ],
});
