import { test, expect } from '@playwright/test';
import path from 'path';
import fs from 'fs';
import os from 'os';

// ── helpers ──────────────────────────────────────────────────────────────

const stamp = (prefix: string) => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;

// Minimal 1×1 PNG (transparent) — valid image/jpeg|png|webp for weighbridgeTicket
const ONE_PX_PNG = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+ip1sAAAAASUVORK5CYII=',
  'base64',
);

function todayStr(): string {
  const t = new Date();
  return `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(t.getDate()).padStart(2, '0')}`;
}

async function ensureTicketFile(): Promise<string> {
  const dir = path.join(os.tmpdir(), 'anbar-e2e');
  fs.mkdirSync(dir, { recursive: true });
  const p = path.join(dir, 'ticket.png');
  fs.writeFileSync(p, ONE_PX_PNG);
  return p;
}

// Pick first real grade option (skip placeholder "")
async function selectFirstGrade(page: import('@playwright/test').Page) {
  const sel = page.locator('select[name="gradeId"]');
  await expect(sel).toBeVisible({ timeout: 10_000 });
  const opts = sel.locator('option[value]:not([value=""])');
  const n = await opts.count();
  expect(n, 'at least one active grade must exist').toBeGreaterThan(0);
  const firstVal = await opts.first().getAttribute('value');
  const firstText = (await opts.first().textContent())?.trim() ?? '';
  await sel.selectOption(firstVal!);
  return { gradeValue: firstVal!, gradeText: firstText };
}

// ── Scenario 1: seller creates → admin keeps active → visible in /market ──

test('market flow — scenario 1: seller creates listing → admin keeps active → visible in /market', async ({
  browser,
}) => {
  const cityStamp = stamp('e2e-listing');
  const ticketPath = await ensureTicketFile();

  // ── Seller: create listing ──
  const sellerCtx = await browser.newContext({
    baseURL: 'http://185.164.73.143:3000',
    storageState: '.auth/seller.json',
  });
  const seller = await sellerCtx.newPage();
  await seller.goto('/new-listing');
  await expect(seller).not.toHaveURL(/\/login/);

  // If seller lacks KYC level 2, the form is not shown — fail fast with clear message
  const kycBlock = seller.locator('text=احراز تولیدکننده لازمه');
  if (await kycBlock.count() > 0) {
    throw new Error(
      'testseller lacks KYC level 2 (producer verification) — /new-listing shows KYC gate. Ask admin to approve testseller KYC before running market tests.',
    );
  }
  const restrictedBlock = seller.locator('text=حسابت موقتاً محدوده');
  if (await restrictedBlock.count() > 0) {
    throw new Error('testseller is restricted (deadline violation) — cannot create listing.');
  }

  await expect(seller.locator('form[action="/api/material-listings"]')).toBeVisible({ timeout: 10_000 });

  const { gradeText } = await selectFirstGrade(seller);

  // Fill required fields — city carries the unique stamp so we can locate the row everywhere
  await seller.fill('input[name="quantityTon"]', '1');
  await seller.fill('input[name="province"]', 'تهران');
  await seller.fill('input[name="city"]', cityStamp);
  await seller.fill('input[name="packagingType"]', 'کیسه 25 کیلویی');
  await seller.fill('input[name="packagingQuality"]', 'نو');
  await seller.fill('input[name="materialQuality"]', 'virgin');
  await seller.fill('input[name="askingPriceToman"]', '95000');
  await seller.fill('input[name="weighbridgeNetWeightKg"]', '1000');
  // weighbridgeDate defaults to today; ensure it
  const dateInput = seller.locator('input[name="weighbridgeDate"]');
  await dateInput.fill(todayStr());
  await seller.setInputFiles('input[name="weighbridgeTicket"]', ticketPath);

  // Submit — Route Handler returns 303 → /my-listings on success, or 303 → /new-listing?error=... on failure
  await Promise.all([
    seller.waitForURL(/\/my-listings(\?|$)/, { timeout: 20_000 }),
    seller.click('button:has-text("ثبت آگهی")'),
  ]);
  await expect(seller).not.toHaveURL(/\/login/);
  // If redirected back to /new-listing with ?error=, surface it
  if (seller.url().includes('/new-listing') && seller.url().includes('error=')) {
    const errBanner = seller.locator('text=برای ثبت آگهی باید').or(seller.locator('[style*="dangerBg"]')).first();
    const errText = await seller.content();
    throw new Error(`listing creation failed — redirected to ${seller.url()}\n${errText.slice(0, 3000)}`);
  }
  expect(seller.url(), 'should redirect to /my-listings after successful listing creation').toContain('/my-listings');

  // Verify in /my-listings — card contains our unique city + grade code
  await seller.goto('/my-listings');
  await expect(seller).not.toHaveURL(/\/login/);
  const myCard = seller.locator('div').filter({ hasText: cityStamp }).first();
  await expect(myCard, `seller my-listings card with city ${cityStamp}`).toBeVisible({ timeout: 15_000 });
  await expect(myCard.locator('text=فعال').first()).toBeVisible({ timeout: 10_000 });

  // ── Admin: verify listing appears in /admin-material-listings ──
  const adminCtx = await browser.newContext({
    baseURL: 'http://185.164.73.143:3001',
    storageState: '.auth/admin.json',
  });
  const admin = await adminCtx.newPage();
  await admin.goto('/admin-material-listings');
  await expect(admin).not.toHaveURL(/\/login/);
  const adminRow = admin.locator('tr').filter({ hasText: cityStamp }).first();
  await expect(adminRow, `admin row with city ${cityStamp}`).toBeVisible({ timeout: 15_000 });
  // Listing is created as active — admin keeps it active (no toggle needed).
  // Verify badge shows "آزاد" (active)
  await expect(adminRow.locator('text=آزاد').first()).toBeVisible({ timeout: 10_000 });

  // ── Buyer (or guest) sees it in /market ──
  const buyerCtx = await browser.newContext({
    baseURL: 'http://185.164.73.143:3000',
    storageState: '.auth/buyer.json',
  });
  const buyer = await buyerCtx.newPage();
  await buyer.goto('/market');
  await expect(buyer).not.toHaveURL(/\/login/);
  // Market table row contains city + grade code; search by unique city
  const marketRow = buyer.locator('tr').filter({ hasText: cityStamp }).first();
  await expect(marketRow, `market row with city ${cityStamp} should be visible`).toBeVisible({ timeout: 15_000 });
  // Also verify grade code appears in that row
  const gradeCodeShort = gradeText.split('—')[0].trim().split(' ')[0];
  if (gradeCodeShort) {
    await expect(marketRow.locator(`text=${gradeCodeShort}`).first()).toBeVisible({ timeout: 10_000 });
  }

  await sellerCtx.close();
  await adminCtx.close();
  await buyerCtx.close();
});

// ── Scenario 2: buyer purchase-request → seller responds with listing ──

test('market flow — scenario 2: buyer purchase-request → seller listing in response → buyer sees it', async ({
  browser,
}) => {
  const prStamp = stamp('e2e-pr');
  const cityStamp = stamp('e2e-listing-pr');
  const ticketPath = await ensureTicketFile();

  // ── Buyer: create purchase request ──
  const buyerCtx = await browser.newContext({
    baseURL: 'http://185.164.73.143:3000',
    storageState: '.auth/buyer.json',
  });
  const buyer = await buyerCtx.newPage();
  await buyer.goto('/purchase-requests?new=1');
  await expect(buyer).not.toHaveURL(/\/login/);
  await expect(buyer.locator('form[action]').first()).toBeVisible({ timeout: 10_000 });

  const gradeSel = buyer.locator('select[name="gradeId"]');
  await expect(gradeSel).toBeVisible({ timeout: 10_000 });
  const opts = gradeSel.locator('option[value]:not([value=""])');
  const n = await opts.count();
  expect(n, 'at least one grade for purchase request').toBeGreaterThan(0);
  const gradeVal = await opts.first().getAttribute('value');
  await gradeSel.selectOption(gradeVal!);

  await buyer.fill('input[name="quantityTon"]', '2');
  await buyer.fill('input[name="maxPriceToman"]', '90000');
  await buyer.fill('input[name="province"]', 'اصفهان');
  await buyer.fill('textarea[name="description"]', prStamp + ' — درخواست تستی بازار دوطرفه، پاک شود.');

  await Promise.all([
    buyer.waitForURL(/\/purchase-requests(\?|$)/, { timeout: 20_000 }),
    buyer.click('button:has-text("ثبت درخواست")'),
  ]);
  await expect(buyer).not.toHaveURL(/\/login/);
  expect(buyer.url()).toContain('/purchase-requests');

  // Find the newly created request card by our unique description
  await buyer.goto('/purchase-requests');
  await expect(buyer).not.toHaveURL(/\/login/);
  const reqCard = buyer.locator('div').filter({ hasText: prStamp.slice(0, 20) }).first();
  await expect(reqCard, `buyer purchase-request card with stamp ${prStamp.slice(0, 20)}`).toBeVisible({
    timeout: 15_000,
  });
  // Extract request id from hidden input or card — the card shows #<8chars>, but we need full id for seller
  // Instead, parse from the "ثبت آگهی در پاسخ" link in /market?view=demand, or directly from buyer's card hidden input
  const requestIdInput = reqCard.locator('input[name="requestId"]');
  let requestId: string | null = null;
  if ((await requestIdInput.count()) > 0) {
    requestId = await requestIdInput.first().getAttribute('value');
  }
  // Fallback: find request id via /market?view=demand where demandRequests are listed with #<id>
  if (!requestId) {
    // The purchase-requests page itself stores id in the card's hidden form; if not found, scrape from page source
    // The card shows #{id.slice(0,8)} — we can find the link that contains request id by going to market demand tab
    const marketTmpCtx = await browser.newContext({
      baseURL: 'http://185.164.73.143:3000',
      storageState: '.auth/buyer.json',
    });
    const marketTmp = await marketTmpCtx.newPage();
    await marketTmp.goto('/market?view=demand');
    await expect(marketTmp).not.toHaveURL(/\/login/);
    const demandCard = marketTmp.locator('div').filter({ hasText: prStamp.slice(0, 20) }).first();
    await expect(demandCard, 'demand card in /market?view=demand').toBeVisible({ timeout: 15_000 });
    const respondLink = demandCard.locator('a[href*="/new-listing?request="]').first();
    if ((await respondLink.count()) > 0) {
      const href = await respondLink.getAttribute('href');
      const m = href?.match(/request=([^&]+)/);
      if (m) requestId = m[1];
    }
    await marketTmpCtx.close();
  }
  expect(requestId, 'purchase request id must be resolvable').toBeTruthy();

  // ── Seller: create listing in response to that purchase request ──
  const sellerCtx = await browser.newContext({
    baseURL: 'http://185.164.73.143:3000',
    storageState: '.auth/seller.json',
  });
  const seller = await sellerCtx.newPage();
  await seller.goto(`/new-listing?request=${requestId}`);
  await expect(seller).not.toHaveURL(/\/login/);

  const kycBlock = seller.locator('text=احراز تولیدکننده لازمه');
  if (await kycBlock.count() > 0) {
    throw new Error('testseller lacks KYC level 2 — cannot respond to purchase request.');
  }
  await expect(seller.locator('form[action="/api/material-listings"]')).toBeVisible({ timeout: 10_000 });
  // When request param is present, grade and quantity are pre-filled — verify
  const gradeSelectAfter = seller.locator('select[name="gradeId"]');
  const selectedVal = await gradeSelectAfter.inputValue();
  expect(selectedVal, 'grade should be pre-filled from purchase request').toBeTruthy();

  // Fill remaining required fields (city carries unique stamp)
  // Province may be pre-filled from request; overwrite with our city stamp province
  await seller.fill('input[name="city"]', cityStamp);
  // Ensure province is filled (pre-filled from request, but ensure)
  const provInput = seller.locator('input[name="province"]');
  if (!(await provInput.inputValue())) await provInput.fill('اصفهان');
  await seller.fill('input[name="packagingType"]', 'کیسه 25 کیلویی');
  await seller.fill('input[name="packagingQuality"]', 'نو');
  await seller.fill('input[name="materialQuality"]', 'virgin');
  // askingPrice may be empty — fill it
  const priceInput = seller.locator('input[name="askingPriceToman"]');
  if (!(await priceInput.inputValue())) await priceInput.fill('92000');
  await seller.fill('input[name="weighbridgeNetWeightKg"]', '2000');
  await seller.locator('input[name="weighbridgeDate"]').fill(todayStr());
  await seller.setInputFiles('input[name="weighbridgeTicket"]', ticketPath);

  await Promise.all([
    seller.waitForURL(/\/my-listings(\?|$)/, { timeout: 20_000 }),
    seller.click('button:has-text("ثبت آگهی")'),
  ]);
  await expect(seller).not.toHaveURL(/\/login/);
  expect(seller.url()).toContain('/my-listings');

  // Verify seller sees the new listing
  await seller.goto('/my-listings');
  await expect(seller).not.toHaveURL(/\/login/);
  const sellerCard = seller.locator('div').filter({ hasText: cityStamp }).first();
  await expect(sellerCard, `seller card for purchase-request response ${cityStamp}`).toBeVisible({
    timeout: 15_000,
  });

  // ── Buyer: verify purchase request now shows at least 1 listing in response ──
  await buyer.goto('/purchase-requests');
  await expect(buyer).not.toHaveURL(/\/login/);
  const updatedReqCard = buyer.locator('div').filter({ hasText: prStamp.slice(0, 20) }).first();
  await expect(updatedReqCard).toBeVisible({ timeout: 15_000 });
  // The card shows "X آگهی در پاسخ" — after seller response it should be >=1
  await expect(updatedReqCard.locator('text=آگهی در پاسخ').first()).toBeVisible({ timeout: 15_000 });

  // Also verify the listing is visible in /market
  await buyer.goto('/market');
  await expect(buyer).not.toHaveURL(/\/login/);
  const marketRow = buyer.locator('tr').filter({ hasText: cityStamp }).first();
  await expect(marketRow, `market row for purchase-request response ${cityStamp}`).toBeVisible({
    timeout: 15_000,
  });

  await buyerCtx.close();
  await sellerCtx.close();
});

// ── Scenario 3: seller creates → admin cancels → NOT in /market ──

test('market flow — scenario 3: seller creates → admin cancels (حذف به دلیل تخلف) → NOT in /market', async ({
  browser,
}) => {
  const cityStamp = stamp('e2e-listing-cancel');
  const ticketPath = await ensureTicketFile();

  // ── Seller: create listing ──
  const sellerCtx = await browser.newContext({
    baseURL: 'http://185.164.73.143:3000',
    storageState: '.auth/seller.json',
  });
  const seller = await sellerCtx.newPage();
  await seller.goto('/new-listing');
  await expect(seller).not.toHaveURL(/\/login/);

  const kycBlock = seller.locator('text=احراز تولیدکننده لازمه');
  if (await kycBlock.count() > 0) {
    throw new Error('testseller lacks KYC level 2 — cannot create listing for cancel test.');
  }
  await expect(seller.locator('form[action="/api/material-listings"]')).toBeVisible({ timeout: 10_000 });

  await selectFirstGrade(seller);
  await seller.fill('input[name="quantityTon"]', '1');
  await seller.fill('input[name="province"]', 'تهران');
  await seller.fill('input[name="city"]', cityStamp);
  await seller.fill('input[name="packagingType"]', 'کیسه 25 کیلویی');
  await seller.fill('input[name="packagingQuality"]', 'نو');
  await seller.fill('input[name="materialQuality"]', 'virgin');
  await seller.fill('input[name="askingPriceToman"]', '88000');
  await seller.fill('input[name="weighbridgeNetWeightKg"]', '1000');
  await seller.locator('input[name="weighbridgeDate"]').fill(todayStr());
  await seller.setInputFiles('input[name="weighbridgeTicket"]', ticketPath);

  await Promise.all([
    seller.waitForURL(/\/my-listings(\?|$)/, { timeout: 20_000 }),
    seller.click('button:has-text("ثبت آگهی")'),
  ]);
  await expect(seller).not.toHaveURL(/\/login/);
  expect(seller.url()).toContain('/my-listings');

  await seller.goto('/my-listings');
  await expect(seller).not.toHaveURL(/\/login/);
  const myCard = seller.locator('div').filter({ hasText: cityStamp }).first();
  await expect(myCard, `seller card ${cityStamp} before cancel`).toBeVisible({ timeout: 15_000 });

  // ── Admin: cancel the listing (حذف به دلیل تخلف) ──
  const adminCtx = await browser.newContext({
    baseURL: 'http://185.164.73.143:3001',
    storageState: '.auth/admin.json',
  });
  const admin = await adminCtx.newPage();
  await admin.goto('/admin-material-listings');
  await expect(admin).not.toHaveURL(/\/login/);
  const adminRow = admin.locator('tr').filter({ hasText: cityStamp }).first();
  await expect(adminRow, `admin row ${cityStamp} before cancel`).toBeVisible({ timeout: 15_000 });

  // The cancel button is "حذف به دلیل تخلف" — hidden inputs id + action=cancel.
  // Locate the exact form by our listing id (row-level filter can miss because
  // the form lives inside the last <td>).
  const rowId = await adminRow.locator('input[name="id"]').first().getAttribute('value');
  expect(rowId, 'admin row must expose the listing id').toBeTruthy();
  const targetForm = admin
    .locator(`form:has(input[name="id"][value="${rowId}"]):has(input[name="action"][value="cancel"])`)
    .first();
  await expect(targetForm, 'cancel form for our listing').toBeVisible({ timeout: 10_000 });
  await Promise.all([
    admin.waitForURL(/\/admin-material-listings\?updated=1/, { timeout: 20_000 }),
    targetForm.locator('button:has-text("حذف به دلیل تخلف")').click(),
  ]);
  await expect(admin).not.toHaveURL(/\/login/);

  // Verify admin now shows "لغو شده" for our row
  await admin.goto('/admin-material-listings');
  await expect(admin).not.toHaveURL(/\/login/);
  const cancelledRow = admin.locator('tr').filter({ hasText: cityStamp }).first();
  await expect(cancelledRow, `admin row ${cityStamp} after cancel`).toBeVisible({ timeout: 15_000 });
  await expect(cancelledRow.locator('text=لغو شده').first()).toBeVisible({ timeout: 10_000 });

  // ── Buyer: verify NOT in /market (market only shows validityStatus=active) ──
  const buyerCtx = await browser.newContext({
    baseURL: 'http://185.164.73.143:3000',
    storageState: '.auth/buyer.json',
  });
  const buyer = await buyerCtx.newPage();
  await buyer.goto('/market');
  await expect(buyer).not.toHaveURL(/\/login/);
  const marketRow = buyer.locator('tr').filter({ hasText: cityStamp });
  await expect(marketRow, `market should NOT contain cancelled listing ${cityStamp}`).toHaveCount(0);

  // Seller's own /my-listings should now show "لغو‌شده"
  await seller.goto('/my-listings');
  await expect(seller).not.toHaveURL(/\/login/);
  const sellerCardAfter = seller.locator('div').filter({ hasText: cityStamp }).first();
  await expect(sellerCardAfter).toBeVisible({ timeout: 15_000 });
  await expect(sellerCardAfter.locator('text=لغو‌شده').first()).toBeVisible({ timeout: 10_000 });

  await sellerCtx.close();
  await adminCtx.close();
  await buyerCtx.close();
});
