import { test, expect } from '@playwright/test';
import { TEST_GRADE_CODE } from './helpers/testWarehouse';

const N = 5;

test('load: 5 parallel RFQs against isolated stock + admin refresh', async ({ browser }) => {
  if (TEST_GRADE_CODE.startsWith('FILL_ME')) test.skip(true, 'test warehouse IDs not filled — Sina must provision via SSH/psql');

  const t0 = Date.now();
  const buyers = await Promise.all(
    Array.from({ length: N }, async (_, i) => {
      const ctx = await browser.newContext({
        baseURL: 'http://185.164.73.143:3000',
        storageState: '.auth/buyer.json',
      });
      const page = await ctx.newPage();
      return { ctx, page, i };
    })
  );

  const adminCtx = await browser.newContext({
    baseURL: 'http://185.164.73.143:3001',
    storageState: '.auth/admin.json',
  });
  const admin = await adminCtx.newPage();

  // Each buyer hits /rfq, adds the test row (by latin grade code), submits with different qty.
  const rfqRuns = buyers.map(async ({ page, i }) => {
    const start = Date.now();
    await page.goto('/rfq');
    await expect(page, `buyer ${i} /rfq must not redirect to /login`).not.toHaveURL(/\/login/);
    const row = page
      .locator('div')
      .filter({ hasText: TEST_GRADE_CODE })
      .filter({ has: page.locator('button:has-text("افزودن")') })
      .first();
    const rowCount = await page.locator('div').filter({ hasText: TEST_GRADE_CODE }).count();
    console.log(`[debug load buyer ${i}] rows matching ${TEST_GRADE_CODE}: ${rowCount}`);
    await row.waitFor({ timeout: 15_000 });
    await row.locator('button:has-text("افزودن")').click();
    // Increase qty to i+1
    const cartRow = page.locator('div').filter({ has: page.locator('button:has-text("✕")') }).first();
    await cartRow.waitFor({ timeout: 5_000 });
    for (let k = 1; k <= i; k++) {
      await cartRow.locator('button:has-text("+")').click();
    }
    await Promise.all([
      page.waitForURL(/\/my-orders/),
      page.click('button:has-text("ثبت درخواست قیمت")'),
    ]);
    const elapsed = Date.now() - start;
    expect(elapsed, `buyer ${i} RFQ round-trip under 5s`).toBeLessThan(5000);
    await expect(page.locator('text=در حال ثبت اولیه').first()).toBeVisible({ timeout: 10_000 });
    return { i, elapsed };
  });

  // In parallel: admin refreshes /admin-orders 3 times, each under 5s
  const adminRuns = (async () => {
    for (let r = 0; r < 3; r++) {
      const s = Date.now();
      await admin.goto('/admin-orders');
      await expect(admin, `admin /admin-orders must not redirect to /login`).not.toHaveURL(/\/login/);
      await admin.waitForLoadState('networkidle');
      const e = Date.now() - s;
      expect(e, `admin /admin-orders refresh ${r} under 5s`).toBeLessThan(5000);
      if (r < 2) await admin.waitForTimeout(800);
    }
  })();

  const results = await Promise.all([...rfqRuns, adminRuns]);
  const total = Date.now() - t0;

  // No cross-contamination: all 5 /my-orders pages still show at least one pending order
  for (const { page, i } of buyers) {
    await page.goto('/my-orders');
    await expect(page.locator('text=در حال ثبت اولیه').first()).toBeVisible({ timeout: 10_000 });
  }

  for (const { ctx } of buyers) await ctx.close();
  await adminCtx.close();
});
