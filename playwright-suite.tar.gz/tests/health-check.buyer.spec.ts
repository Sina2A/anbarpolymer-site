import { test, expect } from '@playwright/test';

// Buyer-side routes only — run under the `buyer` project (baseURL :3000).
// Multi-actor specs are also matched to `buyer`; see playwright.config.ts.
const BUYER_ROUTES = ['/dashboard', '/rfq', '/custom-request', '/support', '/my-orders', '/my-requests'] as const;

for (const route of BUYER_ROUTES) {
  test(`buyer ${route} loads without 404 or GENERIC error`, async ({ page }) => {
    const res = await page.goto(route);
    expect(res, `${route} navigation failed`).not.toBeNull();
    expect(res!.status(), `${route} status`).not.toBe(404);
    expect(res!.status(), `${route} status`).not.toBe(500);
    // Category 3 guard: never silently land on /login
    await expect(page, `${route} must not redirect to /login`).not.toHaveURL(/\/login/);
    const body = (await page.content()).toLowerCase();
    expect(body, `${route} should not contain "کد خطا"`).not.toContain('کد خطا');
    expect(body, `${route} should not contain "generic"`).not.toContain('generic');
    // Light "rendered at all" gate — buyer pages use UserNav or at least a heading:
    const hasNav = await page.locator('aside, nav').first().isVisible().catch(() => false);
    const hasHeading = await page.locator('h1, h2').first().isVisible().catch(() => false);
    expect(hasNav || hasHeading, `${route} should render nav or a heading`).toBe(true);
  });
}
