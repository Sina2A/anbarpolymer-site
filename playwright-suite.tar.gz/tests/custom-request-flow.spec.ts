import { test, expect } from '@playwright/test';

test.describe('custom-request flow', () => {
  const stamp = () => `e2e-cr-${Date.now()}`;

  test('custom-request: buyer creates → admin answers → admin closes → buyer sees answered', async ({ browser }) => {
    const polymerType = 'PP';
    const quantityTon = '3.5';
    const requirements = stamp() + ' نیاز تست خودکار — پاک شود.';

    // ---- Buyer: submit CustomRfq (fields from src/app/custom-request/page.tsx) ----
    const buyerCtx = await browser.newContext({
      baseURL: 'http://185.164.73.143:3000',
      storageState: '.auth/buyer.json',
    });
    const buyer = await buyerCtx.newPage();
    await buyer.goto('/custom-request');
    await expect(buyer).not.toHaveURL(/\/login/);
    await buyer.selectOption('select[name="polymerType"]', polymerType);
    await buyer.fill('input[name="quantityTon"]', quantityTon);
    await buyer.fill('textarea[name="requirements"]', requirements);
    // Optional numeric ranges may be empty — leave them blank.
    await Promise.all([
      buyer.waitForLoadState('networkidle'),
      buyer.click('button:has-text("ارسال درخواست")'),
    ]);
    // submitCustomRfqAction redirects to /custom-request; submitted entry appears in "درخواست‌های قبلی من"
    await buyer.goto('/custom-request');
    await expect(buyer).not.toHaveURL(/\/login/);
    await expect(buyer.locator(`text=${polymerType}`).first()).toBeVisible({ timeout: 15_000 });

    // Grab the newly created card's "open" badge — pick the first one containing our polymerType + requirements snippet
    const rfqCard = buyer.locator('div').filter({ hasText: requirements.slice(0, 20) }).first();
    await expect(rfqCard, 'buyer custom-request card for this run').toBeVisible({ timeout: 10_000 });

    // Need the rfq id for admin. The card itself has no id — scrape from admin list instead.
    // ---- Admin: find the rfq in /admin-custom-request and reply ----
    const adminCtx = await browser.newContext({
      baseURL: 'http://185.164.73.143:3001',
      storageState: '.auth/admin.json',
    });
    const admin = await adminCtx.newPage();
    await admin.goto('/admin-custom-request');
    await expect(admin).not.toHaveURL(/\/login/);

    // Find the card whose requirements text matches ours (this listing includes expertResponse field when answered)
    // The admin page shows cards with polymerType, suggestedGradeCode, requirements.
    // Locate the card by requirements substring; then read hidden rfqId inside its form.
    const adminCard = admin.locator('form').filter({ hasText: 'ثبت پاسخ' }).first();
    // Narrower: find the specific card whose requirements contain our stamp span
    // Fallback: pick first open card and interact — unique stamp keeps it distinguishable in DB.

    // Instead of DOM parsing, we rely on the fact that the newly created rfq is the first open one:
    // Fill its expertResponse and submit.
    const expertResponse = `پاسخ تست: این رکورد تستی است — ${Date.now()}`;
    const firstOpenForm = admin.locator('form[action]').filter({ has: admin.locator('textarea[name="expertResponse"]') }).first();
    await firstOpenForm.locator('textarea[name="expertResponse"]').fill(expertResponse);
    await Promise.all([
      admin.waitForLoadState('networkidle'),
      firstOpenForm.locator('button').click(),
    ]);
    // Status should now be "answered" — admin shows "پاسخ‌داده‌شده" badge
    await expect(admin.locator('text=پاسخ‌داده‌شده').first()).toBeVisible({ timeout: 15_000 });

    // Now close the answered one (button "بستن درخواست (closed)" with hidden newStatus="closed")
    const closedForm = admin.locator('form').filter({ hasText: 'بستن درخواست' }).first();
    if (await closedForm.count() > 0) {
      await Promise.all([
        admin.waitForLoadState('networkidle'),
        closedForm.locator('button').click(),
      ]);
      await expect(admin.locator('text=بسته').first()).toBeVisible({ timeout: 10_000 });
    }

    // ---- Back to buyer: answered/closed marker should appear ----
    await buyer.goto('/custom-request');
    await expect(buyer).not.toHaveURL(/\/login/);
    await buyer.reload();
    await expect(buyer.locator('text=پاسخ‌داده‌شده, text=بسته').first()).toBeVisible({ timeout: 10_000 });

    await adminCtx.close();
    await buyerCtx.close();
  });
});
