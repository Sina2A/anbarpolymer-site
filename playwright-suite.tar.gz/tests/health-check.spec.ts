import { test, expect } from '@playwright/test';

const BUYER_ROUTES = ['/dashboard', '/rfq', '/custom-request', '/support', '/my-orders', '/my-requests'] as const;
// Every admin route below is real: sections.ts marks all 17 sections isReal:true,
// and each of these has a page.tsx on disk (verified against the re-synced src/).
const ADMIN_ROUTES = [
  '/admin-orders',
  '/admin-custom-request',
  '/admin-support',
  '/admin-pricing',
  '/admin-logistics',
  '/admin-warehouses',
  '/admin-buyers',
  '/admin-material-listings',
] as const;

for (const route of BUYER_ROUTES) {
  test(`buyer ${route} loads without 404 or GENERIC error`, async ({ page }) => {
    const res = await page.goto(route);
    expect(res, `${route} navigation failed`).not.toBeNull();
    expect(res!.status(), `${route} status`).not.toBe(404);
    expect(res!.status(), `${route} status`).not.toBe(500);
    const body = (await page.content()).toLowerCase();
    expect(body, `${route} should not contain "کد خطا"`).not.toContain('کد خطا');
    expect(body, `${route} should not contain "generic"`).not.toContain('generic');
    // Light "rendered at all" gate — buyer pages use UserNav or at least a heading:
    const hasNav = await page.locator('aside, nav').first().isVisible().catch(() => false);
    const hasHeading = await page.locator('h1, h2').first().isVisible().catch(() => false);
    expect(hasNav || hasHeading, `${route} should render nav or a heading`).toBe(true);
  });
}

for (const route of ADMIN_ROUTES) {
  test(`admin ${route} loads without 404 or GENERIC error`, async ({ page }) => {
    const res = await page.goto(route);
    expect(res, `${route} navigation failed`).not.toBeNull();
    expect(res!.status(), `${route} status`).not.toBe(404);
    expect(res!.status(), `${route} status`).not.toBe(500);
    const body = (await page.content()).toLowerCase();
    expect(body, `${route} should not contain "کد خطا"`).not.toContain('کد خطا');
    expect(body, `${route} should not contain "generic"`).not.toContain('generic');
    const hasNav = await page.locator('aside, nav').first().isVisible().catch(() => false);
    const hasHeading = await page.locator('h1, h2').first().isVisible().catch(() => false);
    expect(hasNav || hasHeading, `${route} should render nav or a heading`).toBe(true);
  });
}
