import { test as setup } from '@playwright/test';
import fs from 'fs';
import path from 'path';

const stateFile = path.join(__dirname, '..', '..', '.auth', 'admin.json');

setup('admin login', async ({ page }) => {
  fs.mkdirSync(path.dirname(stateFile), { recursive: true });
  await page.goto('/login');
  await page.fill('input[name="identifier"]', 'SinaAbouei');
  await page.fill('input[name="password"]', '404696417SKj');
  await Promise.all([
    page.waitForURL(/\/admin-/),
    page.click('button[type="submit"]'),
  ]);
  await page.waitForLoadState('networkidle');
  await page.context().storageState({ path: stateFile });
});
