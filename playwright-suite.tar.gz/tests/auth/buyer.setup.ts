import { test as setup, expect } from '@playwright/test';
import fs from 'fs';
import path from 'path';

const stateFile = path.join(__dirname, '..', '..', '.auth', 'buyer.json');

setup('buyer login', async ({ page }) => {
  fs.mkdirSync(path.dirname(stateFile), { recursive: true });
  await page.goto('/login');
  await page.fill('input[name="identifier"]', 'testbuyer');
  await page.fill('input[name="password"]', 'Test@1234');
  await Promise.all([
    page.waitForURL(/\/(my-orders|dashboard|rfq)/),
    page.click('button[type="submit"]'),
  ]);
  await page.waitForLoadState('networkidle');
  await page.context().storageState({ path: stateFile });
});
