import { test, expect } from '@playwright/test';

/**
 * button-health — ConfirmSubmitButton (native confirm() dialogs)
 *
 * Highest-value targets: admin-pricing formula/[id], margins/[id], benchino/[id]
 * delete buttons. These three pages had three layers of bugs fixed recently:
 *   1. onClick handler crashing in a Server Component context,
 *   2. a nested <form> making the delete click fire the save action instead,
 *   3. missing redirect() after delete → 404.
 * All three are now fixed: ConfirmSubmitButton + sibling (non-nested) delete forms
 * + redirect() in each delete action. Each test creates its OWN throwaway record
 * through the real /new UI, then exercises the delete flow on ONLY that record.
 *
 * Redirect targets (verified in src/app/admin-pricing/actions.ts):
 *   formula  → /admin-pricing?tab=formula
 *   margins  → /admin-pricing?tab=margins
 *   benchino → /admin-pricing?tab=publish&subtab=benchino
 *
 * Also covers ConfirmSubmitButton on:
 *   /admin-orders          — "رد این سفارش" (rejectOrder, restores stock)
 *   /admin-support/[id]    — "بستن تیکت" (updateTicketStatusAction status=closed)
 *
 * Only records created by this spec are ever deleted/rejected.
 */

test.describe('pricing delete buttons (formula / margins / benchino)', () => {
  test('formula/[id]: dismiss keeps the formula, accept deletes and redirects to ?tab=formula (no 404)', async ({ browser }) => {
    const adminCtx = await browser.newContext({
      baseURL: 'http://185.164.73.143:3001',
      storageState: '.auth/admin.json',
    });
    const admin = await adminCtx.newPage();

    // --- Create our own throwaway formula via the real UI (general, no grade) ---
    await admin.goto('/admin-pricing/formula/new');
    await admin.fill('input[placeholder="قیمت پایه"]', '12345');
    await admin.fill('input[placeholder="ضریب"]', '2');
    await admin.fill('input[placeholder="هزینهی ثابت"]', '3');
    await Promise.all([
      admin.waitForURL(/\/admin-pricing(\?|$)/, { timeout: 20_000 }),
      admin.click('button:has-text("ذخیره فرمول")'),
    ]);

    // --- Locate ONLY our formula row (list is newest-first) ---
    await admin.goto('/admin-pricing?tab=formula');
    const row = admin.locator('tr').filter({ hasText: 'عمومی (همهی گریدها)' }).filter({ hasText: '12345 * 2 + 3' }).first();
    await row.waitFor({ timeout: 10_000 });
    const editHref = await row.locator('a:has-text("ویرایش")').getAttribute('href');
    expect(editHref, 'edit link should point at /admin-pricing/formula/<id>').toMatch(/\/admin-pricing\/formula\/.+/);

    // --- DISMISS: native confirm cancelled → nothing happens.
    // Regression guard for the nested-form bug: the delete click must NOT
    // fire the "ذخیره تغییرات" action (no mutation, no navigation, page intact).
    await admin.goto(editHref!);
    await expect(admin.locator('button:has-text("ذخیره تغییرات")')).toBeVisible();
    admin.once('dialog', (d) => d.dismiss());
    await admin.click('button:has-text("حذف فرمول")');
    await admin.waitForTimeout(800);
    await expect(admin.locator('button:has-text("ذخیره تغییرات")')).toBeVisible();

    // --- ACCEPT: formula deleted, redirected to ?tab=formula, row gone ---
    admin.once('dialog', (d) => d.accept());
    await Promise.all([
      admin.waitForURL(/\/admin-pricing\?tab=formula/, { timeout: 20_000 }),
      admin.click('button:has-text("حذف فرمول")'),
    ]);
    expect(admin.url(), 'redirect target after formula delete').toContain('/admin-pricing?tab=formula');
    await expect(admin.locator('text=12345 * 2 + 3')).toHaveCount(0);

    await adminCtx.close();
  });

  test('margins/[id]: dismiss keeps the record, accept deletes and redirects to ?tab=margins (no 404)', async ({ browser }) => {
    const adminCtx = await browser.newContext({
      baseURL: 'http://185.164.73.143:3001',
      storageState: '.auth/admin.json',
    });
    const admin = await adminCtx.newPage();

    // --- Create our own margin set via the real UI ---
    await admin.goto('/admin-pricing/margins/new');
    const gradeSelect = admin.locator('select[name="gradeId"]');
    const options = gradeSelect.locator('option[value]:not([value=""])');
    const optCount = await options.count();
    if (optCount === 0) {
      await adminCtx.close();
      // The /new page only lists grades that have NO margin yet. If every active
      // grade already has one, we can't create an isolated record — skipping is
      // the safe option (never touch a real production margin record).
      test.skip(true, 'all grades already have margins — no isolated record can be created');
      return;
    }
    const gradeCode = (await options.first().textContent())?.trim();
    await gradeSelect.selectOption({ index: 1 });
    await admin.fill('input[name="floorPercent"]', '5');
    await admin.fill('input[name="targetPercent"]', '10');
    await admin.fill('input[name="stretchPercent"]', '15');
    await Promise.all([
      admin.waitForURL(/\/admin-pricing(\?|$)/, { timeout: 20_000 }),
      admin.click('button:has-text("ذخیره سطوح")'),
    ]);

    // --- Locate ONLY our row via the unique percent triple (list is newest-first) ---
    await admin.goto('/admin-pricing?tab=margins');
    const row = admin.locator('tr').filter({ hasText: '5%' }).filter({ hasText: '10%' }).filter({ hasText: '15%' }).first();
    await row.waitFor({ timeout: 10_000 });
    const editHref = await row.locator('a:has-text("ویرایش")').getAttribute('href');
    expect(editHref, 'edit link should point at /admin-pricing/margins/<id>').toMatch(/\/admin-pricing\/margins\/.+/);

    // --- DISMISS: confirm cancelled → still on the edit page, nothing mutated ---
    await admin.goto(editHref!);
    await expect(admin.locator('button:has-text("ذخیره تغییرات")')).toBeVisible();
    admin.once('dialog', (d) => d.dismiss());
    await admin.click('button:has-text("حذف")');
    await admin.waitForTimeout(800);
    await expect(admin.locator('button:has-text("ذخیره تغییرات")')).toBeVisible();

    // --- ACCEPT: deleted, redirected to ?tab=margins, our triple gone ---
    admin.once('dialog', (d) => d.accept());
    await Promise.all([
      admin.waitForURL(/\/admin-pricing\?tab=margins/, { timeout: 20_000 }),
      admin.click('button:has-text("حذف")'),
    ]);
    expect(admin.url(), 'redirect target after margins delete').toContain('/admin-pricing?tab=margins');
    await expect(admin.locator('tr').filter({ hasText: '5%' }).filter({ hasText: '10%' }).filter({ hasText: '15%' })).toHaveCount(0);
    expect(gradeCode, 'created + deleted margin for grade (net zero)').toBeTruthy();

    await adminCtx.close();
  });

  test('benchino/[id]: dismiss keeps the price, accept deletes and redirects to ?tab=publish&subtab=benchino (no 404)', async ({ browser }) => {
    const adminCtx = await browser.newContext({
      baseURL: 'http://185.164.73.143:3001',
      storageState: '.auth/admin.json',
    });
    const admin = await adminCtx.newPage();

    // --- Create our own benchmark price via the real UI ---
    await admin.goto('/admin-pricing/benchino/new');
    const gradeSelect = admin.locator('select[name="gradeId"]');
    const options = gradeSelect.locator('option[value]:not([value=""])');
    const optCount = await options.count();
    if (optCount === 0) {
      await adminCtx.close();
      test.skip(true, 'no active grades — cannot create an isolated benchmark price');
      return;
    }
    await gradeSelect.selectOption({ index: 1 });
    await admin.fill('input[name="manualValue"]', '999');
    await admin.fill('input[name="sourceLabel"]', 'e2e-btnhealth');
    await Promise.all([
      admin.waitForURL(/\/admin-pricing(\?|$)/, { timeout: 20_000 }),
      admin.click('button:has-text("ذخیره قیمت")'),
    ]);

    // --- Locate ONLY our row via the unique source label (list is effectiveDate-desc) ---
    await admin.goto('/admin-pricing?tab=publish&subtab=benchino');
    const row = admin.locator('tr').filter({ hasText: 'e2e-btnhealth' }).first();
    await row.waitFor({ timeout: 10_000 });
    const editHref = await row.locator('a:has-text("ویرایش")').getAttribute('href');
    expect(editHref, 'edit link should point at /admin-pricing/benchino/<id>').toMatch(/\/admin-pricing\/benchino\/.+/);

    // --- DISMISS: confirm cancelled → still on the edit page, nothing mutated ---
    await admin.goto(editHref!);
    await expect(admin.locator('button:has-text("ذخیره تغییرات")')).toBeVisible();
    admin.once('dialog', (d) => d.dismiss());
    await admin.click('button:has-text("حذف")');
    await admin.waitForTimeout(800);
    await expect(admin.locator('button:has-text("ذخیره تغییرات")')).toBeVisible();

    // --- ACCEPT: deleted, redirected to ?tab=publish&subtab=benchino, row gone ---
    admin.once('dialog', (d) => d.accept());
    await Promise.all([
      admin.waitForURL(/\/admin-pricing\?tab=publish&subtab=benchino/, { timeout: 20_000 }),
      admin.click('button:has-text("حذف")'),
    ]);
    expect(admin.url(), 'redirect target after benchino delete').toContain('/admin-pricing?tab=publish&subtab=benchino');
    await expect(admin.locator('tr').filter({ hasText: 'e2e-btnhealth' })).toHaveCount(0);

    await adminCtx.close();
  });
});

test.describe('button-health (ConfirmSubmitButton native confirm)', () => {
  test('dismiss keeps ticket open, accept closes it — isolated ticket', async ({ browser }) => {
    // Buyer creates a disposable ticket on :3000
    const buyerCtx = await browser.newContext({
      baseURL: 'http://185.164.73.143:3000',
      storageState: '.auth/buyer.json',
    });
    const buyer = await buyerCtx.newPage();
    const stamp = `e2e-btnhealth-${Date.now()}`;
    await buyer.goto('/support');
    await buyer.fill('input[name="subject"]', stamp);
    await buyer.fill('textarea[name="detail"]', 'تست خودکار button-health — پاک شود.');
    await Promise.all([
      buyer.waitForURL(/\/support\/[a-z0-9]+/i),
      buyer.click('form[action] button[type="submit"]'),
    ]);
    const ticketId = buyer.url().split('/support/')[1];
    expect(ticketId).toBeTruthy();

    // Admin dismisses the close dialog → still open. Then accepts → closed.
    const adminCtx = await browser.newContext({
      baseURL: 'http://185.164.73.143:3001',
      storageState: '.auth/admin.json',
    });
    const admin = await adminCtx.newPage();
    await admin.goto(`/admin-support/${ticketId}`);
    await expect(admin.locator('text=باز').first()).toBeVisible({ timeout: 10_000 });

    // Dismiss
    admin.once('dialog', (d) => d.dismiss());
    await admin.locator('button:has-text("بستن تیکت")').click();
    await admin.waitForTimeout(800);
    // Still open — not closed
    await expect(admin.locator('text=بسته').first()).toHaveCount(0);

    // Accept
    admin.once('dialog', (d) => d.accept());
    await admin.locator('button:has-text("بستن تیکت")').click();
    await expect(admin.locator('text=بسته').first()).toBeVisible({ timeout: 15_000 });

    // Verify buyer now sees closed (no textarea)
    await buyer.goto(`/support/${ticketId}`);
    await expect(buyer.locator('text=بسته').first()).toBeVisible({ timeout: 10_000 });
    await expect(buyer.locator('textarea[name="body"]')).toHaveCount(0);

    // Re-open via admin so cleanup (if any) can consistently reason about state
    await admin.goto(`/admin-support/${ticketId}`);
    await admin.locator('button:has-text("بازگرداندن به «باز»")').click();
    await expect(admin.locator('text=باز').first()).toBeVisible({ timeout: 10_000 });

    await adminCtx.close();
    await buyerCtx.close();
  });

  test('admin-orders price submit also goes through native confirm', async ({ browser }) => {
    // We don't execute a full priced flow here; just verify the confirm() fires and dismiss prevents submit.
    // Needs an order created against the isolated test warehouse — skip if placeholder.
    const { TEST_WAREHOUSE_ID } = await import('./helpers/testWarehouse');
    if (TEST_WAREHOUSE_ID.startsWith('FILL_ME')) test.skip(true, 'test warehouse not provisioned');

    // Create an RFQ order to get a card with price inputs + priced submit
    const buyerCtx = await browser.newContext({
      baseURL: 'http://185.164.73.143:3000',
      storageState: '.auth/buyer.json',
    });
    const { TEST_WAREHOUSE_NAME } = await import('./helpers/testWarehouse');
    const buyer = await buyerCtx.newPage();
    await buyer.goto('/rfq');
    const row = buyer.locator('div').filter({ hasText: TEST_WAREHOUSE_NAME }).filter({ has: buyer.locator('button:has-text("افزودن")') }).first();
    await row.waitFor({ timeout: 15_000 });
    await row.locator('button:has-text("افزودن")').click();
    await Promise.all([
      buyer.waitForURL(/\/my-orders/),
      buyer.click('button:has-text("ثبت درخواست قیمت")'),
    ]);

    const adminCtx = await browser.newContext({
      baseURL: 'http://185.164.73.143:3001',
      storageState: '.auth/admin.json',
    });
    const admin = await adminCtx.newPage();
    await admin.goto('/admin-orders');
    const card = admin.locator('div').filter({ hasText: TEST_WAREHOUSE_NAME }).filter({ hasText: 'در انتظار قیمتگذاری' }).first();
    await card.waitFor({ timeout: 15_000 });

    // Dismiss → should stay pending
    admin.once('dialog', (d) => d.dismiss());
    await card.locator('button:has-text("ثبت قیمتها و ارسال به مشتری")').click();
    await admin.waitForTimeout(800);
    await expect(admin.locator('text=در انتظار قیمتگذاری').first()).toBeVisible({ timeout: 10_000 });

    // Clean up: reject it so its locked stock is returned (only touches isolated test stock)
    admin.once('dialog', (d) => d.accept());
    await card.locator('button:has-text("رد این سفارش")').click();
    await expect(admin.locator('text=رد شد').first()).toBeVisible({ timeout: 10_000 }).catch(() => {});

    await adminCtx.close();
    await buyerCtx.close();
  });
});
