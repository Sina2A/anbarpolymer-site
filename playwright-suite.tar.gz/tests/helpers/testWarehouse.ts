export const TEST_WAREHOUSE_ID = 'test-wh-fa3bf37936754ae4a703';
export const TEST_STOCK_ID = 'test-stock-3df671f2f56fa889f2ee';
// Latin grade code of the isolated test stock — safe from ZWNJ issues.
// Used (instead of the Persian warehouse name) to locate the test row on /rfq.
export const TEST_GRADE_CODE = 'PP H110MA';
