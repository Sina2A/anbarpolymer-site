export const TEST_WAREHOUSE_ID = 'test-wh-fa3bf37936754ae4a703';
export const TEST_STOCK_ID = 'test-stock-3df671f2f56fa889f2ee';
export const TEST_WAREHOUSE_NAME = 'test-wh-fa3bf37936754ae4a703';
