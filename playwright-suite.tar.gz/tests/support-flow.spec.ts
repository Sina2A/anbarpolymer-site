import { test, expect } from '@playwright/test';

// Records created by this spec (for REPORT-PLAYWRIGHT.md cleanup).
const created: string[] = [];

const stamp = () => `e2e-support-${Date.now()}`;

test('support flow: buyer creates ticket → admin replies → admin closes → buyer sees closed', async ({ browser }) => {
  const subject = stamp();
  const detail = 'تست خودکار: این یک تیکت آزمایشی است و باید پاک شود.';

  // ---- Buyer context (port 3000) ----
  const buyerCtx = await browser.newContext({
    baseURL: 'http://185.164.73.143:3000',
    storageState: '.auth/buyer.json',
  });
  const buyer = await buyerCtx.newPage();

  await buyer.goto('/support');
  await expect(buyer).not.toHaveURL(/\/login/);
  await buyer.fill('input[name="subject"]', subject);
  await buyer.fill('textarea[name="detail"]', detail);
  await Promise.all([
    buyer.waitForURL(/\/support\/[a-z0-9]+/i),
    buyer.click('form[action] button[type="submit"]'),
  ]);
  const ticketId = buyer.url().split('/support/')[1];
  expect(ticketId, 'ticket id parsed from redirect URL').toBeTruthy();
  created.push(`SupportTicket ${ticketId} (subject "${subject}")`);

  // Buyer sees own ticket "open"
  await expect(buyer.locator('h1')).toContainText(subject);

  // ---- Admin context (port 3001) ----
  const adminCtx = await browser.newContext({
    baseURL: 'http://185.164.73.143:3001',
    storageState: '.auth/admin.json',
  });
  const admin = await adminCtx.newPage();

  // Find the ticket in the open tab by its unique subject
  await admin.goto('/admin-support?status=open');
  await expect(admin).not.toHaveURL(/\/login/);
  await admin.locator(`a[href="/admin-support/${ticketId}"]`).first().waitFor({ timeout: 15_000 });

  await admin.goto(`/admin-support/${ticketId}`);
  await expect(admin).not.toHaveURL(/\/login/);
  // Reply as staff
  await admin.fill('textarea[name="body"]', 'پاسخ خودکار تست — تیکت بررسی شد.');
  await admin.click('button:has-text("ارسال پاسخ")');
  await expect(admin.locator('text=پاسخ‌داده‌شده').first()).toBeVisible({ timeout: 15_000 });

  // Close ticket — triggers native confirm() via ConfirmSubmitButton
  admin.once('dialog', (d) => d.accept());
  await admin.click('button:has-text("بستن تیکت")');
  await expect(admin.locator('text=بسته').first()).toBeVisible({ timeout: 15_000 });

  // ---- Back to buyer: ticket now closed, no reply form ----
  await buyer.goto(`/support/${ticketId}`);
  await expect(buyer).not.toHaveURL(/\/login/);
  await expect(buyer.locator('text=بسته').first()).toBeVisible();
  await expect(buyer.locator('textarea[name="body"]')).toHaveCount(0);
  await expect(buyer.locator('text=این تیکت بسته شده')).toBeVisible();

  await adminCtx.close();
  await buyerCtx.close();
});

test('support flow: buyer replies to answered ticket re-opens it', async ({ browser }) => {
  // This exercises addUserMessageAction: user message sets status back to open.
  const subject = stamp() + '-reopen';
  const buyerCtx = await browser.newContext({
    baseURL: 'http://185.164.73.143:3000',
    storageState: '.auth/buyer.json',
  });
  const buyer = await buyerCtx.newPage();

  await buyer.goto('/support');
  await expect(buyer).not.toHaveURL(/\/login/);
  await buyer.fill('input[name="subject"]', subject);
  await buyer.fill('textarea[name="detail"]', 'تست خودکار reopen.');
  await Promise.all([
    buyer.waitForURL(/\/support\/[a-z0-9]+/i),
    buyer.click('form[action] button[type="submit"]'),
  ]);
  const ticketId = buyer.url().split('/support/')[1];
  created.push(`SupportTicket ${ticketId} (subject "${subject}")`);

  // Admin replies → answered
  const adminCtx = await browser.newContext({
    baseURL: 'http://185.164.73.143:3001',
    storageState: '.auth/admin.json',
  });
  const admin = await adminCtx.newPage();
  await admin.goto(`/admin-support/${ticketId}`);
  await expect(admin).not.toHaveURL(/\/login/);
  await admin.fill('textarea[name="body"]', 'پاسخ کارشناس تست.');
  await admin.click('button:has-text("ارسال پاسخ")');
  await expect(admin.locator('text=پاسخ‌داده‌شده').first()).toBeVisible({ timeout: 15_000 });

  // Buyer adds a message → status flips to open again
  await buyer.goto(`/support/${ticketId}`);
  await expect(buyer).not.toHaveURL(/\/login/);
  await buyer.fill('textarea[name="body"]', 'پاسخ کاربر برای تست بازگشت به باز.');
  await buyer.click('button:has-text("ارسال پیام")');
  await expect(buyer.locator('text=باز').first()).toBeVisible({ timeout: 15_000 });

  await adminCtx.close();
  await buyerCtx.close();
});
