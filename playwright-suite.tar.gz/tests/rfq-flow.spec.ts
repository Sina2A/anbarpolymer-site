import { test, expect } from '@playwright/test';
import { TEST_WAREHOUSE_ID, TEST_STOCK_ID, TEST_GRADE_CODE } from './helpers/testWarehouse';

const PLACEHOLDER = TEST_WAREHOUSE_ID.startsWith('FILL_ME');

const created: string[] = [];

test.skip(PLACEHOLDER, 'test warehouse IDs not filled in — Sina must provision via SSH/psql first');

// NOTE (verified against re-synced source, 2026-09-05): the earlier warehouseId/id
// FK mismatch is FIXED. src/app/rfq/page.tsx now sends `warehouseId: s.id` (the
// WarehouseStock id) and src/app/rfq/actions.ts resolves OrderItem.warehouseId from
// `stock.warehouseId`. RFQ submissions no longer fail with a Foreign Key error.

async function addTestWarehouseRow(page: import('@playwright/test').Page) {
  // Locate the isolated test row via TEST_GRADE_CODE (latin, ZWNJ-safe).
  // Row structure in RfqCart: <div> with <b monospace>{gradeCode}</b> + "افزودن" button.
  const byGrade = page.locator('div').filter({ hasText: TEST_GRADE_CODE });
  const rowCount = await byGrade.count();
  console.log(`[debug /rfq] rows matching ${TEST_GRADE_CODE}: ${rowCount}`);
  if (rowCount === 0) {
    console.log(`[debug /rfq] page text (first 2000 chars):\n${(await page.content()).slice(0, 2000)}`);
  }
  const row = byGrade.filter({ has: page.locator('button:has-text("افزودن")') }).first();
  await row.waitFor({ timeout: 10_000 });
  await row.locator('button:has-text("افزودن")').click();
}

async function bumpQtyInCart(page: import('@playwright/test').Page, times: number) {
  const cartRow = page.locator('div').filter({ has: page.locator('button:has-text("✕")') }).first();
  await cartRow.waitFor({ timeout: 5_000 });
  for (let i = 0; i < times; i++) {
    await cartRow.locator('button:has-text("+")').click();
  }
}

async function submitCart(page: import('@playwright/test').Page) {
  await Promise.all([
    page.waitForURL(/\/my-orders/),
    page.click('button:has-text("ثبت درخواست قیمت")'),
  ]);
}

async function findOurOrderInAdmin(admin: import('@playwright/test').Page) {
  // Disambiguate by the latin grade code (rendered inside the order card).
  const card = admin.locator('div').filter({ hasText: TEST_GRADE_CODE }).filter({ hasText: 'در انتظار قیمتگذاری' }).first();
  await card.waitFor({ timeout: 15_000 });
  const orderId = await card.locator('input[name="orderId"]').first().getAttribute('value');
  return { card, orderId: orderId! };
}

test('rfq scenario A: buyer submits → admin prices → buyer sees "priced"', async ({ browser }) => {
  const buyerCtx = await browser.newContext({
    baseURL: 'http://185.164.73.143:3000',
    storageState: '.auth/buyer.json',
  });
  const buyer = await buyerCtx.newPage();
  await buyer.goto('/rfq');
  await expect(buyer, 'buyer /rfq must not redirect to /login').not.toHaveURL(/\/login/);
  await addTestWarehouseRow(buyer);
  await bumpQtyInCart(buyer, 1); // quantity 2 (initial add = 1, plus one increment)
  await submitCart(buyer);
  await expect(buyer, 'buyer /my-orders must not redirect to /login').not.toHaveURL(/\/login/);
  // FK-regression guard: before the fix, submission blew up with a Foreign Key error
  // and this row never appeared.
  await expect(buyer.locator('text=در حال ثبت اولیه').first()).toBeVisible({ timeout: 15_000 });
  const myOrderHeader = await buyer.locator('text=/^سفارش #/').first().textContent();
  created.push(`Order via RFQ (priced scenario): header "${myOrderHeader?.trim()}"`);

  const adminCtx = await browser.newContext({
    baseURL: 'http://185.164.73.143:3001',
    storageState: '.auth/admin.json',
  });
  const admin = await adminCtx.newPage();
  await admin.goto('/admin-orders');
  await expect(admin, 'admin /admin-orders must not redirect to /login').not.toHaveURL(/\/login/);
  const { card, orderId } = await findOurOrderInAdmin(admin);
  // Fill pricing inputs — use positional selection (avoids Persian pattern pitfalls).
  const priceInputs = card.locator('input[type="number"]');
  const n = await priceInputs.count();
  expect(n, 'admin order card should show at least one price input').toBeGreaterThan(0);
  for (let i = 0; i < n; i++) {
    await priceInputs.nth(i).fill('999000000');
  }
  // Submit — ConfirmSubmitButton fires native confirm()
  admin.once('dialog', (d) => d.accept());
  await Promise.all([
    admin.waitForLoadState('networkidle'),
    card.locator('button:has-text("ثبت قیمتها و ارسال به مشتری")').click(),
  ]);

  // Buyer refreshes: status now priced
  await buyer.goto('/my-orders');
  await expect(buyer).not.toHaveURL(/\/login/);
  await expect(buyer.locator('text=در حال تعیین قیمت توسط کارشناس فروش').first()).toBeVisible({ timeout: 15_000 });

  await adminCtx.close();
  await buyerCtx.close();
});

test('rfq scenario B: buyer submits → admin rejects → stock returned, buyer sees rejected', async ({ browser }) => {
  const buyerCtx = await browser.newContext({
    baseURL: 'http://185.164.73.143:3000',
    storageState: '.auth/buyer.json',
  });
  const buyer = await buyerCtx.newPage();
  await buyer.goto('/rfq');
  await expect(buyer, 'buyer /rfq must not redirect to /login').not.toHaveURL(/\/login/);
  await addTestWarehouseRow(buyer);
  await submitCart(buyer);
  await expect(buyer, 'buyer /my-orders must not redirect to /login').not.toHaveURL(/\/login/);
  await expect(buyer.locator('text=در حال ثبت اولیه').first()).toBeVisible({ timeout: 15_000 });
  const myOrderHeader = await buyer.locator('text=/^سفارش #/').first().textContent();
  created.push(`Order via RFQ (reject scenario): header "${myOrderHeader?.trim()}"`);

  const adminCtx = await browser.newContext({
    baseURL: 'http://185.164.73.143:3001',
    storageState: '.auth/admin.json',
  });
  const admin = await adminCtx.newPage();
  await admin.goto('/admin-orders');
  await expect(admin, 'admin /admin-orders must not redirect to /login').not.toHaveURL(/\/login/);
  const { card } = await findOurOrderInAdmin(admin);
  admin.once('dialog', (d) => d.accept());
  await Promise.all([
    admin.waitForLoadState('networkidle'),
    card.locator('button:has-text("رد این سفارش")').click(),
  ]);

  await buyer.goto('/my-orders');
  await expect(buyer).not.toHaveURL(/\/login/);
  await expect(buyer.locator('text=رد شد').first()).toBeVisible({ timeout: 15_000 });

  await adminCtx.close();
  await buyerCtx.close();
});
