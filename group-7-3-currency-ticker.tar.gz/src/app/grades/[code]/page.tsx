import { notFound } from 'next/navigation'
import prisma from '@/lib/prisma'
import { SPEC_GROUPS, SPEC_FIELD_BY_KEY, parseSpecs } from '@/lib/gradeSpecs'
import { findSimilarGrades } from '@/lib/gradeMatch'
import CurrencyTicker from '@/components/CurrencyTicker'

export const dynamic = 'force-dynamic'

export default async function GradeDetailPage({
  params,
}: {
  params: Promise<{ code: string }>
}) {
  const { code } = await params
  const decoded = decodeURIComponent(code)

  const grade = await prisma.grade.findUnique({
    where: { code: decoded },
    include: { documents: { orderBy: { createdAt: 'desc' } } },
  })
  if (!grade || !grade.isActive) notFound()

  // specsJson → دسته‌بندی‌شده بر اساس SPEC_GROUPS
  const specs = parseSpecs(grade.specsJson)
  const specEntries = Object.entries(specs) // [key, value][]
  const groupedSpecs = SPEC_GROUPS.map((g) => ({
    group: g,
    fields: specEntries
      .filter(([k]) => SPEC_FIELD_BY_KEY[k]?.group === g.key)
      .map(([k, v]) => ({ field: SPEC_FIELD_BY_KEY[k], value: v })),
  })).filter((g) => g.fields.length > 0)

  // گریدهای مشابه
  const similar = await findSimilarGrades(grade.id, 6)

  // ۶.۱ — امتیاز معامله‌های این گرید: میانگین rating از Reviewهایی که
  // روی معامله‌های همین گرید ثبت شده‌اند (Review → Deal → MaterialListing → Grade).
  // فقط aggregate عددی — هیچ رکورد Userی به payload عمومی صفحه serialize نمی‌شه.
  const ratingAgg = await prisma.review.aggregate({
    _avg: { rating: true },
    _count: true,
    where: { deal: { materialListing: { gradeId: grade.id } } },
  })
  const ratingAvg = ratingAgg._avg.rating // null یعنی هنوز هیچ امتیازی ثبت نشده
  const ratingCount = ratingAgg._count
  const fullStars = ratingAvg != null ? Math.round(ratingAvg) : 0

  return (
    <>
      <CurrencyTicker />
      <div className="topbar">
        <div className="wrap">
          <span>پشتیبانی فروش شنبه تا چهارشنبه ۸:۳۰ تا ۱۷:۳۰</span>
          <a className="phone" href="tel:+982191234567">
            021-91234567
          </a>
        </div>
      </div>
      <header className="site-header">
        <div className="wrap">
          <a href="/" className="logo">
            <span className="dot"></span> انبار پلیمر
          </a>
          <nav className="main-nav">
            <a href="/">صفحه اصلی</a>
            <a href="/grades" className="active">
              گریدها
            </a>
            <a href="/rfq">استعلام قیمت</a>
            <a href="/reports">گزارش بازار</a>
            <a href="/services">خدمات سازمانی</a>
            <a href="/about">درباره ما</a>
            <a href="/contact">تماس با ما</a>
          </nav>
          <div className="header-actions">
            <a href="/login" className="acct-btn">
              ورود / ثبت‌نام
            </a>
          </div>
        </div>
      </header>

      <section>
        <div className="wrap">
          {/* مسیر */}
          <div style={breadcrumbStyle}>
            <a href="/grades">گریدها</a> &nbsp;/&nbsp; <span>{grade.code}</span>
          </div>

          {/* ---------- هدر ---------- */}
          <div style={headerCardStyle}>
            <div style={thumbWrapStyle}>
              {grade.imageUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={grade.imageUrl} alt={grade.code} style={thumbImgStyle} />
              ) : (
                <div style={thumbPlaceholderStyle}>بدون تصویر</div>
              )}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={codeStyle}>{grade.code}</div>
              <div style={producerStyle}>{grade.producer}</div>
              <div style={categoryBadgeStyle}>{grade.category}</div>
              {/* ۶.۱ — بلوک امتیاز: میانگین Reviewهای معامله‌های همین گرید */}
              <div style={ratingWrapStyle}>
                <span style={ratingStarsStyle} aria-label={`امتیاز ${ratingAvg != null ? Math.round(ratingAvg * 10) / 10 : 0} از ۵`}>
                  {[1, 2, 3, 4, 5].map((i) => (
                    <span key={i} style={{ color: i <= fullStars ? '#f6621b' : '#d8dde3' }}>
                      ★
                    </span>
                  ))}
                </span>
                {ratingCount > 0 && ratingAvg != null ? (
                  <span style={ratingTextStyle}>
                    {(Math.round(ratingAvg * 10) / 10).toLocaleString('fa-IR')} از ۵ —{' '}
                    {ratingCount.toLocaleString('fa-IR')} امتیاز ثبت‌شده از معامله‌های این گرید
                  </span>
                ) : (
                  <span style={ratingTextStyle}>هنوز امتیازی برای معامله‌های این گرید ثبت نشده است</span>
                )}
              </div>
              {grade.description && (
                <p style={descStyle}>{grade.description}</p>
              )}
              {grade.datasheetUrl && (
                <a
                  href={grade.datasheetUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-sm"
                  style={{ marginTop: 12, display: 'inline-block', textDecoration: 'none' }}
                >
                  دانلود دیتاشیت (PDF) ↗
                </a>
              )}
            </div>
          </div>

          {/* ---------- مشخصات کلیدی ---------- */}
          <h3 style={sectionTitleStyle}>مشخصات کلیدی</h3>
          <div style={keyGridStyle}>
            <KeyCell label="MFI" value={grade.mfi != null ? `${grade.mfi} g/10min` : '—'} sub={grade.mfiTestCondition || undefined} />
            <KeyCell label="چگالی" value={grade.density != null ? `${grade.density} g/cm³` : '—'} />
            <KeyCell label="کاربرد" value={grade.applicationType || '—'} />
            <KeyCell label="خانواده پلیمری" value={grade.polymerFamily || '—'} />
            <KeyCell label="کشور مبدا" value={grade.originCountry || '—'} />
            <KeyCell label="نوع بسته‌بندی" value={grade.packagingType || '—'} />
          </div>

          {/* ---------- مشخصات فنی تکمیلی ---------- */}
          {groupedSpecs.length > 0 ? (
            <>
              <h3 style={sectionTitleStyle}>مشخصات فنی تکمیلی</h3>
              {groupedSpecs.map(({ group, fields }) => (
                <div key={group.key} style={{ marginBottom: 20 }}>
                  <div style={groupLabelStyle}>{group.label}</div>
                  <table className="g-table">
                    <thead>
                      <tr>
                        <th>پارامتر</th>
                        <th>مقدار</th>
                        <th>واحد</th>
                        <th>استاندارد</th>
                      </tr>
                    </thead>
                    <tbody>
                      {fields.map(({ field, value }) => (
                        <tr key={field.key}>
                          <td>{field.label}</td>
                          <td style={{ fontWeight: 700, direction: 'ltr', textAlign: 'right' }}>{value}</td>
                          <td style={{ color: '#9199a3', fontSize: 12 }}>{field.unit || '—'}</td>
                          <td style={{ color: '#9199a3', fontSize: 11, fontFamily: 'monospace' }}>{field.standard}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ))}
            </>
          ) : (
            <div style={emptySpecsStyle}>برای این گرید مشخصات تکمیلی ثبت نشده است.</div>
          )}

          {/* ---------- اسناد فنی قابل دانلود ---------- */}
          {grade.documents.length > 0 && (
            <>
              <h3 style={sectionTitleStyle}>اسناد فنی</h3>
              <div style={docsGridStyle}>
                {grade.documents.map((doc) => (
                  <a
                    key={doc.id}
                    href={doc.fileUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    style={docCardStyle}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                      <span style={docIconStyle}>PDF</span>
                      <span style={docTypeBadgeStyle}>{DOC_TYPE_LABELS[doc.docType] ?? doc.docType}</span>
                    </div>
                    <div style={{ fontSize: 13, fontWeight: 700, color: '#1a1a2e' }}>{doc.title}</div>
                    <div style={{ fontSize: 10.5, color: '#9199a3', marginTop: 4, fontFamily: 'monospace' }}>
                      {new Date(doc.createdAt).toLocaleDateString('fa-IR')}
                    </div>
                  </a>
                ))}
              </div>
            </>
          )}

          {/* ---------- گریدهای مشابه ---------- */}
          {similar.length > 0 && (
            <>
              <h3 style={sectionTitleStyle}>گریدهای مشابه</h3>
              <p style={{ fontSize: 12, color: '#9199a3', marginBottom: 12 }}>
                بر اساس خانواده پلیمری، کاربرد، MFI و چگالی — پیشنهاد خودکار، نه توصیه‌ی خرید.
              </p>
              <div style={similarGridStyle}>
                {similar.map((g) => (
                  <a
                    key={g.id}
                    href={`/grades/${encodeURIComponent(g.code)}`}
                    style={similarCardStyle}
                  >
                    <div style={{ fontSize: 13, fontWeight: 800, color: '#1a1a2e' }}>{g.code}</div>
                    <div style={{ fontSize: 11, color: '#636b7a', marginTop: 2 }}>{g.producer}</div>
                    <div style={{ fontSize: 11, color: '#9199a3' }}>{g.category}</div>
                  </a>
                ))}
              </div>
            </>
          )}
        </div>
      </section>

      <footer className="site-footer">
        <div className="wrap">
          <div className="footer-cols">
            <div>
              <a href="/" className="logo" style={{ marginBottom: 14, display: 'flex' }}>
                <span className="dot"></span> انبار پلیمر
              </a>
              <p style={{ color: 'var(--ink-dim)', fontSize: 13, maxWidth: 280 }}>
                واردکننده و فروشنده مستقیم مواد اولیه پلیمری برای کارخانه‌های تولیدی سراسر کشور.
              </p>
            </div>
            <div>
              <h5>محصولات</h5>
              <ul>
                <li><a href="/grades">پلی‌پروپیلن</a></li>
                <li><a href="/grades">پلی‌اتیلن</a></li>
                <li><a href="/grades">پی‌وی‌سی</a></li>
                <li><a href="/grades">پلی‌اتیلن ترفتالات</a></li>
              </ul>
            </div>
            <div>
              <h5>خدمات</h5>
              <ul>
                <li><a href="/rfq">استعلام قیمت آنلاین</a></li>
                <li><a href="/services">فروش سازمانی</a></li>
                <li><a href="/services">ارسال و لجستیک</a></li>
                <li><a href="/reports">گزارش بازار</a></li>
              </ul>
            </div>
            <div>
              <h5>اطلاعات تماس</h5>
              <ul>
                <li>تهران، خیابان ولیعصر، پلاک ۱۲۴</li>
                <li>انبار یزد — شهرک صنعتی یزد</li>
                <li style={{ direction: 'ltr', textAlign: 'right' }}>021-91234567</li>
              </ul>
            </div>
          </div>
          <div className="footer-bottom">
            <span>انبار پلیمر © ۱۴۰۵ — تمام حقوق محفوظ است</span>
          </div>
        </div>
      </footer>
    </>
  )
}

function KeyCell({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div style={keyCellStyle}>
      <div style={keyLabelStyle}>{label}</div>
      <div style={keyValueStyle}>{value}</div>
      {sub && <div style={keySubStyle}>{sub}</div>}
    </div>
  )
}

// ---------- style objects ----------

const breadcrumbStyle: React.CSSProperties = {
  fontSize: 12,
  color: '#9199a3',
  marginBottom: 16,
}

const headerCardStyle: React.CSSProperties = {
  display: 'flex',
  flexWrap: 'wrap',
  gap: 24,
  padding: 20,
  border: '1px solid #e8eaef',
  borderRadius: 12,
  background: '#fff',
  marginBottom: 28,
}

const thumbWrapStyle: React.CSSProperties = {
  width: 220,
  height: 180,
  flexShrink: 0,
  background: '#f1f1f3',
  borderRadius: 10,
  overflow: 'hidden',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
}

const thumbImgStyle: React.CSSProperties = { width: '100%', height: '100%', objectFit: 'cover' }
const thumbPlaceholderStyle: React.CSSProperties = { color: '#a0a6b0', fontSize: 12 }

const codeStyle: React.CSSProperties = { fontSize: 22, fontWeight: 900, color: '#1a1a2e' }
const producerStyle: React.CSSProperties = { fontSize: 13, color: '#636b7a', marginTop: 4 }
const categoryBadgeStyle: React.CSSProperties = {
  display: 'inline-block',
  marginTop: 8,
  fontSize: 11,
  background: '#f1efe8',
  color: '#5a5340',
  borderRadius: 6,
  padding: '3px 10px',
}

// ۶.۱ — بلوک امتیاز
const ratingWrapStyle: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 8,
  marginTop: 10,
  flexWrap: 'wrap',
}
const ratingStarsStyle: React.CSSProperties = { fontSize: 14, letterSpacing: 1, lineHeight: 1, direction: 'ltr' }
const ratingTextStyle: React.CSSProperties = { fontSize: 11.5, color: '#6f7680' }

const descStyle: React.CSSProperties = {
  marginTop: 12,
  fontSize: 13,
  color: '#4f5560',
  lineHeight: 1.7,
  whiteSpace: 'pre-wrap',
}

const sectionTitleStyle: React.CSSProperties = {
  fontSize: 15,
  fontWeight: 800,
  color: '#1a1a2e',
  marginBottom: 12,
  marginTop: 8,
}

const keyGridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))',
  gap: 10,
  marginBottom: 28,
}

const keyCellStyle: React.CSSProperties = {
  padding: '12px 14px',
  border: '1px solid #eceff3',
  borderRadius: 10,
  background: '#f8f9fb',
}

const keyLabelStyle: React.CSSProperties = { fontSize: 10, color: '#9199a3', marginBottom: 4 }
const keyValueStyle: React.CSSProperties = { fontSize: 13, fontWeight: 700, color: '#1a1a2e' }
const keySubStyle: React.CSSProperties = { fontSize: 10, color: '#9199a3', marginTop: 2 }

const groupLabelStyle: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 700,
  color: '#e65716',
  marginBottom: 8,
}

const emptySpecsStyle: React.CSSProperties = {
  padding: 20,
  textAlign: 'center',
  color: '#9199a3',
  fontSize: 13,
  border: '1px dashed #d8dde3',
  borderRadius: 10,
  marginBottom: 28,
}

const similarGridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))',
  gap: 10,
}

const similarCardStyle: React.CSSProperties = {
  display: 'block',
  padding: '12px 14px',
  border: '1px solid #e8eaef',
  borderRadius: 10,
  background: '#fff',
  textDecoration: 'none',
}

// ۶.۳ — اسناد فنی قابل دانلود
const docsGridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))',
  gap: 10,
  marginBottom: 28,
}

const docCardStyle: React.CSSProperties = {
  display: 'block',
  padding: '12px 14px',
  border: '1px solid #e8eaef',
  borderRadius: 10,
  background: '#fff',
  textDecoration: 'none',
  transition: 'border-color .15s',
}

const docIconStyle: React.CSSProperties = {
  fontSize: 9,
  fontWeight: 800,
  color: '#fff',
  background: '#c0392b',
  borderRadius: 3,
  padding: '1px 4px',
  fontFamily: 'monospace',
  letterSpacing: 0.5,
}

const docTypeBadgeStyle: React.CSSProperties = {
  fontSize: 10,
  fontWeight: 700,
  color: '#1e357b',
  background: '#eef4fd',
  padding: '1px 6px',
  borderRadius: 4,
}

const DOC_TYPE_LABELS: Record<string, string> = {
  tds: 'TDS',
  sds: 'SDS',
  coa: 'COA',
  certificate: 'گواهی',
  other: 'سایر',
}
