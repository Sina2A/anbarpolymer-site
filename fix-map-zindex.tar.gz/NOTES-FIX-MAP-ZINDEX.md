# رفعِ سه موردِ نقشه: z-index، چشمکِ پین‌ها، پررنگیِ مرز

## ترتیبِ نصب
این بسته باید **بعد از `orange-border-blinking-pins`** (و آن هم بعد از `limit-zoom-out-iran`)
نصب شود. فایل‌های این بسته روی همان نسخه ساخته شده‌اند.

---

## ۱) نقشه روی هدر و منوی موبایل می‌افتاد — مهارِ z-index
### علت
`leaflet.css` به `.leaflet-pane` تا `z-index:400` و به کنترل‌ها
(`.leaflet-top`/`.leaflet-bottom` = دکمه‌های زوم و Attribution) تا `z-index:1000` می‌دهد.
کانتینرِ نقشه stacking context مستقل نداشت، پس این مقادیر در ریشه با این‌ها رقابت می‌کردند:

| المان | z-index |
|---|---|
| هدر sticky (PanelHeader/PublicHeader و هدر نارنجی) | 50 |
| `.mobile-bottom-nav-wrap` | 40 |
| `.mobile-sheet-scrim` | 41 |
| `.mobile-sheet` (MoreSheet) | 42 |
| `.leaflet-pane` | **400** |
| `.leaflet-top/.leaflet-bottom` (زوم/attribution) | **1000** |

### راه‌حل (globals.css)
```css
.leaflet-container { position: relative; z-index: 0; isolation: isolate; }
```
`isolation:isolate` یک stacking context بسته می‌سازد؛ همه‌ی z-indexهای داخلیِ Leaflet نسبت
به همین کانتینر محبوس می‌شوند و کلِ نقشه با z-index مؤثرِ `0` زیرِ هدر (50) و کلِ ناوبریِ
موبایل (40–42) قرار می‌گیرد. چون قانون روی خودِ `.leaflet-container` است، هر سه نقشه
(Warehouses/LocationPicker/Transport) را یک‌جا پوشش می‌دهد. popup و دکمه‌های زوم چون داخلِ
همین بافت‌اند دست‌نخورده کار می‌کنند.

---

## ۲) پین‌ها چشمک نمی‌زدند — `className` به‌جای `pathOptions.className`
### علت (از سورسِ react-leaflet 5 + Leaflet 1.9.4)
`CircleMarker` هنگام ساخت فقط `{center, children, ...options}` را به سازنده‌ی Leaflet می‌دهد؛
`className` فقط اگر جزوِ همان `options`ِ سازنده باشد در `_initPath` روی المانِ SVG می‌نشیند.
ولی `pathOptions` بعداً با `setStyle` اعمال می‌شود و `setStyle` رنگ/ضخامت را عوض می‌کند اما
`className` را روی DOM نمی‌گذارد. پس `className` داخلِ `pathOptions` بی‌اثر بود
(خروجی: `<path class="leaflet-interactive" fill="#00D4FF">` بدونِ `blink-pin`).

### راه‌حل
روی هر ۴ `CircleMarker` (Warehouses ۱، Transport ۱، LocationPicker ۲: markers + selected)،
`className="blink-pin"` به‌صورتِ **propِ مستقیم** داده شد و از `pathOptions` برداشته شد؛ بقیه‌ی
`color/weight/fillColor/fillOpacity` همان‌جا در `pathOptions` ماندند. `className` propِ typed
معتبر است (`CircleMarkerProps extends CircleMarkerOptions → PathOptions.className`).
خروجی حالا: `class="leaflet-interactive blink-pin"`. CSSِ `@keyframes pinBlink` و `.blink-pin`
در `globals.css` دست‌نخورده است.

---

## ۳) مرزِ نارنجی پررنگ‌تر و ۲۰٪ ضخیم‌تر (IranBorder.tsx)
```
- weight: 2,   opacity: 0.9
+ weight: 2.4, opacity: 1
```
`color`، `fill: false` و `interactive: false` دست‌نخورده (interactive:false تا مرز کلیکِ
انتخابِ موقعیت را نبلعد).

---

## فایل‌های این بسته
- `src/app/globals.css`                  ← ویرایش (قانونِ isolation روی .leaflet-container)
- `src/components/WarehousesMap.tsx`     ← ویرایش (className مستقیم)
- `src/components/TransportMap.tsx`      ← ویرایش (className مستقیم)
- `src/components/LocationPickerMap.tsx` ← ویرایش (className مستقیم × ۲)
- `src/components/IranBorder.tsx`        ← ویرایش (weight/opacity)

## راستی‌آزمایی
- `npx tsc --noEmit` → بدونِ خطا (EXIT=0).
- `npx next build`  → `✓ Compiled successfully` (EXIT=0).
- تستِ بصری روی سرورِ واقعی طبقِ توافق.
