'use client'

// نقشه‌ی انبارها — Leaflet + OpenStreetMap (کاشی‌های OSM: نام شهر/جاده رایگان و قانونی).
// همان الگوی TransportMap: dynamic import با ssr:false، گیتِ mounted.
// leaflet.css به‌صورت سراسری در layout.tsx بارگذاری می‌شود (لازم برای جای‌گیری کاشی‌ها).
// از CircleMarker (SVG) استفاده می‌شود تا پین‌ها بدون آیکن/CSS همیشه دیده شوند.
// امضای prop قبلی ({ warehouses, height }) عیناً حفظ شده تا /warehouses بدون تغییر کار کند.

import { useEffect, useState } from 'react'
import dynamic from 'next/dynamic'
import { colors } from '@/lib/styles/tokens'

// Leaflet فقط در کلاینت کار می‌کنه — SSR ندارد.
const MapContainer = dynamic(() => import('react-leaflet').then((m) => m.MapContainer), { ssr: false })
const TileLayer = dynamic(() => import('react-leaflet').then((m) => m.TileLayer), { ssr: false })
const CircleMarker = dynamic(() => import('react-leaflet').then((m) => m.CircleMarker), { ssr: false })
const Popup = dynamic(() => import('react-leaflet').then((m) => m.Popup), { ssr: false })
// کنترلِ Attribution دستی با prefix=false → حذفِ برند/پرچمِ پیش‌فرضِ Leaflet (که SVGِ پرچم داخلش است)،
// بدون حذفِ متنِ واقعیِ منبع (© OpenStreetMap) که از خودِ TileLayer می‌آید.
const AttributionControl = dynamic(() => import('react-leaflet').then((m) => m.AttributionControl), { ssr: false })
// کنترلرِ محدوده — minZoomِ پویا (کلِ ایران جا شود) + قفلِ pan روی ایران. useMap هوک است ⇒ client-only.
const MapBoundsController = dynamic(() => import('./MapBoundsController'), { ssr: false })
// لایه‌ی مرزِ نارنجیِ ایران (ADM0) بالای کاشی‌ها.
const IranBorder = dynamic(() => import('./IranBorder'), { ssr: false })

type Warehouse = {
  id: string
  name: string
  city: string
  latitude: number | null
  longitude: number | null
  address: string | null
  description: string | null
}

// مرکز تقریبی ایران برای حالتی که میانگین محاسبه نشود.
const IRAN_CENTER: [number, number] = [32.4, 53.6]
// رنگِ پین‌ها — آبی فسفریِ پررهنگ، هماهنگ با انیمیشنِ .blink-pin در globals.css.
const PIN_COLOR = '#00D4FF'

export default function WarehousesMap({
  warehouses,
  height = 420,
}: {
  warehouses: Warehouse[]
  height?: number
}) {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const withLocation = warehouses.filter((w) => w.latitude != null && w.longitude != null)

  if (withLocation.length === 0) {
    return <div style={emptyStyle}>هیچ انباری با موقعیت جغرافیایی ثبت‌شده وجود ندارد.</div>
  }

  if (!mounted) {
    return <div style={{ ...loadingStyle, height }}>در حال بارگذاری نقشه…</div>
  }

  // مرکز نقشه — میانگین موقعیت‌ها (مثل TransportMap).
  const centerLat = withLocation.reduce((sum, w) => sum + (w.latitude as number), 0) / withLocation.length
  const centerLng = withLocation.reduce((sum, w) => sum + (w.longitude as number), 0) / withLocation.length
  const center: [number, number] =
    Number.isFinite(centerLat) && Number.isFinite(centerLng) ? [centerLat, centerLng] : IRAN_CENTER
  const zoom = withLocation.length === 1 ? 11 : 5

  return (
    <div style={{ ...wrapStyle, height }}>
      <MapContainer
        center={center}
        zoom={zoom}
        style={{ width: '100%', height: '100%' }}
        attributionControl={false}
        maxBoundsViscosity={1.0}
      >
        {/* minZoomِ پویا + maxBounds روی ایران (قفلِ pan). باید فرزندِ نقشه باشد چون useMap دارد. */}
        <MapBoundsController />
        <AttributionControl prefix={false} />
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {/* مرزِ نارنجیِ ایران — قبل از پین‌ها تا پین‌ها رویش دیده شوند. */}
        <IranBorder />
        {withLocation.map((w) => (
          <CircleMarker
            key={w.id}
            center={[w.latitude as number, w.longitude as number]}
            radius={6}
            // className باید propِ مستقیم باشد: react-leaflet فقط options سازنده را className‌دار
            // می‌کند (در _initPath)، ولی pathOptions با setStyle اعمال می‌شود و className را روی DOM نمی‌نشاند.
            className="blink-pin"
            pathOptions={{ color: '#fff', weight: 1.5, fillColor: PIN_COLOR, fillOpacity: 1 }}
          >
            <Popup>
              <div style={{ fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl', fontSize: 12 }}>
                <div style={{ fontWeight: 700, marginBottom: 4 }}>{w.name}</div>
                <div style={{ fontSize: 11, color: '#6b7280' }}>{w.city}</div>
                {w.address && (
                  <div style={{ fontSize: 11, color: '#6b7280', marginTop: 4 }}>{w.address}</div>
                )}
              </div>
            </Popup>
          </CircleMarker>
        ))}
      </MapContainer>
    </div>
  )
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const wrapStyle: React.CSSProperties = {
  position: 'relative',
  width: '100%',
  borderRadius: 12,
  overflow: 'hidden',
  border: `1px solid ${colors.borderStrong}`,
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
  background: '#f7f8fa',
  boxSizing: 'border-box',
}
const loadingStyle: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: 13,
  color: '#6f7680',
  border: '1px solid #d8dde3',
  borderRadius: 12,
  background: '#fff',
}
const emptyStyle: React.CSSProperties = {
  padding: '40px 20px',
  textAlign: 'center',
  fontSize: 13,
  color: '#6b7280',
  border: '1px solid #d8dde3',
  borderRadius: 12,
  background: '#fff',
}
