'use client'

// لایه‌ی روکشِ مرزِ ایران — فرزندِ <MapContainer>.
// کاشی‌های OSM تصویرِ رستری‌اند و رنگِ مرزِ داخلشان قابل‌تغییر نیست؛ پس مرزِ بیرونیِ
// کشور را به‌صورت یک لایه‌ی برداریِ جدا (L.geoJSON از react-leaflet) بالای TileLayer
// می‌کشیم و با رنگِ نارنجیِ برند (colors.orange) استایل می‌دهیم.
// داده: فقط سطحِ کشور (ADM0) — یک MultiPolygon، بدونِ جزئیاتِ استان/شهرستان — از
// geoBoundaries IRN ADM0 که به src/data/iran-adm0.json کپی شده و مستقیم import می‌شود
// (resolveJsonModule فعال است؛ یک‌بار در باندلِ مشترک بینِ سه نقشه).
// این ماژول react-leaflet را static ایمپورت می‌کند و امن است چون فقط client-only لود می‌شود:
// LocationPickerMap آن را static می‌آورد (خودش با dynamic ssr:false لود می‌شود) و
// WarehousesMap/TransportMap با dynamic(ssr:false).

import { GeoJSON } from 'react-leaflet'
import type { GeoJsonObject } from 'geojson'
import { colors } from '@/lib/styles/tokens'
import iranAdm0 from '@/data/iran-adm0.json'

// JSON با resolveJsonModule نوعِ `type: string` می‌گیرد که با union literalِ GeoJsonObject
// سازگار نیست؛ کست به‌صورتِ استاندارد از طریقِ unknown.
const IRAN_ADM0 = iranAdm0 as unknown as GeoJsonObject

export default function IranBorder() {
  return (
    <GeoJSON
      data={IRAN_ADM0}
      // fill:false → داخلِ کشور پر نمی‌شود (پاپ‌آپ/دید مسدود نمی‌شود).
      // interactive:false → لایه کلیک را نمی‌بلعد؛ حیاتی برای انتخابِ نقطه در LocationPicker.
      style={{ color: colors.orange, weight: 2.4, opacity: 1, fill: false, interactive: false }}
    />
  )
}
