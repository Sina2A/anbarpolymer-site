import prisma from './prisma'

export type PasswordPolicySettings = {
  minLength: number
  requireNumber: boolean
  requireUppercase: boolean
  requireSpecialChar: boolean
  expiryDays: number | null
}

const DEFAULTS: PasswordPolicySettings = {
  minLength: 8,
  requireNumber: false,
  requireUppercase: false,
  requireSpecialChar: false,
  expiryDays: null,
}

/** اگه هنوز هیچ تنظیمی ثبت نشده، همون پیش‌فرض قبلی سایت (حداقل ۸ کاراکتر) رو برمی‌گردونه. */
export async function getPasswordPolicy(): Promise<PasswordPolicySettings> {
  const row = await prisma.passwordPolicy.findUnique({ where: { id: 'singleton' } })
  if (!row) return DEFAULTS
  return {
    minLength: row.minLength,
    requireNumber: row.requireNumber,
    requireUppercase: row.requireUppercase,
    requireSpecialChar: row.requireSpecialChar,
    expiryDays: row.expiryDays,
  }
}

export async function updatePasswordPolicy(settings: PasswordPolicySettings, updatedById: string) {
  await prisma.passwordPolicy.upsert({
    where: { id: 'singleton' },
    update: { ...settings, updatedById },
    create: { id: 'singleton', ...settings, updatedById },
  })
}

/** بررسی یه رمز پیشنهادی در برابر سیاست فعلی — پیام‌های فارسیِ آماده برای نمایش مستقیم. */
export function validatePassword(password: string, policy: PasswordPolicySettings): { valid: boolean; errors: string[] } {
  const errors: string[] = []

  if (password.length < policy.minLength) {
    errors.push(`رمز عبور باید حداقل ${policy.minLength} کاراکتر باشه.`)
  }
  if (policy.requireNumber && !/[0-9]/.test(password)) {
    errors.push('رمز عبور باید حداقل یک عدد داشته باشه.')
  }
  if (policy.requireUppercase && !/[A-Z]/.test(password)) {
    errors.push('رمز عبور باید حداقل یک حرف بزرگ انگلیسی داشته باشه.')
  }
  if (policy.requireSpecialChar && !/[^A-Za-z0-9]/.test(password)) {
    errors.push('رمز عبور باید حداقل یک نویسه‌ی خاص (مثل ! @ # $) داشته باشه.')
  }

  return { valid: errors.length === 0, errors }
}

/** آیا رمز کاربر طبق سیاست فعلی منقضی شده؟ (اگه expiryDays تنظیم نشده، هیچ‌وقت منقضی نمی‌شه) */
export function isPasswordExpired(passwordChangedAt: Date | null, policy: PasswordPolicySettings): boolean {
  if (!policy.expiryDays) return false
  if (!passwordChangedAt) return false // رمزهای قدیمی‌تر از اضافه‌شدن این قابلیت، عمداً مجبور به تغییر نمی‌شن
  const ageDays = (Date.now() - passwordChangedAt.getTime()) / (1000 * 60 * 60 * 24)
  return ageDays > policy.expiryDays
}
