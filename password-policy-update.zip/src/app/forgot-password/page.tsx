import ForgotPasswordForm from './ForgotPasswordForm'

export default async function ForgotPasswordPage({ searchParams }: { searchParams: Promise<{ phone?: string; reason?: string }> }) {
  const { phone, reason } = await searchParams
  const isExpired = reason === 'expired'

  return (
    <div style={pageStyle}>
      <div style={cardStyle}>
        <h1 style={{ fontSize: 18, fontWeight: 800, marginBottom: 6 }}>فراموشی رمز عبور</h1>
        {isExpired ? (
          <div style={{ background: '#fef3c7', color: '#92400e', borderRadius: 8, padding: '10px 14px', fontSize: 12.5, fontWeight: 600, marginBottom: 16 }}>
            ⏱ رمز عبور شما طبق سیاست امنیتی سایت منقضی شده — برای ادامه، یه رمز جدید تنظیم کن.
          </div>
        ) : (
          <p style={{ fontSize: 13, color: '#6f7680', marginBottom: 20 }}>
            شماره موبایلت رو وارد کن تا کد بازیابی برات پیامک بشه.
          </p>
        )}
        <ForgotPasswordForm initialPhone={phone || ''} />
      </div>
    </div>
  )
}

const pageStyle: React.CSSProperties = { minHeight: '100vh', background: '#faf8f4', padding: '32px 20px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl' }
const cardStyle: React.CSSProperties = { maxWidth: 420, margin: '0 auto', background: '#fff', border: '1px solid #d8dde3', borderRadius: 14, padding: '24px 20px' }
