'use server'

import prisma from '@/lib/prisma'
import { verifyPassword, createSession } from '@/lib/auth'
import { logAudit, logError } from '@/lib/logger'
import { getPasswordPolicy, isPasswordExpired } from '@/lib/passwordPolicy'
import { redirect } from 'next/navigation'

export async function loginAction(prevState: { error: string }, formData: FormData) {
  const identifier = String(formData.get('identifier') || '').trim()
  const password = String(formData.get('password') || '')

  if (!identifier || !password) {
    return { error: 'نام کاربری/شماره تماس و رمز عبور رو وارد کن.' }
  }

  // کاربر می‌تونه با username (کارشناس/مدیر) یا phone (خریدار) وارد بشه
  const user = await prisma.user.findFirst({
    where: { OR: [{ username: identifier }, { phone: identifier }] },
  })

  if (!user || !user.isActive) {
    await logError('auth', 'تلاش ورود ناموفق — کاربر پیدا نشد یا غیرفعاله', { identifier })
    return { error: 'نام کاربری یا رمز عبور اشتباهه.' }
  }

  const passwordOk = verifyPassword(password, user.passwordHash)
  if (!passwordOk) {
    await logError('auth', 'تلاش ورود ناموفق — رمز عبور اشتباه', { identifier }, user.id)
    return { error: 'نام کاربری یا رمز عبور اشتباهه.' }
  }

  // دروازه‌ی تایید شماره — فقط برای خریدارهایی که با phone ثبت‌نام کردن
  // (کارشناس/مدیر با username وارد می‌شن، این چک شاملشون نمی‌شه).
  if (user.role === 'buyer' && user.phone && !user.phoneVerified) {
    await logAudit('auth', 'ورود مسدود شد — شماره هنوز تایید نشده', user.id)
    redirect(`/verify-phone?phone=${encodeURIComponent(user.phone)}`)
  }

  // دروازه‌ی انقضای رمز عبور — فقط اگه مدیر توی تنظیمات سیاست رمز عبور
  // expiryDays رو فعال کرده باشه (پیش‌فرض: هیچ‌وقت منقضی نمی‌شه).
  // کاربرهایی که username دارن (نه phone) رو هم شامل می‌شه، چون این دروازه
  // ربطی به روش ورود نداره، فقط به قدمت رمزشونه.
  const policy = await getPasswordPolicy()
  if (isPasswordExpired(user.passwordChangedAt, policy)) {
    await logAudit('auth', 'ورود مسدود شد — رمز عبور منقضی شده', user.id)
    if (user.phone) {
      redirect(`/forgot-password?phone=${encodeURIComponent(user.phone)}&reason=expired`)
    }
    return { error: 'رمز عبور شما منقضی شده — برای بازیابی با مدیر سیستم تماس بگیر (چون حساب شما شماره‌موبایل ثبت‌شده نداره).' }
  }

  await createSession(user.id)
  await logAudit('auth', 'ورود موفق', user.id, { role: user.role })

  // توجه: /dashboard هنوز واقعی نیست (dashboard.html استاتیکه) — قبلاً این
  // خط مستقیم به /dashboard می‌فرستاد که یعنی خریدارها بعد از ورود موفق به
  // ۴۰۴ می‌خوردن. فعلاً به /my-orders (که واقعیه) می‌فرستیم؛ هروقت
  // dashboard.html مهاجرت کرد، این خط رو برگردون.
  redirect(user.role === 'buyer' ? '/my-orders' : '/admin-users')
}
