#!/bin/bash
# پاکسازی بقایای بی‌فایده که حین بررسی «زیپ انتقال سرور» پیدا شدن.
# روی سرور جدید (anbarpolymer-app) اجرا کن، بعد از این‌که مطمئن شدی سایت
# سالم کار می‌کنه. همه‌ی این‌ها بی‌خطرن — نه کد واقعی سایت، نه دیتا.

set -e
cd /var/www/anbarpolymer-app

echo "== حذف پوشه‌های ابزارهای هوش‌مصنوعی دیگر (Windsurf/Claude Code/Agents) =="
echo "   این‌ها فقط مستندات Prisma بودن، نه کد واقعی — احتمالاً از یه آزمایش قبلی مونده"
rm -rf .agents .claude .windsurf

echo "== حذف زیپ‌های خالی/قدیمی دیپلوی =="
rm -f admin-users-code.zip api-settings.zip

echo "== حذف فایل‌های استاتیک جا‌مونده (باید توی سایت استاتیک باشن، نه اینجا) =="
rm -f my-material-listings.html priority-list-updated.html

echo "== تایید نهایی — این‌ها باید همه ناپدید شده باشن =="
ls -la .agents .claude .windsurf admin-users-code.zip api-settings.zip my-material-listings.html priority-list-updated.html 2>&1 | grep "No such file" && echo "✅ پاکسازی موفق بود" || echo "⚠️ یه چیزی هنوز هست، بالا رو چک کن"

echo ""
echo "== وضعیت گیت بعد از پاکسازی =="
git status --short
