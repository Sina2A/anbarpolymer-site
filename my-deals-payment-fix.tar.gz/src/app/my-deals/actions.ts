'use server'

import prisma from '@/lib/prisma'
import { revalidatePath } from 'next/cache'
import { getCurrentUser } from '@/lib/currentUser'
import { startBuyerPaymentDeadline } from '@/lib/dealDeadlines'
import { savePaymentReceipt } from '@/lib/paymentReceipt'
import { submitDiscrepancyReport } from '@/lib/disputes'
import { logAudit } from '@/lib/logger'

/**
 * کنش‌های سمت سرور پنل «معاملات من».
 * دو طرف معامله از روی خود رکورد Deal تشخیص داده می‌شن:
 *   خریدار  = deal.buyerId
 *   فروشنده = deal.materialListing.userId
 * همه‌ی چک‌های دسترسی همین‌جا و مستقل از UI انجام می‌شن.
 */

/** وضعیت‌هایی که معامله (قبل از بارگیری) قابل لغو دستی‌ست */
const CANCELABLE_STATUSES = ['draft', 'awaiting_approval', 'confirmed', 'seller_fee_paid']

/**
 * فروشنده، پیشنهادِ پیش‌نویس یک خریدار رو می‌پذیره. بعد از پذیرش، مهلت
 * پرداخت خریدار شروع می‌شه؛ اگه قیمت توافقی نیاز به تایید کارشناس داشته
 * باشه، startBuyerPaymentDeadline خودش وضعیت رو روی awaiting_approval می‌ذاره.
 */
export async function acceptDealOfferAction(dealId: string) {
  const user = await getCurrentUser()

  const deal = await prisma.deal.findUnique({
    where: { id: dealId },
    include: { materialListing: true },
  })
  if (!deal || !deal.materialListing) throw new Error('معامله پیدا نشد.')
  if (deal.status !== 'draft') throw new Error('این پیشنهاد دیگر در وضعیت پذیرش نیست.')
  if (user.id !== deal.materialListing.userId) throw new Error('فقط فروشنده‌ی آگهی می‌تونه پیشنهاد رو بپذیره.')

  // در هر دو حالت (قیمت‌دار / بدون قیمت) همین تابع وضعیت و مهلت رو می‌چینه
  await startBuyerPaymentDeadline(dealId, false)

  await logAudit('deal', 'قبول پیشنهاد', user.id, { dealId, action: 'offer_accepted' })
  revalidatePath('/my-deals')
}

/**
 * فروشنده، پیشنهادِ پیش‌نویس رو رد می‌کنه: معامله لغو و آگهی دوباره فعال می‌شه.
 */
export async function rejectDealOfferAction(dealId: string) {
  const user = await getCurrentUser()

  const deal = await prisma.deal.findUnique({
    where: { id: dealId },
    include: { materialListing: true },
  })
  if (!deal || !deal.materialListing) throw new Error('معامله پیدا نشد.')
  if (deal.status !== 'draft') throw new Error('این پیشنهاد دیگر در وضعیت پذیرش نیست.')
  if (user.id !== deal.materialListing.userId) throw new Error('فقط فروشنده‌ی آگهی می‌تونه پیشنهاد رو رد کنه.')

  await prisma.deal.update({ where: { id: dealId }, data: { status: 'cancelled' } })
  if (deal.materialListingId) {
    await prisma.materialListing.update({
      where: { id: deal.materialListingId },
      data: { validityStatus: 'active' },
    })
  }

  await logAudit('deal', 'رد پیشنهاد', user.id, { dealId, action: 'offer_rejected' })
  revalidatePath('/my-deals')
}

/**
 * هر طرف رسید پرداخت خودش رو آپلود می‌کنه — بسته به kind:
 *   BUYER_GOODS  → خریدار (deal.buyerId)، بهای بار
 *   SELLER_FEE   → فروشنده (deal.sellerId)، کارمزد معامله
 * گیت روی خودِ ردیف DealPayment است (نه status معامله): فقط وقتی هنوز
 * رسیدی روی اون ردیف ثبت نشده. رسید روی همون ردیف نوشته می‌شه، نه فیلد
 * قدیمی Deal.paymentReceiptUrl. تایید نهایی با ادمین است (approvePaymentAction).
 */
export async function uploadDealPaymentReceiptAction(formData: FormData) {
  const dealId = String(formData.get('dealId') || '')
  const kind = String(formData.get('kind') || '')
  const file = formData.get('receiptFile') as File | null

  const user = await getCurrentUser()
  if (!dealId || !file || file.size === 0) return
  if (kind !== 'BUYER_GOODS' && kind !== 'SELLER_FEE') throw new Error('نوع پرداخت نامعتبر است.')

  const deal = await prisma.deal.findUnique({ where: { id: dealId } })
  if (!deal) throw new Error('معامله پیدا نشد.')

  // نقش مجاز بر اساس kind تعیین می‌شه؛ طرفِ دیگه (یا کاربر ثالث) نمی‌تونه رسید طرف مقابل رو ثبت کنه.
  const payerId = kind === 'BUYER_GOODS' ? deal.buyerId : deal.sellerId
  if (!payerId || user.id !== payerId) {
    throw new Error(
      kind === 'BUYER_GOODS'
        ? 'فقط خریدار می‌تونه رسید پرداخت بها رو ثبت کنه.'
        : 'فقط فروشنده می‌تونه رسید کارمزد رو ثبت کنه.',
    )
  }

  const payment = await prisma.dealPayment.findUnique({
    where: { dealId_kind: { dealId, kind } },
  })
  if (!payment) throw new Error('ردیف پرداخت این معامله پیدا نشد.')
  if (payment.receiptUrl) throw new Error('رسید این پرداخت قبلاً ثبت شده.')

  const url = await savePaymentReceipt(file)

  // نوشتن race-safe/idempotent روی همون ردیف: فقط اگه هنوز رسیدی نداشته باشه.
  const res = await prisma.dealPayment.updateMany({
    where: { dealId, kind, receiptUrl: null },
    data: { receiptUrl: url, submittedAt: new Date(), status: 'SUBMITTED' },
  })
  if (res.count === 0) throw new Error('در وضعیت جاری امکان ثبت رسید پرداخت وجود ندارد.')

  await logAudit('deal', 'ثبت رسید پرداخت', user.id, {
    dealId,
    action: 'payment_receipt_uploaded',
    kind,
  })
  revalidatePath(`/my-deals/${dealId}`)
}

/**
 * خریدار، گزارش مغایرت کیفی رو توی پنجره‌ی مهلت اعلام می‌کنه. موارد انتخابی
 * از formData.getAll('items') گرفته می‌شن؛ submitDiscrepancyReport خودش حساس/جزئی
 * بودن رو تشخیص می‌ده و در صورت لزوم تایمر واریز رو فریز و Dispute باز می‌کنه.
 */
export async function reportDiscrepancyAction(formData: FormData) {
  const dealId = String(formData.get('dealId') || '')
  const note = String(formData.get('note') || '').trim()
  const selectedItems = formData.getAll('items').map((v) => String(v)).filter(Boolean)

  const user = await getCurrentUser()
  if (!dealId || selectedItems.length === 0) return

  const deal = await prisma.deal.findUnique({ where: { id: dealId } })
  if (!deal) throw new Error('معامله پیدا نشد.')
  if (user.id !== deal.buyerId) throw new Error('فقط خریدار می‌تونه مغایرت گزارش کنه.')

  await submitDiscrepancyReport({ dealId, raisedById: user.id, selectedItems, note })

  await logAudit('deal', 'ثبت گزارش مغایرت', user.id, { dealId, action: 'discrepancy_reported', count: selectedItems.length })
  revalidatePath(`/my-deals/${dealId}`)
}

/**
 * لغو دستی معامله — خریدار یا فروشنده، فقط تا پیش از مرحله‌ی بارگیری
 * (draft/awaiting_approval/confirmed/seller_fee_paid). آگهی دوباره فعال می‌شه.
 */
export async function cancelDealAction(formData: FormData) {
  const dealId = String(formData.get('dealId') || '')
  const reason = String(formData.get('reason') || '').trim()

  const user = await getCurrentUser()
  if (!dealId) return

  const deal = await prisma.deal.findUnique({
    where: { id: dealId },
    include: { materialListing: true },
  })
  if (!deal) throw new Error('معامله پیدا نشد.')

  const isBuyer = user.id === deal.buyerId
  const isSeller = Boolean(deal.materialListing && user.id === deal.materialListing.userId)
  if (!isBuyer && !isSeller) throw new Error('شما طرف این معامله نیستید.')
  if (!CANCELABLE_STATUSES.includes(deal.status)) throw new Error('این معامله در وضعیت جاری قابل لغو نیست.')

  await prisma.deal.update({ where: { id: dealId }, data: { status: 'cancelled' } })
  if (deal.materialListingId) {
    await prisma.materialListing.update({
      where: { id: deal.materialListingId },
      data: { validityStatus: 'active' },
    })
  }

  await logAudit('deal', 'لغو معامله', user.id, { dealId, action: 'deal_cancelled', reason: reason || null })
  revalidatePath('/my-deals')
  revalidatePath(`/my-deals/${dealId}`)
}
