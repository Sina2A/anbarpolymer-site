import { getCurrentUser } from '@/lib/currentUser'
import { getKycForUser } from '@/lib/kyc'
import { submitCompanyStepAction, submitProducerStepAction, submitBusinessProfileAction } from './actions'
import prisma from '@/lib/prisma'
import { colors, spacing, radius, fontSize } from '@/lib/styles/tokens'
import { cardStyle as sharedCardStyle, btnPrimaryStyle, inputStyle as sharedInputStyle } from '@/lib/styles/shared'

export const dynamic = 'force-dynamic'

const LEGAL_TYPES = [
  { value: 'factory', label: 'کارخانه / واحد تولیدی' },
  { value: 'production_unit', label: 'واحد تولیدی کوچک' },
  { value: 'trading_company', label: 'شرکت بازرگانی' },
  { value: 'cooperative', label: 'تعاونی' },
  { value: 'official_agent', label: 'نماینده‌ی رسمی' },
  { value: 'importer', label: 'واردکننده' },
  { value: 'exporter', label: 'صادرکننده' },
]

// گام ۳ — مقادیر ثابت چک‌باکس‌ها (هم‌خط با enum‌های schema)
const ACTIVITY_DOMAINS = [
  'Pipe', 'Film', 'Injection', 'Raffia', 'Sheet',
  'Blow Molding', 'Masterbatch', 'Compound', 'Recycling',
]

const PRODUCTS_USED = [
  'پلی‌پروپیلن (PP)', 'پلی‌اتیلن (PE)', 'پی‌وی‌سی (PVC)',
  'پلی‌اتیلن ترفتالات (PET)', 'پلی‌استایرن (PS)', 'ABS',
  'مستربچ', 'افزودنی‌ها', 'سایر',
]

const TARGET_MARKETS = [
  'ایران', 'عراق', 'افغانستان', 'ترکیه', 'پاکستان',
  'آسیای میانه', 'آفریقا', 'اروپا', 'سایر',
]

export default async function VerificationPage() {
  const user = await getCurrentUser()
  const company = await getKycForUser(user.id)
  const kyc = company?.kyc

  const level = kyc?.level ?? 0
  const step1Pending = kyc?.documentsSubmittedAt && level < 1
  const step2Pending = kyc?.producerDocumentsSubmittedAt && level < 2 && level >= 1

  // گام ۳ — پروفایل تجاری (فقط وقتی Company ساخته شده باشه)
  const bizProfile = company
    ? await prisma.businessProfile.findUnique({ where: { companyId: company.id } })
    : null

  return (
    <div style={pageStyle}>
      <div style={containerStyle}>
        <h1 style={{ fontSize: fontSize.xxl, fontWeight: 800, marginBottom: 6, color: colors.textPrimary }}>احراز هویت</h1>
        <p style={{ color: colors.textSecondary, fontSize: fontSize.md, marginBottom: 28, lineHeight: 1.9 }}>
          برای استفاده از همه‌ی امکانات سایت (دیدن قیمت دقیق، ارسال استعلام، خرید/فروش) باید مدارک هویتی رو تکمیل کنی.
          تا وقتی احراز نشده، فقط بخش عمومی (لیست گریدها، مقالات) رو می‌بینی.
        </p>

        <StatusBadge level={level} />

        {/* ---------- گام ۱: هویت شرکت ---------- */}
        <div style={cardStyle}>
          <h3 style={{ fontSize: fontSize.lg, marginBottom: 4, color: colors.textPrimary }}>گام ۱ — هویت شرکت</h3>
          <p style={{ fontSize: fontSize.sm, color: colors.textMuted, marginBottom: spacing.lg }}>
            برای دیدن قیمت‌های دقیق و ارسال استعلام لازمه. نیازی به آپلود مدرک نیست — فقط اطلاعات زیر رو دقیق وارد کن،
            کارشناس از طریق سامانه‌ی رسمی «روزنامه‌ی رسمی کشور» تطبیقش می‌ده.
          </p>

          {level >= 1 ? (
            <div style={{ background: colors.successBg, color: colors.successText, borderRadius: radius.md, padding: '10px 14px', fontSize: fontSize.base, fontWeight: 600 }}>
              ✓ تایید شده
            </div>
          ) : step1Pending ? (
            <div style={{ background: colors.warningBg, color: colors.warningText, borderRadius: radius.md, padding: '10px 14px', fontSize: fontSize.base, fontWeight: 600 }}>
              ⏳ اطلاعات ارسال شد، منتظر بررسی کارشناسه
            </div>
          ) : (
            <form action={submitCompanyStepAction} style={{ display: 'flex', flexDirection: 'column', gap: 12, marginTop: 10 }}>
              <input name="companyName" placeholder="نام کامل شرکت" defaultValue={company?.companyName} required style={inputStyle} />
              <select name="legalType" defaultValue={company?.legalType || 'factory'} style={inputStyle}>
                {LEGAL_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
              </select>
              <input name="nationalId" placeholder="شناسه‌ی ملی شرکت" defaultValue={company?.nationalId || ''} required style={inputStyle} />
              <input name="registrationNumber" placeholder="شماره‌ی ثبت" defaultValue={company?.registrationNumber || ''} required style={inputStyle} />
              <div style={{ display: 'flex', gap: 10 }}>
                <input name="province" placeholder="استان" defaultValue={company?.province || ''} required style={{ ...inputStyle, flex: 1 }} />
                <input name="city" placeholder="شهر" defaultValue={company?.city || ''} required style={{ ...inputStyle, flex: 1 }} />
              </div>
              <input name="address" placeholder="آدرس دقیق" defaultValue={company?.address || ''} required style={inputStyle} />

              <button type="submit" style={submitBtnStyle}>ارسال برای بررسی</button>
            </form>
          )}
        </div>

        {/* ---------- گام ۲: احراز تولیدکننده ---------- */}
        <div style={cardStyle}>
          <h3 style={{ fontSize: fontSize.lg, marginBottom: 4, color: colors.textPrimary }}>گام ۲ — احراز تولیدکننده</h3>
          <p style={{ fontSize: fontSize.sm, color: colors.textMuted, marginBottom: spacing.lg }}>فقط لازمه اگه می‌خوای توی سایت بار بفروشی (شبکه عرضه).</p>

          {level < 1 ? (
            <div style={{ background: colors.neutralBg, color: colors.textSecondary, borderRadius: radius.md, padding: '10px 14px', fontSize: fontSize.base }}>
              اول باید گام ۱ تایید بشه.
            </div>
          ) : level >= 2 ? (
            <div style={{ background: colors.successBg, color: colors.successText, borderRadius: radius.md, padding: '10px 14px', fontSize: fontSize.base, fontWeight: 600 }}>
              ✓ تولیدکننده‌ی تایید‌شده — می‌تونی توی شبکه عرضه بار ثبت کنی
            </div>
          ) : step2Pending ? (
            <div style={{ background: colors.warningBg, color: colors.warningText, borderRadius: radius.md, padding: '10px 14px', fontSize: fontSize.base, fontWeight: 600 }}>
              ⏳ مدارک ارسال شد، منتظر بررسی کارشناسه (تطبیق با سامانه‌ی بهین‌یاب)
            </div>
          ) : (
            <form action={submitProducerStepAction} style={{ display: 'flex', flexDirection: 'column', gap: 12, marginTop: 10 }}>
              <input name="productionLicenseNumber" placeholder="شماره‌ی پروانه‌ی بهره‌برداری" required style={inputStyle} />
              <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
                <input type="checkbox" name="productionLicenseIsSetup" />
                واحد هنوز در حال احداثه (به‌جاش جواز تاسیس دارم، نه پروانه‌ی نهایی)
              </label>
              <input name="factoryAddress" placeholder="آدرس دقیق کارخانه" required style={inputStyle} />
              <input name="factoryActivityType" placeholder="نوع فعالیت تولیدی" required style={inputStyle} />
              <textarea name="factoryProducts" placeholder="محصولات تولیدی" rows={3} style={{ ...inputStyle, fontFamily: 'inherit', resize: 'vertical' }} />

              <label style={fileLabelStyle}>
                تصویر پروانه‌ی بهره‌برداری (یا جواز تاسیس)
                <input type="file" name="licenseFile" accept=".pdf,image/*" required style={{ marginTop: 6 }} />
              </label>

              <button type="submit" style={submitBtnStyle}>ارسال برای بررسی</button>
            </form>
          )}
        </div>

        {/* ---------- گام ۳: پروفایل تجاری ---------- */}
        <div style={cardStyle}>
          <h3 style={{ fontSize: fontSize.lg, marginBottom: 4, color: colors.textPrimary }}>گام ۳ — پروفایل تجاری</h3>
          <p style={{ fontSize: fontSize.sm, color: colors.textMuted, marginBottom: spacing.lg }}>
            اطلاعات تجاری شرکت (حوزه فعالیت، ظرفیت، بازار هدف). اختیاریه ولی برای ویترین بهتر و اولویت در معامله‌ها پیشنهاد می‌شه.
          </p>

          {!company ? (
            <div style={{ background: colors.neutralBg, color: colors.textSecondary, borderRadius: radius.md, padding: '10px 14px', fontSize: fontSize.base }}>
              اول باید گام ۱ رو کامل کنی.
            </div>
          ) : (
            <form action={submitBusinessProfileAction} style={{ display: 'flex', flexDirection: 'column', gap: 14, marginTop: 10 }}>
              {/* نقش */}
              <label style={fieldLabelStyle}>نقش شرکت در بازار</label>
              <select name="role" defaultValue={bizProfile?.role || 'seller'} style={inputStyle}>
                <option value="seller">فروشنده / تولیدکننده</option>
                <option value="buyer">خریدار</option>
                <option value="both">هر دو</option>
              </select>

              {/* حوزه‌ی فعالیت — چک‌باکس‌های چندتایی */}
              <fieldset style={fieldsetStyle}>
                <legend style={fieldLabelStyle}>حوزه‌ی فعالیت (چند مورد انتخاب کن)</legend>
                <div style={checkboxGridStyle}>
                  {ACTIVITY_DOMAINS.map((d) => (
                    <label key={d} style={checkboxLabelStyle}>
                      <input type="checkbox" name="activityDomain" value={d} defaultChecked={bizProfile?.activityDomain?.includes(d)} />
                      {d}
                    </label>
                  ))}
                </div>
              </fieldset>

              {/* محصولات مصرفی — چک‌باکس‌های چندتایی */}
              <fieldset style={fieldsetStyle}>
                <legend style={fieldLabelStyle}>محصولات مصرفی (چند مورد انتخاب کن)</legend>
                <div style={checkboxGridStyle}>
                  {PRODUCTS_USED.map((p) => (
                    <label key={p} style={checkboxLabelStyle}>
                      <input type="checkbox" name="productsUsed" value={p} defaultChecked={bizProfile?.productsUsed?.includes(p)} />
                      {p}
                    </label>
                  ))}
                </div>
              </fieldset>

              {/* ظرفیت خرید */}
              <label style={fieldLabelStyle}>ظرفیت خرید ماهانه</label>
              <select name="purchaseCapacityTier" defaultValue={bizProfile?.purchaseCapacityTier || ''} style={inputStyle}>
                <option value="">انتخاب نشده</option>
                <option value="under_20t">زیر ۲۰ تن</option>
                <option value="20_100t">۲۰ تا ۱۰۰ تن</option>
                <option value="100_500t">۱۰۰ تا ۵۰۰ تن</option>
                <option value="over_500t">بالای ۵۰۰ تن</option>
              </select>

              {/* مصرف ماهانه */}
              <label style={fieldLabelStyle}>مصرف ماهانه (تن)</label>
              <input
                type="number"
                name="monthlyConsumptionTon"
                placeholder="مثلاً ۵۰"
                defaultValue={bizProfile?.monthlyConsumptionTon ?? ''}
                min={0}
                step="0.1"
                style={inputStyle}
              />

              {/* ظرفیت تولید سالانه */}
              <label style={fieldLabelStyle}>ظرفیت تولید سالانه (تن در سال)</label>
              <input
                type="number"
                name="productionCapacityTonPerYear"
                placeholder="مثلاً ۱۲۰۰"
                defaultValue={bizProfile?.productionCapacityTonPerYear ?? ''}
                min={0}
                step="1"
                style={inputStyle}
              />

              {/* بازار هدف — چک‌باکس‌های چندتایی */}
              <fieldset style={fieldsetStyle}>
                <legend style={fieldLabelStyle}>بازارهای هدف (چند مورد انتخاب کن)</legend>
                <div style={checkboxGridStyle}>
                  {TARGET_MARKETS.map((m) => (
                    <label key={m} style={checkboxLabelStyle}>
                      <input type="checkbox" name="targetMarkets" value={m} defaultChecked={bizProfile?.targetMarkets?.includes(m)} />
                      {m}
                    </label>
                  ))}
                </div>
              </fieldset>

              <button type="submit" style={submitBtnStyle}>ذخیره‌ی پروفایل تجاری</button>
              {bizProfile && (
                <div style={{ fontSize: fontSize.xs, color: colors.successText, textAlign: 'center' }}>✓ قبلاً ذخیره شده — می‌تونی ویرایش کنی</div>
              )}
            </form>
          )}
        </div>
      </div>
    </div>
  )
}

function StatusBadge({ level }: { level: number }) {
  const labels = ['کاربر ساده', 'شرکت تایید‌شده', 'تولیدکننده‌ی تایید‌شده']
  const levelColors = [colors.textSecondary, colors.successText, colors.successText]
  return (
    <div style={{ marginBottom: spacing.xl, fontSize: fontSize.base, fontWeight: 700, color: levelColors[level] }}>
      وضعیت فعلی: {labels[level]}
    </div>
  )
}

const pageStyle: React.CSSProperties = { minHeight: '100vh', background: colors.bgPage, padding: `${spacing.xxl}px ${spacing.xl}px`, fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl' }
const containerStyle: React.CSSProperties = { maxWidth: 560, margin: '0 auto' }
const cardStyle: React.CSSProperties = { ...sharedCardStyle, borderRadius: radius.lg, padding: '22px 20px', marginBottom: 20 }
const inputStyle: React.CSSProperties = { ...sharedInputStyle, padding: '10px 14px', fontSize: fontSize.md }
const fileLabelStyle: React.CSSProperties = { fontSize: fontSize.sm, color: colors.neutralText, display: 'flex', flexDirection: 'column' }
const submitBtnStyle: React.CSSProperties = { ...btnPrimaryStyle, borderRadius: radius.md, padding: '13px 0', fontSize: fontSize.md, fontWeight: 800, marginTop: 6 }

// گام ۳ — استایل‌های اضافه
const fieldLabelStyle: React.CSSProperties = { fontSize: fontSize.sm, fontWeight: 700, color: colors.neutralText, marginBottom: -6 }
const fieldsetStyle: React.CSSProperties = { border: 'none', padding: 0, margin: 0 }
const checkboxGridStyle: React.CSSProperties = { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: '6px 12px', marginTop: 6 }
const checkboxLabelStyle: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 6, fontSize: fontSize.sm, cursor: 'pointer' }
