import prisma from '@/lib/prisma'

export const dynamic = 'force-dynamic'

// نگاشت بسته: کاراکتر ورودیِ URL → فیلد دیتابیس
// برای اینکه فیلتر جدید اضافه کنیم، فقط یه سطر به URL_FIELDS و یه شاخه
// به whereBuilder زیر اضافه کن — بدون دست‌زدن به Prisma یا بقیه فایل.
const URL_FIELDS = {
  q: 'q',
  category: 'category',
  family: 'polymerFamily',
} as const

function one(v: string | string[] | undefined): string | undefined {
  if (Array.isArray(v)) return v[0]
  return v
}

export default async function GradesPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>
}) {
  const sp = await searchParams
  const q = one(sp.q)?.trim() || ''
  const category = one(sp.category)?.trim() || ''
  const family = one(sp.family)?.trim() || ''

  // ---------- ساخت where ----------
  const where: Record<string, unknown> = { isActive: true }

  if (q) {
    ;(where as Record<string, unknown>).OR = [
      { code: { contains: q, mode: 'insensitive' } },
      { producer: { contains: q, mode: 'insensitive' } },
      { category: { contains: q, mode: 'insensitive' } },
      { polymerFamily: { contains: q, mode: 'insensitive' } },
    ]
  }
  if (category) where.category = category
  if (family) where.polymerFamily = family

  // ---------- کوئری ----------
  const grades = await prisma.grade.findMany({
    where: where as never,
    orderBy: [{ producer: 'asc' }, { code: 'asc' }],
  })

  // گزینه‌های فیلتر — از distinct واقعی دیتابیس، نه هاردکد
  const [allCategories, allFamilies] = await Promise.all([
    prisma.grade.findMany({
      where: { isActive: true },
      distinct: ['category'],
      select: { category: true },
      orderBy: { category: 'asc' },
    }),
    prisma.grade.findMany({
      where: { isActive: true, polymerFamily: { not: null } },
      distinct: ['polymerFamily'],
      select: { polymerFamily: true },
      orderBy: { polymerFamily: 'asc' },
    }),
  ])

  const categories: string[] = allCategories.map((r) => r.category)
  const families: string[] = allFamilies
    .map((r) => r.polymerFamily)
    .filter((v): v is string => !!v)

  return (
    <>
      <div className="topbar">
        <div className="wrap">
          <span>پشتیبانی فروش شنبه تا چهارشنبه ۸:۳۰ تا ۱۷:۳۰</span>
          <a className="phone" href="tel:+982191234567">
            021-91234567
          </a>
        </div>
      </div>
      <header className="site-header">
        <div className="wrap">
          <a href="/" className="logo">
            <span className="dot"></span> انبار پلیمر
          </a>
          <nav className="main-nav">
            <a href="/">صفحه اصلی</a>
            <a href="/grades" className="active">
              گریدها
            </a>
            <a href="/rfq">استعلام قیمت</a>
            <a href="/reports">گزارش بازار</a>
            <a href="/services">خدمات سازمانی</a>
            <a href="/about">درباره ما</a>
            <a href="/contact">تماس با ما</a>
          </nav>
          <div className="header-actions">
            <a href="/login" className="acct-btn">
              ورود / ثبت‌نام
            </a>
          </div>
        </div>
      </header>

      <section>
        <div className="wrap">
          <div className="eyebrow">دیتاشیت و مقایسه گریدها</div>
          <div className="sec-title">مشخصات فنی گریدهای پلیمری</div>
          <div className="sec-sub" style={{ marginBottom: 20 }}>
            این صفحه فقط برای مقایسه‌ی فنی گریدهاست؛ برای قیمت و موجودی به صفحه‌ی استعلام قیمت مراجعه کنید. —{' '}
            <b style={{ color: 'var(--cyan)' }}>{grades.length} گرید فعال</b>
          </div>

          {/* ---------- فیلترها ---------- */}
          <form method="GET" action="/grades" style={filterFormStyle}>
            <input
              name="q"
              defaultValue={q}
              placeholder="جستجو: کد، تولیدکننده، دسته، خانواده پلیمری…"
              style={inputStyle}
            />
            <select name="category" defaultValue={category} style={selectStyle}>
              <option value="">همه‌ی دسته‌ها</option>
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
            <select name="family" defaultValue={family} style={selectStyle}>
              <option value="">همه‌ی خانواده‌ها</option>
              {families.map((f) => (
                <option key={f} value={f}>
                  {f}
                </option>
              ))}
            </select>
            <button type="submit" className="btn btn-sm" style={{ whiteSpace: 'nowrap' }}>
              اعمال فیلتر
            </button>
            {(q || category || family) && (
              <a href="/grades" className="btn btn-sm btn-outline" style={{ whiteSpace: 'nowrap' }}>
                پاک کردن
              </a>
            )}
          </form>

          {/* ---------- لیست گریدها ---------- */}
          {grades.length === 0 ? (
            <div style={emptyStyle}>هیچ گرید فعالی با این فیلتر یافت نشد.</div>
          ) : (
            <div style={gridStyle}>
              {grades.map((g) => (
                <a key={g.id} href={`/grades/${encodeURIComponent(g.code)}`} style={cardStyle}>
                  {/* عکس */}
                  <div style={thumbWrapStyle}>
                    {g.imageUrl ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={g.imageUrl} alt={g.code} style={thumbImgStyle} />
                    ) : (
                      <div style={thumbPlaceholderStyle}>بدون تصویر</div>
                    )}
                  </div>

                  {/* متن */}
                  <div style={{ padding: '12px 14px', flex: 1 }}>
                    <div style={codeStyle}>{g.code}</div>
                    <div style={producerStyle}>{g.producer}</div>
                    <div style={categoryStyle}>{g.category}</div>

                    <div style={specRowStyle}>
                      {g.mfi != null && (
                        <span style={specChipStyle}>
                          MFI {g.mfi} g/10min
                        </span>
                      )}
                      {g.density != null && (
                        <span style={specChipStyle}>
                          چگالی {g.density} g/cm³
                        </span>
                      )}
                    </div>

                    {g.applicationType && (
                      <div style={appTypeStyle}>{g.applicationType}</div>
                    )}
                  </div>

                  <div style={cardFootStyle}>مشاهده دیتاشیت ←</div>
                </a>
              ))}
            </div>
          )}
        </div>
      </section>

      <footer className="site-footer">
        <div className="wrap">
          <div className="footer-cols">
            <div>
              <a href="/" className="logo" style={{ marginBottom: 14, display: 'flex' }}>
                <span className="dot"></span> انبار پلیمر
              </a>
              <p style={{ color: 'var(--ink-dim)', fontSize: 13, maxWidth: 280 }}>
                واردکننده و فروشنده مستقیم مواد اولیه پلیمری برای کارخانه‌های تولیدی سراسر کشور.
              </p>
            </div>
            <div>
              <h5>محصولات</h5>
              <ul>
                <li>
                  <a href="/grades">پلی‌پروپیلن</a>
                </li>
                <li>
                  <a href="/grades">پلی‌اتیلن</a>
                </li>
                <li>
                  <a href="/grades">پی‌وی‌سی</a>
                </li>
                <li>
                  <a href="/grades">پلی‌اتیلن ترفتالات</a>
                </li>
              </ul>
            </div>
            <div>
              <h5>خدمات</h5>
              <ul>
                <li>
                  <a href="/rfq">استعلام قیمت آنلاین</a>
                </li>
                <li>
                  <a href="/services">فروش سازمانی</a>
                </li>
                <li>
                  <a href="/services">ارسال و لجستیک</a>
                </li>
                <li>
                  <a href="/reports">گزارش بازار</a>
                </li>
              </ul>
            </div>
            <div>
              <h5>اطلاعات تماس</h5>
              <ul>
                <li>تهران، خیابان ولیعصر، پلاک ۱۲۴</li>
                <li>انبار یزد — شهرک صنعتی یزد</li>
                <li style={{ direction: 'ltr', textAlign: 'right' }}>021-91234567</li>
              </ul>
            </div>
          </div>
          <div className="footer-bottom">
            <span>انبار پلیمر © ۱۴۰۵ — تمام حقوق محفوظ است</span>
          </div>
        </div>
      </footer>
    </>
  )
}

// ---------- style objects (inline — هماهنگ با بقیه‌ی پروژه) ----------

const filterFormStyle: React.CSSProperties = {
  display: 'flex',
  flexWrap: 'wrap',
  gap: 8,
  marginBottom: 20,
  padding: 12,
  background: '#f8f9fb',
  border: '1px solid #eceff3',
  borderRadius: 10,
}

const inputStyle: React.CSSProperties = {
  flex: '1 1 200px',
  minWidth: 0,
  padding: '8px 12px',
  border: '1px solid #d8dde3',
  borderRadius: 8,
  fontSize: 13,
  outline: 'none',
}

const selectStyle: React.CSSProperties = {
  padding: '8px 10px',
  border: '1px solid #d8dde3',
  borderRadius: 8,
  fontSize: 13,
  background: '#fff',
  minWidth: 140,
}

const gridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))',
  gap: 16,
}

const cardStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  border: '1px solid #e8eaef',
  borderRadius: 12,
  overflow: 'hidden',
  background: '#fff',
  textDecoration: 'none',
  color: 'inherit',
  transition: 'box-shadow .15s',
}

const thumbWrapStyle: React.CSSProperties = {
  height: 150,
  background: '#f1f1f3',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  overflow: 'hidden',
}

const thumbImgStyle: React.CSSProperties = {
  width: '100%',
  height: '100%',
  objectFit: 'cover',
}

const thumbPlaceholderStyle: React.CSSProperties = {
  color: '#a0a6b0',
  fontSize: 12,
}

const codeStyle: React.CSSProperties = { fontSize: 14, fontWeight: 800, color: '#1a1a2e' }
const producerStyle: React.CSSProperties = { fontSize: 12, color: '#636b7a', marginTop: 2 }
const categoryStyle: React.CSSProperties = { fontSize: 11, color: '#9199a3', marginTop: 2 }

const specRowStyle: React.CSSProperties = {
  display: 'flex',
  flexWrap: 'wrap',
  gap: 6,
  marginTop: 10,
}

const specChipStyle: React.CSSProperties = {
  fontSize: 11,
  background: '#f1efe8',
  color: '#5a5340',
  borderRadius: 6,
  padding: '3px 8px',
}

const appTypeStyle: React.CSSProperties = {
  marginTop: 8,
  fontSize: 11,
  color: '#e65716',
  background: '#fff4ee',
  borderRadius: 6,
  padding: '3px 8px',
  display: 'inline-block',
}

const cardFootStyle: React.CSSProperties = {
  padding: '10px 14px',
  borderTop: '1px solid #f0f1f3',
  fontSize: 12,
  color: '#e65716',
  fontWeight: 700,
  textAlign: 'center',
}

const emptyStyle: React.CSSProperties = {
  padding: 40,
  textAlign: 'center',
  color: '#9199a3',
  fontSize: 13,
  border: '1px dashed #d8dde3',
  borderRadius: 10,
}
