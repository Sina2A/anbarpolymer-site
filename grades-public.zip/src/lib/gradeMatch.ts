// موتور تطبیق گریدها — فقط بر پایه‌ی ۴ فیلد فنی
//
// این فایل عمداً هیچ ارجاعی به قیمت، موجودی، بنچمارک یا هر مدل مالی/معاملاتی
// ندارد. فقط polymerFamily / applicationType / mfi / density استفاده می‌شوند.
// دلیل: صفحه‌ی عمومی گریدها کاتالوگ فنی است نه فروشگاه؛ قیمت‌گذاری جداست و فریز است.

import prisma from './prisma'

/**
 * گریدهای مشابه یک گرید هدف را بر اساس ۴ فیلد فنی پیدا می‌کند.
 * امتیازدهی:
 *   polymerFamily یکسان          → +3
 *   applicationType یکسان        → +2
 *   mfi در بازه‌ی ±۳۵٪           → +2 * (1 - نسبت/0.35)  (خطی، هرچه نزدیک‌تر امتیاز بیشتر)
 *   density در بازه‌ی ±0.03      → +2 * (1 - Δ/0.03)
 * فقط کاندیدهای با score > 0 برمی‌گردند، مرتب نزولی، حداکثر limit عدد.
 */
export async function findSimilarGrades(gradeId: string, limit = 6) {
  const target = await prisma.grade.findUnique({ where: { id: gradeId } })
  if (!target || !target.isActive) return []
  if (!target.polymerFamily && !target.applicationType) return []

  const orConditions: Record<string, unknown>[] = []
  if (target.polymerFamily) orConditions.push({ polymerFamily: target.polymerFamily })
  if (target.applicationType) orConditions.push({ applicationType: target.applicationType })

  const candidates = await prisma.grade.findMany({
    where: {
      id: { not: gradeId },
      isActive: true,
      OR: orConditions as never,
    },
  })

  const scored = candidates
    .map((c) => {
      let score = 0

      if (target.polymerFamily && c.polymerFamily === target.polymerFamily) score += 3
      if (target.applicationType && c.applicationType === target.applicationType) score += 2

      if (
        target.mfi != null &&
        c.mfi != null &&
        target.mfi !== 0
      ) {
        const diff = Math.abs(c.mfi - target.mfi)
        const ratio = diff / Math.abs(target.mfi)
        if (ratio <= 0.35) score += 2 * (1 - ratio / 0.35)
      }

      if (target.density != null && c.density != null) {
        const diff = Math.abs(c.density - target.density)
        if (diff <= 0.03) score += 2 * (1 - diff / 0.03)
      }

      return { grade: c, score }
    })
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((x) => x.grade)

  return scored
}
