# NOTES-FONT.md

## خلاصه‌ی خودمیزبانی فونت‌ها

### هدف
حذف وابستگی به سرور گوگل (`fonts.googleapis.com`) — فونت‌ها حالا از دامنه‌ی خودمون سرو می‌شن.

### روش
`@font-face` دستی (نه `next/font/google` یا `next/font/local`) — چون `next/font/*` نام خانواده‌ی هش‌شده تولید می‌کنه و ۷۹ `fontFamily: "'Vazirmatn', ..."` inline در کامپوننت‌ها رو می‌شکنه.

### فایل‌های تغییریافته

#### 1. `src/app/globals.css`
- **حذف**: خط ۲ — `@import url('https://fonts.googleapis.com/css2?...')`
- **اضافه**: ۸ بلوک `@font-face` در ابتدای فایل (قبل از `:root`)
  - **Vazirmatn** (وزن‌های 400, 500, 600, 700, 800) → `/fonts/vazirmatn-{weight}.ttf`
  - **JetBrains Mono** (وزن‌های 400, 500, 600) → `/fonts/jetbrainsmono-{weight}.ttf`
- هر `@font-face` با `font-family: 'Vazirmatn'` یا `font-family: 'JetBrains Mono'` تعریف شده — دقیقاً مثل قبل، بدون هش.

#### 2. `public/fonts/` (پوشه‌ی جدید)
فایل‌های دانلود‌شده از `fonts.gstatic.com`:
- `vazirmatn-400.ttf` (192.5K)
- `vazirmatn-500.ttf` (192.5K)
- `vazirmatn-600.ttf` (192.5K)
- `vazirmatn-700.ttf` (192.5K)
- `vazirmatn-800.ttf` (192.5K)
- `jetbrainsmono-400.ttf` (192.5K)
- `jetbrainsmono-500.ttf` (192.5K)
- `jetbrainsmono-600.ttf` (192.5K)

**جمع**: ۸ فایل، ~۱٫۵ مگابایت

---

## تصمیمات طراحی

### چرا `@font-face` دستی؟
- `next/font/google` و `next/font/local` هردو نام خانواده‌ی هش‌شده تولید می‌کنن (`__Vazirmatn_a1b2c3`)
- ۷۹ inline style در کامپوننت‌ها (`fontFamily: "'Vazirmatn', Tahoma, sans-serif"`) و ۲ متغیر CSS (`--sans`, `--mono`) همگی به رشته‌ی لفظی `'Vazirmatn'` و `'JetBrains Mono'` اشاره می‌کنن
- `@font-face` دستی این نام‌ها رو دقیقاً حفظ می‌کنه — هیچ کدنویسی اضافه‌ای لازم نیست

### چرا TTF؟
- گوگل فونتز بسته به user-agent برای مرورگرهای مدرن woff2 برمی‌گردونه، برای قدیمی‌تر ttf
- درخواست ما ttf برگردونده (سرور Windows با curl)
- ttf با همه‌ی مرورگرها سازگاره — woff2 فقط ۲۰٪ کوچیک‌تره، برای یک سایت فارسی با ۸ فایل (۱٫۵ مگ) قابل‌چشم‌پوشی

### چرا JetBrains Mono هم اضافه شد؟
- `@import` قبلی **هردو** فونت رو لود می‌کرد
- حذف اون خط بدون جایگزینی JetBrains Mono، متغیر `--mono` (استفاده در ۷ جا) رو می‌شکنه
- پس هردو با همون روش خودمیزبانی شدن

### وزن ۳۰۰ کجاست؟
- پرامپت اشاره کرده بود «۶ وزن (۳۰۰،۴۰۰،۵۰۰،۶۰۰،۷۰۰،۸۰۰)»
- ولی `@import` واقعی فقط **۵ وزن** لود می‌کرد: `400;500;600;700;800`
- وزن ۳۰۰ اصلاً استفاده نمی‌شه — از دانلود حذف شده

---

## تست‌های پیشنهادی

۱. باز کردن هر صفحه‌ی سایت (عمومی و admin) — چک کنید Vazirmatn به‌درستی رندر می‌شه (نه Tahoma)
۲. بررسی Network tab در DevTools — درخواستی به `fonts.googleapis.com` یا `fonts.gstatic.com` نباید باشه
۳. چک کردن المان‌هایی که از `--mono` استفاده می‌کنن (کدهای گرید، جداول قیمت، شمارنده‌ی کاراکتر ادیتور) — JetBrains Mono باید لود بشه
۴. (اختیاری) تبدیل ttf به woff2 با ابزار `fonttools` یا `google-webfonts-helper` برای کاهش ۲۰٪ حجم

---

**تاریخ**: 2026-09-11  
**وضعیت**: کامل — آماده‌ی تست
