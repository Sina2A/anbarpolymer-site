import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { addDriver, toggleDriverActive } from './actions'
import ConfirmSubmitButton from '@/components/ConfirmSubmitButton'

export const dynamic = 'force-dynamic'

// وضعیت‌هایی که برای شرکت حمل معنی دارن. قبل از payment_secured معامله هنوز
// قابل برنامه‌ریزیِ حمل نیست، پس عمداً به این پنل نمیاد.
const ACTIVE_STATUSES = ['payment_secured', 'loading', 'in_transit']
const DONE_STATUSES = ['delivered', 'settled']

const CARRIER_STATUS: Record<string, { label: string; bg: string; color: string }> = {
  payment_secured: { label: 'در انتظار بارگیری', bg: '#fef3c7', color: '#92400e' },
  loading: { label: 'در حال بارگیری', bg: '#eef4fd', color: '#1e357b' },
  in_transit: { label: 'در مسیر', bg: '#eef4fd', color: '#1e357b' },
  delivered: { label: 'تحویل‌شده', bg: '#eaf3de', color: '#146c3a' },
  settled: { label: 'تسویه‌شده', bg: '#eaf3de', color: '#146c3a' },
}

// نام/پلاک راننده‌ی هر محموله از آخرین تاییدیه‌ی بارگیری درمیاد —
// خودِ Deal فیلد driverId نداره، رابطه از سمت DealConfirmation.driverId است.
function loadingInfo(confs: { type: string; driverName: string | null; vehiclePlate: string | null }[]) {
  const c = confs.find((x) => x.type === 'loading') ?? confs[0]
  return { driverName: c?.driverName || null, plate: c?.vehiclePlate || null }
}
const faDateTime = (d: Date) => new Date(d).toLocaleString('fa-IR', { dateStyle: 'short', timeStyle: 'short' })

export default async function TransportPanelPage() {
  const user = await getCurrentUser()

  const company = await prisma.transportCompany.findUnique({
    where: { managerUserId: user.id },
    include: {
      // ۵.۳ — کرایه‌ی حمل (transportCost / transportCostPaid) هم اینجاست؛
      // مبلغ معامله (agreedPrice) و هویت خریدار همچنان برداشته نمی‌شه.
      deals: {
        where: { status: { in: [...ACTIVE_STATUSES, ...DONE_STATUSES] } },
        orderBy: { createdAt: 'desc' },
        take: 60,
        include: {
          materialListing: { include: { grade: true } },
          confirmations: { orderBy: { confirmedAt: 'desc' }, take: 5 },
        },
      },
      drivers: {
        orderBy: { createdAt: 'asc' },
        include: {
          confirmations: {
            orderBy: { confirmedAt: 'desc' },
            take: 10,
            include: { deal: true },
          },
        },
      },
    },
  })

  if (!company) {
    return (
      <div style={pageStyle}>
        <div style={cardStyle}>
          <h1 style={{ fontSize: 18, fontWeight: 800, marginBottom: 8 }}>
            پنل شرکت حمل‌ونقل — دسترسی ندارید
          </h1>
          <p style={{ fontSize: 13.5, color: '#4f5560' }}>این حساب به هیچ شرکت حمل‌ونقلی وصل نیست. با پشتیبانی انبار پلیمر تماس بگیرید.</p>
        </div>
      </div>
    )
  }

  // گیت دسترسی پنل (۵.۳) — جدای از خودِ قرارداد حمل. اگه مدیر دسترسی رو
  // قطع کرده باشه، شرکت اصلاً محتوای پنل رو نمی‌بینه؛ عملیاتش هم از سمت
  // اکشن‌ها قفله (getMyTransportCompany هم همین چک رو داره).
  if (!company.logisticsAccessEnabled) {
    return (
      <div style={pageStyle}>
        <div style={cardStyle}>
          <h1 style={{ fontSize: 18, fontWeight: 800, marginBottom: 8 }}>
            پنل شرکت حملونقل — دسترسی غیرفعال
          </h1>
          <p style={{ fontSize: 13.5, color: '#4f5560' }}>
            دسترسی پنل حملونقل برای <b>{company.name}</b> در حال حاضر غیرفعاله. برای فعال‌شدن با پشتیبانی انبار پلیمر تماس بگیرید.
          </p>
        </div>
      </div>
    )
  }

  const activeDeals = company.deals.filter((d) => ACTIVE_STATUSES.includes(d.status))
  const doneDeals = company.deals.filter((d) => DONE_STATUSES.includes(d.status)).slice(0, 20)

  return (
    <div style={pageStyle}>
      <div style={{ maxWidth: 780, margin: '0 auto' }}>
        <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 6 }}>
          پنل شرکت حمل‌ونقل
          <span style={panelTagStyle}>یوزر لجیستیک</span>
        </h1>
        <p style={{ fontSize: 13, color: '#9199a3', marginBottom: 24 }}>
          <b style={{ color: '#4f5560', fontWeight: 700 }}>{company.name}</b>
          {' — '}
          محموله‌های سپرده‌شده، راننده‌ها و تاریخچه‌ی سفرهای تایید‌شده
        </p>

        <div style={purposeBoxStyle}>
          <b>هدف این پنل چیه؟</b>
          <p style={{ margin: '6px 0 0', lineHeight: 1.9 }}>
            این پنل مخصوص <b>مدیر شرکت حمل‌ونقل</b>‌ه — بخش داخلی «حمل و نقل» انبار پلیمر جای دیگه‌ایه و به این صفحه ربطی نداره.
            کارش فقط <b>احراز هویت راننده و مسیر طی‌شده</b>‌ست — به‌خاطر حساسیت صنعت مواد اولیه پتروشیمی در ایران.
            انبار پلیمر با رقم دقیق مسافتِ طی‌شده‌ی هیچ راننده‌ای کاری نداره و این داده رو برای ارزیابی عملکرد یا هزینه استفاده نمی‌کنه —
            فقط جهت تایید این‌که سفر واقعاً و توسط همون راننده‌ی ثبت‌شده انجام شده.
          </p>
        </div>

        <h3 style={sectionTitleStyle}>محموله‌های جاری ({activeDeals.length})</h3>

        {activeDeals.length === 0 && <div style={emptyBoxStyle}>الان محموله‌ی جاری‌ای به این شرکت سپرده نشده.</div>}

        {activeDeals.map((deal) => {
          const st = CARRIER_STATUS[deal.status]
          const { driverName, plate } = loadingInfo(deal.confirmations)
          const gradeCode = deal.materialListing?.grade?.code
          return (
            <div key={deal.id} style={cardStyle}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, flexWrap: 'wrap', marginBottom: 12 }}>
                <div>
                  <b style={{ fontSize: 13.5 }}>محموله</b>{' '}
                  <span style={dealIdStyle}>#{deal.id.slice(0, 8)}</span>
                  {gradeCode && <span style={gradeTagStyle}>{gradeCode}</span>}
                </div>
                <span style={{ ...dealBadgeStyle, background: st?.bg ?? '#eceff3', color: st?.color ?? '#4f5560' }}>{st?.label ?? deal.status}</span>
              </div>

              <div style={metaGridStyle}>
                <div>
                  <span style={metaLabelStyle}>مقدار</span>
                  <span style={metaValueStyle}>{deal.quantity}</span>
                </div>
                <div>
                  <span style={metaLabelStyle}>راننده</span>
                  <span style={metaValueStyle}>{driverName ?? 'ثبت نشده'}</span>
                </div>
                <div>
                  <span style={metaLabelStyle}>پلاک</span>
                  <span style={{ ...metaValueStyle, direction: 'ltr', display: 'inline-block' }}>{plate ?? '—'}</span>
                </div>
                <div>
                  <span style={metaLabelStyle}>آخرین گزارش موقعیت</span>
                  <span style={metaValueStyle}>{deal.locationUpdatedAt ? faDateTime(deal.locationUpdatedAt) : 'گزارشی ثبت نشده'}</span>
                </div>
              </div>

              {/** ۵.۳ — کرایه‌ی حمل: همون واحد پول پیش‌فرض سایت (تومان، my-listings/my-requests) */}
              <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap', marginTop: 10 }}>
                <span style={metaLabelStyle}>کرایه حمل</span>
                <span style={metaValueStyle}>{deal.transportCost != null ? `${deal.transportCost.toLocaleString('fa-IR')} تومان` : '—'}</span>
                {deal.transportCost != null && (
                  <span style={{ ...dealBadgeStyle, background: deal.transportCostPaid ? '#dcfce7' : '#fef3c7', color: deal.transportCostPaid ? '#146c3a' : '#92400e' }}>
                    {deal.transportCostPaid ? 'پرداخت شده' : 'پرداخت نشده'}
                  </span>
                )}
              </div>

              {deal.driverSilenceFlaggedAt && (
                <div style={silenceBoxStyle}>
                  از <b>{faDateTime(deal.driverSilenceFlaggedAt)}</b> هیچ گزارشی از راننده‌ی این محموله ثبت نشده — پیگیری کنید.
                </div>
              )}
            </div>
          )
        })}

        <h3 style={sectionTitleStyle}>تاریخچه‌ی محموله‌ها ({doneDeals.length})</h3>

        {doneDeals.length === 0 ? (
          <div style={emptyBoxStyle}>هنوز محموله‌ی تکمیل‌شده‌ای ثبت نشده.</div>
        ) : (
          <div style={cardStyle}>
            {doneDeals.map((deal, i) => {
              const st = CARRIER_STATUS[deal.status]
              const { driverName } = loadingInfo(deal.confirmations)
              return (
                <div key={deal.id} style={{ ...tripRowStyle, ...(i > 0 ? { borderTop: '1px solid #eceff3' } : {}), padding: '8px 0', gap: 8, flexWrap: 'wrap' }}>
                  <span>
                    <span style={dealIdStyle}>#{deal.id.slice(0, 8)}</span>
                    {' — '}
                    {deal.materialListing?.grade?.code ?? 'بدون گرید'}
                    {' — '}
                    {driverName ?? 'راننده ثبت نشده'}
                  </span>
                  <span style={{ ...dealBadgeStyle, background: st?.bg ?? '#eceff3', color: st?.color ?? '#4f5560' }}>{st?.label ?? deal.status}</span>
                </div>
              )
            })}
          </div>
        )}

        <h3 style={sectionTitleStyle}>افزودن راننده‌ی جدید</h3>

        <div style={cardStyle}>
          <form action={addDriver} style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 12 }}>
            <input name="fullName" placeholder="نام و نام خانوادگی" required style={inputStyle} />
            <input name="phone" placeholder="شماره موبایل" required style={{ ...inputStyle, direction: 'ltr' }} />
            <input name="nationalId" placeholder="کد ملی (اختیاری)" style={{ ...inputStyle, direction: 'ltr' }} />
            <input name="licenseNumber" placeholder="شماره گواهینامه (اختیاری)" style={{ ...inputStyle, direction: 'ltr' }} />
            <button type="submit" style={btnStyle}>افزودن راننده</button>
          </form>
        </div>

        <h3 style={sectionTitleStyle}>راننده‌ها ({company.drivers.length})</h3>

        {company.drivers.length === 0 && <div style={emptyBoxStyle}>هنوز راننده‌ای ثبت نشده.</div>}

        {company.drivers.map((driver) => (
          <div key={driver.id} style={cardStyle}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
              <div>
                <b style={{ fontSize: 14 }}>{driver.fullName}</b>{' '}
                <span style={{ fontSize: 12, color: '#9199a3', direction: 'ltr', display: 'inline-block' }}>— {driver.phone}</span>
              </div>
              <form action={toggleDriverActive}>
                <input type="hidden" name="driverId" value={driver.id} />
                <input type="hidden" name="value" value={(!driver.isActive).toString()} />
                <ConfirmSubmitButton
                  message={driver.isActive ? `«${driver.fullName}» غیرفعال بشه؟` : `«${driver.fullName}» دوباره فعال بشه؟`}
                  style={{ ...statusBtn, ...(driver.isActive ? activeStatus : inactiveStatus) }}
                >
                  {driver.isActive ? 'فعال' : 'غیرفعال'}
                </ConfirmSubmitButton>
              </form>
            </div>

            {driver.confirmations.length > 0 && (
              <div style={{ borderTop: '1px dashed #eceff3', paddingTop: 10, marginTop: 4 }}>
                <div style={{ fontSize: 11, color: '#9199a3', marginBottom: 6 }}>آخرین سفرهای تایید‌شده:</div>
                {driver.confirmations.map((c) => (
                  <div key={c.id} style={tripRowStyle}>
                    <span>{c.type === 'loading' ? 'بارگیری' : 'تخلیه'} — معامله #{c.dealId.slice(0, 8)}</span>
                    <span style={{ color: '#9199a3' }}>{new Date(c.confirmedAt).toLocaleDateString('fa-IR')}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}

        <div style={{ ...cardStyle, background: '#eef4fd', borderColor: '#1e357b' }}>
          <h3 style={{ fontSize: 14, fontWeight: 800, color: '#1e357b', marginBottom: 8 }}>پشتیبانی فنی</h3>
          <p style={{ fontSize: 12.5, color: '#4f5560', margin: 0 }}>برای هر مشکل فنی در این پنل، با تیم انبار پلیمر تماس بگیرید: <span style={{ direction: 'ltr', display: 'inline-block', fontWeight: 700 }}>۰۲۱-۹۱۲۳۴۵۶۷</span></p>
        </div>
      </div>
    </div>
  )
}

const pageStyle: React.CSSProperties = { minHeight: '100vh', background: '#faf8f4', padding: '32px 20px', fontFamily: "'Vazirmatn', Tahoma, sans-serif", direction: 'rtl' }
const cardStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 12, padding: 18, marginBottom: 14, background: '#fff', boxShadow: '0 1px 4px rgba(27,30,36,.05)' }
const panelTagStyle: React.CSSProperties = { fontSize: 10.5, fontWeight: 700, color: '#1e357b', background: '#eef4fd', borderRadius: 5, padding: '3px 9px', marginRight: 10, verticalAlign: 'middle' }
const purposeBoxStyle: React.CSSProperties = { background: '#fef3c7', color: '#92400e', borderRadius: 10, padding: '14px 16px', fontSize: 12.5, marginBottom: 20 }
const inputStyle: React.CSSProperties = { border: '1px solid #d8dde3', borderRadius: 8, padding: '9px 12px', fontSize: 13, fontFamily: 'inherit' }
const btnStyle: React.CSSProperties = { background: '#1e357b', color: '#fff', border: 'none', borderRadius: 8, padding: '9px 16px', fontSize: 13, fontWeight: 700, cursor: 'pointer', gridColumn: 'span 1' }
const statusBtn: React.CSSProperties = { fontSize: 10.5, fontWeight: 700, borderRadius: 5, padding: '4px 12px', border: 'none', cursor: 'pointer' }
const activeStatus: React.CSSProperties = { background: '#dcfce7', color: '#146c3a' }
const inactiveStatus: React.CSSProperties = { background: '#fee2e2', color: '#a8241a' }
const tripRowStyle: React.CSSProperties = { display: 'flex', justifyContent: 'space-between', fontSize: 12, padding: '5px 0', color: '#4f5560' }
const sectionTitleStyle: React.CSSProperties = { fontSize: 15, fontWeight: 800, margin: '28px 0 14px' }
const emptyBoxStyle: React.CSSProperties = { padding: 28, textAlign: 'center', color: '#9199a3', border: '1px dashed #d8dde3', borderRadius: 12, marginBottom: 14 }
const dealIdStyle: React.CSSProperties = { fontFamily: 'monospace', fontSize: 12, color: '#6f7680', direction: 'ltr', display: 'inline-block' }
const gradeTagStyle: React.CSSProperties = { fontSize: 10.5, fontWeight: 700, background: '#f1efe8', color: '#4f5560', borderRadius: 4, padding: '1px 7px', marginRight: 8, verticalAlign: 'middle' }
const dealBadgeStyle: React.CSSProperties = { fontSize: 10.5, fontWeight: 700, borderRadius: 5, padding: '3px 10px' }
const metaGridStyle: React.CSSProperties = { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: 8 }
const metaLabelStyle: React.CSSProperties = { display: 'block', fontSize: 10.5, color: '#9199a3', marginBottom: 2 }
const metaValueStyle: React.CSSProperties = { fontSize: 13, fontWeight: 600, color: '#1b1e24' }
const silenceBoxStyle: React.CSSProperties = { marginTop: 10, background: '#fee2e2', color: '#9b1c1c', borderRadius: 8, padding: '8px 12px', fontSize: 12, fontWeight: 600 }
