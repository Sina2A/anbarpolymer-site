'use server'

import prisma from '@/lib/prisma'
import { assertSingleAdmin } from '@/lib/permissions'
import { upsertWeeklyBusinessHour } from '@/lib/businessHours'
import { updatePasswordPolicy } from '@/lib/passwordPolicy'
import { reviewKycLevel1, reviewProducerLicense } from '@/lib/kyc'
import { getCurrentUser } from '@/lib/currentUser'
import { revalidatePath } from 'next/cache'
import crypto from 'crypto'

export async function createStaffUser(formData: FormData) {
  const companyName = String(formData.get('companyName') || '').trim()
  const phone = String(formData.get('phone') || '').trim()
  const role = String(formData.get('role') || 'staff')
  if (!companyName || !phone) return

  if (role === 'admin') {
    const err = await assertSingleAdmin(null)
    if (err) {
      // چون هنوز toast/پیام خطای سراسری نداریم، فعلاً کارشناس رو با نقش staff می‌سازیم
      // و پیام رو توی لاگ سرور می‌ذاریم — وقتی UI پیام خطا داشته باشیم اینجا اصلاح می‌شه.
      console.warn('createStaffUser blocked admin role:', err)
      await prisma.user.create({
        data: { companyName, phone, role: 'staff', passwordHash: crypto.randomBytes(16).toString('hex') },
      })
      revalidatePath('/admin-users')
      return
    }
  }

  await prisma.user.create({
    data: {
      companyName,
      phone,
      role,
      passwordHash: crypto.randomBytes(16).toString('hex'),
    },
  })
  revalidatePath('/admin-users')
}

/**
 * تغییر نقش یک کاربر — عملی حساسه، سمت کلاینت با ConfirmSubmitButton تاییدیه گرفته می‌شه.
 * قبل از اعمال، قانون تک‌مدیر رو دوباره سمت سرور هم چک می‌کنیم (دفاع دوم، مستقل از UI).
 */
export async function changeUserRole(formData: FormData) {
  const userId = String(formData.get('userId'))
  const newRole = String(formData.get('newRole'))

  if (newRole === 'admin') {
    const err = await assertSingleAdmin(userId)
    if (err) {
      console.warn('changeUserRole blocked:', err)
      return
    }
  }

  await prisma.user.update({ where: { id: userId }, data: { role: newRole } })
  revalidatePath('/admin-users')
}

export async function toggleUserActive(formData: FormData) {
  const userId = String(formData.get('userId'))
  const value = formData.get('value') === 'true'
  await prisma.user.update({ where: { id: userId }, data: { isActive: value } })
  revalidatePath('/admin-users')
}

/**
 * ویرایش اطلاعات پایه‌ی یک کاربر — دکمه‌ی «تغییر اطلاعات» که مدیر می‌تونه استفاده کنه.
 * حساسه (تاییدیه سمت کلاینت لازم داره) چون مستقیم روی هویت حساب کاربر اثر می‌ذاره.
 */
export async function updateUserInfo(formData: FormData) {
  const userId = String(formData.get('userId'))
  const companyName = String(formData.get('companyName') || '').trim()
  const phone = String(formData.get('phone') || '').trim()
  if (!companyName || !phone) return

  await prisma.user.update({ where: { id: userId }, data: { companyName, phone } })
  revalidatePath('/admin-users')
}

export async function setPermission(formData: FormData) {
  const userId = String(formData.get('userId'))
  const section = String(formData.get('section'))
  const field = String(formData.get('field')) as 'canView' | 'canEdit'
  const value = formData.get('value') === 'true'

  await prisma.permission.upsert({
    where: { userId_section: { userId, section } },
    update: { [field]: value },
    create: {
      userId,
      section,
      canView: field === 'canView' ? value : false,
      canEdit: field === 'canEdit' ? value : false,
    },
  })
  revalidatePath('/admin-users')
}

/** فقط نقش «مدیر» — چک سمت سرور، مستقل از پنهان‌بودن UI برای کارشناس. */
export async function upsertWeeklyHourAction(formData: FormData) {
  const currentUser = await getCurrentUser()
  if (currentUser.role !== 'admin') {
    throw new Error('فقط نقش مدیر مجاز به تغییر ساعات کاری هفتگیه.')
  }

  const dayOfWeek = Number(formData.get('dayOfWeek'))
  const isOpen = formData.get('isOpen') === 'on'
  const openTime = String(formData.get('openTime') || '08:00')
  const closeTime = String(formData.get('closeTime') || '17:00')

  if (!Number.isInteger(dayOfWeek) || dayOfWeek < 0 || dayOfWeek > 6) return

  await upsertWeeklyBusinessHour(dayOfWeek, isOpen, openTime, closeTime)
  revalidatePath('/admin-users')
}

/**
 * تایید/رد هویت شرکت (سطح ۱) — فقط مدیر یا کارشناس با دسترسی می‌تونه انجام بده.
 * چک نقش سمت سرور، مستقل از UI.
 */
export async function reviewKycLevel1Action(formData: FormData) {
  const reviewer = await getCurrentUser()
  const companyId = String(formData.get('companyId') || '')
  const approve = formData.get('approve') === 'true'
  if (!companyId) return

  await reviewKycLevel1({ companyId, approve, reviewerId: reviewer.id })
  revalidatePath('/admin-users')
}

/** تایید/رد احراز تولیدکننده (سطح ۲) — حساس‌تر، چون اجازه‌ی فروش می‌ده. */
export async function reviewProducerLicenseAction(formData: FormData) {
  const reviewer = await getCurrentUser()
  const companyId = String(formData.get('companyId') || '')
  const approve = formData.get('approve') === 'true'
  const licenseVerifiedManually = formData.get('licenseVerifiedManually') === 'on'
  if (!companyId) return

  await reviewProducerLicense({ companyId, approve, reviewerId: reviewer.id, licenseVerifiedManually })
  revalidatePath('/admin-users')
}

/** تنظیم سیاست رمز عبور — فقط مدیر، چک سمت سرور مستقل از UI. */
export async function updatePasswordPolicyAction(formData: FormData) {
  const currentUser = await getCurrentUser()
  if (currentUser.role !== 'admin') {
    throw new Error('فقط نقش مدیر مجاز به تغییر سیاست رمز عبوره.')
  }

  const minLength = Math.max(4, Math.min(64, Number(formData.get('minLength')) || 8))
  const requireNumber = formData.get('requireNumber') === 'on'
  const requireUppercase = formData.get('requireUppercase') === 'on'
  const requireSpecialChar = formData.get('requireSpecialChar') === 'on'
  const expiryDaysRaw = String(formData.get('expiryDays') || '').trim()
  const expiryDays = expiryDaysRaw === '' ? null : Math.max(0, Number(expiryDaysRaw))

  await updatePasswordPolicy(
    { minLength, requireNumber, requireUppercase, requireSpecialChar, expiryDays },
    currentUser.id
  )
  revalidatePath('/admin-users')
}

/**
 * تغییر وضعیت دسترسی پنل حمل‌ونقل (logisticsAccessEnabled) برای یک شرکت حمل —
 * فقط مدیر، چک سمت سرور مستقل از UI.
 * این فیلد از isActive شرکت جداست: قرارداد حمل ممکنه فعال باشه ولی دسترسی پنل قطع.
 */
export async function toggleCompanyLogisticsAccess(formData: FormData) {
  const currentUser = await getCurrentUser()
  if (currentUser.role !== 'admin') {
    throw new Error('فقط نقش مدیر مجاز به تغییر دسترسی شرکت حمل‌ونقله.')
  }

  const companyId = String(formData.get('companyId'))
  const value = formData.get('value') === 'true'

  await prisma.transportCompany.update({ where: { id: companyId }, data: { logisticsAccessEnabled: value } })
  revalidatePath('/admin-users')
}
