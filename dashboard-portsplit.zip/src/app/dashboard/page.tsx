import prisma from '@/lib/prisma'
import { getCurrentUser } from '@/lib/currentUser'
import { getUserKycLevel } from '@/lib/kyc'
import KycStatusBanner from '@/components/KycStatusBanner'

export const dynamic = 'force-dynamic'

export default async function DashboardPage() {
  const user = await getCurrentUser()
  const kycLevel = await getUserKycLevel(user.id)

  const recentOrders = await prisma.order.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    take: 5,
    include: { items: { include: { grade: true } } },
  })

  const myListingsCount =
    kycLevel >= 2
      ? await prisma.materialListing.count({ where: { userId: user.id } })
      : null

  return (
    <div style={pageStyle}>
      <div style={{ maxWidth: 860, margin: '0 auto' }}>
        <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>داشبورد</h1>
        <p style={{ fontSize: 13, color: '#9199a3', marginBottom: 20 }}>
          خلاصه‌ی وضعیت خرید و فروش شما در انبار پلیمر
        </p>

        <KycStatusBanner level={kycLevel} />

        {/* کارت سفارش‌های اخیر */}
        <div style={cardStyle}>
          <div style={cardHeaderStyle}>
            <b style={{ fontSize: 14 }}>سفارش‌های اخیر</b>
            <a href="/my-orders" style={linkStyle}>
              مشاهده‌ی همه ←
            </a>
          </div>

          {recentOrders.length === 0 ? (
            <div style={emptyStyle}>هنوز سفارشی ثبت نکردی.</div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {recentOrders.map((order) => (
                <div key={order.id} style={rowStyle}>
                  <span style={{ fontSize: 12.5, fontWeight: 700 }}>سفارش #{order.id.slice(0, 8)}</span>
                  <span style={statusTag}>{order.status}</span>
                  <span style={{ fontSize: 11, color: '#9199a3' }}>
                    {order.items.length} قلم — {new Date(order.createdAt).toLocaleDateString('fa-IR')}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* کارت آگهی‌های فروش — فقط اگر سطح ۲ */}
        {kycLevel >= 2 && (
          <div style={cardStyle}>
            <div style={cardHeaderStyle}>
              <b style={{ fontSize: 14 }}>آگهی‌های فروش من</b>
            </div>
            <div style={{ fontSize: 13 }}>
              تعداد آگهی‌های ثبت‌شده: <b>{myListingsCount}</b>
            </div>
            {/* TODO: لینک به صفحه‌ی مدیریت آگهی‌ها وقتی ساخته شد */}
          </div>
        )}

        {/* لینک‌های سریع */}
        <div style={cardStyle}>
          <b style={{ fontSize: 14, display: 'block', marginBottom: 12 }}>دسترسی سریع</b>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            <a href="/grades" style={quickLinkStyle}>
              گریدها
            </a>
            <a href="/rfq" style={quickLinkStyle}>
              استعلام قیمت
            </a>
            <a href="/verification" style={quickLinkStyle}>
              احراز هویت
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}

const pageStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: '#faf8f4',
  padding: '32px 20px',
  fontFamily: "'Vazirmatn', Tahoma, sans-serif",
  direction: 'rtl',
}
const cardStyle: React.CSSProperties = {
  border: '1px solid #d8dde3',
  borderRadius: 12,
  padding: 18,
  marginBottom: 14,
  background: '#fff',
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
}
const cardHeaderStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: 12,
}
const linkStyle: React.CSSProperties = { fontSize: 12, color: '#e65716', fontWeight: 700, textDecoration: 'none' }
const emptyStyle: React.CSSProperties = { fontSize: 12.5, color: '#9199a3', padding: '12px 0' }
const rowStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  padding: '10px 12px',
  border: '1px solid #f1efe8',
  borderRadius: 8,
  background: '#faf8f4',
}
const statusTag: React.CSSProperties = {
  fontSize: 11,
  fontWeight: 700,
  background: '#eef4fd',
  color: '#1e357b',
  borderRadius: 6,
  padding: '3px 10px',
}
const quickLinkStyle: React.CSSProperties = {
  display: 'inline-block',
  padding: '8px 14px',
  border: '1px solid #d8dde3',
  borderRadius: 8,
  fontSize: 12.5,
  fontWeight: 600,
  color: '#1a1a2e',
  textDecoration: 'none',
  background: '#fff',
}
