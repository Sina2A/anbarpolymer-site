'use client'

// نقشه‌ی پایه‌ی ایران (SVG برداری) — هسته‌ی مشترکِ WarehousesMap و LocationPicker.
// منبع مرزها: geoBoundaries (سطح شهرستان/ADM3) — GeoJSON با ۱۰۶۶ ناحیه — مجوز باز، بدون هیچ محتوای Google.
// پروجکشن با geoMercator().fitExtent از روی مختصات واقعیِ خودِ فایل ساخته می‌شود
// (کالیبراسیون خودکار، بدون Bounding Box یا نقطه‌ی مرجع دستی). همان پروجکشن هم برای
// رندر پین‌ها و هم برای invert کردنِ کلیک (پیکسل → طول/عرض) استفاده می‌شود.
// ZoomableGroupِ react-simple-maps برای زوم/پن داخلی استفاده می‌شود (بدون پیاده‌سازی دستی).

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { ComposableMap, Geographies, Geography, Marker, ZoomableGroup } from 'react-simple-maps'
import { geoMercator, type GeoProjection } from 'd3-geo'
import type { FeatureCollection, Geometry } from 'geojson'
import { colors } from '@/lib/styles/tokens'

export type IranMapMarker = {
  id: string
  lat: number
  lng: number
  label?: string
  color?: string
}

type IranMapProps = {
  /** ارتفاع رَپر به پیکسل. SVG داخلش کامل و متناسب جا می‌شود. */
  height?: number
  /** پین‌های نمایشی (انبارها و…). */
  markers?: IranMapMarker[]
  /** اگر داده شود، نقشه تعاملی می‌شود: کلیک → (lat, lng). */
  onSelect?: (lat: number, lng: number) => void
  /** پینِ انتخاب‌شده/در‌انتظار (حالت تعاملی). */
  selected?: { lat: number; lng: number } | null
  /** برچسب دسترس‌پذیری. */
  ariaLabel?: string
}

// فضای مختصاتِ داخلیِ SVG (viewBox). نسبت ~۱٫۲۵ نزدیک به کشیدگیِ ایران در مرکاتور.
const VIEW_W = 800
const VIEW_H = 640
const PAD = 10
const MIN_ZOOM = 1
const MAX_ZOOM = 8

// کَش سطح-ماژول: فایل GeoJSON (۲۰مگابایت) فقط یک‌بار برای کل صفحه fetch می‌شود.
let featuresCache: Promise<FeatureCollection<Geometry>> | null = null
function loadIranFeatures(): Promise<FeatureCollection<Geometry>> {
  if (!featuresCache) {
    featuresCache = fetch('/geoBoundaries-IRN-ADM3.geojson')
      .then((r) => {
        if (!r.ok) throw new Error(`map fetch failed: ${r.status}`)
        return r.json() as Promise<FeatureCollection<Geometry>>
      })
  }
  return featuresCache
}

function round6(n: number): number {
  return Math.round(n * 1e6) / 1e6
}

export default function IranMap({
  height = 420,
  markers = [],
  onSelect,
  selected,
  ariaLabel,
}: IranMapProps) {
  const interactive = typeof onSelect === 'function'
  const [features, setFeatures] = useState<FeatureCollection<Geometry> | null>(null)
  const [failed, setFailed] = useState(false)
  const [zoom, setZoom] = useState(1)
  // رِف روی گروهِ داخلیِ متحولِ ZoomableGroup — برای invert دقیقِ کلیک زیرِ زوم/پن.
  const zoomGroupRef = useRef<SVGGElement | null>(null)

  useEffect(() => {
    let alive = true
    loadIranFeatures()
      .then((fc) => {
        if (alive) setFeatures(fc)
      })
      .catch(() => {
        if (alive) setFailed(true)
      })
    return () => {
      alive = false
    }
  }, [])

  // پروجکشنِ خودکار از روی مرزهای واقعیِ فایل — همین یک نمونه هم رندر هم invert می‌کند.
  const projection = useMemo<GeoProjection | null>(() => {
    if (!features) return null
    return geoMercator().fitExtent(
      [
        [PAD, PAD],
        [VIEW_W - PAD, VIEW_H - PAD],
      ],
      features,
    )
  }, [features])

  // مرکزِ متناظر با حالتِ fitExtent: در k=1، transform همانی (همه‌چیز سرِ جاش بماند).
  const mapCenter = useMemo<[number, number] | undefined>(() => {
    if (!projection) return undefined
    const c = projection.invert?.([VIEW_W / 2, VIEW_H / 2])
    if (!c || !Number.isFinite(c[0]) || !Number.isFinite(c[1])) return undefined
    return [c[0], c[1]]
  }, [projection])

  const handleMoveEnd = useCallback(
    (pos: { zoom?: number }) => {
      if (typeof pos.zoom === 'number' && Number.isFinite(pos.zoom)) {
        const z = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, pos.zoom))
        setZoom((prev) => (Math.abs(prev - z) < 1e-6 ? prev : z))
      }
    },
    [],
  )

  if (failed) {
    return <div style={boxMsgStyle(height)}>بارگذاری نقشه ناموفق بود.</div>
  }
  if (!features || !projection) {
    return <div style={boxMsgStyle(height)}>در حال بارگذاری نقشه…</div>
  }

  function handleClick(e: React.MouseEvent<SVGSVGElement>) {
    if (!interactive || !onSelect) return
    // زیرِ ZoomableGroup، محتوا در گروهِ داخلیِ متحول (forwarded ref) قرار دارد؛
    // برای invert باید CTM همان گروه خوانده شود، نه ریشه‌ی SVG.
    const g = zoomGroupRef.current
    const ctm = g?.getScreenCTM() ?? (e.currentTarget as unknown as SVGGraphicsElement).getScreenCTM?.() ?? null
    if (!ctm) return
    const pt = new DOMPoint(e.clientX, e.clientY).matrixTransform(ctm.inverse())
    const inv = projection!.invert?.([pt.x, pt.y])
    if (!inv) return
    const [lng, lat] = inv
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return
    onSelect(round6(lat), round6(lng))
  }

  const atMin = zoom <= MIN_ZOOM + 1e-6
  const atMax = zoom >= MAX_ZOOM - 1e-6

  return (
    <div style={{ ...wrapStyle, height }}>
      <ComposableMap
        // نمونه‌ی پروجکشن عیناً استفاده می‌شود (rsm اگر function باشد همان را برمی‌گرداند).
        projection={projection}
        width={VIEW_W}
        height={VIEW_H}
        role="img"
        aria-label={ariaLabel ?? 'نقشه‌ی ایران'}
        onClick={interactive ? handleClick : undefined}
        style={{
          width: '100%',
          height: '100%',
          display: 'block',
          cursor: interactive ? 'crosshair' : 'default',
        }}
      >
        <ZoomableGroup
          ref={zoomGroupRef}
          center={mapCenter}
          zoom={zoom}
          minZoom={MIN_ZOOM}
          maxZoom={MAX_ZOOM}
          onMoveEnd={handleMoveEnd}
        >
          <Geographies geography={features}>
            {({ geographies }) =>
              geographies.map((geo) => (
                <Geography
                  key={geo.rsmKey}
                  geography={geo}
                  fill="#eef1f6"
                  stroke="#cfd6e0"
                  strokeWidth={0.3}
                  tabIndex={-1}
                  style={{ outline: 'none', pointerEvents: interactive ? 'none' : undefined }}
                />
              ))
            }
          </Geographies>

          {markers.map((m) => (
            <Marker key={m.id} coordinates={[m.lng, m.lat]}>
              <g transform="translate(0,0)" style={{ pointerEvents: interactive ? 'none' : 'auto' }}>
                <circle r={6} fill={m.color ?? colors.navy} stroke="#fff" strokeWidth={1.5} />
                <circle r={2} fill="#fff" />
                {m.label ? <title>{m.label}</title> : null}
              </g>
            </Marker>
          ))}

          {selected ? (
            <Marker coordinates={[selected.lng, selected.lat]}>
              <g style={{ pointerEvents: 'none' }}>
                <circle r={8} fill={colors.orange} stroke="#fff" strokeWidth={2} />
                <circle r={2.5} fill="#fff" />
              </g>
            </Marker>
          ) : null}
        </ZoomableGroup>
      </ComposableMap>

      {/* کنترل زوم — روی رَپرِ بیرونی (نه داخل SVG) تا با Pointerهای نقشه تداخل نکند. */}
      <div style={zoomBarStyle} role="group" aria-label="کنترل زوم نقشه">
        <button
          type="button"
          aria-label="بزرگ‌نمایی"
          title="بزرگ‌نمایی"
          disabled={atMax}
          onClick={() => setZoom((z) => Math.min(MAX_ZOOM, z * 1.5))}
          style={{ ...zoomBtnStyle, opacity: atMax ? 0.45 : 1 }}
        >
          +
        </button>
        <button
          type="button"
          aria-label="کوچک‌نمایی"
          title="کوچک‌نمایی"
          disabled={atMin}
          onClick={() => setZoom((z) => Math.max(MIN_ZOOM, z / 1.5))}
          style={{ ...zoomBtnStyle, opacity: atMin ? 0.45 : 1 }}
        >
          −
        </button>
      </div>
    </div>
  )
}

// ── استایل‌ها ─────────────────────────────────────────────────────────
const wrapStyle: React.CSSProperties = {
  position: 'relative',
  width: '100%',
  borderRadius: 12,
  overflow: 'hidden',
  border: `1px solid ${colors.borderStrong}`,
  boxShadow: '0 1px 4px rgba(27,30,36,.05)',
  background: '#f7f8fa',
  boxSizing: 'border-box',
}
const zoomBarStyle: React.CSSProperties = {
  position: 'absolute',
  insetInlineEnd: 10,
  insetBlockEnd: 10,
  display: 'flex',
  flexDirection: 'column',
  gap: 6,
  zIndex: 1,
}
const zoomBtnStyle: React.CSSProperties = {
  width: 36,
  height: 36,
  borderRadius: 10,
  border: `1px solid ${colors.borderStrong}`,
  background: '#fff',
  color: colors.textPrimary,
  fontSize: 18,
  fontWeight: 800,
  lineHeight: '1',
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  boxShadow: '0 1px 6px rgba(27,30,36,.12)',
  cursor: 'pointer',
  userSelect: 'none',
  touchAction: 'manipulation',
}
function boxMsgStyle(height: number): React.CSSProperties {
  return {
    height,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: 13,
    color: colors.textMuted,
    border: `1px solid ${colors.borderStrong}`,
    borderRadius: 12,
    background: '#fff',
  }
}
