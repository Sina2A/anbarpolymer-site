# اَبرتسک سه‌گانه — نقشه‌ی GeoJSON + زوم · بازطراحی بنچینو · قفلِ ۶ تب

این بسته سه بخشِ مستقل را پیاده می‌کند. همه با `npx tsc --noEmit` (EXIT 0) و `npx next build` (EXIT 0) راستی‌آزمایی شده‌اند.

---

## بخش ۱ — تعویض فرمت نقشه TopoJSON → GeoJSON + دکمه‌های زوم

### چه چیزی عوض شد
- فایل نقشه از `geoBoundaries-IRN-ADM3.topojson` (۲٫۷ مگابایت) به `geoBoundaries-IRN-ADM3.geojson` تغییر کرد و در `public/` قرار گرفت.
- در [`src/components/IranMap.tsx`](src/components/IranMap.tsx):
  - `fetch('/geoBoundaries-IRN-ADM3.geojson')` مستقیماً یک `FeatureCollection` برمی‌گرداند — مرحله‌ی decode با `feature()`ِ `topojson-client` **حذف شد** (GeoJSON نیازی به decode ندارد).
  - importهای `feature` از `topojson-client`، تایپ `Topology` از `topojson-specification`، و ثابتِ `TOPO_OBJECT` حذف شدند.
  - زوم/پن داخلی با **`ZoomableGroup`ِ خودِ react-simple-maps** اضافه شد (نه پیاده‌سازی دستی)، به‌همراه دو دکمه‌ی «+ / −» روی رَپرِ نقشه — روی هر دو حالت (فقط‌نمایش و انتخاب‌گر) و هر دو breakpoint (موبایل/دسکتاپ) کار می‌کند.
- چون IranMap هسته‌ی مشترک است، `WarehousesMap.tsx` و `LocationPicker.tsx` **به‌صورت خودکار** زوم را به‌ارث می‌برند — بدون تغییر کد.

### وابستگی‌ها
- `topojson-client` در `package.json` **حفظ شد** — چون react-simple-maps بی‌قیدوشرط در بالای باندلِ خودش آن را `require` می‌کند (وابستگیِ زمان‌اجرا).
- `@types/topojson-specification` (devDep) هم **حفظ شد** — چون تایپ‌های خودِ react-simple-maps (`dist/core/types/index.d.ts`) از آن `import` می‌کنند؛ حذفش باعث خطای «Cannot find module» در typecheck می‌شود.
- فایل ambient اضافیِ `src/types/topojson-client.d.ts` که فقط برای importِ حذف‌شده‌ی IranMap بود، **حذف شد** (هیچ‌جای دیگری استفاده نمی‌شد).

### ⚠️ باگِ مهمی که در حین کار پیدا و رفع شد — چرخشِ رینگ‌ها (winding order)
فایل خامِ geoBoundaries با کنوانسیونِ RFC 7946 (رینگِ بیرونی خلافِ عقربه) نوشته شده، اما `d3-geo` جهتِ معکوس را «داخل» می‌داند. با decodeِ TopoJSON این مشکل پنهان بود (چون `topojson-client.feature()` رینگ‌ها را با چرخشِ سازگارِ d3 بازسازی می‌کند)، ولی با GeoJSONِ خام آشکار شد:
- **پیش از رفع:** هر ۱۰۶۶ ناحیه مساحتِ کروی > ۲π داشت؛ مجموع ≈ ۱۳۸۷۳ استرادیان (ایران باید ≈ ۰٫۰۴ باشد). `fitExtent` کلِ کره را در کادر جا می‌داد → ایران یک نقطه‌ی نامرئی، `center=[0,0]`. **روی مرورگر هم خراب رندر می‌شد.**
- **رفع:** فایل **یک‌بار به‌صورت آفلاین** rewind شد (هر پلی‌گانی که `geoArea > 2π` داشت، رینگ‌هایش معکوس شد — ۱۱۰۴ پلی‌گان). هیچ هزینه‌ی زمان‌اجرا یا وابستگیِ جدیدی اضافه نشد.
- **پس از رفع (راستی‌آزمایی از روی فایلِ نهایی):** مجموع مساحت = ۰٫۰۳۹۸۶ · محدوده = طول ۴۴٫۰۳–۶۳٫۳۳، عرض ۲۵٫۰۶–۳۹٫۷۸ (دقیقاً گستره‌ی ایران) · `scale≈2026`، `center≈[53.68, 32.72]` · تهران هم داخل کادر می‌افتد و هم `geoContains` تأیید می‌کند داخلِ خاکِ ایران است (پس invertِ کلیک روی مختصاتِ درست می‌نشیند).
- **جانبی:** فشرده‌سازیِ JSON (حذف whitespaceِ pretty-print) حجم را از ۲۰٫۴ به ۱۸٫۰ مگابایت (~۱۲٪) کم کرد.

### invertِ کلیک زیرِ زوم/پن
`ZoomableGroup` تبدیلِ زوم را روی یک `<g>`ِ داخلی اعمال می‌کند (که با forwarded ref در دسترس است). هندلرِ کلیکِ IranMap حالا `getScreenCTM()` را از **همان گروهِ داخلی** می‌خواند (نه ریشه‌ی SVG)، پس انتخابِ موقعیت در LocationPicker در هر سطح زوم/پن دقیق می‌ماند. مقدارِ `center` نقشه هم `projection.invert([VIEW_W/2, VIEW_H/2])` است تا در `zoom=1` تبدیل، همانی (identity) بماند و نمای fitExtent حفظ شود.

### ⚠️ نکته‌ی حجم / موبایل
GeoJSON (۱۸ مگابایت) هنوز خیلی بزرگ‌تر از TopoJSONِ قبلی (۲٫۷ مگابایت) است. Service Workerِ دست‌نویس (`public/sw.js`) پسوندِ `json`/`geojson` را cache نمی‌کند (در `STATIC_EXT` نیست)، پس فقط cacheِ HTTPِ مرورگر اعمال می‌شود و فایل هر بار برای بارِ اول دانلود می‌شود. کش سطح-ماژولِ IranMap تضمین می‌کند در هر بارگذاریِ صفحه فقط **یک‌بار** fetch شود.

---

## بخش ۲ — بازطراحی زیرتبِ «۷.۱ لیست بنچینو»

در [`src/app/admin-pricing/page.tsx`](src/app/admin-pricing/page.tsx)، تابع `Tab7_1Benchino`:
- **ترتیب برعکس شد:** فرمِ افزودن + جدولِ لیستِ قیمت‌ها **بالا**؛ نمودار روند + Dropdownِ انتخاب گرید (`Tab7_1BenchinoClient`) **پایین**.
- **افزودنِ inline:** یک `<form action={createBenchinoPriceAction}>` مستقیم روی همین صفحه اضافه شد (گرید از میان گریدهای فعال، نوع منبع دستی/API، قیمت دستی، اسنپشات API، برچسب منبع). دیگر رفتن به صفحه‌ی جدا لازم نیست. همان Server Actionِ موجود بازاستفاده شد (که بعد از ثبت به همین زیرتب redirect می‌کند).
- **حذف مسیر:** صفحه‌ی `src/app/admin-pricing/benchino/new/page.tsx` **حذف شد** (تنها لینک به آن، همین دکمه بود که با فرمِ inline جایگزین شد). مسیر ویرایش `benchino/[id]` دست‌نخورده ماند.
- بدون داده‌ی جعلی؛ فقط چیدمان و محلِ فرم عوض شد.

---

## بخش ۳ — قفل + بلورِ ۶ تبِ نیمه‌کاره + مسیر پیش‌فرض

در [`src/app/admin-pricing/page.tsx`](src/app/admin-pricing/page.tsx):
- شش تبِ `formula`, `waterfall`, `payment`, `volume`, `margins`, `approval` با کامپوننتِ محلیِ `LockedTab` پوشانده شدند: محتوای واقعیِ تب رندر می‌شود اما با `blur(8px)` + `pointerEvents:none` غیرفعال و یک overlayِ «🔒 این بخش در حال توسعه است» رویش قرار می‌گیرد (الگوی بلور از `GuestBlurGate`).
- تبِ `publish` (مدیریت بنچینو) **فعال** باقی ماند.
- مقدارِ پیش‌فرضِ `activeTab` از `'formula'` به `'publish'` تغییر کرد.
- در [`src/lib/sections.ts`](src/lib/sections.ts)، `href`ِ بخشِ «قیمت‌گذاری» به `/admin-pricing?tab=publish&subtab=benchino` تغییر کرد؛ پس ورود به قیمت‌گذاری مستقیم روی زیرتبِ ۷.۱ (بنچینو) می‌نشیند. (حالتِ active در AdminNav با `key` تطبیق داده می‌شود نه `href`، پس هایلایت سالم است — هم دسکتاپ هم درارِ موبایل.)

---

## فایل‌های این بسته

| فایل | بخش | نوع |
|---|---|---|
| `public/geoBoundaries-IRN-ADM3.geojson` | ۱ | افزوده (rewind‌شده، ۱۸ مگابایت) |
| `src/components/IranMap.tsx` | ۱ | بازنویسی (GeoJSON + ZoomableGroup + دکمه‌های زوم + invertِ زوم‌آگاه) |
| `src/app/admin-pricing/page.tsx` | ۲،۳ | ویرایش (بازچینشِ بنچینو + فرمِ inline + LockedTab + پیش‌فرضِ publish) |
| `src/lib/sections.ts` | ۳ | ویرایش (hrefِ قیمت‌گذاری) |

### فایل‌هایی که باید **حذف** شوند (tar نمی‌تواند حذف را منتقل کند — دستی اجرا کنید)
پس از باز کردنِ بسته روی ریپو، این‌ها را حذف کنید:
```
rm -f public/geoBoundaries-IRN-ADM3.topojson
rm -f src/types/topojson-client.d.ts
rm -f src/app/admin-pricing/benchino/new/page.tsx
```

## نصب
```
tar -xzf map-geojson-benchino-lock.tar.gz -C <repo-root>
# سپس حذف‌های بالا را اجرا کنید
npx tsc --noEmit
npx next build
```

## راستی‌آزمایی انجام‌شده
- `npx tsc --noEmit` → **EXIT 0**.
- `npx next build` → **EXIT 0**؛ مانیفستِ مسیرها: `benchino/[id]` هست، `benchino/new` نیست.
- assetِ نقشه روی dev: `HTTP 200`, `content-type: application/geo+json`, `18016336` بایت.
- پایپ‌لاینِ پروجکشن روی فایلِ نهایی: مساحت/محدوده/مرکزِ درستِ ایران؛ round-trip و `geoContains` تهران موفق.
- (نکته‌ی محیط: صفحاتِ نقشه پشتِ دیتابیس‌اند؛ در این سندباکس بدونِ DATABASE_URLِ معتبر، `/warehouses` خطای `P1000` می‌دهد — بی‌ربط به این تغییرات.)
