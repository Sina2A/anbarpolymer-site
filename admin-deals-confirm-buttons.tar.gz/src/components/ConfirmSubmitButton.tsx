'use client'

import { useFormStatus } from 'react-dom'

export default function ConfirmSubmitButton({
  message,
  children,
  style,
  className,
}: {
  message: string
  children: React.ReactNode
  style?: React.CSSProperties
  className?: string
}) {
  const { pending } = useFormStatus()
  return (
    <button
      type="submit"
      style={{ ...style, opacity: pending ? 0.6 : undefined, pointerEvents: pending ? 'none' as const : undefined }}
      className={className}
      disabled={pending}
      aria-busy={pending}
      onClick={(e) => {
        if (!confirm(message)) {
          e.preventDefault()
        }
      }}
    >
      {pending ? 'در حال ارسال…' : children}
    </button>
  )
}
